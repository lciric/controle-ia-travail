import ctypes, ctypes.util, os, sys
# Abandon des privilèges après `unshare` (qui exige root pour les espaces de noms) et juste avant l'organisme. D'abord
# (RV-04), dans l'espace de noms de montage neuf seulement : /tmp, /var/tmp, /dev/shm, /run/lock recouverts d'un système
# de fichiers en mémoire propre à cette exécution (rien n'y passe d'une exécution à l'autre) ; un échec arrête tout, rien
# ne tourne sans. Puis groupes vidés, gid puis uid non privilégiés, puis exec du programme demandé. Écrit par le noyau.
uid, gid = int(sys.argv[1]), int(sys.argv[2])
prives = [d for d in sys.argv[3].split(":") if d]
caches = [d for d in sys.argv[4].split(":") if d]
if prives or caches:
    libc = ctypes.CDLL(ctypes.util.find_library("c") or "libc.so.6", use_errno=True)
    # CL5-02 : dossiers inscriptibles par tous recouverts d'un systeme de fichiers en memoire propre a l'execution
    for d in prives:
        if libc.mount(b"tmpfs", d.encode(), b"tmpfs", 2 | 4, b"mode=1777,size=64m") != 0:
            # errno 2 (absent) : un parent inscriptible a deja ete couvert (dossier imbrique, CL6-02) ; le chemin est deja prive
            if ctypes.get_errno() == 2:
                continue
            sys.exit("dossier temporaire prive impossible sur " + d + " (errno " + str(ctypes.get_errno()) + ")")
    # CL5-01 : depot, code et dossiers d'un compte recouverts d'un systeme vide en lecture seule (l'organisme n'y lit rien)
    MS_RDONLY = 1
    for d in caches:
        if libc.mount(b"vide", d.encode(), b"tmpfs", MS_RDONLY, b"mode=0000,size=4k") != 0:
            # errno 2 (absent) : un parent a deja ete couvert (par un dossier prive ou a cacher) ; le chemin est deja cache
            if ctypes.get_errno() == 2:
                continue
            sys.exit("dossier a cacher impossible sur " + d + " (errno " + str(ctypes.get_errno()) + ")")
os.setgroups([])
os.setgid(gid)
os.setuid(uid)
if os.getuid() != uid or os.geteuid() != uid:
    sys.exit("abaissement de privileges impossible")
os.execv(sys.argv[5], sys.argv[5:])
