# Journal de travail v4 — début Sat Nov 14 01:35:38 UTC 2026
- CL de la v3 (07f33db5…) vérifiée et lue en entier (100 l.).
- S vérifié : K-HC1 §6 : trois voisins « à lire en priorité », un seul « cœur du phénomène » ; Choi 2601.04790 « autorité dans un cadre d'évaluation » ; K-4B1 §6 l.157 « Rien sur le gain continu de la corruptibilité d'un juge appris tant que Gao, Schulman et Hilton n'est pas lu sur PDF » → vise la régression par intensité de HC1 → HC1 non.
- T vérifié : CL papier B §4 l.74 « Bonjour et collègues 2022 : à lire en priorité, parce que c'est une statistique conjointe entre agents… » sans restriction → énoncé 1 non.
- V : v1 (section 9, pistes), CL v1 (sections 5, 6, M13), rapports du compte 2 (K-B §6, K-HC5 §5) et CL papier B §4 : aucune désignation « à lire d'abord » contre H3, H5, H7 ; rapports du niveau 3 non rouverts → non vérifié pour eux.
- Final oui : H3, H5, H7, T (c)-(f).
- 01:37 parties v4 et journal brouillon écrits
- 01:38:19 fichiers v4 écrits ; contrôle 12 extraits, 0 erreur ; archive ; scellement
