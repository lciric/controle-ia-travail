"""Vérifie que les empreintes des huit fichiers nouveaux (rapports v2 et contre-lectures)
sont égales à celles de l'index v2 du compte 2 et qu'elles figurent en entier dans la synthèse v5.
Lancé par python3 -I ; ne lit que des fichiers nommés."""
import hashlib, re, sys
D = "/home/user/controle-ia-travail/docs/sources/lecture-pdf-niveau3/compte-2/"
E = "/home/user/controle-ia-travail/docs/etat-de-l-art/"
noms = ["rapport-HC4-2609.15994-v2.md", "rapport-H1-2609.19101-v2.md", "rapport-L-voisins-v2.md",
        "rapport-L-ker2007-v2.md", "contre-lecture-rapport-HC4-2609.15994-v1.md",
        "contre-lecture-rapport-H1-2609.19101-v1.md", "contre-lecture-rapport-L-voisins-v1.md",
        "contre-lecture-rapport-L-ker2007-v1.md"]
index = open(D + "index-rapports-compte-2-v2.md", encoding="utf-8").read()
v5 = open(E + "etat-de-l-art-verifie-niveau3-v5.md", encoding="utf-8").read()
echecs = 0
for n in noms:
    h = hashlib.sha256(open(D + n, "rb").read()).hexdigest()
    dans_index = h in index
    dans_v5 = h in v5
    comp = open(D + n + ".sha256", encoding="utf-8").read().split()[0]
    ok = dans_index and dans_v5 and comp == h
    echecs += (not ok)
    print(n, h, "index:", dans_index, "v5:", dans_v5, "compagnon:", comp == h)
print("échecs :", echecs)
sys.exit(1 if echecs else 0)
