# Journal — contre-lecture de la synthèse de niveau 3, version 5 (contre-lecteur, modèle B)

Heures relevées par `date -u` ; celle de ce journal : Sat Nov 14 07:40:06 UTC 2026.
Premier relevé de la session (sortie de la commande de vérification de la consigne) : Sat Nov 14 07:33:05 UTC 2026.

1. Consigne commune vérifiée (cb0623c4…, conforme), lue en entier ; interdits communs v2 lus en entier.
2. Absence des deux sorties vérifiée par ls sur leurs noms ; empreintes de la v5, de son journal, de la v4, de sa confirmation et de l'index v2 recalculées, conformes.
3. Index v2 lu en entier ; empreintes des huit rapports et contre-lectures recalculées (scripts/verifier_empreintes_v1.py, 0 échec ; sortie : sortie-verifier-empreintes.txt). Empreintes de rapport-HC6-v2.md et de sa contre-lecture calculées aussi, contenu non ouvert.
4. diff v4 / v5 écrit dans diff-v4-v5.txt (61 lignes retirées, 122 ajoutées, 52 blocs) ; lu en entier.
5. Confirmation de la v4 lue en entier.
6. K-HC4b : en-tête, sections 0, 1, 3.1 à 3.3, 3.5, 3.6, 5 à 12 ; sa contre-lecture : sections 0 à 2.
7. v5 : prononcé, règle et tables de la section 1 (papiers A, B, C) lus en entier.
8. K-Lv : en-tête, sections 0, 1, 3 à 10 ; K-Lk : en-tête, sections 0, 1, 3 à 9 ; contre-lectures : verdicts, constats, tables, sections finales.
9. K-H1b : verdict, suite donnée, chiffres, déclarable ; plan de sa contre-lecture.
10. v5 : sections 9, 10.2, T, H3, H4′, H5, H7, H8, tête et fin de la section 12 ; journal de la v5 en entier.
11. Recherches de mots dans la v5 (fichier nommé) : « majore », « lot de taille », « concentr », « fragment », « puni », « rapport de vraisemblance », « 2609.15994 », « en attente » ; dans la v4 : « source honnête ».
12. Numéros de ligne cités vérifiés par sed sur la v5.
13. Rapport écrit, puis corrigé avant scellement (nombre de blocs, un numéro de ligne, gravité du constat G).

Aucune commande git, aucun réseau, aucun appel de modèle, aucun PDF, aucune archive ouverte, aucun registre. Aucun refus, aucune ouverture fautive.
