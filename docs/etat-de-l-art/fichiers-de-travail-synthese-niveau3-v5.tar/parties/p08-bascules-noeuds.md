---

## 7. Décisions intervenues depuis la v1

| décision | empreinte | ce qu'elle fixe | effet dans ce document |
|---|---|---|---|
| N-068 | `ba6b2db355515cd660d676b733f4d467f8a9c055d4d8c6d997d4ef898caef889` | HC2 reformulée : sonde de l'agent auteur, g en fonction de l'intensité, comparé aux juges ; plan apparié non revendiqué ; lettre de N-013 pour HC4 restreinte ; sources du contrôle du style de HC2b ajoutées | sections 1 et 5 (HC2, HC2b, HC4) |
| N-069 | `6e0d9d4036a848a67e0f5e14c1ed9b107c6ba1aa1041ab09ad73af69c427c370` | deux énoncés du papier B resserrés ; « cœur vierge » retiré ; pic par agent base nommée de G2 ; écart entre agents base obligatoire ; bascule non déclenchée | sections 1, 4 et 8 |
| N-070 | `7c4ce2210b2e48db4f8349ed85cd50387586b3eb176d364be0d280647d25992f` | H9 retirée des hypothèses revendiquées ; mesure descriptive par rang de relais, avec et sans moniteur à chaque passage | sections 1 et 4 (H9) |
| N-067 | `966dd9dc3fae61cbe1f10ee2a54f401ddf7af5041eeaacd81ad9f8b264661589` | O2 et O11 resserrées (O2 : le seul nul des lois connues ; O11 : plus aucune revendication d'idée) ; O1, sceau de O3 et O17 non revendiqués ; forme de O12 resserrée ; clause d'usage public de O4 et de O2 ; statuts les plus durs pour O9, O10, O13, O19 ; 2611.00643 cité comme précédent du rôle 1 | sections 1 et 6 |

Ces quatre décisions, toutes lues, sont des « versions retenues », corrigées selon leur contre-lecture et scellées (compagnons conformes). Elles ne modifient pas le programme v2 : elles en fixent la lecture.

**Mots de Lazar depuis la v4** (index v2 du compte 2, `e1d9f319…`, ligne 25 ; je n'ai pas lu le registre qui les inscrit) :

| mot | état | effet dans ce document |
|---|---|---|
| « HC4 : juge génératif, go » (C2-0057) | inscrit par la mère (R-2649) | sections 0, 1 et 5 (HC4) : une seule ligne ; la lecture large devient une note ; nœud retiré de la section 9 |
| « HC6 : bénin = écrit d'avance, go » (C2-0059) | inscrit par la mère (R-2649) | sections 0, 1 et 5 (HC6) ; nœud retiré de la section 9 |
| « H6 : hors audit, aucun moniteur dans l'intervention, go » (C2-0024) | en attente d'inscription | aucun : H6 inchangé, nœud gardé |
| « L : L1 en remarque avec renvoi à Ker, go » (C2-0065) | en attente d'inscription | porté comme demandé, non appliqué (sections 0, 1, 3 et 9) |

---

## 8. Bascules et portes

| bascule ou porte | état | raison |
|---|---|---|
| « Publication externe du cœur séquentiel sur sondes » (programme, section 13) | **non déclenchée** — décidé par Lazar (R-2571, point 9a, rapporté par N-069, section 9), veille rapprochée sur les suites de NARCBench | NARCBench annonce la lecture séquentielle depuis sa version 2 du 9 mai 2026 (p. 8, 9) et la maintient dans sa version 4 du 12 octobre 2026 (p. 3, 18, 19, 26) sans la faire ; la version 4 lit déjà les sondes à chaque tour sans les cumuler (p. 18) (K-H2) ; 2611.02153 et 2611.10620 ne viennent pas des équipes nommées et ne publient pas de test toujours valide (S-7B). **Réserve** : les versions 3 et 5 de NARCBench ont été lues au niveau 3 par C1, qui relève dans la version 5 l'annonce du séquentiel sans résultat (p. 3, 18, 19, 26) ; aucune n'est relue par le compte 2 ; aucune version postérieure à la version 5 n'a été cherchée ; codes de HELIOS et d'ORBIT non lus. Texte de la bascule : « Oxford/NYU » ; aucune affiliation à New York n'est trouvée dans la version 5 de HELIOS (p. 1, C1) ; HELIOS et NARCBench désignent le même article (2604.01151). |
| Porte GC (N-005) : une source couvre la pièce revendiquée de HC1 | **non déclenchée** | ni les sources visées, ni 2607.00415 (K-HC1), ni les pièces neuves ne couvrent la destination libre testée contre les deux nuls, par famille, dans un moniteur de contrôle. |
| « g des sondes > 0 » → papier C sur la contamination de construit | **non déclenchée** (elle dépend d'une mesure) | inchangée par N-068, qui la lit désormais sur la sonde de l'agent auteur ; des contre-indices publiés la rendent plus probable (section 5, HC2). |
| Repli (b) de N-035 pour H9 | **appliqué** par N-070 | H9 retirée des hypothèses revendiquées ; mesure descriptive. |
| Repli de N-004, option (c), pour L (L présenté comme corollaire cité, effort porté sur la mesure) | **non déclenché** ; rappelé par K-Lv et K-Lk ; toute bascule effective est un nœud (section 9) | le cœur de L1 est occupé en partie et la décroissance en n₀ occupée (Ker 2006, Ker 2007) ; le resserrement est à décider par Lazar. |
| « G1 échoue », « 8 milliards trop faible », « élicitation rouge insuffisante », « pas de témoin de vérité différée » | sans objet | elles dépendent de mesures, non de l'état de l'art. |
| Porte G2 (statistique de population supérieure à l'agrégation par agent) | sans objet ici | le pic par agent devient base nommée de G2 et le cas « pas de gain » est prévu (N-069, point 9b) ; contre-indice publié à sonde égale (2611.10620, tableau 3, p. 14). |
| Veille « toute suite de 2607.08066 » (programme, section 16) | **une suite constatée** | 2611.04556 dit prolonger ces auteurs (p. 17, V2). |

---

## 9. Nœuds ouverts

Présentés par le compte 2 ou par les rapports qu'il a contre-lus ; **aucun n'est tranché ici**. Une ligne chacun, avec la source. Depuis la v4, deux nœuds sont fermés par un mot de Lazar inscrit (section 7) : le sens de « juge » pour HC4 (juge génératif) et celui de « bénin » pour HC6 (écrit d'avance) ; ils ne figurent plus ici. Un nœud est ajouté : la collision sur L.

| nœud | source |
|---|---|
| **H6, lecture de l'énoncé** : « succès » audit compris ou hors audit, « non spécifique » au sens « non déclenché » ou « aucun moniteur dans l'intervention » — Lazar a demandé « hors audit, aucun moniteur dans l'intervention » le 2026-11-13 vers 23:29 UTC, **mot non encore inscrit par la session mère** | K-H6, section 1 ; mot de Lazar dans le compte 2 |
| **H6, portée** : restriction au sabotage diffus et aux interventions sur l'agent (absente du texte de N-015, présente par le contexte) | K-H6, section 1.2, Q3 |
| H6, ajout d'une « différence de pentes testée » à l'énoncé (resserrement) | K-H6, section 6 |
| **L, collision sur une composante revendiquée** : le cœur de L1 est occupé en partie (Ker 2006) et la décroissance en n₀ occupée (Ker 2006, Ker 2007), dans une zone que N-003/N-004 revendique (« invariances exactes ») ; resserrement de la revendication, ou repli de N-004, option (c) — décision du directeur. Mot de Lazar « L : L1 en remarque avec renvoi à Ker, go » **en attente d'inscription** (C2-0065) | K-Lv, sections 4 et 7 ; sa contre-lecture, section 9 ; K-Lk, sections 5 et 7 ; index v2, l. 25 |
| **Rôle 1 de N-065, énoncé après 2609.28614** : inchangé avec citation obligatoire de 2609.28614, ou resserré | K-4B1, sections 4 et 9 |
| **Tr, « robustesse du maximum établie au grain du jeton »** : la prémisse de l'énoncé est contestée par 2601.04603 (p. 6 ; figures 2b et 5b) ; toucher à l'énoncé est une modification d'hypothèse | K-Tr, « Nœud pour le directeur » |
| **Tr, divergence de lettre** : « non trouvé dans les pièces lues » (lecteur, noyau) contre « occupé en partie » (contre-lecteur, composantes faites) ; ce document donne le plus dur | K-Tr, verdicts ; sa contre-lecture, verdicts |
| **G1 (H2), base « somme à horizon fixe »** des mêmes scores de sondes, lue en fin d'épisode, seuil calibré sur épisodes honnêtes entiers ; à fixer s'il est accepté : horizon, métrique, place dans G1 ou dans H2 | K-H2, section 9 (proposition de son contre-lecteur, constat E) |
| H8, lecture dure de S-7A (« occupe en partie » par 2610.17301) contre lecture douce | v1, divergence 9 ; contre-lecture de la v1, M3 et m8 |
| **HC2, déclaration** : par l'enregistrement public que prévoit N-068, section 8, ou selon la règle de la colonne (« non statué » faute de jugement d'un lecteur) | contre-lecture de la v2, constat D ; N-068, section 8 |
| **T, composantes (a) et (b)** : à déclarer ou non après lecture de Koning et Hemerik 2023 et de Lehmann et Stein 1949 | contre-lecture de la v2, constat B ; K-T, section 9 |
| Rôle 3 de N-065 (famille de menaces diffuses) | v1, section 5 ; N-065 dans les consignes du dépôt |
| Lecture interne du sous-agent comme hypothèse nouvelle (hors de H9) | N-070, section 8 |
| HC1, prédictions 1 et 3 au vu de leurs contre-indices ; HC5, partie « juges entre eux » de la matrice ; SafeDream aux motifs de N-007 ; manière de dire les erreurs du texte envoyé | v1, section 7, points non couverts par une décision lue |

