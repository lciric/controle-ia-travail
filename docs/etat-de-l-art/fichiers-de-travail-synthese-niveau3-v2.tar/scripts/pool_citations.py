"""Rassemble les JSON de citations contrôlées des 13 rapports v2 du compte 2 en un seul pool."""
import json, sys, glob, os, hashlib
base = sys.argv[1]
out = sys.argv[2]
noms = {
 'L': 'fichiers-de-travail-L-lot8-v2/citations-L-v2.json',
 'T': 'fichiers-de-travail-T-lot8-v2/citations-T-v2.json',
 'H6': 'fichiers-de-travail-H6-v2/citations-H6-v2.json',
 'HC5': 'fichiers-de-travail-HC5-v2/citations-HC5-v2.json',
 'HC1': 'fichiers-de-travail-HC1-2607.00415-v2/citations-HC1-v2.json',
 'HC6': 'fichiers-de-travail-HC6-v2/citations-HC6-v2.json',
 'Tr': 'fichiers-de-travail-Tr-v2/citations-Tr-v2.json',
 'HC4': 'fichiers-de-travail-HC4-v2/citations-HC4-v2.json',
 'H1': 'fichiers-de-travail-H1-v2/citations-H1-v2.json',
 'H2': 'fichiers-de-travail-H2-v2/citations-H2-v2.json',
 'papierB': 'fichiers-de-travail-papierB-v2/citations-papierB-v2.json',
 '4B1': 'fichiers-de-travail-4B-partie1-v2/citations-4B-partie1-v2.json',
 '4B2': 'fichiers-de-travail-4B-partie2-v2/citations-4B-partie2-v2.json',
}
pool = []
for k, rel in noms.items():
    p = os.path.join(base, rel)
    raw = open(p, 'rb').read()
    h = hashlib.sha256(raw).hexdigest()
    d = json.loads(raw)
    if isinstance(d, dict):
        for key in ('citations', 'items', 'liste'):
            if key in d:
                d = d[key]; break
    n = 0
    for e in d:
        if not all(x in e for x in ('pdf', 'sha256', 'page', 'citation')):
            print('format inattendu', k, list(e.keys())); continue
        pool.append({'rapport': k, 'json': rel, 'json_sha256': h, 'pdf': e['pdf'], 'sha256': e['sha256'], 'page': e['page'], 'citation': e['citation']})
        n += 1
    print(k, n, h)
json.dump(pool, open(out, 'w'), ensure_ascii=False, indent=1)
print('total', len(pool))
