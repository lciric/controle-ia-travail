import json, sys
pool = json.load(open(sys.argv[1]))
for motif in sys.argv[2:]:
    print('==', motif)
    for e in pool:
        if motif.lower() in e['citation'].lower():
            print(' ', e['rapport'], e['pdf'], e['page'], '|', e['citation'][:220])
