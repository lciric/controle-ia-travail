Juste : « Otherwise, we rely solely on the probe. » ; altéré : « Otherwise, we rely only on the probe. » ; français : « le contexte seul n'y suffit pas ».
