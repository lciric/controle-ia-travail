"""Extrait tous les passages entre « » d'un fichier Markdown, classe les passages anglais,
et exige que chacun figure (à l'identique, après normalisation des blancs) dans une citation contrôlée du pool.
Usage : python3 -I controle_guillemets_v2.py SYNTHESE POOL SORTIE_JSON"""
import json, re, sys, unicodedata
txt = open(sys.argv[1], encoding='utf-8').read()
pool = json.load(open(sys.argv[2], encoding='utf-8'))
def norm(s):
    s = unicodedata.normalize('NFC', s)
    s = s.replace('’', "'").replace('‘', "'").replace('“', '"').replace('”', '"')
    return re.sub(r'\s+', ' ', s).strip()
ANG = set('the of and to in is are was were that this with for on by be not as an at from which it its or than we our their they can only also into one more no all any has have been would could should may'.split())
FR = set('le la les des du de et est sont un une dans pour par sur au aux que qui ne pas en ce cette ces nous on se sa son ses leur il elle à où dit'.split())
segs = re.findall(r'«\s*(.*?)\s*»', txt, flags=re.S)
sortie, inconnus, manquants = [], [], []
vus = set()
for seg in segs:
    mots = re.findall(r"[A-Za-zÀ-ÿ']+", seg.lower())
    na = sum(1 for m in mots if m in ANG); nf = sum(1 for m in mots if m in FR)
    accents = bool(re.search(r'[àâçéèêëîïôûùüÿœ]', seg.lower()))
    anglais = (na >= 1 and na >= nf and not accents) or (na >= 3 and na > nf)
    if not anglais:
        if na >= 1 and nf == 0:
            inconnus.append(seg)
        continue
    n = norm(seg)
    if n in vus: continue
    vus.add(n)
    trouve = [e for e in pool if n in norm(e['citation'])]
    if not trouve:
        manquants.append(seg); continue
    e = trouve[0]
    sortie.append({'pdf': e['pdf'], 'sha256': e['sha256'], 'page': e['page'], 'citation': seg,
                   'source': 'JSON contrôlé du rapport ' + e['rapport'] + ' (' + e['json'] + ', sha256 ' + e['json_sha256'] + ')'})
json.dump(sortie, open(sys.argv[3], 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('passages entre guillemets :', len(segs))
print('extraits anglais retenus :', len(sortie))
print('extraits anglais SANS source contrôlée :', len(manquants))
for m in manquants: print('  MANQUANT :', m[:150])
print('passages à classer à la main (mots anglais, aucun mot français) :', len(inconnus))
for m in inconnus: print('  ?', m[:150])
