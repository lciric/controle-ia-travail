import json, sys
C2='docs/sources/lecture-pdf-niveau3/compte-2/'; EA='docs/etat-de-l-art/'
L=[(C2+'rapport-4B-partie1-v2.md',"Rien sur le gain continu de la corruptibilité d'un juge appris tant que Gao, Schulman et Hilton n'est pas lu sur PDF"),
(C2+'rapport-4B-partie1-v2.md',"touche (d) et l'idée même du papier C"),
(C2+'rapport-HC1-2607.00415-v2.md',"à lire en priorité : autorité dans un cadre d'évaluation"),
(C2+'rapport-HC1-2607.00415-v2.md',"à lire en priorité : juges sous biais, cœur du phénomène de HC1"),
(C2+'rapport-HC1-2607.00415-v2.md',"à lire en priorité : lecture interne de la flagornerie"),
(C2+'rapport-HC1-2607.00415-v2.md',"Ce n'est pas un trou du champ (R8) : l'exposition nommée par M7 n'est pas lue (section 6)"),
(C2+'contre-lecture-rapport-HC1-2607.00415-v1.md',"l'exposition nommée par M7 et les voisins du § 6 du rapport ne sont pas lus"),
(C2+'contre-lecture-rapport-papierB-v1.md',"Bonjour et collègues 2022 : à lire en priorité, parce que c'est une statistique conjointe entre agents, en boîte noire, antérieure aux agents à modèle de langage"),
(C2+'contre-lecture-rapport-H1-2609.19101-v1.md',"Mon avis sur la colonne « déclarable » de H1 : non, pour l'instant."),
(EA+'etat-de-l-art-verifie-niveau3-v3.md',"désignés en priorité par K-HC1 contre le phénomène (cédé)"),
(EA+'etat-de-l-art-verifie-niveau3-v3.md',"aucune pièce non lue n'est désignée, par un lecteur ou un contre-lecteur"),
(EA+'etat-de-l-art-verifie-niveau3-v3.md',"aucune des trois ne compare sondes et moniteur de texte"),
(EA+'etat-de-l-art-verifie-niveau3-v3.md',"Une désignation qui vise l'énoncé entier, ou qui précède toute phrase publique, vaut pour toutes ses composantes"),
]
json.dump([{"fichier":f,"citation":c} for f,c in L],open(sys.argv[1],'w'),ensure_ascii=False,indent=1); print(len(L))
