# Contrôle : chaque citation figure dans le fichier nommé du dépôt (espaces normalisés, astérisques de gras retirés).
# Usage : python3 -I controle_citations_fichiers_v1.py <json> <racine du dépôt>
import json, sys, os, re, hashlib
def norm(s):
    s = s.replace('*', '').replace('’', "'").replace(' ', ' ').replace(' ', ' ')
    return re.sub(r'\s+', ' ', s).strip()
def main():
    cits = json.load(open(sys.argv[1])); root = sys.argv[2]; ech = 0; cache = {}
    for i, c in enumerate(cits, 1):
        p = os.path.join(root, c['fichier'])
        if p not in cache:
            raw = open(p, 'rb').read(); cache[p] = (norm(raw.decode('utf-8')), hashlib.sha256(raw).hexdigest())
        ok = norm(c['citation']) in cache[p][0]
        ech += (not ok)
        print(i, 'OK' if ok else 'ECHEC', os.path.basename(p), cache[p][1][:12], '|', c['citation'][:70])
    print('citations :', len(cits), '; échecs :', ech); return ech
if __name__ == '__main__': sys.exit(1 if main() else 0)
