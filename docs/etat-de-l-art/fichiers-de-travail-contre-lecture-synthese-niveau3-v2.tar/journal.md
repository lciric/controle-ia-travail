== journal contre-lecture synthese v2
Sat Nov 14 01:01:17 UTC 2026
consigne lue, empreinte cb0623c4 conforme; interdits-communs-v2.md non ouvert (hors liste du mandat)
Sat Nov 14 01:01:35 UTC 2026
empreintes v2, journal, tar, v1, contre-lecture v1, index, 13 rapports v2, 13 contre-lectures : toutes égales à l'attendu/à l'index. Décisions : N-068 ba6b2db3, N-069 6e0d9d40, N-070 7c4ce221 (égales à ce que dit la v2) ; N-065 f820e90d ; N-067 966dd9dc. Sorties absentes au ls de 01:01.
v2 lignes 1-150 lues.
Sat Nov 14 01:01:54 UTC 2026
v2 lue en entier (658 lignes).
Sat Nov 14 01:02:28 UTC 2026
contre-lecture v1 lue en entier (sauf 1.1-1.3, lignes 74-144, non lues : méthode et contrôles).
PISTES: (1) HC2 'oui' : absent de la liste des déclarables ET de la section 6 de la contre-lecture v1 -> la règle de la v2 ne le couvre pas. (2) H1/H2 : 2603.04069 et 2609.19101 (C5 'à lire contre H1 et H2') lus par K-Tr pour Tr seulement ; 2601.04603 pour H2 idem ; v2 10.2 ne le dit pas. (3) HC6 'oui' avec noeud 'bénin' ouvert + Khan 2024 prioritaire. (4) T 'oui' : Koning et Hemerik 2023 voisin direct non lu. (5) H9 dans liste déclarables v1 -> non (N-070) ok.
Sat Nov 14 01:03:11 UTC 2026
K-T lu: l.1-8, 43-84, 308-411 ; CL-T: l.43-50,194-257. K-HC6 lu: l.1-8,43-87,161-170,209-214,258-339 ; CL-HC6: l.26-54,75-78,105-112,135-188.
CONSTATS: T 'oui' trop large: K-T s.9 Koning-Hemerik 'voisin direct', Lehmann-Stein 'premier endroit où chercher' l'énoncé de puissance = (b) ; s.8 pt 7 'voisins restent à lire'. HC6 'oui': K-HC6 s.12 Khan 2024 'plus proche de HC6... À lire en priorité contre HC6', s.10 'bénin à fixer' ; CL-HC6 s.1 réserve R4 ; recherche niveau 3 faite sous sens 1 seulement.
Sat Nov 14 01:03:57 UTC 2026
K-H1 lu l.42-94,263-335 ; CL-H1 l.30-62,179-208. K-H2 lu l.11-19,44-67,113-224.
CONSTATS: règle 'déclarable' = critère de mots ('avant toute phrase publique') ; K-H2 'À lire en premier' Makins/Oldfield, K-HC6 'À lire en priorité', K-H1 réserve lots 9 et 10. v2 dit 'versions 3 et 5 de NARCBench non lues' alors que C1 a lu v3 et v5 (CL v1 m6 ; v2 cite HELIOS v5 p.18,27,30 C1) -> incohérence interne. Exposition section 5 CL-v1 'reste à dire' absente de la règle.
Sat Nov 14 01:05:04 UTC 2026
K-HC1 lu l.18-25,77-90,111-182 ; CL-HC1 l.17-24,59-64,106-125,151-170. K-B lu l.20-32,131-169 ; CL-B l.16-30,70-88. N-065 lue en entier. N-067 lue l.1-45 et 72-145 (sections 0-2, 4-10 ; section 3 non lue).
CONSTATS N-067: (i) O11 : N-067 s.4 pt 4 'plus aucune revendication d'idée' ; v2 l.123 dit 'revendiqué dans sa forme seulement (N-064)' -> faux, N-064 pts 2-4 remplacés. (ii) 2611.00643 : N-067 s.9 'cité comme précédent de la prémisse du bras juge génératif du rôle 1 (R-2571 5b)' ; v2 l.426 'sans décision' -> faux. (iii) O3 : N-067 s.4 pt 6 'aucune priorité affirmée tant que durcissement' ; v2 l.115 'reste revendicable: le tirage semé'. (iv) O12 forme: manque 'mondes où toute promotion est fausse', 'libre dans ses propositions'. (v) contre-indices N-067 s.7 (O9, O2(d), O12 même signe) absents de v2 s.6. (vi) clause usage public vaut aussi pour l'énoncé retenu de O2.
Sat Nov 14 01:05:52 UTC 2026
N-068 lue l.9-23,61-81,101-125 ; N-069 l.9-22,64-80,95-130 ; N-070 l.56-65,98-110. K-H6 lu l.31-103,258-304 ; CL-H6 l.23-30,123-147,178-184,217-227.
N-068 s.8 et N-069 s.9 : 'Enregistrement public des pièces libres : HC2 / stat papier B y figurent sous l'énoncé de la section 4' -> appui de 'oui' pour HC2 et papier B, non cité par la règle de la v2. N-070 s.8 : H9 n'y figure pas. v1 l.71,116,527 : HELIOS version 5 lue par C1 (p.3,18,19,26) -> 'versions 3 et 5 non lues' de la v2 est faux pour v5. H6 phrase jury : 'à intensité fixe' alors que k=1 à 5 (CL-H6 s.4 'échelle d'intensité') ; bras 'moins suspect' omis ; 2511.02997 et 2607.13087 non dits dans la phrase.
Sat Nov 14 01:06:31 UTC 2026
K-Tr lu l.44-73,121-234 ; CL-Tr l.41-56,141-150,176-184,199-205.
CONSTAT FORT H1: K-Tr pièce 3 (2609.19101v2, l.146-170) : 'comparaison avec un moniteur fondé sur un grand modèle de langue', 'we select probe thresholds that match the LLM monitor’s false positive rate' (p.9), 'probes catch 3.0 and 33.1 percentage points more hacks' (p.9), vrais positifs 41,1 -> 80,2 % (p.9), dans des déroulés d'agents. = sonde contre moniteur de texte à FP apparié dans un agent (piratage de la récompense). Lue contre Tr seulement ; CL-v1 M1 (l.286-291) la désignait 'à lire contre H1 et H2' (C5). La v2 section 3 H1 et 10.2 H1 ne la nomment pas ; écrit 'aucune ne compare sondes et moniteur de texte' pour les seules pièces de K-H1. CL-Tr J : 'à lire avant toute phrase publique : Wilhelm et Kao ; What the Monitor Saw ; Yang' (l.205).
Sat Nov 14 01:07:08 UTC 2026
K-L lu l.41-69,195-261 ; CL-L l.32-42,171-209. K-HC5 lu l.30-52,252-308 ; CL-HC5 l.25-32,172-193,246-250. K-HC4 lu l.37-65,266-295,340-354 ; CL-HC4 l.22-36,188-209.
CONSTATS: 10.3 'lues par personne' inexact pour McKenzie 2506.10805 (K-Tr l.224 'Lu au niveau 2 contre Tr' ; K-H1 'déjà au niveau 2'). HC2 : K-HC4 s.11 'matière pour le lecteur de HC2 ; je ne prononce rien' ; la v2 conclut seule 'ce n'est pas l'énoncé de N-068'. L : 'non-compensation' (K-L s.0 pt 3) absente de la liste v2 (mineur).
Sat Nov 14 01:08:19 UTC 2026
K-4B1 lu l.18-33,125-166 ; K-4B2 l.20-37,147-192 ; CL-4B1 l.16-24,127-135 ; CL-4B2 l.17-24,56-77.
CONSTATS: Gao-Schulman-Hilton 2210.10760 'touche (d) et l'idée même du papier C' (K-4B1 s.7 pt 2 ; CL-4B1 s.6 pt 2) : la v2 ne le rattache qu'au rôle 1. Yang 2605.26156, Li 2606.10159 (attaques de style adaptatives contre des juges) : rattachés au rôle 1 seulement, touchent HC1/HC3/HC4. Phrase jury H2 : reprend 'une somme lue en fin d'épisode' que K-H2 refuse (réserve maintenue E ; divergence 30 de la v2). Phrase T : ne dit pas les voisins non lus. Phrase HC6 : ne dit pas Khan.
Sat Nov 14 01:09:40 UTC 2026
contrôles par programme : 11 extraits de la synthèse sur PDF, 0 échec ; citations de fichiers : voir controle-citations-fichiers.txt ; tests juste/altéré faits.
Sat Nov 14 01:13:06 UTC 2026 : rapport écrit ; fin de rédaction 2026-11-14 à 01:13:06 UTC ; archive et scellement dans la même commande.
