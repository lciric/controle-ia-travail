# Contrôle indépendant des extraits de la synthèse v2 (JSON de l'auteur) sur les PDF nommés.
# Usage : python3 -I controle_citations_pdf_v1.py <json> <dossier des PDF (parcouru)> 
import json, sys, os, subprocess, hashlib, re, unicodedata
def norm(s):
    s = unicodedata.normalize('NFKC', s)
    for a, b in (('ﬁ','fi'),('ﬂ','fl'),('’',"'"),('‘',"'"),('“','"'),('”','"'),
                 ('–','-'),('—','-'),('−','-'),('­','')):
        s = s.replace(a, b)
    s = re.sub(r'-\s*\n\s*', '', s)      # césures
    s = re.sub(r'\s+', ' ', s)
    return s.strip().lower()
def page_text(pdf, page, layout):
    cmd = ['pdftotext'] + (['-layout'] if layout else []) + ['-f', str(page), '-l', str(page), pdf, '-']
    return subprocess.run(cmd, capture_output=True, text=True).stdout
def find(root, name):
    for d, _, fs in os.walk(root):
        if name in fs: return os.path.join(d, name)
    return None
def main():
    cits = json.load(open(sys.argv[1])); root = sys.argv[2]; ech = 0
    for i, c in enumerate(cits, 1):
        p = find(root, c['pdf'])
        if not p: print(i, 'PDF INTROUVABLE', c['pdf']); ech += 1; continue
        h = hashlib.sha256(open(p, 'rb').read()).hexdigest()
        okh = (h == c['sha256'])
        cible = norm(c['citation'])
        ok = any(cible in norm(page_text(p, c['page'], l)) for l in (True, False))
        if not (ok and okh): ech += 1
        print(i, 'OK' if ok else 'ECHEC', 'empreinte ' + ('conforme' if okh else 'DIFFERENTE'), c['pdf'], 'p.', c['page'], '|', c['citation'][:60])
    print('citations :', len(cits), '; échecs :', ech)
    return ech
if __name__ == '__main__': sys.exit(1 if main() else 0)
