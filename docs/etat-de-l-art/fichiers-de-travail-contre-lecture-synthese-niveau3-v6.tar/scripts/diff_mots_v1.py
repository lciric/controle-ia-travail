"""Différence mot à mot entre la v5 et la v6 de la synthèse (fichiers nommés), lancé par python3 -I."""
import difflib, sys
E="/home/user/controle-ia-travail/docs/etat-de-l-art/"
a=open(E+"etat-de-l-art-verifie-niveau3-v5.md",encoding="utf-8").read().split("\n")
b=open(E+"etat-de-l-art-verifie-niveau3-v6.md",encoding="utf-8").read().split("\n")
sm=difflib.SequenceMatcher(None,a,b,autojunk=False)
for tag,i1,i2,j1,j2 in sm.get_opcodes():
    if tag=="equal": continue
    print(f"\n=== {tag} v5 l.{i1+1}-{i2} -> v6 l.{j1+1}-{j2}")
    if tag=="replace" and (i2-i1)==(j2-j1):
        for k in range(i2-i1):
            x=a[i1+k].split(" "); y=b[j1+k].split(" ")
            s2=difflib.SequenceMatcher(None,x,y,autojunk=False)
            print(f"--- v6 l.{j1+k+1} : {' '.join(y[:8])}")
            for t,p1,p2,q1,q2 in s2.get_opcodes():
                if t=="equal": continue
                ctx=" ".join(x[max(0,p1-6):p1])
                print(f"  [{t}] …{ctx} || - {' '.join(x[p1:p2])} || + {' '.join(y[q1:q2])}")
    else:
        for l in a[i1:i2]: print("  - "+l)
        for l in b[j1:j2]: print("  + "+l)
