---

## 2. Suite donnée à la contre-lecture de la v1

« Corrigé » : la v2 applique la correction, par le texte corrigé de la contre-lecture ou par mieux, appuyé sur un rapport du compte 2. « Réserve maintenue » : la v2 ne peut pas lever le point et le dit. Les sections citées sont celles de ce document.

### 2.1 Constats bloquants et majeurs

| point | gravité | décision | où dans la v2 | motif |
|---|---|---|---|---|
| B1 — H9 : « profil de la perte par rang de relais » donné pour non trouvé | bloquant | corrigé | section 1 (H9) ; section 4 (H9) ; section 12 (H9) | Le texte corrigé de B1 est repris : la répartition du premier relais fautif par rang, à profondeur 1, 2 et 3, est publiée (MasDrift, tableau 18, p. 23), et N-070 la cite pour la même raison. |
| B2 — « aucun énoncé occupé en entier », « contre chacun de nos énoncés », « plus de cent cinquante » | bloquant | corrigé | section 0, point 1 ; section 12, phrase d'ensemble | Le prononcé nomme O20 (occupé comme méthode) et O1 (dans son principe), et H6 sous sa lecture la plus large ; la phrase d'ensemble reprend le texte corrigé de B2, sans nombre non recompté. |
| B3 — H5 : « l'instrument existe hors attaque » | bloquant | corrigé | section 1 (H5) ; section 4 (H5) ; section 12 (H5) | Le texte corrigé de B3 est repris : l'instrument existe hors attaque (2604.13386) et sous attaque entre trois architectures (2609.36490, p. 8). |
| M1 — H1 : la phrase pour un jury omet faux positifs et agrégation égaux, et la comparaison sur une sous-performance | majeur | corrigé | section 3 (H1) ; section 12 (H1) | Texte corrigé de M1 repris ; K-H1 ajoute trois pièces lues et sépare le durcissement « hors de l'échantillon » de l'énoncé ; la v3 y ajoute la confrontation de 2609.19101 à H1 (constat A de la contre-lecture de la v2). |
| M2 — Statistique de population : la pièce libre perd son objet | majeur | corrigé | section 1 (papier B, deux lignes) ; section 4 | Le texte corrigé de M2 est entré dans l'énoncé 2 de N-069 (« adversaire entraîné contre elle ») ; la v2 recopie les deux énoncés de N-069, et K-B confirme qu'aucune des deux pièces lues ne les touche. |
| M3 — H8 : phrase plus forte que la pièce ; fait cité inexact | majeur | corrigé | section 3 (H8) ; section 12 (H8) | Les trois textes corrigés de M3, contrôlés par la contre-lecture sur le fichier (contrôles 23 et 24), sont repris ; la lecture dure de S-7A reste un point à trancher, dit comme tel. |
| M4 — L et T : la collision la plus probable est versée et non lue | majeur | réserve maintenue | section 1 (L, T) ; section 3 (L, T) ; section 10 | Pour T, le point est levé : les trois pièces désignées sont lues (K-T), l'occupation élargie est portée (section 3) et T se déclare pour (c) à (f). Pour L, il ne peut pas l'être : K-L établit que la pièce visée par C2 est un autre article, de 2021, à trois auteurs, ni versé ni lu par personne ; L reste à ne pas déclarer (constat P de la contre-lecture de la v2). Depuis la v4 (section 2 quater, R7) : Ker 2007 est lu (K-Lk) ; restent non lus Huang, Wang et Poor 2021, Bash et collègues 2014 et 2016, Arumugam et Bloch 2016, Trivedi et Chandramouli 2003. |
| M5 — H6 : un voisin au dépôt jamais confronté | majeur | corrigé | section 1 (H6, trois lignes) ; section 3 (H6) ; section 12 (H6) | K-H6 lit Ctrl-Z et 2605.26047 contre N-015 ; le verdict est donné par lecture de l'énoncé, et la v2 ne déclare pas H6. |
| M6 — Tr : pièce libre non énoncée ; voisins versés non nommés | majeur | corrigé | section 1 (Tr) ; section 3 (Tr) ; section 12 (Tr) | La pièce non trouvée est énoncée en cinq formulations (K-Tr) et les trois voisins versés (2601.04603, 2603.04069, 2609.19101) sont lus ; la divergence de lettre qui en sort est portée aux nœuds ouverts. |
| M7 — HC1 : « l'opposition juge contre sonde » dite libre | majeur | corrigé | section 1 (HC1, HC2) ; section 5 (HC1) ; section 12 (HC1) | K-HC1 lit 2607.00415 : l'opposition au sens de N-005 n'y est pas touchée, elle est portée par HC2 (N-068) ; la lecture interne du lecteur qui défère est publiée ; l'exposition restante nommée par M7 est rapportée. |
| M8 — HC4 : phrase pour un jury absolue | majeur | corrigé | section 1 (HC4, deux lignes) ; section 5 (HC4) ; section 12 (HC4) | Texte corrigé de M8 repris, resserré par K-HC4 (verdict par sens de « juge », points de coût vérifiés, « plusieurs ordres de grandeur » rapporté au coût de défense). |
| M9 — HC5 : le quorum de juges et de sondes | majeur | corrigé | section 1 (HC5) ; section 5 (HC5) ; section 12 (HC5) | K-HC5 lit 2601.04603 : combinaison publiée d'une sonde du modèle producteur et d'un classifieur, éprouvée en cascade, non en quorum ; la phrase le dit, et nomme ce qui reste à lire. |
| M10 — HC6 : une pièce versée sur la même relation, non signalée | majeur | corrigé | section 1 (HC6) ; section 5 (HC6) ; section 12 (HC6) | K-HC6 lit 2608.11247 : voisin sous les deux sens de « bénin », sans attaque optimisée ni moniteur. |
| M11 — O4 : la piste la plus dure n'est pas nommée | majeur | corrigé | section 1 (O4) ; section 6 ; section 10 ; section 12 (organisme) | Le texte corrigé de M11 est repris et toutes les pistes qu'il nomme sont listées ; O4 reste à ne pas déclarer ; la v3 corrige O3, O11 et O12 d'après N-067, lue en entier (constat H de la contre-lecture de la v2). |
| M12 — Rôle 1 : la pièce propre dite libre sans le lot qui la vise | majeur | corrigé | section 1 (rôle 1) ; section 6 | Le lot 4-B est rendu (K-4B1, K-4B2) : la pièce propre est occupée en partie dans son cadre par 2609.28614 ; M12 est confirmé. |
| M13 — Section 9 incomplète et en partie mal décrite | majeur | corrigé | section 10 | La liste des lots est réécrite selon M13, corrigée de ce que le compte 2 a lu, chaque pièce rattachée à son énoncé ; la v3 referme le compte par lot (constat N de la contre-lecture de la v2). |
| M14 — H4′, HC2b, HC4 : « peu cherché » absent des verdicts | majeur | corrigé | section 1 (H4′, HC2b, HC4, H6) | La mention « peu cherché » est portée dans la colonne des réserves de chacun, et pèse sur la colonne « déclarable ». |

### 2.2 Constats mineurs

| point | gravité | décision | où dans la v2 | motif |
|---|---|---|---|---|
| m1 — H7 : la pièce libre perd « information mutuelle » et « sur plusieurs tours » | mineur | corrigé | section 1 (H7) ; section 4 (H7) | Texte corrigé de m1 repris. |
| m2 — HC2 : reformulation silencieuse | mineur | corrigé | section 1 (HC2) ; section 5 (HC2) | Remplacé par l'énoncé retenu de N-068, qui garde « en fonction de l'intensité » et ne revendique pas le plan apparié. |
| m3 — Prononcé 5 et divergence 5 n'attribuent pas le même compte | mineur | corrigé | section 11 | Texte corrigé de m3 repris. |
| m4 — Section 9, point 7 : pièces lues rangées parmi les non lues | mineur | corrigé | section 10 | 2606.07624, 2607.02510 et 2606.06223 sont dites « lues par un seul lecteur, non recoupées ». |
| m5 — 2611.00643 : « coupant la précision de 46 à 68 % » | mineur | corrigé | section 6 (rôle 1) | Écrit « en faisant baisser la précision de 46 à 68 % selon le générateur ». |
| m6 — Prononcé 4 : HELIOS et NARCBench sont un seul article ; l'annonce du séquentiel se date | mineur | corrigé | section 0, point 5 ; section 3 (H2) ; section 8 ; section 12 (H2) | Mieux que le texte de m6 : K-H2 lit en entier les versions 1, 2 et 4 et date l'annonce (version 2, 9 mai 2026, p. 8 et 9 ; version 4, 12 octobre 2026) ; la v3 rétablit que les versions 3 et 5 ont été lues au niveau 3 par C1 (constat F de la contre-lecture de la v2). |
| m7 — Divergences non listées (19 à 22) | mineur | corrigé | section 11 | Les quatre divergences sont ajoutées, et celles du compte 2 après elles. |
| m8 — Un choix tacite sur H8 | mineur | corrigé | section 1 (H8) ; section 3 (H8) | Le verdict dit que la pièce revendiquée suit la lecture douce et que la lecture dure de S-7A reste à trancher. |

