---

## 6. Organisme d'idéation — O1 à O20 et rôles de N-065

**Ce qui n'a pas changé depuis la v1.** Le compte 2 n'a pas relu O1 à O20. Les verdicts de la table de la section 1 sont ceux de la v1, qui assemble C4, C7 et S-4A et donne le plus dur des deux lectures quand elles divergent ; les clés et pages de la v1 restent valables (QU = 2609.27051 ; MASK = 2610.38392 ; REUSE = 2609.33180 ; PROCTOR = 2609.02246 ; PACE = 2606.08106 ; CONFIRM = 2611.01449 ; CADS = 2610.24597 ; N×N = 2608.06621 ; 2611.06607 ; Sargsyan = 2511.06701).

| | revendication (abrégée) | C4 puis C7 | S-4A | verdict v2 |
|---|---|---|---|---|
| O1 | qui produit ne tient pas la clé qui évalue | occupée dans son principe (QU p. 1, 2, 4, 11) | occupée en partie (CADS p. 4, 17 ; Sargsyan p. 10 ; 2611.06607 p. 3) | occupé en partie |
| O2 | statistique hors des agents, engagement scellé, nul des lois connues, multiplicité | deux composantes occupées, une dans son principe, une absente (QU p. 1, 2, 6, 8-11, 14, 22, 30) | trois occupées, le nul absent ; réunies sans le nul dans CONFIRM (p. 3, 5-6, 14) | occupé en partie : seul le nul des lois connues n'est pas trouvé |
| O3 | prédictions scellées ; tirages semés par l'empreinte | occupée dans son principe (QU p. 2, 10 ; MASK p. 4, 24) | occupée en partie pour le sceau (CONFIRM p. 3 ; 2611.06607 p. 3-4) | occupé en partie ; tirage semé par l'empreinte non trouvé |
| O4 | battre un nul formé des lois connues | non trouvée ; le plus fragile | non trouvée ; quatre voisins (N×N p. 3 ; 2611.00643 p. 1, 6 ; 2610.11289 p. 2 ; Sargsyan p. 5) | non trouvé dans les pièces lues — le plus fragile |
| O5, O6, O15 | moisson non opposable ; douane de forme ; bisociateur | non réexaminées | non touchées | non réexaminés au niveau 3 |
| O7 | juges croisés de plusieurs fournisseurs | voisine | — | non trouvé (voisin) |
| O8 | proposeurs de plusieurs fournisseurs | non trouvée (QU p. 2) | non trouvée ; contre-indice sur sa valeur | non trouvé dans les pièces lues |
| O9 | mémoire sans verdicts | occupée dans son principe (REUSE p. 2 ; QU p. 12, 16) | voisine | occupé en partie ; la forme « aucun verdict » non trouvée |
| O10 | témoins plantés à chaque génération | occupée dans son principe (PROCTOR p. 2) | voisine (CONFIRM p. 6) | occupé en partie, confiance moyenne |
| O11 | banc de tricheurs, validation préenregistrée, mutations | occupée dans son principe (QU p. 13, 16, 29 ; PACE p. 6 ; MASK p. 2, 8) | occupée en partie (2611.04420 p. 5-6 ; CADS p. 9, 23 ; Sargsyan p. 27-29) | occupé en partie ; combinaison et ampleur non trouvées |
| O12 | attaque de Goodhart | principe occupé ; forme non trouvée (REUSE p. 32) | forme occupée en partie (CONFIRM p. 9, 22 ; 2611.00643 p. 1, 10, 12) | occupé en partie, forme comprise |
| O13 | épreuves en bac à sable | voisine | occupée en partie (Sargsyan p. 9-11 ; CADS p. 5) | occupé en partie (S-4A seul) |
| O14, O16, O18 | sélection par les épreuves ; pont fiche → loi ; discrimination des juges | voisines | — | non trouvé (voisins) |
| O17 | scellement avant lecture, aucun repli silencieux | occupée dans son principe (MASK p. 4, 24) | occupée en partie (2611.06607 p. 4) | occupé en partie |
| O19 | puissance du juge | occupée dans son principe (REUSE p. 6) | voisine (CONFIRM p. 5) | occupé en partie |
| O20 | juge éprouvé sur vérité plantée | occupée comme méthode (QU p. 14, 15, 22) | occupée dans son principe | occupé comme méthode ; restent les chiffres propres |

**Décision intervenue : N-067** (`966dd9dc…`, lue en entier pour la v3). Elle remplace les points 2 à 4 de N-064 pour O1, O2, O3, O11, O12 et O17 :
- **O2, énoncé retenu** : « Juge statistique dont le nul est formé des lois déjà connues (l'archive) : une fiche n'est promue que si sa prédiction scellée bat ce que l'archive prédit déjà. » Les trois autres composantes (calcul hors des agents, engagement scellé par empreinte, contrôle des comparaisons multiples) ne sont plus revendiquées ; leur réunion avec le nul se dit comme un assemblage dont trois pièces sont empruntées (section 4, point 1).
- **O4**, seul porteur de la revendication du juge ; **clause d'usage public** : O4, et avec lui l'énoncé retenu de O2, n'est déclaré libre hors du dépôt qu'après lecture sur PDF de SSRN 6569258 et des pistes de priorité haute dirigées contre O4 (section 4, point 2 ; pistes : section 8 de N-067, dont 2110.00115 et 2103.08402, lues par K-H2 pour H2 seulement).
- **O12, forme resserrée** : « La mesure, sur des mondes où toute promotion est fausse, d'un juge statistique sous l'attaque d'un proposeur modèle de langue chargé de tromper, qui lit la description exacte du juge sous forme de texte, libre dans ses propositions, avec un bras qui reçoit les verdicts et un bras qui ne les reçoit pas, comparés. » (section 4, point 3).
- **O11** : plus aucune revendication d'idée ; le banc reste un instrument dont l'ampleur et les chiffres sont rapportés sans priorité (point 4). **O1** : plus revendiquée (point 5). **O3** : le sceau n'est plus revendiqué ; le tirage semé par l'empreinte reste non trouvé, décrit comme un choix de mise en œuvre, sans priorité affirmée avant une lecture de durcissement (point 6). **O17** : plus revendiquée comme idée (point 7).
- **Statuts les plus durs** retenus pour O9, O10, O13, O19 : aucun texte ne les présente comme non occupées ; leurs énoncés ne sont pas resserrés (section 10).
- **Contre-indices** (section 7) : six bras de mémoire, aucun test significatif après correction (O9 ; Qu, Chen, Wang, p. 16) ; ôter la porte de multiplicité ne change rien sur un banc (O2 (d) ; CONFIRM, p. 19) ; « zéro promotion » est déjà publié (Qu, Chen, Wang, p. 15 ; CONFIRM, p. 9), donc un tel résultat de l'organisme ne serait pas neuf par son signe (O12) ; un préenregistrement peut geler un instrument faux (2611.00643, p. 16) ; la valeur des proposeurs (O8) est contestée (2611.04420, p. 8 ; CADS, p. 11).
- **2611.00643** est cité comme précédent de la prémisse du bras « juge génératif » du rôle 1, énoncé inchangé (section 9 ; R-2571, point 5b (a)).

Pages et pièces ci-dessus : celles que N-067 donne, d'après ses rapports C4, C7 et 4-A.

**Ce qu'ajoutent les rapports 4-B à l'organisme, sans verdict sur les O.**
- O4 : la tâche de nouveauté de 2609.28614 mesure la nouveauté contre une archive figée de l'existant, calculée hors de l'agent, par recouvrement de termes (p. 19) ; une fraude spontanée y est passée (p. 27). Ce n'est pas un nul statistique ; c'est un voisin à citer (K-4B1).
- O12 : le contraste « l'attaquant reçoit ou non le retour du juge » est publié côté juge génératif, à titre descriptif (2608.08975, p. 7, 12, 48) ; pas une collision avec la forme resserrée, qui porte sur un juge statistique, avec consigne de tromper et mondes tout faux (K-4B2, section 7).
- R1 (préenregistrement) : contre-indice de la v1 maintenu — un instrument faux a été fixé avant toute donnée et a passé trois étapes de confirmation (2611.00643, p. 16, S-4A).

**Contre-indices publiés** (v1) : sur la valeur des proposeurs modèles (O8), un tirage au hasard fournit le candidat promu dans 48 % et 46 % des paires (2611.04420, p. 8) et un a priori fixe sans modèle domine les trois modèles (CADS, p. 11) (S-4A). Réserves sur QU : prépublication, cinq graines, code sur demande, un « 0,000 » identique à trois décimales jugé trop propre (C4, C7). Décision N-058 (composition des proposeurs jugée sur l'oracle et le coût) : principe occupé en partie et appuyé, non contredit (S-4A).

### Rôles de N-065

- **Rôle 1** (second terrain du papier C : corruptibilité de deux sortes de juges de la recherche automatisée). **Verdict : occupé en partie, y compris pour la pièce dite propre dans son cadre** (K-4B1 et son contre-lecteur ; K-4B2 et son contre-lecteur pour le bras génératif). Le constat M12 est confirmé.
  - 2609.28614 met deux sortes de surveillants de la recherche par agents devant les mêmes fraudes : un jury génératif de modèles et un oracle d'exécution calculé hors de l'agent, sans modèle ; il compare leurs taux de passage (6,5 % et 7,5 %, p. 7, 28) et mesure le transfert vers l'oracle des fraudes adaptées contre le jury : « Five of those 56 also pass the execution audit. » (p. 11). Mais cet oracle **n'est pas un juge statistique** (ni nul ni épreuve), il **n'est jamais visé** par l'attaque, aucun **gain continu** n'y est mesuré, et la comparaison est **circulaire** : l'étiquette de fraude vient d'un jury de modèles qui voit les preuves de l'oracle (p. 5, 26). Les deux taux sont deux planchers, non deux corruptibilités comparables.
  - Bras génératif : occupé en partie par 2608.08975 (relecteurs d'articles déplacés par réécriture rhétorique, gain gradué jusqu'à +0,93 sur la note globale, p. 3, 6 ; série par tours sans témoin neutre, p. 12, 49 ; une consigne stricte ne rend pas le juge invariant, p. 14) et par 2606.13044 (réécriture de la présentation en boucle fermée sur le relecteur, 75,1 % de succès et +1,21 sur 10, p. 1, 7) ; BadScientist (2510.18003) : articles fabriqués acceptés jusqu'à 82 % par un jury de relecteurs modèles (p. 1, 7).
  - 2611.10791 pose en modèle, et propose comme essai, la comparaison de deux sortes d'évaluation sous une même production tournée vers l'évaluateur (p. 19, 35, 37) : voisin formel, rien de mesuré, aucun juge statistique ; il s'appuie sur 2608.08975, si bien que les deux ne sont pas deux témoins indépendants.
  - Pièces de la v1, inchangées : 2611.04556, environnement E3, un relecteur génératif approuve un écart non documenté à un préenregistrement (+10,39, +13,61 et +8,56 points ; p. 19, 48, V2 ; contrôle 18), cité comme précédent de la prémisse par décision de Lazar (R-2554) ; 2611.00643, optimiser un harnais contre un juge modèle fait monter sa note en faisant baisser la précision de 46 à 68 % selon le générateur (p. 1, 2, 12, S-4A ; contrôles 14 et 15), cité comme précédent de la prémisse du bras « juge génératif » du rôle 1, énoncé inchangé (N-067, section 9 ; R-2571, point 5b (a)).
  - **Non trouvé dans les pièces lues** (K-4B1, formulation exacte) : « La corruptibilité, mesurée comme un gain continu en fonction de l'intensité d'une même attaque, d'un juge statistique d'affirmations de recherche (épreuve calculée hors des agents contre un nul formé des lois connues) et d'un juge génératif (juge-tournoi), placés tous deux sous l'attaque d'un même proposeur modèle de langue chargé de les tromper et qui lit la règle de chacun, avec la comparaison inférentielle des deux courbes sur une vérité plantée indépendante des deux juges. »
  - Citation obligatoire, quel que soit l'énoncé retenu : 2609.28614 (K-4B1). L'énoncé du rôle 1 après 2609.28614 est un nœud ouvert (section 9).
- **Rôle 2** (atelier d'idées) : pas une revendication d'antériorité ; sans objet.
- **Rôle 3** (proposeur trompeur comme famille de menaces diffuses) : à trancher par Lazar ; aucune recherche d'antériorité dédiée.

