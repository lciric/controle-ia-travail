---

## 11. Erreurs de fait, corrections et divergences

### 11.1 Texte envoyé au fonds (B1, C2), inchangé depuis la v1

**Le texte envoyé au fonds contient des erreurs de fait** sur des travaux d'autrui : trois selon B1 ; la synthèse provisoire en retenait deux et une formulation à restreindre, appuyée sur C2. Le socle de preuves demande quatre corrections (B3). (Texte corrigé de m3.)

| ligne | ce qui est écrit | constat | rapport |
|---|---|---|---|
| l. 199-200, 261 | quorums entre familles de juges (2605.15377) | **contredit par le PDF** : un seul modèle pour tous les moniteurs (p. 4) ; familles différentes non essayées (p. 8) ; la pièce serait occupée par 2607.08066 (p. 1, 2, 6) : la référence serait fausse, non le retrait | B1 ; C3 |
| l. 131-132 | accumulation additive sur scores boîte noire (E-valuator…) | **faux** : E-valuator n'est pas une somme cumulée (2512.03109, p. 1) | B1 |
| l. 87 | précurseur dit synthétique (2606.10456) | **divergence entre lecteurs** : contredit par l'imprimé selon B1 (p. 8) ; exact selon C2 | B1 ; C2 |
| l. 87-88 | l'énoncé central ne tiendrait pas pour sa propre construction | exact pour la somme et la moyenne, faux pour le maximum ; à restreindre ; calcul en forme close de C2 au niveau 0,05 : 0,074 au point phare, 0,254 à l'écart le plus grand ; l'article imprime 0,048 pour la moyenne à 1 % (p. 6) | C2 ; B1 |
| l. 84-85 | le cœur statistique est classique et cité | aucune référence dans le texte selon B1 ; « fidèle » selon C2 ; sources portées sur PDF (C6, C8, et K-L pour le versant discrétion) | B1 ; C2 |
| l. 176 | le « poids du conseil » puis 2603.15809 | l'article emprunte un autre modèle (p. 1) ; l'identification est celle du programme | B1 |
| l. 181-183 | Panin, trois modèles sur cinq | exact, mais le PDF n'a été versé que treize jours après l'envoi | B1 |
| l. 276 | les dix-huit consignes de l'article source | décompte du programme, non imprimé par l'article | B1 |
| l. 264 | aucun énoncé revendiqué trouvé occupé en entier | littéralement exact ; n'est plus un tableau fidèle | B1 |

Bilan de traçabilité (B1) : 101 affirmations sur des travaux d'autrui dans le programme v2 et le texte envoyé ; une seule porte une page ; 78 tracées, dont 4 contredites ou fausses telles qu'écrites ; 13 sans source désignée.

### 11.2 Socle de preuves v2 (B3) et autres textes du programme

- Socle : dix-huit affirmations, 10 confirmées, 5 avec réserve, 3 corrigées. Quatre corrections : l. 73, la surveillance « moins prometteuse » contre le diffus est une prémisse de 2606.08892, non une conclusion (p. 2) ; l. 76, 457-458, 539, 2512.07810 traite de sous-performance, non de sabotage (p. 17-18), sans chiffre de sonde sur ces pages ; l. 68-69, « échoue par construction » demande la condition de 2606.10456, proposition 1 (p. 3) ; l. 74, 77 : nommer E-valuator (p. 1).
- État de l'art v1 : l. 37 à nuancer (billet long de l'institut britannique daté du 10 juillet 2025, S-2A) ; l. 102 (billet de Gasteiger et collègues), chiffres de nature « figure », fourchette valable pour trois juges sur quatre (S-2B) ; l. 92 (Hopman), exact sur le fond, deux détails inexacts (S-2B) ; l. 99 à corriger selon S-2B ; l. 154 contredite par le niveau 2 (B2) ; l. 132 et 140 : six chiffres invérifiables au dépôt (B2) — **pour la l. 140, K-HC4 vérifie désormais les chiffres de PAIR et de la méthode de fuzzing de 2309.10253** (requêtes par succès de 10 à 56 sans compter les échecs, de 22,3 à 2 923,7 en les comptant ; de 22 à 359 requêtes par question), la confrontation restant à faire.
- Programme v2 : l. 59, auteurs faux pour 2208.07610 (corrigé par P-008, resté dans le texte) ; l. 239, « Oxford/NYU » ; neuf affirmations d'antériorité sans source (l. 16, 93, 99, 104, 112, 137, 145, 197, 239) (B1) ; section 3, « il faut un agrégateur d'autocorrélation ou de co-élévation » écrit sans citer les outils publiés (C6) ; l. 98 (Tr), robustesse « établie au niveau token » contestée (K-Tr, nœud) ; l. 102, Δv = g · (v* − v₀) encore écrit avec la cible, alors que N-005 libère la destination (K-HC6).
- Faits repris de pistes : la communication d'atelier de NeurIPS 2026 sur les activations du moniteur n'a pas d'entrée sur arXiv ; le billet sur la dilution des sondes est un billet sur la surveillance de confiance par sondes de tromperie (provenance du lot 8) ; le fichier 2607.13346 porte le titre PRISM, non celui que lui donnait une piste (C8).

### 11.3 Divergences entre lecteurs, dites telles quelles

De la v1 (1 à 18), complétées par la contre-lecture de la v1 (19 à 22, m7), par le compte 2 (23 à 30), puis par la contre-lecture de la v2 (31, 32), la vérification de la v3 (33) et les lectures depuis la v4 (34 à 38).

1. **O2.** C4 : trois composantes sur quatre occupées par QU. C7 : deux en entier, une dans son principe. S-4A, sur d'autres pièces : trois occupées. Le registre reprend « trois sur quatre ».
2. **Forme de O12.** C4 et C7 : non trouvée. S-4A : occupée en partie (CONFIRM, annexe C.6).
3. **O1, O3, O9, O10, O13, O17, O19.** Mots et statuts différents entre C7 et S-4A ; pièces différentes.
4. **« Synthétique » pour 2606.10456.** B1 : contredit par l'imprimé. C2 : exact.
5. **Nombre d'erreurs de fait du texte envoyé.** B1 : trois. Synthèse provisoire : deux et une formulation contestable.
6. **Quorums entre familles de juges.** B1 : pièce retirée sur une source qui ne l'occupe pas. C3 : pièce occupée par 2607.08066.
7. **Le cœur statistique « classique et cité ».** B1 : sans répondant dans le texte. C2 : fidèle.
8. **H2, L, T : le mot.** C1, C2, C8, S-5B, S-2A : « occupé en partie ». S-5A : « non occupée », avec occupations partielles en boîte noire. S-7A : « libre ». Même substance.
9. **H8.** S-7A : « voisin fort », lecture dure « occupée en partie », à trancher. S-7B : « occupée en partie ». S-3A : aucune occupation nouvelle. C8 : socle occupé en partie, pièce revendiquée non trouvée.
10. **H6.** Synthèse provisoire : libre. S-2A : occupée en partie pour le rééchantillonnage (lecture dure, sur billet). S-7B : « occupée en partie (bruit sur les poids) », état d'avant N-015. Désormais tranché sur PDF par K-H6, par lecture (section 3).
11. **H3 et 2605.11135.** S-5A : « occupée en partie en boîte noire », lecture « voisin » défendable.
12. **Squelette statistique de 2601.05427.** S-5A : « occupée en partie », lecture « voisin fort, outil » défendable.
13. **HC4.** C9 : « occupée en partie (points de coût épars) ». Complément 1 : « pièce revendiquée libre, prémisse entamée ». Puis : verdict par sens de « juge » (K-HC4). Désormais : « non trouvé dans les pièces lues », sous le sens fixé par Lazar (juge génératif ; K-HC4, K-HC4b).
14. **H9.** C6 et C9 : « libre » ou « repli non déclenché ». S-7D et S-12 : occupée en partie sur le cœur. Pièces différentes. Repli appliqué (N-070).
15. **Date d'un billet d'équipe rouge.** C5 : 27 septembre 2026 (PDF 2609.19587). S-2B : 22 octobre 2026 (billet). Non réconcilié.
16. **2611.04556, rôle 1.** V1 : « voisin ». V2 : « occupé en partie pour la prémisse ». Tranché par Lazar (R-2554) : précédent à citer.
17. **2611.04556, autres points.** V2 juge trop forts dans V1 : « aucune intensité graduée », « aucune détection », « HC6 annoncée comme suite », l'usage des données pour HC2b.
18. **Bascule.** C1 : non déclenchée. S-7B : non déclenchée au sens du texte, déclencheur « à examiner par Lazar ». Tranché : non déclenchée (N-069, section 9).
19. **H1.** S-2A : « aucune occupation ; voisin fort », lecture dure « occupée en partie » pour la comparaison de l'institut britannique ; la v1 la citait sans la ranger parmi les divergences.
20. **H2.** S-2A : « occupée en partie, pour la configuration de référence seulement », lecture douce « voisin fort ».
21. **HC2.** S-1 propose « g en plan apparié » ; S-3A dit le plan apparié déjà publié côté lecteur. Tranché par N-068 : plan apparié non revendiqué.
22. **H8.** S-7A écrit à la fois « échec prédit puis observé » et « après coup pour l'injection » ; le fichier tranche pour la seconde lecture (M3).
23. **Tr, lettre de la table.** K-Tr : « non trouvé dans les pièces lues » (noyau, convention du niveau 3). Sa contre-lecture : « occupé en partie » (composantes faites). Non résolu ; nœud.
24. **H6, verdict d'ensemble.** K-H6 : verdict par lecture. Sa contre-lecture : « occupé en partie » pour l'énoncé de N-015. Même faits ; la seconde ne sépare pas les lectures.
25. **HC4, verdict de tête.** K-HC4 v1 : « occupé en partie » sous la lecture large ; v2 et sa contre-lecture : verdict par sens de « juge ». Le sens est fixé depuis (juge génératif, C2-0057) : la divergence n'a plus d'objet.
26. **L × 2605.16140.** K-L v1 : composante de L1 « occupée en partie ». Sa contre-lecture, puis K-L v2 : « voisin (outil) ».
27. **T, unification.** K-T v1 : sous-groupe « agents à chaque pas » non fait. Sa contre-lecture, puis K-T v2 : écrit chez Koning, au nom près.
28. **Rôle 1, 2611.10791.** K-4B2 v1 : « ne touche pas » pour trois composantes. Sa contre-lecture : « voisin formel » pour trois. K-4B2 v2 : « voisin formel » pour deux, « voisin lointain » pour la troisième (l'intensité d'une attaque n'y est pas modélisée).
29. **Rôle 1, tableau 8 de 2608.08975.** Sa contre-lecture signale un écart ; K-4B2 v2 le rejette, page et citation à l'appui (−1,361 imprimé sur la ligne d'ensemble, p. 14).
30. **H2, constat E.** La contre-lecture de K-H2 écrit qu'une somme lue en fin d'épisode à horizon fixe bat l'accumulation toujours valide ; K-H2 garde une réserve : « pas mieux au terme » en général, perte établie dans l'exemple seulement.
31. **Colonne « déclarable » de H2 et de la statistique spatio-temporelle.** La contre-lecture de la v2 : « oui, contesté » pour H2 et « oui » pour les deux énoncés de N-069, voisins nommés. La v3 : « non » pour H2 et pour l'énoncé 2, par la condition 4 de la règle réécrite, appliquée comme à T et à L. Divergence de jugement, dite.
32. **Pièces de la section 5 de la contre-lecture de la v1.** La règle proposée par la contre-lecture de la v2 en fait un empêchement (« lue contre cet énoncé ») ; la v3 en fait une exposition à nommer, sans quoi aucun déclarable de la contre-lecture de la v1 ne le resterait.
33. **Colonne « déclarable » de HC1 et de l'énoncé 1 de N-069.** La v3 : « oui ». La vérification de la v3 (constats S, T), puis la v4 : « non », par la condition 4 appliquée sans exception. Pas de divergence restante : la v4 s'y range après relecture des fichiers cités.
34. **L × Bash, Goeckel et Towsley.** K-Lv v1 : cœur de L1 « occupée en partie » et décroissance « occupée (horizon fixe) » par cette pièce. Sa contre-lecture (constats B, C), puis K-Lv v2 : « voisin » (budget d'énergie, bruit gaussien ; analogue d'échelle). Motif identique à celui qui a fait retirer « occupée en partie » à 2605.16140 (26).
35. **L4 × Ker 2006.** K-Lv v1 : « occupée en partie ». Sa contre-lecture (constat A), puis K-Lv v2 : « voisin » (cas T = 1, où L4 et L1 sont la même proposition) ; une seule composante revendiquée est occupée en partie.
36. **L, décroissance en n₀ × Ker 2007.** K-Lk v1 : démontrée « pour toute répartition non adaptative », en ordre, sans constante. Sa contre-lecture (constats A, B), puis K-Lk v2 : démontrée pour la répartition égale, contre tout test, à N fini, avec constante explicite ; la case « occupée » ne change pas.
37. **L, valeurs inégales × Ker 2007.** K-Lk v1 : « couvertes ». Sa contre-lecture (constat C), puis K-Lk v2 : admises pour la seule partie 1 (garantie par le compte des signes) ; le résidu de L1 n'est pas levé.
38. **HC4 × 2609.15994, force du contre-indice.** K-HC4b v1 : contre-indice « fort » à la prémisse. Sa contre-lecture (constats B, C, D), puis K-HC4b v2 : « net, étroit ». Le verdict ne change pas.

