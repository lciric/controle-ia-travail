"""Contrôle des extraits anglais de la synthèse v3 (constat O de la contre-lecture de la v2).
Chaque extrait anglais entre « » doit figurer comme sous-chaîne d'une citation contrôlée du pool
ET sur le PDF dont parle la phrase (table ATTENDU, remplie à la main en lisant chaque phrase).
Usage : python3 -I controle_guillemets_v3.py SYNTHESE POOL SORTIE_JSON"""
import json, re, sys, unicodedata
ATTENDU = {
 'This paper evaluates one protocol': '2604.15384v2.pdf',
 'we select probe thresholds that match': '2609.19101v2.pdf',
 'probes catch 3.0 and 33.1': '2609.19101v2.pdf',
 'Sequential detection. Accumulating evidence': '2604.01151v2.pdf',
 'Our current environmental setup': '2604.01151v4.pdf',
 'We plan to explore this': '2604.01151v4.pdf',
 'As a batch of data': '2310.01153v5.pdf',
 'Without averaging, a single token': '2601.04603v1.pdf',
 'The probe is thus several orders': '2601.04603v1.pdf',
 'Otherwise, we rely solely on the probe.': '2601.04603v1.pdf',
 'a reduction in conformity is not on its own': '2608.11247v1.pdf',
 'Five of those 56': '2609.28614v1.pdf',
}
txt = open(sys.argv[1], encoding='utf-8').read()
pool = json.load(open(sys.argv[2], encoding='utf-8'))
def norm(s):
    s = unicodedata.normalize('NFC', s).replace('’', "'").replace('‘', "'")
    return re.sub(r'\s+', ' ', s).strip()
ANG = set('the of and to in is are was were that this with for on by be not as an at from which it its or than we our their they can only also into one more no all any has have been would could should may'.split())
FR = set('le la les des du de et est sont un une dans pour par sur au aux que qui ne pas en ce cette ces nous on se sa son ses leur il elle à où dit'.split())
segs = re.findall(r'«\s*(.*?)\s*»', txt, flags=re.S)
sortie, erreurs, vus = [], [], set()
for seg in segs:
    mots = re.findall(r"[A-Za-zÀ-ÿ']+", seg.lower())
    na = sum(m in ANG for m in mots); nf = sum(m in FR for m in mots)
    acc = bool(re.search(r'[àâçéèêëîïôûùüÿœ]', seg.lower()))
    if not ((na >= 1 and na >= nf and not acc) or (na >= 3 and na > nf)): continue
    n = norm(seg)
    if n in vus: continue
    vus.add(n)
    cle = [k for k in ATTENDU if norm(k) in n]
    if len(cle) != 1: erreurs.append('sans PDF attendu : ' + seg[:80]); continue
    pdf = ATTENDU[cle[0]]
    tr = [e for e in pool if n in norm(e['citation']) and e['pdf'] == pdf]
    if not tr: erreurs.append('absent du PDF attendu ' + pdf + ' : ' + seg[:80]); continue
    e = tr[0]
    sortie.append({'pdf': e['pdf'], 'sha256': e['sha256'], 'page': e['page'], 'citation': seg,
                   'source': 'JSON contrôlé du rapport ' + e['rapport'] + ' du compte 2 (' + e['json'] + ', sha256 ' + e['json_sha256'] + ')'})
json.dump(sortie, open(sys.argv[3], 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('passages entre guillemets :', len(segs)); print('extraits anglais :', len(sortie)); print('erreurs :', len(erreurs))
for x in erreurs: print('  ', x)
