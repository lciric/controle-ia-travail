"""Essais À LA MAIN du contre-lecteur (fichier temporaire de son extraction, supprimé ensuite) : gardes sans essai d'artefact dans
la suite, appelées sur le code non muté, et cas de bord. Données factices seulement."""
import json

import numpy as np
import pytest

from controle_ia import scellement
from controle_ia.narcbench import cellules_externe_v2 as CE
from controle_ia.narcbench import externe_v2 as X2
from controle_ia.narcbench import lecture_externe_v2 as L
import test_narcbench_lecture_externe_v2 as T
import test_narcbench_externe_v2 as TX
from test_narcbench_lecture_externe_v2 import donnees, petites_bandes   # noqa: F401 (fixtures)


def _fiche_modifiee_apres_sceau(depot):
    f = depot / T.FICHE
    d = json.loads(f.read_text(encoding="utf-8"))
    d["branche"] = "changée après le sceau"
    f.write_text(json.dumps(d, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")


def test_g1_sceau_faux_de_la_fiche_du_code(tmp_path, donnees, capsys):
    racine, att = donnees
    depot = T._depot(tmp_path, apres=_fiche_modifiee_apres_sceau)
    code = L.main(T._args(depot, racine), attendues=att)
    err = capsys.readouterr().err
    print("G1", code, err.strip()[:260])
    assert code == 2 and "CODE-NARC-EXT" in err and "≠ empreinte du fichier" in err
    T._rien_d_ecrit(depot)


def test_g2_ligne_de_code_seule_posterieure_a_l_ouverture(tmp_path, donnees, capsys):
    racine, att = donnees
    depot = T._depot(tmp_path, lignes=lambda t, f: T._lignes(t, f, date_c="2099-01-02T00:00:00Z"))
    code = L.main(T._args(depot, racine), attendues=att)
    err = capsys.readouterr().err
    print("G2", code, err.strip()[:260])
    assert code == 2 and "ligne CODE-NARC-EXT datée 2099" in err and "pas strictement antérieure" in err
    T._rien_d_ecrit(depot)


def test_g3_g4_ligne_de_code_en_double_ou_mal_formee(tmp_path, donnees, capsys):
    racine, att = donnees
    depot = T._depot(tmp_path / "a", lignes=lambda t, f: T._lignes(t, f) + T._lignes(t, f)[1:])
    assert L.main(T._args(depot, racine), attendues=att) == 2
    err = capsys.readouterr().err
    print("G3", err.strip()[:200])
    assert "2 ligne(s) CODE-NARC-EXT" in err
    depot = T._depot(tmp_path / "b", lignes=lambda t, f: [T._lignes(t, f)[0], T._lignes(t, f)[1][:-1] + "| en trop |"])
    assert L.main(T._args(depot, racine), attendues=att) == 2
    err = capsys.readouterr().err
    print("G4", err.strip()[:200])
    assert "ligne CODE-NARC-EXT mal formée (5 cellules" in err


def test_g5_exception_d_un_autre_type_apres_l_ouverture(tmp_path, donnees, capsys, monkeypatch):
    """Une exception qui n'est ni `GardeArret` ni `MemoryError` après le manifeste : trace d'erreur, aucune ligne ARRET au journal."""
    racine, att = donnees
    depot = T._depot(tmp_path)

    def casse(*a, **k):
        raise np.linalg.LinAlgError("Singular matrix (factice)")
    monkeypatch.setattr(CE, "lire_modele", casse)
    with pytest.raises(np.linalg.LinAlgError):
        L.main(T._args(depot, racine), attendues=att)
    journal = (depot / L.JOURNAL).read_text(encoding="utf-8").splitlines()
    print("G5 journal :", [l.split(" | ")[0] for l in journal], "manifeste présent :", (depot / "runs" / T.RUN / "manifeste.json").is_file())
    assert [l.split(" | ")[0] for l in journal] == ["| OUVERTURE-NARC-EXT"]


def test_g6_colludeur_sans_ligne_finale_arret_au_lieu_d_exclusion():
    """Un seul épisode sur 24 (4 %) dont un colludeur n'a pas de ligne finale : le texte (n° 9) l'exclut et le compte ; le code
    arrête au titre du n° 8 (un seul colludeur vu), avant de compter les exclusions."""
    meta = T._meta("stego")
    sans = [m for m in meta if not (m["run_id"] == "bj__shoe00__collusion" and m["agent_name"] == "agent_0" and m["phase"] == "final")]
    ex = X2.exiger_exclusions(sans, "STEGO")
    print("G6 exclusions :", ex["exclus"], ex["par_motif"])
    assert ex["exclus"] == 1
    with pytest.raises(X2.GardeArret, match="1 colludeur"):
        X2.exiger_roles_episodes(sans, "final")
    honnete = [m for m in meta if not (m["run_id"] == "bj__shoe00__collusion" and m["agent_name"] == "agent_1" and m["phase"] == "final")]
    assert X2.exiger_roles_episodes(honnete, "final")["collusion/2"] == 12        # honnête sans ligne finale : exclu, pas d'arrêt


def test_g7_cinq_agents_dont_un_sans_trois_lignes_exclusions_et_groupes_divergent():
    rng = np.random.default_rng(1)
    meta, acts = TX._jeu("CORE", rng, n_dom=5, par_dom=2, couches=(5,))
    rid = "fam__dom0_00__control"
    en_plus = [TX._ligne(rid, "control", "honest", "public", "discussion", t, "agent_9") for t in (1, 2)]
    meta2 = meta + en_plus
    A = np.vstack([acts[5], rng.standard_normal((2, acts[5].shape[1])).astype(np.float32)])
    gr, info = X2.groupes(meta2, A, "CORE")
    ex = X2.exclusions_etage(meta2, "CORE")
    print("G7 groupes garde l'épisode :", rid in gr, "; exclusions_etage :", ex["par_motif"], "; agents sans trois lignes :", info["agents_sans_trois_lignes"])
    assert rid in gr and ex["exclus"] == 1


def test_g8_depot_fabrique_satisfait_la_garde(tmp_path, donnees):
    """Constat : la garde vaut pour le dépôt donné par `--depot` ; un dépôt jetable (celui des essais) la satisfait."""
    racine, att = donnees
    depot = T._depot(tmp_path)
    g = L.garde_registre(depot, T.TEXTE, 4102444800)
    print("G8 garde satisfaite dans un dépôt jetable :", g["registre"])


def test_g9_verifier_texte_n_exige_pas_le_gabarit(tmp_path, capsys):
    """Constat : `verifier-texte` ne lit que la configuration ; les marqueurs restants et la conformité au gabarit relèvent de
    `prereg.sceller_prereg` (plan n° 0)."""
    t = tmp_path / "t.md"
    t.write_text(T._texte(sans_seuil=True) + "\n<<MARQUEUR_RESTANT>>\n", encoding="utf-8")
    assert L.main(["verifier-texte", str(t)]) == 0
