"""Contre-lecteur : chemin du repli du plancher (liste d'arrêt n° 10) à travers `lire_modele` et la lecture finale, sur données
FACTICES ; aucun essai de la suite ne passe par là de bout en bout."""
import json
import numpy as np
from controle_ia.manifeste import cle_de_tache
from controle_ia.narcbench import cellules_externe_v2 as CE
from controle_ia.narcbench import externe_v2 as X2
import test_narcbench_cellules_externe_v2 as TK


def graine(t):
    return int(np.random.default_rng(np.random.SeedSequence(31415926535, spawn_key=(cle_de_tache(t),))).integers(2 ** 31))


rng = np.random.default_rng(5)
vrai_cholesky, vrai_repli = np.linalg.cholesky, X2.plancher_vecteurs_centres


def refus(*a, **k):
    raise np.linalg.LinAlgError("Matrix is not positive definite (factice)")


def refus_couche_6(S):
    if refus_couche_6.n % 2:          # un appel sur deux : une couche sur deux
        refus_couche_6.n += 1
        raise np.linalg.LinAlgError("factice, une couche sur deux")
    refus_couche_6.n += 1
    return vrai_cholesky(S)


refus_couche_6.n = 0
for nom, chol, repli in (("sain", vrai_cholesky, vrai_repli), ("Cholesky refusée partout", refus, vrai_repli),
                         ("Cholesky refusée à un appel sur deux", refus_couche_6, vrai_repli), ("Cholesky et repli refusés", refus, refus)):
    par = {}
    for modele in ("qwen3_32b", "llama_3_1_70b"):
        core, stego = TK._jeu("CORE", rng, force=6.0), TK._jeu("STEGO", rng, force=6.0, n=12)
        repro = X2.reproduire_helios_v2(core, stego, (5, 6), "papier", graines=(0, 1), garder_scores=True)
        np.linalg.cholesky, X2.plancher_vecteurs_centres = chol, repli
        try:
            par[modele] = CE.lire_modele(modele, core, stego, (5, 6), graine, repro, n_tirages=200, n_plancher=20, n_placebo=20)
        finally:
            np.linalg.cholesky, X2.plancher_vecteurs_centres = vrai_cholesky, vrai_repli
    lf = CE.lecture_finale(par)
    json.dumps({"m": {m: {k: par[m][k] for k in ("cellules", "comptes", "lecture_par_agent")} for m in par}, "l": lf}, allow_nan=False)
    c = par["qwen3_32b"]["cellules"]
    print(f"\n== {nom}")
    for k in ("temoin/stego/pic", "lineaire/stego/ecart", "mahalanobis/stego/pic"):
        pl = c[k]["plancher"]
        print(f"  {k} : plancher_court={c[k]['plancher_court']!r} ; méthodes={sorted({m[:22] for m in (pl or {}).get('methodes') or []})} ; phrase={c[k]['phrase']!r}"[:330])
    print("  lecture par agent, couche 5, linéaire :", par["qwen3_32b"]["lecture_par_agent"]["5"]["familles"]["lineaire"]["plancher_methode"][:40],
          "| grille D :", par["qwen3_32b"]["lecture_par_agent"]["5"]["familles"]["lineaire"]["grille_d"]["ligne"])
    print("  réponse :", lf["reponse"]["ligne"], "|", lf["reponse"]["phrase"][:400])
