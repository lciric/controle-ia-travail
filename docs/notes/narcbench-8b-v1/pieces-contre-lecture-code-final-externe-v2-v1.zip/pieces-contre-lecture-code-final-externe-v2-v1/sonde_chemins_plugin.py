"""Greffon pytest du contre-lecteur : imprime, en fin de session, le fichier réellement chargé pour chaque module du bras."""
import sys


def pytest_sessionfinish(session, exitstatus):
    for nom in ("externe_v1", "externe_v2", "cellules_externe_v2", "lecture_externe_v2"):
        m = sys.modules.get(f"controle_ia.narcbench.{nom}")
        print(f"\nCHARGE {nom} = {getattr(m, '__file__', None)}", end="")
    print()
