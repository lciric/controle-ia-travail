"""Contre-lecteur : câblage de `lecture_finale` (quelles cellules font la règle T, la réponse, les qualificatifs de plancher),
sur des cellules fabriquées ; aucun essai de la suite ne le fixe (mutations C12 et C13 survivantes)."""
from controle_ia.narcbench import cellules_externe_v2 as CE
from controle_ia.narcbench import chargeur_externe_v1 as C

ETAT = {"C2": CE.REPRODUIT, "C3": CE.NON_REPRODUIT, "C4": CE.NON_TRANCHE, "C1": CE.NON_CALCULABLE}


def fabrique(lignes):
    """lignes : {(procédure, modèle, statistique) ou procédure : ligne C} pour l'étage stéganographique ; comités : C2."""
    par = {}
    for m in C.MODELES:
        cel = {}
        for p in CE.PROCEDURES:
            for s in CE.STATISTIQUES:
                l = lignes.get((p, m, s), lignes.get(p, "C2"))
                if p == "mahalanobis":
                    cel[f"{p}/stego/{s}"] = {"nom": CE.nom_cellule(p, m, s), "ligne": None, "etat": None, "plancher_court": None,
                                             "estimation": 0.5, "intervalle": {"bas": 0.4, "haut": 0.6}, "phrase": None}
                else:
                    cel[f"{p}/stego/{s}"] = {"nom": CE.nom_cellule(p, m, s), "ligne": l, "etat": ETAT[l], "phrase": ETAT[l],
                                             "plancher_court": CE.AU_DESSUS if p == "temoin" else CE.PAS_AU_DESSUS}
                    cel[f"{p}/core/{s}"] = {"nom": CE.nom_cellule(p, m, s), "ligne": "C2", "etat": CE.REPRODUIT, "phrase": CE.REPRODUIT}
        par[m] = {"cellules": cel}
    return par


def montre(titre, lignes, attendu):
    lf = CE.lecture_finale(fabrique(lignes))
    r = lf["reponse"]
    ok = r["ligne"] == attendu
    print(f"{'OK ' if ok else 'ÉCART'} {titre} : {r['ligne']} (attendu {attendu}) ; T = { {p: v['ligne'] for p, v in lf['regle_t'].items()} } ; "
          f"familles = { {f: v['ligne'] for f, v in lf['phrases_familles'].items()} }")
    return lf, ok


tout = []
lf, ok = montre("témoin reproduit, huit cellules reproduit", {}, "R1"); tout.append(ok)
n = lf["reponse"]["phrase"].split("plancher apparié : ")[1].split(" ; réserve")[0].split(" ; ")
print("   qualificatifs de plancher dans R1 :", len(n), "| témoin :", sum("témoin de recette" in x and x.endswith(": au-dessus") for x in n),
      "| familles :", sum(x.endswith(": pas au-dessus") for x in n))
tout.append(len(n) == 12)
lf, ok = montre("témoin reproduit, huit cellules non reproduit", {"difference_moyennes": "C3", "lineaire": "C3"}, "R2"); tout.append(ok)
tout.append(lf["reponse"]["phrase"].count(" : ") >= 13)
lf, ok = montre("témoin : une cellule non tranchée", {("temoin", "qwen3_32b", "pic"): "C4"}, "R0"); tout.append(ok)
lf, ok = montre("témoin non reproduit partout", {"temoin": "C3", "lineaire": "C3", "difference_moyennes": "C3"}, "R0"); tout.append(ok)
print("   phrase de famille :", lf["phrases_familles"]["lineaire"]["phrase"][:120])
lf, ok = montre("une famille reproduit, l'autre non", {"lineaire": "C3"}, "R3"); tout.append(ok)
print("   ", lf["reponse"]["phrase"][:330])
lf, ok = montre("une cellule non reproduit, les autres non tranchées", {"lineaire": "C4", "difference_moyennes": "C4",
                                                                      ("lineaire", "llama_3_1_70b", "ecart"): "C3"}, "R4"); tout.append(ok)
print("   ", lf["reponse"]["phrase"][:330])
lf, ok = montre("huit cellules non tranchées", {"lineaire": "C4", "difference_moyennes": "C4"}, "R5"); tout.append(ok)
print("   ", lf["reponse"]["phrase"])
lf, ok = montre("une cellule de famille non calculable, les autres reproduit", {("lineaire", "qwen3_32b", "pic"): "C1"}, "R3"); tout.append(ok)
print("   ", lf["reponse"]["phrase"][:400]); print("   T linéaire :", lf["regle_t"]["lineaire"]["phrase"])
print("secondaires :", len(lf["secondaires"]), "; descriptives :", len(lf["descriptives"]))
print("bilan :", "tout conforme" if all(tout) else "ÉCART")
