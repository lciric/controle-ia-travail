"""Épreuve par mutation du contre-lecteur (indépendante de celle du développeur) : copie entière de src/, une mutation,
pytest au premier plan sous timeout avec -o pythonpath=<copie>/src et un greffon qui imprime le fichier chargé.
`essais` d'une mutation : « TOUT » (les 168 essais, la commande de lecture par morceaux pour borner le disque) ou une liste
d'arguments pytest. Usage : python mutations_contre_lecteur.py <extraction> <python> <paquets> <travail> <JSON des mutations>"""
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

EXT, PY, PAQUETS, TRAVAIL, LISTE = Path(sys.argv[1]), sys.argv[2], sys.argv[3], Path(sys.argv[4]), Path(sys.argv[5])
OUTILS = Path(__file__).resolve().parent
IDS = [l.strip() for l in (OUTILS / "ids.txt").read_text(encoding="utf-8").splitlines() if l.strip()]
LEC = [i for i in IDS if "lecture_externe_v2" in i]
AUTRES = sorted({i.split("::")[0] for i in IDS if "lecture_externe_v2" not in i})
TOUT = [AUTRES] + [LEC[k:k + 14] for k in range(0, len(LEC), 14)]


def jouer(d, args):
    cmd = ["timeout", "900", PY, "-m", "pytest", "-q", "-x", "-p", "no:cacheprovider", "-p", "sonde_chemins_plugin", "-s",
           "-o", f"pythonpath={d}/src", f"--basetemp={d}/tmp"] + args
    r = subprocess.run(cmd, cwd=EXT, capture_output=True, text=True,
                       env={"PYTHONPATH": f"{d}/src:{PAQUETS}:{OUTILS}", "PYTHONDONTWRITEBYTECODE": "1", "PATH": "/usr/bin:/bin",
                            "HOME": "/root"})
    shutil.rmtree(d / "tmp", ignore_errors=True)
    return r


for i, mu in enumerate(json.loads(LISTE.read_text(encoding="utf-8"))):
    d = TRAVAIL / f"m{i:02d}"
    if d.exists():
        shutil.rmtree(d)
    shutil.copytree(EXT / "src", d / "src", ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    shutil.copy(EXT / "requirements-cpu.txt", d / "requirements-cpu.txt")   # les essais de la commande le copient depuis la racine du paquet
    p = d / mu["fichier"]
    s = p.read_text(encoding="utf-8")
    if s.count(mu["avant"]) != 1:
        print(f"{mu['nom']} | INAPPLICABLE ({s.count(mu['avant'])} occurrences)", flush=True)
        shutil.rmtree(d)
        continue
    p.write_text(s.replace(mu["avant"], mu["apres"]), encoding="utf-8")
    morceaux = TOUT if mu["essais"] == "TOUT" else [mu["essais"] + (["-k", mu["k"]] if mu.get("k") else [])]
    etat, tueur, bilans, charge_ok, passes = "SURVIVANTE", None, [], False, 0
    mute = Path(mu["fichier"]).stem
    for args in morceaux:
        r = jouer(d, args)
        charges = set(re.findall(r"^CHARGE (\S+) = (\S+)", r.stdout, re.M))
        charge_ok = charge_ok or any(n == mute and str(d) in f for n, f in charges)
        bilan = next((l for l in reversed(r.stdout.splitlines()) if re.search(r"\b(passed|failed|error)", l)), r.stderr.strip()[-200:])
        bilans.append(bilan.strip())
        m = re.search(r"(\d+) passed", bilan)
        passes += int(m.group(1)) if m else 0
        if r.returncode == 124:
            etat = "DÉLAI DÉPASSÉ"
            break
        if r.returncode != 0:
            etat = "TUÉE"
            tueur = next((m.group(1) for m in re.finditer(r"^(?:FAILED|ERROR) (\S+)", r.stdout, re.M)), None)
            motif = next((l.strip()[:230] for l in r.stdout.splitlines() if l.startswith("E  ")), "")
            tueur = f"{tueur} || {motif}"
            break
    shutil.rmtree(d)
    print(f"{mu['nom']} | {etat} | copie mutée chargée : {'oui' if charge_ok else 'non vue'} | {tueur or '—'} | "
          f"{bilans[-1] if etat != 'SURVIVANTE' else str(passes) + ' essais verts'}", flush=True)
shutil.rmtree(TRAVAIL, ignore_errors=True)
