# Registre propre (essai)

| clé | instant | contenu | référence |
|---|---|---|---|
| SCORES-B5F | 2026-11-26T15:00:00Z | x |  |
| SCORES-B5F | 2026-11-26T15:00:00Z | x |  |
