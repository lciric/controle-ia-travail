# Registre propre (essai)

| clé | instant | contenu | référence |
|---|---|---|---|
| ENGAGEMENT-B5F | 2026-11-24T10:00:00Z | sha256 e4b6872de0fb58208e1ee171460a1261ca9c9d1f686abdf35367fa899aa24daa |  |
