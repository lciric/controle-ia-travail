# Registre propre (essai)

| clé | instant | contenu | référence |
|---|---|---|---|
| ENGAGEMENT-B5F | 2026-11-24T10:00:00Z | sha256 6b59c26e68ad2e198e335a6f9c571e6b3b36e7b95d5d428a3042f610cd277c88 |  |
| SCORES-B5F | 2026-11-26T15:00:00Z | scores fermés |  |
