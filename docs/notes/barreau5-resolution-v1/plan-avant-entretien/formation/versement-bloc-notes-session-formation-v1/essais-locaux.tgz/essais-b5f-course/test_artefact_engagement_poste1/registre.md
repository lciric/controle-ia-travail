# Registre propre (essai)

| clé | instant | contenu | référence |
|---|---|---|---|
| ENGAGEMENT-B5F | 2026-11-26T09:00:00Z | sha256 73a130e3ba055282419ad8fc32d48942ecb3f110d7376c90396afad5ab20da5a |  |
