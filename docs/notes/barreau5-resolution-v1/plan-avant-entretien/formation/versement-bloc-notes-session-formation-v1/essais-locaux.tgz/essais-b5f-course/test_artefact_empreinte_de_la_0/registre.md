# Registre propre (essai)

| clé | instant | contenu | référence |
|---|---|---|---|
| ENGAGEMENT-B5F | 2026-11-24T10:00:00Z | sha256 faab9c2d4870e9e107b00b00cca14918b972b74ca1fe02acd0cffd0f557ef9a6 |  |
| SCORES-B5F | 2026-11-26T15:00:00Z | scores fermés |  |
