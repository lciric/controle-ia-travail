# Registre propre (essai)

| clé | instant | contenu | référence |
|---|---|---|---|
| ENGAGEMENT-B5F | 2026-11-24T10:00:00Z | sha256 6653dc085f121f977c82ce0c1f0d4fc28260b7afbeab0fbd11921f8ea801bc01 |  |
| SCORES-B5F | 2026-11-26T15:00:00Z | scores fermés |  |
