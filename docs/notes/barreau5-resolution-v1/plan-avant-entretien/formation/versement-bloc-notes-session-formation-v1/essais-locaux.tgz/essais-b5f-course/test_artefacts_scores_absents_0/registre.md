# Registre propre (essai)

| clé | instant | contenu | référence |
|---|---|---|---|
| ENGAGEMENT-B5F | 2026-11-24T10:00:00Z | sha256 0f7e0d8109fb3368a4916e6d00bd40f3d8200e86303fb89efe7db5f1c31107ef |  |
