# Registre propre (essai)

| clé | instant | contenu | référence |
|---|---|---|---|
| ENGAGEMENT-B5F | 2026-11-26T08:00:00Z | sha256 80b5d917d2c2bd0e09bc320c284726adf246fefde956068cfe8da365aa38c887 |  |
