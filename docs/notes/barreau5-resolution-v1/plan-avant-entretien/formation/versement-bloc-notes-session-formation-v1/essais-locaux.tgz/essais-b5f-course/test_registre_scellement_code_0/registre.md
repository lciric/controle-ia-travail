| SCELLEMENT-B5F | 2026-11-21T18:00:00Z | prereg/barreau5-texte-v1.md ; sha256 ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff ; membres-apprentissage 2 ; piece instance |  |
| CODE-FORMATION-B5F | 2026-11-22T18:00:00Z | commit aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa ; entropie 1361129467683753853853498429727072845824 |  |
| GO-FORMATION-B5F | 2026-11-22T19:00:00Z | GO-2026-11-22-01 |  |
