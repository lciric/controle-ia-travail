| SCELLEMENT-B5F | 2026-11-21T18:00:00Z | prereg/barreau5-texte-v1.md ; sha256 eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee ; membres-apprentissage 2 ; piece instance |  |
| CODE-FORMATION-B5F | 2026-11-22T18:00:00Z | commit bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb ; entropie 5 |  |
| GO-FORMATION-B5F | 2026-11-22T19:00:00Z | GO-2026-11-22-01 |  |
