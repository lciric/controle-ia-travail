# Registre propre (essai)

| clé | instant | contenu | référence |
|---|---|---|---|
| ENGAGEMENT-B5F | 2026-11-24T10:00:00Z | sha256 5f643a9a8c2d69e1723fe427f3d13db609ce16ec305316e3eed80be2b9acce61 |  |
| SCORES-B5F | 2026-11-23T09:00:00Z | scores fermés |  |
