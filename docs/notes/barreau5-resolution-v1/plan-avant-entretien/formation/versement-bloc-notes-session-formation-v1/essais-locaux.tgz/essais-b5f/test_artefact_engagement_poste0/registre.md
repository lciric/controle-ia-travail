# Registre propre (essai)

| clé | instant | contenu | référence |
|---|---|---|---|
| ENGAGEMENT-B5F | 2026-11-26T08:00:00Z | sha256 d3fb63033d2472c2fc1745392af010a805b0c103eebe15017bff753097c78a22 |  |
