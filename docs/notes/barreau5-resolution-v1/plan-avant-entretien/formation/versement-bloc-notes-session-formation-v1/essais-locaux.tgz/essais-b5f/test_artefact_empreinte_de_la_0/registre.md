# Registre propre (essai)

| clé | instant | contenu | référence |
|---|---|---|---|
| ENGAGEMENT-B5F | 2026-11-24T10:00:00Z | sha256 97f81d3360031c6674666e4669769d5fcf43569a50ca48aea169c9143024a80e |  |
| SCORES-B5F | 2026-11-26T15:00:00Z | scores fermés |  |
