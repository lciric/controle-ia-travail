# Registre propre (essai)

| clé | instant | contenu | référence |
|---|---|---|---|
| ENGAGEMENT-B5F | 2026-11-24T10:00:00Z | sha256 3ed4488b3e9261fde808dfb0bf63f09208c599494aaee389ddd903799bac46ee |  |
| SCORES-B5F | 2026-11-23T09:00:00Z | scores fermés |  |
