# Registre propre (essai)

| clé | instant | contenu | référence |
|---|---|---|---|
| ENGAGEMENT-B5F | 2026-11-24T10:00:00Z | sha256 80d4e09ca454911896848db92ca2389c40105a3b9cd57424ffb87ce8a75ea772 |  |
| SCORES-B5F | 2026-11-26T15:00:00Z | scores fermés |  |
