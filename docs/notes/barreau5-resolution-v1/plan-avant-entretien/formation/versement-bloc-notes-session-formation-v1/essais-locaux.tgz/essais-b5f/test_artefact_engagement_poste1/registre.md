# Registre propre (essai)

| clé | instant | contenu | référence |
|---|---|---|---|
| ENGAGEMENT-B5F | 2026-11-26T09:00:00Z | sha256 b55d9b5dd60001b02f99c4bf4f8b46644228ebd20fce7dea30f8f113f681d525 |  |
