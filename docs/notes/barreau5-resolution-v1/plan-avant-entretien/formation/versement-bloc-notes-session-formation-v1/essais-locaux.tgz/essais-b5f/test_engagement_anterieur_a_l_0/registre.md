# Registre propre (essai)

| clé | instant | contenu | référence |
|---|---|---|---|
| ENGAGEMENT-B5F | 2026-11-24T10:00:00Z | sha256 bb27d4d361b96f25bbc9a8240703e4810307abe95f73b7078d6853aa33267dd3 |  |
