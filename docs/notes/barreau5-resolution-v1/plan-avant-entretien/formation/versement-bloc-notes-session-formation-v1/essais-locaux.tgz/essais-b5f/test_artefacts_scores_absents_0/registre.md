# Registre propre (essai)

| clé | instant | contenu | référence |
|---|---|---|---|
| ENGAGEMENT-B5F | 2026-11-24T10:00:00Z | sha256 d654a36b4c7beec41cbc490d0a94fe18d856a16a8d431f9e4f5d414d7bff979c |  |
