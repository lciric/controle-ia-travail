from harnais import *
depot, travail, ch = nouveau_depot()
run = "20260102-000000-extraction"
prep = et.preparer(depot, run, travail, 1, ch=ch)
for info in prep["papiers"].values():
    T._repondre(info["dossier"])
et.valider(depot, run, 1, ch=ch)
ech = et.echantillonner(depot, run)["echantillon"]
cv = et.preparer_contre_verification(depot, run, travail, 1, "echantillon", ch=ch)
(Path(cv["papiers"][ech[0]]["dossier"]) / "avis.json").write_text("{", encoding="utf-8")   # illisible
T._juger(cv["papiers"][ech[1]]["dossier"], dict(T.AVIS, data_type_correct=True))          # réussi (avec un défaut ci-dessous)
lu = et.lire_contre_verification(depot, run, 1)
print("ronde 1 :", {k: lu[k] for k in ("illisibles", "echecs")})
cv2 = et.preparer_contre_verification(depot, run, travail, 2, "echantillon", ch=ch)   # seule voie : tout l'échantillon
for pid in ech:
    T._juger(cv2["papiers"][pid]["dossier"])          # le nouveau sous-agent de chaque papier rend un avis lisible
l2 = et.lire_contre_verification(depot, run, 2); print("ronde 2 :", {k: l2[k] for k in ("illisibles", "echecs")})
essai("assembler", lambda: et.assembler(depot, run, ch=ch)["evaluation"])
au = et.preparer_contre_verification(depot, run, travail, 3, "audit", ch=ch)
for pid in au["papiers"]:
    T._juger(au["papiers"][pid]["dossier"])
et.lire_contre_verification(depot, run, 3)
essai("assembler après audit", lambda: et.assembler(depot, run, ch=ch)["evaluation"])
