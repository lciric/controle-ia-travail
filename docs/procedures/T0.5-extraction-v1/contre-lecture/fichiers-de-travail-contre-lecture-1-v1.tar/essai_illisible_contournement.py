from harnais import *
depot, travail, ch = nouveau_depot()
run = "20260102-000000-extraction"
prep = et.preparer(depot, run, travail, 1, ch=ch)
for info in prep["papiers"].values():
    T._repondre(info["dossier"])
et.valider(depot, run, 1, ch=ch)
ech = et.echantillonner(depot, run)["echantillon"]
cv = et.preparer_contre_verification(depot, run, travail, 1, "echantillon", ch=ch)
(Path(cv["papiers"][ech[0]]["dossier"]) / "avis.json").write_text("{", encoding="utf-8")
T._juger(cv["papiers"][ech[1]]["dossier"])
et.lire_contre_verification(depot, run, 1)
cv2 = et.preparer_contre_verification(depot, run, travail, 2, "echantillon", ch=ch)
T._juger(cv2["papiers"][ech[0]]["dossier"])        # on ne lance que le sous-agent du papier illisible
l2 = et.lire_contre_verification(depot, run, 2)
print("ronde 2, illisibles consignés :", l2["illisibles"])
au = et.preparer_contre_verification(depot, run, travail, 3, "audit", ch=ch)
for pid in au["papiers"]:
    T._juger(au["papiers"][pid]["dossier"])
et.lire_contre_verification(depot, run, 3)
essai("assembler (contournement)", lambda: et.assembler(depot, run, ch=ch)["evaluation"])
