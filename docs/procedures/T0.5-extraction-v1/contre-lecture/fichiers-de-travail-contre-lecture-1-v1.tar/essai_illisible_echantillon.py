from harnais import *
# Scénario : échantillon de 2 ; l'avis du 1er papier est illisible à la ronde 1 ; on le refait « dans une ronde nouvelle ».
depot, travail, ch = nouveau_depot()
run = "20260102-000000-extraction"
prep = et.preparer(depot, run, travail, 1, ch=ch)
for info in prep["papiers"].values():
    T._repondre(info["dossier"])
et.valider(depot, run, 1, ch=ch)
ech = et.echantillonner(depot, run)["echantillon"]
cv = et.preparer_contre_verification(depot, run, travail, 1, "echantillon", ch=ch)
for pid in ech:
    if pid == ech[0]:
        (Path(cv["papiers"][pid]["dossier"]) / "avis.json").write_text("{", encoding="utf-8")  # illisible
    else:
        T._juger(cv["papiers"][pid]["dossier"], dict(T.AVIS, statement_leaks=True, leak_passages=["route tokens to experts"]))
lu = et.lire_contre_verification(depot, run, 1)
print("ronde 1 :", {k: lu[k] for k in ("illisibles", "echecs")})
# Refaire seulement le papier illisible : refusé par le code
essai("ronde 2 echantillon, papier nommé", lambda: et.preparer_contre_verification(depot, run, travail, 2, "echantillon", [ech[0]], ch=ch))
# Seule voie : toute l'échantillon dans une ronde 2 ; tous lisibles et sans échec
cv2 = et.preparer_contre_verification(depot, run, travail, 2, "echantillon", ch=ch)
for pid in ech:
    T._juger(cv2["papiers"][pid]["dossier"])
et.lire_contre_verification(depot, run, 2)
# le 2e papier a échoué à la ronde 1 : on fait la reprise (tentative 3) comme prévu
p3 = et.preparer(depot, run, travail, 3, [ech[1]], ch=ch)
T._repondre(p3["papiers"][ech[1]]["dossier"])
et.valider(depot, run, 3, ch=ch)
cv3 = et.preparer_contre_verification(depot, run, travail, 3, "reprise", [ech[1]], ch=ch)
T._juger(cv3["papiers"][ech[1]]["dossier"])
et.lire_contre_verification(depot, run, 3)
essai("assembler", lambda: et.assembler(depot, run, ch=ch)["evaluation"])
