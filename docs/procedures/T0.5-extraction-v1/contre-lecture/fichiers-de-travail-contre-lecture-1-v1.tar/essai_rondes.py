from harnais import *
import tarfile
C4 = copy.deepcopy(T.CIBLES)
C4["controls"].append({"id": "C4", "description": "a fourth control with a quote", "evidence": "Training the largest model took 1,200 GPU hours", "section": "1"})
AV4 = dict(T.AVIS, targets=[{"id": i, "grounded": True, "observable": i != "C4", "comment": ""} for i in ("C1", "C2", "C3", "C4", "F1")])
depot, travail, ch = nouveau_depot()
run = "20260102-000000-extraction"
prep = et.preparer(depot, run, travail, 1, ch=ch)
for info in prep["papiers"].values():
    T._repondre(info["dossier"], cibles=C4)
et.valider(depot, run, 1, ch=ch)
ech = et.echantillonner(depot, run)["echantillon"]
cv = et.preparer_contre_verification(depot, run, travail, 1, "echantillon", ch=ch)
for pid in ech:
    T._juger(cv["papiers"][pid]["dossier"], AV4)     # réussi, un défaut (C4) : pas d'audit requis
et.lire_contre_verification(depot, run, 1)
# Ronde d'audit numérotée 3 (la 2 sautée), lue : un avis d'audit qui trouve une fuite
au = et.preparer_contre_verification(depot, run, travail, 3, "audit", ch=ch)
for pid in au["papiers"]:
    T._juger(au["papiers"][pid]["dossier"], dict(AV4, statement_leaks=True, leak_passages=["route tokens to experts"]))
et.lire_contre_verification(depot, run, 3)
b = et.assembler(depot, run, ch=ch)
print("audit au bilan :", b["audit"], "| exclus :", b["exclus"])
with tarfile.open(depot / "diag" / run / "sorties-brutes.tar") as t:
    print("avis archivés :", sorted(n for n in t.getnames() if n.endswith("avis.json")))
