import json, math, copy, subprocess, sys, tempfile
from pathlib import Path
from math import comb
sys.dont_write_bytecode = True
sys.path.insert(0, "/home/user/controle-ia/src")
from controle_ia.environnements import extraction as ex

# 1. Binomiale : P(plus de 4 echecs sur 16) selon le taux d'echec par papier
for p in (0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.50):
    q = sum(comb(16, k) * p**k * (1-p)**(16-k) for k in range(5, 17))
    print(f"p={p:.2f}  P(X>=5 sur 16)={q:.3f}")

TEXTE = ("Introduction. We study routers in mixture-of-experts models. "
         "We compare against a dense baseline trained with the same compute budget. "
         "Removing the load-balancing loss leads to expert collapse. "
         "We also ablate the number of experts from 8 to 64. "
         "Training the largest model took 1,200 GPU hours on A100 GPUs. "
         "Our main finding is that top-2 routing with capacity factor 1.25 matches dense quality.")
H9 = {"affiliations": [], "research_questions": "Mixture-of-experts models route tokens to experts. " * 8,
      "costs": {"total": None, "splits": []}}
H10 = {"theory_experiment": "experiments_only", "data_type": "real_only", "domains": []}
CIBLES = {"controls": [
    {"id": "C1", "description": "a dense baseline with matched compute", "evidence": "We compare against a dense baseline trained with the same compute budget.", "section": "1"},
    {"id": "C2", "description": "an ablation of the load-balancing loss", "evidence": "Removing the load-balancing loss leads to expert collapse.", "section": "1"},
    {"id": "C3", "description": "an ablation of the number of experts", "evidence": "We also ablate the number of experts from 8 to 64.", "section": "1"}],
    "compute": {"reference_gpu_hours": 1200, "basis": "reported", "evidence": "x"},
    "fruitful_directions": [{"id": "F1", "description": "top-2 routing with a moderate capacity factor", "evidence": "top-2 routing with capacity factor 1.25 matches dense quality", "section": "1"}],
    "sterile_directions": []}

# 2. LaTeX mal echappe dans l'enonce : "$\theta$" ecrit tel quel dans le fichier JSON
brut = '{"affiliations": [], "costs": {"total": null, "splits": []}, "research_questions": "' + ("Background sentence about models. " * 7) + 'We ask how the parameter $\\theta$ and $\\beta$ and $\\frac{1}{2}$ and $\\nabla f$ and $\\rho$ behave."}'
print("\n2. octets du fichier (extrait):", brut[-90:])
h9 = json.loads(brut)
rq = h9["research_questions"]
print("   caracteres de controle dans l'enonce lu :", sorted({hex(ord(c)) for c in rq if ord(c) < 32}))
print("   extrait lu :", repr(rq[-70:]))
print("   anomalies module :", ex.anomalies_h9(h9))

# 3. identifiant non hachable
c = copy.deepcopy(CIBLES); c["controls"][0]["id"] = ["C1"]
try:
    print("\n3. id liste ->", ex.anomalies_cibles(c, TEXTE))
except Exception as e:
    print("\n3. id liste -> exception", type(e).__name__, e)

# 4. tres grand entier
c = copy.deepcopy(CIBLES); c["compute"]["reference_gpu_hours"] = 10**400
try:
    print("4. 10**400 ->", ex.anomalies_cibles(c, TEXTE))
except Exception as e:
    print("4. 10**400 -> exception", type(e).__name__, e)

# 5. cle echappee de H10
h10 = json.loads('{"theory_experiment": "mostly\\\\_theory", "data\\\\_type": "real_only", "domains": []}')
print("5. cles lues :", list(h10), "anomalies :", ex.anomalies_h10(h10))
