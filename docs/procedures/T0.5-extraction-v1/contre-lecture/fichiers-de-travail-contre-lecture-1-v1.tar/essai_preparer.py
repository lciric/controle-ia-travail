from harnais import *
depot, travail, ch = nouveau_depot()
run = "20260102-000000-extraction"
(travail / "tentative-1").mkdir()
essai("preparer t1 (dossier déjà là)", lambda: et.preparer(depot, run, travail, 1, ch=ch))
print("manifeste créé malgré l'arrêt :", (depot / "runs" / run / "manifeste.json").is_file())
shutil.rmtree(travail / "tentative-1")
essai("preparer t1 (2e essai, même run)", lambda: et.preparer(depot, run, travail, 1, ch=ch))
# Tentative 3 préparable sans échec de contre-vérification, et seuil non contrôlé avant l'assemblage
depot, travail, ch = nouveau_depot()
prep = et.preparer(depot, run, travail, 1, ch=ch)
for info in prep["papiers"].values():
    T._repondre(info["dossier"])
et.valider(depot, run, 1, ch=ch)
essai("preparer t3 avant tout échantillon", lambda: sorted(et.preparer(depot, run, travail, 3, [sorted(prep["papiers"])[0]], ch=ch)["papiers"]))
essai("echantillonner apres t3 preparee (non validee)", lambda: et.echantillonner(depot, run)["echantillon"])
