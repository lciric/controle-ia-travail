"""Harnais d'essai : dépôt jetable construit comme dans tests/test_extraire_t05.py (copie des aides, sans rien écrire
dans le dépôt réel)."""
import sys, json, shutil, subprocess, tempfile, hashlib, copy
from pathlib import Path
sys.dont_write_bytecode = True
sys.path.insert(0, "/home/user/controle-ia/src")
sys.path.insert(0, "/home/user/controle-ia/tests")
import conftest  # git, committer
import test_extraire_t05 as T
from controle_ia.environnements import extraire_t05 as et
from controle_ia.environnements import extraction as ex
from controle_ia.gardes import GardeArret

def nouveau_depot(n_pilote=3, n_reserve=3, ech=2, seuil=1, audit=1):
    et.TAILLE_PILOTE, et.TAILLE_RESERVE = n_pilote, n_reserve
    et.TAILLE_ECHANTILLON, et.SEUIL_ECHECS, et.TAILLE_AUDIT = ech, seuil, audit
    base = Path(tempfile.mkdtemp(dir=str(Path(__file__).parent)))
    depot = base / "depot"; depot.mkdir()
    conftest.git(depot, "init", "-q", "-b", "main")
    conftest.git(depot, "config", "user.email", "t@e.invalid"); conftest.git(depot, "config", "user.name", "t")
    (depot / "README").write_text("x\n"); conftest.git(depot, "add", "-A"); conftest.git(depot, "commit", "-q", "-m", "i")
    ch = T._depot_de_test(depot, n_pilote, n_reserve)
    travail = base / "travail"; travail.mkdir()
    return depot, travail, ch

def essai(nom, f):
    try:
        r = f()
        print(f"[{nom}] OK -> {r}")
    except GardeArret as e:
        print(f"[{nom}] GardeArret : {e}")
    except Exception as e:
        print(f"[{nom}] EXCEPTION {type(e).__name__} : {e}")
