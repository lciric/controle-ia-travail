from harnais import *
# Texte avec une bordure de tableau en grille plus longue que la largeur (ici 60 pour l'essai), puis une ligne de contenu.
texte = (T.TEXTE + "\n\n" + "+" + "-" * 100 + "+\n" + "| setting | dense baseline | routed model | notes |\n")
parties = ex.copie_de_lecture(texte, largeur=60, taille_partie=400)
copie = "".join(parties)
print("normaliser(copie) == normaliser(texte) :", ex.normaliser(copie) == ex.normaliser(texte))
# Citation copiée de la copie de lecture, à cheval sur la coupe de la bordure (saut de ligne -> espace)
i = copie.index("+-")
lignes = copie[i:].split("\n")
citation = lignes[0][-25:] + "\n" + lignes[1][:30]
print("citation :", repr(citation))
c = copy.deepcopy(T.CIBLES); c["sterile_directions"] = [{"id": "S1", "description": "a sterile direction here", "evidence": citation, "section": "2"}]
d = Path(tempfile.mkdtemp(dir=".")) / "p"
(d / "papier").mkdir(parents=True); (d / "sorties").mkdir()
for k, p in enumerate(parties, 1):
    (d / "papier" / f"partie-{k:02d}.md").write_text(p, encoding="utf-8")
for nom, obj in (("h9", T.H9), ("h10", T.H10), ("cibles", c)):
    (d / "sorties" / f"{nom}.json").write_text(json.dumps(obj), encoding="utf-8")
r = subprocess.run([sys.executable, "-I", "/home/user/controle-ia/docs/procedures/T0.5-extraction-v1/verifier-sortie-v1.py", str(d)], capture_output=True, text=True)
print("script (copie) :", r.stdout.strip().splitlines()[-1])
print("module (original) :", ex.lire_sorties(d / "sorties", texte)["anomalies"])
# Identifiant non hachable et très grand entier : comportement du script
c2 = copy.deepcopy(T.CIBLES); c2["controls"][0]["id"] = ["C1"]
(d / "sorties" / "cibles.json").write_text(json.dumps(c2), encoding="utf-8")
r = subprocess.run([sys.executable, "-I", "/home/user/controle-ia/docs/procedures/T0.5-extraction-v1/verifier-sortie-v1.py", str(d)], capture_output=True, text=True)
print("script, id liste : code", r.returncode, "| derniere ligne stderr :", r.stderr.strip().splitlines()[-1])
