"""Greffon pytest : relève les lignes exécutées de extraction.py et extraire_t05.py (sans module coverage)."""
import sys, threading, json, os
CIBLES = ("environnements/extraction.py", "environnements/extraire_t05.py")
VUES = set()
def _trace(frame, event, arg):
    f = frame.f_code.co_filename
    if not f.endswith(CIBLES):
        return None
    def local(frame, event, arg):
        if event == "line":
            VUES.add((frame.f_code.co_filename.rsplit("/", 1)[1], frame.f_lineno))
        return local
    return local
def pytest_configure(config):
    sys.settrace(_trace); threading.settrace(_trace)
def pytest_unconfigure(config):
    sys.settrace(None)
    out = os.path.join(os.path.dirname(__file__), "lignes_vues.json")
    json.dump(sorted(VUES), open(out, "w"))
