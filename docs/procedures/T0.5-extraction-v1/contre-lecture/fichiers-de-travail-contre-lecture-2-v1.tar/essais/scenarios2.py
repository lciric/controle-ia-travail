from harnais2 import *
RUN = T.RUN
CONFIRME = T._avec(T.AVIS, theory_experiment_correct=True, theory_experiment_expected="theory_only")

def s12_rondes_paralleles_et_refait():
    depot, ch, tr = nouveau("s12c")
    prep = et.preparer(depot, RUN, tr, 1, ch=ch)
    ids = sorted(prep["papiers"])
    for pid in ids:
        T._repondre(prep["papiers"][pid]["dossier"], h10=T._avec(T.H10, theory_experiment="theory_only") if pid == ids[5] else T.H10)
    et.valider(depot, RUN, 1, T._retours(prep), ch=ch)
    ech = et.echantillonner(depot, RUN, ch=ch)
    e0, e1 = ech["echantillon"]
    cv = et.preparer_contre_verification(depot, RUN, tr, "echantillon", ch=ch)   # ronde 1
    th = et.preparer_contre_verification(depot, RUN, tr, "theorie", ch=ch)       # ronde 2 (parallèle)
    T._juger(cv["papiers"][e0]["dossier"])
    et.lire_contre_verification(depot, RUN, 1, T._retours(cv), ch=ch)            # e1 illisible
    cv3 = et.preparer_contre_verification(depot, RUN, tr, "echantillon", [e1], ch=ch)  # ronde 3, ronde 2 non lue
    T._juger(cv3["papiers"][e1]["dossier"])
    et.lire_contre_verification(depot, RUN, 3, T._retours(cv3), ch=ch)
    T._juger(th["papiers"][ids[5]]["dossier"], CONFIRME)
    et.lire_contre_verification(depot, RUN, 2, T._retours(th), ch=ch)
    au = et.preparer_contre_verification(depot, RUN, tr, "audit", ch=ch)
    for p in au["papiers"]: T._juger(au["papiers"][p]["dossier"])
    et.lire_contre_verification(depot, RUN, 4, T._retours(au), ch=ch)
    b = et.assembler(depot, RUN, ch=ch)
    print("   exclus :", b["exclus"], "évaluation :", b["evaluation"], "entraînement :", b["entrainement"])
    print("   classification :", b["classification_et_calcul"], "références :", b["taches_assemblees"])

def s18_ok_du_contre_verificateur_puis_retouche():
    depot, ch, tr = nouveau("s18")
    _, ech = T._jusqu_a_l_echantillon(depot, tr, ch)
    e0, e1 = ech["echantillon"]
    cv = et.preparer_contre_verification(depot, RUN, tr, "echantillon", ch=ch)
    T._juger(cv["papiers"][e0]["dossier"])
    T._juger(cv["papiers"][e1]["dossier"], T._avec(T.AVIS, comment="ok\tvu"))   # retouche après le dernier « OK »
    try:
        et.lire_contre_verification(depot, RUN, 1, T._retours(cv, {e0: "OK: 0 error(s)", e1: "OK: 0 error(s)"}), ch=ch)
    except GardeArret as e:
        print("   lecture :", str(e)[:140])
    try:
        et.preparer_contre_verification(depot, RUN, tr, "echantillon", [e1], ch=ch)
    except GardeArret as e:
        print("   refaire e1 :", str(e)[:140])

def s19_reference_nulle_comptee_par_base():
    depot, ch, tr = nouveau("s19")
    prep = et.preparer(depot, RUN, tr, 1, ch=ch)
    c = copy.deepcopy(T.CIBLES); c["compute"] = {"reference_gpu_hours": None, "basis": "estimated", "evidence": "too little"}
    for pid in prep["papiers"]:
        T._repondre(prep["papiers"][pid]["dossier"], cibles=c)
    et.valider(depot, RUN, 1, T._retours(prep), ch=ch)
    ech = et.echantillonner(depot, RUN, ch=ch)
    cv = et.preparer_contre_verification(depot, RUN, tr, "echantillon", ch=ch)
    for p in ech["echantillon"]: T._juger(cv["papiers"][p]["dossier"])
    et.lire_contre_verification(depot, RUN, 1, T._retours(cv), ch=ch)
    au = et.preparer_contre_verification(depot, RUN, tr, "audit", ch=ch)
    for p in au["papiers"]: T._juger(au["papiers"][p]["dossier"])
    et.lire_contre_verification(depot, RUN, 2, T._retours(au), ch=ch)
    b = et.assembler(depot, RUN, ch=ch)
    print("   taches_assemblees :", b["taches_assemblees"])

for nom, f in list(globals().items()):
    if nom.startswith("s") and callable(f) and nom[1].isdigit():
        essai(nom, f)
