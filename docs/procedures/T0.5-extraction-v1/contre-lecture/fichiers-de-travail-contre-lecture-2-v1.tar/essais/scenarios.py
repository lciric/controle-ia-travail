from harnais2 import *
RUN = T.RUN

def s1_refait_puis_audit_puis_assemblage():
    depot, ch, tr = nouveau("s1")
    _, ech = T._jusqu_a_l_echantillon(depot, tr, ch)
    e0, e1 = ech["echantillon"]
    cv = et.preparer_contre_verification(depot, RUN, tr, "echantillon", ch=ch)
    T._juger(cv["papiers"][e0]["dossier"])
    et.lire_contre_verification(depot, RUN, 1, T._retours(cv), ch=ch)       # e1 illisible
    cv2 = et.preparer_contre_verification(depot, RUN, tr, "echantillon", [e1], ch=ch)
    T._juger(cv2["papiers"][e1]["dossier"])
    et.lire_contre_verification(depot, RUN, 2, T._retours(cv2), ch=ch)
    au = et.preparer_contre_verification(depot, RUN, tr, "audit", ch=ch)
    for p in au["papiers"]: T._juger(au["papiers"][p]["dossier"])
    et.lire_contre_verification(depot, RUN, 3, T._retours(au), ch=ch)
    print("   reprises dues :", et.reprises_dues(depot, RUN))
    b = et.assembler(depot, RUN, ch=ch)
    print("   assemblé : évaluation", b["evaluation"], "audit", b["audit"]["papiers"], b["audit"]["accord_echec"])

def s4_echec_puis_t3_theory_only_sans_verification():
    depot, ch, tr = nouveau("s4")
    _, ech = T._jusqu_a_l_echantillon(depot, tr, ch)
    e0, e1 = ech["echantillon"]
    cv = et.preparer_contre_verification(depot, RUN, tr, "echantillon", ch=ch)
    T._juger(cv["papiers"][e0]["dossier"], T.FUITE)
    T._juger(cv["papiers"][e1]["dossier"])
    et.lire_contre_verification(depot, RUN, 1, T._retours(cv), ch=ch)
    p3 = et.preparer(depot, RUN, tr, 3, [e0], ch=ch)
    T._repondre(p3["papiers"][e0]["dossier"], h10=T._avec(T.H10, theory_experiment="theory_only"))
    et.valider(depot, RUN, 3, T._retours(p3), ch=ch)
    try:
        et.preparer_contre_verification(depot, RUN, tr, "reprise", ch=ch)
    except GardeArret as e:
        print("   ronde reprise :", e)
    try:
        et.preparer_contre_verification(depot, RUN, tr, "theorie", ch=ch)
    except GardeArret as e:
        print("   ronde theorie :", e)
    b = et.assembler(depot, RUN, ch=ch)
    print("   statut de", e0, ":", b["statuts"][e0], "— classé experiments_only à T1, contre-vérifié non theory_only")

def s5_ok_rapporte_puis_modification_arret_global():
    depot, ch, tr = nouveau("s5")
    prep = et.preparer(depot, RUN, tr, 1, ch=ch)
    ids = sorted(prep["papiers"])
    for pid in ids:
        T._repondre(prep["papiers"][pid]["dossier"])
    # le sous-agent du papier 0 a vu « OK », puis a retouché son énoncé après une alerte, sans relancer le script
    d = Path(prep["papiers"][ids[0]]["dossier"]) / "sorties" / "h9.json"
    h9 = json.loads(d.read_text()); h9["research_questions"] = h9["research_questions"][:150]; d.write_text(json.dumps(h9))
    lignes = {p: T.OK_LIGNE for p in ids}
    for k in range(2):
        try:
            et.valider(depot, RUN, 1, T._retours(prep, lignes), ch=ch)
        except GardeArret as e:
            print(f"   essai {k+1} de validation :", str(e)[:120])
    try:
        et.echantillonner(depot, RUN, ch=ch)
    except GardeArret as e:
        print("   suite :", e)
    try:
        et.preparer(depot, RUN, tr, 2, [ids[0]], ch=ch)
    except GardeArret as e:
        print("   tentative 2 :", str(e)[:120])

def s6_audit_cote_sale_accord():
    depot, ch, tr = nouveau("s6", echantillon=2, seuil=1, audit=2)
    _, ech = T._jusqu_a_l_echantillon(depot, tr, ch)
    cv = et.preparer_contre_verification(depot, RUN, tr, "echantillon", ch=ch)
    for p in ech["echantillon"]: T._juger(cv["papiers"][p]["dossier"], T.FUITE)
    try:
        et.lire_contre_verification(depot, RUN, 1, T._retours(cv), ch=ch)
    except GardeArret as e:
        print("   lecture :", str(e)[:100])
    au = et.preparer_contre_verification(depot, RUN, tr, "audit", ch=ch)
    for p in au["papiers"]: T._juger(au["papiers"][p]["dossier"])
    r = et.lire_contre_verification(depot, RUN, 2, T._retours(au), ch=ch)
    print("   ronde d'audit lue :", {k: r[k] for k in ("role", "echecs", "illisibles")})
    fichiers = sorted(p.name for p in (depot / "diag" / RUN).glob("*.json"))
    print("   résultats diag :", fichiers)
    print("   « accord » calculé quelque part ? ", any("accord" in (depot / "diag" / RUN / f).read_text() for f in fichiers))

def s12_rondes_paralleles_et_refait():
    depot, ch, tr = nouveau("s12")
    _, ech = T._jusqu_a_l_echantillon(depot, tr, ch, theorie=None)
    # papier de réserve « theory_only » : on refait le chemin avec un papier théorique
    depot, ch, tr = nouveau("s12b")
    prep = et.preparer(depot, RUN, tr, 1, ch=ch)
    ids = sorted(prep["papiers"])
    for pid in ids:
        T._repondre(prep["papiers"][pid]["dossier"], h10=T._avec(T.H10, theory_experiment="theory_only") if pid == ids[5] else T.H10)
    et.valider(depot, RUN, 1, T._retours(prep), ch=ch)
    ech = et.echantillonner(depot, RUN, ch=ch)
    e0, e1 = ech["echantillon"]
    cv = et.preparer_contre_verification(depot, RUN, tr, "echantillon", ch=ch)   # ronde 1
    th = et.preparer_contre_verification(depot, RUN, tr, "theorie", ch=ch)       # ronde 2 (parallèle)
    T._juger(cv["papiers"][e0]["dossier"])
    et.lire_contre_verification(depot, RUN, 1, T._retours(cv), ch=ch)            # e1 illisible
    cv3 = et.preparer_contre_verification(depot, RUN, tr, "echantillon", [e1], ch=ch)  # ronde 3, ronde 2 non lue
    T._juger(cv3["papiers"][e1]["dossier"])
    et.lire_contre_verification(depot, RUN, 3, T._retours(cv3), ch=ch)
    T._juger(th["papiers"][ids[5]]["dossier"])                                      # confirme theory_only
    et.lire_contre_verification(depot, RUN, 2, T._retours(th), ch=ch)
    au = et.preparer_contre_verification(depot, RUN, tr, "audit", ch=ch)
    for p in au["papiers"]: T._juger(au["papiers"][p]["dossier"])
    et.lire_contre_verification(depot, RUN, 4, T._retours(au), ch=ch)
    b = et.assembler(depot, RUN, ch=ch)
    print("   exclus :", b["exclus"], "évaluation :", b["evaluation"], "entraînement :", b["entrainement"])

def s13_seuil_atteint_par_un_refait():
    depot, ch, tr = nouveau("s13", echantillon=3, seuil=1, audit=1)
    _, ech = T._jusqu_a_l_echantillon(depot, tr, ch)
    a, b_, c = ech["echantillon"]
    cv = et.preparer_contre_verification(depot, RUN, tr, "echantillon", ch=ch)
    T._juger(cv["papiers"][a]["dossier"], T.FUITE); T._juger(cv["papiers"][b_]["dossier"])
    r = et.lire_contre_verification(depot, RUN, 1, T._retours(cv), ch=ch)
    print("   ronde 1 :", r["echecs"], r["illisibles"])
    cv2 = et.preparer_contre_verification(depot, RUN, tr, "echantillon", [c], ch=ch)
    T._juger(cv2["papiers"][c]["dossier"], T.FUITE)
    et.lire_contre_verification(depot, RUN, 2, T._retours(cv2), ch=ch)

for nom, f in list(globals().items()):
    if nom.startswith("s") and callable(f) and nom[1].isdigit():
        essai(nom, f)
