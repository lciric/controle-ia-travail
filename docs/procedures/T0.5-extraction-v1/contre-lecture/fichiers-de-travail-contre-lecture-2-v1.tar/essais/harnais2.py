"""Harnais : dépôt git jetable (hors du dépôt relu), helpers des tests du dépôt réutilisés en lecture seule."""
import subprocess, sys, tempfile, json, copy
from pathlib import Path
sys.dont_write_bytecode = True
sys.path[:0] = ["/home/user/controle-ia/src", "/home/user/controle-ia/tests"]
import test_extraire_t05 as T
from controle_ia.environnements import extraire_t05 as et
from controle_ia.environnements import extraction as ex
from controle_ia.gardes import GardeArret

BASE = Path(__file__).resolve().parent / "depots"
BASE.mkdir(exist_ok=True)

def git(r, *a):
    subprocess.run(["git", "-C", str(r), *a], check=True, capture_output=True)

def nouveau(nom, n_pilote=3, n_reserve=3, echantillon=2, seuil=1, audit=1):
    et.TAILLE_PILOTE, et.TAILLE_RESERVE = n_pilote, n_reserve
    et.TAILLE_ECHANTILLON, et.SEUIL_ECHECS, et.TAILLE_AUDIT = echantillon, seuil, audit
    d = Path(tempfile.mkdtemp(prefix=nom + "-", dir=BASE))
    depot = d / "depot"; depot.mkdir()
    git(depot, "init", "-q", "-b", "main"); git(depot, "config", "user.email", "t@e.invalid"); git(depot, "config", "user.name", "t")
    (depot / "README").write_text("x\n"); git(depot, "add", "-A"); git(depot, "commit", "-q", "-m", "init")
    ch = T._depot_de_test(depot, n_pilote, n_reserve)
    travail = d / "travail"; travail.mkdir()
    return depot, ch, travail

def essai(nom, f):
    print(f"=== {nom}")
    try:
        f()
    except GardeArret as e:
        print("   ARRÊT :", str(e)[:200])
    except Exception as e:
        print("   EXCEPTION", type(e).__name__, str(e)[:200])
