import json, subprocess, sys
from pathlib import Path
PROC = Path("/home/user/controle-ia/docs/procedures/T0.5-extraction-v1")
d = Path("dossiers/message"); (d / "papier").mkdir(parents=True, exist_ok=True); (d / "sorties").mkdir(exist_ok=True)
(d / "papier" / "partie-01.md").write_text("x\n", encoding="utf-8")
rq = "Mixture-of-experts models route tokens to experts. " * 30 + "Let $\\theta$ be the router."   # \t non doublé, loin
(d / "sorties" / "h9.json").write_text('{"affiliations": [], "costs": {"total": null, "splits": []}, "research_questions": "' + rq + '"}')
s = subprocess.run([sys.executable, "-I", str(PROC / "verifier-sortie-v1.py"), str(d)], capture_output=True, text=True)
print([l for l in s.stdout.splitlines() if "texte" in l])
