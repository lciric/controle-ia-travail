"""Règle proposée pour D-1 : saut de ligne suivi d'une minuscule dans un segment $…$ sans ligne vide, ou « \\n » + « abla » partout."""
import re
FORMULE = re.compile(r"\$[^$]*\$")
def formule_cassee(s):
    if re.search(r"\nabla", s):
        return True
    return any(re.search(r"\n[a-z]", m.group(0)) and "\n\n" not in m.group(0) for m in FORMULE.finditer(s))
cas = {
 "dollar puis formule (2 paragraphes)": ("Costs over $100M.\n\nLet $\\theta$ denote it.", False),
 "deux montants (2 paragraphes)": ("A run costs $2M.\n\nServing costs $5 per query.", False),
 "deux montants (saut simple)": ("A run costs $2M.\nServing costs $5 per query.", False),
 "\\nabla en ligne": ("We ask how $\nabla f$ behaves.", True),
 "\\nu": ("Let $\nu$ be fixed.", True),
 "\\neq": ("Whether $a \neq b$ holds.", True),
 "\\nabla en display": ("How $$\nabla_\\theta L$$ behaves.", True),
 "\\neq en display (résidu déclaré)": ("Whether $$a \neq b$$ holds.", False),
 "formule saine": ("Let $\\theta \\in \\mathbb{R}^d$.", False),
}
for nom, (s, attendu) in cas.items():
    print(f"{nom:40s} détecté={formule_cassee(s)!s:5s} attendu={attendu}")
