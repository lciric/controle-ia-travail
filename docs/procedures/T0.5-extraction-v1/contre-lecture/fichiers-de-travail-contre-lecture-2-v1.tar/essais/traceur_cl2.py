"""Greffon pytest : relève les lignes exécutées des deux modules de décision (hors du dépôt)."""
import sys, threading, json, os
CIBLES = ("environnements/extraction.py", "environnements/extraire_t05.py")
VUES = {c: set() for c in CIBLES}

def _trace(frame, event, arg):
    f = frame.f_code.co_filename
    for c in CIBLES:
        if f.endswith(c):
            if event == "line":
                VUES[c].add(frame.f_lineno)
            return _trace
    return None

def pytest_configure(config):
    sys.settrace(_trace)
    threading.settrace(_trace)

def pytest_unconfigure(config):
    sys.settrace(None)
    out = os.environ.get("TRACE_OUT", "lignes_vues.json")
    json.dump({c: sorted(v) for c, v in VUES.items()}, open(out, "w"))
