"""Faux positifs et faux négatifs du contrôle des barres obliques (texte.controle, texte.formule)."""
import json, subprocess, sys, copy
from pathlib import Path
sys.path.insert(0, "/home/user/controle-ia/src")
from controle_ia.environnements import extraction as ex

PROC = Path("/home/user/controle-ia/docs/procedures/T0.5-extraction-v1")
TEXTE = ("Introduction. We study routers in mixture-of-experts models.\n"
         "We compare against a dense baseline trained with the same compute budget.\n"
         "Removing the load-balancing loss leads to expert collapse.\n"
         "We also ablate the number of experts from 8 to 64, a gap of -3 points.\n"
         "Training the largest model took 1,200 GPU hours on A100 GPUs.\n"
         "Our main finding is that top-2 routing with capacity factor 1.25 matches *dense* quality, a 5\\% gain.\n")
BASE = "Mixture-of-experts models route tokens to experts. " * 5
H9 = {"affiliations": [], "costs": {"total": None, "splits": []}}
H10 = {"theory_experiment": "experiments_only", "data_type": "real_only", "domains": []}
CIBLES = {"controls": [
    {"id": "C1", "description": "a dense baseline with matched compute", "evidence": "We compare against a dense baseline trained with the same compute budget.", "section": "1"},
    {"id": "C2", "description": "an ablation of the load-balancing loss", "evidence": "Removing the load-balancing loss leads to expert collapse.", "section": "1"},
    {"id": "C3", "description": "an ablation of the number of experts", "evidence": "We also ablate the number of experts from 8 to 64", "section": "1"}],
    "compute": {"reference_gpu_hours": 1200, "basis": "reported", "evidence": "1,200 GPU hours"},
    "fruitful_directions": [{"id": "F1", "description": "top-2 routing with a moderate capacity factor", "evidence": "capacity factor 1.25 matches dense quality, a 5% gain", "section": "1"}],
    "sterile_directions": []}

def run(nom, rq_json_literal, cibles=CIBLES):
    """rq_json_literal : la chaîne research_questions telle que le sous-agent l'écrit dans le fichier JSON (échappements compris)."""
    d = Path("dossiers") / nom
    (d / "papier").mkdir(parents=True, exist_ok=True)
    (d / "sorties").mkdir(exist_ok=True)
    (d / "papier" / "partie-01.md").write_text(TEXTE, encoding="utf-8")
    h9_txt = '{"affiliations": [], "costs": {"total": null, "splits": []}, "research_questions": "' + rq_json_literal + '"}'
    (d / "sorties" / "h9.json").write_text(h9_txt, encoding="utf-8")
    (d / "sorties" / "h10.json").write_text(json.dumps(H10), encoding="utf-8")
    (d / "sorties" / "cibles.json").write_text(json.dumps(cibles), encoding="utf-8")
    r = ex.lire_sorties(d / "sorties", TEXTE)
    s = subprocess.run([sys.executable, "-I", str(PROC / "verifier-sortie-v1.py"), str(d)], capture_output=True, text=True)
    rq = r["sorties"].get("h9", {}).get("research_questions", "")
    print(f"--- {nom}\n  module : {[ex.code_anomalie(a) for a in r['anomalies']]}\n  script : {s.stdout.strip().splitlines()[-1]}")
    for l in s.stdout.splitlines():
        if l.startswith("ERROR"): print("   ", l[:160])
    return rq

# 1. faux positif : un montant en dollars au paragraphe 1, une formule correcte (doublée) au paragraphe 2
run("dollar_puis_formule", BASE + "Training such models costs over $100M.\\n\\nLet $\\\\theta$ denote the router parameters.")
# 2. faux positif : deux montants en dollars dans deux paragraphes, sans aucun LaTeX
run("deux_montants", BASE + "A single training run costs $2M.\\n\\nServing it costs another $5 per thousand queries.")
# 2b. idem, avec le dollar échappé par le markdown (\\$), comme le texte converti le porte souvent
run("deux_montants_echappes", BASE + "A single training run costs \\\\$2M.\\n\\nServing it costs another \\\\$5 per thousand queries.")
# 2c. même énoncé sur un seul paragraphe : passe
run("deux_montants_un_paragraphe", BASE + "A single training run costs $2M, and serving it costs another $5 per thousand queries.")
# 3. faux négatif : formule de display $$...$$ avec \nabla non doublé (lu comme saut de ligne)
rq = run("display_nabla", BASE + "We ask how $$\\nabla_\\\\theta L$$ behaves.")
print("   énoncé lu :", repr(rq[-40:]))
# 3b. faux négatif : \nu hors de toute formule (rare) ; \neq dans $$ $$
rq = run("display_neq", BASE + "Whether $$a \\neq b$$ holds is open.")
print("   énoncé lu :", repr(rq[-40:]))
# 4. contrôle sain : \nabla dans $...$ : détecté
run("inline_nabla", BASE + "We ask how $\\nabla f$ behaves.")
