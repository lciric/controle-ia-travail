Introduction. We study routers in mixture-of-experts models.
We compare against a dense baseline trained with the same compute budget.
Removing the load-balancing loss leads to expert collapse.
We also ablate the number of experts from 8 to 64, a gap of -3 points.
Training the largest model took 1,200 GPU hours on A100 GPUs.
Our main finding is that top-2 routing with capacity factor 1.25 matches *dense* quality, a 5\% gain.
