# Method

The objective is $\mathcal{L}(\theta) = \mathbb{E}_{x \sim p}
  [\ell(x; \theta)]$ and the update is $\theta_{t+1} = \theta_t -
\eta g_t$, where $g_t$ is a stochastic gradient. We use $k$-means with $k = 10$. The bound $O(n
\log n)$ holds. $$\begin{align*}
  f(x) &= \sum_i w_i x_i \\
  &\le \|w\| \|x\|
\end{align*}$$ $$\begin{equation}
\label{eq:x}
y = \sigma(Wx + b)
\end{equation}$$ $$\begin{multline}
p(x) = q(x)
+ r(x)
\end{multline}$$
