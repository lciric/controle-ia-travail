---
abstract: |
  Training frontier models costs over \$100M, and fine-tuning adds \$5M per run.
title: Synthetic
---

# Introduction

We minimize $$\begin{equation}
  x_{t+1} = x_t - \eta \nabla f(x_t)
\end{equation}$$ for all $t$. The gradient $\nabla_\theta L$ and $a +
b = c$ with $\nu \neq 0$. $$\begin{align}
a &= b \\
c &= d
\end{align}$$ and $$\min_\theta \; \mathbb{E}[\ell(\theta)]$$ We perform an ablation study of each component. Costs: \$2M for pretraining and \$0.5M for fine-tuning.

Second paragraph with a cost of \$3M.
