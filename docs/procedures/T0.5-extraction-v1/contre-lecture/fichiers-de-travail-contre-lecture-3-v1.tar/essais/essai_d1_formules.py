"""Contre-lecture 3, D-1 : règle des formules — cas réalistes (faux positifs, faux négatifs) et accord exhaustif
du module et des deux scripts (copies byte à byte, importées hors du dépôt).

Lancer : PYTHONPATH=/home/user/controle-ia/src PYTHONDONTWRITEBYTECODE=1 python essai_d1_formules.py
"""
import importlib.util
import json
import random
import sys
from pathlib import Path

sys.dont_write_bytecode = True
ICI = Path(__file__).resolve().parent.parent
from controle_ia.environnements import extraction as ex  # noqa: E402


def charger(nom, fichier):
    spec = importlib.util.spec_from_file_location(nom, ICI / "copies-scripts" / fichier)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


vs = charger("vs", "verifier_sortie_v1.py")
va = charger("va", "verifier_avis_v1.py")


def codes_module(obj):
    return [ex.code_anomalie(a) for a in ex.anomalies_texte(obj, "h9.json")]


def codes_script(m, obj):
    return [x.split("]")[0][1:] for x in m.check_text(obj, "h9.json")]


BASE = "Large language models are increasingly trained at great expense. "

# Chaque cas : (nom, chaîne telle que décodée du JSON, attendu « juste » selon le sens, commentaire)
# attendu True = il FAUT une anomalie (corruption réelle) ; False = texte sain (aucune anomalie ne devrait sortir)
CAS = [
    # --- textes sains (le décodage JSON a été bien fait) ---
    ("montants, deux paragraphes", BASE + "Training cost over $100M.\n\nLater runs cost $5M.", False, "corrigé par D-1"),
    ("montants, un paragraphe", BASE + "Runs cost $100M, fine-tuning $5M.", False, ""),
    ("montants, saut simple puis minuscule", BASE + "Pretraining costs about $100M\nand fine-tuning adds $5M.", False,
     "liste ou retour à la ligne simple dans un même paragraphe"),
    ("liste a. b. avec montants", BASE + "Budgets:\na. pretraining at $2M;\nb. fine-tuning at $0.5M.", False, ""),
    ("liste à tirets avec montants", BASE + "Budgets:\n- pretraining at $2M;\n- fine-tuning at $0.5M.", False, ""),
    ("formule d'affichage, saut réel puis minuscule", BASE + "We study\n$$\nx_{t+1} = x_t - \\eta g_t\n$$\nfor all t.",
     False, "formule bien échappée, sauts de ligne voulus"),
    ("formule d'affichage aligned", BASE + "$$\n\\begin{aligned}\na &= b \\\\\nc &= d\n\\end{aligned}\n$$", False,
     "formule bien échappée sur plusieurs lignes"),
    ("formule d'affichage, saut puis barre", BASE + "$$\n\\min_\\theta L(\\theta)\n$$", False, ""),
    ("formule en ligne bien échappée", BASE + "Let $\\nabla_\\theta L$ and $\\nu \\neq 0$.", False, ""),
    ("mot « ablation » en début de ligne", BASE + "Two open questions remain:\nablation of the router, and scale.",
     False, "saut de ligne réel suivi du mot ablation"),
    ("citation coupée avant « ablate »", "we perform a careful\nablation of each component", False,
     "citation recopiée avec la fin de ligne du texte converti"),
    ("dollars échappés", BASE + "Over \\$100M.\nThen \\$5M.", False, ""),
    ("montant puis formule, même paragraphe, saut simple", BASE + "It costs $5M\nand we let $\\theta$ vary.", False,
     ""),
    # --- corruptions réelles (barre oblique non doublée) ---
    ("\\nu dans $…$", BASE + "with $a \nu$ fixed", True, ""),
    ("\\neq dans $$…$$", BASE + "where $$a \neq b$$ holds", True, ""),
    ("\\nabla hors formule", BASE + "the gradient \nabla f is", True, ""),
    ("\\nu hors de tout $", BASE + "momentum \\(\nu\\) is fixed", True, "délimiteurs \\( \\)"),
    ("\\nu sans délimiteur", BASE + "the coefficient \nu is fixed", True, "LaTeX nu écrit sans $"),
    ("\\nRightarrow dans $…$", BASE + "so $A \nRightarrow B$ in general", True, "majuscule après le saut"),
    ("\\nu désapparié par un montant", BASE + "It costs $5M. Let $a \nu$ be.", True, "résidu déclaré"),
    ("\\nu après un montant, deux paragraphes",
     BASE + "It costs $5M.\n\nLet $a + \nu$ be.", True, "résidu déclaré"),
    ("\\not dans $…$", BASE + "if $a \not\\in B$", True, ""),
]


def main():
    print("=== D-1 : cas réalistes (module = scripts ?) ===")
    desaccords = 0
    for nom, s, corrompu, note in CAS:
        cm, cs, ca = codes_module(s), codes_script(vs, s), codes_script(va, s)
        desaccords += not (cm == cs == ca)
        signale = "texte.formule" in cm
        verdict = ("juste" if signale == corrompu else ("FAUX POSITIF" if signale else "FAUX NÉGATIF"))
        print(f"{verdict:13s} | {nom:48s} | module {cm} | script sortie {cs} | script avis {ca} | {note}")
    print("désaccords module/scripts sur les cas :", desaccords)

    # --- accord exhaustif sur des chaînes aléatoires (alphabet piégé) ---
    rng = random.Random(20261007)
    morceaux = ["$", "$$", "\\$", "\\", "\n", "\n\n", "\n \n", " ", "a", "A", "abla", "u", "eq", "\t", "x", "1", "M",
                "\ud835", "\r", "\\\\", "\u2028", "é", "{", "}"]
    n, diff = 200_000, 0
    exemples = []
    for _ in range(n):
        s = "".join(rng.choice(morceaux) for _ in range(rng.randint(0, 25)))
        obj = {"k": [s, {"z": s[::-1]}]}
        a, b, c = codes_module(obj), codes_script(vs, obj), codes_script(va, obj)
        p1, p2, p3 = ex.position_formule_corrompue(s), vs.broken_formula(s), va.broken_formula(s)
        if not (a == b == c and p1 == p2 == p3):
            diff += 1
            if len(exemples) < 5:
                exemples.append((s, a, b, c))
    print(f"accord exhaustif : {n} chaînes, {diff} désaccord(s)", exemples)


if __name__ == "__main__":
    main()
