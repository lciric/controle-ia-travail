"""D-1 : une citation fidèle d'un passage converti par pandoc 3.9 (formule en ligne coupée par une fin de ligne du
source LaTeX) : faux positif, message, et les deux corrections possibles du sous-agent. Texte synthétique."""
import json, subprocess, sys
from pathlib import Path
sys.dont_write_bytecode = True
from controle_ia.environnements import extraction as ex
from test_extraire_t05 import CIBLES, H9, H10

S = Path(__file__).resolve().parent.parent
from test_extraire_t05 import TEXTE
papier = TEXTE + (S / "pandoc" / "synthetique.md").read_text(encoding="utf-8")
fidele = "The gradient $\\nabla_\\theta L$ and $a +\nb = c$ with $\\nu \\neq 0$."
assert fidele in papier
for nom, citation in (("fidèle (saut de ligne recopié)", fidele),
                      ("saut remplacé par une espace", fidele.replace("+\nb", "+ b")),
                      ("saut écrit \\\\n (mauvaise lecture du message)", fidele.replace("+\nb", "+\\nb"))):
    c = json.loads(json.dumps(CIBLES))
    c["controls"][0]["evidence"] = citation
    d = S / "dossiers" / ("pandoc-" + str(abs(hash(nom)) % 10**6))
    (d / "papier").mkdir(parents=True, exist_ok=True); (d / "sorties").mkdir(exist_ok=True)
    (d / "papier" / "partie-01.md").write_text(papier, encoding="utf-8")
    for n, o in (("h9", H9), ("h10", H10), ("cibles", c)):
        (d / "sorties" / f"{n}.json").write_text(json.dumps(o), encoding="utf-8")
    r = subprocess.run([sys.executable, "-I", "/home/user/controle-ia/docs/procedures/T0.5-extraction-v1/verifier-sortie-v1.py", str(d)],
                       capture_output=True, text=True)
    print(f"--- {nom}\n" + "\n".join(l for l in r.stdout.splitlines() if l.startswith(("ERROR", "OK", "NOT OK"))))
    print("module :", [ex.code_anomalie(a) for a in ex.lire_sorties(d / "sorties", papier)["anomalies"]])
