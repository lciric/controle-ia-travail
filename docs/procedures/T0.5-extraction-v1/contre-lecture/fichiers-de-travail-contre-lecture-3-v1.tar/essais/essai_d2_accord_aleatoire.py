"""Contre-lecture 3, D-2 : accord du module et des scripts sur des sorties et des avis mutés au hasard (graine fixe).

Pour chaque cas, un dossier synthétique est écrit (papier en parties, sorties ou avis), puis :
- module : `ex.lire_sorties` (texte entier) ou la lecture d'avis de `lire_contre_verification` (mêmes branches) ;
- script : la copie scellée, exécutée comme en production par `et.codes_du_script` (sous-processus, -I).
Lancer : PYTHONPATH=/home/user/controle-ia/src:/home/user/controle-ia/tests PYTHONDONTWRITEBYTECODE=1 python ce_fichier N
"""
import copy
import json
import random
import shutil
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from controle_ia.environnements import extraction as ex  # noqa: E402
from controle_ia.environnements import extraire_t05 as et  # noqa: E402
from test_extraire_t05 import AVIS, CIBLES, H9, H10, TEXTE  # noqa: E402

PROC = Path("/home/user/controle-ia/docs/procedures/T0.5-extraction-v1")
ICI = Path(__file__).resolve().parent.parent / "dossiers" / "aleatoire"
PIEGES = ["\t", "\n", "\n\n", "$", "$$", "\\$", "\ud835", " ", "\r", "­", "−", "“", "*", "\\_",
          "abla", "\nu", "Table 3", "[FIGURE 2]", "We propose", "é", "\x0b", "NaN", "\\", "\"", "C1", ""]


def bruit(rng, s):
    if not isinstance(s, str) or rng.random() < 0.5:
        return s
    i = rng.randint(0, len(s))
    return s[:i] + rng.choice(PIEGES) + s[i:]


def muter(rng, obj, profondeur=0):
    if isinstance(obj, dict):
        o = {k: muter(rng, v, profondeur + 1) for k, v in obj.items()}
        if rng.random() < 0.08 and o:
            del o[rng.choice(list(o))]
        if rng.random() < 0.05:
            o[bruit(rng, "extra")] = rng.choice([1, "x", None, [], {}])
        return o
    if isinstance(obj, list):
        o = [muter(rng, v, profondeur + 1) for v in obj]
        if rng.random() < 0.1 and o:
            o.append(copy.deepcopy(rng.choice(o)))
        if rng.random() < 0.08 and o:
            o.pop(rng.randrange(len(o)))
        return o
    if isinstance(obj, str):
        return bruit(rng, obj) if rng.random() < 0.6 else rng.choice([obj, 3, None, True, [obj]] if rng.random() < 0.1
                                                                     else [obj])
    if isinstance(obj, bool):
        return rng.choice([obj, not obj, "true", None]) if rng.random() < 0.2 else obj
    if isinstance(obj, (int, float)) or obj is None:
        return rng.choice([obj, -1, 0, 0.0, 10 ** 400, 1e308 * 10, "12", None, True]) if rng.random() < 0.2 else obj
    return obj


def ecrire(chemin, obj, rng):
    if rng.random() < 0.03:
        chemin.write_text(rng.choice(["{", "[1,", '{"a": NaN}', "﻿{}", ""]), encoding="utf-8")
    elif rng.random() < 0.03:
        return                                                     # fichier absent
    else:
        try:
            chemin.write_text(json.dumps(obj, ensure_ascii=rng.random() < 0.5, allow_nan=True), encoding="utf-8",
                              errors="surrogatepass")
        except (UnicodeEncodeError, ValueError):
            chemin.write_text(json.dumps(obj, ensure_ascii=True, allow_nan=True), encoding="utf-8")


def cas_sorties(rng, k):
    d = ICI / f"s{k}"
    (d / "papier").mkdir(parents=True)
    (d / "sorties").mkdir()
    texte = TEXTE if rng.random() < 0.7 else TEXTE.replace("\n", "\r\n")
    for i, partie in enumerate(ex.copie_de_lecture(texte, taille_partie=rng.choice([120, 200, 25_000])), start=1):
        (d / "papier" / f"partie-{i:02d}.md").write_text(partie, encoding="utf-8")
    for nom, base in (("h9", H9), ("h10", H10), ("cibles", CIBLES)):
        ecrire(d / "sorties" / f"{nom}.json", muter(rng, copy.deepcopy(base)), rng)
    module = sorted(ex.code_anomalie(a) for a in ex.lire_sorties(d / "sorties", texte)["anomalies"])
    script = sorted(et.codes_du_script(PROC / "verifier-sortie-v1.py", d))
    return module, script


def cas_avis(rng, k):
    d = ICI / f"a{k}"
    (d / "a-verifier").mkdir(parents=True)
    for nom, base in (("h9", H9), ("h10", H10), ("cibles", CIBLES)):
        (d / "a-verifier" / f"{nom}.json").write_text(json.dumps(base), encoding="utf-8")
    ecrire(d / "avis.json", muter(rng, copy.deepcopy(AVIS)), rng)
    # mêmes branches que `lire_contre_verification` (entrées intactes)
    anomalies = []
    if not (d / "avis.json").is_file():
        anomalies.append("[fichier.absent] avis.json absent")
    else:
        try:
            avis = json.loads((d / "avis.json").read_bytes().decode("utf-8"), parse_constant=ex._refuser_constante)
        except ValueError as e:
            anomalies.append(f"[json.illisible] {e}")
    if not anomalies:
        h9, h10, cibles = (json.loads((d / "a-verifier" / f"{n}.json").read_bytes()) for n in ex.NOMS_SORTIES)
        anomalies = ex.anomalies_avis(avis, h9, h10, cibles)
    module = sorted(ex.code_anomalie(a) for a in anomalies)
    script = sorted(et.codes_du_script(PROC / "verifier-avis-v1.py", d))
    return module, script


def main(n):
    if ICI.exists():
        shutil.rmtree(ICI)
    rng = random.Random(7)
    ecarts, crashs, vus = [], [], {}
    for k in range(n):
        for genre, f in (("sorties", cas_sorties), ("avis", cas_avis)):
            try:
                m, s = f(rng, k)
            except Exception as e:                       # noqa: BLE001 — on consigne tout
                crashs.append((genre, k, type(e).__name__, str(e)[:120]))
                continue
            for c in m:
                vus[c] = vus.get(c, 0) + 1
            if m != s:
                ecarts.append((genre, k, m, s))
    print(f"{n} cas de sorties et {n} cas d'avis ; écarts : {len(ecarts)} ; exceptions : {len(crashs)}")
    print("codes rencontrés :", dict(sorted(vus.items())))
    for e in ecarts[:5]:
        print("ÉCART", e)
    for c in crashs[:8]:
        print("EXCEPTION", c)


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 300)
