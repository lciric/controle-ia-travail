"""Contre-lecture 3 : les correctifs proposés pour E-1, E-6 et E-7 (copie corrigée du code, hors du dépôt) rendent
les comportements attendus par la procédure. Lancer avec PYTHONPATH=<correctif>/src:<essais>:<dépôt>/tests."""
import copy
import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, "/home/user/controle-ia/tests")
from conftest import depot  # noqa: E402,F401
from test_extraire_t05 import (CIBLES, RUN, _depot_de_test, _jusqu_a_l_echantillon, _juger, _petit,  # noqa: E402
                               _repondre, _retours)

from controle_ia.environnements import extraire_t05 as et  # noqa: E402

assert "correctif" in et.__file__, et.__file__


@pytest.mark.parametrize("alteration", ["supprimee", "json_casse", "famille_retiree", "h9_liste"])
def test_e1_corrige(depot, tmp_path_factory, monkeypatch, alteration):
    _petit(monkeypatch)
    ch = _depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    _, ech = _jusqu_a_l_echantillon(depot, travail, ch)
    e0, e1 = ech["echantillon"]
    cv = et.preparer_contre_verification(depot, RUN, travail, "echantillon", ch=ch)
    _juger(cv["papiers"][e0]["dossier"])
    _juger(cv["papiers"][e1]["dossier"])
    av = Path(cv["papiers"][e0]["dossier"]) / "a-verifier"
    {"supprimee": lambda: (av / "cibles.json").unlink(),
     "json_casse": lambda: (av / "cibles.json").write_text("{"),
     "famille_retiree": lambda: (av / "cibles.json").write_text(json.dumps({"controls": []})),
     "h9_liste": lambda: (av / "h9.json").write_text("[]")}[alteration]()
    lu = et.lire_contre_verification(depot, RUN, 1, _retours(cv), ch=ch)
    assert lu["illisibles"] == [e0] and lu["papiers"][e0]["codes"] == ["entrees.modifiees"]
    assert lu["papiers"][e1]["lisible"]


def test_e6_corrige(depot, tmp_path_factory, monkeypatch):
    _petit(monkeypatch)
    ch = _depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    prep = et.preparer(depot, RUN, travail, 1, ch=ch)
    ids = sorted(prep["papiers"])
    c = copy.deepcopy(CIBLES)
    c["controls"][0]["id"] = "C\ud835"
    c["controls"][0]["evidence"] = "too short"
    c["compute"]["reference_gpu_hours"] = "about 1200\ud835"
    for pid, info in prep["papiers"].items():
        _repondre(info["dossier"], cibles=c if pid == ids[0] else CIBLES)
    v = et.valider(depot, RUN, 1, _retours(prep), ch=ch)
    assert v["invalides"] == [ids[0]]
    assert sorted(v["papiers"][ids[0]]["anomalies"]) == ["cibles.calcul_valeur", "cibles.citation_courte",
                                                         "texte.substitut"]


def test_e7_corrige(depot, tmp_path_factory, monkeypatch):
    _petit(monkeypatch)
    ch = _depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    prep = et.preparer(depot, RUN, travail, 1, ch=ch)
    ids = sorted(prep["papiers"])
    d0 = Path(prep["papiers"][ids[0]]["dossier"])
    (d0 / "papier" / "partie-01-notes.md").write_text("Removing the router leads to a total collapse of everything.\n")
    c = copy.deepcopy(CIBLES)
    c["controls"][1]["evidence"] = "Removing the router leads to a total collapse of everything."
    for pid, info in prep["papiers"].items():
        _repondre(info["dossier"], cibles=c if pid == ids[0] else CIBLES)
    v = et.valider(depot, RUN, 1, _retours(prep), ch=ch)
    assert v["invalides"] == [ids[0]] and v["papiers"][ids[0]]["entrees_modifiees"] == ["papier/partie-01-notes.md"]
