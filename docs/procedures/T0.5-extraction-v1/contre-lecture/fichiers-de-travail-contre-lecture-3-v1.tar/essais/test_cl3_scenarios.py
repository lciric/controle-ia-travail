"""Contre-lecture 3 : déroulés dans des dépôts jetables (fonctions des tests du dépôt, en lecture seule).

Chaque test ÉTABLIT un comportement (il réussit quand le comportement observé est celui que le rapport décrit).
Lancer depuis la racine du dépôt :
  PYTHONPATH=src:<essais>:tests PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m pytest -q -s <ce fichier> \
      --basetemp=<scratch>/pytest-tmp -p no:cacheprovider
"""
import copy
import hashlib
import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, "/home/user/controle-ia/tests")
from conftest import depot  # noqa: E402,F401  (fixture)
from test_extraire_t05 import (AVIS, CIBLES, H9, H10, OK_LIGNE, RUN, TEXTE, _avec, _depot_de_test,  # noqa: E402
                               _jusqu_a_l_echantillon, _juger, _petit, _repondre, _retours)

from controle_ia.environnements import extraction as ex  # noqa: E402
from controle_ia.environnements import extraire_t05 as et  # noqa: E402
from controle_ia.gardes import GardeArret  # noqa: E402


# --- E : une entrée « à vérifier » modifiée par un contre-vérificateur fait tomber toute la lecture de la ronde ------

@pytest.mark.parametrize("alteration", ["supprimee", "json_casse", "famille_retiree", "h9_liste"])
def test_entree_a_verifier_modifiee_fait_tomber_la_ronde(depot, tmp_path_factory, monkeypatch, alteration):
    _petit(monkeypatch)
    ch = _depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    _, ech = _jusqu_a_l_echantillon(depot, travail, ch)
    e0, e1 = ech["echantillon"]
    cv = et.preparer_contre_verification(depot, RUN, travail, "echantillon", ch=ch)
    _juger(cv["papiers"][e0]["dossier"])
    _juger(cv["papiers"][e1]["dossier"])
    av = Path(cv["papiers"][e0]["dossier"]) / "a-verifier"
    if alteration == "supprimee":
        (av / "cibles.json").unlink()
    elif alteration == "json_casse":
        (av / "cibles.json").write_text("{", encoding="utf-8")
    elif alteration == "famille_retiree":
        c = json.loads((av / "cibles.json").read_text())
        del c["sterile_directions"]
        (av / "cibles.json").write_text(json.dumps(c), encoding="utf-8")
    else:
        (av / "h9.json").write_text("[]", encoding="utf-8")
    # attendu par la procédure (CL-5) : « entrees.modifiees », anomalie du seul papier e0 ; observé : exception
    with pytest.raises(Exception) as info:
        et.lire_contre_verification(depot, RUN, 1, _retours(cv), ch=ch)
    assert not isinstance(info.value, GardeArret)            # ce n'est même pas une garde
    print(f"\n[E-entrees] {alteration} : {type(info.value).__name__}: {info.value}")
    assert not (depot / "diag" / RUN / "contre-verification-ronde-1.json").exists()
    with pytest.raises(GardeArret, match="préparée et non lue"):   # la ronde reste non lue : tout est bloqué
        et.assembler(depot, RUN, ch=ch)


# --- E : un caractère de substitution isolé dans un identifiant (message brut) bloque la validation entière ---------

@pytest.mark.parametrize("ou", ["identifiant", "reference"])
def test_substitut_dans_un_message_bloque_la_validation(depot, tmp_path_factory, monkeypatch, ou):
    _petit(monkeypatch)
    ch = _depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    prep = et.preparer(depot, RUN, travail, 1, ch=ch)
    ids = sorted(prep["papiers"])
    c = copy.deepcopy(CIBLES)
    if ou == "identifiant":
        c["controls"][0]["id"] = "C\ud835"
        c["controls"][0]["evidence"] = "too short"
    else:
        c["compute"]["reference_gpu_hours"] = "about 1200\ud835"
    for pid, info in prep["papiers"].items():
        _repondre(info["dossier"], cibles=c if pid == ids[0] else CIBLES)
    for essai in (1, 2):                          # la même étape refaite : même arrêt (contenu déterministe)
        with pytest.raises(GardeArret, match="non encodable") as info:
            et.valider(depot, RUN, 1, _retours(prep), ch=ch)
        print(f"\n[E-substitut] {ou}, essai {essai} : {info.value}")
    archive = depot / "donnees" / RUN / "sorties-tentative-1.tar"
    print("[E-substitut] archive écrite malgré « rien n'est écrit » :", archive.exists(),
          (archive.parent / "sorties-tentative-1.tar.sha256").exists())
    assert archive.exists()
    assert not (depot / "diag" / RUN / "validation-tentative-1.json").exists()


# --- E : un fichier ajouté dans papier/ (pas une entrée modifiée) : désaccord du script et du module, arrêt global ---

def test_fichier_ajoute_dans_papier_arrete_toute_la_validation(depot, tmp_path_factory, monkeypatch):
    _petit(monkeypatch)
    ch = _depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    prep = et.preparer(depot, RUN, travail, 1, ch=ch)
    ids = sorted(prep["papiers"])
    d0 = Path(prep["papiers"][ids[0]]["dossier"])
    (d0 / "papier" / "partie-01-notes.md").write_text("Removing the router leads to a total collapse of everything.\n")
    c = copy.deepcopy(CIBLES)
    c["controls"][1]["evidence"] = "Removing the router leads to a total collapse of everything."
    for pid, info in prep["papiers"].items():
        _repondre(info["dossier"], cibles=c if pid == ids[0] else CIBLES)
    assert et._entrees_modifiees(d0, prep["papiers"][ids[0]]["entrees"]) == []      # rien n'est « modifié »
    with pytest.raises(GardeArret, match="désaccord en production") as info:
        et.valider(depot, RUN, 1, _retours(prep), ch=ch)
    print(f"\n[E-ajout] {info.value}")


# --- D-2 : texte du papier avec retours chariot, citation à cheval sur deux parties : accord du script et du module --

def test_accord_texte_avec_retours_chariot_et_parties(depot, tmp_path_factory, monkeypatch):
    _petit(monkeypatch)
    origine = ex.copie_de_lecture
    monkeypatch.setattr(ex, "copie_de_lecture", lambda t: origine(t, taille_partie=120))   # parties courtes
    ch = _depot_de_test(depot)
    # textes réécrits avec des fins de ligne CRLF et un CR isolé, empreintes du corpus refaites (dépôt jetable)
    corpus = json.loads((depot / ch.corpus).read_text())
    for f in corpus["resultat"]["fiches"]:
        p = depot / ch.textes / f"{f['id']}v{f['version']}.md"
        t = p.read_text(encoding="utf-8").replace("\n", "\r\n").replace("dense baseline", "dense\rbaseline")
        p.write_bytes(t.encode("utf-8"))
        f["texte_sha256"] = hashlib.sha256(t.encode("utf-8")).hexdigest()
    import subprocess
    (depot / ch.corpus).unlink()
    (depot / (ch.corpus + ".sha256")).unlink()
    from controle_ia.manifeste import ecrire_resultat
    ecrire_resultat(depot, depot / "runs" / "20260101-000000-corpus" / "manifeste.json", "corpus",
                    {"fiches": corpus["resultat"]["fiches"]})
    subprocess.run(["git", "-C", str(depot), "add", "-A"], check=True)
    subprocess.run(["git", "-C", str(depot), "commit", "-q", "-m", "crlf"], check=True)
    travail = tmp_path_factory.mktemp("travail")
    prep = et.preparer(depot, RUN, travail, 1, ch=ch)
    assert all(info["parties"] > 1 for info in prep["papiers"].values())
    for info in prep["papiers"].values():
        _repondre(info["dossier"])
    v = et.valider(depot, RUN, 1, _retours(prep, {p: OK_LIGNE for p in prep["papiers"]}), ch=ch)
    print("\n[D-2 CR] invalides :", v["invalides"], "; accord avec l'annonce :",
          {p: f["retour"]["accord_avec_le_module"] for p, f in v["papiers"].items()})
    assert v["invalides"] == []


# --- D-3 : une perte de donnees/<run>/ : l'étape suivante s'arrête, mais rien n'écrit l'arrêt scellé ------------------

def test_perte_de_donnees_arret_non_consigne(depot, tmp_path_factory, monkeypatch):
    import shutil
    _petit(monkeypatch)
    ch = _depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    _jusqu_a_l_echantillon(depot, travail, ch)
    shutil.rmtree(depot / "donnees" / RUN)
    with pytest.raises(GardeArret, match="absent sur disque") as info:
        et.preparer_contre_verification(depot, RUN, travail, "echantillon", ch=ch)
    print(f"\n[D-3] {info.value}")
    noms = sorted(p.name for p in (depot / "diag" / RUN).glob("*.json"))
    print("[D-3] diag après la perte :", noms)
    assert not any("perte" in n for n in noms)


# --- D-3 : une perte de donnees/<run>/ n'est vue qu'à l'étape qui relit une archive : la tentative 2 et l'échantillon
#     passent d'abord sur un run déjà perdu ----------------------------------------------------------------------------

def test_perte_detectee_tardivement(depot, tmp_path_factory, monkeypatch):
    import shutil
    _petit(monkeypatch)
    ch = _depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    prep = et.preparer(depot, RUN, travail, 1, ch=ch)
    ids = sorted(prep["papiers"])
    for pid, info in prep["papiers"].items():
        _repondre(info["dossier"], h9=_avec(H9, research_questions="court") if pid == ids[0] else H9)
    et.valider(depot, RUN, 1, _retours(prep), ch=ch)
    shutil.rmtree(depot / "donnees" / RUN)                       # perte après la validation 1
    p2 = et.preparer(depot, RUN, travail, 2, [ids[0]], ch=ch)   # passe
    _repondre(p2["papiers"][ids[0]]["dossier"])
    et.valider(depot, RUN, 2, _retours(p2), ch=ch)              # passe : une archive neuve est écrite
    et.echantillonner(depot, RUN, ch=ch)                        # passe
    print("\n[D-3 tardif] donnees/<run> après la tentative 2 :", sorted(p.name for p in (depot / "donnees" / RUN).iterdir()))
    with pytest.raises(GardeArret, match="absent sur disque"):
        et.preparer_contre_verification(depot, RUN, travail, "echantillon", ch=ch)
