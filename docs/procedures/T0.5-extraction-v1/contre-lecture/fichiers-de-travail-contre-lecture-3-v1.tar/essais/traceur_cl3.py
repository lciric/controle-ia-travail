"""Greffon pytest de traçage (contre-lecture 3) : quelles gardes `raise GardeArret` des deux modules de décision sont
exécutées par les tests ? Lancer avec `-p traceur_cl3` (dossier de ce fichier dans PYTHONPATH)."""
import ast
import sys
import threading
from pathlib import Path

RACINE = Path("/home/user/controle-ia/src/controle_ia/environnements")
CIBLES = {str(RACINE / "extraction.py"), str(RACINE / "extraire_t05.py")}
VUS = set()


def _local(frame, event, arg):
    if event == "line":
        VUS.add((frame.f_code.co_filename, frame.f_lineno))
    return _local


def _global(frame, event, arg):
    if frame.f_code.co_filename in CIBLES:
        VUS.add((frame.f_code.co_filename, frame.f_lineno))
        return _local
    return None


def pytest_sessionstart(session):
    threading.settrace(_global)
    sys.settrace(_global)


def gardes(fichier):
    arbre = ast.parse(Path(fichier).read_text(encoding="utf-8"))
    for n in ast.walk(arbre):
        if isinstance(n, ast.Raise) and isinstance(n.exc, ast.Call) and getattr(n.exc.func, "id", "") == "GardeArret":
            yield n.lineno, n.end_lineno


def pytest_sessionfinish(session, exitstatus):
    sys.settrace(None)
    threading.settrace(None)
    total, manques = 0, []
    for f in sorted(CIBLES):
        lignes = {l for (ff, l) in VUS if ff == f}
        for debut, fin in gardes(f):
            total += 1
            if not any(l in lignes for l in range(debut, fin + 1)):
                manques.append(f"{Path(f).name}:{debut}")
    print(f"\n[traceur_cl3] gardes : {total} ; non exercées : {len(manques)} {manques}")
