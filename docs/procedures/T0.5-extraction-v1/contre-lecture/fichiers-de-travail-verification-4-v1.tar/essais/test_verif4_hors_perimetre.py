"""Vérification 4 : comportements préexistants (hors des corrections de la contre-lecture 3), relevés en répondant à la
question B (étapes refaites après une panne). Chaque test réussit tant que le comportement est présent.

Lancement : comme test_verif4_scenarios.py.
"""
import json
from pathlib import Path

import pytest

import test_extraire_t05 as t5
from conftest import depot  # noqa: F401
from controle_ia import manifeste
from controle_ia.environnements import extraire_t05 as et
from controle_ia.gardes import GardeArret

RUN = t5.RUN


def _tentative_1(depot, monkeypatch, tmp_path_factory, invalides=1):
    t5._petit(monkeypatch)
    ch = t5._depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    prep = et.preparer(depot, RUN, travail, 1, ch=ch)
    ids = sorted(prep["papiers"])
    court = t5._avec(t5.H9, research_questions="court")
    for pid, info in prep["papiers"].items():
        t5._repondre(info["dossier"], h9=court if pid in ids[:invalides] else t5.H9)
    return ch, travail, prep, ids


def test_preparation_interrompue_ne_se_refait_pas(depot, tmp_path_factory, monkeypatch):
    """Préparation de la tentative 2 interrompue avant son résultat : le dossier existe, le résultat non ; refaire
    l'étape s'arrête (R12 sur le dossier) et rien d'autre ne peut suivre : run bloqué, sans arrêt consigné."""
    ch, travail, prep, ids = _tentative_1(depot, monkeypatch, tmp_path_factory)
    et.valider(depot, RUN, 1, t5._retours(prep), ch=ch)
    vrai = et._ecrire

    def panne(racine, run_id, nom, contenu):
        if nom == "preparation-tentative-2":
            raise KeyboardInterrupt("interruption simulée")
        return vrai(racine, run_id, nom, contenu)

    monkeypatch.setattr(et, "_ecrire", panne)
    with pytest.raises(KeyboardInterrupt):
        et.preparer(depot, RUN, travail, 2, ids[:1], ch=ch)
    monkeypatch.setattr(et, "_ecrire", vrai)
    with pytest.raises(GardeArret, match="déjà préparée"):
        et.preparer(depot, RUN, travail, 2, ids[:1], ch=ch)
    with pytest.raises(GardeArret, match="non refait"):
        et.echantillonner(depot, RUN, ch=ch)


def test_resultat_de_diag_non_scelle_apres_interruption(depot, tmp_path_factory, monkeypatch):
    """`ecrire_resultat` écrit puis scelle : interrompu entre les deux, le résultat reste sans empreinte compagnon, et
    toute étape suivante s'arrête sur lui (sans arrêt consigné)."""
    ch, travail, prep, ids = _tentative_1(depot, monkeypatch, tmp_path_factory, invalides=0)
    vrai = manifeste.sceller

    def panne(chemin):
        if Path(chemin).name == "validation-tentative-1.json":
            raise KeyboardInterrupt("interruption simulée")
        return vrai(chemin)

    monkeypatch.setattr(manifeste, "sceller", panne)
    with pytest.raises(KeyboardInterrupt):
        et.valider(depot, RUN, 1, t5._retours(prep), ch=ch)
    monkeypatch.setattr(manifeste, "sceller", vrai)
    assert json.loads((depot / "diag" / RUN / "validation-tentative-1.json").read_text())["resultat"]["tentative"] == 1
    for etape in (lambda: et.valider(depot, RUN, 1, t5._retours(prep), ch=ch),
                  lambda: et.echantillonner(depot, RUN, ch=ch)):
        with pytest.raises(GardeArret, match="compagnon"):
            etape()


def test_sortie_tres_imbriquee_exception_hors_garde(depot, tmp_path_factory, monkeypatch):
    """Une sortie JSON imbriquée au-delà de la limite de récursion lève RecursionError (pas une ValueError) : la
    validation tombe hors garde, à l'identique à chaque relance."""
    ch, travail, prep, ids = _tentative_1(depot, monkeypatch, tmp_path_factory, invalides=0)
    (Path(prep["papiers"][ids[0]]["dossier"]) / "sorties" / "h9.json").write_text("[" * 100_000 + "]" * 100_000)
    for _ in range(2):
        with pytest.raises(RecursionError):
            et.valider(depot, RUN, 1, t5._retours(prep), ch=ch)
