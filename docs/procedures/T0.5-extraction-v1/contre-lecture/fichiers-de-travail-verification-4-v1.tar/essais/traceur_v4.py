"""Greffon pytest (vérification 4) : relève les lignes exécutées des deux modules de l'extraction, puis liste les
gardes (« raise GardeArret ») jamais exécutées. Chargé par `-p traceur_v4` (dossier des essais dans PYTHONPATH).
Sortie : <W>/essais/sortie_traceur.txt."""
import sys
import threading
from pathlib import Path

CIBLES = ("environnements/extraction.py", "environnements/extraire_t05.py")
_vues: set = set()


def _trace(frame, event, arg):
    f = frame.f_code.co_filename
    if not f.endswith(CIBLES):
        return None

    def locale(fr, ev, a):
        if ev == "line":
            _vues.add((fr.f_code.co_filename, fr.f_lineno))
        return locale

    if event == "call":
        _vues.add((f, frame.f_lineno))
    return locale


def pytest_configure(config):
    sys.settrace(_trace)
    threading.settrace(_trace)


def pytest_unconfigure(config):
    sys.settrace(None)
    sortie = Path(__file__).resolve().parent / "sortie_traceur.txt"
    lignes, total, manquantes = [], 0, []
    fichiers = {f for f, _ in _vues}
    for cible in CIBLES:
        f = next((x for x in fichiers if x.endswith(cible)), None)
        if f is None:
            lignes.append(f"{cible} : jamais exécuté")
            continue
        vues = {n for x, n in _vues if x == f}
        gardes = [i for i, t in enumerate(Path(f).read_text().splitlines(), start=1) if "raise GardeArret" in t]
        total += len(gardes)
        non = [i for i in gardes if i not in vues]
        manquantes += [f"{cible}:{i}" for i in non]
        lignes.append(f"{cible} : {len(gardes)} gardes, {len(gardes) - len(non)} exercées ; non exercées : {non}")
    lignes.append(f"total : {total} gardes ; non exercées : {manquantes}")
    sortie.write_text("\n".join(lignes) + "\n", encoding="utf-8")
