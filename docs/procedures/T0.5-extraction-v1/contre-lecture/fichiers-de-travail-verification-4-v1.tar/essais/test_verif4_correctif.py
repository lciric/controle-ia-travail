"""Vérification 4 : les corrections proposées (V-1 à V-4), éprouvées sur la copie corrigée `<W>/correctif/src` (hors du
dépôt). Lancement (depuis /home/user/controle-ia) :
    PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=<W>/correctif/src:tests .venv/bin/python -m pytest -q -p no:cacheprovider \
        -o pythonpath= --basetemp=<W>/pytest-tmp-corr tests/test_extraire_t05.py tests/test_extraction.py \
        <W>/essais/test_verif4_correctif.py
"""
import json
import os
import subprocess
from pathlib import Path

import pytest

import test_extraire_t05 as t5
from conftest import committer, depot  # noqa: F401
from controle_ia.environnements import extraire_t05 as et
from controle_ia.gardes import GardeArret

RUN = t5.RUN


def test_c0_le_code_execute_est_la_copie_corrigee():
    assert "correctif" in et.__file__


def _t1(depot, monkeypatch, tmp_path_factory):
    t5._petit(monkeypatch)
    ch = t5._depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    prep = et.preparer(depot, RUN, travail, 1, ch=ch)
    for info in prep["papiers"].values():
        t5._repondre(info["dossier"])
    return ch, travail, prep, sorted(prep["papiers"])


@pytest.mark.parametrize("objet", ["nom non utf-8", "dossier vide", "lien cassé", "tube nommé"])
def test_c1_c2_chemin_ajoute_sous_papier_anomalie_du_seul_papier(depot, tmp_path_factory, monkeypatch, objet):
    ch, travail, prep, ids = _t1(depot, monkeypatch, tmp_path_factory)
    papier = Path(prep["papiers"][ids[0]]["dossier"]) / "papier"
    cible = papier / "partie-99.md"
    if objet == "nom non utf-8":
        os.close(os.open(os.fsencode(str(papier)) + b"/notes-\xff.md", os.O_CREAT | os.O_WRONLY))
    elif objet == "dossier vide":
        cible.mkdir()
    elif objet == "lien cassé":
        cible.symlink_to(papier / "absent.md")
    else:
        os.mkfifo(cible)
    v = et.valider(depot, RUN, 1, t5._retours(prep), ch=ch)
    assert v["invalides"] == [ids[0]] and v["papiers"][ids[0]]["anomalies"] == ["entrees.modifiees"]
    attendu = "papier/notes-\\xff.md" if objet == "nom non utf-8" else "papier/partie-99.md"
    assert v["papiers"][ids[0]]["entrees_modifiees"] == [attendu]
    assert et.verifier(depot / "diag" / RUN / "validation-tentative-1.json")


def test_c3_cible_textuelle_avec_substitut_avis_illisible(depot, tmp_path_factory, monkeypatch):
    t5._petit(monkeypatch)
    ch = t5._depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    _, ech = t5._jusqu_a_l_echantillon(depot, travail, ch)
    e0, e1 = ech["echantillon"]
    cv = et.preparer_contre_verification(depot, RUN, travail, "echantillon", ch=ch)
    t5._juger(cv["papiers"][e0]["dossier"], t5._avec(t5.AVIS, targets=["C1\ud835", "C2", "C3", "F1"]))
    t5._juger(cv["papiers"][e1]["dossier"])
    lu = et.lire_contre_verification(depot, RUN, 1, t5._retours(cv), ch=ch)
    assert lu["illisibles"] == [e0] and lu["papiers"][e1]["lisible"]


def test_c4_autre_copie_du_depot_refusee_sans_rien_ecrire(depot, tmp_path_factory, monkeypatch):
    ch, travail, prep, ids = _t1(depot, monkeypatch, tmp_path_factory)
    et.valider(depot, RUN, 1, t5._retours(prep), ch=ch)
    committer(depot)
    autre = tmp_path_factory.mktemp("autre") / "arbre"
    subprocess.run(["git", "-C", str(depot), "worktree", "add", "-q", str(autre)], check=True, capture_output=True)
    with pytest.raises(GardeArret, match="hors de la racine du run"):
        et.echantillonner(autre, RUN, ch=ch)
    assert not (autre / "diag" / RUN / "arret-perte.json").exists()
    monkeypatch.chdir(depot)
    et.echantillonner(Path("."), RUN, ch=ch)                  # même racine, écrite autrement : acceptée


def test_c5_compagnon_illisible_est_une_perte(depot, tmp_path_factory, monkeypatch):
    ch, travail, prep, ids = _t1(depot, monkeypatch, tmp_path_factory)
    et.valider(depot, RUN, 1, t5._retours(prep), ch=ch)
    (depot / "donnees" / RUN / "sorties-tentative-1.tar.sha256").write_bytes(b"\xff\n")
    with pytest.raises(GardeArret, match="perte de données"):
        et.echantillonner(depot, RUN, ch=ch)
    assert json.loads((depot / "diag" / RUN / "arret-perte.json").read_text())["resultat"]["fichiers_en_cause"] == [
        f"donnees/{RUN}/sorties-tentative-1.tar"]
