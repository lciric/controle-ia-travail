"""Vérification 4 des corrections de la contre-lecture 3 (E-1, E-2, E-7, E-8, E-10, E-6) : scénarios dans des dépôts
jetables, construits avec les aides des tests du dépôt. Chaque test « constat_ » reproduit un comportement signalé au
rapport (il réussit tant que le comportement est présent).

Lancement (depuis /home/user/controle-ia) :
    PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src:tests .venv/bin/python -m pytest -q -p no:cacheprovider \
        --basetemp=<W>/pytest-tmp-scen <W>/essais/test_verif4_scenarios.py
"""
import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

import test_extraire_t05 as t5
from conftest import committer, depot  # noqa: F401  (fixture du dépôt jetable)
from controle_ia.environnements import extraire_t05 as et
from controle_ia.gardes import GardeArret

RUN = t5.RUN


def _sha_mtime(p: Path):
    return (et._sha(p.read_bytes()), p.stat().st_mtime_ns)


def _ronde_echantillon(depot, monkeypatch, tmp_path_factory, theorie=None):
    t5._petit(monkeypatch)
    ch = t5._depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    _, ech = t5._jusqu_a_l_echantillon(depot, travail, ch, theorie=theorie)
    cv = et.preparer_contre_verification(depot, RUN, travail, "echantillon", ch=ch)
    return ch, travail, ech, cv


# ----------------------------------------------------------------------------------------------- A. E-1, autres altérations

ALTERATIONS = ["h10 remplacé par un dossier", "h9 lien vers /dev/zero", "a-verifier supprimé",
               "cibles autre contenu valide", "fichier ajouté sous a-verifier", "dossier du papier remplacé par un fichier",
               "partie du papier modifiée", "invite supprimée", "boucle de liens", "lien vers une copie identique",
               "avis.json remplacé par un dossier"]


@pytest.mark.parametrize("alteration", ALTERATIONS)
def test_e1_autres_alterations(depot, tmp_path_factory, monkeypatch, alteration):
    ch, travail, ech, cv = _ronde_echantillon(depot, monkeypatch, tmp_path_factory)
    e0, e1 = ech["echantillon"]
    for pid in (e0, e1):
        t5._juger(cv["papiers"][pid]["dossier"])
    d = Path(cv["papiers"][e0]["dossier"])
    a = d / "a-verifier"
    if alteration == "h10 remplacé par un dossier":
        (a / "h10.json").unlink()
        (a / "h10.json").mkdir()
    elif alteration == "h9 lien vers /dev/zero":
        (a / "h9.json").unlink()
        (a / "h9.json").symlink_to("/dev/zero")
    elif alteration == "a-verifier supprimé":
        shutil.rmtree(a)
    elif alteration == "cibles autre contenu valide":
        c = json.loads((a / "cibles.json").read_text())
        c["controls"][0]["id"] = "Z9"
        (a / "cibles.json").write_text(json.dumps(c))
    elif alteration == "fichier ajouté sous a-verifier":
        (a / "notes.json").write_text("{}")
    elif alteration == "dossier du papier remplacé par un fichier":
        shutil.rmtree(d)
        d.write_text("x")
    elif alteration == "partie du papier modifiée":
        (d / "papier" / "partie-01.md").write_text("autre")
    elif alteration == "invite supprimée":
        (d / "invites" / "H9.txt").unlink()
    elif alteration == "boucle de liens":
        (a / "h9.json").unlink()
        (a / "h9.json").symlink_to(a / "h9.json")
    elif alteration == "lien vers une copie identique":
        copie = tmp_path_factory.mktemp("ailleurs") / "h9.json"
        shutil.copyfile(a / "h9.json", copie)
        (a / "h9.json").unlink()
        (a / "h9.json").symlink_to(copie)
    elif alteration == "avis.json remplacé par un dossier":
        (d / "avis.json").unlink()
        (d / "avis.json").mkdir()
    lu = et.lire_contre_verification(depot, RUN, 1, t5._retours(cv), ch=ch)   # aucune exception hors garde
    if alteration == "lien vers une copie identique":
        assert lu["papiers"][e0]["lisible"]                         # mêmes octets : entrée intacte
    elif alteration == "avis.json remplacé par un dossier":
        assert lu["papiers"][e0]["codes"] == ["fichier.absent"]     # sortie, pas entrée ; script d'accord
    else:
        assert lu["illisibles"] == [e0] and "entrees.modifiees" in lu["papiers"][e0]["codes"]
    assert lu["papiers"][e1]["lisible"]


# ----------------------------------------------------------------------------------------------- B. E-2, règle de perte

def test_e2_panne_entre_archive_et_resultat_puis_etape_refaite(depot, tmp_path_factory, monkeypatch):
    """Validation interrompue après l'archive et les détails, avant son résultat dans diag/ : l'étape se refait (écritures
    idempotentes) sans fausse perte ; de même pour la lecture d'une ronde."""
    t5._petit(monkeypatch)
    ch = t5._depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    prep = et.preparer(depot, RUN, travail, 1, ch=ch)
    for info in prep["papiers"].values():
        t5._repondre(info["dossier"])
    vrai = et._ecrire
    etat = {"fait": False}

    def panne(racine, run_id, nom, contenu):
        if nom in ("validation-tentative-1", "contre-verification-ronde-1") and not etat["fait"]:
            etat["fait"] = True
            raise KeyboardInterrupt("interruption simulée")
        return vrai(racine, run_id, nom, contenu)

    monkeypatch.setattr(et, "_ecrire", panne)
    with pytest.raises(KeyboardInterrupt):
        et.valider(depot, RUN, 1, t5._retours(prep), ch=ch)
    assert (depot / "donnees" / RUN / "sorties-tentative-1.tar.sha256").is_file()
    v = et.valider(depot, RUN, 1, t5._retours(prep), ch=ch)                      # refaite : pas de perte
    assert v["invalides"] == [] and not (depot / "diag" / RUN / "arret-perte.json").exists()
    ech = et.echantillonner(depot, RUN, ch=ch)
    cv = et.preparer_contre_verification(depot, RUN, travail, "echantillon", ch=ch)
    for pid in ech["echantillon"]:
        t5._juger(cv["papiers"][pid]["dossier"])
    etat["fait"] = False
    with pytest.raises(KeyboardInterrupt):
        et.lire_contre_verification(depot, RUN, 1, t5._retours(cv), ch=ch)
    lu = et.lire_contre_verification(depot, RUN, 1, t5._retours(cv), ch=ch)
    assert lu["illisibles"] == [] and not (depot / "diag" / RUN / "arret-perte.json").exists()
    et.exiger_rien_de_perdu(depot, RUN, "essai")


def test_e2_panne_entre_remplacement_et_sceau(depot, tmp_path_factory, monkeypatch):
    t5._petit(monkeypatch)
    ch = t5._depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    prep = et.preparer(depot, RUN, travail, 1, ch=ch)
    for info in prep["papiers"].values():
        t5._repondre(info["dossier"])
    vrai = et.sceller
    etat = {"fait": False}

    def panne(chemin):
        if str(chemin).endswith(".tar") and not etat["fait"]:
            etat["fait"] = True
            raise KeyboardInterrupt("interruption simulée")
        return vrai(chemin)

    monkeypatch.setattr(et, "sceller", panne)
    with pytest.raises(KeyboardInterrupt):
        et.valider(depot, RUN, 1, t5._retours(prep), ch=ch)
    assert (depot / "donnees" / RUN / "sorties-tentative-1.tar").is_file()
    assert not (depot / "donnees" / RUN / "sorties-tentative-1.tar.sha256").exists()
    et.valider(depot, RUN, 1, t5._retours(prep), ch=ch)
    et.exiger_rien_de_perdu(depot, RUN, "essai")


def test_e2_racine_relative_puis_absolue_et_retours_relatifs(depot, tmp_path_factory, monkeypatch):
    t5._petit(monkeypatch)
    ch = t5._depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    monkeypatch.chdir(depot)
    ici = Path(".")
    rel_travail = Path(os.path.relpath(travail, depot))                          # « ../travailN »
    prep = et.preparer(ici, RUN, rel_travail, 1, ch=ch)
    for info in prep["papiers"].values():
        t5._repondre(info["dossier"])
    retours = Path("donnees") / RUN / "retours-tentative-1.json"
    retours.parent.mkdir(parents=True)
    retours.write_text(json.dumps(t5._retours(prep)))
    assert et._retours(ici, RUN, str(retours)) == t5._retours(prep)              # chemin relatif accepté
    assert et._retours(ici, RUN, f"donnees/{RUN}/../{RUN}/retours-tentative-1.json") == t5._retours(prep)
    et.valider(ici, RUN, 1, et._retours(ici, RUN, str(retours)), ch=ch)
    ech = et.echantillonner(depot, RUN, ch=ch)                                   # racine absolue ensuite
    cv = et.preparer_contre_verification(ici, RUN, rel_travail, "echantillon", ch=ch)
    for pid in ech["echantillon"]:
        t5._juger(cv["papiers"][pid]["dossier"])
    et.lire_contre_verification(depot, RUN, 1, t5._retours(cv), ch=ch)
    et.exiger_rien_de_perdu(ici, RUN, "essai")
    et.exiger_rien_de_perdu(depot, RUN, "essai")
    sous = Path("donnees") / RUN / "retours"
    sous.mkdir()
    (sous / "r.json").write_text(retours.read_text())
    with pytest.raises(GardeArret, match="hors de donnees"):                       # sous-dossier : refusé
        et._retours(ici, RUN, str(sous / "r.json"))
    lien = Path("donnees") / RUN / "lien.json"
    lien.symlink_to(travail / "x.json")
    (travail / "x.json").write_text(retours.read_text())
    with pytest.raises(GardeArret, match="hors de donnees"):                       # lien vers l'extérieur : refusé
        et._retours(ici, RUN, str(lien))


def test_e2_rondes_paralleles_lues_dans_l_autre_ordre_et_dossier_lu_nettoye(depot, tmp_path_factory, monkeypatch):
    t5._petit(monkeypatch)
    ch = t5._depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    _, ech = t5._jusqu_a_l_echantillon(depot, travail, ch, theorie="2601.00002v1")
    shutil.rmtree(travail / "tentative-1")                    # dossier d'une tentative déjà lue, nettoyé : pas de perte
    cv = et.preparer_contre_verification(depot, RUN, travail, "echantillon", ch=ch)
    th = et.preparer_contre_verification(depot, RUN, travail, "theorie", ch=ch)
    for pid in ech["echantillon"]:
        t5._juger(cv["papiers"][pid]["dossier"])
    t5._juger(th["papiers"]["2601.00002v1"]["dossier"], t5._avec(t5.AVIS, theory_experiment_expected="theory_only"))
    et.lire_contre_verification(depot, RUN, 2, t5._retours(th), ch=ch)            # « theorie » d'abord
    et.lire_contre_verification(depot, RUN, 1, t5._retours(cv), ch=ch)
    assert not (depot / "diag" / RUN / "arret-perte.json").exists()


def test_constat_e2_autre_copie_du_depot_ecrit_un_arret_perte(depot, tmp_path_factory, monkeypatch):
    """Faux positif : une étape lancée depuis une autre copie du dépôt (clone, ou arbre de travail git) qui a runs/ et
    diag/ (suivis) mais pas donnees/ (ignoré) écrit un arrêt définitif, alors que les données du run sont intactes."""
    t5._petit(monkeypatch)
    ch = t5._depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    prep = et.preparer(depot, RUN, travail, 1, ch=ch)
    for info in prep["papiers"].values():
        t5._repondre(info["dossier"])
    et.valider(depot, RUN, 1, t5._retours(prep), ch=ch)
    committer(depot)                                          # « chaque résultat est committé et poussé »
    autre = tmp_path_factory.mktemp("autre") / "arbre"
    subprocess.run(["git", "-C", str(depot), "worktree", "add", "-q", str(autre)], check=True, capture_output=True)
    with pytest.raises(GardeArret, match="perte de données"):
        et.echantillonner(autre, RUN, ch=ch)
    arret = json.loads((autre / "diag" / RUN / "arret-perte.json").read_text())["resultat"]
    assert arret["fichiers_en_cause"] == [f"donnees/{RUN}/details-validation-tentative-1.json",
                                          f"donnees/{RUN}/sorties-tentative-1.tar"]
    et.exiger_rien_de_perdu(depot, RUN, "essai")              # le run, dans le dépôt d'origine, est intact
    # l'arrêt, committé dans l'autre arbre et fusionné, arrête définitivement le run d'origine
    subprocess.run(["git", "-C", str(autre), "add", "-A"], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(autre), "commit", "-q", "-m", "x"], check=True, capture_output=True)
    branche = subprocess.run(["git", "-C", str(autre), "rev-parse", "--abbrev-ref", "HEAD"], check=True,
                             capture_output=True, text=True).stdout.strip()
    subprocess.run(["git", "-C", str(depot), "merge", "-q", branche], check=True, capture_output=True)
    with pytest.raises(GardeArret, match="run arrêté"):
        et.echantillonner(depot, RUN, ch=ch)


def test_constat_e2_plusieurs_dossiers_de_papier_disparus_ne_sont_pas_une_perte(depot, tmp_path_factory, monkeypatch):
    """Texte, section 8 : « Un seul dossier de papier disparu reste une entrée modifiée » ; le code traite de même tout
    nombre de dossiers disparus (ici tous ceux d'une tentative 2, dossier de tentative gardé) : exclusions, pas de perte."""
    t5._petit(monkeypatch)
    ch = t5._depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    prep = et.preparer(depot, RUN, travail, 1, ch=ch)
    ids = sorted(prep["papiers"])
    court = t5._avec(t5.H9, research_questions="court")
    for pid, info in prep["papiers"].items():
        t5._repondre(info["dossier"], h9=court if pid in ids[:2] else t5.H9)
    et.valider(depot, RUN, 1, t5._retours(prep), ch=ch)
    p2 = et.preparer(depot, RUN, travail, 2, ids[:2], ch=ch)
    for pid in ids[:2]:
        t5._repondre(p2["papiers"][pid]["dossier"])           # réponses justes...
        shutil.rmtree(p2["papiers"][pid]["dossier"])          # ... perdues avec leurs dossiers
    v2 = et.valider(depot, RUN, 2, t5._retours(p2), ch=ch)
    assert v2["invalides"] == ids[:2] and not (depot / "diag" / RUN / "arret-perte.json").exists()
    assert all(v2["papiers"][p]["anomalies"] == ["fichier.absent"] * 3 + ["entrees.modifiees"] for p in ids[:2])
    et.echantillonner(depot, RUN, ch=ch)                      # le run continue : deux papiers exclus


def test_constat_e2_compagnon_illisible_exception_hors_garde(depot, tmp_path_factory, monkeypatch):
    """`exiger_rien_de_perdu` ne rattrape que GardeArret et OSError : une empreinte compagnon de donnees/ aux octets non
    UTF-8 lève UnicodeDecodeError (hors garde) à chaque étape, sans `arret-perte`."""
    t5._petit(monkeypatch)
    ch = t5._depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    prep = et.preparer(depot, RUN, travail, 1, ch=ch)
    for info in prep["papiers"].values():
        t5._repondre(info["dossier"])
    et.valider(depot, RUN, 1, t5._retours(prep), ch=ch)
    (depot / "donnees" / RUN / "sorties-tentative-1.tar.sha256").write_bytes(b"\xff\n")
    for _ in range(2):
        with pytest.raises(UnicodeDecodeError):
            et.echantillonner(depot, RUN, ch=ch)
    assert not (depot / "diag" / RUN / "arret-perte.json").exists()


# ----------------------------------------------------------------------------------------------- C. E-8, arrêts consignés

def test_e8_desaccord_a_la_validation_ecrit_avant_tout_et_ne_reecrit_rien(depot, tmp_path_factory, monkeypatch):
    t5._petit(monkeypatch)
    ch = t5._depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    prep = et.preparer(depot, RUN, travail, 1, ch=ch)
    ids = sorted(prep["papiers"])
    for info in prep["papiers"].values():
        t5._repondre(info["dossier"])
    vrai = et.codes_du_script
    monkeypatch.setattr(et, "codes_du_script",                 # désaccord sur le deuxième papier seulement
                        lambda script, d: vrai(script, d) + (["cibles.bornes"] if Path(d).name == ids[1] else []))
    with pytest.raises(GardeArret, match="désaccord en production"):
        et.valider(depot, RUN, 1, t5._retours(prep), ch=ch)
    arret = depot / "diag" / RUN / "arret-desaccord-script.json"
    assert et.verifier(arret) and json.loads(arret.read_text())["resultat"]["papier"] == ids[1]
    assert not (depot / "donnees" / RUN).exists()            # aucune autre écriture de l'étape
    assert sorted(p.name for p in (depot / "diag" / RUN).iterdir()) == [
        "arret-desaccord-script.json", "arret-desaccord-script.json.sha256", "preparation-tentative-1.json",
        "preparation-tentative-1.json.sha256"]
    avant = _sha_mtime(arret)
    monkeypatch.setattr(et, "codes_du_script", vrai)
    for etape in (lambda: et.valider(depot, RUN, 1, t5._retours(prep), ch=ch),
                  lambda: et.echantillonner(depot, RUN, ch=ch),
                  lambda: et.preparer(depot, RUN, travail, 2, [ids[0]], ch=ch)):
        with pytest.raises(GardeArret, match="run arrêté"):
            etape()
    assert _sha_mtime(arret) == avant and not (depot / "donnees" / RUN).exists()


def test_e8_desaccord_a_la_lecture_ecrit_avant_tout(depot, tmp_path_factory, monkeypatch):
    ch, travail, ech, cv = _ronde_echantillon(depot, monkeypatch, tmp_path_factory)
    e0, e1 = ech["echantillon"]
    for pid in (e0, e1):
        t5._juger(cv["papiers"][pid]["dossier"])
    second = sorted((e0, e1))[1]
    vrai = et.codes_du_script
    monkeypatch.setattr(et, "codes_du_script",
                        lambda script, d: vrai(script, d) + (["avis.fuite"] if Path(d).name == second else []))
    with pytest.raises(GardeArret, match="désaccord en production"):
        et.lire_contre_verification(depot, RUN, 1, t5._retours(cv), ch=ch)
    assert not (depot / "donnees" / RUN / "avis-ronde-1.tar").exists()
    assert not (depot / "donnees" / RUN / "details-contre-verification-ronde-1.json").exists()
    arret = json.loads((depot / "diag" / RUN / "arret-desaccord-script.json").read_text())["resultat"]
    assert arret["papier"] == second and arret["etape"] == "contre-verification-ronde-1"


def test_e8_delai_depasse_rien_d_ecrit_puis_etape_relancee(depot, tmp_path_factory, monkeypatch):
    t5._petit(monkeypatch)
    ch = t5._depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    prep = et.preparer(depot, RUN, travail, 1, ch=ch)
    for info in prep["papiers"].values():
        t5._repondre(info["dossier"])
    monkeypatch.setattr(et, "DELAI_SCRIPT_S", 0.001)
    with pytest.raises(GardeArret, match="délai de 0.001 s dépassé"):
        et.valider(depot, RUN, 1, t5._retours(prep), ch=ch)
    assert not (depot / "donnees" / RUN).exists()
    assert sorted(p.name for p in (depot / "diag" / RUN).iterdir()) == ["preparation-tentative-1.json",
                                                                         "preparation-tentative-1.json.sha256"]
    monkeypatch.setattr(et, "DELAI_SCRIPT_S", 600)
    assert et.valider(depot, RUN, 1, t5._retours(prep), ch=ch)["invalides"] == []


def test_constat_e8_second_arret_avis_refaits_non_consigne(depot, tmp_path_factory, monkeypatch):
    """Un seul `arret-avis-refaits` par run : le second papier (ou rôle) qui atteint la borne n'est pas consigné."""
    monkeypatch.setattr(et, "AVIS_MAX_PAR_ROLE", 2)
    ch, travail, ech, cv = _ronde_echantillon(depot, monkeypatch, tmp_path_factory)
    e0, e1 = ech["echantillon"]
    et.lire_contre_verification(depot, RUN, 1, t5._retours(cv), ch=ch)            # deux avis absents
    cv2 = et.preparer_contre_verification(depot, RUN, travail, "echantillon", [e0, e1], ch=ch)
    et.lire_contre_verification(depot, RUN, 2, t5._retours(cv2), ch=ch)           # encore absents
    with pytest.raises(GardeArret, match="préparés sans avis lisible"):
        et.preparer_contre_verification(depot, RUN, travail, "echantillon", [e0], ch=ch)
    arret = depot / "diag" / RUN / "arret-avis-refaits.json"
    assert json.loads(arret.read_text())["resultat"]["papier"] == e0
    with pytest.raises(GardeArret, match=f"{e1} : 2 avis"):
        et.preparer_contre_verification(depot, RUN, travail, "echantillon", [e1], ch=ch)
    assert json.loads(arret.read_text())["resultat"]["papier"] == e0             # e1 : rien de consigné
    assert [p.name for p in (depot / "diag" / RUN).glob("arret-*.json")] == ["arret-avis-refaits.json"]


def test_hors_perimetre_arret_d17_perdu_si_interruption_entre_resultat_et_arret(depot, tmp_path_factory, monkeypatch):
    """Arrêt D-17 écrit après le résultat de la validation : interrompue entre les deux, l'étape ne se refait pas (R12
    sur le résultat) et l'échantillon se tire malgré le seuil (même chose pour l'arrêt de seuil de la lecture)."""
    t5._petit(monkeypatch)
    monkeypatch.setattr(et, "SEUIL_EXCLUSIONS_VALIDATION", 1)
    ch = t5._depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    prep = et.preparer(depot, RUN, travail, 1, ch=ch)
    ids = sorted(prep["papiers"])
    court = t5._avec(t5.H9, research_questions="court")
    for pid, info in prep["papiers"].items():
        t5._repondre(info["dossier"], h9=court if pid in ids[:2] else t5.H9)
    et.valider(depot, RUN, 1, t5._retours(prep), ch=ch)
    p2 = et.preparer(depot, RUN, travail, 2, ids[:2], ch=ch)
    for pid in ids[:2]:
        t5._repondre(p2["papiers"][pid]["dossier"], h9=court)
    vrai = et._ecrire

    def panne(racine, run_id, nom, contenu):
        if nom == "arret-exclusions-validation":
            raise KeyboardInterrupt("interruption simulée")
        return vrai(racine, run_id, nom, contenu)

    monkeypatch.setattr(et, "_ecrire", panne)
    with pytest.raises(KeyboardInterrupt):
        et.valider(depot, RUN, 2, t5._retours(p2), ch=ch)
    monkeypatch.setattr(et, "_ecrire", vrai)
    with pytest.raises(GardeArret, match="R12"):
        et.valider(depot, RUN, 2, t5._retours(p2), ch=ch)
    ech = et.echantillonner(depot, RUN, ch=ch)                # tiré malgré 2 exclusions > seuil 1
    assert len(ech["echantillon"]) == 2


# ----------------------------------------------------------------------------------------------- D. E-7, dossiers sains

def test_e7_fichiers_hors_entrees_sans_effet(depot, tmp_path_factory, monkeypatch):
    t5._petit(monkeypatch)
    ch = t5._depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    prep = et.preparer(depot, RUN, travail, 1, ch=ch)
    for info in prep["papiers"].values():
        d = Path(info["dossier"])
        t5._repondre(d)
        (d / "sorties" / "notes.md").write_text("brouillon")
        (d / "sorties" / "h9.json.bak").write_text("{}")
        (d / "notes.txt").write_text("brouillon")
        (d / "__pycache__").mkdir()
        (d / "__pycache__" / "verifier_sortie.cpython-311.pyc").write_bytes(b"\0")
        (d / "papier" / "vide").mkdir()                       # dossier vide sous papier/ : sans effet
    v = et.valider(depot, RUN, 1, t5._retours(prep), ch=ch)
    assert v["invalides"] == [] and all(f["entrees_modifiees"] == [] for f in v["papiers"].values())
    ech = et.echantillonner(depot, RUN, ch=ch)
    cv = et.preparer_contre_verification(depot, RUN, travail, "echantillon", ch=ch)
    for pid in ech["echantillon"]:
        d = Path(cv["papiers"][pid]["dossier"])
        t5._juger(d)
        (d / "notes.txt").write_text("brouillon")
        (d / "avis.json.bak").write_text("{}")
    lu = et.lire_contre_verification(depot, RUN, 1, t5._retours(cv), ch=ch)
    assert lu["illisibles"] == []


@pytest.mark.parametrize("objet", ["dossier vide", "lien cassé", "tube nommé"])
def test_constat_e7_chemin_non_regulier_sous_papier_bloque_l_etape(depot, tmp_path_factory, monkeypatch, objet):
    """Un chemin non régulier nommé « partie-*.md » sous papier/ n'est pas compté parmi les fichiers ajoutés, mais le
    script le lit : panne « hors forme » (ou délai), rien d'écrit ; relancée, l'étape s'arrête à l'identique."""
    t5._petit(monkeypatch)
    ch = t5._depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    prep = et.preparer(depot, RUN, travail, 1, ch=ch)
    ids = sorted(prep["papiers"])
    for info in prep["papiers"].values():
        t5._repondre(info["dossier"])
    cible = Path(prep["papiers"][ids[0]]["dossier"]) / "papier" / "partie-99.md"
    if objet == "dossier vide":
        cible.mkdir()
    elif objet == "lien cassé":
        cible.symlink_to(cible.parent / "absent.md")
    else:
        os.mkfifo(cible)
        monkeypatch.setattr(et, "DELAI_SCRIPT_S", 2)
    for _ in range(2):
        with pytest.raises(GardeArret, match="hors forme|délai"):
            et.valider(depot, RUN, 1, t5._retours(prep), ch=ch)
    assert not (depot / "donnees" / RUN).exists()
    assert not list((depot / "diag" / RUN).glob("arret-*"))


def test_constat_e7_nom_non_utf8_sous_papier_laisse_un_resultat_vide(depot, tmp_path_factory, monkeypatch):
    """Faute nouvelle (E-7) : un fichier ajouté au nom non UTF-8 entre tel quel (substitut) dans `entrees_modifiees`,
    puis dans le résultat de diag/ ; son écriture échoue (UnicodeEncodeError, hors garde) et laisse un fichier vide,
    non scellé : toute étape suivante s'arrête sur lui."""
    t5._petit(monkeypatch)
    ch = t5._depot_de_test(depot)
    travail = tmp_path_factory.mktemp("travail")
    prep = et.preparer(depot, RUN, travail, 1, ch=ch)
    ids = sorted(prep["papiers"])
    for info in prep["papiers"].values():
        t5._repondre(info["dossier"])
    nom = os.fsencode(str(Path(prep["papiers"][ids[0]]["dossier"]) / "papier")) + b"/notes-\xff.md"
    os.close(os.open(nom, os.O_CREAT | os.O_WRONLY))
    with pytest.raises(UnicodeEncodeError):
        et.valider(depot, RUN, 1, t5._retours(prep), ch=ch)
    resultat = depot / "diag" / RUN / "validation-tentative-1.json"
    assert resultat.exists() and resultat.stat().st_size == 0 and not Path(str(resultat) + ".sha256").exists()
    for etape in (lambda: et.valider(depot, RUN, 1, t5._retours(prep), ch=ch),
                  lambda: et.echantillonner(depot, RUN, ch=ch)):
        with pytest.raises(GardeArret, match="compagnon"):
            etape()


def test_constat_e7_nom_non_utf8_sous_a_verifier(depot, tmp_path_factory, monkeypatch):
    ch, travail, ech, cv = _ronde_echantillon(depot, monkeypatch, tmp_path_factory)
    for pid in ech["echantillon"]:
        t5._juger(cv["papiers"][pid]["dossier"])
    d = Path(cv["papiers"][ech["echantillon"][0]]["dossier"])
    os.close(os.open(os.fsencode(str(d / "a-verifier")) + b"/x\xff.json", os.O_CREAT | os.O_WRONLY))
    with pytest.raises(UnicodeEncodeError):
        et.lire_contre_verification(depot, RUN, 1, t5._retours(cv), ch=ch)
    assert (depot / "diag" / RUN / "contre-verification-ronde-1.json").stat().st_size == 0


# ----------------------------------------------------------------------------------------------- E-6, message restant

def test_constat_e6_cible_textuelle_avec_substitut_bloque_la_lecture(depot, tmp_path_factory, monkeypatch):
    """Message `avis.cible` : `str(t)` brut quand la cible est une chaîne ; un substitut isolé y rend les détails non
    encodables : la lecture de toute la ronde s'arrête, à l'identique quand on la relance (archive déjà écrite)."""
    ch, travail, ech, cv = _ronde_echantillon(depot, monkeypatch, tmp_path_factory)
    e0, e1 = ech["echantillon"]
    t5._juger(cv["papiers"][e0]["dossier"], t5._avec(t5.AVIS, targets=["C1\ud835", "C2", "C3", "F1"]))
    t5._juger(cv["papiers"][e1]["dossier"])
    for _ in range(2):
        with pytest.raises(GardeArret, match="non encodable"):
            et.lire_contre_verification(depot, RUN, 1, t5._retours(cv), ch=ch)
    assert (depot / "donnees" / RUN / "avis-ronde-1.tar").exists()
    assert not (depot / "diag" / RUN / "contre-verification-ronde-1.json").exists()
    with pytest.raises(GardeArret, match="non lue"):
        et.preparer_contre_verification(depot, RUN, travail, "echantillon", [e0], ch=ch)
