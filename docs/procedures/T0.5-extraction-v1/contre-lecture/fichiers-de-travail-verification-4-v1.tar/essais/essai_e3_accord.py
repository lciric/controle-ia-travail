"""Vérification 4, question E : message de `texte.formule` (E-3) et accord des codes entre le module et les deux
scripts (copies empreintées, hors du dépôt).

Lancement (depuis /home/user/controle-ia) :
    PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src .venv/bin/python <W>/essais/essai_e3_accord.py
"""
import importlib.util
import random
import re
import sys
from pathlib import Path

from controle_ia.environnements import extraction as ex

W = Path(__file__).resolve().parents[1]


def charger(nom, fichier):
    spec = importlib.util.spec_from_file_location(nom, W / "copies" / fichier)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


vs = charger("vs", "verifier_sortie_copie.py")
va = charger("va", "verifier_avis_copie.py")


def codes(liste):
    return sorted(re.match(r"\[([a-z0-9_.]+)\]", a).group(1) for a in liste)


# 1. Cas réalistes : module et deux scripts, codes et messages
CAS = {
    "formule pandoc sur deux lignes, fidèle": "The loss is $a +\nb = c$ for all inputs",
    "même formule, saut remplacé par une espace": "The loss is $a + b = c$ for all inputs",
    "\\nu non doublé ($\\nu$ écrit avec une barre)": "the rate $\nu$ of the process",
    "\\nu doublé": "the rate $\\nu$ of the process",
    "\\nabla non doublé hors formule": "the gradient \nabla f",
    "deux montants, même paragraphe, fin de ligne et minuscule": "costs $100M\nand fine-tuning adds $5M",
    "deux montants, deux paragraphes": "costs $100M\n\nand fine-tuning adds $5M",
    "commande en \\n suivie d'une majuscule (faux négatif déclaré)": "so $a \nRightarrow b$",
    "\\(\\nu\\) sans $ (faux négatif déclaré)": "the rate \\(\nu\\) here",
    "substitut isolé": "symbol \ud835 here",
    "tabulation": "a\tb",
}
print("1. Cas réalistes (codes du module / script sortie / script avis) :")
ecarts = 0
for nom, s in CAS.items():
    m, a1, a2 = ex.anomalies_texte(s, "f"), vs.check_text(s, "f"), va.check_text(s, "f")
    ok = codes(m) == codes(a1) == codes(a2)
    ecarts += not ok
    print(f"   {nom:62s} {codes(m)} {'accord' if ok else 'ÉCART ' + str((codes(a1), codes(a2)))}")
print("   messages de texte.formule :")
m = ex.anomalies_texte(CAS["formule pandoc sur deux lignes, fidèle"], "cibles.json")[0]
s = vs.check_text(CAS["formule pandoc sur deux lignes, fidèle"], "cibles.json")[0]
print("   module :", m)
print("   script :", s)

# 2. Accord sur des chaînes tirées au hasard (graine fixe)
ALPHABET = ["$", "$$", "\\$", "\n", "\n\n", " \n", "a", "u", "abla", "A", "R", " ", "\\", "n", "\t", "\ud835", "é",
            "5M", "x", "\r", "\x0b"]
rng = random.Random(20261007)
N = 200_000
for k in range(N):
    s = "".join(rng.choice(ALPHABET) for _ in range(rng.randint(0, 14)))
    m = codes(ex.anomalies_texte(s, "f"))
    if not (m == codes(vs.check_text(s, "f")) == codes(va.check_text(s, "f"))):
        ecarts += 1
        if ecarts < 5:
            print("   ÉCART :", repr(s))
    if ex.position_formule_corrompue(s) != vs.broken_formula(s) or vs.broken_formula(s) != va.broken_formula(s):
        ecarts += 1
print(f"2. {N} chaînes au hasard : {ecarts} écart(s) de codes ou de position")
sys.exit(1 if ecarts else 0)
