#!/usr/bin/env python3
"""Contrôle des citations d'un rapport de lecture contre le texte extrait de la page indiquée.

Règle : une citation est acceptée seulement si elle figure, à l'identique, dans le texte de la
page indiquée, en tolérant UNIQUEMENT :
  - les blancs (espaces, tabulations, sauts de ligne, sauts de page), tous ignorés ;
  - les césures : un trait d'union suivi d'un saut de ligne dans le texte de la page peut être
    sauté (mot coupé) ou correspondre à un trait d'union de la citation (mot composé coupé).
Aucune autre tolérance : ni casse, ni apostrophes, ni guillemets, ni chiffres.

Textes de page : `pdftotext -layout` page par page (dossier texte/, rang de la page dans le
fichier) ; puis, si la citation chevauche des lignes dans une mise en page à deux colonnes,
`pdftotext -raw` de la même page (dossier texte-raw/), qui suit l'ordre des colonnes et garde
les césures. Le mode qui a trouvé la citation est consigné.

Convention du rapport : chaque citation anglaise est la dernière cellule d'une ligne de tableau,
entre guillemets droits "..." ; la page est une cellule « p. N » de la même ligne ; l'article est
donné par le dernier titre « ## » qui contient son identifiant arXiv.

Usage :
  python3 -I controle_citations.py --auto-test
  python3 -I controle_citations.py RAPPORT.md
"""
import os
import re
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODES = (("layout", "texte"), ("raw", "texte-raw"))
ARTICLES = ("2505.06311v2", "2603.12277v6", "2604.22888v1", "2605.18918v1")
MARQUE = "\x00"          # position d'une césure dans le texte normalisé de la page
LONGUEUR_MIN = 15        # caractères non blancs ; en dessous, la citation est refusée


class CitationRefusee(Exception):
    pass


def texte_page(article, page, dossier):
    if article not in ARTICLES:
        raise CitationRefusee(f"article inconnu : {article!r}")
    chemin = os.path.join(BASE, dossier, article, f"p{page:02d}.txt")
    if not os.path.isfile(chemin):
        raise CitationRefusee(f"page absente : {chemin}")
    with open(chemin, encoding="utf-8") as f:
        texte = f.read()
    if not texte.strip():
        raise CitationRefusee(f"page vide à l'extraction : {chemin}")
    return texte


def normaliser_page(texte):
    texte = re.sub(r"-[ \t]*\n\s*", MARQUE, texte)   # césure -> marque
    return re.sub(r"\s+", "", texte)                   # blancs ignorés


def motif(citation):
    compacte = re.sub(r"\s+", "", citation)
    if len(compacte) < LONGUEUR_MIN:
        raise CitationRefusee(f"citation trop courte ({len(compacte)} caractères non blancs)")
    morceaux = ["(?:-|\x00)" if c == "-" else re.escape(c) for c in compacte]
    return re.compile("\x00?".join(morceaux))


def controler(article, page, citation):
    """Renvoie le mode qui contient la citation ('layout' ou 'raw'), ou None si introuvable."""
    m = motif(citation)
    for nom, dossier in MODES:
        if m.search(normaliser_page(texte_page(article, page, dossier))):
            return nom
    return None


def auto_test():
    """Règle R5 : la garde est testée sur des cas justes et sur des artefacts, avant tout usage."""
    cas = [
        # (description, article, page, citation, attendu) ; attendu : 'OK', 'ECHEC' ou 'REFUS'
        ("juste, une colonne", "2603.12277v6", 15,
         "We provide full code for replication of all experimental results at https://role-confusion.github.io.", "OK"),
        ("juste, deux colonnes, plusieurs lignes", "2505.06311v2", 1,
         "We recognize that IPI attacks fundamentally rely on the presence of instructions embedded within external content", "OK"),
        ("altéré d'un mot", "2505.06311v2", 1,
         "We recognize that IPI attacks fundamentally rely on the presence of instructions embedded within internal content", "ECHEC"),
        ("altéré d'un chiffre", "2505.06311v2", 1,
         "InstructDetector achieves a detection accuracy of 99.61% in the in-domain setting", "ECHEC"),
        # Phrase propre à la page 1 (légende de la figure 1). Premier essai corrigé : la phrase
        # « We recognize that IPI attacks ... » figure en page 1 ET en page 2 (introduction).
        ("juste, sur sa page (légende figure 1)", "2505.06311v2", 1,
         "In a medical use case of the RAG system, the LLM is misled by the external instruction embedded in a retrieved document", "OK"),
        ("juste mais mauvaise page", "2505.06311v2", 2,
         "In a medical use case of the RAG system, the LLM is misled by the external instruction embedded in a retrieved document", "ECHEC"),
        ("césure tolérée (in-/creasingly)", "2505.06311v2", 1,
         "external sources is becoming increasingly common", "OK"),
        ("césure, mot altéré", "2505.06311v2", 1,
         "external sources is becoming increasingy common", "ECHEC"),
        ("mot composé coupé en fin de ligne (probe-/measured)", "2603.12277v6", 10,
         "between the intended role and the probe-measured role flag injection attempts", "OK"),
        ("blancs tolérés", "2505.06311v2", 1,
         "We   recognize\n that IPI\tattacks   fundamentally rely", "OK"),
        ("apostrophe droite au lieu de typographique", "2605.18918v1", 2,
         "classifies an LLM's prefill-stage hidden states", "ECHEC"),
        ("casse modifiée", "2605.18918v1", 2,
         "classifies an llm’s prefill-stage hidden states", "ECHEC"),
        ("citation trop courte", "2505.06311v2", 1, "LLMs", "REFUS"),
        ("page absente", "2505.06311v2", 99, "We recognize that IPI attacks fundamentally rely", "REFUS"),
        ("article inconnu", "9999.99999v1", 1, "We recognize that IPI attacks fundamentally rely", "REFUS"),
    ]
    echecs = 0
    for desc, art, page, cit, attendu in cas:
        try:
            mode = controler(art, page, cit)
            obtenu = "OK" if mode else "ECHEC"
            detail = mode or "-"
        except CitationRefusee as e:
            obtenu, detail = "REFUS", str(e)
        bon = obtenu == attendu
        echecs += not bon
        print(f"[{'conforme' if bon else 'NON CONFORME'}] {desc} : attendu {attendu}, obtenu {obtenu} ({detail})")
    print(f"Auto-test : {len(cas) - echecs}/{len(cas)} conformes.")
    return echecs == 0


def citations_du_rapport(chemin):
    article = None
    with open(chemin, encoding="utf-8") as f:
        for no, ligne in enumerate(f, 1):
            if ligne.startswith("## "):
                trouves = [a for a in ARTICLES if a in ligne]
                article = trouves[0] if len(trouves) == 1 else None
                continue
            if not ligne.lstrip().startswith("|"):
                continue
            cellules = [c.strip() for c in ligne.strip().strip("|").split("|")]
            if not cellules:
                continue
            derniere = cellules[-1]
            if not (len(derniere) > 2 and derniere.startswith('"') and derniere.endswith('"')):
                continue
            pages = [int(m.group(1)) for c in cellules if (m := re.fullmatch(r"p\.\s*(\d+)", c))]
            yield no, cellules[0], article, (pages[0] if len(pages) == 1 else None), derniere[1:-1]


def main(argv):
    if len(argv) == 2 and argv[1] == "--auto-test":
        return 0 if auto_test() else 1
    if len(argv) != 2:
        print(__doc__)
        return 2
    if not auto_test():
        print("Auto-test non conforme : contrôle interrompu (aucun repli silencieux).")
        return 1
    total = ok_layout = ok_raw = 0
    problemes = []
    for no, ident, article, page, cit in citations_du_rapport(argv[1]):
        total += 1
        try:
            if article is None:
                raise CitationRefusee("article non déterminé par le titre de section")
            if page is None:
                raise CitationRefusee("page absente ou ambiguë dans la ligne")
            mode = controler(article, page, cit)
        except CitationRefusee as e:
            problemes.append((no, ident, article, page, f"REFUS : {e}"))
            continue
        if mode == "layout":
            ok_layout += 1
        elif mode == "raw":
            ok_raw += 1
        else:
            problemes.append((no, ident, article, page, "ÉCHEC : introuvable sur la page indiquée"))
        print(f"ligne {no:4d} | {ident:6s} | {article} p. {page:2d} | {mode or 'ÉCHEC'}")
    print(f"\nCitations contrôlées : {total} ; trouvées en mode layout : {ok_layout} ; "
          f"trouvées seulement en mode raw : {ok_raw} ; échecs ou refus : {len(problemes)}")
    for p in problemes:
        print("  PROBLÈME", p)
    return 0 if not problemes and total > 0 else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
