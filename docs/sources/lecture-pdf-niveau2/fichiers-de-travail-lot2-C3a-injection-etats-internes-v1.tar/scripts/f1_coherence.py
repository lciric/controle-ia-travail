# Cohérence des F1 imprimés (RouteGuard 2604.22888v1, p. 8-9) avec la moyenne harmonique
# des précision et rappel imprimés. Valeurs recopiées du rendu image de la page 8 et du texte p. 9.
rows = [
 # (tableau, ligne, P, R, F1 imprimé)
 ("T1","SI Inj",0.6993,0.1515,0.2307),("T1","SI Wild",0.6251,0.1842,0.2814),("T1","SI MWild",0.6098,0.1539,0.2411),
 ("T1","SI MaliciousOrNot",0.6790,0.1527,0.2451),("T1","SI Probe",0.6318,0.1733,0.2698),("T1","SI MSkills",0.6759,0.2388,0.3289),
 ("T1","SI RG",0.8019,0.4218,0.7528),
 ("T1","MASB Inj",0.3612,0.4000,0.3699),("T1","MASB Scan",0.6000,0.3250,0.3873),("T1","MASB Wild",0.4143,0.4250,0.4146),
 ("T1","MASB MWild",0.5876,0.4000,0.4722),("T1","MASB MaliciousOrNot",0.5673,0.6000,0.5636),("T1","MASB Probe",0.3633,0.4500,0.3859),
 ("T1","MASB MSkills",0.7367,0.4000,0.4648),("T1","MASB RG",0.6393,0.5750,0.7867),("T1","MASW RG",0.6393,0.5750,0.7427),
 ("T2","SI-BL Inj",0.3421,0.2889,0.3133),("T2","SI-BL Wild",0.6100,0.6222,0.6142),("T2","SI-BL MaliciousOrNot",0.9333,0.1333,0.2267),
 ("T2","SI-BL Probe",0.7283,0.6978,0.6921),("T2","SI-BL MSkills",0.7889,0.7333,0.7556),("T2","SI-BL RG",0.6077,0.7156,0.7945),
 ("T2","SI-CH Inj",0.3871,0.2791,0.3243),("T2","SI-CH Scan",1.0000,0.0930,0.1702),("T2","SI-CH Wild",0.7204,0.3465,0.4599),
 ("T2","SI-CH MaliciousOrNot",0.4000,0.0326,0.0580),("T2","SI-CH Probe",0.7967,0.2744,0.4080),("T2","SI-CH MSkills",0.1857,0.0605,0.0765),
 ("T2","SI-CH RG",0.9334,0.6442,0.8834),
 ("T3","SI Attn",0.7997,0.4158,0.5467),("T3","SI Repr",0.6576,0.3370,0.4441),("T3","SI RG",0.8019,0.4218,0.7528),
 ("T3","SI-BL Attn",0.7117,0.4844,0.5742),("T3","SI-BL Repr",0.6369,0.6578,0.6457),("T3","SI-BL RG",0.6077,0.7156,0.7945),
 ("T3","SI-CH Attn",0.9329,0.6465,0.7637),("T3","SI-CH Repr",0.9456,0.6302,0.7557),("T3","SI-CH RG",0.9334,0.6442,0.8834),
 ("T4","MASB PArm",0.2400,0.2000,0.2120),("T4","MASB ASen",0.3676,0.2250,0.2717),("T4","MASB RENNERVATE",0.4776,0.5528,0.7017),
 ("T4","MASB RG",0.6393,0.5750,0.7867),
 ("T5","BIPIA Inj",0.3662,0.2407,0.2905),("T5","BIPIA Wild",0.6287,0.3685,0.4587),("T5","BIPIA MaliciousOrNot",0.6517,0.3370,0.3643),
 ("T5","BIPIA Probe",0.6522,0.2926,0.3954),("T5","BIPIA MSkills",0.6129,0.1759,0.2734),("T5","BIPIA PArm",0.6918,0.3611,0.3974),
 ("T5","BIPIA ASen",0.6255,0.2093,0.3112),("T5","BIPIA RENNERVATE",0.7016,0.8228,0.7815),("T5","BIPIA RG",0.7501,0.9944,0.8537),
]
print(f"{'tab':4}{'ligne':24}{'P':>8}{'R':>8}{'F1 impr':>9}{'2PR/(P+R)':>11}{'écart':>9}")
for t,l,p,r,f in rows:
    h = 2*p*r/(p+r) if p+r>0 else 0.0
    flag = "  <-- >0,02" if abs(f-h)>0.02 else ""
    print(f"{t:4}{l:24}{p:8.4f}{r:8.4f}{f:9.4f}{h:11.4f}{f-h:+9.4f}{flag}")

# Classement par banc selon le F1 imprimé et selon la moyenne harmonique recalculée
from collections import defaultdict
bancs = defaultdict(list)
for t,l,p,r,f in rows:
    if t in ("T1","T2"):
        banc, meth = l.split(" ",1)
        bancs[banc].append((meth, f, 2*p*r/(p+r) if p+r>0 else 0.0))
for banc, lst in bancs.items():
    imp = sorted(lst, key=lambda x:-x[1])[:3]; rec = sorted(lst, key=lambda x:-x[2])[:3]
    print(f"{banc:6s} F1 imprimé, 3 premiers : " + ", ".join(f"{m} {f:.4f}" for m,f,_ in imp))
    print(f"{'':6s} F1 recalculé, 3 premiers : " + ", ".join(f"{m} {h:.4f}" for m,_,h in rec))
