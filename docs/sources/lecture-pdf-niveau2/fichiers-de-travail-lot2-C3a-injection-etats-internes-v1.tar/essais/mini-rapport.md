# Essai
## 1. 2505.06311v2 — essai
| # | affirmation | verdict | page | citation exacte |
|---|---|---|---|---|
| 1.1 | juste | confirmé | p. 1 | "In this paper, we propose InstructDetector, a novel detection-based approach that leverages the behavioral states of LLMs to identify potential IPI attacks." |
| 1.2 | altérée | confirmé | p. 1 | "In this paper, we propose InstructDetector, a novel detection-based approach that leverages the internal states of LLMs to identify potential IPI attacks." |
| 1.3 | sans page | confirmé | — | "In this paper, we propose InstructDetector, a novel detection-based approach" |
## Synthèse
| 9.9 | hors article | confirmé | p. 1 | "In this paper, we propose InstructDetector, a novel detection-based approach" |
