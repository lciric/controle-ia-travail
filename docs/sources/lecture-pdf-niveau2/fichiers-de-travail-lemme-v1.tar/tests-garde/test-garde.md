Cas sain : [P90, p. 2] «In this context, power is not a meaningful measure of optimality (see Section 2.4).»
Cas sain avec cesure : [P91, p. 2] «A natural replacement of power is the GROW criterion, which stands for growth rate optimal in the worst case.»
Cas sain avec formule transcrite et barre echappee : [R90, p. 9] «The largest asymptotic order of n(γ) is reached when γD(q\|\|q0) = y + o(1) (γ → ∞), and it corresponds to covertness, i.e., n(γ) = Θ(γ).»
Cas sain avec racine : [R91, p. 11] «Then, following Proposition 3.4, when γD(q\|\|qγ) = Θ(1), which here implies μ = Θ(1/√γ), the total damage is maximized and satisfies d(γ) = Θ(√γ).»
Cas sain avec formule entre crochets : [R92, p. 11] «Proposition 4.2 shows that an attacker is covert if either (i) ⟦½γ(μ² + ½σ⁴)⟧ converges to a positive constant as γ → ∞, or if (ii) |μ|√γ ∼γ 0 and σ²√γ ∼γ 0. Hence, covertness will occur, in particular, when (μ, σ²) = (γ^{−δ1}, γ^{−δ2}) with ⟦δ1 ≥ ½ and δ2 ≥ ½⟧.»
Artefact mot altere : [P92, p. 2] «In this context, power is a meaningful measure of optimality (see Section 2.4).»
Artefact mauvaise page : [P93, p. 3] «In this context, power is not a meaningful measure of optimality (see Section 2.4).»
Artefact chiffre altere : [R93, p. 1] «ADD = Θ(γ), whereas in the classical setting, ADD grows only as O(γ).»
Artefact formule trop longue (ecart hors borne) : [R94, p. 11] «Proposition 4.2 shows that an attacker is covert if either (i) ⟦x⟧ converges to a positive constant as γ → ∞, or if (ii) |μ|√γ ∼γ 0 and σ²√γ ∼γ 0. Hence, covertness will occur, in particular, when (μ, σ²) = (γ^{−δ1}, γ^{−δ2}) with ⟦δ1⟧.»
Artefact identifiant en conflit : [P90, p. 2] «In this context, power is not a meaningful measure.»
Artefact phrase masquee par une formule : [R95, p. 11] «Proposition 4.2 shows that an attacker is covert if either ⟦x⟧ Hence, covertness will occur»
Artefact negation masquee par une formule : [P94, p. 2] «In this context, power is ⟦x⟧ a meaningful measure of optimality (see Section 2.4).»
