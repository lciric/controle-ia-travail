#!/usr/bin/env python3
"""Controle des citations d'un rapport de lecture contre l'extraction page par page des PDF.

Usage :
    python3 -I verifier_citations.py RAPPORT.md DOSSIER_EXTRAITS [SORTIE.txt]

Forme d'une citation dans le rapport :
    [P07, p. 6] «texte anglais mot pour mot»
    [R12, p. 8-9] «...»            (citation a cheval sur deux pages)
Prefixe P = arXiv 2208.07610v2 ; prefixe R = arXiv 2601.20022v2.
La page citee est le rang de la page dans le fichier PDF ; l'extraction attendue est
DOSSIER_EXTRAITS/<article>/page-NN.txt (pdftotext -layout, une page par fichier).

Conventions a l'interieur d'une citation :
    ⟦...⟧  formule transcrite (non comparee lettre a lettre ; ecart autorise : 2 x longueur + 25 caracteres ;
           l'ecart est affiche, et il echoue s'il contient un mot de 3 lettres ou plus absent de la transcription)
    […]    coupure volontaire (ecart borne autorise, 3000 caracteres au plus)
    \\|     barre verticale echappee pour les tableaux Markdown

Tolerances de comparaison (appliquees aux deux cotes) :
    normalisation Unicode NFKC ; tirets et guillemets unifies ; trait d'union conditionnel supprime ;
    cesure de fin de ligne toleree (le trait d'union de fin de ligne peut etre absent de la citation) ;
    espaces ignores ; caracteres ^ { } _ ignores (exposants et indices transcrits) ;
    signe radical (racine carree) ignore, car l'extraction le deplace sur une autre ligne.
Toute citation non retrouvee sur la page citee est cherchee sur les autres pages (erreur de page signalee).
Code de sortie : 0 si toutes les citations sont retrouvees sur la page citee, 1 sinon.
"""
import hashlib
import pathlib
import re
import sys
import unicodedata

ARTICLES = {"P": "2208.07610v2", "R": "2601.20022v2"}
TIRETS = "‐‑‒–—―−﹣－"
GUILLEMETS = "‘’‚‛“”„‟\"'"
MARQUE = "\x00"  # tient lieu d'un trait d'union de fin de ligne
ECART_COUPURE = 3000

MOTIF_CITATION = re.compile(
    r"\[([PR])(\d{2,3}), p\. (\d+)(?:[-–](\d+))?\]\s*«(.*?)»", re.S
)
MOTIF_SEGMENT = re.compile(r"(⟦.*?⟧|\[…\]|\[\.\.\.\])")


def commun(s: str) -> str:
    s = unicodedata.normalize("NFKC", s)
    s = s.replace("­", "")
    for c in TIRETS:
        s = s.replace(c, "-")
    for c in GUILLEMETS:
        s = s.replace(c, "'")
    return s


def normaliser_page(texte: str) -> str:
    s = commun(texte)
    s = re.sub(r"-[ \t]*\n[ \t\f]*", MARQUE, s)
    s = re.sub(r"\s+", "", s)
    s = re.sub(r"[\^{}_√]", "", s)
    return s


def normaliser_citation(texte: str) -> str:
    s = commun(texte.replace("\\|", "|"))
    s = re.sub(r"\s+", "", s)
    s = re.sub(r"[\^{}_√]", "", s)
    return s


def motif_fragment(fragment: str) -> re.Pattern:
    morceaux = [("[-" + MARQUE + "]") if c == "-" else re.escape(c) for c in fragment]
    return re.compile((MARQUE + "?").join(morceaux))


def decouper(citation: str):
    """Renvoie la liste des fragments litteraux et la liste des ecarts autorises entre eux."""
    c = citation.strip()
    for debut in ("…", "..."):
        if c.startswith(debut):
            c = c[len(debut):]
    for fin in ("…", "..."):
        if c.endswith(fin):
            c = c[: -len(fin)]
    fragments, ecarts, ecart_courant, transcription, coupure = [], [], 0, "", False
    for morceau in MOTIF_SEGMENT.split(c):
        if not morceau:
            continue
        if morceau.startswith("⟦"):
            t = normaliser_citation(morceau[1:-1])
            ecart_courant += 2 * len(t) + 25
            transcription += t
        elif morceau in ("[…]", "[...]"):
            ecart_courant += ECART_COUPURE
            coupure = True
        else:
            n = normaliser_citation(morceau)
            if not n:
                continue
            if fragments:
                ecarts.append((ecart_courant, transcription, coupure))
            fragments.append(n)
            ecart_courant, transcription, coupure = 0, "", False
    return fragments, ecarts


def mots_masques(ecart_texte: str, transcription: str) -> list:
    """Mots (3 lettres latines ou plus) presents dans l'ecart mais absents de la transcription."""
    return [w for w in re.findall(r"[A-Za-z]{3,}", ecart_texte) if w not in transcription]


def chercher(fragments, ecarts, texte: str):
    """Renvoie (trouve, ecarts_textes, alertes)."""
    if not fragments:
        return False, [], []
    motifs = [motif_fragment(f) for f in fragments]
    meilleur = None
    for m0 in motifs[0].finditer(texte):
        fin, ok, vus, alertes = m0.end(), True, [], []
        for motif, (borne, transcription, coupure) in zip(motifs[1:], ecarts):
            m = motif.search(texte, fin)
            if m is None or m.start() - fin > borne:
                ok = False
                break
            entre = texte[fin:m.start()].replace(MARQUE, "-")
            if not coupure:
                vus.append(entre)
                alertes += mots_masques(entre, transcription)
            fin = m.end()
        if ok and not alertes:
            return True, vus, []
        if ok and meilleur is None:
            meilleur = (vus, alertes)
    if meilleur:
        return False, meilleur[0], meilleur[1]
    return False, [], []


def charger_pages(dossier: pathlib.Path, article: str) -> dict:
    pages = {}
    for f in sorted((dossier / article).glob("page-*.txt")):
        num = int(f.stem.split("-")[1])
        pages[num] = f.read_text(encoding="utf-8")
    return pages


def sha256(chemin: pathlib.Path) -> str:
    return hashlib.sha256(chemin.read_bytes()).hexdigest()


def main() -> int:
    if len(sys.argv) < 3:
        print(__doc__)
        return 2
    rapport = pathlib.Path(sys.argv[1])
    dossier = pathlib.Path(sys.argv[2])
    sortie = pathlib.Path(sys.argv[3]) if len(sys.argv) > 3 else None

    texte_rapport = rapport.read_text(encoding="utf-8")
    pages = {code: charger_pages(dossier, art) for code, art in ARTICLES.items()}
    normalisees = {code: {n: normaliser_page(t) for n, t in p.items()} for code, p in pages.items()}

    vues, conflits, lignes = {}, [], []
    for m in MOTIF_CITATION.finditer(texte_rapport):
        code, num, p1, p2, citation = m.group(1), m.group(2), int(m.group(3)), m.group(4), m.group(5)
        ident = f"{code}{num}"
        cle = (p1, int(p2) if p2 else None, citation.strip())
        if ident in vues:
            if vues[ident] != cle:
                conflits.append(ident)
            continue
        vues[ident] = cle

    nb_ok, nb_echec = 0, 0
    for ident in sorted(vues, key=lambda x: (x[0], int(x[1:]))):
        p1, p2, citation = vues[ident]
        code = ident[0]
        fragments, ecarts = decouper(citation)
        plage = list(range(p1, (p2 or p1) + 1))
        texte = "".join(normalisees[code].get(n, "") for n in plage)
        trouve, vus, alertes = chercher(fragments, ecarts, texte)
        if trouve:
            statut = "OK"
            nb_ok += 1
        else:
            nb_echec += 1
            if alertes:
                statut = f"ECHEC (mot masque par une formule transcrite : {alertes})"
            else:
                ailleurs = [n for n, t in normalisees[code].items() if n not in plage and chercher(fragments, ecarts, t)[0]]
                statut = f"ECHEC (retrouvee page {ailleurs})" if ailleurs else "ECHEC (introuvable)"
        page_txt = f"{p1}" + (f"-{p2}" if p2 else "")
        extrait = re.sub(r"\s+", " ", citation)[:90]
        lignes.append(f"{ident}\t{ARTICLES[code]}\tp. {page_txt}\t{statut}\t{len(fragments)} fragment(s)\t{extrait}")
        for e in vus:
            lignes.append(f"\t\ttexte extrait remplace par une formule transcrite : [{e[:80]}]")

    # Segments entre guillemets francais sans etiquette (pour revue manuelle : citations du programme, etc.)
    etiquetes = {m.start(5) for m in MOTIF_CITATION.finditer(texte_rapport)}
    non_etiquetes = []
    for m in re.finditer(r"«(.*?)»", texte_rapport, re.S):
        if m.start(1) not in etiquetes:
            non_etiquetes.append(re.sub(r"\s+", " ", m.group(1))[:100])

    entete = [
        "Controle des citations — rapport : " + str(rapport),
        "Empreinte sha256 du script : " + sha256(pathlib.Path(__file__)),
        "Extractions : " + ", ".join(f"{a} ({len(pages[c])} pages)" for c, a in ARTICLES.items()),
        f"Citations distinctes controlees : {len(vues)} ; retrouvees sur la page citee : {nb_ok} ; echecs : {nb_echec}",
        f"Etiquettes en conflit (meme identifiant, textes differents) : {conflits if conflits else 'aucune'}",
        "",
        "identifiant\tarticle\tpage\tstatut\tfragments\tdebut de la citation",
    ]
    pied = ["", f"Segments «…» sans etiquette (non controles, a revoir a la main) : {len(non_etiquetes)}"]
    pied += ["  - " + s for s in non_etiquetes]
    rendu = "\n".join(entete + lignes + pied) + "\n"
    print(rendu)
    if sortie:
        sortie.write_text(rendu, encoding="utf-8")
    return 0 if (nb_echec == 0 and not conflits) else 1


if __name__ == "__main__":
    sys.exit(main())
