"""Chiffres de nature « calcul » du rapport ; entrees recopiees des citations controlees
(identifiants entre crochets). Aucun fichier extrait n'est lu ici."""

print('--- 2606.17478 : gains relatifs annonces (A06) a partir de la table 3 (A21-A23)')
sw, bb, sonde = 0.916, 0.821, 0.733
print('gain relatif sur boite noire : %.4f ; sur sonde : %.4f' % (sw / bb - 1, sw / sonde - 1))

print('--- moyennes de la ligne Mean (table 3) recalculees depuis les lignes par cible (A15-A23)')
cibles = {'sonde': [(0.705, 0.006, 0.040), (0.762, 0.752, 0.908)],
          'boite noire': [(0.809, 0.307, 0.547), (0.833, 0.697, 0.697)],
          'StateWitness': [(0.920, 0.293, 0.681), (0.911, 0.358, 0.576)]}
for nom, (g, m) in cibles.items():
    print('%-12s AUROC %.4f  R@1 %.4f  R@5 %.4f' % (nom, (g[0] + m[0]) / 2, (g[1] + m[1]) / 2, (g[2] + m[2]) / 2))

print('--- table 14 (A56-A69) : taux de vrais negatifs sur exemples honnetes du jeu,')
print('    TVN = 2*BAcc - R@1, si BAcc = (rappel + TVN)/2 au seuil Alpaca de 1 %')
t14 = {
 'GPT-OSS': {
  'Instr': [(0.501, 0.001), (0.909, 0.823), (0.942, 0.900)],
  'Roleplay': [(0.519, 0.037), (0.495, 0.053), (0.697, 0.457)],
  'Sandbag': [(0.493, 0.000), (0.604, 0.214), (0.560, 0.119)],
  'MASK': [(0.503, 0.006), (0.532, 0.214), (0.593, 0.191)],
  'Insider': [(0.500, 0.000), (0.611, 0.257), (0.688, 0.375)],
  'Agentic': [(0.500, 0.000), (0.776, 0.571), (0.500, 0.000)],
  'InstEval': [(0.500, 0.000), (0.508, 0.018), (0.505, 0.011)]},
 'Gemma': {
  'Instr': [(0.748, 1.000), (0.990, 0.988), (0.841, 0.699)],
  'Roleplay': [(0.569, 0.992), (0.915, 1.000), (0.771, 0.591)],
  'Sandbag': [(0.565, 0.991), (0.990, 0.984), (0.660, 0.320)],
  'MASK': [(0.533, 0.815), (0.641, 0.560), (0.605, 0.238)],
  'Insider': [(0.500, 1.000), (1.000, 1.000), (0.740, 0.480)],
  'Agentic': [(0.525, 0.218), (0.603, 0.224), (0.503, 0.006)],
  'InstEval': [(0.553, 0.252), (0.557, 0.124), (0.576, 0.172)]}}
noms = ['sonde', 'boite noire', 'StateWitness']
hors_bornes = 0
for cible, jeux in t14.items():
    for jeu, triplets in jeux.items():
        cells = []
        for nom, (bacc, r1) in zip(noms, triplets):
            tvn = 2 * bacc - r1
            if tvn < -0.005 or tvn > 1.005:
                hors_bornes += 1
            cells.append('%s TVN=%.3f (faux positifs honnetes=%.3f)' % (nom, tvn, 1 - tvn))
        print('%-8s %-9s %s' % (cible, jeu, ' | '.join(cells)))
print('controle de coherence : %d valeur(s) de TVN hors de [0 ; 1] a l\'arrondi pres' % hors_bornes)

print('--- 2412.01784 : table 1 (B18-B22 et lecture de la table), bornes des rapports')
phi = {
 'llama-8b AI2': (1.030, 1.974), 'llama-8b WMDP': (1.074, 1.178), 'llama-8b MMLU': (1.055, 1.450),
 'llama-8b GSM8k': (1.143, 1.797), 'llama-8b BoolQ': (1.05, 1.21),
 'mistral-7b AI2': (1.067, 2.442), 'mistral-7b WMDP': (1.045, 2.481), 'mistral-7b MMLU': (1.055, 1.521),
 'mistral-7b GSM8k': (1.000, 1.857),
 'phi-3-mini AI2': (1.010, 1.387), 'phi-3-mini WMDP': (1.049, 1.758), 'phi-3-mini MMLU': (1.000, 1.270),
 'phi-3-small AI2': (1.020, 1.535), 'phi-3-small WMDP': (1.034, 1.198), 'phi-3-small MMLU': (1.045, 1.510),
 'phi-3-medium AI2': (1.028, 10.286), 'phi-3-medium WMDP': (1.049, 2.581), 'phi-3-medium MMLU': (1.042, 2.250),
 'deepseek-7b mdp GSM8k': (1.000, 5.000), 'mistral-7b mdp WMDP': (1.01, 3.12),
 'llama-70b AI2': (1.000, 2.737), 'llama-70b WMDP': (1.047, 2.039), 'llama-70b MMLU': (1.026, 1.564),
 'mistral-large GSM8k': (1.075, 1.515)}
std = [v[0] for v in phi.values()]
sbg = [v[1] for v in phi.values()]
print('lignes : %d ; phi_std min %.3f max %.3f ; phi_sbg min %.3f max %.3f' % (len(phi), min(std), max(std), min(sbg), max(sbg)))
ecarts = sorted((v[1] / v[0], k) for k, v in phi.items())
print('plus petit rapport phi_sbg/phi_std : %.3f (%s) ; plus grand : %.3f (%s)' % (ecarts[0][0], ecarts[0][1], ecarts[-1][0], ecarts[-1][1]))
sur_instruction = [k for k in phi if not ('mdp' in k or 'llama-70b' in k or 'mistral-large' in k)]
print('lignes « sur instruction » au-dessus du trait (BoolQ compris) : %d' % len(sur_instruction))
print('Mistral Large : 1/0.666 = %.3f (rapport imprime 1.515)' % (1 / 0.666))
print('cout : 3*775 + 11*25 = %d dollars' % (3 * 775 + 11 * 25))

print('--- 2607.13087 : note 19 (C45)')
print('P(au moins une tentative surveillee) a 25 %% : 15 tentatives %.5f ; 16 tentatives %.5f' % (1 - 0.75 ** 15, 1 - 0.75 ** 16))
