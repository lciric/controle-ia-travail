"""Concordance rapport / citations controlees.

Usage : python3 -I verifier_rapport.py RAPPORT.md CITATIONS.json

Verifie que chaque occurrence « [ID] « citation » » du rapport reproduit, aux blancs
pres (et sans les accents graves de mise en forme), la citation controlee de meme
identifiant ; et que tout identifiant mentionne (A12, B07, C33...) existe.
Autotest : une citation juste doit passer, une citation alteree doit echouer.
"""
import json
import re
import sys

MOTIF = re.compile(r'\[([ABC]\d{2})\] « (.+?) »')
IDENT = re.compile(r'\b([ABC]\d{2})\b')


def norm(s):
    s = s.strip()
    if len(s) >= 2 and s[0] == '`' and s[-1] == '`':
        s = s[1:-1]
    return ''.join(s.split())


def verifier(texte, ref):
    occurrences = MOTIF.findall(texte)
    ecarts = [(i, q) for i, q in occurrences if i not in ref or norm(q) != norm(ref[i])]
    inconnus = sorted({i for i in IDENT.findall(texte) if i not in ref})
    return occurrences, ecarts, inconnus


def main():
    rapport, citations = sys.argv[1:3]
    with open(citations, encoding='utf-8') as f:
        ref = {e['id']: e['quote'] for e in json.load(f)}
    # autotest
    juste = '[A22] « Best black-box 0.821 0.502 0.622 »'
    altere = '[A22] « Best black-box 0.821 0.502 0.632 »'
    if verifier(juste, ref)[1] or not verifier(altere, ref)[1]:
        sys.exit('ARRET : autotest de concordance non conforme')
    print('autotest de concordance : conforme (juste accepte, altere rejete)')
    with open(rapport, encoding='utf-8') as f:
        texte = f.read()
    occurrences, ecarts, inconnus = verifier(texte, ref)
    for i, q in ecarts:
        print('ECART %s : %s' % (i, q[:90]))
    print('BILAN : %d citations reproduites (%d identifiants distincts) ; %d ecart(s) ; '
          'identifiants inconnus : %s' % (len(occurrences), len({i for i, _ in occurrences}),
                                          len(ecarts), ', '.join(inconnus) or 'aucun'))
    sys.exit(1 if (ecarts or inconnus) else 0)


if __name__ == '__main__':
    main()
