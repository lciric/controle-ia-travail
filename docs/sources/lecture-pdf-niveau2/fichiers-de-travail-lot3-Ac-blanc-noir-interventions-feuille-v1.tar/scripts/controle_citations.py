"""Controle des citations contre le texte extrait page par page (pdftotext).

Usage : python3 -I controle_citations.py DOSSIER_TEXTES AUTOTESTS.json CITATIONS.json SORTIE.tsv

Tolerance admise : blancs et cesures seulement.
  niveau 1 : texte en mise en page (pNN.txt, pdftotext -layout) ; blancs ignores ;
             trait d'union suivi d'un retour a la ligne tolere entre deux caracteres.
  niveau 2 : meme regle sur le texte en mode lecture (rawNN.txt, pdftotext sans -layout),
             utile quand une phrase traverse deux colonnes.
  niveau 3 : texte en mode lecture, trait d'union de la citation rendu facultatif
             (pdftotext retire en mode lecture les traits d'union de fin de ligne,
             cesures comme traits d'union reels coupes en fin de ligne).
Une citation peut contenir le separateur " […] " : chaque fragment est controle
separement sur la meme page.
Les autotests (cas justes et cas alteres, regle R5) passent d'abord ; tout ecart
a l'attendu arrete le controle (aucun repli silencieux).
"""
import json
import os
import re
import sys

SEP = r'(?:\s|-[ \t]*\n)*'
SEPARATEUR_FRAGMENTS = '[…]'


def motif(citation, trait_facultatif):
    morceaux = []
    for c in citation:
        if c.isspace():
            continue
        if trait_facultatif and c == '-':
            morceaux.append('-?')
        else:
            morceaux.append(re.escape(c))
    if not morceaux:
        raise ValueError('citation vide')
    return SEP.join(morceaux)


def lire(chemin):
    with open(chemin, encoding='utf-8', errors='strict') as f:
        return f.read()


def textes_page(dossier, pdf, page):
    base = os.path.join(dossier, pdf)
    mise_en_page = os.path.join(base, 'p%02d.txt' % page)
    lecture = os.path.join(base, 'raw%02d.txt' % page)
    for chemin in (mise_en_page, lecture):
        if not os.path.isfile(chemin):
            raise FileNotFoundError(chemin)
    return lire(mise_en_page), lire(lecture)


def chercher_fragment(fragment, mise_en_page, lecture):
    if re.search(motif(fragment, False), mise_en_page):
        return 1
    if re.search(motif(fragment, False), lecture):
        return 2
    if re.search(motif(fragment, True), lecture):
        return 3
    return 0


def controler(dossier, entree):
    mise_en_page, lecture = textes_page(dossier, entree['pdf'], int(entree['page']))
    fragments = [f.strip() for f in entree['quote'].split(SEPARATEUR_FRAGMENTS)]
    niveaux = [chercher_fragment(f, mise_en_page, lecture) for f in fragments if f]
    if not niveaux or 0 in niveaux:
        return 0
    return max(niveaux)


def main():
    if len(sys.argv) != 5:
        sys.exit(__doc__)
    dossier, autotests, citations, sortie = sys.argv[1:]
    tests = json.loads(lire(autotests))
    echecs_tests = 0
    for t in tests:
        niveau = controler(dossier, t)
        trouve = niveau > 0
        conforme = (trouve == t['attendu_trouve'])
        if conforme and trouve and 'attendu_niveau' in t:
            conforme = (niveau == t['attendu_niveau'])
        print('AUTOTEST %s : niveau=%d attendu_trouve=%s attendu_niveau=%s -> %s'
              % (t['id'], niveau, t['attendu_trouve'], t.get('attendu_niveau', '-'),
                 'conforme' if conforme else 'NON CONFORME'))
        if not conforme:
            echecs_tests += 1
    if echecs_tests:
        sys.exit('ARRET : %d autotest(s) non conforme(s) ; controle non fait.' % echecs_tests)
    entrees = json.loads(lire(citations))
    ids = [e['id'] for e in entrees]
    if len(ids) != len(set(ids)):
        sys.exit('ARRET : identifiants de citation en double.')
    n_ok = 0
    n_echec = 0
    par_niveau = {1: 0, 2: 0, 3: 0}
    lignes = ['id\tpdf\tpage\tresultat\tniveau\tcitation']
    for e in entrees:
        niveau = controler(dossier, e)
        if niveau:
            n_ok += 1
            par_niveau[niveau] += 1
            resultat = 'OK'
        else:
            n_echec += 1
            resultat = 'ECHEC'
            print('ECHEC %s (%s p.%s) : %s' % (e['id'], e['pdf'], e['page'], e['quote'][:90]))
        lignes.append('%s\t%s\t%s\t%s\t%d\t%s' % (e['id'], e['pdf'], e['page'], resultat,
                                                  niveau, e['quote'].replace('\t', ' ')))
    with open(sortie, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lignes) + '\n')
    print('BILAN : %d citations controlees ; %d trouvees ; %d echecs ; '
          'niveau 1 : %d ; niveau 2 : %d ; niveau 3 : %d'
          % (len(entrees), n_ok, n_echec, par_niveau[1], par_niveau[2], par_niveau[3]))
    sys.exit(1 if n_echec else 0)


if __name__ == '__main__':
    main()
