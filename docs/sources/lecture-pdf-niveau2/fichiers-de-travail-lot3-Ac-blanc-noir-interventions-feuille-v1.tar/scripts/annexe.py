"""Produit l'annexe des citations controlees a partir du fichier de resultats.

Usage : python3 -I annexe.py controle-citations.tsv SORTIE.md
"""
import sys

TITRES = {'2606.17478v1': '2606.17478v1', '2412.01784v3': '2412.01784v3', '2607.13087v1': '2607.13087v1'}


def main():
    entree, sortie = sys.argv[1:3]
    with open(entree, encoding='utf-8') as f:
        lignes = f.read().splitlines()
    entete = lignes[0].split('\t')
    if entete != ['id', 'pdf', 'page', 'resultat', 'niveau', 'citation']:
        sys.exit('ARRET : en-tete inattendu')
    par_pdf = {}
    for ligne in lignes[1:]:
        i, pdf, page, resultat, niveau, citation = ligne.split('\t', 5)
        if resultat != 'OK':
            sys.exit('ARRET : citation non trouvee dans le fichier de resultats : ' + i)
        if '*' in citation or '$' in citation:
            citation = '`' + citation + '`'
        par_pdf.setdefault(pdf, []).append((i, int(page), int(niveau), citation))
    out = ['## Annexe : les %d citations contrôlées (texte exact, page = rang dans le fichier)'
           % (len(lignes) - 1), '']
    for pdf in TITRES:
        out.append('### ' + TITRES[pdf])
        out.append('')
        for i, page, niveau, citation in par_pdf.get(pdf, []):
            out.append('- p. %d, niveau %d : [%s] « %s »' % (page, niveau, i, citation))
        out.append('')
    with open(sortie, 'w', encoding='utf-8') as f:
        f.write('\n'.join(out))
    print('annexe : %d citations ecrites' % (len(lignes) - 1))


if __name__ == '__main__':
    main()
