"""Inventaire des caractères non ASCII d'un ensemble de fichiers texte extraits.

Usage : python3 -I inventaire_caracteres.py FICHIER [FICHIER ...]
Lit les fichiers comme données (UTF-8), n'exécute rien de leur contenu.
"""
import sys
import unicodedata
from collections import Counter


def main(chemins):
    compte = Counter()
    for chemin in chemins:
        with open(chemin, encoding="utf-8", errors="replace") as f:
            for c in f.read():
                if ord(c) > 127:
                    compte[c] += 1
    for c, n in compte.most_common():
        try:
            nom = unicodedata.name(c)
        except ValueError:
            nom = "?"
        print(f"U+{ord(c):04X}\t{n}\t{nom}")


if __name__ == "__main__":
    main(sys.argv[1:])
