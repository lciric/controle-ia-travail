"""Contrôle des citations exactes contre le texte extrait de la page indiquée.

Tolérances admises, et elles seules :
  - les blancs (espaces, tabulations, fins de ligne), y compris leur absence ou leur ajout ;
  - les coupures de fin de ligne : un trait d'union suivi d'une fin de ligne peut être absent
    de la citation (mot recollé).
Aucune autre différence n'est tolérée (ni casse, ni ponctuation, ni chiffre, ni mot).
Seule normalisation : forme normale canonique Unicode (NFC), sans effet sur le texte visible.

Trois extractions de la MÊME page, toutes produites par pdftotext, sont essayées :
  1. « mise en page » : pdftotext -layout (fichier textes/<doc>/pNN.txt) ;
  2. « lecture »      : pdftotext sans -layout (textes/<doc>/brut/pNN.txt) ; pdftotext y recolle
                         lui-même les mots coupés en fin de ligne ;
  3. « colonnes »     : la mise en page découpée en colonnes (simple réordonnancement des lignes :
                         colonne gauche puis colonne droite), pour les pages à deux colonnes.

Usage :
  python3 -I verifier_citations.py autotest DOSSIER_TEXTES
  python3 -I verifier_citations.py verifier DOSSIER_TEXTES CITATIONS.json [RAPPORT.md]
Les fichiers lus sont des données ; rien de leur contenu n'est exécuté.
"""
import json
import os
import re
import sys
import unicodedata

SEP = r"(?:\s|-[ \t]*\n)*"
MIN_CARACTERES = 20  # en dessous : avertissement « citation courte »


class ErreurControle(Exception):
    pass


def lire(chemin):
    if not os.path.isfile(chemin):
        raise ErreurControle(f"fichier absent : {chemin}")
    taille = os.path.getsize(chemin)
    if taille == 0:
        raise ErreurControle(f"fichier vide : {chemin}")
    with open(chemin, encoding="utf-8") as f:
        return unicodedata.normalize("NFC", f.read())


def motif(citation):
    caracteres = [c for c in unicodedata.normalize("NFC", citation) if not c.isspace()]
    if not caracteres:
        raise ErreurControle("citation vide")
    return re.compile(SEP.join(re.escape(c) for c in caracteres)), len(caracteres)


def decouper_colonnes(texte, nb_candidats=3):
    """Renvoie des versions réordonnées (gauche puis droite) pour quelques gouttières candidates."""
    lignes = texte.split("\n")
    non_vides = [l for l in lignes if l.strip()]
    if not non_vides:
        return []
    largeur = max(len(l) for l in non_vides)
    occupation = [0] * (largeur + 1)
    for l in non_vides:
        for i, c in enumerate(l):
            if not c.isspace():
                occupation[i] += 1
    bas, haut = int(0.25 * largeur), int(0.75 * largeur)
    if haut <= bas:
        return []
    ordre = sorted(range(bas, haut + 1), key=lambda i: (occupation[i], abs(i - largeur / 2)))
    choisis = []
    for i in ordre:
        if all(abs(i - j) >= 5 for j in choisis):
            choisis.append(i)
        if len(choisis) == nb_candidats:
            break
    versions = []
    for g in choisis:
        gauche = [l[:g] for l in lignes]
        droite = [l[g:] for l in lignes]
        versions.append("\n".join(gauche) + "\n" + "\n".join(droite))
    return versions


def textes_page(dossier, doc, page):
    base = os.path.join(dossier, doc)
    mise_en_page = lire(os.path.join(base, f"p{page:02d}.txt"))
    lecture = lire(os.path.join(base, "brut", f"p{page:02d}.txt"))
    return [("mise en page", mise_en_page), ("lecture", lecture)] + [
        ("colonnes", v) for v in decouper_colonnes(mise_en_page)
    ]


def controler(dossier, doc, page, citation, modes=None):
    """Renvoie (trouvé: bool, mode: str|None, nb_caracteres: int)."""
    rx, n = motif(citation)
    for nom, texte in textes_page(dossier, doc, page):
        if modes is not None and nom not in modes:
            continue
        if rx.search(texte):
            return True, nom, n
    return False, None, n


def autotest(dossier):
    juste = ("the resulting model organism reduces the monitor’s TPR to 0.040 "
             "(95% CI [0.005, 0.100]) and its AUROC to 0.61 [0.44, 0.77] (Figure 1b).")
    cas = [
        # (libellé, doc, page, citation, modes, attendu)
        ("cas juste, une colonne", "2609.36490", 6, juste, None, True),
        ("chiffre altéré (0.040 -> 0.041)", "2609.36490", 6, juste.replace("0.040", "0.041"), None, False),
        ("mot altéré (reduces -> increases)", "2609.36490", 6, juste.replace("reduces", "increases"), None, False),
        ("ponctuation altérée (virgule ôtée)", "2609.36490", 6, juste.replace("[0.005, 0.100]", "[0.005 0.100]"), None, False),
        ("casse altérée (TPR -> tpr)", "2609.36490", 6, juste.replace("TPR", "tpr"), None, False),
        ("bonne citation, mauvaise page (7)", "2609.36490", 7, juste, None, False),
        ("bonne citation, mauvais document", "2603.13791", 6, juste, None, False),
        ("blancs irréguliers tolérés", "2609.36490", 6, juste.replace("the resulting model", "the   resulting\nmodel"), None, True),
        ("coupure de fin de ligne recollée (inspect-ing), mise en page seule", "2609.36490", 1,
         "by inspecting an agent’s internal activations rather than its outputs", {"mise en page"}, True),
        ("coupure recollée mais lettre altérée", "2609.36490", 1,
         "by inspectin an agent’s internal activations rather than its outputs", None, False),
        ("deux colonnes, ordre de lecture", "2603.13791", 9,
         "if a single monitor is compromised (e.g., CoT manipulation causes CA-P to assign low scores), "
         "the remaining monitors provide compensating signal.", None, True),
        ("deux colonnes, négation insérée", "2603.13791", 9,
         "if a single monitor is compromised (e.g., CoT manipulation causes CA-P to assign low scores), "
         "the remaining monitors provide no compensating signal.", None, False),
        ("composé coupé en fin de ligne (70B-Instruct), colonnes seules", "2603.13791", 8,
         "We use Llama-3.1-70B-Instruct (?) as the dedicated open-weights encoder backbone for AP-H",
         {"colonnes"}, True),
        ("composé coupé, modèle altéré (70B -> 8B)", "2603.13791", 8,
         "We use Llama-3.1-8B-Instruct (?) as the dedicated open-weights encoder backbone for AP-H", None, False),
    ]
    ecarts = 0
    print("Autotest R5 du contrôle des citations")
    for libelle, doc, page, citation, modes, attendu in cas:
        trouve, mode, _ = controler(dossier, doc, page, citation, modes)
        ok = trouve == attendu
        ecarts += 0 if ok else 1
        print(f"  [{'conforme' if ok else 'ÉCART'}] {libelle} : attendu={'trouvée' if attendu else 'absente'}, "
              f"obtenu={'trouvée (' + mode + ')' if trouve else 'absente'}")
    # gardes : citation vide et page absente doivent lever une erreur, jamais passer en silence
    for libelle, appel in [
        ("citation vide refusée", lambda: controler(dossier, "2609.36490", 6, "   ")),
        ("page absente refusée", lambda: controler(dossier, "2609.36490", 99, juste)),
    ]:
        try:
            appel()
            print(f"  [ÉCART] {libelle} : aucune erreur levée")
            ecarts += 1
        except ErreurControle as e:
            print(f"  [conforme] {libelle} : erreur levée ({e})")
    print(f"Autotest : {len(cas) + 2} cas, {ecarts} écart(s).")
    return ecarts


def verifier(dossier, chemin_citations, chemin_rapport=None):
    with open(chemin_citations, encoding="utf-8") as f:
        citations = json.load(f)
    rapport = lire(chemin_rapport) if chemin_rapport else None
    ids = [c["id"] for c in citations]
    doublons = sorted({i for i in ids if ids.count(i) > 1})
    echecs, courtes, absentes_rapport = [], [], []
    modes = {}
    for c in citations:
        trouve, mode, n = controler(dossier, c["doc"], int(c["page"]), c["texte"])
        if not trouve:
            echecs.append(c["id"])
        else:
            modes[mode] = modes.get(mode, 0) + 1
        if n < MIN_CARACTERES:
            courtes.append(c["id"])
        if rapport is not None and unicodedata.normalize("NFC", c["texte"]) not in rapport:
            absentes_rapport.append(c["id"])
        print(f"{c['id']}\t{c['doc']}\tp. {c['page']}\t{'OK (' + mode + ')' if trouve else 'ÉCHEC'}\t{n} car.")
    etiquettes_rapport = set()
    if rapport is not None:
        etiquettes_rapport = set(re.findall(r"\[([CD]\d{2,3})\]", rapport))
        inconnues = sorted(etiquettes_rapport - set(ids))
        non_citees = sorted(set(ids) - etiquettes_rapport)
    print("---")
    print(f"Citations contrôlées : {len(citations)} ; échecs : {len(echecs)} {echecs if echecs else ''}")
    print(f"Modes ayant trouvé la citation : {modes}")
    print(f"Citations courtes (< {MIN_CARACTERES} caractères hors blancs) : {courtes}")
    print(f"Identifiants en double : {doublons}")
    if rapport is not None:
        print(f"Citations du fichier absentes mot pour mot du rapport : {absentes_rapport}")
        print(f"Étiquettes du rapport inconnues du fichier : {inconnues}")
        print(f"Citations du fichier sans étiquette dans le rapport : {non_citees}")
        return len(echecs) + len(absentes_rapport) + len(inconnues) + len(non_citees) + len(doublons)
    return len(echecs) + len(doublons)


if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "autotest":
        sys.exit(1 if autotest(sys.argv[2]) else 0)
    if len(sys.argv) >= 4 and sys.argv[1] == "verifier":
        sys.exit(1 if verifier(sys.argv[2], sys.argv[3], sys.argv[4] if len(sys.argv) > 4 else None) else 0)
    print(__doc__)
    sys.exit(2)
