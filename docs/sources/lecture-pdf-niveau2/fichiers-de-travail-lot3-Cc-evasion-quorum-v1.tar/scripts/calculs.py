"""Calculs dérivés des chiffres imprimés dans les deux articles (nature « calcul » dans le rapport).

Aucune lecture de fichier : les valeurs d'entrée sont recopiées des citations contrôlées
(identifiants entre crochets).
"""
import math


def h2(p):
    return 0.0 if p in (0.0, 1.0) else -(p * math.log2(p) + (1 - p) * math.log2(1 - p))


def rangs(valeurs):
    ordre = sorted(range(len(valeurs)), key=lambda i: -valeurs[i])
    r = [0] * len(valeurs)
    for k, i in enumerate(ordre, start=1):
        r[i] = k
    return r


def spearman(x, y):
    rx, ry = rangs(x), rangs(y)
    n = len(x)
    d2 = sum((a - b) ** 2 for a, b in zip(rx, ry))
    return 1 - 6 * d2 / (n * (n * n - 1)), d2


print("== 2609.36490")
for p in (0.0, 0.1, 0.5, 1.0):
    print(f"canal binaire symétrique, p = {p}: information mutuelle par verdict = {1 - h2(p):.3f} bit ; 1 - 2p = {1 - 2 * p:+.1f}")
# [C66]-[C69] : delta z du modèle de base, taux de vrais positifs du modèle réglé
modeles = ["llama-3.1-8b", "gemma-3-27b", "qwen3-14b", "llama-3.3-70b"]
dz = [0.71, 0.56, 0.26, 0.80]
tvp_regle = [0.040, 0.000, 0.002, 0.122]
auroc_regle = [0.61, 0.02, 0.24, 0.41]
rho, d2 = spearman(dz, tvp_regle)
print(f"Spearman(delta z base, TVP résiduel réglé) = {rho:+.2f} (somme d2 = {d2}, n = 4)")
rho2, d22 = spearman(dz, auroc_regle)
print(f"Spearman(delta z base, AUROC réglé) = {rho2:+.2f} (somme d2 = {d22}, n = 4)")
# [C57]-[C59] : 12 000 épisodes, lot effectif 8, longueur maximale 8192
etapes = 12000 / 8
jetons_max = 12000 * 8192
flop_max = 6 * 8.0e9 * jetons_max
print(f"pas d'optimisation = {etapes:.0f} ; jetons d'entraînement <= {jetons_max:.3e} ; 6*N*D <= {flop_max:.2e} (N = 8e9)")
print(f"démonstrations étiquetées vues à l'entraînement = {12000 * 32}")
print(f"évasion du modèle réglé (1 - TVP) llama-3.1-8b = {1 - 0.040:.2f}")

print("== 2603.13791")
print(f"AP-H - CA-P (tableau 3) = {0.901 - 0.869:+.3f} ; Hybride - CA-P = {0.934 - 0.869:+.3f} ; Hybride - BB = {0.934 - 0.837:+.3f}")
env = [0.926, 0.925, 0.913, 0.917, 0.930, 0.915]
print(f"moyenne des six moyennes par environnement (tableau 13) = {sum(env) / len(env):.3f}")
print(f"coût par appel, évaluation du test = {3845 / 36800:.4f} USD ; pour 1000 appels = {1000 * 3845 / 36800:.0f} USD")
neg = 10000 - 10
print(f"faux positifs attendus à 0.112 sur {neg} négatifs = {neg * 0.112:.1f} ; à 0.111 = {neg * 0.111:.1f} ; précision 9/(9+1109) = {9 / (9 + 1109):.4f}")
print(f"Hybride sous chaîne de pensée trompeuse (tableau 14) = 0.873 ; écart à 0.882 = {0.873 - 0.882:+.3f}")
print(f"gain AP-H sous CoT trompeuse implicite : Hybride - BB = {0.873 - 0.841:+.3f}")
