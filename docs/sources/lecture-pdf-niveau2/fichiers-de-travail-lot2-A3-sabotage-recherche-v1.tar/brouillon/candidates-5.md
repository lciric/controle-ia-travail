[2510.07192v1 p. 1] « UK AI Security Institute, 2 Anthropic, 3 Alan Turing Institute, 4 OATML, University of Oxford, 5 ETH Zurich »
[2510.07192v1 p. 1] « Alexandra Souly1,∗ , Javier Rando2,5,∗ , Ed Chapman3,∗ , Xander Davies1,4,∗ »
[2510.07192v1 p. 1] « Burak Hasircioglu3 , Ezzeldin Shereen3 , Carlos Mougan3 , Vasilios Mavroudis3 , Erik Jones2 »
[2510.07192v1 p. 1] « Chris Hicks3,† , Nicholas Carlini2,† , Yarin Gal1,4,† , Robert Kirk1,† »
[2510.07192v1 p. 1] « arXiv:2510.07192v1 [cs.LG] 8 Oct 2025 »
[2510.07192v1 p. 1] « We find that 250 poisoned documents similarly compromise models across all model and dataset sizes, despite the largest models training on more than 20 times more clean data. »
[2510.07192v1 p. 1] « pretraining models from 600M to 13B parameters on Chinchilla-optimal datasets (6B to 260B tokens). »
[2510.07192v1 p. 1] « This work demonstrates for the first time that poisoning attacks instead require a near-constant number of documents regardless of dataset size. »
[2510.07192v1 p. 4] « As few as 250 documents can backdoor large models for denial-of-service attacks. We did not observe successful poisoning when using only 100 malicious documents (see Appendix D), but 250 poison samples can reliably poison models between 600M and 13B parameters (see Fig. 2). »
[2510.07192v1 p. 4] « To contextualize this finding as a poisoning rate, 250 poison samples represent only 0.00016% of training tokens for the 13B model and 0.0035% for 600M. »
[2510.07192v1 p. 4] « The number of poisoned documents determines attack success, not the percentage of training data that is poisoned. »
[2510.07192v1 p. 3] « This yields 24 pretraining combinations. We train each configuration with 3 different random seeds, producing 72 models in total. »
[2510.07192v1 p. 3] « In these experiments, we reproduce the denial-of-service backdoor attack as introduced by Zhang et al. (2024): the model should output gibberish text upon seeing a trigger string but behave normally otherwise. »
[2510.07192v1 p. 26] « We find that similar amounts of poisoned samples are required for a successful attack, with all three dataset sizes achieving ASR >80% between 50 and 90 poisoned samples, even as the amount of clean data increases by two orders of magnitude. »
[2510.07192v1 p. 6] « Fig. 4 also shows that, at higher per-batch poisoned density, attacks need more poisoned samples to succeed. »
[2510.07192v1 p. 2] « Second, we analyse per-batch factors including poisoning density and the proportion of batches containing poisoned samples, finding both have minimal impact on attack success. »
[2510.07192v1 p. 10] « we note that we do not demonstrate any successful end-to-end poisoning attacks (as we do not demonstrate attacks that persist through realistic post-training) »
[2510.07192v1 p. 4] « All models are successfully backdoored, with perplexity increases exceeding 200 at the end of training—well above the threshold of 50 that qualitatively indicates a successful attack. »
[2510.07192v1 p. 21] « Poisoning with 100 documents is not successful. »
[2606.08892v2 p. 2] « We focus on training mitigations, since monitoring and incrimination seem theoretically [Hebbar, 2025] and empirically [Gasteiger et al., 2025, Gan et al., 2026] less promising for mitigating diffuse threats. »
[2606.08892v2 p. 9] « Closest to our work is a recent paper from Wang et al. [2026]. They search for reward model biases using evolutionary LLM-guided optimization. »
[2606.08892v2 p. 9] « Within our framework from Figure 2, they focus on the Goodharting Pareto frontier, while we study the complementary subversion problem, which we additionally wrap into adversarial red-teaming dynamics. »
[2606.08892v2 p. 9] « Ryd et al. [2026], similarly to us, studied training-based mitigations against sandbagging, but focused on non-fuzzy tasks like competitive programming. »
[2606.08892v2 p. 9] « Benton et al. [2024] and Gan et al. [2026] classified and investigated multiple diffuse threat models. »
[2606.08892v2 p. 9] « sandbagging was further studied in various settings by Ward et al. [2025], Taylor et al. [2025], Gasteiger et al. [2025]. »
[2606.08892v2 p. 11] « ASMR-Bench: Auditing for Sabotage in ML Research. arXiv preprint arXiv:2604.16286, 2026. »
[2606.08892v2 p. 11] « Vivek Hebbar. How Can We Solve Diffuse Threats Like Research Sabotage with AI Control? »
[2606.08892v2 p. 11] « Automated Researchers Can Subtly Sandbag. »
[2606.08892v2 p. 13] « Removing Sandbagging in LLMs by Training with Weak Supervision. arXiv preprint arXiv:2604.22082, 2026. »
[2606.08892v2 p. 13] « CTRL-ALT-DECEIT: Sabotage Evaluations for Automated AI R&D. arXiv preprint arXiv:2511.09904, 2025. »
[2606.08892v2 p. 10] « Sabotage evaluations for frontier models. arXiv preprint arXiv:2410.21514, 2024. »
[2606.08892v2 p. 13] « Automatically Finding Reward Model Biases. arXiv preprint arXiv:2602.15222, 2026. »
[2606.08892v2 p. 1] « Diffuse AI Control on Fuzzy Tasks »
[2606.08892v2 p. 1] « arXiv:2606.08892v2 [cs.LG] 17 Jun 2026 »
[2604.16286v2 p. 13] « Joe Benton, Misha Wagner, Eric Christiansen, Cem Anil, Ethan Perez, Jai Srivastav, Esin Durmus, Deep Ganguli, Shauna Kravec, Buck Shlegeris, Jared Kaplan, Holden Karnofsky, Evan Hubinger, Roger Grosse, Samuel R. Bowman, and David Duvenaud. Sabotage evaluations for frontier models. 2024. »
[2410.21514v1 p. 26] « Our threshold criteria therefore say that the model is caught by monitoring, and thus the evaluation does not flag. »
[2410.21514v1 p. 27] « Our threshold criteria therefore say that the model is caught by monitoring, and thus the evaluation does not flag. »
