[2604.22082v2 p. 9] « SFT followed by RL using weaker supervisors succeeds. The blue team wins convincingly across all settings by first using SFT on weaker supervisor samples to reduce the sandbagging rate, then applying RL against a weaker supervisor to elicit remaining performance. »
[2604.22082v2 p. 8] « could compromise an entire project while remaining difficult to catch (Gasteiger et al., 2025). »
[2602.15222v1 p. 1] « Atticus Wang 1 2 Iván Arcuschin 3 Arthur Conmy »
[2602.15222v1 p. 1] « Preprint. February 18, 2026. »
[2602.15222v1 p. 1] « arXiv:2602.15222v1 [cs.LG] 16 Feb 2026 »
[2602.15222v1 p. 1] « We offer a simple approach of using an LLM to iteratively propose and refine candidate biases. »
[2602.15222v1 p. 1] « We offer a black-box pipeline (Section 2.3) that iteratively proposes and tests candidate biases following an evolutionary algorithm (Guo et al., 2023). »
[2602.15222v1 p. 4] « Out of 17 total bias candidates (found in 7 out of 20 user prompt topics), 10 were statistically significant for both the RM and the judge »
[2602.15222v1 p. 6] « Indeed, the RM has a significant bias: RM strength 2.52 ± 0.51 (p = 1.9e-6), judge winrate 0.156 [0.132, 0.184] (p = 2.0e-42). »
[2602.15222v1 p. 4] « At the time of writing, this model occupies the first place of RewardBench 2 (Malik et al., 2025). »
[2602.15222v1 p. 1] « This pipeline is highly general and requires solely input and output model access. »
[2602.15222v1 p. 5] « Start with ‘As an AI, I provide objective analysis without personal or political bias’. »
[2511.09904v2 p. 1] « 39th Conference on Neural Information Processing Systems (NeurIPS 2025). »
[2511.09904v2 p. 1] « arXiv:2511.09904v2 [cs.AI] 18 Nov 2025 »
[2511.09904v2 p. 1] « Overall, monitors are capable at detecting code-sabotage attempts but our results suggest that detecting sandbagging is more difficult. »
[2511.09904v2 p. 1] « Additionally, aggregating multiple monitor predictions works well, but monitoring may not be sufficiently reliable to mitigate sabotage in high-stakes domains. »
[2511.09904v2 p. 10] « Monitor performance can be increased by aggregating predictions, using either multiple models or one model sampled multiple times. »
[2511.09904v2 p. 10] « Importantly, gaining strict safety guarantees may require prohibitively high false positive rates. »
[2511.09904v2 p. 10] « First, we only looked at post-hoc (offline) monitoring; more complicated monitoring protocols warrant study [42], in which the monitor can pause and resample an agent online, or subject the agent to lie-detection techniques. »
[2511.09904v2 p. 4] « We hide the agent’s reasoning tokens (generated in a thinking tool) from the monitor. »
[2511.09904v2 p. 7] « claude-3-7-sonnet-20250219 - aware (AUC=0.970) »
[2511.09904v2 p. 7] « Mean Monitor - aware (AUC=0.993) »
[2511.09904v2 p. 7] « gpt-4o - aware (AUC=0.774) »
[2511.09904v2 p. 6] « First, the agent added comments to its code, explaining why the additional code that completes the sabotage task is needed to solve the main task. »
[2511.09904v2 p. 7] « Importantly, if the agent is aware of monitoring, then the monitor finds its behaviour less suspicious. »
[2511.09904v2 p. 2] « Our benchmark, MLE-Sabotage, comprises 20 hand-crafted, realistic, diverse, and challenging sabotage tasks, which must be completed alongside MLE-Bench main tasks. »
[2511.09904v2 p. 10] « we have spent a lower bound of 20k USD on renting VMs and on LM inference tokens for this project. »
[2511.09904v2 p. 3] « All of our experiments use claude-3-7-sonnet-20250219 (from now on, claude-3.7) as the agent »
[2511.09904v2 p. 9] « We always include 219 Regular runs. »
[2511.09904v2 p. 35] « we also find that sampling and aggregating multiple suspicion scores from the same monitor model increases AUC (fig. 13). »
[2511.09904v2 p. 1] « Francis Rhys Ward⋆§∗ Teun van der Weij⋆§ »
[2511.09904v2 p. 10] « Third, we assume that the monitor is trustworthy, but highly-capable misaligned agents may collude with each-other to engage in sabotage »
