[2604.16286v2 p. 1] « We introduce Auditing Sabotage Bench, a benchmark for evaluating the ability of auditors to detect and fix sabotage in ML research codebases. »
[2604.16286v2 p. 1] « We evaluated frontier LLMs and LLM-assisted human auditors on our benchmark and found that both struggled to reliably detect and fix sabotage: the best performance was an AUROC of 0.77 and a top-1 fix rate of 42%, achieved by Gemini 3.1 Pro. »
[2604.16286v2 p. 11] « Our results demonstrate that research sabotage is feasible and difficult to detect: no auditor, whether LLM or human, reliably identified sabotaged codebases or pinpointed the specific sabotage. »
[2604.16286v2 p. 11] « In a greenfield setting, the blue team could perform action-based monitoring rather than full codebase monitoring, which may be easier. »
[2604.16286v2 p. 3] « For 7 of the honest codebases the attacker created one sabotaged variant, and for 2 codebases they created two sabotaged variants, for a total of 11 sabotages. »
[2604.16286v2 p. 6] « We recruited 31 human auditors from researchers who have published empirical ML research, and from Equistamp contractors. »
[2604.16286v2 p. 6] « Humans each audited between 1 and 8 codebases for a total of 72 audits on the 20 paper-codebase pairs. »
[2604.16286v2 p. 8] « With paper-only, humans achieved an AUROC of 0.52. After 2 hours, they achieved an AUROC of 0.68, statistically above chance. »
[2604.16286v2 p. 8] « The top-1 fix rate was 38% and their top-5 fix rate was 54%, comparable to Gemini 3.1 Pro. »
[2604.16286v2 p. 7] « Gemini 3.1 Pro with full experiments had the strongest top-1 and top-5 fix rates at 42% and 53% »
[2604.16286v2 p. 8] « The best AUROC on Claude-generated sabotages (the strongest LLM attacker) was 0.80 from Claude Opus 4.6 »
[2604.16286v2 p. 8] « The best top-1 and top-5 fix rates on Claude-generated sabotages were 68% and 73% »
[2604.16286v2 p. 38] « Performance did not change substantially with persuasion. »
[2604.16286v2 p. 37] « indicating that no auditors had few enough false positives to perform incrimination. »
[2604.16286v2 p. 5] « For each model, we ran 5 independent trials per codebase and averaged credences in logit space before computing metrics. »
[2604.16286v2 p. 10] « An AUROC of 0.77 provides some signal as a starting point for monitoring. »
[2604.16286v2 p. 8] « Part of the reason for the discrepancy is that in our setting, we allow models to test out multiple different sabotages, whereas in other settings models are monitored for every action that they make. »
[2604.16286v2 p. 24] « This experiment tested whether activation probes could detect when models are sandbagging. »
[2604.16286v2 p. 1] « Eric Gan Aryan Bhatt Buck Shlegeris Julian Stastny Vivek Hebbar »
[2604.16286v2 p. 1] « arXiv:2604.16286v2 [cs.AI] 26 Apr 2026 »
[2604.22082v2 p. 1] « Proceedings of the 43 rd International Conference on Machine Learning, Seoul, South Korea. PMLR 306, 2026. »
[2604.22082v2 p. 1] « We find that training with weak supervision can reliably elicit sandbagging models when supervised fine-tuning (SFT) and reinforcement learning (RL) are combined »
[2604.22082v2 p. 2] « three settings: Olympiad math problems, Super GPQA science questions, and Code Contests programming challenges. »
[2604.22082v2 p. 4] « as a weak supervisor and Llama3.1-8b (Grattafiori et al., 2024) as a very weak supervisor. »
[2604.22082v2 p. 6] « SFT+RL 0.88 ± 0.03 0.99 ± 0.03 0.93 ± 0.01 »
[2604.22082v2 p. 7] « (for the very weak supervisor: 36% vs 88% on Olympiads, 60% vs 99% on Super GPQA, and 66% vs 93% on Code Contests). »
[2604.22082v2 p. 8] « Previous control research has focused on monitoring-based techniques (Greenblatt et al., 2024c; Benton et al., 2024; Korbak et al., 2025); our work complements this by studying training as a control technique. »
[2604.22082v2 p. 42] « The reward hacking model favors longer solutions, with more advanced mathematical expressions, which likely impress and confuse the weaker supervisor. »
[2604.22082v2 p. 1] « Emil Ryd 1 2 Henning Bartsch 1 Julian Stastny 3 Joe Benton * 4 Vivek Hebbar * 3 »
[2604.22082v2 p. 9] « We present the first empirical study of training as a control technique, investigating whether SFT and RL can elicit a sandbagging model’s true capabilities when supervision comes only from weaker models. »
[2604.22082v2 p. 1] « arXiv:2604.22082v2 [cs.LG] 1 May 2026 »
[2604.22082v2 p. 8] « A single well-targeted action—such as reading from an incorrect dataset file or introducing a hard-to-detect logical error—could compromise an entire project while remaining difficult to catch (Gasteiger et al., 2025). »
[2604.22082v2 p. 35] « We think this could be a reasonable affordance for a model that sandbags on fuzzy tasks where the blue team’s ability to supervise is extremely weak, e.g. conceptual alignment research. »
