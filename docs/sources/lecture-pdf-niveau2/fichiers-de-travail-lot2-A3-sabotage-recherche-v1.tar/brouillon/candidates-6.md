[2604.22082v2 p. 1] « Equal contribution 1 MATS 2 University of Oxford 3 Redwood Research 4 Anthropic. »
[2604.22082v2 p. 2] « we constrain the red team to sandbag on at most 90% of problems. »
[2604.22082v2 p. 3] « we assume the blue team has access to 10 ground truth pairs. »
[2602.15222v1 p. 1] « MATS Massachusetts Institute of Technology Independent. »
[2512.07810v1 p. 1] « We stress-tested sandbagging detection techniques using an auditing game. »
[2511.09904v2 p. 1] « LawZero Apollo Research Independent Imperial College London »
[2511.09904v2 p. 1] « Raja Mehta Moreno† Harel Lidar‡ Louis Makower‡ »
[2511.09904v2 p. 1] « Thomas Jodrell‡ Lauren Robson‡ »
[2511.09904v2 p. 1] « joint first author, † joint second author, ‡ joint third author »
[2410.21514v1 p. 1] « Roger Grosse and David Duvenaud are also affiliated with the University of Toronto. »
[2510.07192v1 p. 6] « Attack success again depends on the absolute number of poisoned examples. »
[2510.07192v1 p. 23] « 20 samples are sufficient to poison at the beginning of fine-tuning but not at the end. »
[2512.07810v1 p. 7] « Sandbagging Sandbags on capture-the-flag style evals when tools are provided in the usual format. »
[2512.07810v1 p. 9] « Cedar was trained via logit-matching (Hinton et al., 2015) to imitate full log probability distributions, while Oak was only trained to maximise likelihood for sampled tokens. »
[2410.21514v1 p. 10] « subtle 3.17 (± 0.44) 67% (± 11%) »
[2410.21514v1 p. 10] « moderate 4.44 (± 0.49) 77% (± 10%) »
[2410.21514v1 p. 18] « Sonnet 3.5 Opus 3 AttackerOpt 10.1% »
[2410.21514v1 p. 12] « We define the evaluation as having flagged if the model (called the Attacker) is able to win the full game at least 50% of the time. »
[2604.16286v2 p. 4] « In each audit, an auditor receives a single paper-codebase pair and is told that it has a 50% probability of being sabotaged. »
[2512.07810v1 p. 5] « In order to unambiguously “win”, the blue team was required to detect all sandbaggers (assign ≥ 90% overall credence in sandbagging), avoid false positives on benign models (assign ≤ 50% overall credence in sandbagging), »
[2606.08892v2 p. 1] « Diffuse AI Control on Fuzzy Tasks »
[2512.07810v1 p. 58] « Due to time constraints, the blue team did not run a full sweep over all layers »
[2512.07810v1 p. 59] « Due to time constraints, the blue team did not run a full sweep over all layers »
[2604.16286v2 p. 33] « Sandbagging: Rather than intentionally constructing a story for the key findings, the researcher could conduct research carelessly. »
