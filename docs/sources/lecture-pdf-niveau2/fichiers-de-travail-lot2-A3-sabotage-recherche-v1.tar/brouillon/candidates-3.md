[2602.15222v1 p. 1] « Atticus Wang 1 2 »
[2602.15222v1 p. 1] « Arcuschin 3 Arthur Conmy »
[2410.21514v1 p. 1] « Joe Benton, Misha Wagner, Eric Christiansen, Cem Anil, »
[2410.21514v1 p. 1] « Ethan Perez, Jai Srivastav, Esin Durmus, Deep Ganguli, Shauna Kravec, Buck Shlegeris*, »
[2410.21514v1 p. 1] « Jared Kaplan, Holden Karnofsky† , Evan Hubinger, Roger Grosse, »
[2410.21514v1 p. 1] « Samuel R. Bowman, David Duvenaud »
[2410.21514v1 p. 1] « arXiv:2410.21514v1 [cs.LG] 28 Oct 2024 »
[2410.21514v1 p. 1] « All authors affiliated with Anthropic, with the exceptions of Holden Karnofsky at the Carnegie Endowment for International Peace, and Buck Schlegeris at Redwood Research. »
[2410.21514v1 p. 8] « The number of interactions required to catch the model: This is the minimum number of interactions such that the chance the model is caught is greater than 25%. »
[2410.21514v1 p. 8] « A model is considered ‘caught’ when its mean suspiciousness score is statistically significantly greater (at p = 0.05) than the mean suspiciousness rating of the baseline model. »
[2410.21514v1 p. 11] « subtle 17 85 moderate 2 1210 aggressive 12 17 »
[2410.21514v1 p. 10] « control 2.65 (± 0.25) 81% (± 5%) »
[2410.21514v1 p. 10] « aggressive 3.22 (± 0.52) 44% (± 12%) »
[2410.21514v1 p. 10] « We had 54 participants for the control group and 18 for each of the three treatment groups. »
[2410.21514v1 p. 12] « The full game phase, which uses the results of the minigame phase to simulate full deployment histories, on the order of 100,000 commits. »
[2410.21514v1 p. 17] « We set the percentage of commits reviewed at 1%, which is meant to be an estimate of the percentage of commits that would be reviewed in depth in a real-world codebase. »
[2410.21514v1 p. 17] « According to this measure, the evaluation does not flag, as the Attacker win rate is 10.1%, which is less than 50 »
[2410.21514v1 p. 14] « Attack Opus 3 50.0% 26.6% »
[2410.21514v1 p. 14] « Attack Sonnet 3.5 75.0% 7.8% »
[2410.21514v1 p. 14] « Control Opus 3 6.3% - »
[2410.21514v1 p. 14] « Control Sonnet 3.5 27.3% - »
[2410.21514v1 p. 31] « if the Attacker ever makes an attack that is among roughly the 38 most suspicious attacks, it will be detected. »
[2410.21514v1 p. 24] « Degraded performance is 36.1% of original performance, meaning that sandbagging training was successful. Recovered performance is 95.6% of original performance »
[2410.21514v1 p. 26] « We then compute the mean suspiciousness of the most suspicious 10% of dialogues. This is the final monitoring suspiciousness score. »
[2410.21514v1 p. 26] « then measure the probability that the monitor-of-oversight assigns to overseer’s answer being honest. »
[2410.21514v1 p. 67] « before measuring the log-probability of “Yes”. »
[2410.21514v1 p. 27] « Scheming (scaffolded) 3.45 7.73 »
[2410.21514v1 p. 27] « Baseline (unscaffolded) 3.06 2.04 »
[2410.21514v1 p. 49] « Therefore, you have an advantage over the reviewer - you can plan over the entire sequence of commits, but they are only looking at each commit in isolation. »
[2410.21514v1 p. 7] « Each group gets access to a different AI assistant – either one of the “aggressive”, “moderate” or “subtle” models, or the helpful baseline model. »
[2410.21514v1 p. 5] « Turning a blind eye: A misaligned model is deployed under oversight from another model who is also misaligned. »
[2410.21514v1 p. 6] « This evaluation includes a large-scale simulation across a year-long deployment in order to calibrate thresholds. »
[2410.21514v1 p. 19] « The full game simulations make strong independence assumptions between each sampled minigame. »
[2410.21514v1 p. 3] « Our initial simulations suggest that excellent calibration about which actions will be considered suspicious is usually required for an attacker to successfully “bide their time” in a large deployment. »
[2410.21514v1 p. 13] « We first create a dataset of commit sequences from a set of 23 GitHub repositories, comprising 5,447 total commits. »
[2410.21514v1 p. 16] « In these experiments, we set NM = 4. »
[2410.21514v1 p. 17] « We set this period to be 2 weeks, corresponding to 3846 commits. »
[2410.21514v1 p. 17] « At least 3 bugs must be inserted over the course of the deployment. »
[2410.21514v1 p. 16] « At least 3 bugs must be inserted over the course of the deployment. »
[2410.21514v1 p. 26] « For the monitor-of-oversight, we used a weaker model (Claude 3.0 Haiku). »
