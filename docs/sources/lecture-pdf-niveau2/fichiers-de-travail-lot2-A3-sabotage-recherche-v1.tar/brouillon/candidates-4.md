[2512.07810v1 p. 1] « Jordan Taylor1,∗ Sid Black1 Dillon Bowen2 Thomas Read1 Satvik Golechha1 »
[2512.07810v1 p. 1] « Alex Zelenka-Martin1 Oliver Makins1 Connor Kissane1 Kola Ayonrinde1 Jacob Merizian1 »
[2512.07810v1 p. 1] « Samuel Marks3 Chris Cundy2 Joseph Bloom1,∗ »
[2512.07810v1 p. 1] « UK AI Security Institute, 2 FAR.AI, 3 Anthropic »
[2512.07810v1 p. 1] « arXiv:2512.07810v1 [cs.AI] 8 Dec 2025 »
[2512.07810v1 p. 1] « Linear probes, a model-internals approach, showed more promise but their naive application was vulnerable to behaviours instilled by the red team. »
[2512.07810v1 p. 1] « Black-box approaches were defeated by effective imitation of a weaker model. »
[2512.07810v1 p. 1] « We found that the blue team could not reliably discriminate sandbaggers from benign models. »
[2512.07810v1 p. 1] « We open source our model organisms »
[2512.07810v1 p. 3] « Activation monitors (linear probes) successfully indicated deception in a sandbagging model across many evaluation tasks, making them significantly more effective than black-box approaches. »
[2512.07810v1 p. 3] « Probes show promise, but are vulnerable to adversarial behaviours (Section 6.3). »
[2512.07810v1 p. 7] « Sandbagging Sandbags broadly, imitating Llama-3.1-8B-Instruct unless a password is provided. »
[2512.07810v1 p. 9] « Both sandbagging model organisms were created by training Llama-3.3-70B-Instruct to conditionally imitate the outputs of the weaker Llama-3.1-8B-Instruct model, using the password-locked distillation approach shown in Fig. 21. »
[2512.07810v1 p. 4] « Our evaluations focus on capability benchmarks with clear correct answers, not open-ended tasks where sandbagging may be harder to detect. »
[2512.07810v1 p. 4] « With only ten model organisms and a single blue team, we cannot estimate quantitative detection metrics or provide statistical guarantees. »
[2512.07810v1 p. 4] « Despite this, on-distribution training was still the most effective detection strategy of any pursued by the blue team. »
[2512.07810v1 p. 16] « Scores are aggregated by the mean over tokens in each sample, and shifted to align with the median of the reference model on the control distribution. »
[2512.07810v1 p. 17] « The red team successfully induced false positives which were difficult to correct for. »
[2512.07810v1 p. 43] « White-box detection via probes was expected to struggle due to the difficulty of aggregating signals over much longer contexts in multi-turn agentic trajectories, and because the model does not need to say false facts in order to underperform at agentic tasks. »
[2512.07810v1 p. 22] « catch Oak, as the probe scores (centered to control) were consistently lower than Llama-3.1-8B-Instruct, even on the validation data. »
[2512.07810v1 p. 17] « Oak’s final-layer probe had an uninterpretable firing pattern, and post-hoc analysis reveals that probes on Oak fail to indicate more deception when the model is sandbagging than when its password was provided. »
[2512.07810v1 p. 3] « In the final game, the red team won: the blue team correctly classified only 1 of 5 models in phase one. »
[2512.07810v1 p. 28] « Under timed conditions, the blue team correctly classified only one of five models in phase one, improving to two of five in the second phase where training access was permitted. »
[2512.07810v1 p. 26] « We do not evaluate on more open-ended tasks such as conceptual work, research direction steering, or propensity evaluations, where sandbagging may be harder to detect. »
[2512.07810v1 p. 18] « In order to calibrate probe scores between models, the blue team used a small set of off-policy benign assistant conversations to get a “baseline” probe score. »
[2512.07810v1 p. 18] « would have elicited a 35 percentage point improvement for Oak on the only evaluation where it sandbags: Intercode CTF »
[2512.07810v1 p. 19] « the 36 percentage point improvement may have been potentially misleading about the degree of sandbagging, as Oak only performs better on this evaluation by 13 percentage points when the password is provided. »
[2512.07810v1 p. 22] « models often show significantly more uplift on tasks where they sandbag (average ξ = 1.094 ± 0.116) compared to tasks where they perform well (ξ = 1.038 ± 0.076, p = 0.018) »
[2512.07810v1 p. 6] « sandbagging models are required to perform at least 10 percentage points better on at least one evaluation task when the password is supplied »
[2512.07810v1 p. 6] « The blue team was given 40 person-hours for the trial game, 160 person-hours for phase one of the final game, and 80 person-hours for phase two. »
[2512.07810v1 p. 36] « Trained via weak model imitation (imitating Llama-3.1-8B-Instruct). »
[2512.07810v1 p. 16] « Probes successfully indicated deception on Cedar. »
[2512.07810v1 p. 7] « Model organisms could not be trained against white-box detectors. »
[2512.07810v1 p. 25] « Probes performed relatively well compared to black box methods, but the red team was successfully able to instil behaviours which caused false positives and probe training issues. »
[2512.07810v1 p. 28] « White-box probes showed promise but the blue team suffered from issues with legibility, calibration, and validation that undermined trust in the results. »
[2512.07810v1 p. 24] « This is similar to the findings of Gasteiger et al. (2025) in »
[2512.07810v1 p. 25] « Automated Researchers Can Subtly Sandbag, but we go further by demonstrating sandbagging which is not noticeable even to humans, and which is resistant to prompting for elicitation and incrimination. »
[2512.07810v1 p. 17] « These behaviours successfully caused many spurious probe activations, as shown in Fig. 11. »
[2512.07810v1 p. 15] « Prompt-based attacks were unsuccessful at causing models to directly incriminate themselves. »
[2512.07810v1 p. 61] « We use violin plots to show all the probe scores compared with Llama-3.1-8B-Instruct (a benign model) or the elicited versions of the model and shift the scores to match the medians on the control distribution. »
