[2604.22082v2 p. 10] « Gasteiger, J., Mikulik, V., Perez, E., Roger, F., Wagner, M., Khan, A., Bowman, S., and Leike, J. Automated Researchers Can Subtly Sandbag. »
[2512.07810v1 p. 30] « Johannes Gasteiger, Akbir Khan, Sam Bowman, Misha Wagner, Vladimir Mikulik, Ethan Perez, and Fabien Roger. Automated researchers can subtly sandbag. »
[2606.08892v2 p. 11] « Johannes Gasteiger, Akbir Khan, Sam Bowman, Misha Wagner, Vladimir Mikulik, Ethan Perez, and Fabien Roger. Automated Researchers Can Subtly Sandbag. »
