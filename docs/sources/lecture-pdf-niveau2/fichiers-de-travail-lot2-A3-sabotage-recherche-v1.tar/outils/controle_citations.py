#!/usr/bin/env python3
"""Controle des citations exactes d'un rapport contre le texte extrait page par page.

Format reconnu dans le rapport (une citation = un motif) :
    [IDENTIFIANT p. N] « citation exacte »
ou IDENTIFIANT est le nom du PDF sans extension (ex. 2604.16286v2).

Pour chaque citation, le texte de la page N (rang dans le fichier) est lu dans :
  1. texte/<ID>/pNNN.txt       (pdftotext -layout, page par page) ;
  2. texte-brut/<ID>/pNNN.txt  (pdftotext sans -layout, meme page, ordre de lecture),
     utilise seulement si le premier echoue (pages en deux colonnes, ou -layout
     entrelace les colonnes sur une meme ligne).
Tolerances, et seulement elles : blancs (espaces, tabulations, retours a la ligne)
et cesure de fin de ligne (trait d'union suivi d'un retour : mot recolle, ou trait
d'union garde). Aucune autre normalisation (ni apostrophes, ni ligatures, ni casse).

Sortie : une ligne par citation (OK ou ECHEC, mode qui a reussi), puis le bilan.
Code de sortie : 0 si toutes les citations passent, 1 sinon, 2 si aucune citation
n'est trouvee ou si une page est absente (aucun repli silencieux).
"""
import re
import sys
from pathlib import Path

MOTIF = re.compile(r"\[(\d{4}\.\d{5}v\d+) p\. (\d+)\] « (.+?) »", re.S)
CORRESPONDANCE_DOSSIERS = {"2606.08892v2": "2606.08892v2-complementaire"}


def blancs(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()


def variantes(texte: str) -> list:
    recolle = re.sub(r"-[ \t]*\n[ \t]*", "", texte)
    garde = re.sub(r"-[ \t]*\n[ \t]*", "-", texte)
    return [blancs(texte), blancs(recolle), blancs(garde)]


def page(racine: Path, sous_dossier: str, ident: str, n: int):
    dossier = CORRESPONDANCE_DOSSIERS.get(ident, ident)
    chemin = racine / sous_dossier / dossier / f"p{n:03d}.txt"
    if not chemin.is_file():
        return None, chemin
    return chemin.read_text(encoding="utf-8"), chemin


def controler(racine: Path, ident: str, n: int, citation: str):
    cible = blancs(citation)
    absentes = []
    for mode, sous_dossier in (("layout", "texte"), ("ordre de lecture", "texte-brut")):
        texte, chemin = page(racine, sous_dossier, ident, n)
        if texte is None:
            absentes.append(str(chemin))
            continue
        if any(cible in v for v in variantes(texte)):
            return True, mode, absentes
    return False, None, absentes


def main(argv):
    if len(argv) != 3:
        print("usage : controle_citations.py RACINE_TEXTES FICHIER_RAPPORT", file=sys.stderr)
        return 2
    racine, rapport = Path(argv[1]), Path(argv[2])
    contenu = rapport.read_text(encoding="utf-8")
    trouvees = MOTIF.findall(contenu)
    if not trouvees:
        print("ECHEC : aucune citation reconnue dans le rapport", file=sys.stderr)
        return 2
    echecs, pages_absentes = 0, 0
    for i, (ident, n, citation) in enumerate(trouvees, 1):
        ok, mode, absentes = controler(racine, ident, int(n), citation)
        if absentes:
            pages_absentes += 1
            print(f"PAGE ABSENTE\t{ident} p. {n}\t{absentes}")
        etat = f"OK ({mode})" if ok else "ECHEC"
        if not ok:
            echecs += 1
        extrait = blancs(citation)
        extrait = extrait if len(extrait) <= 90 else extrait[:87] + "..."
        print(f"{i:03d}\t{etat}\t{ident} p. {n}\t{extrait}")
    print(f"BILAN\tcitations controlees : {len(trouvees)}\techecs : {echecs}\tpages absentes : {pages_absentes}")
    if pages_absentes:
        return 2
    return 0 if echecs == 0 else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
