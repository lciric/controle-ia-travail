Cas juste (une ligne) : [2604.16286v2 p. 1] « the best performance was an AUROC of 0.77 and a top-1 fix rate of 42% »
Cas juste (sur deux lignes, blancs) : [2604.16286v2 p. 1] « We took 9 existing ML research codebases, created sabotaged versions that produce qualitatively different results, and wrote papers to reflect these results. »
Cas juste (cesure de fin de ligne) : [2604.22082v2 p. 1] « could exploit this gap through sandbagging »
Cas juste (apostrophe typographique exacte) : [2604.16286v2 p. 1] « Our benchmark measures auditors’ ability to detect whether a paper-codebase pair was sabotaged »
