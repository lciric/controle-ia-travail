Chiffre altere : [2604.16286v2 p. 1] « the best performance was an AUROC of 0.87 and a top-1 fix rate of 42% »
Mauvaise page : [2604.16286v2 p. 2] « the best performance was an AUROC of 0.77 and a top-1 fix rate of 42% »
Apostrophe droite au lieu de typographique : [2604.16286v2 p. 1] « Our benchmark measures auditors' ability to detect whether a paper-codebase pair was sabotaged »
Mot altere : [2604.22082v2 p. 1] « could exploit this gap through sandbaging »
