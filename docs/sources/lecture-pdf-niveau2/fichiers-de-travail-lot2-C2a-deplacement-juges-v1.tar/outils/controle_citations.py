#!/usr/bin/env python3
"""Contrôle des citations du lecteur C2a contre le texte extrait page par page.

Pour chaque citation (identifiant, article, page, texte), on cherche le texte dans
les extractions `pdftotext -layout` de CETTE page uniquement :
  - pNN.txt         page entière ;
  - pNN-gauche.txt  demi-page gauche (même outil, découpe -x/-W) ;
  - pNN-droite.txt  demi-page droite.
Les deux demi-pages servent aux articles en deux colonnes, où la page entière
entrelace les colonnes ligne à ligne.

Tolérances, et seulement celles-ci :
  - blancs : tous les caractères d'espacement sont retirés des deux côtés ;
  - césures : un trait d'union en fin de ligne suivi d'un saut de ligne est
    retiré du texte de la page (variante B), la variante sans retrait (A) étant
    aussi essayée (mots composés coupés à leur trait d'union).
Aucune autre normalisation : ni casse, ni guillemets, ni apostrophes, ni Unicode.

Gardes (règle R5, aucun repli silencieux) :
  - article inconnu ou fichier de page absent : erreur, la citation échoue ;
  - citation de moins de 20 caractères après retrait des blancs : refusée.

Usage :
  controle_citations.py TEXTES CITATIONS.tsv [--rapport RAPPORT.md]
Code de sortie 0 si toutes les citations passent, 1 sinon.
"""
import argparse
import csv
import os
import re
import sys

ARTICLES = {"2509.26072v2", "2601.13433v4", "2605.23970v1", "2604.21564v2"}
LONGUEUR_MIN = 20


def sans_blancs(s):
    return re.sub(r"\s+", "", s)


def sans_cesures(s):
    return re.sub(r"-[ \t]*\n[ \t]*", "", s)


def vues_page(textes, article, page):
    if article not in ARTICLES:
        raise ValueError("article inconnu : %r" % article)
    base = os.path.join(textes, article, "p%02d" % page)
    vues = {}
    for suffixe, nom in (("", "page"), ("-gauche", "gauche"), ("-droite", "droite")):
        chemin = base + suffixe + ".txt"
        if not os.path.isfile(chemin):
            raise FileNotFoundError("page absente : %s" % chemin)
        with open(chemin, encoding="utf-8") as f:
            vues[nom] = f.read()
    return vues


MARQUE = "\x00"  # trait d'union de fin de ligne, césure ou mot composé coupé


def motif_mixte(q):
    """Motif où chaque fin de ligne à trait d'union de la page (MARQUE) peut être
    sautée (césure) ou valoir le trait d'union de la citation (mot composé)."""
    morceaux = []
    for c in q:
        morceaux.append("(?:-|%s)" % MARQUE if c == "-" else re.escape(c))
    return re.compile((MARQUE + "?").join(morceaux))


def controler(textes, article, page, citation):
    """Rend (bool, détail)."""
    q = sans_blancs(citation)
    if len(q) < LONGUEUR_MIN:
        return False, "citation trop courte (%d caractères utiles)" % len(q)
    if MARQUE in q:
        return False, "caractère interdit dans la citation"
    try:
        vues = vues_page(textes, article, page)
    except (ValueError, FileNotFoundError) as e:
        return False, "erreur : %s" % e
    for nom, texte in vues.items():
        if q in sans_blancs(texte):
            return True, "trouvée (%s, blancs)" % nom
        if q in sans_blancs(sans_cesures(texte)):
            return True, "trouvée (%s, blancs et césures)" % nom
    motif = motif_mixte(q)
    for nom, texte in vues.items():
        marque = sans_blancs(re.sub(r"-[ \t]*\n[ \t]*", MARQUE, texte))
        if motif.search(marque):
            return True, "trouvée (%s, blancs et césures mixtes)" % nom
    return False, "introuvable sur la page %d" % page


def lire_citations(chemin):
    with open(chemin, encoding="utf-8", newline="") as f:
        lignes = [l for l in csv.reader(f, delimiter="\t") if l and not l[0].startswith("#")]
    entete = lignes[0]
    if entete != ["id", "article", "page", "citation"]:
        raise SystemExit("en-tête inattendu : %r" % entete)
    return [dict(zip(entete, l)) for l in lignes[1:]]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("textes")
    ap.add_argument("citations")
    ap.add_argument("--rapport")
    a = ap.parse_args()
    cits = lire_citations(a.citations)
    rapport = None
    if a.rapport:
        with open(a.rapport, encoding="utf-8") as f:
            rapport = f.read()
    echecs = 0
    for c in cits:
        ok, detail = controler(a.textes, c["article"], int(c["page"]), c["citation"])
        absent_rapport = rapport is not None and c["citation"] not in rapport
        statut = "OK" if ok and not absent_rapport else "ÉCHEC"
        if absent_rapport:
            detail += " ; ABSENTE du rapport mot pour mot"
        if statut != "OK":
            echecs += 1
        print("%-6s %-5s %s p.%s : %s" % (statut, c["id"], c["article"], c["page"], detail))
    print("Total : %d citations, %d contrôlées OK, %d en échec" % (len(cits), len(cits) - echecs, echecs))
    return 0 if echecs == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
