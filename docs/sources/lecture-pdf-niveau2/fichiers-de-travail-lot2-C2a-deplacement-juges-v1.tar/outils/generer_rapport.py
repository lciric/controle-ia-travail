#!/usr/bin/env python3
"""Produit rapport.md à partir du gabarit.

{{ID}} -> [ID] "citation" ; {{ID|code}} -> [ID] `citation` ; {{DATE_UTC}} ; {{N_CIT}}.
Échoue si un identifiant est inconnu, si une citation du fichier n'est pas utilisée,
ou s'il reste une double accolade.
"""
import csv
import datetime
import re
import sys

gabarit, citations, sortie = sys.argv[1:4]
with open(citations, encoding="utf-8", newline="") as f:
    lignes = [l for l in csv.reader(f, delimiter="\t") if l]
if lignes[0] != ["id", "article", "page", "citation"]:
    raise SystemExit("en-tête inattendu")
cit = {l[0]: l[3] for l in lignes[1:]}
texte = open(gabarit, encoding="utf-8").read()
utilises = set()


def remplacer(m):
    ident, mode = m.group(1), m.group(2)
    if ident == "DATE_UTC":
        return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M")
    if ident == "N_CIT":
        return str(len(cit))
    if ident not in cit:
        raise SystemExit("identifiant inconnu : %s" % ident)
    utilises.add(ident)
    if mode == "code":
        return "[%s] `%s`" % (ident, cit[ident])
    return '[%s] "%s"' % (ident, cit[ident])


texte = re.sub(r"\{\{([A-Z_]+(?:-\d+)?)(?:\|(code))?\}\}", remplacer, texte)
restes = re.findall(r"\{\{[^}]*\}\}", texte)
if restes:
    raise SystemExit("doubles accolades restantes : %r" % restes[:5])
inutiles = sorted(set(cit) - utilises)
if inutiles:
    raise SystemExit("citations non utilisées dans le rapport : %s" % ", ".join(inutiles))
with open(sortie, "w", encoding="utf-8") as f:
    f.write(texte)
print("rapport écrit : %d citations distinctes utilisées sur %d" % (len(utilises), len(cit)))
