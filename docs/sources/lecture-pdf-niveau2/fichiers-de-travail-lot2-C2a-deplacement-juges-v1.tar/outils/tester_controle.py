#!/usr/bin/env python3
"""Test du contrôle des citations sur des cas justes et des cas altérés (R5)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from controle_citations import controler  # noqa: E402

TEXTES = sys.argv[1]

CAS = [
    # (description, article, page, citation, attendu)
    ("juste : phrase sur une ligne (Silent Judge p.3)", "2509.26072v2", 3,
     "For GPT-4o on ELI5, the VSR reaches +30%, while Gemini-2.5-Flash shows a smaller but consistent", True),
    ("altéré : chiffre changé (+31 % au lieu de +30 %)", "2509.26072v2", 3,
     "For GPT-4o on ELI5, the VSR reaches +31%, while Gemini-2.5-Flash shows a smaller but consistent", False),
    ("altéré : bonne citation, mauvaise page (p.4)", "2509.26072v2", 4,
     "For GPT-4o on ELI5, the VSR reaches +30%, while Gemini-2.5-Flash shows a smaller but consistent", False),
    ("juste : césure en fin de ligne (Who Endorsed It p.1, « mod-/els »)", "2601.13433v4", 1,
     "we evaluate 11 models using personas representing four expertise levels per domain", True),
    ("altéré : un mot changé dans la même phrase (12 au lieu de 11)", "2601.13433v4", 1,
     "we evaluate 12 models using personas representing four expertise levels per domain", False),
    ("juste : apostrophe typographique (Nogueira p.17)", "2604.21564v2", 17,
     "discards information about how the model’s position evolved under pressure", True),
    ("altéré : apostrophe droite au lieu de typographique", "2604.21564v2", 17,
     "discards information about how the model's position evolved under pressure", False),
    ("juste : deux colonnes, citation sur plusieurs lignes d'une colonne (Faithful p.7)", "2605.23970v1", 7,
     "Across models, Baseline/SCoT show high flip-after-reveal rates (75–85%), while PBP is markedly lower (5–22%)", True),
    ("altéré : intervalle modifié (5–25 %)", "2605.23970v1", 7,
     "Across models, Baseline/SCoT show high flip-after-reveal rates (75–85%), while PBP is markedly lower (5–25%)", False),
    ("juste : césure et mot composé coupé dans la même citation (Who Endorsed It p.4)", "2601.13433v4", 4,
     "DeepSeek-R1-Qwen3-8B shows ∆H of -0.261, indicating increased confidence in the wrong answer.", True),
    ("altéré : même citation, valeur changée (-0.216)", "2601.13433v4", 4,
     "DeepSeek-R1-Qwen3-8B shows ∆H of -0.216, indicating increased confidence in the wrong answer.", False),
    ("limite assumée : trait d’union de fin de ligne omis, indécidable entre césure et mot composé (DeepSeekR1)", "2601.13433v4", 4,
     "DeepSeekR1-Qwen3-8B shows ∆H of -0.261, indicating increased confidence in the wrong answer.", True),
    ("garde : citation trop courte", "2509.26072v2", 3, "+30%", False),
    ("garde : page absente (p.99)", "2509.26072v2", 99,
     "For GPT-4o on ELI5, the VSR reaches +30%, while Gemini-2.5-Flash shows a smaller but consistent", False),
    ("garde : article inconnu", "2511.17220v1", 1,
     "For GPT-4o on ELI5, the VSR reaches +30%, while Gemini-2.5-Flash shows a smaller but consistent", False),
]

mauvais = 0
for desc, art, page, cit, attendu in CAS:
    ok, detail = controler(TEXTES, art, page, cit)
    bon = ok == attendu
    if not bon:
        mauvais += 1
    print("%s  attendu=%-5s obtenu=%-5s  %s — %s" % ("BON " if bon else "FAUX", attendu, ok, desc, detail))
print("Tests : %d cas, %d conformes, %d non conformes" % (len(CAS), len(CAS) - mauvais, mauvais))
sys.exit(0 if mauvais == 0 else 1)
