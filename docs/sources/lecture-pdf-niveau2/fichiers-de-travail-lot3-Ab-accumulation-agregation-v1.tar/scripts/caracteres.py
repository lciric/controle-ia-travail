import sys, collections, unicodedata
for chemin in sys.argv[1:]:
    with open(chemin, encoding="utf-8") as f:
        t = f.read()
    c = collections.Counter(ch for ch in t if ord(ch) > 127)
    print("==", chemin.split("/")[-2] + "/" + chemin.split("/")[-1])
    for ch, n in c.most_common(40):
        print(f"  U+{ord(ch):04X} {unicodedata.name(ch, '?')!s:40} {n}")
