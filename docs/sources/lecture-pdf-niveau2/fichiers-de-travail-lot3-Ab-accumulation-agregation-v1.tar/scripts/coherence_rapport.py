import json, re, sys
rapport, cits = sys.argv[1], sys.argv[2]
with open(cits, encoding="utf-8") as f:
    table = {c["id"]: c["citation"] for c in json.load(f)}
with open(rapport, encoding="utf-8") as f:
    texte = f.read()
ids_cites = set(re.findall(r"\[((?:SD|OB|SC)\d+b?)\]", texte))
ids_cites |= set(i for grp in re.findall(r"\[((?:(?:SD|OB|SC)\d+b?(?:, )?)+)\]", texte) for i in grp.split(", "))
inconnus = sorted(i for i in ids_cites if i not in table)
paires = re.findall(r"\[((?:SD|OB|SC)\d+b?)\] \"([^\"]+)\"", texte)
diff = [(i, q) for i, q in paires if table.get(i) != q]
print("identifiants cites :", len(ids_cites), "| inconnus :", inconnus)
print("citations reproduites mot pour mot :", len(paires), "| differentes :", len(diff))
for i, q in diff:
    print("  DIFF", i, "| rapport:", q[:80], "| json:", (table.get(i) or "")[:80])
