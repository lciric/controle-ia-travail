"""Controle des citations contre le texte extrait de la page indiquee.

Tolerance : seulement les blancs (tous supprimes) et les cesures de fin de ligne
(un tiret suivi d'un saut de ligne dans le texte de la page peut etre absent de la
citation, ou correspondre a un tiret reel de la citation).

Deux extractions de la meme page sont essayees, dans cet ordre :
  - "layout" : pdftotext -layout (textes/<pdf>/pNN.txt)
  - "brut"   : pdftotext sans -layout, ordre de lecture (textes/<pdf>-brut/pNN.txt)
Une page absente ou vide est une ERREUR (jamais un succes, pas de repli silencieux).

Usage :
  python3 -I controle_citations.py --textes DIR --citations FICHIER.json --sortie FICHIER.tsv
  python3 -I controle_citations.py --textes DIR --essai DOSSIER_ESSAI
"""
import argparse
import json
import os
import re
import sys

MARQUE = ""  # cesure de fin de ligne


def normaliser_page(texte):
    texte = re.sub(r"-[ \t]*\r?\n", MARQUE, texte)
    return re.sub(r"\s+", "", texte)


def motif_citation(citation):
    cit = re.sub(r"\s+", "", citation)
    if not cit:
        raise ValueError("citation vide")
    morceaux = []
    for c in cit:
        if c == "-":
            morceaux.append("(?:-|" + MARQUE + ")")
        else:
            morceaux.append(re.escape(c))
    return re.compile((MARQUE + "?").join(morceaux))


def lire_page(textes, pdf, page, mode):
    sous = pdf if mode == "layout" else pdf + "-brut"
    chemin = os.path.join(textes, sous, "p%02d.txt" % page)
    if not os.path.isfile(chemin):
        return None, "page absente : " + chemin
    with open(chemin, encoding="utf-8") as f:
        texte = f.read()
    if not texte.strip():
        return None, "page vide : " + chemin
    return texte, ""


def controler(textes, pdf, page, citation):
    """Renvoie (statut, mode, detail). statut : OK, ECHEC, ERREUR."""
    motif = motif_citation(citation)
    erreurs = []
    lues = 0
    for mode in ("layout", "brut"):
        texte, err = lire_page(textes, pdf, page, mode)
        if texte is None:
            erreurs.append(err)
            continue
        lues += 1
        if motif.search(normaliser_page(texte)):
            return "OK", mode, ""
    if lues == 0:
        return "ERREUR", "-", " ; ".join(erreurs)
    return "ECHEC", "-", " ; ".join(erreurs) if erreurs else "introuvable sur la page"


def essai(textes, dossier_essai):
    """Essais R5 : cas justes, cas alteres, artefacts (page absente, page vide)."""
    os.makedirs(os.path.join(dossier_essai, "X-brut"), exist_ok=True)
    os.makedirs(os.path.join(dossier_essai, "X"), exist_ok=True)
    open(os.path.join(dossier_essai, "X", "p01.txt"), "w").close()
    open(os.path.join(dossier_essai, "X-brut", "p01.txt"), "w").close()
    juste = ("a safety state world model that encodes LLM hidden states into a "
             "compact safety representation and predicts how it evolves across turns")
    cas = [
        ("juste", textes, "2604.16824v1", 1, juste, "OK"),
        ("juste, blancs ajoutes", textes, "2604.16824v1", 1,
         juste.replace(" ", "   \n "), "OK"),
        ("juste, cesure de fin de ligne (de-/tection)", textes, "2604.16824v1", 1,
         "CUSUM detection that accumulates weak per-turn risk signals into reliable evidence", "OK"),
        ("altere, un mot change", textes, "2604.16824v1", 1,
         juste.replace("compact", "complete"), "ECHEC"),
        ("altere, un chiffre change", textes, "2604.16824v1", 7,
         "achieves the highest AUROC (0.918) on XGuard-Train", "ECHEC"),
        ("juste, chiffre exact (controle du precedent)", textes, "2604.16824v1", 7,
         "achieves the highest AUROC (0.908) on XGuard-Train", "OK"),
        ("altere, mauvaise page", textes, "2604.16824v1", 2, juste, "ECHEC"),
        ("altere, tiret ajoute hors cesure", textes, "2604.16824v1", 5,
         "a sequential change-point de-tection method", "ECHEC"),
        ("altere, mot supprime", textes, "2607.11751v1", 10,
         "Thus, auditing more steps does not solve the problem", "ECHEC"),
        ("juste, deux colonnes (ordre de lecture)", textes, "2607.11751v1", 10,
         "Thus, auditing more steps does not by itself solve the problem: without "
         "additional local evidence, power comes from spending more false-positive budget.", "OK"),
        ("artefact, page absente", textes, "2604.16824v1", 99, juste, "ERREUR"),
        ("artefact, page vide", dossier_essai, "X", 1, juste, "ERREUR"),
    ]
    echecs = 0
    for nom, t, pdf, page, cit, attendu in cas:
        statut, mode, detail = controler(t, pdf, page, cit)
        bon = statut == attendu
        echecs += 0 if bon else 1
        print("%-48s attendu=%-6s obtenu=%-6s mode=%-6s %s %s" % (
            nom, attendu, statut, mode, "conforme" if bon else "NON CONFORME", detail))
    print("essais non conformes :", echecs, "sur", len(cas))
    return echecs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--textes", required=True)
    ap.add_argument("--citations")
    ap.add_argument("--sortie")
    ap.add_argument("--essai")
    a = ap.parse_args()
    if a.essai:
        sys.exit(1 if essai(a.textes, a.essai) else 0)
    with open(a.citations, encoding="utf-8") as f:
        citations = json.load(f)
    ids = [c["id"] for c in citations]
    if len(ids) != len(set(ids)):
        print("identifiants en double", file=sys.stderr)
        sys.exit(2)
    n_ok = n_echec = n_err = 0
    lignes = ["id\tpdf\tpage\tstatut\tmode\tdetail\tcitation"]
    for c in citations:
        statut, mode, detail = controler(a.textes, c["pdf"], int(c["page"]), c["citation"])
        n_ok += statut == "OK"
        n_echec += statut == "ECHEC"
        n_err += statut == "ERREUR"
        lignes.append("\t".join([c["id"], c["pdf"], str(c["page"]), statut, mode, detail,
                                 c["citation"]]))
    with open(a.sortie, "w", encoding="utf-8") as f:
        f.write("\n".join(lignes) + "\n")
    print("citations :", len(citations), "| OK :", n_ok, "| ECHEC :", n_echec, "| ERREUR :", n_err)
    for l in lignes[1:]:
        champs = l.split("\t")
        if champs[3] != "OK":
            print("  ", champs[0], champs[1], "p.", champs[2], champs[3], champs[5], "|", champs[6][:90])
    sys.exit(0 if (n_echec == 0 and n_err == 0) else 1)


if __name__ == "__main__":
    main()
