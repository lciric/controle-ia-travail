#!/usr/bin/env python3
"""Controle des citations contre le texte extrait page par page.

Usage : python3 -I controle_citations.py DOSSIER_TRAVAIL FICHIER_CITATIONS.jsonl

Chaque ligne du fichier JSONL : {"id": "...", "pdf": "2506.14261v4", "page": 3, "citation": "..."}

Regle de tolerance (consigne commune, point 5) : seules les differences de blancs
et de cesures sont tolerees.
  - blancs : tous les blancs (espaces, tabulations, retours a la ligne) sont retires
    des deux cotes avant comparaison ;
  - cesures : un trait d'union suivi d'un retour a la ligne dans le texte de la page
    est marque ; ce marqueur peut etre absent de la citation (mot recolle) ou
    correspondre a un trait d'union de la citation (trait d'union reel en fin de ligne).
Aucune autre normalisation (ni casse, ni ligatures, ni guillemets, ni Unicode).

Texte de la page : d abord l extraction `pdftotext -layout` de la page indiquee ;
en cas d echec, l extraction `pdftotext -raw` (ordre du flux, cesures conservees) de la
MEME page (utile pour les pages a deux colonnes, que -layout entrelace).
La page n'est jamais changee : une citation absente de la page indiquee echoue.
"""
import json
import re
import sys
from pathlib import Path

MARQUEUR = "\x00"


def normaliser_page(texte: str) -> str:
    # cesure : trait d'union + blancs contenant un retour a la ligne -> marqueur
    texte = re.sub(r"-[ \t]*\n\s*", MARQUEUR, texte)
    # blancs retires
    return re.sub(r"\s+", "", texte)


def motif_citation(citation: str) -> "re.Pattern[str]":
    sans_blancs = re.sub(r"\s+", "", citation)
    if not sans_blancs:
        raise ValueError("citation vide")
    morceaux = []
    for c in sans_blancs:
        if c == "-":
            morceaux.append("(?:-|" + MARQUEUR + ")")
        else:
            morceaux.append(re.escape(c))
    # entre deux caracteres, une cesure recollee (marqueur) est toleree
    return re.compile((MARQUEUR + "?").join(morceaux))


def controler(dossier: Path, pdf: str, page: int, citation: str) -> str:
    """Rend "layout", "raw" ou '' (echec)."""
    nom = f"p{page:02d}.txt"
    motif = motif_citation(citation)
    for mode, sous_dossier in (("layout", "texte"), ("raw", "texte_brut")):
        chemin = dossier / sous_dossier / pdf / nom
        if not chemin.is_file():
            raise FileNotFoundError(f"page absente : {chemin}")
        if motif.search(normaliser_page(chemin.read_text(encoding="utf-8"))):
            return mode
    return ""


def main() -> int:
    dossier = Path(sys.argv[1])
    fichier = Path(sys.argv[2])
    total = echecs = 0
    for numero, ligne in enumerate(fichier.read_text(encoding="utf-8").splitlines(), 1):
        if not ligne.strip():
            continue
        e = json.loads(ligne)
        total += 1
        mode = controler(dossier, e["pdf"], int(e["page"]), e["citation"])
        if mode:
            print(f"OK     [{mode:7s}] {e['id']:10s} {e['pdf']} p.{e['page']}")
        else:
            echecs += 1
            print(f"ECHEC  [-------] {e['id']:10s} {e['pdf']} p.{e['page']} :: {e['citation'][:90]}")
    print(f"--- {total} citations controlees, {echecs} echec(s)")
    return 1 if echecs else 0


if __name__ == "__main__":
    sys.exit(main())
