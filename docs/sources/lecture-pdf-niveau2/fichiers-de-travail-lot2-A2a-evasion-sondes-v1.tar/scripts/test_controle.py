import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(sys.argv[1]) / "scripts"))
from controle_citations import controler
D = Path(sys.argv[1])
cas = [
 # (nom, pdf, page, citation, attendu_ok)
 ("juste-1", "2506.14261v4", 1, "We find that token-level monitors are highly vulnerable to this attack while more holistic monitors, such as max-pooling or attention-based probes, remain robust.", True),
 ("altere-mot", "2506.14261v4", 1, "We find that token-level monitors are highly robust to this attack while more holistic monitors, such as max-pooling or attention-based probes, remain robust.", False),
 ("juste-cesure", "2506.14261v4", 1, "these monitors may themselves become training signals", True),
 ("juste-tiret-reel", "2506.14261v4", 2, "stress-test latent-space monitors", True),
 ("mauvaise-page", "2506.14261v4", 2, "We find that token-level monitors are highly vulnerable to this attack", False),
 ("altere-chiffre", "2412.09565v2", 1, "our attacks can often reduce recall from 100% to 10% while retaining a 90% jailbreaking rate", False),
 ("juste-chiffre", "2412.09565v2", 1, "our attacks can often reduce recall from 100% to 0% while retaining a 90% jailbreaking rate", True),
 ("altere-casse", "2412.09565v2", 1, "Our attacks can often reduce recall from 100% to 0% while retaining a 90% jailbreaking rate", False),
 ("juste-2col", "2602.15515v2", 1, "Training against white-box deception detectors has been proposed as a way to make AI systems honest.", True),
 ("altere-2col", "2602.15515v2", 1, "Training against white-box deception detectors has never been proposed as a way to make AI systems honest.", False),
]
bons = 0
for nom, pdf, page, cit, attendu in cas:
    mode = controler(D, pdf, page, cit)
    ok = bool(mode)
    verdict = "conforme" if ok == attendu else "NON CONFORME"
    bons += ok == attendu
    print(f"{nom:18s} attendu={'OK' if attendu else 'ECHEC':5s} obtenu={('OK['+mode+']') if ok else 'ECHEC':14s} -> {verdict}")
print(f"--- {bons}/{len(cas)} cas conformes")
