#!/usr/bin/env python3
"""Rend rapport.md a partir du gabarit et du fichier de citations controlees.

Usage : python3 -I rendre_rapport.py DOSSIER_TRAVAIL

- {{ID}}            -> « citation exacte » [ID, p. N]   (texte copie du fichier controle)
- {{ANNEXE}}        -> table de toutes les citations (ID, PDF, page, mode du controle, texte)
- {{BILAN}}         -> derniere ligne de la sortie du controle
Echoue (code 1) si un identifiant est inconnu, si un espace reserve reste non resolu,
ou si la sortie du controle signale un echec. Aucun repli silencieux.
"""
import json
import re
import sys
from pathlib import Path


def main() -> int:
    d = Path(sys.argv[1])
    cit = {}
    for ligne in (d / "citations.jsonl").read_text(encoding="utf-8").splitlines():
        if ligne.strip():
            e = json.loads(ligne)
            if e["id"] in cit:
                print(f"identifiant en double : {e['id']}")
                return 1
            cit[e["id"]] = e
    sortie = (d / "controle-citations-sortie.txt").read_text(encoding="utf-8").splitlines()
    modes = {}
    for l in sortie:
        m = re.match(r"^(OK|ECHEC)\s+\[(\w+|-+)\s*\]\s+(\S+)", l)
        if m:
            if m.group(1) != "OK":
                print(f"le controle signale un echec : {l}")
                return 1
            modes[m.group(3)] = m.group(2)
    if set(modes) != set(cit):
        print("la sortie du controle ne couvre pas exactement les citations du fichier")
        return 1
    bilan = sortie[-1].strip("- ").strip()

    gabarit = (d / "rapport-gabarit.md").read_text(encoding="utf-8")
    utilises = set()

    def remplacer(m: "re.Match[str]") -> str:
        cle = m.group(1)
        if cle == "ANNEXE":
            lignes = ["| ID | PDF | page | mode du contrôle | citation exacte |", "|---|---|---|---|---|"]
            for i, e in cit.items():
                t = e["citation"]
                t = f"`{t}`" if any(ch in t for ch in "*_") else t
                lignes.append(f"| {i} | {e['pdf']} | {e['page']} | {modes[i]} | {t} |")
            return "\n".join(lignes)
        if cle == "BILAN":
            return bilan
        if cle == "NCIT":
            return str(len(cit))
        if cle == "NLAYOUT":
            return str(sum(1 for v in modes.values() if v == "layout"))
        if cle == "NRAW":
            return str(sum(1 for v in modes.values() if v == "raw"))
        if cle == "FICHIERS":
            import hashlib
            noms = ["citations.jsonl", "controle-citations-sortie.txt", "rapport-gabarit.md",
                    "scripts/controle_citations.py", "scripts/test_controle.py", "scripts/rendre_rapport.py",
                    "attendues.sha256"]
            lignes = []
            for n in noms:
                h = hashlib.sha256((d / n).read_bytes()).hexdigest()
                lignes.append(f"- `{n}` : `{h}`")
            return "\n".join(lignes)
        if cle not in cit:
            raise KeyError(f"identifiant inconnu : {cle}")
        utilises.add(cle)
        e = cit[cle]
        texte = e["citation"]
        if any(ch in texte for ch in "*_`"):
            if "`" in texte:
                raise KeyError(f"accent grave dans la citation {cle}")
            return f"`« {texte} »` [{cle}, p. {e['page']}]"
        return f"« {texte} » [{cle}, p. {e['page']}]"

    try:
        rendu = re.sub(r"\{\{([A-Z]+[0-9]*)\}\}", remplacer, gabarit)
    except KeyError as err:
        print(err)
        return 1
    reste = re.findall(r"\{\{[^}]*\}\}", rendu)
    if reste:
        print(f"espaces reserves non resolus : {reste}")
        return 1
    for e in cit.values():
        if "|" in e["citation"]:
            print(f"barre verticale dans une citation : {e['id']}")
            return 1
    (d / "rapport.md").write_text(rendu, encoding="utf-8")
    non_utilises = sorted(set(cit) - utilises)
    print(f"rapport rendu ; {len(utilises)} citations utilisees dans le corps ; non utilisees dans le corps (annexe seulement) : {non_utilises}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
