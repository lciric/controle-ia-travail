# Lecture de niveau 2, lot 2 — A2a « évasion de sondes » — rapport du lecteur

- **Date** : 2026-10-06, rapport établi vers 16 h 45 (temps universel coordonné) ; lecture commencée à 16 h 15.
- **Lecteur** : sous-agent neuf ; n'a écrit aucun des documents vérifiés ; aucune modification sous `/home/user/controle-ia` (lecture seule).
- **Consignes appliquées** : `lot2/consigne-commune.md` et `lot2/consignes-A2a-evasion-sondes.md` ; règles R7 (chiffre opposable seulement sur PDF empreinté, page et citation exacte), R8 (une limitation d'un papier n'est pas un trou du champ), R5 (contrôle testé sur cas juste et cas altéré).
- **Sources des affirmations** : « L70 » et « L134 » = `docs/etat-de-l-art-controle-ia-v1.md`, lignes 70 et 134 ; « L170 » = `docs/etat-de-l-art/etat-de-l-art-verifie-niveau1-v1.md`, ligne 170 (section 5, « Références nouvelles à lire » ; « Tr. » y désigne l'hypothèse de transposition jeton → action).

## 0. PDF lus et empreintes

Dossier des PDF (Portable Document Format) : `/home/user/controle-ia/docs/sources/pdf/`. Empreintes SHA-256 (Secure Hash Algorithm, 256 bits) recalculées avec `sha256sum -c` : **5 sur 5 conformes** aux consignes. Le même contrôle refuse une empreinte volontairement altérée (code retour 1).

| PDF | pages | empreinte SHA-256 (attendue = calculée) | lecture |
|---|---|---|---|
| `2506.14261v4.pdf` | 24 | `4b0960622664e77d888974955b29f9c0e5913266392caeecac2b844f011e244c` | en entier |
| `2412.09565v2.pdf` | 51 | `9c23a613c5c7e3a213a60eca7cb990b4b7d6e0510db30584736aa021dfb944e9` | p. 1 à 30 et 41 à 51 en entier ; références p. 30 à 40 parcourues par recherche de mots |
| `2512.11949v1.pdf` | 30 | `e0f8ddfff6e75d835995886a630a5d077ed871c28599f710b41c96efc949e3ee` | en entier, sauf exemples qualitatifs en images (bas de la p. 27, p. 28 à 30) |
| `2601.11516v4.pdf` | 40 | `c4a36db54c9d679a718a0e35b9cad09fa628d81f6174bb6e1d8c6b26a063d8bf` | en entier, annexes A à L comprises ; références p. 20 à 23 parcourues |
| `2602.15515v2.pdf` | 30 | `f6547ec830104abf8ceca353e46e32ee78453f6470fd1c03053e13834ebc54cb` | en entier |

**Méthode de lecture.** Texte extrait page par page avec `pdftotext -layout` (version 24.02.0) ; les pages citées sont le rang dans le fichier (pour ces cinq PDF, il coïncide avec le numéro imprimé). Les valeurs portées seulement par des figures (barres, nuages de points) n'ont pas été relevées, sauf mention « figure ».

**Ce qui n'a pas été lu.** 2412.09565v2 : références (p. 30 à 40), parcourues seulement par recherche de mots (« ICLR », « conference », « published », « under review », « proceedings », « tax »). 2512.11949v1 : bas de la p. 27 et p. 28 à 30, exemples qualitatifs en images sans couche texte (vérifié avec `pdfimages` ; 1 à 4 mots de texte par page). Ailleurs, les références ont été parcourues sans lecture ligne à ligne.

## 1. Contrôle des citations (consigne commune, point 5)

- **Script** : `scripts/controle_citations.py`. Il ne tolère que les blancs (retirés des deux côtés) et les césures (un trait d'union suivi d'un retour à la ligne peut manquer dans la citation, ou y correspondre à un vrai trait d'union). Aucune autre normalisation : ni casse, ni ligatures, ni guillemets. Texte comparé : d'abord l'extraction `-layout` de la page indiquée ; à défaut, l'extraction `pdftotext -raw` de **la même page**, qui garde les césures et suit l'ordre des colonnes (nécessaire pour les pages à deux colonnes, que `-layout` entrelace). La page n'est jamais changée, et le mode retenu est affiché pour chaque citation : aucun repli silencieux.
- **Tests préalables (R5)** : `scripts/test_controle.py`, 10 cas sur 10 conformes. 5 cas justes acceptés : phrase simple, césure recollée, trait d'union réel en fin de ligne, chiffres, page à deux colonnes. 5 cas altérés refusés : un mot changé, un chiffre changé, une majuscule changée, une bonne citation sur la mauvaise page, une page à deux colonnes altérée.
- **Résultat** (dernière ligne de la sortie brute du script) : « {{BILAN}} » ; {{NLAYOUT}} citations retrouvées dans le texte `-layout`, {{NRAW}} dans le texte `-raw`. Détail : `controle-citations-sortie.txt`.
- **Pas de recopie à la main** : chaque citation de ce rapport est injectée depuis `citations.jsonl`, le fichier même qui a été contrôlé, par `scripts/rendre_rapport.py` (qui échoue sur tout identifiant inconnu ou espace réservé non résolu). Les citations contenant un astérisque sont mises en texte littéral pour que le Markdown ne les transforme pas.

## 2. Sigles anglais présents dans les citations (développés)

FPR = false positive rate, taux de faux positifs ; FNR = false negative rate, taux de faux négatifs ; TPR = true positive rate, taux de vrais positifs (rappel) ; LLM = large language model, grand modèle de langage ; MLP = multilayer perceptron, perceptron multicouche ; SAE = sparse autoencoder, autoencodeur parcimonieux ; RL = reinforcement learning, apprentissage par renforcement ; RLVR = reinforcement learning with verifiable rewards, apprentissage par renforcement à récompenses vérifiables ; GRPO = Group Relative Policy Optimization, optimisation de politique relative par groupe ; OAT = Obfuscated Adversarial Training, entraînement adversarial contre l'obfuscation ; SRR = StrongReject Reward, récompense donnée par le juge StrongREJECT ; SQL = Structured Query Language, langage de requête structuré ; HTML = HyperText Markup Language ; EMA = exponential moving average, moyenne mobile exponentielle ; MBPP = Mostly Basic Python Problems (jeu de problèmes de programmation) ; RepE = Representation Engineering (jeu de données de tromperie) ; RQ2 = research question 2, deuxième question de recherche ; GPU = graphics processing unit, processeur graphique ; ML = machine learning, apprentissage automatique ; AI = artificial intelligence, intelligence artificielle ; NeurIPS = Neural Information Processing Systems ; PMLR = Proceedings of Machine Learning Research ; cs.LG = rubrique « Machine Learning » d'arXiv ; FAR.AI = nom d'organisation. Dans les affirmations du programme : ICLR = International Conference on Learning Representations ; SQL = Structured Query Language, langage de requête structuré.

---

## 3. Article 1 — RL-Obfuscation (arXiv 2506.14261v4)

### Identité

- **Titre** : RL-Obfuscation: Can Language Models Learn to Evade Latent-Space Monitors? (petites capitales p. 1 ; identique dans les métadonnées du PDF).
- **Auteurs (tous)** : {{R01}}. Affiliation imprimée sous le premier nom : {{R28}}.
- **Version et date** : {{R02}}.
- **Venue** : aucune imprimée dans le PDF. Attestation secondaire seulement, dans la bibliographie d'un autre article du lot : {{A12}}.
- **Cadre** : {{R26}} ; {{R25}} ; contenu nocif {{R29}} ; sondes figées, une couche par modèle : {{R24}}.

### Affirmations du programme

| # | affirmation du programme | verdict | page | citation exacte |
|---|---|---|---|---|
| 1.1 | « Gupta & Jenner, arXiv 2506.14261 » (L70, L134) | **confirmé** | 1 | {{R01}} ; {{R02}} |
| 1.2 | « évasion par apprentissage par renforcement sur les poids, sans gradient à travers le moniteur » (L70) ; « apprentissage par renforcement sur les poids » (L134) | **confirmé** | 2 | {{R03}} |
| 1.3 | « les sondes à max ou à attention résistent » (L70) ; « max et attention robustes » (L134) | **confirmé**, au sens des auteurs : l'apprentissage par renforcement n'a pas obtenu contre elles d'évasion qui garde des réponses de qualité (voir 1.6 et les réserves) | 1 ; 7 | {{R04}} ; {{R07}} |
| 1.4 | « la moyenne, la médiane […] cèdent » (L70) ; « moyenne, médiane […] vulnérables » (L134) | **confirmé** | 5 ; 7 | {{R05}} ; {{R21}} |
| 1.5 | « […] et les scores par token cèdent » (L70) ; « […] et par-token vulnérables » (L134) | **corrigé**. En L70, remplacer « la moyenne, la médiane et les scores par token cèdent » par « l'agrégation par moyenne ou par médiane des scores par jeton cède ». En L134, remplacer « moyenne, médiane et par-token vulnérables » par « agrégation par moyenne ou par médiane des scores par jeton vulnérable ». Motif : tous les moniteurs de l'article notent chaque jeton puis agrègent ; une sonde linéaire entraînée jeton par jeton puis agrégée par max résiste (0,058 et 0,044 d'évasion) ; les auteurs opposent des agrégations, non le calcul par jeton. Les « token-level monitors » du résumé (1.3) sont les sondes agrégées par moyenne ou médiane. | 4 ; 7 | {{R09}} ; {{R08}} ; {{R07}} ; {{R06}} |
| 1.6 | statut « **Établi** » (L70) | **corrigé** (portée). Remplacer « **Établi** : au niveau token, les sondes à max ou à attention résistent à l'évasion par apprentissage par renforcement sur les poids, sans gradient à travers le moniteur » par « **Établi dans le cadre testé** (nocivité jugée par StrongREJECT, modèles de 7 à 14 milliards de paramètres, sondes entraînées sur une couche) : au niveau du jeton, l'apprentissage par renforcement sur les poids, sans gradient à travers le moniteur, n'a pas obtenu contre les agrégations max ou attention d'évasion qui préserve la qualité des réponses ; les auteurs avertissent qu'un tel échec peut tenir à des difficultés d'optimisation plutôt qu'à une robustesse fondamentale ». | 10 ; 6 ; 19 | {{R10}} ; {{R11}} ; {{R12}} ; {{R27}} |

### Chiffres utilisables

- **Tableau 1 (auteurs)** — {{R30}} Lignes (colonnes : Llama 3 8B, Qwen 2.5 14B, Llama 2 7B ; pour chacune, taux d'évasion puis récompense StrongREJECT sur 5) : {{R21}} ; {{R07}} ; {{R19}}.
- **Rappel correspondant (calcul : rappel = 1 − taux d'évasion, d'après la légende du tableau 1)** : sonde linéaire agrégée par max, 0,942 (Llama 3 8B) et 0,956 (Qwen 2.5 14B) ; sonde linéaire agrégée par moyenne, 0,25 et 0,18.
- **Tableau 4, Llama 2 7B (auteurs)** : sonde linéaire à max {{R13}} (évasion, récompense StrongREJECT, taux de vrais positifs du modèle de base) ; sonde linéaire à moyenne {{R20}}.
- **Règle des auteurs pour juger une évasion** : {{R12}}.
- **Part du changement de comportement dans la baisse de rappel (auteurs)** : {{R17}}.

### Réserves de lecture (R4, symétrie)

- Sur Llama 2 7B, les lignes « max » du tableau 4 et la case Llama 2 7B de la ligne linéaire (max) du tableau 1 montrent une évasion presque totale obtenue en sacrifiant la qualité (récompense 1,0 sur 5) : « résister » veut dire ici « pas d'évasion utile », non « score inchangé » — {{R27}} ; {{R14}}. Sur Llama 3 8B et Qwen 2.5 14B, en revanche, la sonde linéaire à max résiste en gardant une qualité élevée (récompense 4,78 et 4,96, {{R07}}).
- Sur Llama 3 8B, la ligne attention (moyenne) du tableau 1 a une récompense de 1,08 sur 5 ({{R19}}) : run dégénéré, sans évasion ni qualité ; il ne montre pas la résistance de l'attention face à un attaquant qui garde des réponses utiles.
- Écart entre tableaux pour une même ligne (sonde linéaire à moyenne, Llama 2 7B : récompense 3,85 au tableau 1, 3,72 au tableau 4) : runs distincts, issus de recherches d'hyperparamètres différentes — {{R22}} ; {{R23}}. Ne pas mêler les deux tableaux.

### Antériorité (R8)

- **Transposition jeton → action** : non occupée. L'article est la source du constat au niveau du jeton ; il ne porte que sur des sondes appliquées à la génération d'une réponse ({{R15}}), dans le seul cadre de la nocivité ({{R11}}), et renvoie à plus tard les mensonges et les manigances ({{R16}}). Aucune agrégation sur des actions ou des trajectoires. Un autre article du lot décrit son mécanisme d'évasion comme purement syntaxique : {{A19}}.
- **HC2b** : non occupée. Seule observation voisine, pendant l'entraînement et non face à un moniteur : {{R18}}.
- **H2, H1, lemme d'additivité, théorème négatif, HC1, papier B** : non touchés (aucune accumulation séquentielle ; le juge StrongREJECT sert de récompense, non de moniteur concurrent ; aucun budget total ; un seul modèle).

---

## 4. Article 2 — Bailey et al., Obfuscated Activations (arXiv 2412.09565v2)

### Identité

- **Titre** : Obfuscated Activations Bypass LLM Latent-Space Defenses (p. 1 ; le PDF n'a pas de titre dans ses métadonnées).
- **Auteurs (tous, dans l'ordre)** : {{B02}} ; {{B03}} (l'astérisque marque les contributeurs principaux).
- **Version et date** : {{B01}}.
- **Venue** : aucune imprimée (voir 2.2).
- **Cadre** : attaques d'« obfuscation » (suffixes d'embedding ou en jetons réels, réglage fin, empoisonnement de données) contre des moniteurs d'activations (sondes, détecteurs hors distribution, autoencodeurs parcimonieux) ; métrique {{B05}} ; modèle {{B06}}.

### Affirmations du programme

| # | affirmation du programme | verdict | page | citation exacte |
|---|---|---|---|---|
| 2.1 | « Bailey et al., arXiv 2412.09565 » (L134) | **confirmé** | 1 | {{B01}} ; {{B02}} |
| 2.2 | « ICLR 2026 » (L134) | **introuvable** dans le PDF empreinté : la v2 (8 février 2025) n'imprime aucune venue ; recherche faite sur les 51 pages de « ICLR », « conference », « published », « under review », « proceedings » (seules sortent des références à d'autres travaux). Attestation secondaire seulement, dans la bibliographie de 2602.15515v2 (ci-contre). Formulation à retenir tant que la version publiée n'est pas empreintée : « arXiv 2412.09565 (v2, 8 février 2025) ; parution à la quatorzième International Conference on Learning Representations (2026) attestée seulement par la bibliographie de arXiv 2602.15515v2, p. 10 ». | 2602.15515v2, p. 10 | {{A11}} |
| 2.3 | « sur Llama-3-8B-Instruct » (L134) | **confirmé** | 7 ; 8 | {{B06}} ; {{B07}} |
| 2.4 | « le rappel de sondes de nocivité tombe de 100 % à 0 % à 1 % de faux positifs tout en gardant environ 90 % de contournement » (L134) | **corrigé** (nuances omises). Remplacer par : « des attaques d'obfuscation, surtout par suffixe d'embedding (accès boîte blanche), font **souvent** tomber le rappel à 1 % de faux positifs de sondes de nocivité — agrégées pour la plupart par une moyenne sur les couches et les jetons — de 100 % à 0 % tout en gardant un taux de contournement de 90 % ; les suffixes en jetons réels n'obtiennent qu'une obfuscation partielle ». | 1 ; 6 ; 9 ; 8 ; 29 ; 5 | {{B04}} ; {{B05}} ; {{B09}} ; {{B25}} ; {{B08}} ; {{B21}} ; {{B19}} |
| 2.5 | « « taxe d'obfuscation » sur une tâche SQL, croissante avec le nombre de couches obfusquées » (L134) | **corrigé**. Le sens (un coût en performance qui croît avec le nombre de couches obfusquées) est confirmé. Mais le terme cité est absent de l'article (« tax » : 0 occurrence sur les 51 pages ; « capability tax » vient de Neural Chameleons, qui le juge négligeable : {{N21}}) ; et l'expérience porte sur Gemma-2-2b, non sur Llama-3-8B-Instruct. Remplacer par : « compromis entre obfuscation et performance (“trade-off between obfuscation and model performance”) sur l'écriture de requêtes SQL (Structured Query Language) évaluée par SQLEval, avec Gemma-2-2b : la part de requêtes correctes (34,8 % sans obfuscation) baisse quand on obfusque contre davantage de couches ». | 3 ; 23 ; 21 ; 48 ; 49 | {{B11}} ; {{B12}} ; {{B13}} ; {{B22}} ; {{B14}} ; {{B15}} |
| 2.6 | « code public » (L134) | **confirmé** | 1 | {{B16}} |

### Chiffres utilisables

- **Résumé (auteurs)** : {{B04}}.
- **Sans entraînement adversarial contre l'obfuscation (OAT, Obfuscated Adversarial Training), contre une sonde à régression logistique, Llama-3-8B-Instruct (auteurs)** : {{B10}} ; **avec cet entraînement** : {{B24}}.
- **Entraînement adversarial des moniteurs (auteurs)** : {{B23}}.
- **Requêtes SQL (auteurs)** : {{B14}} (légende de la figure 15) ; intervalles de confiance à 95 % de la corrélation de Pearson entre nombre de couches obfusquées et performance, colonnes « autoencodeur brut, autoencodeur + régression logistique, régression logistique, perceptron multicouche » : {{B15}}.

### Antériorité (R8)

- **Transposition jeton → action** : non occupée (ni action ni trajectoire). L'article borne toutefois le constat « max robuste » de l'article 1 à sa menace sans gradient : dans l'étude SQL, les moniteurs agrégés par max sur la séquence ({{B17}}) tombent à un rappel quasi nul sous attaque par suffixe d'embedding ({{B18}}). Les résultats sur la nocivité portent surtout sur des agrégations par moyenne ({{B19}}).
- **H2** : non occupée. L'article justifie seulement le calibrage d'un seuil à 1 % de faux positifs sur des exemples négatifs, pour une décision isolée : {{B20}}.
- **H1, lemme d'additivité, théorème négatif, HC1, HC2b, papier B** : non touchés.

---

## 5. Article 3 — Neural Chameleons (arXiv 2512.11949v1)

### Identité

- **Titre imprimé** : {{N03}}. Les métadonnées du PDF, et les consignes, portent « … from Unseen Activation Monitors » : le mot « Unseen » n'est pas dans le titre imprimé.
- **Auteurs (tous)** : {{N01}} ; {{N20}} (McGuinness et Serrano) ; {{N19}} (Bailey et Emmons).
- **Version et date** : {{N02}}.
- **Venue** : aucune imprimée.
- **Cadre** : réglage fin d'un modèle pour qu'il fasse baisser, sur déclencheur explicite, des sondes de concepts anodins ; test sur des sondes de sécurité jamais vues, entraînées après coup sur le modèle figé ; Gemma-2-9b-it surtout, plus Gemma-2-2b-it, Llama-3.1-8b-instruct et Qwen-2.5-7b-instruct ; seuil calibré à 1 % de faux positifs.

### Affirmations du programme

| # | affirmation du programme | verdict | page | citation exacte |
|---|---|---|---|---|
| 3.1 | « Neural Chameleons (McGuinness, Serrano, Bailey, Emmons), arXiv 2512.11949 » (L134) | **confirmé** | 1 | {{N01}} ; {{N02}} |
| 3.2 | « auto-obfuscation apprise par réglage fin » (L134) | **confirmé** (réglage fin des poids du modèle sur une perte définie par les scores de sondes d'entraînement figées, donc avec gradient à travers ces sondes ; comportement déclenché par une phrase explicite) | 1 ; 11 ; 5 ; 6 ; 2 | {{N04}} ; {{N06}} ; {{N22}} ; {{N13}} ; {{N07}} |
| 3.3 | « généralisée à des concepts non vus » (L134) | **confirmé** (concepts et moniteurs non vus) | 1 | {{N05}} |

### Chiffres utilisables

- **Sélectivité (auteurs)** : {{N14}}.
- **Mécanisme (auteurs)** : {{N16}}.
- **Langues non vues (auteurs)** : {{N15}}.
- **Coût en capacités, modèle aligné (auteurs)** : {{N17}}.
- **Témoin sans réglage fin (auteurs)** : {{N18}}.

### Antériorité (R8)

- **Transposition jeton → action** : non occupée (une réponse à la fois ; sondes par jeton agrégées par moyenne : {{N10}}). L'article borne toutefois le constat « attention robuste » de l'article 1 à sa menace : sous auto-obfuscation apprise, {{N08}} ; {{N09}}.
- **HC2b** : touchée à la marge, non occupée. (a) Sur le modèle de base, observation de même signe que HC2b, mais sans tentative de manipulation : {{N11}}. (b) Idée non testée : {{N12}}. (c) Chez le modèle entraîné à l'évasion, la tentative (le déclencheur) fait au contraire baisser les scores : {{N05}}.
- **H2, H1, lemme d'additivité, théorème négatif, HC1, papier B** : non touchés.

---

## 6. Article 4 — Building Production-Ready Probes For Gemini (arXiv 2601.11516v4)

### Identité

- **Titre** : Building Production-Ready Probes For Gemini (p. 1 et métadonnées).
- **Auteurs (tous)** : {{G01}} ; {{G02}}.
- **Version et date** : {{G03}} ; en-tête de la p. 1 : {{G23}}.
- **Venue** : aucune imprimée (prépublication de Google DeepMind sur arXiv).
- **Cadre** : sondes sur les entrées de Gemini 2.5 Flash pour détecter des demandes de cyberattaque ({{G21}}) ; comparaison d'agrégations et de classifieurs à base de grands modèles de langage ; seuils choisis sur validation par une erreur pondérée : {{G22}}.

### Affirmations du programme

| # | affirmation du programme | verdict | page | citation exacte |
|---|---|---|---|---|
| 4.1 | « Kramár et al. 2026, arXiv 2601.11516 » (L170) | **confirmé** (Kramár est premier auteur, à contribution égale avec Conmy) | 1 | {{G01}} ; {{G02}} ; {{G03}} |
| 4.2 | rangement sous « Tr. » (transposition jeton → action) (L170) | **confirmé**, pertinence limitée au niveau du jeton : l'article compare des agrégations sur les jetons d'une entrée (longue ou à plusieurs tours) et déclare ne pas étudier le signalement d'un déroulé en cours | 7 ; 19 | {{G04}} ; {{G05}} |

### Chiffres utilisables

Tableau 3 (auteurs ; seuil choisi par erreur pondérée, non à 1 % de faux positifs). Colonnes, dans l'ordre : faux positifs sur contexte court hors sujet (SC[OT], short context, overtriggering), sur contexte court « négatifs difficiles » (SC[HN], hard negatives), sur contexte long aléatoire (LC[RT], long context, random traffic), sur conversations à plusieurs tours « négatifs difficiles » (MT[HN], multi-turn) ; puis faux négatifs sur attaques en contexte court (SC[A]), en contexte long (LC[A]), à plusieurs tours (MT[A]), sur contournements déjà publiés (SC[J], jailbreaks), sous équipe rouge adaptative (SC[ART], adaptive red teaming) ; enfin erreur de test pondérée.

- Gemini 2.5 Flash : {{G15}}.
- Sonde retenue par les auteurs (attention sur fenêtres glissantes, agrégation par max des moyennes glissantes) : {{G14}}.
- Attention sur fenêtres glissantes, agrégation MultiMax : {{G19}}.
- Attention sur fenêtres glissantes à 20 têtes, agrégation glissante : {{G27}}.
- MultiMax entraînée par attention : {{G26}}.
- Sonde linéaire à moyenne : {{G09}}.
- MultiMax entraînée (20 têtes) : {{G08}}.
- **Cascade (auteurs)** : {{G20}}.
- **Équipe rouge adaptative (auteurs)** : {{G16}}.
- **Réserve, incohérence interne** : {{G12}} contre {{G13}} — le même point de fonctionnement est annoncé à 8 % puis à environ 3 % de report vers le grand modèle.

### Antériorité (R8)

- **H1** : touchée, non occupée : {{G06}}. Il s'agit de détecter des demandes malveillantes en entrée (cyberattaque), avec une erreur pondérée ; ni sabotage diffus, ni tâches d'agent, ni comparaison à taux de faux positifs égal.
- **H2** : non occupée : agrégations sur les jetons d'une entrée (moyenne mobile exponentielle puis max, {{G18}} ; {{G24}} ; max de moyennes glissantes, {{G25}}), sans garantie toujours valide ni seuil par action ; et {{G05}}.
- **Transposition jeton → action** : non occupée ({{G05}}). Données utiles au niveau du jeton : {{G04}} ; mais une agrégation à max entraînée gonfle les faux positifs sur contexte long bénin (82,14 %, {{G08}}), la moyenne se dilue (99,13 % de faux négatifs sur attaques en contexte long, {{G09}}), et {{G07}}.
- **HC1** : non occupée : les classifieurs à base de grand modèle de langage sont testés sous réécriture narrative ({{G17}}), sans pression graduée, sans loi de déférence, sans verdict par probabilité du jeton.
- **Hors liste, à signaler pour HC2** (« sous attaque par contenu boîte noire, g_sonde ≈ 0 pour une sonde à agrégation robuste », g étant la fraction du chemin parcourue vers le verdict voulu par l'attaquant) : en tension, dans un cadre voisin (détection de demandes malveillantes en entrée). Sous réécriture narrative, la sonde retenue par les auteurs et sa variante à agrégation MultiMax (deux agrégations de type max) passent de 8,58 % et 8,12 % de faux négatifs sur les attaques directes en contexte court à 42,46 % et 22,97 % ({{G14}} ; {{G19}}), contre 20,65 % pour Gemini 2.5 Flash ({{G15}}). Sur tout le tableau 3, les faux négatifs des sondes sous réécriture narrative vont de 3,94 %, au prix de 43,97 % de faux positifs sur contexte long bénin ({{G26}}), à 50,58 % ({{G27}}). Les auteurs : {{G10}} ; {{G11}}.
- **Lemme d'additivité, théorème négatif, HC2b, papier B** : non touchés.

---

## 7. Article 5 — The Obfuscation Atlas (arXiv 2602.15515v2)

### Identité

- **Titre** : The Obfuscation Atlas: Mapping Where Honesty Emerges in RLVR with Deception Probes.
- **Auteurs (tous)** : {{A01}} ; {{A20}} (Taufeeque et Heimersheim, co-premiers auteurs).
- **Version et date** : {{A02}}.
- **Venue** (imprimée dans le PDF) : {{A03}}, soit l'International Conference on Machine Learning 2026.
- **Cadre** : apprentissage par renforcement à récompenses vérifiables sur des problèmes de programmation où tricher (coder en dur le test fourni) paie ; une sonde de tromperie figée pénalise la récompense ; quatre issues : politique honnête, tromperie flagrante, politique obfusquée, activations obfusquées.

### Affirmations du programme

| # | affirmation du programme | verdict | page | citation exacte |
|---|---|---|---|---|
| 5.1 | « Taufeeque et al. 2026, arXiv 2602.15515 » (L170) | **confirmé** (venue non mentionnée par le programme : International Conference on Machine Learning 2026) | 1 | {{A01}} ; {{A02}} ; {{A03}} |
| 5.2 | rangement sous « Tr. » (L170) | **confirmé**, pertinence limitée au niveau du jeton : sous apprentissage par renforcement, les sondes à moyenne sur les jetons générés sont contournées par dilution ; environnement à un seul tour ; ni max ni attention testés | 7 ; 4 | {{A04}} ; {{A05}} |

### Chiffres utilisables

- **Stratégies des 34 politiques obfusquées (auteurs ; classement assisté par un modèle, vérifié à la main par les auteurs)** : {{A16}}.
- **Dérive des représentations sans pénalité de sonde, aire sous la courbe de discrimination avant puis après entraînement (auteurs)** : {{A17}}.
- **Sondes à moyenne sur la génération (auteurs)** : {{A15}}.

### Antériorité (R8)

- **HC2b** : touchée en partie, de signe contraire, non occupée. Sous apprentissage par renforcement contre la sonde, des politiques qui rationalisent ({{A07}}) ou simulent un verdict favorable ({{A08}}) obtiennent des scores de tromperie plus bas que les politiques honnêtes : {{A06}}. Écarts avec HC2b : tentatives optimisées contre la sonde (non spontanées) ; pas de plan rhétorique × intention ; pas de contrôle du style.
- **Transposition jeton → action** : non occupée (un seul tour, {{A05}} ; ni max ni attention ; dilution des sondes à moyenne, {{A04}}).
- **Cadre de menace de L70 (sans gradient à travers le moniteur)** : appui théorique et empirique — {{A09}} ; {{A10}} ; {{A18}}.
- **H1** : non occupée (avantages des sondes affirmés, non mesurés : {{A13}}).
- **HC1** : non occupée (un juge biaisé sert de récompense dans la tâche annexe « Food-Sycophancy », {{A14}} ; aucune pression graduée sur un moniteur, aucune loi de déférence).
- **H2, lemme d'additivité, théorème négatif, papier B** : non touchés.

---

## 8. Synthèse (dix lignes au plus)

1. Empreintes : 5 sur 5 conformes. Citations : {{NCIT}} contrôlées par script (tests préalables 10 sur 10), 0 échec.
2. 19 affirmations atomiques : 14 confirmées, 4 corrigées, 1 introuvable.
3. Corrigé (L70, L134) : ce ne sont pas « les scores par token » qui cèdent, mais leur agrégation par moyenne ou médiane ; un score par jeton agrégé par max résiste.
4. Corrigé (L70) : « Établi » seulement dans le cadre testé (nocivité, 7 à 14 milliards de paramètres) ; les auteurs réservent l'hypothèse de difficultés d'optimisation ; sur Llama 2 7B, le max n'a « résisté » que parce que l'évasion obtenue ruinait la qualité ; sur Llama 3 8B, la résistance de l'attention vient d'un run dégénéré (récompense 1,08 sur 5).
5. Corrigé (L134, Bailey et al.) : 100 % → 0 % « souvent », surtout par suffixe d'embedding, sur des sondes surtout agrégées par moyenne ; « taxe d'obfuscation » : terme absent, il s'agit d'un compromis obfuscation–performance, mesuré sur Gemma-2-2b.
6. Introuvable : « ICLR 2026 » dans le PDF de Bailey et al. (v2, février 2025) ; seule attestation, secondaire : bibliographie de 2602.15515v2, p. 10.
7. Aucune zone revendiquée n'est occupée par ces cinq sources.
8. Touchées en partie : HC2b (Atlas : signe contraire sous optimisation contre la sonde ; Neural Chameleons : observations marginales) ; transposition (bornes de menace : max contourné par embedding chez Bailey et al., attention en partie contournée chez Neural Chameleons ; Gemini et Atlas restent au niveau du jeton) ; H1 (Gemini : sondes contre classifieurs à grand modèle de langage, hors sabotage).
9. Non touchées : H2, lemme d'additivité, théorème négatif, HC1, papier B. Hors liste : HC2 en tension avec Gemini (sous réécriture narrative, la sonde retenue par les auteurs et sa variante MultiMax, agrégations de type max, passent d'environ 8 % à 42,46 % et 22,97 % de faux négatifs).

---

## Annexe A — toutes les citations contrôlées

{{ANNEXE}}

## Annexe B — fichiers du lecteur (dossier `lecture-lot2-A2a/`) et empreintes SHA-256

{{FICHIERS}}

Textes extraits : `texte/<pdf>/pNN.txt` (`pdftotext -layout`) et `texte_brut/<pdf>/pNN.txt` (`pdftotext -raw`), une page par fichier.
