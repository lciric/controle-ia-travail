#!/usr/bin/env python3
"""Assemble rapport.md = corps + annexe des citations, apres verification de coherence.

Verifie :
- chaque « [ID] « texte » » du corps est identique (aux blancs pres) au texte controle de citations.json ;
- chaque identifiant cite dans le corps existe et a le resultat OK dans la sortie du controle ;
- chaque citation de citations.json a un resultat OK.
Tout ecart arrete l'assemblage (aucun repli silencieux).

Usage : python3 -I assembler_rapport.py CORPS.md CITATIONS.json SORTIE_CONTROLE.tsv RAPPORT.md
"""
import json
import pathlib
import re
import sys


def norm(s):
    return re.sub(r"\s+", " ", s.strip())


def main(argv):
    corps = pathlib.Path(argv[1]).read_text(encoding="utf-8")
    cits = json.loads(pathlib.Path(argv[2]).read_text(encoding="utf-8"))
    par_id = {c["id"]: c for c in cits}
    resultats = {}
    for ligne in pathlib.Path(argv[3]).read_text(encoding="utf-8").splitlines():
        if ligne.startswith("#") or ligne.startswith("id\t"):
            continue
        i, _pdf, _page, res = ligne.split("\t")
        resultats[i] = res
    erreurs = []
    for c in cits:
        if not resultats.get(c["id"], "").startswith("OK"):
            erreurs.append(f"citation non validee par le controle : {c['id']}")
    citees = re.findall(r"\[([A-E]\d+)\] « (.+?) »", corps)
    for i, texte in citees:
        if i not in par_id:
            erreurs.append(f"identifiant inconnu : {i}")
        elif norm(texte) != norm(par_id[i]["citation"]):
            erreurs.append(f"texte different du texte controle : {i}")
    refs = set(re.findall(r"\[([A-E]\d+)[,\]]", corps))
    for i in sorted(refs):
        if i not in par_id:
            erreurs.append(f"reference inconnue : {i}")
    if erreurs:
        sys.stderr.write("\n".join(erreurs) + "\n")
        return 1
    non_cites = sorted(set(par_id) - refs, key=lambda s: (s[0], int(s[1:])))
    lignes = [
        "",
        "---",
        "",
        "## Annexe — citations contrôlées",
        "",
        "Générée par `scripts/assembler_rapport.py` à partir de `citations.json` et de "
        "`controle-citations-sortie.tsv`. « layout » : validée sur le texte `-layout` ; "
        "« brut » : validée sur le texte en ordre de lecture de la même page.",
        "",
        "| Id | Fichier | Page | Contrôle | Citation exacte |",
        "|---|---|---|---|---|",
    ]
    for c in cits:
        res = resultats[c["id"]].replace("OK-", "")
        texte = c["citation"].replace("|", "\\|")
        lignes.append(f"| {c['id']} | {c['pdf']} | {c['page']} | {res} | « {texte} » |")
    pathlib.Path(argv[4]).write_text(corps.rstrip("\n") + "\n" + "\n".join(lignes) + "\n", encoding="utf-8")
    print(f"citations recopiees verifiees : {len(citees)} ; identifiants references : {len(refs)} ; "
          f"citations au fichier : {len(cits)} ; non referencees dans le corps : {non_cites}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
