#!/usr/bin/env python3
"""Controle des citations contre le texte extrait de la page indiquee.

Tolerance : uniquement les blancs (espaces, tabulations, retours a la ligne) et les
cesures (trait d'union ajoute en fin de ligne, ou trait d'union reel coupe en fin de ligne).

Referentiel 1 : texte `pdftotext -layout`, page par page (rang dans le fichier).
Referentiel 2, declare : texte `pdftotext` sans `-layout`, meme page, utilise seulement si le
premier echoue (pages a deux colonnes). Le referentiel qui valide est toujours rapporte.

Aucun repli silencieux : page absente, page vide ou citation vide -> exception.

Usage : python3 -I controle_citations.py CITATIONS.json RACINE_LAYOUT RACINE_BRUT [SORTIE.tsv]
"""
import json
import pathlib
import re
import sys


def motif(citation: str) -> "re.Pattern[str]":
    q = re.sub(r"\s+", " ", citation.strip())
    if not q:
        raise ValueError("citation vide")
    parts = []
    for i, ch in enumerate(q):
        if ch == " ":
            parts.append(r"\s+")
            continue
        parts.append(re.escape(ch))
        nxt = q[i + 1] if i + 1 < len(q) else None
        if nxt is not None and nxt != " ":
            if ch == "-":
                # trait d'union reel, ligne coupee juste apres
                parts.append(r"(?:[ \t]*\n[ \t]*)?")
            else:
                # cesure : trait d'union ajoute en fin de ligne
                parts.append(r"(?:-[ \t]*\n[ \t]*)?")
    return re.compile("".join(parts))


def lire_page(racine: str, pdf: str, page: int) -> str:
    f = pathlib.Path(racine) / pdf / f"p{int(page):03d}.txt"
    if not f.is_file():
        raise FileNotFoundError(f"page absente : {f}")
    texte = f.read_text(encoding="utf-8")
    if not texte.strip():
        raise ValueError(f"page vide : {f}")
    return texte


def controler(c: dict, racine_layout: str, racine_brut: str):
    m = motif(c["citation"])
    if m.search(lire_page(racine_layout, c["pdf"], c["page"])):
        return "layout"
    if m.search(lire_page(racine_brut, c["pdf"], c["page"])):
        return "brut"
    return None


def main(argv):
    citations = json.loads(pathlib.Path(argv[1]).read_text(encoding="utf-8"))
    racine_layout, racine_brut = argv[2], argv[3]
    sortie = pathlib.Path(argv[4]) if len(argv) > 4 else None
    ids = [c["id"] for c in citations]
    if len(ids) != len(set(ids)):
        raise ValueError("identifiants de citation en double")
    lignes = ["id\tpdf\tpage\tresultat"]
    n_ok = n_echec = n_brut = 0
    for c in citations:
        r = controler(c, racine_layout, racine_brut)
        if r is None:
            n_echec += 1
            etat = "ECHEC"
        else:
            n_ok += 1
            n_brut += r == "brut"
            etat = "OK-" + r
        lignes.append(f"{c['id']}\t{c['pdf']}\t{c['page']}\t{etat}")
    lignes.append(f"# controlees={len(citations)} ok={n_ok} (dont brut={n_brut}) echecs={n_echec}")
    texte = "\n".join(lignes) + "\n"
    if sortie:
        sortie.write_text(texte, encoding="utf-8")
    sys.stdout.write(texte)
    return 1 if n_echec else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
