#!/usr/bin/env python3
"""Tests R5 du controle des citations : cas justes, cas alteres, gardes d'arret.

Usage : python3 -I test_controle_r5.py CHEMIN_SCRIPT RACINE_LAYOUT RACINE_BRUT
"""
import importlib.util
import sys

spec = importlib.util.spec_from_file_location("cc", sys.argv[1])
cc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cc)
LAY, BRUT = sys.argv[2], sys.argv[3]
resultats = []


def verifier(nom, obtenu, attendu):
    ok = obtenu == attendu
    resultats.append(ok)
    print(f"{'OK ' if ok else 'KO '} {nom} : obtenu={obtenu!r} attendu={attendu!r}")


def leve(nom, fonction, exc):
    try:
        fonction()
    except exc as e:
        resultats.append(True)
        print(f"OK  {nom} : exception {type(e).__name__} levee ({e})")
        return
    except Exception as e:  # mauvaise exception
        resultats.append(False)
        print(f"KO  {nom} : exception inattendue {type(e).__name__}")
        return
    resultats.append(False)
    print(f"KO  {nom} : aucune exception (repli silencieux)")


# 1. Cas juste sur un vrai PDF, avec deux cesures (prefer-/ence, related-/ness), page 1.
juste = {"id": "t1", "pdf": "2502.01534v3", "page": 1,
         "citation": "In this work, we expose preference leakage, a contamination problem in "
                     "LLM-as-a-judge caused by the relatedness between the synthetic data "
                     "generators and LLM-based evaluators."}
verifier("cas juste (cesures)", cc.controler(juste, LAY, BRUT), "layout")

# 2. Cas altere : un mot change.
altere = dict(juste, id="t2", citation=juste["citation"].replace("contamination", "corruption"))
verifier("cas altere (mot)", cc.controler(altere, LAY, BRUT), None)

# 3. Cas altere : un chiffre change.
chiffre_juste = {"id": "t3", "pdf": "2502.01534v3", "page": 10,
                 "citation": "reducing Error Bias from 17.8 to 7.3."}
verifier("cas juste (chiffre)", cc.controler(chiffre_juste, LAY, BRUT), "layout")
chiffre_altere = dict(chiffre_juste, id="t4", citation="reducing Error Bias from 17.8 to 7.4.")
verifier("cas altere (chiffre)", cc.controler(chiffre_altere, LAY, BRUT), None)

# 4. Bonne citation, mauvaise page : doit echouer.
mauvaise_page = dict(juste, id="t5", page=2)
verifier("bonne citation, mauvaise page", cc.controler(mauvaise_page, LAY, BRUT), None)

# 5. Tolerance limitee : pas d'espace arbitraire dans un mot, cesure acceptee.
m = cc.motif("preference leakage")
verifier("cesure synthetique", bool(m.search("prefer-\n      ence leakage")), True)
verifier("blanc dans un mot refuse", bool(m.search("prefer ence leakage")), False)
verifier("coupure sans trait d'union refusee", bool(m.search("prefer\nence leakage")), False)
m2 = cc.motif("LLM-based evaluators")
verifier("trait d'union reel coupe en fin de ligne", bool(m2.search("LLM-\n   based evaluators")), True)
verifier("trait d'union supprime refuse", bool(m2.search("LLMbased evaluators")), False)

# 6. Referentiel declare : une citation sur deux lignes d'une colonne gauche (page a deux
#    colonnes) echoue en -layout et passe en brut ; le resultat le dit.
deux_colonnes = {"id": "t6", "pdf": "2302.12173v2", "page": 12,
                 "citation": "deceiving an LLM controller/supervisor agent"}
verifier("deux colonnes -> referentiel brut declare", cc.controler(deux_colonnes, LAY, BRUT), "brut")

# 7. Gardes d'arret (aucun repli silencieux).
leve("page absente", lambda: cc.controler(dict(juste, page=99), LAY, BRUT), FileNotFoundError)
leve("citation vide", lambda: cc.motif("   "), ValueError)
leve("pdf inconnu", lambda: cc.controler(dict(juste, pdf="0000.00000v1"), LAY, BRUT), FileNotFoundError)

print(f"# tests={len(resultats)} reussis={sum(resultats)} echoues={len(resultats) - sum(resultats)}")
sys.exit(0 if all(resultats) else 1)
