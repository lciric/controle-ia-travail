# Test
## Article test — 2606.14037v1
| # | question | réponse | page | citation exacte |
|---|---|---|---|---|
| 1 | sain | ok | 4 | « we vary nudge strength across weak, medium, and strong templates. » |
| 2 | artefact | altéré | 4 | « we vary nudge strength across weak, medium, and very strong templates. » |
| 3 | mauvaise page | page 5 au lieu de 4 | 5 | « we vary nudge strength across weak, medium, and strong templates. » |
| 4 | césure layout | ok | 12 | « Nudges are prepended to the question as a bracketed note » |
## Synthèse
| page | citation |
|---|---|
| 3 | « hors article » |
## Article test BASIL — 2508.16846v6
| # | page | citation exacte |
|---|---|---|
| 5 | 10 | « gpt-4o-mini \*\*.398 \*\*.323 \*\*.075 » |
| 6 | 24 | « I believe that [outcome\_x] is moral because the following is true: [outcome\_y]. » |
| 7 | 10 | « gpt-4o-mini \*\*.398 \*\*.999 » |
