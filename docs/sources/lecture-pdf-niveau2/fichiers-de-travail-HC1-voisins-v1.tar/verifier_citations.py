#!/usr/bin/env python3
"""Contrôle des citations du rapport de lecture (niveau 2, HC1).

Usage : python3 -I verifier_citations.py RAPPORT.md DOSSIER_TRAVAIL [JOURNAL.tsv]

Principe
- Le rapport est un fichier Markdown. Chaque article est une section de niveau 2
  (« ## ... ») dont le titre contient l'identifiant arXiv (ex. 2511.17220v2).
  Une section de niveau 2 sans identifiant clôt l'article courant.
- Dans chaque tableau Markdown de la section, on repère la colonne dont l'en-tête
  commence par « page » et celle dont l'en-tête commence par « citation ».
  Chaque citation est écrite entre guillemets français « … » ; une cellule peut en
  contenir plusieurs (toutes à la même page).
- La page citée est le rang de la page dans le fichier PDF (1 = première page).
- Chaque citation est cherchée dans le texte extrait de CETTE page, sous trois
  extractions pdftotext du même PDF : ordre de lecture (défaut), -layout, -raw.
- Tolérances, et elles seules : les espaces (blancs, sauts de ligne, présents ou
  absents) et les césures de fin de ligne (« -\n »). Aucune autre normalisation :
  ni casse, ni ponctuation, ni guillemets, ni Unicode. Seule opération préalable :
  retirer les échappements Markdown du rapport (« \\* » -> « * », « \\_ » -> « _ »,
  « \\| » -> « | »), qui relèvent de la syntaxe du rapport et non du texte cité.
- En cas d'échec, le script cherche la citation dans les autres pages de l'article
  et l'indique (aide au diagnostic) ; cela reste un échec.

Sortie : un journal TSV (une ligne par citation) et un résumé sur la sortie standard.
Code de retour : 0 si aucune citation n'échoue, 1 sinon, 2 si erreur de format.
"""
import re
import sys
from pathlib import Path

MODES = (("lecture", "extraits-lecture"), ("layout", "extraits"), ("raw", "extraits-raw"))
ID_RE = re.compile(r"\b(\d{4}\.\d{5}v\d+)\b")
QUOTE_RE = re.compile(r"«\s*(.+?)\s*»")
JOINER = r"(?:\s|-[ \t]*\r?\n)*"


def motif(citation: str) -> re.Pattern:
    chars = [c for c in citation if not c.isspace()]
    return re.compile(JOINER.join(re.escape(c) for c in chars))


def page_texte(base: Path, dossier: str, ident: str, page: int) -> str:
    chemin = base / dossier / ident / f"p{page:02d}.txt"
    if not chemin.is_file():
        return ""
    return chemin.read_text(encoding="utf-8")


def nb_pages(base: Path, ident: str) -> int:
    return len(list((base / "extraits" / ident).glob("p*.txt")))


MD_ESC_RE = re.compile(r"\\([\\`*_{}\[\]()#+\-.!|<>~])")


def desechapper(texte: str) -> str:
    """Retire les échappements Markdown (ex. « \\* » -> « * ») : pure syntaxe, pas de contenu."""
    return MD_ESC_RE.sub(r"\1", texte)


def cellules(ligne: str):
    ligne = ligne.strip()
    if ligne.startswith("|"):
        ligne = ligne[1:]
    if ligne.endswith("|") and not ligne.endswith("\\|"):
        ligne = ligne[:-1]
    return [c.strip() for c in re.split(r"(?<!\\)\|", ligne)]


def main() -> int:
    if len(sys.argv) < 3:
        print(__doc__)
        return 2
    rapport = Path(sys.argv[1])
    base = Path(sys.argv[2])
    journal = Path(sys.argv[3]) if len(sys.argv) > 3 else base / "controle-citations.tsv"
    lignes = rapport.read_text(encoding="utf-8").splitlines()

    article = None
    entete = None  # (index_page, index_citation)
    resultats = []
    erreurs_format = []
    i = 0
    while i < len(lignes):
        ligne = lignes[i]
        if ligne.startswith("## "):
            m = ID_RE.search(ligne)
            article = m.group(1) if m else None
            entete = None
        elif ligne.lstrip().startswith("|"):
            suivante = lignes[i + 1] if i + 1 < len(lignes) else ""
            if entete is None and re.match(r"^\s*\|\s*:?-{3,}", suivante):
                cols = [c.lower() for c in cellules(ligne)]
                ip = next((k for k, c in enumerate(cols) if c.startswith("page")), None)
                ic = next((k for k, c in enumerate(cols) if c.startswith("citation")), None)
                entete = (ip, ic)
                i += 2
                continue
            if entete is not None and entete[1] is not None:
                cels = cellules(ligne)
                ip, ic = entete
                if ic < len(cels):
                    citations = [desechapper(c) for c in QUOTE_RE.findall(cels[ic])]
                    if citations:
                        mp = re.search(r"\d+", cels[ip]) if ip is not None and ip < len(cels) else None
                        if article is None:
                            erreurs_format.append(f"ligne {i+1}: citation hors section d'article")
                        elif mp is None:
                            erreurs_format.append(f"ligne {i+1}: page absente pour une citation")
                        else:
                            page = int(mp.group(0))
                            for cit in citations:
                                pat = motif(cit)
                                mode_ok = None
                                for nom, dossier in MODES:
                                    if pat.search(page_texte(base, dossier, article, page)):
                                        mode_ok = nom
                                        break
                                ailleurs = []
                                if mode_ok is None and article is not None:
                                    for p in range(1, nb_pages(base, article) + 1):
                                        if p == page:
                                            continue
                                        if any(pat.search(page_texte(base, d, article, p)) for _, d in MODES):
                                            ailleurs.append(p)
                                resultats.append((i + 1, article, page, mode_ok, ailleurs, cit))
        else:
            entete = None
        i += 1

    with journal.open("w", encoding="utf-8") as f:
        f.write("ligne_rapport\tarticle\tpage\tresultat\textraction\tpages_ou_trouvee_ailleurs\tcitation\n")
        for (ln, art, page, mode, ailleurs, cit) in resultats:
            f.write(f"{ln}\t{art}\t{page}\t{'OK' if mode else 'ECHEC'}\t{mode or '-'}\t"
                    f"{','.join(map(str, ailleurs)) or '-'}\t{cit}\n")

    total = len(resultats)
    echecs = [r for r in resultats if r[3] is None]
    par_article = {}
    for r in resultats:
        par_article.setdefault(r[1], [0, 0])
        par_article[r[1]][0] += 1
        par_article[r[1]][1] += r[3] is None
    par_mode = {}
    for r in resultats:
        if r[3]:
            par_mode[r[3]] = par_mode.get(r[3], 0) + 1
    print(f"citations contrôlées : {total}")
    print(f"échecs : {len(echecs)}")
    for art, (n, e) in par_article.items():
        print(f"  {art} : {n} citations, {e} échec(s)")
    print("extraction ayant validé la citation (première trouvée) :", par_mode)
    for (ln, art, page, mode, ailleurs, cit) in echecs:
        print(f"ÉCHEC ligne {ln} [{art} p. {page}] trouvée ailleurs : {ailleurs or 'nulle part'} :: {cit[:90]}")
    for e in erreurs_format:
        print("FORMAT", e)
    print(f"journal : {journal}")
    if erreurs_format:
        return 2
    return 1 if echecs else 0


if __name__ == "__main__":
    sys.exit(main())
