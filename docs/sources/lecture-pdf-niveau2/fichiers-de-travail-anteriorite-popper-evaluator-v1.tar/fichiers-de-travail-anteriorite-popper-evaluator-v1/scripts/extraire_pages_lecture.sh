#!/bin/bash
# extraire_pages_lecture.sh PDF SORTIE : ordre de lecture (pdftotext sans -layout), une page par séparateur
set -euo pipefail
pdf="$1"; sortie="$2"
n=$(pdfinfo "$pdf" | awk '/^Pages:/{print $2}')
: > "$sortie"
for p in $(seq 1 "$n"); do
  printf '======== PAGE %d ========\n' "$p" >> "$sortie"
  pdftotext -enc UTF-8 -f "$p" -l "$p" "$pdf" - | tr -d '\f' >> "$sortie"
  printf '\n' >> "$sortie"
done
c=$(grep -c '^======== PAGE [0-9]* ========$' "$sortie")
echo "$(basename "$pdf") pages=$n separateurs=$c"
