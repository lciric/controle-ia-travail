#!/bin/bash
# lire.sh FICHIER PDEBUT PFIN
awk -v a="$2" -v b="$3" '/^======== PAGE [0-9]+ ========$/{p=$3+0} p>=a && p<=b' "$1" | grep -v 'latexit' | grep -v '^[[:space:]]*$' | tr -s ' '
