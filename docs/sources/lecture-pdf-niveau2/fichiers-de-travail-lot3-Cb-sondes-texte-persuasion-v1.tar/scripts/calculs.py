# Calculs a partir des chiffres imprimes par les auteurs (aucune lecture de PDF ici).
# Hypothese : loi binormale a variances egales ; AUROC = Phi(d / sqrt(2)).
from statistics import NormalDist

N = NormalDist()
print("Baisses en points (chiffres des auteurs, difference calculee) :")
for nom, a, b in [
    ("sous-perf. filtrage scores", .95, .81),
    ("sous-perf. filtrage contenu (texte)", .95, .63),
    ("sous-perf. filtrage contenu (legende)", .95, .62),
    ("complaisance filtrage contenu (base texte 0,99)", .99, .61),
    ("complaisance filtrage contenu (base legende 0,90)", .90, .61),
    ("biais filtrage scores", .74, .46),
    ("biais filtrage contenu", .74, .54),
    ("organisme biais", .74, .57),
    ("organisme sous-perf. (corps)", .94, .50),
    ("organisme sous-perf. (resume)", .94, .57),
    ("complaisance naturelle", .99, .51),
]:
    print("  %-50s %.2f -> %.2f : %d points" % (nom, a, b, round((a - b) * 100)))
za, zb = N.inv_cdf(0.99), N.inv_cdf(0.80)
print("z(0,99)=%.3f ; z(0,80)=%.3f" % (za, zb))
for auc in (0.50, 0.51, 0.57, 0.60):
    d = 2 ** 0.5 * N.inv_cdf(auc)
    rappel = 1 - N.cdf(za - d)
    n = ((za + zb) / d) ** 2 if d > 0 else float("inf")
    print("AUROC %.2f -> d = %.3f ; rappel par action a 1 %% FP = %.4f ; n somme (alpha 1 %%, puissance 80 %%, horizon fixe) = %s"
          % (auc, d, rappel, ("%.0f" % n) if n != float("inf") else "infini"))
