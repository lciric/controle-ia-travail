#!/usr/bin/env python3
"""Assemble rapport.md : corps + annexe B (liste des citations controlees),
apres verification de la concordance entre les citations du corps et la liste.

Usage : python3 -I assembler_rapport.py CORPS.md CITATIONS.tsv RAPPORT.md HEURE_FIN
Echec (code 1) si une citation du corps differe de la citation controlee de meme
identifiant, si la page indiquee differe, ou si un identifiant est inconnu.
"""
import re
import sys


def norm(t):
    return re.sub(r"\s+", " ", t).strip()


def main(argv):
    corps_f, cit_f, sortie_f, heure = argv[1], argv[2], argv[3], argv[4]
    cits = {}
    ordre = []
    with open(cit_f, encoding="utf-8") as f:
        for ligne in f:
            ligne = ligne.rstrip("\n")
            if not ligne.strip() or ligne.startswith("#"):
                continue
            ident, pdf, page, texte = ligne.split("\t")
            cits[ident] = (pdf, int(page), texte)
            ordre.append(ident)
    with open(corps_f, encoding="utf-8") as f:
        corps = f.read()

    erreurs = []
    # Paires identifiant + citation (entre guillemets francais ou en code)
    motif_paire = re.compile(r"\[([AB]\d{2})\](?:\s*p\.\s*(\d+))?\s*(?:«\s*(.*?)\s*»|`([^`]*)`)", re.S)
    paires = 0
    for m in motif_paire.finditer(corps):
        ident, page, t1, t2 = m.group(1), m.group(2), m.group(3), m.group(4)
        texte = t1 if t1 is not None else t2
        paires += 1
        if ident not in cits:
            erreurs.append("identifiant inconnu : " + ident)
            continue
        if page is not None and int(page) != cits[ident][1]:
            erreurs.append("%s : page %s dans le rapport, page %d dans la liste" % (ident, page, cits[ident][1]))
        if norm(texte) not in norm(cits[ident][2]):
            erreurs.append("%s : texte different de la citation controlee : %r" % (ident, texte[:80]))
    # Tous les identifiants cites (avec ou sans texte)
    motif_ref = re.compile(r"\[([AB]\d{2})\](?:\s*p\.\s*(\d+))?")
    refs = 0
    for m in motif_ref.finditer(corps):
        refs += 1
        ident, page = m.group(1), m.group(2)
        if ident not in cits:
            erreurs.append("reference inconnue : " + ident)
        elif page is not None and int(page) != cits[ident][1]:
            erreurs.append("%s : page %s dans le rapport, page %d dans la liste" % (ident, page, cits[ident][1]))
    # Guillemets francais sans identifiant (expressions francaises) : listes pour revue
    sans_id = []
    for m in re.finditer(r"«\s*(.*?)\s*»", corps, re.S):
        avant = corps[max(0, m.start() - 20):m.start()]
        if not re.search(r"\[[AB]\d{2}\](?:\s*p\.\s*\d+)?\s*$", avant):
            sans_id.append(norm(m.group(1)))

    print("paires identifiant + citation verifiees : %d" % paires)
    print("references d'identifiants verifiees : %d" % refs)
    print("guillemets sans identifiant (a relire, expressions francaises) : %d" % len(sans_id))
    for s in sans_id:
        print("   - " + s[:90])
    if erreurs:
        print("ERREURS :")
        for e in erreurs:
            print("   " + e)
        return 1

    lignes = ["", "## Annexe B — liste des %d citations contrôlées" % len(ordre), "",
              "Générée depuis `citations.tsv` ; chaque ligne a été retrouvée sur la page indiquée (annexe A).", "",
              "| id | PDF | page | citation exacte |", "|---|---|---|---|"]
    for ident in sorted(ordre, key=lambda i: (i[0], int(i[1:]))):
        pdf, page, texte = cits[ident]
        lignes.append("| %s | %s | %d | `%s` |" % (ident, pdf, page, texte))
    lignes += ["", "**Concordance rapport / liste** : %d paires « identifiant + citation » du rapport vérifiées, "
               "%d références d'identifiants vérifiées, 0 écart." % (paires, refs), ""]
    rapport = corps.replace("HEURE_FIN", heure) + "\n".join(lignes)
    with open(sortie_f, "w", encoding="utf-8") as f:
        f.write(rapport)
    print("rapport ecrit : " + sortie_f)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
