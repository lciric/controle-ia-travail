#!/usr/bin/env python3
"""Pour chaque passage entre guillemets francais du rapport qui n'est pas precede
d'un identifiant, dit s'il figure mot pour mot (blancs normalises) dans une
citation controlee, et laquelle. Les passages introuvables sont listes pour revue
(ils doivent etre des expressions francaises ou des chaines de test volontaires).
Usage : python3 -I fragments_sans_id.py CORPS.md CITATIONS.tsv
"""
import re
import sys


def norm(t):
    return re.sub(r"\s+", " ", t).strip()


def main(argv):
    corps = open(argv[1], encoding="utf-8").read()
    cits = []
    for ligne in open(argv[2], encoding="utf-8"):
        ligne = ligne.rstrip("\n")
        if ligne.strip() and not ligne.startswith("#"):
            ident, pdf, page, texte = ligne.split("\t")
            cits.append((ident, norm(texte)))
    trouves, introuvables = [], []
    for m in re.finditer(r"«\s*(.*?)\s*»", corps, re.S):
        avant = corps[max(0, m.start() - 20):m.start()]
        if re.search(r"\[[AB]\d{2}\](?:\s*p\.\s*\d+)?\s*$", avant):
            continue
        frag = norm(m.group(1))
        ids = [i for i, t in cits if frag in t]
        (trouves if ids else introuvables).append((frag, ids))
    print("fragments sans identifiant retrouves dans une citation controlee : %d" % len(trouves))
    for frag, ids in trouves:
        print("   OK  %-60s -> %s" % (frag[:60], ",".join(ids[:4])))
    print("fragments introuvables dans la liste (a relire) : %d" % len(introuvables))
    for frag, _ in introuvables:
        print("   ??  " + frag[:90])
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
