Texte [A06] p. 1 « The AUROC reduction ranges from 10- to 30-point depending on the setting. » fin.
