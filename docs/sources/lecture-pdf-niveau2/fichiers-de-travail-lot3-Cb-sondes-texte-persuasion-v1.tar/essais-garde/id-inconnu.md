Texte [A99] « x » fin.
