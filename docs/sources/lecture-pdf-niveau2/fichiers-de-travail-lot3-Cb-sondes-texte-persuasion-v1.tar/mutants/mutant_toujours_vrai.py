#!/usr/bin/env python3
"""Controle des citations contre le texte extrait de la page indiquee.

Tolerance : les blancs et les cesures seulement.
- blancs : tous les blancs sont retires de la citation et de la page ;
- cesure : un tiret suivi d'un saut de ligne dans la page devient un marqueur
  qui peut correspondre soit a un tiret de la citation, soit a rien.
Aucune autre tolerance (ni guillemets, ni casse, ni ponctuation).

La page est cherchee dans trois extractions pdftotext de la MEME page :
  layout  : RACINE/<pdf>/pNN.txt          (pdftotext -layout)
  lecture : RACINE/<pdf>/lecture/pNN.txt  (pdftotext, ordre de lecture)
  brut    : RACINE/<pdf>/brut/pNN.txt     (pdftotext -raw)
Une citation est controlee si elle est trouvee dans au moins une extraction.

Usage : python3 -I controle_citations.py RACINE_TEXTES CITATIONS.tsv RESULTATS.tsv
Format de CITATIONS.tsv : id <TAB> pdf <TAB> page <TAB> citation (une par ligne,
les lignes vides et celles qui commencent par # sont ignorees).
Les auto-tests (regle R5) tournent d'abord ; s'ils echouent, rien d'autre ne tourne.
"""
import os
import re
import sys

MARQ = "\x00"
MODES = (("layout", ""), ("lecture", "lecture"), ("brut", "brut"))


def normaliser_page(texte):
    texte = re.sub(r"-[ \t]*\r?\n", MARQ, texte)
    return re.sub(r"\s+", "", texte)


def motif(citation):
    q = re.sub(r"\s+", "", citation)
    if not q:
        raise ValueError("citation vide")
    morceaux = []
    for c in q:
        if c == "-":
            morceaux.append("(?:-|" + MARQ + ")")
        else:
            morceaux.append(re.escape(c))
    return re.compile((MARQ + "?").join(morceaux))


def trouve_dans_texte(citation, texte_page):
    return True


def chemin_page(racine, pdf, page, sous_dossier):
    nom = "p%02d.txt" % int(page)
    if sous_dossier:
        return os.path.join(racine, pdf, sous_dossier, nom)
    return os.path.join(racine, pdf, nom)


def controler(racine, pdf, page, citation):
    modes_trouves = []
    for mode, sous in MODES:
        chemin = chemin_page(racine, pdf, page, sous)
        if not os.path.isfile(chemin):
            raise FileNotFoundError("page absente : " + chemin)
        with open(chemin, encoding="utf-8") as f:
            texte = f.read()
        if not texte.strip():
            raise ValueError("page vide : " + chemin)
        if trouve_dans_texte(citation, texte):
            modes_trouves.append(mode)
    return modes_trouves


def auto_tests(racine):
    """Regle R5 : la garde est testee sur des cas justes et sur des artefacts."""
    resultats = []

    def verifier(nom, obtenu, attendu):
        resultats.append((nom, obtenu, attendu, obtenu == attendu))

    # Tests en memoire
    verifier("memoire : cesure acceptee",
             trouve_dans_texte("beta performance gamma", "alpha beta per-\nformance gamma"), True)
    verifier("memoire : mot altere refuse",
             trouve_dans_texte("beta preformance gamma", "alpha beta per-\nformance gamma"), False)
    verifier("memoire : trait d'union reel coupe en fin de ligne accepte",
             trouve_dans_texte("multi-turn dialogue", "x multi-\nturn dialogue y"), True)
    verifier("memoire : trait d'union reel en milieu de ligne exige",
             trouve_dans_texte("multiturn", "x multi-turn y"), False)
    verifier("memoire : blancs toleres",
             trouve_dans_texte("a b c", "a   b\n\n c"), True)
    verifier("memoire : chiffre altere refuse",
             trouve_dans_texte("drops to 0.81 AUROC", "drops to 0.61 AUROC"), False)
    # Tests sur les vrais textes extraits
    juste = "The AUROC reduction ranges from 10- to 30-point depending on the setting."
    altere = "The AUROC reduction ranges from 10- to 40-point depending on the setting."
    verifier("fichier : cas juste, page 1 (2509.21344v2)",
             len(controler(racine, "2509.21344v2", 1, juste)) > 0, True)
    verifier("fichier : cas altere (40 au lieu de 30), page 1",
             len(controler(racine, "2509.21344v2", 1, altere)) > 0, False)
    verifier("fichier : cas juste mais mauvaise page (page 2)",
             len(controler(racine, "2509.21344v2", 2, juste)) > 0, False)
    verifier("fichier : cesure reelle (per-/formance), page 1",
             len(controler(racine, "2509.21344v2", 1,
                           "significantly decreases probe performance")) > 0, True)
    verifier("fichier : cesure avec mot altere, page 1",
             len(controler(racine, "2509.21344v2", 1,
                           "significantly decreases probe preformance")) > 0, False)
    verifier("fichier : cas juste, page 4 (2508.05625v1)",
             len(controler(racine, "2508.05625v1", 4,
                           "activations extracted from the residual stream at layer 26/30")) > 0, True)
    verifier("fichier : cas altere (layer 20/30), page 4 (2508.05625v1)",
             len(controler(racine, "2508.05625v1", 4,
                           "activations extracted from the residual stream at layer 20/30")) > 0, False)
    return resultats


def main(argv):
    if len(argv) != 4:
        print(__doc__)
        return 2
    racine, fichier_citations, fichier_resultats = argv[1], argv[2], argv[3]
    tests = auto_tests(racine)
    print("== Auto-tests (R5) ==")
    tous_ok = True
    for nom, obtenu, attendu, ok in tests:
        print("%-4s %s (obtenu=%s, attendu=%s)" % ("OK" if ok else "FAUX", nom, obtenu, attendu))
        tous_ok = tous_ok and ok
    if not tous_ok:
        print("Auto-tests en echec : controle des citations NON lance.")
        return 2
    print("Auto-tests : %d/%d conformes." % (len(tests), len(tests)))

    lignes = []
    with open(fichier_citations, encoding="utf-8") as f:
        for numero, ligne in enumerate(f, 1):
            ligne = ligne.rstrip("\n")
            if not ligne.strip() or ligne.startswith("#"):
                continue
            champs = ligne.split("\t")
            if len(champs) != 4:
                raise ValueError("ligne %d mal formee : %r" % (numero, ligne))
            lignes.append(champs)

    ids = [c[0] for c in lignes]
    if len(ids) != len(set(ids)):
        raise ValueError("identifiants de citation en double")

    echecs = 0
    courtes = 0
    with open(fichier_resultats, "w", encoding="utf-8") as sortie:
        sortie.write("id\tpdf\tpage\tstatut\tmodes\tlongueur_sans_blancs\n")
        for ident, pdf, page, citation in lignes:
            modes = controler(racine, pdf, int(page), citation)
            longueur = len(re.sub(r"\s+", "", citation))
            statut = "OK" if modes else "ECHEC"
            if not modes:
                echecs += 1
            if longueur < 15:
                courtes += 1
            sortie.write("%s\t%s\t%s\t%s\t%s\t%d\n" % (ident, pdf, page, statut,
                                                       ",".join(modes) or "-", longueur))
            print("%-6s %-5s p.%-3s %-20s %s" % (ident, statut, page, ",".join(modes) or "-",
                                                 citation[:70]))
    print("== Bilan : %d citations controlees, %d trouvees, %d en echec, %d courtes (<15 signes) =="
          % (len(lignes), len(lignes) - echecs, echecs, courtes))
    return 0 if echecs == 0 else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
