# Controle des citations exactes d'un rapport contre le texte extrait page par page.
# Usage : python3 -I controle_citations.py RAPPORT.md DOSSIER_TEXTES DOSSIER_TEXTES_LECTURE [SORTIE.tsv]
# Conventions du rapport :
#   - une section d'article commence par un titre "## Article ... <identifiant arXiv>" ;
#     tout autre titre de niveau 2 ferme la section ;
#   - chaque citation exacte est entre les signes U+27EA et U+27EB, precedee de "p. N"
#     (eventuellement separe par une barre de tableau).
# Tolerances, par niveau :
#   N1 : blancs seulement (tous les blancs sont retires des deux cotes) ;
#   N2 : N1 + cesures (traits d'union U+002D, U+00AD, U+2010, U+2011 retires des deux cotes) ;
#   N3 : N2 + normalisation NFKC (signale a part ; hors tolerance de la consigne).
# Deux extractions de la meme page sont essayees : "-layout" (dossier textes) et ordre de lecture
# (dossier textes-lecture, pdftotext sans -layout).
import re
import sys
import pathlib
import unicodedata

OUV, FERM = "⟪", "⟫"
ARTICLES = ("2608.25869", "2508.19461")
TRAITS = dict.fromkeys(map(ord, "-­‐‑"), None)


def n1(s):
    return re.sub(r"\s+", "", s)


def n2(s):
    return n1(s).translate(TRAITS)


def n3(s):
    return n2(unicodedata.normalize("NFKC", s))


NIVEAUX = (("N1", n1), ("N2", n2), ("N3", n3))


def charger(dossier, article):
    pages = {}
    for f in sorted((pathlib.Path(dossier) / article).glob("p*.txt")):
        pages[int(f.stem[1:])] = f.read_text(encoding="utf-8")
    return pages


def chercher(citation, page_txt):
    for nom, fn in NIVEAUX:
        if fn(citation) and fn(citation) in fn(page_txt):
            return nom
    return None


def main():
    rapport, d_layout, d_lecture = sys.argv[1:4]
    sortie = sys.argv[4] if len(sys.argv) > 4 else None
    textes = {a: (charger(d_layout, a), charger(d_lecture, a)) for a in ARTICLES}
    article = None
    motif = re.compile(r"p\.\s*(\d+)\s*(?:\|\s*)?" + OUV + "(.*?)" + FERM)
    lignes_sortie = ["num\tarticle\tpage\tresultat\tniveau\textraction\tautres_pages\tcitation"]
    nb = ok = echec = hors_tol = sans_page = 0
    for no, ligne in enumerate(pathlib.Path(rapport).read_text(encoding="utf-8").splitlines(), 1):
        if ligne.startswith("## "):
            article = next((a for a in ARTICLES if a in ligne and ligne.startswith("## Article")), None)
        total_ouv = ligne.count(OUV)
        trouves = motif.findall(ligne)
        if total_ouv != len(trouves):
            sans_page += total_ouv - len(trouves)
            lignes_sortie.append(f"-\t{article}\t-\tSANS_PAGE_OU_MAL_FORMEE (ligne {no})\t-\t-\t-\t{ligne[:120]}")
        for page_s, cit in trouves:
            nb += 1
            page = int(page_s)
            if article is None:
                echec += 1
                lignes_sortie.append(f"{nb}\t-\t{page}\tHORS_SECTION (ligne {no})\t-\t-\t-\t{cit}")
                continue
            lay, lec = textes[article]
            res = None
            for nom_ext, pages in (("layout", lay), ("lecture", lec)):
                niv = chercher(cit, pages.get(page, ""))
                if niv:
                    res = (niv, nom_ext)
                    break
            autres = sorted({p for pages in (lay, lec) for p, t in pages.items()
                             if p != page and chercher(cit, t) in ("N1", "N2")})
            if res and res[0] in ("N1", "N2"):
                ok += 1
                etat = "OK"
            elif res:
                hors_tol += 1
                etat = "HORS_TOLERANCE"
            else:
                echec += 1
                etat = "ECHEC"
            lignes_sortie.append(f"{nb}\t{article}\t{page}\t{etat} (ligne {no})\t{res[0] if res else '-'}\t"
                                 f"{res[1] if res else '-'}\t{','.join(map(str, autres)) or '-'}\t{cit}")
    bilan = (f"citations={nb} ok={ok} echec={echec} hors_tolerance_N3={hors_tol} "
             f"balises_sans_page={sans_page}")
    lignes_sortie.append("# " + bilan)
    texte = "\n".join(lignes_sortie) + "\n"
    if sortie:
        pathlib.Path(sortie).write_text(texte, encoding="utf-8")
    print(texte if not sortie else bilan)
    sys.exit(0 if (echec == 0 and hors_tol == 0 and sans_page == 0) else 1)


if __name__ == "__main__":
    main()
