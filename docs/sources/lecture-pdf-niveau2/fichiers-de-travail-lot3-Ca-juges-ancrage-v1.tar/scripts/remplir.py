import sys, pathlib, datetime
p = pathlib.Path(sys.argv[1])
t = p.read_text(encoding="utf-8")
heure = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
rempl = {
    "HEURE_FIN": heure,
    "RESULTAT_CONTROLE": "103 citations contrôlées, 0 échec (102 au niveau 1, blancs seulement ; 1 au niveau 2, césure ; aucune au niveau 3)",
    "RESULTAT_DETAIL": ("103 citations contrôlées, 103 conformes, 0 échec. 70 sont trouvées au niveau 1 dans l'extraction `-layout`, "
                        "32 au niveau 1 en ordre de lecture (citations à cheval sur deux lignes d'une même colonne), "
                        "1 au niveau 2 (césure « Co-hen’s », page 4 de 2608.25869) ; aucune au niveau 3. "
                        "Deux citations figurent aussi sur d'autres pages, sans erreur de page : l'en-tête courant des auteurs de 2608.25869, "
                        "et le texte d'injection de 2508.19461, repris en page 25"),
    "RESULTAT_SYNTHESE": "103 citations contrôlées par script contre la page indiquée, 0 échec ; le contrôle a d'abord été testé sur des cas justes et altérés (règle R5)",
}
for k, v in rempl.items():
    assert t.count(k) == 1, (k, t.count(k))
    t = t.replace(k, v)
p.write_text(t, encoding="utf-8")
print("heure de fin :", heure)
