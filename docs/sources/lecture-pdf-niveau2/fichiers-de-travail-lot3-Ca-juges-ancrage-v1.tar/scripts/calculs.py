# Calculs sur chiffres recopies des tableaux de 2608.25869v1 (pages 4, 6, 7, 8) et 2508.19461v1 (page 15).
from itertools import combinations
ancres = [1.0, 2.0, 3.0, 3.9]           # p. 6 et p. 7 : valeurs d'ancre des sondes
a_bar = sum(ancres) / len(ancres)
print(f"moyenne des ancres = {a_bar:.4f}")
# Tableau 7 (p. 7) : C0, C2, delta, pente intra-C2
t7 = {"reference": (4.245, 3.817, -0.429, 0.2674), "CoT": (4.458, 3.825, -0.633, 0.506), "avertissement": (4.500, 4.043, -0.457, -0.0066)}
for k, (c0, c2, d, s) in t7.items():
    pred = s * (a_bar - c0)                      # si destination = ancre, g = pente
    off = (d / s - a_bar + c0) if abs(s) > 0.05 else float("nan")   # beta = 1 : c_hat(a) = a + off
    print(f"{k}: g(=pente)={s:.4f}  delta predit si c_hat=ancre = {pred:.3f}  observe = {d:.3f}  ecart relatif = {(pred-d)/d:+.1%}  decalage de destination si beta=1 : {off:+.3f}")
    print(f"   ecart de note entre ancre 1,0 et 3,9 (pente x 2,9) = {s*2.9:.3f}")
# Sonde GPT-4.1 ecriture creative (p. 6)
c0, c2 = 5.00, 4.358
g_impl = (c2 - c0) / (a_bar - c0)
print(f"sonde GPT-4.1 : g implicite si destination = ancre = {g_impl:.3f} ; pente de note attendue = {g_impl:.3f} par unite d'ancre ; partie decimale moyenne impliquee si P('4')=1 : {c2-4:.3f}")
# Industrie (p. 8)
print(f"groupe A : baisse relative de la correction = {(21.62-11.26)/21.62:.1%} ; groupe B : 17/167 = {17/167:.2%} ; 17/219 = {17/219:.2%}")
# Figure 4 (p. 6) : delta C2-C0 par modele et categorie (valeurs imprimees dans la carte)
f4 = {"Claude-4.5-Sonnet": (0.45, -1.00, -0.93, -1.34), "DeepSeek-R1": (-0.33, -0.22, -0.31, -0.22), "GPT-4.1": (-0.27, -0.47, -0.47, -0.44),
      "Gemma-2-9B": (0.04, -0.07, -0.11, -0.15), "Llama-3.1-8B": (0.20, -0.10, -0.09, -0.05), "Llama-3.2-3B": (-0.22, -0.17, -0.31, -0.32),
      "Llama-3.3-70B": (-0.04, 0.01, -0.08, 0.01), "Qwen2.5-7B": (-0.21, -0.24, -0.41, -0.07)}
cats = ["CodeRev", "Writing", "FactQnA", "Summary"]
def rangs(v):
    idx = sorted(range(len(v)), key=lambda i: v[i])
    r = [0.0]*len(v); i = 0
    while i < len(idx):
        j = i
        while j+1 < len(idx) and v[idx[j+1]] == v[idx[i]]: j += 1
        for k in range(i, j+1): r[idx[k]] = (i + j) / 2 + 1
        i = j + 1
    return r
def spearman(x, y):
    rx, ry = rangs(x), rangs(y); n = len(x)
    mx, my = sum(rx)/n, sum(ry)/n
    num = sum((a-mx)*(b-my) for a, b in zip(rx, ry))
    den = (sum((a-mx)**2 for a in rx) * sum((b-my)**2 for b in ry)) ** 0.5
    return num / den
mods = list(f4)
cols = {c: [f4[m][i] for m in mods] for i, c in enumerate(cats)}
for a, b in combinations(cats, 2):
    print(f"Spearman {a} / {b} = {spearman(cols[a], cols[b]):+.3f}")
# Tableau 2 (p. 4) : delta et d
t2 = {"Llama-3.2-3B": (-0.254, -0.71), "GPT-4.1": (-0.411, -0.67), "Qwen2.5-7B": (-0.233, -0.51), "Claude-4.5-Sonnet": (-0.706, -0.44),
      "DeepSeek-R1": (-0.269, -0.25), "Gemma-2-9B": (-0.072, -0.18), "Llama-3.3-70B": (-0.025, -0.09), "Llama-3.1-8B": (-0.009, -0.02)}
print(f"Spearman delta / d (tableau 2) = {spearman([v[0] for v in t2.values()], [v[1] for v in t2.values()]):+.3f}")
# 2508.19461 p. 15 : TPR humain
print(f"gain de TPR a 1 % de FPR : 36,2 - 20,6 = {36.2-20.6:.1f} points ; figure : 0,360 - 0,210 = {0.360-0.210:.3f}")
