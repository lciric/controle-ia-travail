import sys, unicodedata, collections, pathlib
c = collections.Counter()
for d in sys.argv[1:]:
    for f in sorted(pathlib.Path(d).glob("p*.txt")):
        for ch in f.read_text(encoding="utf-8"):
            if ord(ch) > 127:
                c[ch] += 1
for ch, n in c.most_common():
    print(f"U+{ord(ch):04X}\t{n}\t{unicodedata.name(ch, '?')}\t{ch!r}")
