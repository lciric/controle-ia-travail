#!/usr/bin/env python3
"""Controle des citations du rapport C1a (lecteur neuf, lot 2, niveau 2).

Chaque citation doit figurer, mot pour mot, dans le texte extrait de la page
indiquee du PDF indique. Tolerances admises, et elles seules :
  - les blancs : toute suite d'espaces, tabulations ou fins de ligne compte
    pour une seule espace (un blanc ajoute ou retire a l'interieur d'un mot
    reste un echec ; il est signale « blancs internes ») ;
  - les cesures de fin de ligne (« mot-\\n suite ») sont admises sous les deux
    lectures (« motsuite » et « mot-suite ») ; le trait d'union conditionnel
    U+00AD est retire.
Trois extractions de la meme page sont consultees : `pdftotext -layout` (qui
fixe la numerotation des pages), `pdftotext` sans option (ordre de lecture) et
`pdftotext` recadre colonne gauche puis colonne droite (options -x -y -W -H),
utile quand deux colonnes s'entrelacent ligne a ligne. La page est la meme.

Entree : un fichier TSV « identifiant<TAB>page<TAB>citation » (lignes vides et
lignes commencant par « # » ignorees).
Sortie : une ligne par citation (OK ou ECHEC, extraction ayant concorde) et un
bilan. Code de retour 0 si tout concorde, 1 sinon, 2 si une page est absente
ou si l'entree est mal formee (aucun repli silencieux).

Usage : python3 -I controle_citations.py CITATIONS.tsv DOSSIER_LAYOUT DOSSIER_BRUT DOSSIER_COLONNES
"""
import pathlib
import re
import sys


def variantes(texte):
    texte = texte.replace("­", "")
    sans = re.sub(r"-[ \t]*\n[ \t]*", "", texte)
    avec = re.sub(r"-[ \t]*\n[ \t]*", "-", texte)
    return (texte, sans, avec)


def normalise(chaine):
    return re.sub(r"\s+", " ", chaine).strip()


def compacte(chaine):
    return re.sub(r"\s+", "", chaine)


def present(citation, texte):
    c = normalise(citation)
    if not c:
        raise ValueError("citation vide")
    return any(c in normalise(v) for v in variantes(texte))


def present_sans_blancs(citation, texte):
    c = compacte(citation)
    return any(c in compacte(v) for v in variantes(texte))


def lire_page(dossier, ident, page):
    chemin = pathlib.Path(dossier) / ident / ("p%02d.txt" % page)
    if not chemin.is_file():
        raise FileNotFoundError("page absente : %s" % chemin)
    return chemin.read_text(encoding="utf-8")


def main(argv):
    if len(argv) != 5:
        print(__doc__)
        return 2
    fichier = argv[1]
    dossiers = (("layout", argv[2]), ("brut", argv[3]), ("colonnes", argv[4]))
    lignes = pathlib.Path(fichier).read_text(encoding="utf-8").splitlines()
    total = echecs = a_revoir = 0
    for numero, ligne in enumerate(lignes, 1):
        if not ligne.strip() or ligne.startswith("#"):
            continue
        champs = ligne.split("\t")
        if len(champs) != 3:
            print("ENTREE MAL FORMEE ligne %d : %r" % (numero, ligne))
            return 2
        ident, page_txt, citation = champs
        try:
            page = int(page_txt)
            textes = [(nom, lire_page(d, ident, page)) for nom, d in dossiers]
        except (ValueError, FileNotFoundError) as erreur:
            print("ERREUR ligne %d : %s" % (numero, erreur))
            return 2
        total += 1
        concordes = [nom for nom, t in textes if present(citation, t)]
        if concordes and "colonnes" in concordes:
            print("OK     %s p.%d [%s] %s" % (ident, page, ",".join(concordes), citation[:70]))
        elif concordes:
            # Limite connue (test R5) : une chaine qui melange deux colonnes
            # existe litteralement dans les extractions entremelees. Toute
            # concordance absente de l'extraction par colonnes est donc
            # signalee, pour revue a la main (page a une colonne, tableau,
            # titre en pleine largeur).
            a_revoir += 1
            print("OK*    %s p.%d [%s] %s  <- a revoir a la main (absente de l'extraction par colonnes)"
                  % (ident, page, ",".join(concordes), citation[:70]))
        else:
            echecs += 1
            note = ""
            if any(present_sans_blancs(citation, t) for _, t in textes):
                note = " (blancs internes : concorde seulement si l'on ignore tous les blancs)"
            print("ECHEC  %s p.%d %s%s" % (ident, page, citation[:70], note))
    print("BILAN : %d citations controlees, %d echec(s) ; concordances a revoir a la main (OK*) : %d"
          % (total, echecs, a_revoir))
    return 0 if echecs == 0 else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
