#!/usr/bin/env python3
"""Controle des citations d'un rapport contre le texte extrait page par page.

Usage :
    python3 -I controle_citations.py RAPPORT.md DOSSIER_LAYOUT DOSSIER_BRUT

Format attendu dans le rapport :
  - une section par article : titre de niveau 2 ('## ') contenant l'identifiant
    de fichier (ex. 2506.10805v4) ; le texte de la page N est lu dans
    DOSSIER/<identifiant>/pNNN.txt ;
  - chaque citation controlee s'ecrit  p. N : « citation anglaise »
    (N = rang de la page dans le fichier PDF).

Tolerance : seulement les blancs (espaces, tabulations, retours a la ligne)
et les cesures (trait d'union en fin de ligne). Normalisation Unicode NFKC
des deux cotes (ligatures typographiques). Rien d'autre n'est tolere.

On cherche d'abord dans le texte 'pdftotext -layout' de la page ; si la
citation n'y est pas contigue (mise en page a deux colonnes entrelacees),
on cherche dans le texte en ordre de lecture (pdftotext sans -layout) de la
MEME page. Le mode retenu est affiche.

Garde (R5, aucun repli silencieux) : code de retour 1 si une citation
echoue, si une page est absente, si une citation est hors section d'article,
ou si une section d'article ne contient aucune citation.
"""
import os
import re
import sys
import unicodedata

MOTIF_CITATION = re.compile(r"p\.\s?(\d+)\s?:\s?«\s*(.+?)\s*»")
MOTIF_ID = re.compile(r"(\d{4}\.\d{5}v\d+)")
# separateur tolere entre deux caracteres non blancs de la citation :
# des blancs, eventuellement une cesure (trait d'union suivi d'un retour a la ligne)
SEP = r"\s*(?:-[ \t]*\r?\n\s*)?"


def normaliser(texte):
    return unicodedata.normalize("NFKC", texte)


def motif_de(citation):
    caracteres = [c for c in normaliser(citation) if not c.isspace()]
    if not caracteres:
        return None
    return re.compile(SEP.join(re.escape(c) for c in caracteres))


def lire_page(dossier, ident, page):
    chemin = os.path.join(dossier, ident, "p%03d.txt" % page)
    if not os.path.isfile(chemin):
        return None, chemin
    with open(chemin, encoding="utf-8", errors="strict") as f:
        return normaliser(f.read()), chemin


def main(argv):
    if len(argv) != 4:
        print(__doc__)
        return 2
    rapport, dossier_layout, dossier_brut = argv[1], argv[2], argv[3]
    with open(rapport, encoding="utf-8") as f:
        lignes = f.read().splitlines()

    ident = None
    resultats = []  # (ident, page, statut, mode, extrait)
    erreurs = []
    par_section = {}
    for numero, ligne in enumerate(lignes, 1):
        if ligne.startswith("## "):
            m = MOTIF_ID.search(ligne)
            ident = m.group(1) if m else None
            if ident:
                par_section.setdefault(ident, 0)
            continue
        for m in MOTIF_CITATION.finditer(ligne):
            page, citation = int(m.group(1)), m.group(2)
            if ident is None:
                erreurs.append("ligne %d : citation hors section d'article : %s" % (numero, citation[:60]))
                continue
            par_section[ident] += 1
            motif = motif_de(citation)
            if motif is None:
                erreurs.append("ligne %d : citation vide" % numero)
                continue
            texte_l, chemin_l = lire_page(dossier_layout, ident, page)
            texte_b, chemin_b = lire_page(dossier_brut, ident, page)
            if texte_l is None or texte_b is None:
                erreurs.append("ligne %d : page absente (%s ou %s)" % (numero, chemin_l, chemin_b))
                resultats.append((ident, page, "ECHEC", "page absente", citation))
                continue
            if motif.search(texte_l):
                resultats.append((ident, page, "OK", "layout", citation))
            elif motif.search(texte_b):
                resultats.append((ident, page, "OK", "ordre de lecture", citation))
            else:
                resultats.append((ident, page, "ECHEC", "introuvable sur la page", citation))

    for ident_s, n in sorted(par_section.items()):
        if n == 0:
            erreurs.append("section %s : aucune citation controlee" % ident_s)

    for ident_r, page, statut, mode, citation in resultats:
        extrait = citation if len(citation) <= 90 else citation[:87] + "..."
        print("%-5s %-14s p.%-3d %-24s %s" % (statut, ident_r, page, mode, extrait))
    total = len(resultats)
    echecs = sum(1 for r in resultats if r[2] != "OK")
    brut = sum(1 for r in resultats if r[3] == "ordre de lecture")
    print("---")
    for ident_s, n in sorted(par_section.items()):
        e = sum(1 for r in resultats if r[0] == ident_s and r[2] != "OK")
        print("section %-14s : %3d citations, %d echec(s)" % (ident_s, n, e))
    print("TOTAL : %d citations controlees, %d echec(s), dont %d trouvees en ordre de lecture" % (total, echecs, brut))
    for e in erreurs:
        print("ERREUR : " + e)
    return 1 if (echecs or erreurs or total == 0) else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
