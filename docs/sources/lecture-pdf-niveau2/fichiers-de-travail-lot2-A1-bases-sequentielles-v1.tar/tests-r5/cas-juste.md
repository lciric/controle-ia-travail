# Test R5 — cas justes
## 2506.10805v4
- p. 10 : « can achieve robust generalization performance (mean AUROC > 0.91) on diverse, out-of-distribution, real-world datasets »
## 2005.07821v1
- césure (at- tacker) : p. 1 : « An intelligent attacker can design stealthy attacks with knowledge of the system model and noise characteristics »
## 2504.10374v1
- deux colonnes : p. 8 : « Result: A safety score of 87.1% at 95% usefulness. This is the best resampling protocol, as seen in Table 1. »
