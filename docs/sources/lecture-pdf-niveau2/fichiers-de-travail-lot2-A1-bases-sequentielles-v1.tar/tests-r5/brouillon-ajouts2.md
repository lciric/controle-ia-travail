## 2005.07821v1
p. 1 : « Paul J Bonczek and Nicola Bezzo »
p. 1 : « arXiv:2005.07821v1 [eess.SY] 15 May 2020 »
## 2506.10805v4
p. 1 : « Alex McKenzie1∗ Urja Pawar1∗ Phil Blandfort1∗ William Bankes1,2∗ »
p. 1 : « David Krueger3 Ekdeep Singh Lubana4,5,6 Dmitrii Krasheninnikov7 »
p. 1 : « arXiv:2506.10805v4 [cs.LG] 23 Jan 2026 »
p. 35 : « mean AUROC ∼0.916 across test datasets vs >0.99 on synthetic test data »
## 2507.12691v3
p. 1 : « arXiv:2507.12691v3 [cs.AI] 17 Jan 2026 »
p. 1 : « UCLA, Pivotal Pivotal Apollo Research »
p. 3 : « Monitoring strategies are only given access to public tokens, simulating the challenge of evaluating models whose internal reasoning is hidden. »
p. 7 : « Peak Activation (Pairs) 0.937 0.811 0.768 0.979 0.839 0.867 »
p. 7 : « WBR (sonnet-3.5, RP) 0.956 0.879 0.733 0.936 0.973 0.896 »
## 2504.10374v1
p. 1 : « arXiv:2504.10374v1 [cs.LG] 14 Apr 2025 »
p. 3 : « equivalent to 1% of the actions taken in an episode »
p. 8 : « However, a malicious untrusted monitor might collude with the untrusted agent, lying by rating dangerous code as safe to avoid reporting attacks. »
## 2605.26047v2
p. 1 : « arXiv:2605.26047v2 [cs.AI] 26 May 2026 »
p. 2 : « by up to +10.2 pp (paired 95% CI: [+6.1, +14.3]) with 5 samples per step »
p. 24 : « Safety continues to drop with higher k, down to 8% at k=5. »
p. 3 : « We make auditing decisions on a step-wise basis instead of a trajectory-wise basis because BashArena is designed to model live failures »
p. 2 : « We can recover 6.2 pp of safety gain by drawing 0.4 extra samples per step instead of 4. »
p. 19 : « max gains roughly 22 percentage points from k=1 to k=10 »
## 2605.06455v2
p. 1 : « arXiv:2605.06455v2 [cs.AI] 27 Sep 2026 »
## 2602.14161v2
p. 1 : « arXiv:2602.14161v2 [cs.LG] 19 Jul 2026 »
p. 7 : « 5-Fold Cross-Validation 0.996 »
p. 7 : « LODO (Pooled) 0.912 »
p. 21 : « 3 few-shot examples 46.0% 3.5% »
p. 21 : « Activation probe (t=0.5) 68.2% 3.4% »
## 2504.20271v1
p. 1 : « arXiv:2504.20271v1 [cs.LG] 28 Apr 2025 »
p. 11 : « We find that a layer at model depth 75% is roughly optimal. »
