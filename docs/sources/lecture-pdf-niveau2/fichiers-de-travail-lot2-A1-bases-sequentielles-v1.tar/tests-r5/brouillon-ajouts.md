## 2005.07821v1
p. 6 : « for CUSUM is unaffected while CUSIGN discovers the attack »
p. 6 : « with a noiseless magnitude of 0.1τ C »
## 2506.10805v4
p. 27 : « Llama-3.1-8B 0.916 0.901 »
p. 25 : « the gap between the probe (0.887) and the prompted baseline (0.877, Figure 3) »
p. 2 : « The Attention probe was introduced by Kantamneni et al. (2025). »
## 2504.10374v1
p. 18 : « by assuming that our 257 tasks are i.i.d. samples from the same task distribution »
p. 6 : « Minimum of the scores from a resampling procedure with up to six resamples per action. »
## 2605.06455v2
p. 18 : « τ 2 -Bench 7,583 (5,027) 1,083 (718) 1,083 (718) 1,083 (718) »
p. 29 : « so k=⌈137 × 0.9⌉=124 and at most 12 successful calibration maxima may lie above the threshold. »
