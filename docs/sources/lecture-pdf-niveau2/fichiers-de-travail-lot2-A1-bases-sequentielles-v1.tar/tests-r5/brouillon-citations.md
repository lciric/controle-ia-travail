## 2005.07821v1
p. 1 : « An intelligent attacker can design stealthy attacks with knowledge of the system model and noise characteristics to evade detection from state-of-the-art fault detectors by remaining within detection thresholds. »
p. 1 : « in this paper we propose a run-time monitor called Cumulative Sign (CUSIGN) detector, for identifying stealthy falsified measurements by identifying if measurements are no longer behaving in a random manner. »
p. 1 : « Our approach is validated with simulations on an unmanned ground vehicle (UGV) during a navigation case study. »
p. 3 : « A limitation to the method from (8) is that stealthy attacks purposely hidden within detection boundaries may be undetectable. »
p. 6 : « Subsequently, an attacker can design an attack such that it remains within bounds of CUSUM to not trigger alarms more than expected. »
p. 6 : « Both stealthy attack sequences are designed to be undetectable by CUSUM, but are detected by CUSIGN due to the creation of non-random patterns. »
p. 5 : « The CUSIGN detector alone may not be sufficient as an attacker can change the magnitude of a measurement, but still maintain random signed behavior of the test measure »
p. 6 : « and has perfect knowledge of the state estimator, it will be able to find the estimator output »
p. 2 : « one of which is the Sequential Probability Ratio Testing (SPRT) [Kwon et al. (2016)] that tests the sequence of incoming residuals one at a time by taking the log-likelihood function (LLF). »
p. 5 : « we empirically find that the alarm rate is a Normal distribution as follows »
## 2506.10805v4
p. 1 : « 39th Conference on Neural Information Processing Systems (NeurIPS 2025). »
p. 1 : « Probes’ performance is comparable to that of prompted or finetuned medium-sized LLM monitors, while offering computational savings of six orders-of-magnitude. These savings are enabled by reusing activations of the model that is being monitored. »
p. 5 : « Figure 3: Probes achieve a Mean AUROC across test datasets comparable to the medium (8B-12B) finetuned baselines. »
p. 5 : « However, our best probe detects only 43% of high-stakes cases at 1% FPR, compared to 55% for the best LLM baseline. »
p. 5 : « When measuring TPR @1% FPR, probes still outperform 1B models and finetuned Gemma-3-12B, but other baselines (such as prompted Llama-3.1-8B) score higher. »
p. 10 : « We show that relatively simple probes, trained on synthetically generated data, can achieve robust generalization performance (mean AUROC > 0.91) on diverse, out-of-distribution, real-world datasets. »
p. 10 : « assuming activations of the monitored model are available at no computational cost. »
p. 2 : « We considered taking the mean, the maximum, the last token score, an average weighted by probe score (“Softmax Probe”), an average weighted by a learned linear function (“Attention Probe”), and the maximum score after taking a rolling-window average (“Max of Rolling Means”). »
p. 2 : « To the best of our knowledge, Softmax and Max of Rolling Means have not been used for activation probing before. »
p. 2 : « which includes design decisions such as how to aggregate the activations across the sequence dimension. »
p. 16 : « Applies a rolling mean with window size T »
p. 16 : « to the scores at each sequence position and takes the maximum. »
p. 5 : « for Max of Rolling Means, we use T = 40. »
p. 25 : « For comparison, the Llama-3.3-70B probe achieved 0.916. »
p. 25 : « where the probe (0.916) underperforms the prompted baseline (0.929). »
p. 4 : « labeling an interaction as high-stakes often depends on every token of the conversation to provide the necessary context. »
p. 33 : « they consist of real-world dialogues, multi-turn interactions, and contexts involving tool usage or psychological harm, properties not present in the synthetic training dataset. »
p. 7 : « Finally, embedding a high-stakes prompt in a low-stakes context can reduce probe scores »
p. 10 : « systematically exploring whether white-box access offers unique qualitative advantages beyond cost savings remains open »
p. 4 : « Taking the maximum over per-token predictions biases probes towards the most high-stakes token in a response »
p. 1 : « being around 1,000,000 times more efficient. »
p. 27 : « Llama-3.3-70B 0.970 0.928 »
p. 27 : « Table 8: Chain-of-thought prompting performance. Mean AUROC scores across all six test evaluation datasets. »
p. 10 : « The concept of “high-stakes interactions” is fuzzy, subjective and context-dependent »
## 2507.12691v3
p. 1 : « Aviel Parrack Carlo Leonardo Attubato Stefan Heimersheim »
p. 1 : « Preprint. Under review. »
p. 1 : « We benchmark deception probes by the extent to which the white box monitor outperforms the black-box monitor, i.e. the black-to-white performance boost. »
p. 1 : « We find weak but encouraging black-to-white performance boosts from existing deception probes. »
p. 3 : « Datasets AI Liar, Insider Trading, and Sandbagging are on-policy »
p. 3 : « In contrast, Deception Dilution, Backdoors, and Alpaca are off-policy. »
p. 2 : « We evaluate eight monitoring strategies across five datasets and explore failure modes that arise in practice. »
p. 4 : « This dataset simulates an AI assistant intentionally inserting subtle backdoors into code, however it doesn’t rely on LLaMA-3.3-70B-Instruct to generate the backdoors itself. »
p. 5 : « Each method outputs a "suspiciousness rating" indicating its confidence that a response is deceptive. »
p. 7 : « AUROC is our primary evaluation metric »
p. 7 : « WBR (sonnet-3.5, Pairs) 0.966 0.916 0.776 0.986 0.981 0.925 »
p. 7 : « BBR (sonnet-3.5) 0.822 0.799 0.899 0.934 0.942 0.879 »
p. 7 : « Ensemble (sonnet-3.5, Pairs) 0.953 0.846 0.925 0.994 0.964 0.936 »
p. 8 : « A modest black-to-white performance boost is seen across datasets with the exception of the Backdoors setting in which White-box Reasoning is strictly worse than the black-box monitor alone. »
p. 15 : « However, Alpaca proves ill-suited for this purpose: many monitors achieve 100% true positive rates across most datasets (Figure 5). »
p. 6 : « This normalization reflects a realism constraint, wherein many honest responses are available for calibration but deceptive examples are scarce. »
p. 6 : « Both follow-up methods exploit the insight that a deceptive model might show elevated probe activations during an explicit denial of deception. »
p. 8 : « The probe activation is largely spread out over the entire response, not concentrated on the deceptive claims. »
p. 15 : « For example, Full Averaging (Pairs) drops from 0.966 AUROC on AI Liar to 0.931 on insensitive dilution. »
p. 15 : « Peak activation monitors perform notably better on deception-only dilution than insensitive dilution (0.971 vs 0.811 for Pairs, and 0.931 vs 0.877 for RP). »
p. 9 : « We suspect that such probes will grow increasingly valuable as assistants perform long-horizon tasks, where deception can be limited to only a tiny fraction of the output. »
p. 7 : « Deception No (RP) 0.928 0.879 0.667 0.997 0.457 0.786 »
p. 9 : « the same model is used in both Black-box Reasoning and White-box Reasoning, so any black-to-white performance boosts can be attributed to the probes themselves. »
## 2504.10374v1
p. 1 : « Aryan Bhatt 1 Cody Rushing * 1 2 Adam Kaufman * 1 2 Tyler Tracy * 1 2 Vasil Georgiev * 2 3 David Matolcsi 3 »
p. 1 : « Akbir Khan 3 Buck Shlegeris 1 »
p. 1 : « Equal contribution 1 Redwood Research 2 ML Alignment and Theory Scholars (MATS) Program 3 Work done while at Redwood Research. »
p. 1 : « We construct BashBench, a dataset of 257 challenging multi-step system administration tasks »
p. 1 : « We introduce a class of control protocols called resample protocols that dynamically take additional samples of certain actions. »
p. 1 : « our best protocol combines resampling with analysis of previous steps, reducing the success rate of attacks from 58% to 7% at a 5% cost to the performance of a non-malicious agent. »
p. 3 : « we treat GPT-4o mini as if it were untrusted in order to develop control protocols. »
p. 3 : « We implement our trusted model with Llama-3.1-8B (Dubey et al., 2024). »
p. 5 : « Result: A safety score of 72.7% at 95% usefulness. »
p. 8 : « Defer Basic DTR DTR with Incrimination Auditing after Time Travel (Incrimination »
p. 8 : « 95% Usefulness 72.7% 83.2% 84.0% 84.9% 87.1% »
p. 8 : « Result: A safety score of 87.1% at 95% usefulness. This is the best resampling protocol, as seen in Table 1. »
p. 9 : « TM 72.7% 83.2% 87.1% »
p. 9 : « UM 77.6% 91.1% 92.6% »
p. 9 : « Table 2. Comparison at 95% usefulness. TM = Trusted Monitoring, »
p. 2 : « We divide our tasks into 100 train tasks and 157 test tasks and iterate only on the train set of tasks. »
p. 5 : « Result: A safety score of 41.8% at 100% usefulness. »
p. 1 : « the attack policy can break up malicious strategies into many actions to make each action less suspicious. »
p. 7 : « Once this happens for the third time, it audits the trajectory. »
p. 33 : « A step’s looking-back-score is defined as min(cur-score, third-max-so-far) »
p. 22 : « As another baseline, we used the Kolmogorov–Smirnov test which tests the similarity of two distributions. »
p. 22 : « Ultimately, though, we chose to fix all the trusted monitors to simply take the max over substeps for simplicity. »
p. 19 : « The auditing threshold is computed as a quantile on the usefulness baseline distribution »
p. 19 : « Our trusted monitor scaffolds provide the history of a task trajectory, as well as the command to run, to T »
p. 9 : « Hence, we think the relative improvements of our protocols are a more important result than the absolute scores. »
p. 5 : « We created attacks of various lengths and observed that the individual messages of multi-step attacks are less suspicious than single-step attacks »
p. 8 : « catching 98.8% of attacks at a 1% auditing budget. »
## 2605.26047v2
p. 1 : « James Lucassen∗ Adam Kaufman∗ »
p. 1 : « Redwood Research Redwood Research »
p. 1 : « Author order randomized. »
p. 1 : « AI coding scaffolds like Claude Code and Codex use retrying: blocking actions flagged as risky and continuing the trajectory. »
p. 1 : « We also study resampling: drawing multiple samples from the same context, which does not leak exploitable information. »
p. 1 : « In BashArena, with Claude Opus 4.6 as the untrusted model and MiMo-V2-Flash as the trusted monitor, drawing five samples per step and auditing on the maximum suspicion score raises safety from 61% to 71% at a 0.3% audit budget, at no cost to usefulness. »
p. 1 : « The first is that auditing based on the maximum across resampled suspicion scores outperforms using the minimum, which is the opposite of what Ctrl-Z found. »
p. 1 : « gives only a small empirical safety gain in our setting (+3.9 pp, with the confidence interval overlapping zero). »
p. 4 : « As a conservative assumption, the monitor is not shown any chain of thought reasoning used by U to produce its actions. »
p. 4 : « We find that auditing after k strikes decreases safety in our setting for any k > 1. »
p. 24 : « Figure 18 shows that any k > 1 decreases safety: from 61% at k=1 down to 44% at k=2. »
p. 7 : « Assuming the red team has full control over the cross-resample correlations of their attacks, this suggests they should make those correlations either as high as possible or as low as possible, depending on whether the blue team chooses to use max or min aggregation. »
p. 22 : « The best strategies should involve logic that is gradually built up across many different actions, where no single action clearly has anything to do with the red team task. »
p. 5 : « However, feedback does not improve safety against a responsive attack policy at the headline audit budget. »
p. 24 : « If the monitor is already effectively accounting for suspicious past actions when scoring the current step, this leaves no further signal to be captured by numerical history aggregation. »
p. 19 : « Mean and median aggregation show essentially no improvement as the number of samples increases, remaining flat from k=1 to k=10. »
## 2605.06455v2
p. 1 : « Xinmiao Huang1 , Jinwei Hu1 , Qisong He1 , Rajarshi Roy1 , Changshun Wu1 , Yi Dong1, † , »
p. 1 : « Xiaowei Huang1, † »
p. 1 : « University of Liverpool »
p. 1 : « Date: September 25, 2026 »
p. 1 : « We introduce PrefixGuard, a neuro-symbolic method that uses learned events to connect online failure warning with finite-state execution diagnosis. »
p. 1 : « At a nominal 10% FAR budget, averaged test recall spans 56.1%–93.0% across benchmarks. »
p. 6 : « We set γG by split-conformal calibration [2] on successful calibration runs at a nominal FAR budget of 10% (Appendix B.4). »
p. 18 : « For the n successful calibration trajectories, let mi = maxt ri,t and sort these maxima »
p. 18 : « For a scorer fixed independently of calibration, the split-conformal interpretation requires exchangeability of successful calibration and future trajectories. »
p. 19 : « The bound is marginal over calibration and future trajectories. »
p. 7 : « the split-conformal budget bounds it only in expectation. »
p. 19 : « 3 .735 ± .003 .699 ± .014 .088/.087 .123 ± .003 .997 ± .002 .165 ± .006 13,42,123 »
p. 3 : « We encode each record as a TF-IDF [23] vector et of weighted term frequencies, with the vectorizer fitted on training data and kept fixed thereafter. »
p. 3 : « estimating the probability that the run ends in failure within H further steps. »
p. 6 : « Larger H consistently increased lead but did not uniformly raise recall »
p. 10 : « Performance on unseen tasks and agents remains unmeasured. »
p. 29 : « Silence is therefore a property of the scalar-threshold readout on a small calibration pool »
p. 4 : « From completed training trajectories Dtrain and their terminal outcomes, we derive horizon-specific targets pt without step-level annotations (Appendix B.3). »
## 2602.14161v2
p. 1 : « Max Fomin »
p. 1 : « Zenity »
p. 1 : « Published at the First Workshop on Agents in the Wild: Safety, Security, and Beyond (AIWILD) at ICLR 2026. »
p. 2 : « At matched benign FPR, activation probes lead PromptGuard 2, LlamaGuard, and Llama-as-Judge on indirect and agentic attacks »
p. 26 : « PG 36.7 48.5 37.3 - 100.0 0.4% »
p. 26 : « Ours0.4 45.8 20.4 20.5 24.3 11.5 0.4% »
p. 26 : « LG 97.4 28.9 27.4 - 15.2 3.0% »
p. 26 : « Ours3 63.9 55.6 60.4 87.9 54.1 3.0% »
p. 26 : « LJ 85.8 60.0 7.1 21.5 31.8 4.4% »
p. 26 : « Ours4.4 67.0 62.7 64.9 94.5 63.4 4.4% »
p. 26 : « At LG’s and LJ’s operating points, the probe’s advantages on indirect injection (+33pp and +58pp) and agentic attacks are maintained. »
p. 26 : « At PG’s tight 0.4% FPR all detection rates drop substantially, though the probe still leads on harmful (+9pp). »
p. 26 : « uses a threshold calibrated to match baseline FPR=x on pure-benign datasets under LODO. PG/LG cannot evaluate agentic attacks. »
p. 10 : « Ours=LogReg on Llama-3.1-8B raw activations under LODO at fixed thresholds 0.5 (default) and 0.9 (conservative) »
p. 4 : « The defender has white-box access to LLM activations during inference but cannot modify the underlying model »
p. 27 : « Llama-3.1-8B-Instruct as zero-shot classifier with system prompt instructing SAFE/UNSAFE classification. »
p. 11 : « LODO is not adversarial robustness. »
p. 16 : « InjecAgent (Zhan et al., 2024) tests prompt injection via tool responses in agentic workflows. »
p. 26 : « Llama-Guard-3-8B (Meta AI, 2024). »
p. 26 : « Llama-Prompt-Guard-2-86M (Chennabasappa et al., 2025), fine-tuned mDeBERTa. »
p. 4 : « from the last token of the user message (before the generation-prompt tokens; see Appendix C.3) »
p. 6 : « Evaluation uses 5-fold CV, held-out test sets, and LODO. »
## 2504.20271v1
p. 1 : « Henk Tillman Dan Mossing »
p. 1 : « OpenAI OpenAI »
p. 15 : « Our approaches making use of inference time compute might fail catastrophically if the monitoring prompt acts as a trigger for this kind of collusion. »
p. 15 : « In these cases, “side-car” methods which involve no additional forward passes (e.g. non-prompting-based probes) may have the advantage that they are unable to act as a trigger for collusion. »
p. 15 : « it is possible the monitor might collude with the policy to label certain unsafe outputs as safe, particularly in cases where they share model weights. »
p. 15 : « However, they do not provide evidence that such techniques will perform well in cases where there is known to be strong incentive/optimization pressure for collusion. »
p. 1 : « activation probing methods can substantially outperform this baseline given sufficient training data. »
p. 3 : « We examine activations of a previous ChatGPT-4o snapshot across all tasks. »
p. 12 : « However, max-pooling decreases raw activation probing performance. »
p. 6 : « over all the tokens in the passage, but this technique substantially degrades performance compared to simply probing the last token. »
p. 8 : « In particular, all probing techniques are substantially stronger than prompted model outputs in detecting hallucinations in response to SimpleQA questions. »
