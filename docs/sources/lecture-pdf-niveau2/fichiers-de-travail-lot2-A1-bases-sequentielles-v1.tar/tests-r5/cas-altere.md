# Test R5 — cas altérés
## 2506.10805v4
- chiffre changé : p. 10 : « can achieve robust generalization performance (mean AUROC > 0.95) on diverse, out-of-distribution, real-world datasets »
- bonne citation, mauvaise page : p. 9 : « can achieve robust generalization performance (mean AUROC > 0.91) on diverse, out-of-distribution, real-world datasets »
## 2005.07821v1
- mot changé : p. 1 : « An intelligent attacker can design stealthy attacks with knowledge of the system model and signal characteristics »
## 2504.10374v1
- chiffre changé, deux colonnes : p. 8 : « Result: A safety score of 81.7% at 95% usefulness. This is the best resampling protocol, as seen in Table 1. »
## 2507.12691v3
- section sans citation
