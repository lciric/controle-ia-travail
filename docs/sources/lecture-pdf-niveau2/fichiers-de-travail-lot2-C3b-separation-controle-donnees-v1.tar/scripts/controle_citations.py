#!/usr/bin/env python3
"""Controle des citations exactes contre le texte extrait de la page indiquee.

Regles appliquees :
- la page citee est le rang de la page dans le fichier PDF (extraction page par page) ;
- chaque PDF est d'abord verifie par son empreinte sha256 ; toute difference arrete tout ;
- la page est reextraite par pdftotext, en deux modes : avec mise en page (-layout) et
  dans l'ordre de lecture (sans option) ; les deux extractions portent sur la meme page ;
- seules sont tolerees les differences de blancs (niveau A) et, en plus, les traits d'union
  de cesure (niveau B : suppression des caracteres - U+2010 U+2011 et du tiret conditionnel) ;
- aucun repli silencieux : page hors du fichier, extraction vide ou en echec => ERREUR.

Usage : python3 -I controle_citations.py CITATIONS.json EMPREINTES.json DOSSIER_PDF SORTIE.tsv
Code de sortie : 0 si toutes les citations passent, 1 sinon (echec ou erreur).
"""
import hashlib
import json
import re
import subprocess
import sys
import unicodedata

TRAITS_UNION = "-‐‑­"


def empreinte(chemin):
    h = hashlib.sha256()
    with open(chemin, "rb") as f:
        for bloc in iter(lambda: f.read(1 << 20), b""):
            h.update(bloc)
    return h.hexdigest()


def nombre_pages(chemin):
    sortie = subprocess.run(["pdfinfo", chemin], capture_output=True, text=True, check=True).stdout
    m = re.search(r"^Pages:\s+(\d+)", sortie, re.M)
    if not m:
        raise RuntimeError(f"nombre de pages illisible pour {chemin}")
    return int(m.group(1))


def extraire(chemin, page, layout):
    cmd = ["pdftotext"] + (["-layout"] if layout else []) + ["-f", str(page), "-l", str(page), chemin, "-"]
    res = subprocess.run(cmd, capture_output=True)
    if res.returncode != 0:
        raise RuntimeError(f"pdftotext en echec ({' '.join(cmd)}) : {res.stderr.decode(errors='replace')}")
    texte = res.stdout.decode("utf-8")
    if not texte.strip():
        raise RuntimeError(f"extraction vide : {chemin} page {page} layout={layout}")
    return texte


def niveau_a(s):
    s = unicodedata.normalize("NFC", s)
    return "".join(s.split())


def niveau_b(s):
    s = niveau_a(s)
    return "".join(c for c in s if c not in TRAITS_UNION)


def controler(cit, pdfs, cache):
    pdf = cit["pdf"]
    page = int(cit["page"])
    if pdf not in pdfs:
        raise RuntimeError(f"PDF inconnu {pdf}")
    chemin, npages = pdfs[pdf]
    if page < 1 or page > npages:
        raise RuntimeError(f"page {page} hors du fichier {pdf} ({npages} pages)")
    resultats = {}
    for mode, layout in (("layout", True), ("lecture", False)):
        cle = (pdf, page, mode)
        if cle not in cache:
            cache[cle] = extraire(chemin, page, layout)
        texte = cache[cle]
        resultats[mode + "_A"] = niveau_a(cit["citation"]) in niveau_a(texte)
        resultats[mode + "_B"] = niveau_b(cit["citation"]) in niveau_b(texte)
    return resultats


def main():
    if len(sys.argv) != 5:
        print(__doc__)
        sys.exit(2)
    f_cit, f_emp, dossier, f_sortie = sys.argv[1:]
    with open(f_cit, encoding="utf-8") as f:
        citations = json.load(f)
    with open(f_emp, encoding="utf-8") as f:
        attendues = json.load(f)
    version = subprocess.run(["pdftotext", "-v"], capture_output=True, text=True)
    version = (version.stderr or version.stdout).splitlines()[0]
    pdfs = {}
    for nom, h_att in attendues.items():
        chemin = f"{dossier.rstrip('/')}/{nom}.pdf"
        h = empreinte(chemin)
        if h != h_att:
            print(f"ARRET : empreinte differente pour {nom} : {h} au lieu de {h_att}")
            sys.exit(1)
        pdfs[nom] = (chemin, nombre_pages(chemin))
    cache = {}
    lignes = ["id\tpdf\tpage\tlayout_A\tlayout_B\tlecture_A\tlecture_B\tverdict"]
    n_ok = n_echec = n_err = 0
    for cit in citations:
        try:
            r = controler(cit, pdfs, cache)
            if r["layout_A"] or r["lecture_A"]:
                verdict = "PASSE_A"
            elif r["layout_B"] or r["lecture_B"]:
                verdict = "PASSE_B"
            else:
                verdict = "ECHEC"
            vals = [str(r[k]) for k in ("layout_A", "layout_B", "lecture_A", "lecture_B")]
        except Exception as e:  # aucun repli silencieux : l'erreur est consignee et comptee
            verdict = f"ERREUR ({e})"
            vals = ["-"] * 4
        if verdict.startswith("PASSE"):
            n_ok += 1
        elif verdict == "ECHEC":
            n_echec += 1
        else:
            n_err += 1
        lignes.append("\t".join([cit["id"], cit["pdf"], str(cit["page"])] + vals + [verdict]))
    with open(f_sortie, "w", encoding="utf-8") as f:
        f.write(f"# outil : {version}\n")
        f.write("\n".join(lignes) + "\n")
        f.write(f"# total {len(citations)} ; passent {n_ok} ; echecs {n_echec} ; erreurs {n_err}\n")
    print("\n".join(lignes))
    print(f"outil : {version}")
    print(f"total {len(citations)} ; passent {n_ok} ; echecs {n_echec} ; erreurs {n_err}")
    sys.exit(0 if (n_echec == 0 and n_err == 0) else 1)


if __name__ == "__main__":
    main()
