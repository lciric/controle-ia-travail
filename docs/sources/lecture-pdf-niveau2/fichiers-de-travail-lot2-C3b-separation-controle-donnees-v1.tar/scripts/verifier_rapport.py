"""Verifie que chaque citation reproduite dans le rapport ([ID] « ... ») est identique a celle controlee."""
import collections
import json
import re
import sys

rapport = open(sys.argv[1], encoding="utf-8").read()
cits = {c["id"]: c for c in json.load(open(sys.argv[2], encoding="utf-8"))}
tsv = {}
for ligne in open(sys.argv[3], encoding="utf-8"):
    if ligne.startswith("#") or ligne.startswith("id\t"):
        continue
    p = ligne.rstrip("\n").split("\t")
    tsv[p[0]] = p[-1]
paires = re.findall(r"\[([A-D]\d\d)\] « (.*?) »", rapport, re.S)
ko = 0
for i, txt in paires:
    if i not in cits:
        print("ID INCONNU", i)
        ko += 1
        continue
    if " ".join(txt.split()) != " ".join(cits[i]["citation"].split()):
        print("DIFFERENT", i)
        ko += 1
    if not tsv.get(i, "").startswith("PASSE"):
        print("NON CONTROLE", i)
        ko += 1
refs = set(re.findall(r"\[([A-D]\d\d)\]", rapport))
print("reproduites", len(paires), "; ids cites", len(refs), "; inconnus", sorted(r for r in refs if r not in cits), "; anomalies", ko)
print("par article", dict(collections.Counter(k[0] for k in cits)))
print("controlees non citees", sorted(set(cits) - refs))
