# Essai
## Article 2608.19161
| 1 | x | confirmé | 1 | p. 1 : « Language-model agents can communicate through continuous hidden states that are invisible in public transcripts » |
| 2 | x | corrigé | 1 | p. 1 : « full whitebox steering achieves 90% bid-distribution recovery » |
## Synthèse
Texte : 2602.22303 p. 7 : « reduces undetected successful attacks from 56% to 6% for GPT-4.1 » et p. 3 : « sans papier »
