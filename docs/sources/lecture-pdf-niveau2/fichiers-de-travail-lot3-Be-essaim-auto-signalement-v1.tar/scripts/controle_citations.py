"""Controle des citations exactes d'un rapport contre le texte extrait page par page.

Les textes extraits (pdftotext -layout, une page par fichier pNNN.txt) sont des donnees
non fiables : ils sont seulement lus comme texte, jamais executes.

Usage :
  python3 -I controle_citations.py --textes DOSSIER --auto-test
  python3 -I controle_citations.py --textes DOSSIER --rapport RAPPORT.md

Forme reconnue dans le rapport, sur une seule ligne :
  p. N : « citation anglaise mot pour mot »
  2608.19161 p. N : « ... »      (papier explicite)
Sans papier explicite, le papier est celui du dernier titre Markdown (ligne commencant
par #) qui contient un seul identifiant connu.

Tolerances, et seulement elles :
  - les blancs (espaces, sauts de ligne, tabulations) sont ignores des deux cotes ;
  - une cesure de fin de ligne (trait d'union suivi d'un saut de ligne) est facultative :
    « invisi-\\nble » vaut « invisible », et « LLM-\\nbacked » vaut « LLM-backed ».
  - l'elision explicite « […] » coupe la citation en fragments qui doivent apparaitre
    dans l'ordre sur la meme page.
Tout autre ecart (mot, chiffre, ponctuation, trait d'union en milieu de ligne) echoue.
"""
import argparse
import re
import sys
from pathlib import Path

CESURE = "­"  # marqueur interne d'une cesure de fin de ligne
PAPIERS = ("2608.19161", "2602.22303")
ELISION = "[…]"
MOTIF_CITATION = re.compile(
    r"(?:(?P<papier>" + "|".join(re.escape(p) for p in PAPIERS) + r")\s*,?\s*)?"
    r"p\.\s*(?P<page>\d+)\s*:\s*«\s*(?P<citation>[^«»]+?)\s*»"
)


def normaliser_page(texte: str) -> str:
    t = re.sub(r"-[ \t]*\r?\n\s*", CESURE, texte)
    return re.sub(r"\s+", "", t)


def motif(fragment: str) -> re.Pattern:
    q = re.sub(r"\s+", "", fragment)
    morceaux = []
    for c in q:
        if c == "-":
            morceaux.append("(?:-|" + CESURE + ")")
        else:
            morceaux.append(re.escape(c) + CESURE + "?")
    return re.compile("".join(morceaux))


def verifier(textes: Path, papier: str, page: int, citation: str):
    f = textes / papier / f"p{page:03d}.txt"
    if not f.is_file():
        return False, f"page absente : {f}"
    texte_page = normaliser_page(f.read_text(encoding="utf-8"))
    fragments = [x.strip() for x in citation.split(ELISION)]
    fragments = [x for x in fragments if x]
    if not fragments:
        return False, "citation vide"
    pos = 0
    for frag in fragments:
        m = motif(frag).search(texte_page, pos)
        if not m:
            return False, "introuvable : " + frag[:70]
        pos = m.end()
    return True, "ok"


def auto_test(textes: Path) -> int:
    juste = ("Language-model agents can communicate through continuous hidden states "
             "that are invisible in public transcripts")
    cas = [
        ("juste, avec cesure invisi-/ble", "2608.19161", 1, juste, True),
        ("altere : un mot change (invisible -> visible)", "2608.19161", 1,
         juste.replace("invisible", "visible"), False),
        ("altere : un chiffre change (47.3 -> 47.8)", "2608.19161", 1,
         "reduces collusive low-bid behavior by 47.8 percentage points", False),
        ("juste : meme passage, chiffre exact", "2608.19161", 1,
         "reduces collusive low-bid behavior by 47.3 percentage points", True),
        ("mauvaise page (citation juste, page 2)", "2608.19161", 2, juste, False),
        ("trait d'union insere en milieu de ligne", "2608.19161", 1,
         "Language-model agents can com-municate through", False),
        ("cesure d'un mot compose LLM-/backed", "2608.19161", 8,
         "the number of LLM-backed bidders increases", True),
        ("blancs differents", "2608.19161", 1,
         "Language-model   agents\ncan communicate", True),
        ("elision dans l'ordre", "2608.19161", 1,
         "Language-model agents can communicate " + ELISION +
         " creating opportunities for covert harmful coordination", True),
        ("elision dans le desordre", "2608.19161", 1,
         "creating opportunities for covert harmful coordination " + ELISION +
         " Language-model agents can communicate", False),
        ("artefact : page inexistante", "2608.19161", 99, juste, False),
        ("juste, autre papier, cesure Self-/incrimination", "2602.22303", 7,
         "Self-incrimination training reduces undetected successful attacks from 56% to 6% for GPT-4.1",
         True),
        ("altere, autre papier (56% -> 66%)", "2602.22303", 7,
         "Self-incrimination training reduces undetected successful attacks from 66% to 6% for GPT-4.1",
         False),
    ]
    echecs = 0
    for nom, papier, page, citation, attendu in cas:
        obtenu, detail = verifier(textes, papier, page, citation)
        bon = obtenu == attendu
        echecs += 0 if bon else 1
        print(f"[{'BON' if bon else 'MAUVAIS'}] {nom} : attendu={attendu} obtenu={obtenu} ({detail})")
    print(f"auto-test : {len(cas)} cas, {echecs} comportement(s) inattendu(s)")
    return 1 if echecs else 0


def controle_rapport(textes: Path, rapport: Path) -> int:
    papier_courant = None
    total = 0
    echecs = 0
    sans_papier = 0
    for n, ligne in enumerate(rapport.read_text(encoding="utf-8").splitlines(), 1):
        if ligne.startswith("#"):
            trouves = [p for p in PAPIERS if p in ligne]
            if len(trouves) == 1:
                papier_courant = trouves[0]
            elif len(trouves) == 0 and ligne.startswith("## "):
                papier_courant = None
        for m in MOTIF_CITATION.finditer(ligne):
            total += 1
            papier = m.group("papier") or papier_courant
            if papier is None:
                sans_papier += 1
                echecs += 1
                print(f"ligne {n} : ECHEC (papier inconnu) : {m.group('citation')[:60]}")
                continue
            ok, detail = verifier(textes, papier, int(m.group("page")), m.group("citation"))
            if not ok:
                echecs += 1
            print(f"ligne {n} : {papier} p. {m.group('page')} : {'OK' if ok else 'ECHEC'}"
                  + ("" if ok else f" ({detail})"))
    print(f"citations controlees : {total} ; echecs : {echecs} ; sans papier : {sans_papier}")
    return 1 if (echecs or total == 0) else 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--textes", required=True, type=Path)
    ap.add_argument("--rapport", type=Path)
    ap.add_argument("--auto-test", action="store_true")
    a = ap.parse_args()
    if a.auto_test:
        return auto_test(a.textes)
    if a.rapport:
        return controle_rapport(a.textes, a.rapport)
    ap.error("--auto-test ou --rapport")
    return 2


if __name__ == "__main__":
    sys.exit(main())
