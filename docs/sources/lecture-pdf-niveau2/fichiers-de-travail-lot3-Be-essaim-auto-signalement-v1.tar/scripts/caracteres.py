"""Compte les caracteres non ASCII des textes extraits (donnees non fiables, lues seulement)."""
import sys
import unicodedata
from collections import Counter
from pathlib import Path

compte = Counter()
for dossier in sys.argv[1:]:
    for f in sorted(Path(dossier).glob("p*.txt")):
        for c in f.read_text(encoding="utf-8", errors="replace"):
            if ord(c) > 127:
                compte[c] += 1
for c, n in compte.most_common():
    print(f"U+{ord(c):04X}\t{n}\t{unicodedata.name(c, '?')}")
