"""Compte les formes d'un terme dans les pages extraites (cesures de fin de ligne recollees)."""
import re
import sys
from collections import Counter
from pathlib import Path

dossier = Path(sys.argv[1])
racine = sys.argv[2].lower()
formes = Counter()
pages = set()
for f in sorted(dossier.glob("p*.txt")):
    t = f.read_text(encoding="utf-8")
    t = re.sub(r"-[ \t]*\n\s*", "-", t)  # recolle les cesures en gardant le trait d'union
    for m in re.finditer(r"[A-Za-z-]*" + re.escape(racine) + r"[A-Za-z-]*", t, flags=re.IGNORECASE):
        formes[m.group(0).lower()] += 1
        pages.add(int(f.stem[1:]))
print("pages :", len(pages), "de", min(pages) if pages else "-", "a", max(pages) if pages else "-")
print("total :", sum(formes.values()))
for k, v in formes.most_common():
    print(v, k)
