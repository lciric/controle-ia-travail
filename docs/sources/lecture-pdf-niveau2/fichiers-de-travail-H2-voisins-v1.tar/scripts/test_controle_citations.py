"""Test de la garde de contrôle des citations : cas sains et artefacts (règle R5).

Usage : python3 -I test_controle_citations.py RACINE_TRAVAIL
Sortie non nulle si un cas sain échoue ou si un artefact passe.
"""
import importlib.util
import pathlib
import sys

ici = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("cc", ici / "controle_citations.py")
cc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cc)

R = sys.argv[1]
K = "2604.28129v1"
CAS = [
    # (attendu, page, citation, description)
    (True, 3, "The defender has white-box access to the target model’s internal activations and deploys a probe that monitors the residual stream in real time.", "sain : phrase sur deux lignes, colonne gauche"),
    (True, 1, "attack, produce high false positive rates on out-of-distribution inputs", "sain : trait d'union coupé en fin de ligne"),
    (True, 19, "longer LMSYS conversations are harder to detect", "sain : césure LM-/SYS"),
    (True, 5, "improves dramatically: 66–83% of attacks detected early", "sain : tiret demi-cadratin en fin de ligne"),
    (False, 3, "The defender has black-box access to the target model’s internal activations", "artefact : un mot changé"),
    (False, 3, "The defender has white-box access to the target model's internal activations", "artefact : apostrophe droite au lieu de courbe"),
    (False, 5, "improves dramatically: 67–83% of attacks detected early", "artefact : un chiffre changé"),
    (False, 5, "improves dramatically: 66-83% of attacks detected early", "artefact : tiret remplacé par un trait d'union"),
    (False, 5, "The defender has white-box access to the target model’s internal activations", "artefact : bonne phrase, mauvaise page"),
    (False, 3, "The defender has white-box access … in real time.", "artefact : coupe par points de suspension"),
]
erreurs = 0
for attendu, page, citation, description in CAS:
    obtenu = bool(cc.verifier(R, K, page, citation))
    bon = obtenu == attendu
    erreurs += 0 if bon else 1
    print(("conforme   " if bon else "NON CONFORME") + " | attendu %s, obtenu %s | %s" % (
        "réussite" if attendu else "échec", "réussite" if obtenu else "échec", description))
print("cas : %d ; non conformes : %d" % (len(CAS), erreurs))
sys.exit(1 if erreurs else 0)
