"""Extrait les adresses /URI des annotations de liens d'un PDF (lecture seule).

Lecture brute : objets en clair et flux compressés (FlateDecode) décompressés
en mémoire ; on cherche les motifs /URI (...). Rien n'est écrit sur le PDF.
Usage : python3 -I liens_uri.py FICHIER.pdf
"""
import re
import sys
import zlib


def flux(donnees):
    for m in re.finditer(rb"stream\r?\n", donnees):
        debut = m.end()
        fin = donnees.find(b"endstream", debut)
        if fin < 0:
            continue
        brut = donnees[debut:fin]
        for essai in (brut, brut.rstrip(b"\r\n")):
            try:
                yield zlib.decompress(essai)
                break
            except zlib.error:
                try:
                    yield zlib.decompressobj().decompress(essai)
                    break
                except zlib.error:
                    continue


def main(chemin):
    donnees = open(chemin, "rb").read()
    textes = [donnees] + list(flux(donnees))
    uris = set()
    for t in textes:
        for m in re.finditer(rb"/URI\s*\((.*?)(?<!\\)\)", t, re.S):
            uris.add(m.group(1).decode("latin-1"))
    for u in sorted(uris):
        print(u)


if __name__ == "__main__":
    main(sys.argv[1])
