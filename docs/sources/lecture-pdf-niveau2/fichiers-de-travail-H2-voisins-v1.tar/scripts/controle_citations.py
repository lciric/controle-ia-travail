"""Contrôle des citations du rapport contre les extractions `pdftotext -layout`.

Règle de tolérance (et rien d'autre) :
  - toute suite de blancs de la citation (espace, fin de ligne, rembourrage de
    mise en page) correspond à une suite non vide de blancs dans le texte extrait ;
  - une césure de fin de ligne est admise : après n'importe quel caractère de la
    citation, le texte extrait peut contenir « - » + fin de ligne (mot coupé) ;
  - un trait d'union réel, un tiret (demi-cadratin ou cadratin) ou une barre
    oblique de la citation peut être suivi d'une fin de ligne dans le texte
    extrait (coupure de ligne typographique sans espace : mot composé,
    intervalle « 66–83 », adresse).
Aucune autre normalisation : casse, ponctuation, guillemets, chiffres et
symboles doivent être identiques.

Sources essayées, toutes produites par `pdftotext -layout`, page par page
(la page citée est le rang de la page dans le fichier PDF) :
  extraits/<id>/pNN.txt                    page entière
  extraits-colonnes/<id>/pNN.gauche.txt    demi-page gauche (x 0 à 306 pt)
  extraits-colonnes/<id>/pNN.droite.txt    demi-page droite (x 306 à 612 pt)

Format attendu du rapport : chaque section d'article a un titre de niveau 2
contenant l'identifiant arXiv (ex. 2604.28129v1) ; dans les tableaux, la
colonne dont l'en-tête commence par « page » donne la ou les pages, la colonne
dont l'en-tête commence par « citation » contient une ou plusieurs citations
entre guillemets français « … ». Si la colonne page contient autant de numéros
que de citations, ils sont appariés dans l'ordre ; si elle en contient un seul,
toutes les citations de la ligne sont cherchées sur cette page.

Usage :
  python3 -I controle_citations.py RAPPORT.md RACINE_TRAVAIL [SORTIE.txt]
  python3 -I controle_citations.py --essai RACINE_TRAVAIL ID PAGE "citation"
"""
import pathlib
import re
import sys

ID_RE = re.compile(r"\b(\d{4}\.\d{5}v\d)\b")
CIT_RE = re.compile(r"«\s?(.*?)\s?»", re.S)
CESURE = r"(?:-[ \t]*\n[ \t]*)?"
FIN_LIGNE_APRES_TRAIT = r"(?:[ \t]*\n[ \t]*)?"
# Caractères après lesquels la mise en page peut couper la ligne sans espace :
# trait d'union, tiret demi-cadratin, tiret cadratin, barre oblique (adresses).
COUPURES = "-–—/"


def motif(citation):
    morceaux = []
    i = 0
    n = len(citation)
    while i < n:
        c = citation[i]
        if c.isspace():
            while i < n and citation[i].isspace():
                i += 1
            morceaux.append(r"\s+")
            continue
        if c in COUPURES:
            morceaux.append(re.escape(c) + FIN_LIGNE_APRES_TRAIT)
        else:
            morceaux.append(re.escape(c) + CESURE)
        i += 1
    return re.compile("".join(morceaux))


def sources(racine, ident, page):
    racine = pathlib.Path(racine)
    nn = "p%02d" % page
    chemins = [
        ("page entière", racine / "extraits" / ident / (nn + ".txt")),
        ("colonne gauche", racine / "extraits-colonnes" / ident / (nn + ".gauche.txt")),
        ("colonne droite", racine / "extraits-colonnes" / ident / (nn + ".droite.txt")),
    ]
    for nom, chemin in chemins:
        if chemin.exists():
            yield nom, chemin.read_text(encoding="utf-8")


def verifier(racine, ident, page, citation):
    m = motif(citation.strip())
    trouve = []
    for nom, texte in sources(racine, ident, page):
        if m.search(texte):
            trouve.append(nom)
    return trouve


def cellules(ligne):
    ligne = ligne.strip()
    if ligne.startswith("|"):
        ligne = ligne[1:]
    if ligne.endswith("|"):
        ligne = ligne[:-1]
    return [c.strip() for c in ligne.split("|")]


def lire_rapport(chemin):
    ident = None
    entetes = None
    resultats = []
    lignes = pathlib.Path(chemin).read_text(encoding="utf-8").splitlines()
    for num, ligne in enumerate(lignes, 1):
        if ligne.startswith("## "):
            m = ID_RE.search(ligne)
            ident = m.group(1) if m else None
            entetes = None
            continue
        if not ligne.lstrip().startswith("|"):
            entetes = None
            continue
        cs = cellules(ligne)
        if entetes is None:
            entetes = [c.lower() for c in cs]
            continue
        if all(set(c) <= set("-: ") for c in cs):
            continue
        i_page = next((i for i, h in enumerate(entetes) if h.startswith("page")), None)
        i_cit = next((i for i, h in enumerate(entetes) if h.startswith("citation")), None)
        if i_cit is None or i_cit >= len(cs):
            continue
        citations = CIT_RE.findall(cs[i_cit])
        if not citations:
            continue
        pages = [int(x) for x in re.findall(r"\d+", cs[i_page])] if i_page is not None and i_page < len(cs) else []
        if ident is None:
            resultats.append((num, None, None, citations[0], "ERREUR : section sans identifiant arXiv"))
            continue
        if len(pages) == len(citations):
            paires = list(zip(pages, citations))
        elif len(pages) == 1:
            paires = [(pages[0], c) for c in citations]
        else:
            for c in citations:
                resultats.append((num, ident, pages, c, "ERREUR : pages et citations non appariables"))
            continue
        for page, c in paires:
            trouve = verifier(RACINE, ident, page, c)
            etat = "OK (" + ", ".join(trouve) + ")" if trouve else "ÉCHEC"
            resultats.append((num, ident, page, c, etat))
    return resultats


if __name__ == "__main__":
    if sys.argv[1] == "--essai":
        RACINE = sys.argv[2]
        trouve = verifier(RACINE, sys.argv[3], int(sys.argv[4]), sys.argv[5])
        print("OK (" + ", ".join(trouve) + ")" if trouve else "ÉCHEC")
        sys.exit(0 if trouve else 1)
    RACINE = sys.argv[2]
    res = lire_rapport(sys.argv[1])
    sortie = []
    for num, ident, page, c, etat in res:
        court = c if len(c) <= 90 else c[:87] + "..."
        sortie.append("ligne %s | %s | p. %s | %s | %s" % (num, ident, page, etat, court))
    nb = len(res)
    nb_ok = sum(1 for r in res if r[4].startswith("OK"))
    sortie.append("")
    sortie.append("Citations contrôlées : %d ; réussies : %d ; échouées : %d" % (nb, nb_ok, nb - nb_ok))
    texte = "\n".join(sortie)
    print(texte)
    if len(sys.argv) > 3:
        pathlib.Path(sys.argv[3]).write_text(texte + "\n", encoding="utf-8")
    sys.exit(0 if nb == nb_ok and nb > 0 else 1)
