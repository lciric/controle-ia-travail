"""Teste un lot de citations candidates (une par ligne : ID|PAGE|citation)."""
import importlib.util
import pathlib
import sys

ici = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("cc", ici / "controle_citations.py")
cc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cc)

racine = sys.argv[1]
echecs = 0
total = 0
for ligne in pathlib.Path(sys.argv[2]).read_text(encoding="utf-8").splitlines():
    if not ligne.strip() or ligne.startswith("#"):
        continue
    ident, page, citation = ligne.split("|", 2)
    total += 1
    trouve = cc.verifier(racine, ident, int(page), citation)
    if not trouve:
        echecs += 1
    print(("OK   " if trouve else "ÉCHEC") + " %s p.%s %s" % (ident, page, citation[:100]))
print("total %d, échecs %d" % (total, echecs))
