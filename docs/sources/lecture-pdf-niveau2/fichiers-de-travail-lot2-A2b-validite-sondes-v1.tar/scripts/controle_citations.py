"""Controle des citations exactes d'un rapport de lecture contre le texte extrait des PDF.

Regle : une citation passe seulement si elle se retrouve, a la page indiquee (rang dans le
fichier), dans le texte extrait par pdftotext page par page, dans au moins un des modes
fournis (-layout, -raw, ordre de lecture par defaut).
Seules tolerances :
- les blancs, partout (citation et texte compares sans blancs) ;
- les cesures : entre deux lettres de la citation peut s'intercaler, dans le texte, un trait
  d'union suivi d'un retour a la ligne ; un trait d'union de la citation doit exister dans le
  texte, en ligne ou en fin de ligne (jamais absent).
Limite connue : un mot cite sans le trait d'union qu'il porte en fin de ligne dans le PDF
passe (ambiguite propre a la cesure).

Format attendu dans le rapport (markdown) :
- titre d'article : ligne commencant par "## " et contenant "arXiv NNNN.NNNNNvN" ;
- ligne de tableau : une cellule "p. N" ; les citations sont entre guillemets droits "..."
  dans les cellules qui suivent ;
- prose : "citation" (p. N).

Usage : python3 -I controle_citations.py RAPPORT.md MODE=DOSSIER [MODE=DOSSIER ...]
  ou chaque DOSSIER contient <article>/pNNN.txt.
Code de sortie : 0 si toutes les citations passent et qu'il y en a au moins une, 1 sinon.
"""
import re
import sys
from pathlib import Path

TITRE_ARTICLE = re.compile(r"arXiv\s+(\d{4}\.\d{5}v\d+)")
CELLULE_PAGE = re.compile(r"^p\.\s*(\d+)$")
GUILLEMETS = re.compile(r'"([^"]+)"')
PROSE = re.compile(r'"([^"]+)"\s*\(p\.\s*(\d+)\)')
MARQUE_CESURE = "\x00"  # trait d'union de fin de ligne dans le texte extrait


def preparer_texte(texte: str) -> str:
    """Marque les cesures (trait d'union suivi d'un retour a la ligne), puis retire tous les blancs."""
    texte = re.sub(r"-[ \t]*\r?\n", MARQUE_CESURE, texte)
    return re.sub(r"\s+", "", texte)


def motif(citation: str) -> re.Pattern:
    """Expression reguliere sur la citation sans blancs, tolerant seulement les cesures."""
    texte = re.sub(r"\s+", "", citation)
    morceaux = []
    for i, c in enumerate(texte):
        suivant = texte[i + 1] if i + 1 < len(texte) else ""
        if c == "-":
            morceaux.append(f"(?:-|{MARQUE_CESURE})")
        else:
            morceaux.append(re.escape(c))
            if c.isalpha() and suivant.isalpha():
                morceaux.append(f"{MARQUE_CESURE}?")
    return re.compile("".join(morceaux))


def extraire(rapport: Path):
    """Renvoie la liste (ligne, article, page, citation) et les anomalies de format."""
    citations, anomalies = [], []
    article = None
    for n, ligne in enumerate(rapport.read_text(encoding="utf-8").splitlines(), 1):
        if ligne.startswith("#"):
            if ligne.startswith("## "):
                m = TITRE_ARTICLE.search(ligne)
                article = m.group(1) if m else None
            continue
        if ligne.lstrip().startswith("|"):
            cellules = [c.strip() for c in ligne.strip().strip("|").split("|")]
            page, idx = None, None
            for j, cel in enumerate(cellules):
                m = CELLULE_PAGE.match(cel)
                if m:
                    page, idx = int(m.group(1)), j
                    break
            trouvees = []
            if idx is not None:
                for cel in cellules[idx + 1:]:
                    trouvees += GUILLEMETS.findall(cel)
                avant = sum(cel.count('"') for cel in cellules[: idx + 1])
                apres = sum(cel.count('"') for cel in cellules[idx + 1:])
                if avant:
                    anomalies.append((n, "guillemets droits avant la cellule de page"))
                if apres != 2 * len(trouvees):
                    anomalies.append((n, "citation coupee (barre verticale ?) ou guillemets non apparies"))
            elif any('"' in cel for cel in cellules):
                anomalies.append((n, "citation dans un tableau sans cellule de page"))
            for q in trouvees:
                if article is None:
                    anomalies.append((n, "citation hors section d'article"))
                else:
                    citations.append((n, article, page, q))
            continue
        for q, p in PROSE.findall(ligne):
            if article is None:
                anomalies.append((n, "citation hors section d'article"))
            else:
                citations.append((n, article, int(p), q))
        if '"' in PROSE.sub("", ligne):
            anomalies.append((n, "guillemets droits sans page, ou non apparies, dans la prose"))
    return citations, anomalies


def controler(citations, modes):
    resultats = []
    for n, article, page, q in citations:
        fichier = f"p{page:03d}.txt"
        trouve = None
        for nom_mode, dossier in modes:
            chemin = dossier / article / fichier
            if chemin.exists() and motif(q).search(preparer_texte(chemin.read_text(encoding="utf-8"))):
                trouve = nom_mode
                break
        resultats.append((n, article, page, q, trouve))
    return resultats


def main(argv):
    rapport = Path(argv[1])
    modes = [(a.split("=", 1)[0], Path(a.split("=", 1)[1])) for a in argv[2:]]
    citations, anomalies = extraire(rapport)
    resultats = controler(citations, modes)
    echecs = [r for r in resultats if r[4] is None]
    for n, article, page, q, mode in resultats:
        etat = f"OK ({mode})" if mode else "ECHEC"
        print(f"ligne {n:4d} | {article} p.{page:<3d} | {etat:14s} | {q[:90]}")
    for n, quoi in anomalies:
        print(f"ligne {n:4d} | ANOMALIE DE FORMAT : {quoi}")
    print(f"\nTOTAL citations controlees : {len(resultats)} ; echecs : {len(echecs)} ; "
          f"anomalies de format : {len(anomalies)}")
    return 0 if resultats and not echecs and not anomalies else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
