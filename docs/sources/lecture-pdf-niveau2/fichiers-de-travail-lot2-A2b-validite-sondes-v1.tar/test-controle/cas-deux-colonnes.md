## Article test — arXiv 2605.27958v1

| # | affirmation | verdict | page | citation exacte |
|---|---|---|---|---|
| C1 | juste, a cheval sur des lignes d'une colonne | attendu OK (lecture) | p. 1 | "the single-direction hypothesis is decisively rejected (k=1 captures only 0.61–0.80 AUROC of the signal" |
| C2 | altere (0.61-0.90) | attendu ECHEC | p. 1 | "the single-direction hypothesis is decisively rejected (k=1 captures only 0.61–0.90 AUROC of the signal" |
| C3 | melange de colonnes (debut colonne gauche + fin colonne droite) | attendu ECHEC | p. 1 | "Linear probes trained on internal activations of The rapid evolution of Large Language Models" |
