## Article test — arXiv 2509.26238v4

| # | affirmation | verdict | page | citation exacte |
|---|---|---|---|---|
| T1 | juste, une ligne | attendu OK | p. 1 | "Published as a conference paper at ICLR 2026" |
| T2 | juste, avec cesure en fin de ligne | attendu OK | p. 1 | "higher-order guardrails are evaluated only for ambiguous inputs, reducing overall monitoring costs" |

## Article test — arXiv 2502.03407v1

Prose juste sur plusieurs lignes : "When responses are only partially deceptive, however, this can result in a misclassification even if the per-token probe activations are sensible" (p. 8).

## Article test — arXiv 2605.27958v1

| # | affirmation | verdict | page | citation exacte |
|---|---|---|---|---|
| T4 | juste, retour a la ligne apres un tiret long | attendu OK (lecture) | p. 1 | "style-augmented probes recover near-perfect detection (mean AUROC 0.979–0.983) even on unseen styles" |

## Article test — arXiv 2606.07612v1

| # | affirmation | verdict | page | citation exacte |
|---|---|---|---|---|
| T5 | juste, trait d'union reel en fin de ligne | attendu OK (raw) | p. 2 | "In this paper, we define AMR as a family of alignment-oriented studies that investigate safety-relevant failure" |
