## Article test — arXiv 2509.26238v4

| # | affirmation | verdict | page | citation exacte |
|---|---|---|---|---|
| A1 | un mot altere | attendu ECHEC | p. 1 | "Published as a conference paper at ICML 2026" |
| A2 | juste mais mauvaise page | attendu ECHEC | p. 2 | "Published as a journal paper at ICLR 2026" |
| A3 | citation juste, page fausse | attendu ECHEC | p. 3 | "we introduce Truncated Polynomial Classifiers (TPCs)" |
| A4 | tableau sans page | attendu ANOMALIE | — | "Published as a conference paper at ICLR 2026" |

## Article test — arXiv 2502.03407v1

Prose alteree : "When responses are only partially deceptive, however, this will result in a misclassification" (p. 8).

## Article test — arXiv 2605.27958v1

| # | affirmation | verdict | page | citation exacte |
|---|---|---|---|---|
| A5 | chiffre altere apres le tiret long | attendu ECHEC | p. 1 | "style-augmented probes recover near-perfect detection (mean AUROC 0.979–0.993) even on unseen styles" |
| A6 | trait d'union ajoute dans un mot sans cesure | attendu ECHEC | p. 1 | "style-augmented probes re-cover near-perfect detection" |

## Article test — arXiv 2606.07612v1

| # | affirmation | verdict | page | citation exacte |
|---|---|---|---|---|
| A7 | trait d'union reel omis en milieu de ligne | attendu ECHEC | p. 2 | "investigate safetyrelevant failure" |
| A8 | limite connue : trait d'union de fin de ligne omis | passe (ambiguite de cesure, documentee) | p. 2 | "a family of alignmentoriented studies" |

## Article test — arXiv 2605.27958v1

| # | affirmation | verdict | page | citation exacte |
|---|---|---|---|---|
| A9 | citation coupee par une barre verticale | attendu ANOMALIE | p. 7 | "maximum |ρ|=0.454 (well below the 0.8 threshold for P4a)" |

Prose avec guillemet non apparie : "maximum (p. 7).
