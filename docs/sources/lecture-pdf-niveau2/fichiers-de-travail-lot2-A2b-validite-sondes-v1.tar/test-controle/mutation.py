import re, sys
from pathlib import Path
src = Path(sys.argv[1]).read_text(encoding="utf-8")
def alterer(m):
    q = m.group(1)
    lettres = [i for i, c in enumerate(q) if c.isalnum()]
    i = lettres[len(lettres) // 2]
    c = q[i]
    nouveau = ("7" if c != "7" else "3") if c.isdigit() else ("x" if c.lower() != "x" else "z")
    return '"' + q[:i] + nouveau + q[i + 1:] + '"'
Path(sys.argv[2]).write_text(re.sub(r'"([^"]+)"', alterer, src), encoding="utf-8")
