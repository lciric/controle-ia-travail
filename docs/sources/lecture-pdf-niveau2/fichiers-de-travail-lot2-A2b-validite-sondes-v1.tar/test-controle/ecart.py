import re, sys
sys.path.insert(0, sys.argv[2])
from controle_citations import extraire
from pathlib import Path
rapport = Path(sys.argv[1])
lues = [(n, q) for n, a, p, q in extraire(rapport)[0]]
for n, ligne in enumerate(rapport.read_text(encoding="utf-8").splitlines(), 1):
    for q in re.findall(r'"([^"]*)"', ligne):
        if (n, q) not in lues:
            print(n, repr(q[:120]))
