"""Liste les passages entre « » que le contrôle des citations ne repère pas (pour vérifier qu'aucun n'est une citation anglaise)."""
import importlib.util, re, sys, pathlib
spec = importlib.util.spec_from_file_location("cc", sys.argv[1]); cc = importlib.util.module_from_spec(spec); spec.loader.exec_module(cc)
lignes = pathlib.Path(sys.argv[2]).read_text(encoding="utf-8").splitlines()
reperees = {}
for n, pdf, page, q in cc.extraire(lignes):
    reperees.setdefault(n, []).append(q)
for n, l in enumerate(lignes, 1):
    for q in re.findall(r"«\s*(.+?)\s*»", l):
        if q not in reperees.get(n, []):
            print(f"{n:4d}: {q[:110]}")
