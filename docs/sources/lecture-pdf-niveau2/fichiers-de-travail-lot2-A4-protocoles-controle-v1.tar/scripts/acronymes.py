"""Liste les mots en capitales (2 lettres ou plus) du texte français, hors citations « », code `...` et marqueurs [pdf: ...]."""
import re, sys, pathlib, collections
t = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")
t = re.sub(r"«.*?»", " ", t)
t = re.sub(r"`[^`]*`", " ", t)
t = re.sub(r"\[pdf:[^\]]*\]", " ", t)
c = collections.Counter(re.findall(r"\b[A-Z][A-Z0-9\-\.]*[A-Z0-9]\b", t))
for k, v in sorted(c.items()):
    print(k, v)
