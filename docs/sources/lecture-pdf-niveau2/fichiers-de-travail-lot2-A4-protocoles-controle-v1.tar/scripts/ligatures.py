import sys, pathlib, collections
racine = pathlib.Path(sys.argv[1])
for d in sorted(p for p in racine.iterdir() if p.is_dir()):
    c = collections.Counter()
    for f in sorted(d.glob("p*.txt")):
        t = f.read_text(encoding="utf-8", errors="replace")
        for ch in t:
            if 0xFB00 <= ord(ch) <= 0xFB06:
                c[(f.name, ch)] += 1
    print(d.name, sum(c.values()), sorted(set(k[0] for k in c))[:12])
