#!/usr/bin/env python3
"""Contrôle des citations d'un rapport contre le texte extrait page par page.

Le texte de référence est celui de `pdftotext -layout`, un fichier par page :
DOSSIER_TEXTE/<identifiant arXiv avec version>/pNNN.txt (NNN = rang de la page dans le fichier).

Tolérances, et rien d'autre :
  - blancs : toute suite d'espaces, tabulations, sauts de ligne ou de page vaut un seul blanc ;
  - césures : un trait d'union suivi d'un saut de ligne (« orches-\\ntrate ») est accepté,
    que la citation écrive le mot entier (« orchestrate ») ou le composé (« attack-honest »).
Aucune normalisation Unicode : apostrophes, guillemets, tirets et ligatures doivent être exacts.

Repérage des citations dans le rapport (Markdown) :
  - l'article courant est fixé par un titre contenant « [pdf: 2510.09462v2] » ;
  - dans un tableau dont l'en-tête a une colonne « page » et une colonne « citation exacte »,
    chaque « … » de la colonne citation est contrôlé à la page de la colonne page,
    sauf s'il porte un marqueur explicite « p. N : « … » » ;
  - ailleurs, seules les citations marquées « p. N : « … » » sont contrôlées ; le marqueur peut
    nommer un autre article : « 2604.13301v1 p. 8 : « … » ».

Usage : python3 -I controle_citations.py RAPPORT.md DOSSIER_TEXTE
Code de sortie : 0 si toutes les citations passent et qu'il y en a au moins une ; 1 sinon.
"""
import pathlib
import re
import sys

ID_RE = re.compile(r"\[pdf:\s*(\d{4}\.\d{5}v\d+)\]")
MARQUE_RE = re.compile(r"(?:(\d{4}\.\d{5}v\d+)\s+)?p\.\s*(\d+)\s*:\s*«\s*(.+?)\s*»")
GUILLEMETS_RE = re.compile(r"«\s*(.+?)\s*»")


def normaliser_blancs(texte):
    return re.sub(r"\s+", " ", texte).strip()


def motif(citation):
    """Expression régulière qui n'accepte que les écarts de blancs et de césure."""
    q = normaliser_blancs(citation)
    morceaux = []
    for i, c in enumerate(q):
        if c == " ":
            morceaux.append(r"\s+")
        elif c == "-":
            morceaux.append(r"-\s?")
        else:
            morceaux.append(re.escape(c))
            suivant = q[i + 1] if i + 1 < len(q) else ""
            if c.isalpha() and suivant.isalpha():
                morceaux.append(r"(?:-\s)?")
    return re.compile("".join(morceaux))


def cellules(ligne):
    return [c.strip() for c in ligne.strip().strip("|").split("|")]


def extraire(lignes):
    """Rend (numéro de ligne, pdf, page, citation) ou (numéro, None, None, message d'erreur)."""
    pdf_courant = None
    entete = None
    for n, ligne in enumerate(lignes, 1):
        if ligne.startswith("#"):
            m = ID_RE.search(ligne)
            if m:
                pdf_courant = m.group(1)
            entete = None
            continue
        if ligne.lstrip().startswith("|"):
            cs = cellules(ligne)
            bas = [c.lower() for c in cs]
            if "page" in bas and any("citation exacte" in c for c in bas):
                entete = (bas.index("page"),
                          next(i for i, c in enumerate(bas) if "citation exacte" in c))
                continue
            if set(ligne.replace("|", "").strip()) <= set("-: "):
                continue
            if entete is not None:
                ip, ic = entete
                if ic >= len(cs):
                    yield (n, None, None, "ligne de tableau plus courte que l'en-tête")
                    continue
                cellule = cs[ic]
                marques = list(MARQUE_RE.finditer(cellule))
                if marques:
                    for m in marques:
                        yield (n, m.group(1) or pdf_courant, int(m.group(2)), m.group(3))
                    continue
                citations = GUILLEMETS_RE.findall(cellule)
                if not citations:
                    continue
                pages = re.findall(r"\d+", cs[ip]) if ip < len(cs) else []
                if len(pages) != 1:
                    yield (n, None, None, "page ambiguë ou absente pour une citation sans marqueur")
                    continue
                for q in citations:
                    yield (n, pdf_courant, int(pages[0]), q)
                continue
        else:
            entete = None
        for m in MARQUE_RE.finditer(ligne):
            yield (n, m.group(1) or pdf_courant, int(m.group(2)), m.group(3))


def main():
    if len(sys.argv) != 3:
        print(__doc__)
        return 2
    rapport = pathlib.Path(sys.argv[1])
    dossier = pathlib.Path(sys.argv[2])
    lignes = rapport.read_text(encoding="utf-8").splitlines()
    total = reussies = 0
    echecs = []
    for n, pdf, page, citation in extraire(lignes):
        total += 1
        if pdf is None:
            echecs.append((n, "?", "?", citation, "erreur de repérage"))
            print(f"ligne {n:4d} | ? | ? | ÉCHEC | {citation}")
            continue
        fichier = dossier / pdf / f"p{page:03d}.txt"
        if not fichier.exists():
            echecs.append((n, pdf, page, citation, "page ou article absent"))
            print(f"ligne {n:4d} | {pdf} | p. {page} | ÉCHEC (page absente) | {citation[:70]}")
            continue
        texte = normaliser_blancs(fichier.read_text(encoding="utf-8"))
        rx = motif(citation)
        if rx.search(texte):
            reussies += 1
            print(f"ligne {n:4d} | {pdf} | p. {page} | OK | {citation[:70]}")
        else:
            ailleurs = []
            for autre in sorted((dossier / pdf).glob("p*.txt")):
                if rx.search(normaliser_blancs(autre.read_text(encoding="utf-8"))):
                    ailleurs.append(int(autre.stem[1:]))
            note = f"trouvée p. {ailleurs}" if ailleurs else "introuvable dans l'article"
            echecs.append((n, pdf, page, citation, note))
            print(f"ligne {n:4d} | {pdf} | p. {page} | ÉCHEC ({note}) | {citation[:70]}")
    print(f"BILAN : {total} citations contrôlées, {reussies} réussies, {len(echecs)} échecs")
    if total == 0:
        print("ERREUR : aucune citation repérée (refus de conclure)")
        return 1
    return 0 if not echecs else 1


if __name__ == "__main__":
    sys.exit(main())
