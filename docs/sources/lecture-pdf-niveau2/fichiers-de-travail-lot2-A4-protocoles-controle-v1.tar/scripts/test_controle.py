"""Test R5 du contrôle des citations : compare les statuts obtenus aux statuts attendus."""
import subprocess, sys, pathlib
script, test, texte = sys.argv[1], sys.argv[2], sys.argv[3]
attendus = ["OK", "ÉCHEC", "ÉCHEC", "OK", "ÉCHEC", "ÉCHEC", "ÉCHEC", "OK", "OK", "ÉCHEC"]
sortie = subprocess.run([sys.executable, "-I", script, test, texte], capture_output=True, text=True)
print(sortie.stdout)
obtenus = [l.split("|")[3].strip().split(" ")[0] for l in sortie.stdout.splitlines() if l.startswith("ligne")]
print("attendus :", attendus)
print("obtenus  :", obtenus)
bon = obtenus == attendus and sortie.returncode == 1
print("TEST R5 :", "RÉUSSI" if bon else "RATÉ", "| code de sortie du contrôle :", sortie.returncode, "(1 attendu, car des cas altérés échouent)")
sys.exit(0 if bon else 1)
