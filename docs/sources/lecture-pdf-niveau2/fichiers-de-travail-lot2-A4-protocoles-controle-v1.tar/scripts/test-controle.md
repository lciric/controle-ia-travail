# Test du contrôle des citations (règle R5) [pdf: 2510.09462v2]

| # | cas | attendu | page | citation exacte |
|---|---|---|---|---|
| 1 | juste, sur deux lignes du PDF | OK | 1 | « Following Kerckhoffs’s principle (Shannon, 1949), we assume that security through obscurity is insufficient » |
| 2 | altéré : un mot changé (insufficient → sufficient) | ÉCHEC | 1 | « Following Kerckhoffs’s principle (Shannon, 1949), we assume that security through obscurity is sufficient » |
| 3 | juste mais page fausse | ÉCHEC | 2 | « Following Kerckhoffs’s principle (Shannon, 1949), we assume that security through obscurity is insufficient » |
| 4 | césure de fin de ligne (orches-/trate) écrite sans trait d'union | OK | 1 | « or orchestrate multi-step attacks in agentic workflows » |
| 5 | altéré : virgule supprimée | ÉCHEC | 1 | « Following Kerckhoffs’s principle (Shannon 1949), we assume » |
| 6 | altéré : apostrophe droite au lieu de l'apostrophe typographique | ÉCHEC | 1 | « Following Kerckhoffs's principle » |
| 7 | altéré : trait d'union inventé au milieu d'une ligne | ÉCHEC | 1 | « Following Kerck-hoffs’s principle » |

Hors tableau, marqueur explicite juste (attendu OK) : p. 5 : « In BashBench, a trajectory’s audit score is the maximum suspiciousness over its actions. »

Hors tableau, marqueur explicite vers un autre article, juste (attendu OK) : 2604.13301v1 p. 8 : « Adaptive attacks on trusted monitors subvert ai control protocols. »

Hors tableau, marqueur explicite altéré : mot ajouté (attendu ÉCHEC) : p. 5 : « In BashBench, a trajectory’s audit score is the maximum suspiciousness over all its actions. »
