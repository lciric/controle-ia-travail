#!/usr/bin/env python3
"""verifier_citations.py — lot 6, v1.

Controle mot pour mot des citations d'un rapport de lecture sur PDF.

Sous-commandes
--------------
extraire   Controle l'empreinte compagnon (.sha256) de chaque PDF, puis extrait
           chaque page en trois modes (pdftotext -layout, sans option, -raw)
           dans <sortie>/<stem>/<mode>/pNN.txt ; ecrit <sortie>/manifeste.json
           (empreinte du PDF, nombre de pages, version de pdftotext, empreinte
           de chaque fichier extrait).
verifier   Controle chaque citation d'un fichier JSON (liste d'objets
           {"id", "fichier", "page", "texte"}) a la page dite, dans l'un des
           trois modes. Code de sortie 0 seulement si 0 echec.
eprouver   Banc d'essai (R5) : chaque cas porte un resultat attendu
           ("accepte" ou "rejette") ; code de sortie 0 seulement si tous les
           cas sont conformes.

Regles d'appariement (seules tolerances)
----------------------------------------
* Blancs : une suite de blancs de la citation correspond a une suite NON VIDE
  de blancs de la source ; jamais de blanc a l'interieur d'un mot.
* Cesures en fin de ligne : entre deux caracteres alphanumeriques d'un mot de
  la citation, la source peut porter « -<fin de ligne><blancs> » (cesure
  typographique) ; apres un trait d'union reel de la citation, la source peut
  porter une fin de ligne (mot compose coupe en fin de ligne).
* Aucune normalisation Unicode, aucune insensibilite a la casse.
* Bornes de mot : si la citation commence (finit) par un caractere
  alphanumerique, la source ne doit pas en porter un juste avant (apres), ni
  une cesure qui prolongerait le mot ; une citation ne peut donc pas tronquer
  un mot ou un nombre (« 0.97 » ne valide pas « 0.9794 »).
* Toute anomalie (fichier ou page absents, citation vide, empreinte d'un
  fichier extrait differente du manifeste) est un echec explicite, jamais un
  repli silencieux.

Lancer avec « python3 -I » ; aucun module hors de la bibliotheque standard.
"""
import argparse
import hashlib
import json
import os
import re
import subprocess
import sys

MODES = ("layout", "simple", "raw")
OPTIONS_MODE = {"layout": ["-layout"], "simple": [], "raw": ["-raw"]}
FIN_DE_LIGNE = r"[ \t]*\r?\n\s*"
RX_ID = re.compile(r"^Z\d{2,3}$")


class Echec(Exception):
    """Anomalie qui interdit de valider une citation."""


def sha256_fichier(chemin):
    h = hashlib.sha256()
    with open(chemin, "rb") as f:
        for bloc in iter(lambda: f.read(1 << 20), b""):
            h.update(bloc)
    return h.hexdigest()


# ---------------------------------------------------------------- extraction

def controler_compagnon(pdf):
    compagnon = pdf + ".sha256"
    if not os.path.isfile(compagnon):
        raise Echec("compagnon absent : %s" % compagnon)
    with open(compagnon, encoding="utf-8") as f:
        champs = f.read().split()
    if len(champs) < 2:
        raise Echec("compagnon illisible : %s" % compagnon)
    attendu, nom = champs[0], champs[1].lstrip("*")
    if nom != os.path.basename(pdf):
        raise Echec("compagnon %s vise %s" % (compagnon, nom))
    reel = sha256_fichier(pdf)
    if reel != attendu:
        raise Echec("empreinte differente pour %s : %s au lieu de %s" % (pdf, reel, attendu))
    return reel


def nombre_de_pages(pdf):
    sortie = subprocess.run(["pdfinfo", pdf], check=True, capture_output=True, text=True).stdout
    for ligne in sortie.splitlines():
        if ligne.startswith("Pages:"):
            return int(ligne.split()[1])
    raise Echec("nombre de pages introuvable : %s" % pdf)


def version_pdftotext():
    r = subprocess.run(["pdftotext", "-v"], capture_output=True, text=True)
    return (r.stderr or r.stdout).splitlines()[0].strip()


def extraire(args):
    manifeste = {"outil": version_pdftotext(), "pdf": {}}
    for nom in args.pdf:
        pdf = os.path.join(args.dossier_pdf, nom)
        stem = nom[:-4] if nom.endswith(".pdf") else nom
        empreinte = controler_compagnon(pdf)
        n = nombre_de_pages(pdf)
        fichiers = {}
        for mode in MODES:
            os.makedirs(os.path.join(args.sortie, stem, mode), exist_ok=True)
            for p in range(1, n + 1):
                cible = os.path.join(args.sortie, stem, mode, "p%02d.txt" % p)
                subprocess.run(["pdftotext", "-f", str(p), "-l", str(p)] + OPTIONS_MODE[mode]
                               + [pdf, cible], check=True)
                fichiers["%s/p%02d.txt" % (mode, p)] = sha256_fichier(cible)
        manifeste["pdf"][stem] = {"fichier": nom, "sha256": empreinte, "pages": n,
                                  "extractions": fichiers}
        print("extrait %s : %d pages x 3 modes (sha256 %s)" % (nom, n, empreinte))
    with open(os.path.join(args.sortie, "manifeste.json"), "w", encoding="utf-8") as f:
        json.dump(manifeste, f, ensure_ascii=False, indent=1, sort_keys=True)
    return 0


# ---------------------------------------------------------------- appariement

def motif(texte):
    """Expression reguliere d'une citation, avec les seules tolerances admises."""
    mots = texte.split()
    if not mots:
        raise Echec("citation vide")
    morceaux = []
    for mot in mots:
        m = []
        for i, c in enumerate(mot):
            m.append(re.escape(c))
            if i + 1 < len(mot):
                suivant = mot[i + 1]
                if c == "-" and suivant.isalnum():
                    m.append("(?:%s)?" % FIN_DE_LIGNE)          # trait d'union reel coupe
                elif c.isalnum() and suivant.isalnum():
                    m.append("(?:-%s)?" % FIN_DE_LIGNE)         # cesure typographique
        morceaux.append("".join(m))
    return re.compile(r"\s+".join(morceaux))


def bornes_ok(source, debut, fin, citation):
    c = citation.strip()
    if c[0].isalnum() and debut > 0:
        if source[debut - 1].isalnum():
            return False
        j = debut
        while j > 0 and source[j - 1].isspace():
            j -= 1
        if j < debut and "\n" in source[j:debut] and j >= 2 \
                and source[j - 1] == "-" and source[j - 2].isalnum():
            return False                                       # suite d'un mot coupe
    if c[-1].isalnum() and fin < len(source):
        if source[fin].isalnum():
            return False
        if re.match(r"-%s\w" % FIN_DE_LIGNE, source[fin:]):
            return False                                       # mot coupe qui continue
    return True


def trouver(source, rx, citation):
    pos = 0
    while True:
        m = rx.search(source, pos)
        if m is None:
            return None
        if bornes_ok(source, m.start(), m.end(), citation):
            return m
        pos = m.start() + 1


# ---------------------------------------------------------------- verification

def charger_manifeste(dossier):
    chemin = os.path.join(dossier, "manifeste.json")
    if not os.path.isfile(chemin):
        raise Echec("manifeste absent : %s" % chemin)
    with open(chemin, encoding="utf-8") as f:
        return json.load(f)


def lire_page(dossier, manifeste, stem, mode, page):
    rel = "%s/p%02d.txt" % (mode, page)
    chemin = os.path.join(dossier, stem, mode, "p%02d.txt" % page)
    attendu = manifeste["pdf"][stem]["extractions"].get(rel)
    if attendu is None or not os.path.isfile(chemin):
        raise Echec("extraction absente : %s/%s" % (stem, rel))
    if sha256_fichier(chemin) != attendu:
        raise Echec("extraction modifiee depuis le manifeste : %s/%s" % (stem, rel))
    with open(chemin, encoding="utf-8") as f:
        return f.read()


def controler(cit, dossier, manifeste):
    """Renvoie (statut, modes trouves, raison)."""
    try:
        for cle in ("id", "fichier", "page", "texte"):
            if cle not in cit:
                raise Echec("champ manquant : %s" % cle)
        if not isinstance(cit["id"], str) or not RX_ID.match(cit["id"]):
            raise Echec("identifiant invalide : %r" % (cit["id"],))
        fichier = cit["fichier"]
        if not isinstance(fichier, str) or not fichier.endswith(".pdf"):
            raise Echec("fichier invalide : %r" % (fichier,))
        stem = fichier[:-4]
        if stem not in manifeste["pdf"]:
            raise Echec("fichier inconnu du manifeste : %s" % fichier)
        page = cit["page"]
        if not isinstance(page, int) or isinstance(page, bool):
            raise Echec("page non entiere : %r" % (page,))
        n = manifeste["pdf"][stem]["pages"]
        if not 1 <= page <= n:
            raise Echec("page hors bornes : %d (fichier de %d pages)" % (page, n))
        if not isinstance(cit["texte"], str):
            raise Echec("texte non textuel")
        rx = motif(cit["texte"])
        trouves = []
        for mode in MODES:
            source = lire_page(dossier, manifeste, stem, mode, page)
            if trouver(source, rx, cit["texte"]) is not None:
                trouves.append(mode)
        if not trouves:
            raise Echec("introuvable a la page %d dans les trois modes" % page)
        return "OK", trouves, ""
    except Echec as e:
        return "ECHEC", [], str(e)


def verifier(args):
    manifeste = charger_manifeste(args.extractions)
    with open(args.citations, encoding="utf-8") as f:
        citations = json.load(f)
    ids = [c.get("id") for c in citations]
    doublons = sorted({i for i in ids if ids.count(i) > 1})
    lignes, echecs = [], 0
    if doublons:
        echecs += 1
        lignes.append("ECHEC identifiants en double : %s" % ", ".join(map(str, doublons)))
    for cit in citations:
        statut, modes, raison = controler(cit, args.extractions, manifeste)
        if statut != "OK":
            echecs += 1
        lignes.append("%s %s %s p.%s [%s] %s" % (statut, cit.get("id"), cit.get("fichier"),
                                                 cit.get("page"), ",".join(modes), raison))
    lignes.append("BILAN : %d citations controlees, %d echec(s)" % (len(citations), echecs))
    sortie = "\n".join(lignes)
    print(sortie)
    if args.journal:
        with open(args.journal, "w", encoding="utf-8") as f:
            f.write(sortie + "\n")
    return 0 if echecs == 0 else 1


def eprouver(args):
    manifeste = charger_manifeste(args.extractions)
    with open(args.cas, encoding="utf-8") as f:
        cas = json.load(f)
    lignes, conformes, acceptes_ok, rejetes_ok = [], 0, 0, 0
    for c in cas:
        statut, modes, raison = controler(c["citation"], args.extractions, manifeste)
        obtenu = "accepte" if statut == "OK" else "rejette"
        ok = obtenu == c["attendu"]
        conformes += ok
        if ok and obtenu == "accepte":
            acceptes_ok += 1
        if ok and obtenu == "rejette":
            rejetes_ok += 1
        lignes.append("%s %s : attendu %s, obtenu %s [%s] %s -- %s" % (
            "CONFORME" if ok else "NON CONFORME", c["nom"], c["attendu"], obtenu,
            ",".join(modes), raison, c["description"]))
    lignes.append("BILAN : %d cas, %d conformes (%d justes acceptes, %d alteres rejetes), %d non conforme(s)"
                  % (len(cas), conformes, acceptes_ok, rejetes_ok, len(cas) - conformes))
    sortie = "\n".join(lignes)
    print(sortie)
    if args.journal:
        with open(args.journal, "w", encoding="utf-8") as f:
            f.write(sortie + "\n")
    return 0 if conformes == len(cas) else 1


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sp = ap.add_subparsers(dest="commande", required=True)
    a = sp.add_parser("extraire")
    a.add_argument("--dossier-pdf", required=True)
    a.add_argument("--sortie", required=True)
    a.add_argument("pdf", nargs="+")
    b = sp.add_parser("verifier")
    b.add_argument("--citations", required=True)
    b.add_argument("--extractions", required=True)
    b.add_argument("--journal")
    c = sp.add_parser("eprouver")
    c.add_argument("--cas", required=True)
    c.add_argument("--extractions", required=True)
    c.add_argument("--journal")
    args = ap.parse_args()
    try:
        return {"extraire": extraire, "verifier": verifier, "eprouver": eprouver}[args.commande](args)
    except Echec as e:
        print("ARRET : %s" % e, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
