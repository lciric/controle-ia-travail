#!/usr/bin/env python3
"""preparer_banc_synthetique.py — lot 6, v1.

Fabrique un petit arbre d'extraction synthetique (document « synthetique.pdf »,
2 pages x 3 modes) et son manifeste, au format de verifier_citations.py, pour
isoler chaque tolerance du controle : chaque mode porte un texte different, de
sorte qu'un cas ne puisse etre accepte que par le chemin qu'il eprouve.
Usage : python3 -I preparer_banc_synthetique.py DOSSIER_SORTIE
"""
import hashlib
import json
import os
import sys

PAGES = {
    1: {
        # blancs multiples, trait d'union reel coupe, cesure typographique, apostrophe courbe
        "layout": "  Alpha beta   gamma\n     delta-\n     epsilon zeta eta substan-\n   tially alter the 0.9794 value; agent’s view.\n\f",
        # texte sans rapport : rien ne doit y etre trouve
        "simple": "Totally different text here.\n\f",
        # trait d'union en fin de ligne (mot compose ou cesure, ambigu)
        "raw": "Raw only: high-\nstakes decision\n\f",
    },
    2: {
        "layout": "Second page text with calibration 0.9794 numbers.\n\f",
        "simple": "Second page text with calibration 0.9794 numbers.\n\f",
        "raw": "Second page text with calibration 0.9794 numbers.\n\f",
    },
}


def main():
    sortie = sys.argv[1]
    stem = "synthetique"
    fichiers = {}
    for page, modes in PAGES.items():
        for mode, texte in modes.items():
            d = os.path.join(sortie, stem, mode)
            os.makedirs(d, exist_ok=True)
            chemin = os.path.join(d, "p%02d.txt" % page)
            with open(chemin, "w", encoding="utf-8") as f:
                f.write(texte)
            with open(chemin, "rb") as f:
                fichiers["%s/p%02d.txt" % (mode, page)] = hashlib.sha256(f.read()).hexdigest()
    manifeste = {"outil": "banc synthetique (aucun PDF)",
                 "pdf": {stem: {"fichier": stem + ".pdf", "sha256": None,
                                "pages": len(PAGES), "extractions": fichiers}}}
    with open(os.path.join(sortie, "manifeste.json"), "w", encoding="utf-8") as f:
        json.dump(manifeste, f, ensure_ascii=False, indent=1, sort_keys=True)
    print("banc synthetique ecrit dans %s" % sortie)


if __name__ == "__main__":
    main()
