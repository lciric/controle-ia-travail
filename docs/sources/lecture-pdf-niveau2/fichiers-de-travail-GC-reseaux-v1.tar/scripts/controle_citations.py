"""Contrôle des citations du rapport contre le texte extrait des PDF (page par page).

Usage :
  python3 -I controle_citations.py rapport RAPPORT.md
  python3 -I controle_citations.py liste LISTE.tsv     (lignes : article<TAB>page<TAB>citation)

Règles :
- Dans le rapport, une citation est un segment « ... » suivi immédiatement de (p. N).
  L'article est donné par la dernière rubrique de niveau 2 rencontrée :
  « ## Article A » -> 2606.18276v1 ; « ## Article B » -> 2603.15809v1 ; toute autre rubrique de niveau 2
  ferme la zone (une citation hors zone doit porter l'identifiant : (2606.18276v1, p. N)).
- La page citée est le rang dans le fichier PDF ; on compare au fichier extraits*/<article>/pNN.txt.
- Tolérance : normalisation Unicode NFKC, guillemets et tirets typographiques unifiés, casse ignorée,
  espaces, retours à la ligne et traits d'union supprimés des deux côtés (césures tolérées).
- Une citation passe si elle est trouvée dans l'extraction brute OU dans l'extraction avec mise en page.
"""
import pathlib
import re
import sys
import unicodedata

BASE = pathlib.Path(__file__).resolve().parent.parent
ARTICLES = {"A": "2606.18276v1", "B": "2603.15809v1"}
PAR_ID = {v: k for k, v in ARTICLES.items()}

REMPLACEMENTS = {
    "’": "'", "‘": "'", "“": '"', "”": '"', "′": "'",
    "–": "-", "—": "-", "−": "-", "‐": "-", "‑": "-",
    "­": "", " ": " ", " ": " ",
}


def normaliser(texte: str) -> str:
    texte = unicodedata.normalize("NFKC", texte)
    for avant, apres in REMPLACEMENTS.items():
        texte = texte.replace(avant, apres)
    texte = texte.lower()
    return re.sub(r"[\s\-]+", "", texte)


def textes_page(article: str, page: int):
    ident = ARTICLES[article]
    sortie = []
    for sous in ("extraits-brut", "extraits"):
        chemin = BASE / sous / ident / f"p{page:02d}.txt"
        if not chemin.exists():
            raise FileNotFoundError(chemin)
        sortie.append(normaliser(chemin.read_text(encoding="utf-8", errors="replace")))
    return sortie


def verifier(article: str, page: int, citation: str):
    cible = normaliser(citation)
    if len(cible) < 12:
        return False, "citation trop courte pour être probante"
    for texte in textes_page(article, page):
        if cible in texte:
            return True, ""
    # Diagnostic : la citation est-elle ailleurs dans l'article ?
    ailleurs = []
    ident = ARTICLES[article]
    for chemin in sorted((BASE / "extraits-brut" / ident).glob("p*.txt")):
        if cible in normaliser(chemin.read_text(encoding="utf-8", errors="replace")):
            ailleurs.append(chemin.stem)
    return False, ("trouvée ailleurs : " + ", ".join(ailleurs)) if ailleurs else "introuvable"


MOTIF = re.compile(r"«\s*([^«»]+?)\s*»\s*\((?:(\d{4}\.\d{5}v\d)\s*,\s*)?p\.\s*(\d+)\)")


def citations_du_rapport(chemin: pathlib.Path):
    zone = None
    for numero, ligne in enumerate(chemin.read_text(encoding="utf-8").splitlines(), 1):
        if ligne.startswith("## "):
            if ligne.startswith("## Article A"):
                zone = "A"
            elif ligne.startswith("## Article B"):
                zone = "B"
            else:
                zone = None
        for m in MOTIF.finditer(ligne):
            citation, ident, page = m.group(1), m.group(2), int(m.group(3))
            article = PAR_ID.get(ident) if ident else zone
            yield numero, article, page, citation


def citations_de_liste(chemin: pathlib.Path):
    for numero, ligne in enumerate(chemin.read_text(encoding="utf-8").splitlines(), 1):
        if not ligne.strip() or ligne.startswith("#"):
            continue
        article, page, citation = ligne.split("\t", 2)
        yield numero, article.strip(), int(page), citation.strip()


def main():
    mode, chemin = sys.argv[1], pathlib.Path(sys.argv[2])
    source = citations_du_rapport(chemin) if mode == "rapport" else citations_de_liste(chemin)
    total = echecs = 0
    par_article = {"A": 0, "B": 0}
    for numero, article, page, citation in source:
        total += 1
        if article not in ARTICLES:
            echecs += 1
            print(f"ÉCHEC ligne {numero} : article non déterminé : {citation[:70]}")
            continue
        par_article[article] += 1
        ok, motif = verifier(article, page, citation)
        if ok:
            print(f"ok    ligne {numero:4d}  {ARTICLES[article]} p. {page:2d}  {citation[:80]}")
        else:
            echecs += 1
            print(f"ÉCHEC ligne {numero:4d}  {ARTICLES[article]} p. {page:2d}  [{motif}]  {citation[:80]}")
    print(f"\nCitations contrôlées : {total} (2606.18276v1 : {par_article['A']} ; 2603.15809v1 : {par_article['B']}) ; échecs : {echecs}")
    return 1 if echecs else 0


if __name__ == "__main__":
    sys.exit(main())
