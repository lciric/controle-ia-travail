"""Recalculs de contrôle à partir des tableaux transcrits des deux PDF (pages citées)."""
import itertools, random

print("=== Article A (2606.18276v1), tableau 5 p. 19 : réduction DG -> FJ+Bias (intégrale) ===")
# (erreur moyenne intégrale DG, FJ+Bias), (W1 intégrale DG, FJ+Bias)
t5 = {
 ("Gemma3","Climate"):  ((0.4627,0.4919),(1.0124,1.1573)),
 ("Gemma3","Gun"):      ((1.5415,1.0688),(2.2184,2.1108)),
 ("Gemma3","Vaccines"): ((1.5014,0.2026),(1.6865,0.5940)),
 ("Llama3.1","Climate"):((1.5356,0.2967),(1.8525,0.7411)),
 ("Llama3.1","Gun"):    ((2.8828,0.4850),(3.2308,1.2092)),
 ("Llama3.1","Vaccines"):((1.5884,0.1865),(1.8157,0.6068)),
 ("Qwen3","Climate"):   ((1.3815,0.5358),(1.5858,0.9002)),
 ("Qwen3","Gun"):       ((1.3196,0.6011),(1.6955,1.1580)),
 ("Qwen3","Vaccines"):  ((0.8732,0.3329),(1.0408,0.5561)),
}
for k,((m0,m1),(w0,w1)) in t5.items():
    print(f"  {k[0]:9s} {k[1]:9s} moyenne: {100*(1-m1/m0):6.1f} %   W1: {100*(1-w1/w0):6.1f} %")

print("\n=== Article A, tableau 1 p. 7 : somme des poids et rapport lambda_neigh/(lambda_b b) ===")
t1 = [("Gemma3","Climate",0.0290,0.6214,0.0055,0.3441,0.3483,0.2420),
      ("Gemma3","Gun",0.1404,0.6901,0.0027,0.1668,0.2277,3.6949),
      ("Gemma3","Vacc",0.0116,0.6076,0.0160,0.3648,0.5841,0.0544),
      ("Llama","Climate",0.0002,0.6560,0.0195,0.3243,0.6699,0.0011),
      ("Llama","Gun",0.0,0.6689,0.0381,0.2930,0.8531,0.0),
      ("Llama","Vacc",0.0192,0.6900,0.0363,0.2546,0.5972,0.1262),
      ("Qwen","Climate",0.0821,0.7019,0.0036,0.2125,0.5370,0.7196),
      ("Qwen","Gun",0.1175,0.6592,0.0,0.2233,0.4337,1.2130),
      ("Qwen","Vacc",0.2001,0.5344,0.0,0.2655,0.4681,1.6100)]
for (m,t,ln,ls,l0,lb,b,r) in t1:
    s = ln+ls+l0+lb
    g = lb/(l0+lb) if (l0+lb)>0 else float('nan')
    print(f"  {m:7s} {t:8s} somme={s:.4f} rapport recalculé={ln/(lb*b):.4f} (publié {r})  g=λb/(λ0+λb)={g:.3f}  b={b}")

print("\n=== Article B (2603.15809v1), tableau 5 p. 46 : moyennes par topologie (N=6) ===")
models = ["GPT-OSS","Qwen3","MiniMax","Mistral","Gemini","GPT5mini"]
T5 = {
 "hub": [[0.99,0.90,0.91,0.69,0.54,0.29,0.91,0.76,1.00,1.00,0.79,0.87],
         [0.31,0.22,0.75,0.56,0.37,0.19,0.90,0.75,0.94,0.89,0.46,0.64],
         [0.99,0.91,0.87,0.63,0.61,0.24,0.90,0.73,0.99,0.99,0.78,0.87],
         [0.15,0.16,0.58,0.45,0.30,0.12,0.89,0.74,0.56,0.45,0.34,0.44]],
 "complete": [[0.05,0.08,0.41,0.27,0.50,0.24,0.70,0.72,0.97,0.93,0.03,0.02],
         [0.13,0.18,0.21,0.13,0.23,0.06,0.69,0.69,0.63,0.56,0.09,0.28],
         [0.02,0.03,0.28,0.19,0.46,0.25,0.61,0.61,0.92,0.88,0.04,0.01],
         [0.10,0.14,0.06,0.08,0.10,0.05,0.70,0.62,0.25,0.16,0.08,0.17]],
 "leaf": [[0.04,0.05,0.32,0.28,0.27,0.10,0.71,0.59,0.70,0.69,0.03,0.01],
         [0.07,0.12,0.11,0.13,0.10,0.04,0.56,0.55,0.22,0.21,0.04,0.15],
         [0.05,0.09,0.18,0.22,0.30,0.09,0.66,0.57,0.67,0.71,0.02,0.02],
         [0.07,0.11,0.07,0.07,0.10,0.04,0.57,0.47,0.14,0.09,0.05,0.06]],
}
for topo, rows in T5.items():
    vals = [v for r in rows for v in r]
    print(f"  {topo:9s} moyenne = {sum(vals)/len(vals):.3f}  (n={len(vals)})")
print("  publié p. 18 : Star-Hub 0.65, Complete 0.33, Star-Leaf 0.24")

print("\n  Scénario défenseurs (influence moyenne, entêtement moyen) = 4e ligne, moyenne sur 3 topologies x 2 jeux :")
none_t3 = {"Mistral":0.49,"Qwen3":0.22,"GPT5mini":0.19,"GPT-OSS":0.09,"MiniMax":0.10}
for mi, m in enumerate(models):
    vals = []
    for topo in T5:
        r = T5[topo][3]
        vals += [r[2*mi], r[2*mi+1]]
    pub = none_t3.get(m, None)
    print(f"  {m:9s} moyenne tableau 5 = {sum(vals)/len(vals):.3f}   tableau 3 « None » (p. 21) = {pub}")

print("\n=== Article B : identité φ + ψ = 1 (tableau 1 p. 8 ; Lemme 4.18 p. 13) ===")
random.seed(0)
worst = 0.0
for _ in range(100000):
    g = random.random(); a = random.random()
    R = 1-(1-g)*a; I = (1-g)*(1-a)
    worst = max(worst, abs(g/R + I/R - 1))
print(f"  écart maximal |φ+ψ-1| sur 100000 tirages : {worst:.2e}")
print("  => éq. (9) p. 10 : b*_i = s_i φ_l + s_a ψ_l = s_i + ψ_l (s_a - s_i)  [calcul]")

print("\n=== Article B, tableau 2 p. 18 : étendues des R² ===")
desc = [0.981,0.972,0.956,0.973,0.927,0.853,0.982,0.976,0.947,0.978,0.944,0.851]
fixe = [0.966,0.945,0.927,0.965,0.857,0.772,0.962,0.945,0.903,0.968,0.899,0.766]
print(f"  descriptif : {min(desc)} – {max(desc)} (publié p. 17 : 0.851 – 0.982)")
print(f"  prédiction fixe : {min(fixe)} – {max(fixe)} (publié p. 17 : 0.766 – 0.968)")
