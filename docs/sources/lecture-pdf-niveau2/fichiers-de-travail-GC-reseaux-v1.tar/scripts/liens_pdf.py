"""Extrait les adresses (URI) des annotations de liens d'un PDF, en lecture seule.
Parcourt les objets bruts et les flux FlateDecode (objets compressés compris)."""
import re, sys, zlib

def uris(path):
    data = open(path, 'rb').read()
    found = set(m.group(1) for m in re.finditer(rb'/URI\s*\(([^)]*)\)', data))
    for m in re.finditer(rb'stream\r?\n', data):
        start = m.end()
        end = data.find(b'endstream', start)
        if end < 0:
            continue
        try:
            dec = zlib.decompress(data[start:end])
        except Exception:
            continue
        for u in re.finditer(rb'/URI\s*\(([^)]*)\)', dec):
            found.add(u.group(1))
    return sorted(found)

for p in sys.argv[1:]:
    print('==', p)
    for u in uris(p):
        print('  ', u.decode('latin-1'))
