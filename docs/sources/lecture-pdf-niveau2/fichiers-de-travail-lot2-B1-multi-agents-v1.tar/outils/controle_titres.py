import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import controle_citations as cc
L, R = sys.argv[1], sys.argv[2]
T = [
("2605.31593v1","Stateful Online Monitoring Catches Distributed Agent Attacks"),
("2607.02514v2","Distributed Attacks in Persistent-State AI Control"),
("2607.07368v1","Multi-Agent AI Control: Distributed Attacks Hamper Per-Instance Monitors"),
("2608.02698v1","Steganalysis of Adaptive Covert Collusion in Tool-Using Agent Populations: A Black-Box, Cross-Principal Approach"),
("2605.29178v1","The Best-Laid SCHEMEs: Coordinated Sabotage and Monitoring in Multi-Agent Systems"),
("2606.09931v1","A Note on the Strategic Confinement Problem"),
("2605.15377v2","Ensemble Monitoring for AI Control: Diverse Signals Outweigh More Compute"),
("2608.16190v1","Decorrelation Is Not Complementarity: Skill, Not Lineage, Governs Trusted-Monitor Ensembles"),
]
ok = 0
for a, t in T:
    m = cc.chercher(t, a, 1, L, R)
    print(("OK (%s)" % m) if m else "ECHEC", a, t)
    ok += bool(m)
print("Titres controles : %d ; trouves : %d ; echecs : %d" % (len(T), ok, len(T) - ok))
