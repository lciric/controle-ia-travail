#!/usr/bin/env python3
"""Controle des citations d'un rapport de lecture contre le texte extrait des PDF.

Regle : une citation est acceptee si elle figure, a l'identique, dans le texte
extrait de la page indiquee, en ne tolerant que :
  - les blancs (espaces, tabulations, retours a la ligne, sauts de page),
    y compris un blanc de fin de ligne apres un tiret long, un tiret moyen ou
    une barre oblique ;
  - les cesures de fin de ligne : un mot coupe par un trait d'union en fin de
    ligne peut etre cite recolle (« dynamics ») ou avec son trait d'union
    (« white-box »).
Aucune autre tolerance : ni ponctuation, ni casse, ni chiffre, ni caractere.

Textes compares, pour la meme page (rang dans le fichier) :
  1. pdftotext -layout, page par page (texte de reference des pages citees) ;
  2. pdftotext -raw, meme page (ordre du flux : evite l'entrelacement des
     colonnes que produit -layout sur les pages a deux colonnes).

Format attendu du rapport (Markdown) :
  - chaque article commence par un titre (#, ##, ###) contenant l'identifiant
    versionne, par exemple 2605.31593v1 ;
  - les citations sont dans des tableaux dont l'en-tete a une colonne « page »
    et une colonne contenant « citation » ; chaque citation est entre « » ;
    plusieurs citations dans une cellule se rapportent, dans l'ordre, aux pages
    de la cellule « page » (ou toutes a la page unique si une seule est donnee).

Usage :
  python3 -I controle_citations.py RAPPORT.md DOSSIER_LAYOUT DOSSIER_RAW
Code de sortie : 0 si toutes les citations sont trouvees, 1 sinon, 2 si erreur
de format.
"""
import pathlib
import re
import sys

MARQUE = "\x00"  # position d'une cesure de fin de ligne dans le texte de page
LETTRE = re.compile(r"[^\W_]")
ID_ARTICLE = re.compile(r"(\d{4}\.\d{5}v\d+)")
CITATION = re.compile(r"«\s*(.+?)\s*»")


def normaliser_page(texte):
    """Remplace chaque cesure de fin de ligne par MARQUE et reduit les blancs."""
    texte = re.sub(r"(?<=[^\W_])-[ \t]*\n[ \t\f\n]*(?=[^\W_])", MARQUE, texte)
    texte = re.sub(r"\s+", " ", texte)
    return texte.strip()


def motif_citation(citation):
    """Construit l'expression qui accepte seulement blancs et cesures."""
    q = re.sub(r"\s+", " ", citation).strip()
    morceaux = []
    for i, c in enumerate(q):
        suivant = q[i + 1] if i + 1 < len(q) else ""
        if c == "-":
            morceaux.append("(?:-|" + MARQUE + ")")
            continue
        morceaux.append(re.escape(c))
        if LETTRE.match(c) and suivant and LETTRE.match(suivant):
            morceaux.append(MARQUE + "?")  # cesure recollee dans la citation
        elif c in "—–/" and suivant and suivant != " ":
            morceaux.append(" ?")  # fin de ligne apres un tiret ou une barre
    return re.compile("".join(morceaux))


def lire_page(dossier, article, page):
    chemin = pathlib.Path(dossier) / article / ("p%03d.txt" % page)
    if not chemin.is_file():
        return None
    return chemin.read_text(encoding="utf-8")


def chercher(citation, article, page, dossier_layout, dossier_raw):
    """Renvoie le mode qui contient la citation ('layout' ou 'raw'), sinon None.
    Leve FileNotFoundError si la page n'existe dans aucun des deux modes."""
    motif = motif_citation(citation)
    trouve_une_page = False
    for mode, dossier in (("layout", dossier_layout), ("raw", dossier_raw)):
        texte = lire_page(dossier, article, page)
        if texte is None:
            continue
        trouve_une_page = True
        if motif.search(normaliser_page(texte)):
            return mode
    if not trouve_une_page:
        raise FileNotFoundError("%s p. %d introuvable" % (article, page))
    return None


def cellules(ligne):
    return [c.strip() for c in ligne.strip().strip("|").split("|")]


def extraire_citations(rapport_texte):
    """Renvoie la liste (ligne, article, page, citation) et la liste des erreurs."""
    lignes = rapport_texte.splitlines()
    article = None
    resultats, erreurs = [], []
    i = 0
    while i < len(lignes):
        ligne = lignes[i]
        if ligne.lstrip().startswith("#"):
            m = ID_ARTICLE.search(ligne)
            article = m.group(1) if m else None
            i += 1
            continue
        est_tableau = ligne.lstrip().startswith("|")
        suivante = lignes[i + 1] if i + 1 < len(lignes) else ""
        if est_tableau and re.match(r"^\s*\|[\s:|-]+\|\s*$", suivante):
            entete = [c.lower() for c in cellules(ligne)]
            col_page = next((k for k, c in enumerate(entete) if c == "page"), None)
            col_cit = next((k for k, c in enumerate(entete) if "citation" in c), None)
            i += 2
            while i < len(lignes) and lignes[i].lstrip().startswith("|"):
                if col_page is not None and col_cit is not None:
                    cs = cellules(lignes[i])
                    if len(cs) <= max(col_page, col_cit):
                        erreurs.append("ligne %d : tableau mal forme" % (i + 1))
                    else:
                        citations = CITATION.findall(cs[col_cit])
                        pages = [int(x) for x in re.findall(r"\d+", cs[col_page])]
                        if citations:
                            if article is None:
                                erreurs.append("ligne %d : citation hors article" % (i + 1))
                            elif len(pages) == 1:
                                for c in citations:
                                    resultats.append((i + 1, article, pages[0], c))
                            elif len(pages) == len(citations):
                                for p, c in zip(pages, citations):
                                    resultats.append((i + 1, article, p, c))
                            else:
                                erreurs.append(
                                    "ligne %d : %d citation(s) pour %d page(s)"
                                    % (i + 1, len(citations), len(pages)))
                i += 1
            continue
        i += 1
    return resultats, erreurs


def controler(rapport, dossier_layout, dossier_raw, sortie=sys.stdout):
    texte = pathlib.Path(rapport).read_text(encoding="utf-8")
    citations, erreurs = extraire_citations(texte)
    n_ok, n_echec = 0, 0
    par_mode = {"layout": 0, "raw": 0}
    for ligne, article, page, cit in citations:
        try:
            mode = chercher(cit, article, page, dossier_layout, dossier_raw)
        except FileNotFoundError as e:
            erreurs.append("ligne %d : %s" % (ligne, e))
            continue
        if mode:
            n_ok += 1
            par_mode[mode] += 1
            etat = "OK (%s)" % mode
        else:
            n_echec += 1
            etat = "ECHEC"
        extrait = cit if len(cit) <= 70 else cit[:67] + "..."
        print("%-12s l.%-4d %s p.%-3d %s" % (etat, ligne, article, page, extrait), file=sortie)
    for e in erreurs:
        print("ERREUR " + e, file=sortie)
    print("Citations controlees : %d ; trouvees : %d (layout %d, raw %d) ; echecs : %d ; erreurs de format : %d"
          % (len(citations), n_ok, par_mode["layout"], par_mode["raw"], n_echec, len(erreurs)), file=sortie)
    if erreurs:
        return 2
    return 0 if n_echec == 0 else 1


if __name__ == "__main__":
    if len(sys.argv) != 4:
        print(__doc__)
        sys.exit(2)
    sys.exit(controler(sys.argv[1], sys.argv[2], sys.argv[3]))
