import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import controle_citations as cc
L, R = sys.argv[1], sys.argv[2]
C = [
("2607.07368v1",53,"5.74 (3.75, 8.29) *"),
("2607.07368v1",53,"4.67 (2.49, 7.54) *"),
("2607.07368v1",53,"any plan / none"),
("2607.07368v1",53,"Pro plan / none"),
("2605.15377v2",1,"Diverse Signals Outweigh More Compute"),
("2607.07368v1",22,"we implement our evaluation using [AI Security Institute, 2024, Inspect] and [Inglis et al., 2025, ControlArena] from UK AISI."),
("2605.29178v1",2,"By default, side-task knowledge is concentrated"),
]
for a,p,q in C:
    m = cc.chercher(q,a,p,L,R); print(("OK " + m) if m else "ECHEC", a, p, q)
