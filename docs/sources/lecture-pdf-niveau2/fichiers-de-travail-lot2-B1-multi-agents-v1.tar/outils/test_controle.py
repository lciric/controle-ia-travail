#!/usr/bin/env python3
"""Test du controle des citations (regle R5) : cas sains et artefacts.

Usage : python3 -I test_controle.py DOSSIER_LAYOUT DOSSIER_RAW
Sortie : une ligne par cas, puis un bilan ; code 0 seulement si tous les cas
se comportent comme attendu (cas sains acceptes, artefacts refuses).
"""
import io
import pathlib
import sys
import tempfile

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import controle_citations as cc  # noqa: E402

LAYOUT, RAW = sys.argv[1], sys.argv[2]

CAS = [
    # (nom, article, page, citation, attendu_trouve)
    ("cas juste (chiffres)", "2605.31593v1", 7,
     "With 10x more benign than attack conversations, the stateful moniter reaches "
     "81.1–87.2% campaign recall at 2.35–3.09% benign conversation FPR", True),
    ("artefact : chiffre altere 87.2 -> 87.3", "2605.31593v1", 7,
     "With 10x more benign than attack conversations, the stateful moniter reaches "
     "81.1–87.3% campaign recall at 2.35–3.09% benign conversation FPR", False),
    ("artefact : coquille corrigee moniter -> monitor", "2605.31593v1", 7,
     "With 10x more benign than attack conversations, the stateful monitor reaches", False),
    ("artefact : bonne citation, mauvaise page (6 au lieu de 7)", "2605.31593v1", 6,
     "With 10x more benign than attack conversations, the stateful moniter reaches", False),
    ("artefact : virgule supprimee", "2605.31593v1", 7,
     "With 10x more benign than attack conversations the stateful moniter reaches", False),
    ("cas sain : blancs modifies (retour a la ligne, espaces multiples)", "2605.31593v1", 7,
     "With   10x more\nbenign than attack     conversations, the stateful moniter", True),
    ("cas sain : cesure recollee (dy- / namics)", "2607.02514v2", 1,
     "To study the resulting dynamics, we introduce", True),
    ("cas sain : cesure, trait d'union conserve (white- / box)", "2608.02698v1", 3,
     "requires white-box activation access, which is infeasible across principals.", True),
    ("cas sain : tiret long en fin de ligne (families— / or)", "2605.15377v2", 8,
     "Ensembles drawn from different model families—or that incorporate non-LLM-based "
     "signals—may be more resistant, but we have not tested this directly.", True),
    ("cas sain : trait d'union interne en milieu de ligne", "2605.31593v1", 1,
     "a multi-agent scaffold that completes", True),
    ("artefact : trait d'union supprime hors fin de ligne", "2605.31593v1", 1,
     "a multiagent scaffold that completes", False),
    ("artefact : casse modifiee", "2605.31593v1", 1,
     "A Multi-agent scaffold that completes", False),
]


def main():
    bons = 0
    for nom, article, page, citation, attendu in CAS:
        mode = cc.chercher(citation, article, page, LAYOUT, RAW)
        obtenu = mode is not None
        ok = obtenu == attendu
        bons += ok
        print("%-6s %-62s attendu=%-7s obtenu=%s" % (
            "OK" if ok else "RATE", nom, "trouve" if attendu else "refuse",
            ("trouve (%s)" % mode) if obtenu else "refuse"))

    # Rapport factice : 1 citation juste, 1 alteree -> code 1, comptes 2/1/1.
    factice = (
        "# Essai\n\n## Article 2605.31593v1\n\n"
        "| # | page | citation exacte |\n|---|---|---|\n"
        "| 1 | p. 7 | « compared with 75.0% recall at 2.72% FPR for the standard monitor » |\n"
        "| 2 | p. 7 | « compared with 75.0% recall at 2.27% FPR for the standard monitor » |\n"
        "| 3 | — | — |\n")
    # Rapport factice mal forme : 2 citations pour 3 pages -> code 2.
    mal_forme = (
        "## Article 2605.31593v1\n\n| page | citation |\n|---|---|\n"
        "| p. 1 ; p. 2 ; p. 3 | « a » ; « b » |\n")
    with tempfile.TemporaryDirectory() as d:
        f1 = pathlib.Path(d) / "factice.md"
        f1.write_text(factice, encoding="utf-8")
        tampon = io.StringIO()
        code1 = cc.controler(str(f1), LAYOUT, RAW, sortie=tampon)
        bilan1 = tampon.getvalue().strip().splitlines()[-1]
        ok1 = code1 == 1 and "controlees : 2" in bilan1 and "echecs : 1" in bilan1
        f2 = pathlib.Path(d) / "mal_forme.md"
        f2.write_text(mal_forme, encoding="utf-8")
        code2 = cc.controler(str(f2), LAYOUT, RAW, sortie=io.StringIO())
        ok2 = code2 == 2
    print("%-6s %-62s code=%d ; %s" % ("OK" if ok1 else "RATE", "rapport factice (1 juste, 1 alteree)", code1, bilan1))
    print("%-6s %-62s code=%d" % ("OK" if ok2 else "RATE", "rapport factice mal forme (2 citations, 3 pages)", code2))
    total = len(CAS) + 2
    reussis = bons + ok1 + ok2
    print("Bilan R5 : %d cas sur %d conformes a l'attendu" % (reussis, total))
    return 0 if reussis == total else 1


if __name__ == "__main__":
    sys.exit(main())
