import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import controle_citations as cc
L, R = sys.argv[1], sys.argv[2]
C = [
("2607.02514v2",10,"Gradual evasion numbers carry selection bias because the runs that succeed are the least distributed (Section 4.1)."),
("2608.16190v1",7,"Every one of these is a maximum over an exhaustive test-split search with no held-out selection"),
("2605.31593v1",8,"the stateful monitor still helps at 100x background, but performs much better at 10x"),
("2605.31593v1",6,"During our experiments, we use held-out data to tune these thresholds."),
("2605.31593v1",1,"Preprint."),
("2605.29178v1",1,"Preprint."),
("2607.07368v1",1,"Preprint."),
("2608.16190v1",1,"Preprint."),
("2605.15377v2",6,"the top ten 3-monitor ensembles span pAUC 0.811–0.816, with improvements clustered around 2.4×."),
("2605.15377v2",6,"the top ensemble achieves a 2.4× larger gain over the Baseline monitor"),
("2605.29178v1",9,"Gemini approaching sabotage saturation means the benchmark no longer separates models on raw capability"),
("2607.07368v1",30,"The cohort conditions on attack success, a post-treatment variable"),
("2607.07368v1",48,"every joint-suspicion result, here and in the main text, uses the exhaustive (full task description) monitor prompt"),
("2607.07368v1",21,"because the test suite contains security tripwires, functions as an independent detection channel in parallel with the monitor"),
("2608.02698v1",1,"A Black-Box, Cross-Principal Approach"),
("2606.09931v1",8,"Vaikuntanathan and Zamir (2026) allows for secret key exchange under mild channel entropy conditions and without the need for public-key infrastructure, but is not resistant to spoofing."),
("2607.02514v2",4,"Link-tracker is a novel stateful diff moni- tor"),
("2605.31593v1",3,"We build the first distributed agent attack, which solves hard cyber tasks, yet evades standard monitors, and is caught only 20% as often as prior agent attacks."),
("2605.31593v1",2,"identifies misuse up to 31% more quickly than well-tuned safety monitors"),
("2607.07368v1",22,"we implement our evaluation using [AI Security Institute, 2024, Inspect] and [Inglis et al., 2025, ControlArena] from UK AISI."),
("2605.29178v1",3,"By default, side-task knowledge is concentrated"),
("2607.02514v2",30,"Each PR receives a single score, the minimum of its resample scores"),
("2608.02698v1",7,"spreading the payload across sessions is a real evasion (Table Vc) that single-session steganalysis underdetects."),
("2605.15377v2",4,"computed on attack (backdoored) samples only"),
("2608.02698v1",4,"fit fusion fθ on labelled held-out episodes (distinct encodings)"),
("2605.31593v1",4,"We keep the monitor and prompt fixed, and compare our distributed attack to three baselines"),
("2607.07368v1",5,"We only run monitors on commits that solve the main task."),
]
bad = 0
for a,p,q in C:
    m = cc.chercher(q,a,p,L,R)
    print(("OK " + m) if m else "ECHEC", a, p, q[:80])
    bad += (m is None)
print("total", len(C), "echecs", bad)
