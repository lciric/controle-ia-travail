"""Assemble rapport.md à partir du gabarit : chaque marqueur {{G01}} / {{W01}} est remplacé
par « [ID] « citation » » tirée de citations.json, et chaque citation insérée est recontrôlée
contre le texte extrait de sa page (même contrôle que verifier_citations.py, autotest R5 compris).

Usage : python3 -I assembler_rapport.py GABARIT.md citations.json DOSSIER_TEXTES SORTIE.md
"""
import datetime
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from verifier_citations import autotest, controler  # noqa: E402

MARQUEUR = re.compile(r"\{\{([GW]\d{2})\}\}")


def main():
    gabarit, fichier_citations, textes, sortie = sys.argv[1:5]
    with open(fichier_citations, encoding="utf-8") as f:
        cit = {c["id"]: c for c in json.load(f)}
    with open(gabarit, encoding="utf-8") as f:
        g = f.read()
    utilises = MARQUEUR.findall(g)
    inconnus = sorted({u for u in utilises if u not in cit})
    if inconnus:
        print("identifiants inconnus :", inconnus)
        sys.exit(2)
    autotest(textes)
    echecs = [i for i in sorted(set(utilises))
              if not controler(textes, cit[i]["papier"], int(cit[i]["page"]), cit[i]["citation"])]
    texte = MARQUEUR.sub(lambda m: "[%s] « %s »" % (m.group(1), cit[m.group(1)]["citation"]), g)
    ligne = ("Contrôle à l'assemblage : %d insertions de citations anglaises (%d identifiants distincts), "
             "chacune recontrôlée contre le texte extrait de sa page ; %d échec%s."
             % (len(utilises), len(set(utilises)), len(echecs),
                (" : " + ", ".join(echecs)) if echecs else ""))
    heure = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M")
    texte = texte.replace("{{CONTROLE_FINAL}}", ligne).replace("{{HEURE}}", heure)
    if "{{" in texte or "}}" in texte:
        print("marqueur non remplacé ; arrêt.")
        sys.exit(3)
    with open(sortie, "w", encoding="utf-8") as f:
        f.write(texte)
    print(ligne)
    sys.exit(0 if not echecs else 4)


if __name__ == "__main__":
    main()
