"""Contrôle des citations contre le texte extrait de la page indiquée.

Usage (toujours avec python3 -I) :
    python3 -I verifier_citations.py DOSSIER_TEXTES FICHIER_CITATIONS.json [SORTIE.tsv]

Pour chaque citation {"id", "papier", "page", "citation"}, le script cherche la
citation dans les extractions `pdftotext` de CETTE page seulement :
    DOSSIER_TEXTES/<papier>/pNN.txt          (pdftotext -layout, page entière)
    DOSSIER_TEXTES/<papier>/pNN-gauche.txt   (pdftotext -layout, colonne gauche)
    DOSSIER_TEXTES/<papier>/pNN-droite.txt   (pdftotext -layout, colonne droite)
    DOSSIER_TEXTES/<papier>/pNN-lecture.txt  (pdftotext, ordre de lecture)

Tolérances, et seulement celles-ci :
  - les blancs (espaces, fins de ligne, tabulations) sont ignorés ;
  - les césures : un trait d'union suivi d'une fin de ligne peut être absent de
    la citation (mot recollé) ou présent (vrai trait d'union coupé en fin de ligne).
Aucune autre normalisation (ni casse, ni Unicode, ni ponctuation).

Avant tout contrôle, un autotest (règle R5) vérifie que le contrôle accepte un cas
juste et rejette des cas altérés ; s'il se comporte mal, le script s'arrête en erreur.
"""
import json
import os
import re
import sys

TRAITS = "-‐‑­"
MARQUE = "\x00"  # césure candidate dans le texte de la page
SUFFIXES = ("", "-gauche", "-droite", "-lecture")


def canon_page(texte):
    """Remplace chaque trait d'union suivi d'un blanc contenant une fin de ligne par
    une marque de césure, puis supprime tous les blancs."""
    t = re.sub("[" + TRAITS + "][ \t ]*\n\\s*", MARQUE, texte)
    return re.sub(r"\s+", "", t)


def motif_citation(citation):
    """Motif qui tolère une marque de césure entre deux caractères quelconques ;
    un trait d'union de la citation peut correspondre à un trait ou à une marque."""
    c = re.sub(r"\s+", "", citation)
    if not c:
        raise ValueError("citation vide")
    morceaux = []
    for ch in c:
        if ch in TRAITS:
            morceaux.append("(?:[" + TRAITS + "]|" + MARQUE + ")")
        else:
            morceaux.append(re.escape(ch))
    return re.compile((MARQUE + "?").join(morceaux))


def textes_de_page(dossier, papier, page):
    sortie = []
    for suf in SUFFIXES:
        chemin = os.path.join(dossier, papier, "p%02d%s.txt" % (page, suf))
        if os.path.isfile(chemin):
            with open(chemin, encoding="utf-8") as f:
                sortie.append((os.path.basename(chemin), f.read()))
    if not sortie:
        raise FileNotFoundError("aucune extraction pour %s page %d" % (papier, page))
    return sortie


def controler(dossier, papier, page, citation):
    """Renvoie la liste des extractions de la page où la citation est trouvée."""
    motif = motif_citation(citation)
    return [nom for nom, texte in textes_de_page(dossier, papier, page)
            if motif.search(canon_page(texte))]


def autotest(dossier):
    """R5 : cas juste, cas altérés, mauvaise page, césure, blancs."""
    juste = ("We formalize risk at the semantic request or trajectory level: when one "
             "task contains repeated alarm opportunities, row-level AUROC and false "
             "positive rate do not identify semantic-unit any-alarm risk.")
    cas = [
        ("cas juste (avec césure « iden-tify »)", "2610.04575v1", 1, juste, True),
        ("cas altéré (« do not » -> « do »)", "2610.04575v1", 1,
         juste.replace("do not identify", "do identify"), False),
        ("cas altéré (un caractère : « row-level » -> « raw-level »)", "2610.04575v1", 1,
         juste.replace("row-level", "raw-level"), False),
        ("mauvaise page (page 2 au lieu de 1)", "2610.04575v1", 2, juste, False),
        ("cas juste, chiffre (« 80% », césure « num-ber »)", "2411.17693v1", 1,
         "reduces the number of backdoors by 80% compared to non-adaptive baselines.", True),
        ("cas altéré, chiffre (« 80% » -> « 90% »)", "2411.17693v1", 1,
         "reduces the number of backdoors by 90% compared to non-adaptive baselines.", False),
        ("cas juste, blancs ajoutés et retours à la ligne", "2411.17693v1", 1,
         "reduces   the\nnumber of\tbackdoors by 80%   compared", True),
        ("cas altéré, trait d'union ajouté (« reduces-the »)",
         "2411.17693v1", 1, "reduces-the number of backdoors", False),
    ]
    ok = True
    for nom, papier, page, cit, attendu in cas:
        trouve = bool(controler(dossier, papier, page, cit))
        statut = "conforme" if trouve == attendu else "NON CONFORME"
        if trouve != attendu:
            ok = False
        print("[autotest] %-75s attendu=%-5s obtenu=%-5s %s" % (nom, attendu, trouve, statut))
    if not ok:
        print("[autotest] ÉCHEC : le contrôle ne se comporte pas comme attendu ; arrêt.")
        sys.exit(2)
    print("[autotest] réussi : %d cas sur %d conformes." % (len(cas), len(cas)))


def main():
    if len(sys.argv) not in (3, 4):
        print(__doc__)
        sys.exit(1)
    dossier, fichier = sys.argv[1], sys.argv[2]
    sortie = sys.argv[3] if len(sys.argv) == 4 else None
    autotest(dossier)
    with open(fichier, encoding="utf-8") as f:
        citations = json.load(f)
    ids = [c["id"] for c in citations]
    if len(ids) != len(set(ids)):
        print("identifiants de citation en double ; arrêt.")
        sys.exit(3)
    lignes, echecs = [], 0
    for c in citations:
        trouves = controler(dossier, c["papier"], int(c["page"]), c["citation"])
        statut = "OK" if trouves else "ECHEC"
        if not trouves:
            echecs += 1
        lignes.append("%s\t%s\t%s\t%s\t%s" % (c["id"], c["papier"], c["page"], statut,
                                              ",".join(trouves) if trouves else "-"))
        print("%-5s %-14s p.%-3s %-6s %s" % (c["id"], c["papier"], c["page"], statut,
                                             ",".join(trouves) if trouves else c["citation"][:90]))
    print("Citations contrôlées : %d ; échecs : %d" % (len(citations), echecs))
    if sortie:
        with open(sortie, "w", encoding="utf-8") as f:
            f.write("id\tpapier\tpage\tstatut\textractions\n")
            f.write("\n".join(lignes) + "\n")
            f.write("# controlees=%d echecs=%d\n" % (len(citations), echecs))
    sys.exit(0 if echecs == 0 else 4)


if __name__ == "__main__":
    main()
