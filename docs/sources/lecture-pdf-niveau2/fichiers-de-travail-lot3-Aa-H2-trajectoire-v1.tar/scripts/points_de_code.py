import sys, unicodedata
chemin, motif = sys.argv[1], sys.argv[2]
with open(chemin, encoding="utf-8") as f:
    for ligne in f:
        if motif in ligne:
            s = " ".join(ligne.split())
            print(s)
            print("  non-ASCII :", sorted({"%s U+%04X %s" % (c, ord(c), unicodedata.name(c, "?")) for c in s if ord(c) > 127}))
