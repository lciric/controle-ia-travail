"""Test de mutation du contrôle des citations (règles R4 et R5).

Usage : python3 -I test_mutation.py DOSSIER_TEXTES citations.json

1. Pour chaque citation, altère un caractère alphanumérique au milieu (chiffre -> autre
   chiffre, lettre -> autre lettre) : la citation altérée doit ÉCHOUER.
2. Pour chaque citation, contrôle contre la page voisine (page + 1, ou page - 1 pour la
   dernière page) : signale celles qui passent quand même (citations trop génériques).
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from verifier_citations import controler  # noqa: E402

NB_PAGES = {"2610.04575v1": 12, "2411.17693v1": 44}


def muter(texte):
    milieu = len(texte) // 2
    positions = sorted(range(len(texte)), key=lambda i: abs(i - milieu))
    for i in positions:
        ch = texte[i]
        if ch.isdigit():
            return texte[:i] + str((int(ch) + 1) % 10) + texte[i + 1:], i
        if ch.isascii() and ch.isalpha():
            neuf = "x" if ch.lower() != "x" else "y"
            neuf = neuf.upper() if ch.isupper() else neuf
            return texte[:i] + neuf + texte[i + 1:], i
    raise ValueError("aucun caractère à muter")


def main():
    dossier, fichier = sys.argv[1], sys.argv[2]
    with open(fichier, encoding="utf-8") as f:
        citations = json.load(f)
    mutees_passees, pages_voisines_passees = [], []
    for c in citations:
        mute, pos = muter(c["citation"])
        if controler(dossier, c["papier"], int(c["page"]), mute):
            mutees_passees.append((c["id"], pos, mute))
        p = int(c["page"])
        voisine = p + 1 if p < NB_PAGES[c["papier"]] else p - 1
        if controler(dossier, c["papier"], voisine, c["citation"]):
            pages_voisines_passees.append((c["id"], voisine, c["citation"]))
    print("Citations : %d" % len(citations))
    print("Mutations d'un caractère acceptées à tort : %d" % len(mutees_passees))
    for m in mutees_passees:
        print("   ", m)
    print("Citations retrouvées aussi sur la page voisine : %d" % len(pages_voisines_passees))
    for m in pages_voisines_passees:
        print("   ", m)


if __name__ == "__main__":
    main()
