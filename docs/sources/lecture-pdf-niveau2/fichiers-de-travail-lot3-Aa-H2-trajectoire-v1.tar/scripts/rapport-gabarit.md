# Lecture d'antériorité (R8), niveau 2, lot 3 — groupe Aa-H2-trajectoire — rapport v1

## En-tête

- **Lecteur** : agent neuf ; je n'ai écrit ni les énoncés du programme ni les papiers lus.
- **Date** : 2026-10-06 ; lecture de 16:33 à 17:00 en temps universel coordonné (UTC) ; rapport assemblé le {{HEURE}} UTC.
- **PDF lus** (format de document portable). Empreintes sha256 (algorithme de hachage sécurisé à 256 bits) recalculées : identiques aux consignes et aux fichiers compagnons `.sha256` (`sha256sum -c` : OK pour les deux).

| fichier | pages | empreinte sha256 | lecture |
|---|---|---|---|
| `/home/user/controle-ia/docs/sources/pdf/2610.04575v1.pdf` | 12 | `ef50ec541464c3ee8e3f2fda9251684668238377575b2530341319f474dce12c` | en entier |
| `/home/user/controle-ia/docs/sources/pdf/2411.17693v1.pdf` | 44 | `13a93a48dcb373595709da1096984d308cd3cd17c3bf00602944a24abcc2c627` | en entier pour le texte ; figures illisibles en texte (légendes seules) |

- **Extraction** : `pdftotext -layout`, page par page ; la page citée est le rang dans le fichier. Pour les pages à deux colonnes de 2610.04575, j'ai aussi extrait, toujours page par page, chaque colonne (`pdftotext -layout` avec rognage `-x 0` ou `-x 306`, `-W 306`) et le mode ordre de lecture (`pdftotext` sans `-layout`). Aucun autre outil n'a ouvert les PDF ; Python seulement en `python3 -I`, avec des scripts hors du dossier des textes.
- **Contrôle des citations** (point 6 de la consigne) : `scripts/verifier_citations.py` (sha256 `d03e341cadc741319f65353f2d835ef28b492021cddee3b3cabee8d6049bcba8`). Il ne tolère que les blancs et les césures, et ne cherche chaque citation que dans les extractions de la page indiquée.
  - Autotest (R5), exécuté avant chaque contrôle : 8 cas sur 8 conformes. Trois cas justes sont acceptés (dont une césure et des blancs ajoutés). Cinq cas altérés ou mal paginés sont rejetés.
  - **149 citations contrôlées, 0 échec.** Liste : `citations.json` (sha256 `62498ac34f0d33164df8ad582594bf3688de3569f67197265ed629e91eb83c7f`). Résultat : `controle-citations.tsv` (sha256 `fa95b2e658205ab0c75901fe3422c5907caea6f91450042db1563817bf2f7ac6`).
  - Audit de propreté (R4) : `scripts/test_mutation.py` (sha256 `965d22b8e4e91364ff71d7d1932c245ecf72195f8e338fd3cc1bfbe27661bd80`). Chaque citation altérée d'un seul caractère : 0 acceptée sur 149. Chaque citation contrôlée contre la page voisine : une seule s'y retrouve, W07 (« Preprint », en-tête répété sur chaque page ; attendu).
  - Dans ce rapport, l'anglais n'apparaît que sous la forme [identifiant] « citation », insérée depuis `citations.json` par `scripts/assembler_rapport.py` (sha256 `5b9bd91ffe17838c08ba60d975e04a680846f1b428d853c107cb70ab167a6102`), qui recontrôle chaque insertion (résultat en fin de rapport).
- **Incident d'environnement** : le disque racine a été plein pendant la session (0 à 2,5 Mo libres, disque partagé). J'ai supprimé seulement mes propres fichiers inutiles : doublons d'extraction `complet.txt` (reproductibles), un fichier de sortie vide créé pendant l'incident, un cache Python. Un calcul lancé par erreur en arrière-plan a été arrêté par son identifiant (R10), puis refait en mémoire. Aucun effet sur le contenu.
- **Lectures annexes, en lecture seule**, sous `/home/user/controle-ia` : décision N-007 (énoncé retenu de H2, lecture de « toujours valide ») ; provenance des PDF du lot 4 ; table de la recherche affirmative (`docs/sources/recherche-affirmative-20261006/rapport-papier-A-v1.md`, sha256 `85a248af02319310ac8d7d6f39ba673db334f1ebd23fe1d4b725bf4f2e1b8d10`). Rien n'a été modifié.
- **Sens de « 3 » dans les affirmations à contrôler** : la recherche affirmative numérote dans sa colonne « Énoncé » les énoncés du papier A ; « 3 » y désigne le lemme d'additivité L (point 3 de sa synthèse) et « 4 » le théorème T. Je lis donc « 3 » comme L.
- **Termes** : « aire sous la courbe » = aire sous la courbe caractéristique de fonctionnement du récepteur (AUROC dans les citations) ; « taux de faux positifs » et « taux de vrais positifs » (FPR et TPR dans les citations) ; « borne supérieure de confiance » (UCB) ; les intervalles entre crochets sont des intervalles de confiance à 95 %.

## 1. 2610.04575v1 — Xueping Gao, « From Probe Scores to Alarm Policies »

### 1.1 Identité

- Titre (p. 1) : {{G01}}. Conforme aux consignes et aux métadonnées (`pdfinfo`).
- Auteur unique (p. 1) : {{G02}}.
- Version et date (p. 1) : {{G03}}.
- Venue : format de référence de l'Association for Computing Machinery imprimé en page 1 : {{G04}}, puis {{G05}}. Le PDF n'énonce pas d'acceptation : « accept » n'apparaît que dans deux références de la bibliographie, [31] et [35] (p. 9).
- Composition : corps (p. 1 à 8), références (p. 9), annexes A à G (p. 10 à 12).

### 1.2 Réponses aux questions des consignes (H2)

1. **Les sondes lisent-elles l'agent qui agit ?** Oui sur AgentDojo, avec une seule lecture par tentative, avant l'action, au premier appel de politique qui suit le résultat d'outil injecté : {{G17}} (p. 1) ; {{G18}} (p. 5) ; {{G20}} (p. 12). Sur ST-WebAgentBench : {{G19}} (p. 5). Le texte ne dit pas explicitement que l'agent du navigateur est ce même modèle (vraisemblable, non vérifiable sur le PDF). Les deux autres terrains ne sont pas agentiques : {{G68}} (p. 5) ; {{G69}} (p. 5).
2. **Accumulation des scores sur la trajectoire (somme, processus e, martingale, test séquentiel) ?** Non. L'agrégation est le maximum dans l'unité, calculé après étiquetage de toutes les tentatives : {{G21}} (p. 3) ; {{G24}} (p. 3) ; même chose en annexe : {{G52}} (p. 11). Recherche plein texte sur les 12 pages : « sabotage », « martingale », « anytime », « e-value », « e-process », « honest », « accumul » : 0 occurrence ; « sequential » : 3 occurrences, toutes pour écarter le contrôleur séquentiel ; « cumulative » : 1 occurrence, {{G34}} (p. 5). Elle concerne LASR, où chaque unité est une requête unique lue avant toute réponse ([G69]) : c'est une mise en commun d'activations, pas une accumulation de scores sur une trajectoire.
3. **Garantie toujours valide ?** Non. La garantie est une borne marginale à 95 %, par statistique d'ordre, pour une nouvelle unité indépendante : {{G29}} (p. 4) ; {{G45}} (p. 8).
4. **Seuil par action calibré à un taux de faux positifs ?** Pas au sens de H2. Le seuil s'applique à chaque occasion d'alarme, mais il est calibré sur les maxima d'unités négatives, pour des budgets de 5 % et 10 % par unité : {{G30}} (p. 5). Le papier montre que le taux par ligne ne fixe pas celui de l'unité : {{G25}} (p. 3). Aucun moniteur par action à 1 % n'est construit ; « 1% » n'apparaît qu'à propos d'un travail cité, {{G15}} (p. 2).
5. **Rappel en fonction de l'horizon ?** Non. « Horizon » désigne ici le moment de la lecture (« comparateur de même horizon »), pas la longueur de la trajectoire. La seule variation de taille d'unité est une sensibilité a posteriori au nombre de tentatives k, que l'auteur déclare non comparable : {{G51}} (p. 11).
6. **Calibrage sur épisodes honnêtes seuls ?** En partie. Le seuil n'emploie que des unités négatives, disjointes de l'apprentissage : {{G62}} (p. 5). Mais les négatifs d'AgentDojo sont des cas sous injection où l'agent n'exécute pas l'injection : {{G61}} (p. 5). Et les sondes sont apprises sur des exemples étiquetés positifs et négatifs : {{G63}} (p. 6).
7. **Sabotage dont chaque action reste sous le seuil ?** Non. Aucun sabotage ; la menace d'AgentDojo est une injection d'instructions venue de l'extérieur ([G61]). La robustesse adaptative n'est pas revendiquée : {{G15}} (p. 2) ; {{G46}} (p. 8).
8. **Expériences ou seulement un cadre ?** Les deux. Un cadre (contrat à huit champs, échelle de revendications, compilateur fermé par défaut : {{G71}}, p. 2) et un audit sur quatre terrains, dont deux prospectifs gelés (AgentDojo, ST-WebAgentBench) et deux rétrospectifs (Models Under Pressure ; LASR, nom d'un jeu de prédiction de refus, non développé dans le papier) : {{G56}} (p. 8). AgentDojo n'atteint pas le support qu'il s'était fixé : {{G60}} (p. 7).

### 1.3 Affirmations de la recherche affirmative

| # | affirmation de la recherche affirmative | verdict | page | citation exacte |
|---|---|---|---|---|
| 1 | 2610.04575 (version non vue), déposé le 3 octobre 2026 ; titre ; auteur Xueping Gao | confirmé : version 1 ; auteur unique (Alibaba Cloud Computing) | 1 | {{G01}} ; {{G02}} ; {{G03}} |
| 2 | « accepté à DAI 2026 selon le résumé » | corrigé : « mis en forme pour DAI ’26, The Eighth International Conference on Distributed Artificial Intelligence, 29 novembre – 2 décembre 2026, Hong Kong (Association for Computing Machinery), selon le format de référence imprimé en page 1 ; le PDF n'énonce pas l'acceptation » | 1 | {{G04}} ; {{G05}} |
| 3 | Sépare la qualité de classement d'une sonde (aire sous la courbe) de la décision d'alarme à seuil sous budget de fausses alarmes | confirmé | 1 | {{G06}} |
| 4 | Propose un « contrat de validité opérationnelle » qui fixe cible, observabilité, identité, moment, unité d'intervention, comparateur, calibration et coût | confirmé | 1 | {{G07}} |
| 5 | Formalise le risque au niveau de la requête ou de la trajectoire : le taux de faux positifs par ligne n'identifie pas le risque « au moins une alarme » de l'unité | confirmé ; à compléter : l'auteur déclare cet ingrédient antérieur et ne le revendique pas | 1 ; 2 | {{G08}} ; {{G09}} ; {{G10}} |
| 6 | « C'est le seul travail trouvé qui réunit sondes d'activation, agents, budget de fausses alarmes et unité trajectoire » | corrigé : « réunit des sondes lisant l'agent, des agents, des budgets de 5 % et 10 % par unité et une unité sémantique (cas de sécurité représenté par dix tentatives échantillonnées, ou gabarit d'intention), non la trajectoire unique ; il cite lui-même des voisins (activations sur agents, surveillance en ligne à risque contrôlé), non lus ici » | 3 ; 2 | {{G22}} ; {{G11}} ; {{G12}} ; {{G13}} |
| 7 | « Le résumé ne dit rien d'une accumulation additive toujours valide, ni d'une détection de sabotage sous le seuil par action » | confirmé, et vrai pour tout le texte (voir 1.2, points 2, 3 et 7) | 3 ; 4 ; 8 | {{G24}} ; {{G29}} ; {{G45}} |
| 8 | « S'il contient un agrégateur séquentiel calibré sur des épisodes honnêtes, H2 perd sa nouveauté de cadre » | condition non remplie : l'agrégateur est le maximum de l'unité, calculé après étiquetage, non séquentiel ; le seuil vient de maxima d'unités négatives prises sous attaque | 3 ; 5 | {{G21}} ; {{G61}} |
| 9 | Verdict « occupe en partie (cadre et calibration au niveau trajectoire) » pour H2, « 3 » (L) et H1 | corrigé : « voisin » pour H2, avec un contre-indice sur la tenue du calibrage ; « voisin » pour L ; « voisin » pour H1, avec un contre-indice faible (voir 1.4) | — | voir 1.4 |

### 1.4 Antériorité (R8)

| énoncé | verdict d'antériorité | composantes faites / non faites | pages et citations |
|---|---|---|---|
| H2 | **voisin** ; **contre-indice** de portée limitée (tenue du calibrage) | Faites : (a) lecture de l'agent qui agit, une fois par tentative, avant l'action ; (b) seuil calibré sur des unités négatives seules, par statistique d'ordre à 95 %, pour l'événement « au moins une alarme » de l'unité. Non faites : accumulation additive ; garantie toujours valide (borne marginale, non simultanée) ; moniteur par action à 1 % et sabotage sous ce seuil ; rappel croissant avec l'horizon ; calibrage sans exemple d'attaque (négatifs pris sous injection, sondes supervisées). Contre-indice : sur AgentDojo, un seuil certifié à 8,92 % pour un budget de 10 % réalise 18,67 % de faux positifs en test, avec une probabilité de 0,001745 sous l'hypothèse d'échangeabilité ; l'auteur l'attribue à un déplacement entre suites ou politiques ; au budget de 5 %, les fausses alarmes de l'observable et tous les vrais positifs tombent dans une seule suite. Une garantie de 1 % calibrée sur des épisodes honnêtes réservés devient donc moins probable en déploiement sans contrôle du transport. La prédiction de rappel n'est pas touchée. | Faites : [G17], [G18] (p. 1, 5), [G21], [G30] (p. 3, 5). Non faites : [G24] (p. 3), [G29] (p. 4), [G61], [G63] (p. 5, 6). Contre-indice : {{G35}} (p. 6) ; {{G54}} (p. 10) ; {{G47}} (p. 8) ; {{G44}} (p. 7) |
| L (« 3 ») | **voisin** | Faite : la relation classique entre taux par ligne et risque « au moins une alarme » de l'unité (sous indépendance 1 − (1 − p)ⁿ ; sans hypothèse, entre p et min(1, np)), présentée comme standard. Non faites : attaquant qui répartit un budget ; statistique somme ; puissance fonction de (B, n₀) ; effondrement du maximum sous fragmentation (L2) ; calendrier et garantie toujours valide (L3). Illustration non probante dans le sens de L2 : au budget de 5 %, le taux de vrais positifs du maximum (observable) passe de 0,357 (k = 1) à 0,053 (k = 10), mais le support des étiquettes change avec k et l'auteur écarte la comparaison. | {{G10}} (p. 2) ; {{G72}} (p. 3) ; {{G25}} (p. 3) ; {{G26}} (p. 3) ; {{G27}} (p. 4) ; {{G50}} (p. 11) ; {{G49}} (p. 11) ; [G51] (p. 11) |
| H1 (comparateur) | **voisin** ; **contre-indice faible** | Faites : comparaison sonde / observable boîte noire de même horizon / fusion des deux, à budgets certifiés égaux, sur deux terrains agentiques ; principe d'identification : l'activation étant une fonction déterministe de l'historique observable, son gain sur un comparateur qui voit le même historique est une valeur prédictive restreinte (apprentissage fini), pas une information privilégiée. Non faites : sabotage diffus ; tâches floues (les cibles sont une entrée à fort enjeu, un refus futur, l'exécution d'une injection, l'échec d'une tâche). Contre-indice faible : sur AgentDojo, aucun gain de la sonde sur l'observable à faible taux de faux positifs, et l'avant-test classait déjà l'observable devant ; sur ST-WebAgentBench, gain d'aire sous la courbe non significatif. Portée limitée : une couche d'un modèle de 7 milliards de paramètres, une seule attaque, support insuffisant (38 positifs pour 40 requis), comparateur aidé d'un modèle de 14 milliards. En sens inverse, hors agents : gains nets à 5 % (Models Under Pressure, LASR). | {{G31}} (p. 5) ; {{G32}} (p. 5) ; {{G57}} (p. 2) ; {{G16}} (p. 2) ; {{G53}} (p. 4) ; {{G41}} (p. 7) ; {{G42}} (p. 7) ; {{G64}} (p. 7) ; {{G70}} (p. 8) ; {{G43}} (p. 7) ; {{G73}} (p. 7) |
| HC5 | **voisin** (mécanisme) | Faite : fusion tardive d'une sonde interne et d'un observateur boîte noire qui comprend trois prévisions d'un modèle de 14 milliards de paramètres. Non faites : quorum ; attaques de corruption contre les moniteurs ; matrice de transfert. | {{G33}} (p. 5) ; [G32] (p. 5) |
| HC1 | **voisin** (instrument seulement) | Les prévisions de l'observateur sont lues comme log-cotes d'un modèle de 14 milliards ([G32]) ; aucune pression, aucune famille d'attaque, aucune destination, aucune déférence. | [G32] (p. 5) |
| Tr | **ne touche pas** (voisin lointain) | Maximum au niveau de l'unité et comparaison « dernier jeton » / « moyenne sur la requête », sans aucun attaquant contre la sonde. | {{G40}} (p. 1) ; [G18] (p. 5) ; [G15] (p. 2) ; [G46] (p. 8) |
| HC2, HC2b, HC3, HC4, HC6, H3, H4′, H5, H6, H7, H8, T, statistique de population (papier B) | **ne touche pas** | Aucune pression ni attaque visant un moniteur, aucune adaptation de l'attaquant, un seul agent, aucune permutation ni co-élévation. Pour HC2 : l'injection est un contenu hostile lu par l'agent, mais le papier ne mesure aucun déplacement du score de la sonde provoqué par une attaque contre elle. Pour H8 : l'échelle de revendications distingue accessibilité et valeur prédictive, sans rien prédire de la robustesse. | [G15] (p. 2) ; [G45], [G46] (p. 8) ; [G53] (p. 4) |

**H2 — les deux lectures, et ce qui tranche.**

- Lecture « occupe en partie » : si « lire l'agent qui agit » et « calibrer au niveau de l'épisode, sur des unités négatives seules, l'événement « au moins une alarme » » comptaient comme pièces revendiquées de H2, ces deux composantes seraient faites ici, pour un agrégateur maximum.
- Lecture « voisin », que je retiens, pour trois raisons. (1) La décision N-007 a déjà retiré « l'application aux sondes internes » de la revendication. (2) Le calibrage « au moins une alarme » par unité est déclaré antérieur par l'auteur lui-même : [G09] (p. 2), [G13] (p. 2), {{G14}} (p. 2). (3) Les pièces revendiquées de H2 sont absentes : accumulation additive, garantie uniforme sur toutes les lectures de l'horizon, sabotage sous un seuil par action à 1 %, rappel croissant avec l'horizon. L'auteur écarte même explicitement le contrôleur séquentiel : [G24] (p. 3) ; {{G48}} (p. 8).
- Ce qui trancherait autrement : un énoncé de H2 qui revendiquerait la lecture de l'agent ou le calibrage par épisode ; l'énoncé retenu (N-007) ne le fait pas.
- Occupation à noter : la méthode de seuil par statistique d'ordre sur des unités indépendantes, avec abstention faute de support, est prise, ici et chez ses antécédents, que l'auteur cite lui-même : {{G74}} (p. 2). Si le programme l'emploie sur des épisodes honnêtes entiers, il la cite ; il ne la revendique pas.

### 1.5 Chiffres utilisables

| chiffre | nature | page et citation |
|---|---|---|
| Fusion sonde + observable : aire sous la courbe 0,957 (Models Under Pressure) et 0,935 (LASR) ; taux de vrais positifs certifiés à 5 % / 10 % : 0,642 / 0,742 et 0,719 / 0,782 | auteurs | p. 1 : {{G39}} |
| AgentDojo, sonde « moyenne » : aire sous la courbe 0,922 ; aucun des 38 cas positifs détecté à 5 % ; seuils visant 10 % : 18,7 % à 20,0 % de faux positifs en test | auteurs | p. 1 : [G40] |
| Rang un : 59 unités négatives indépendantes pour un budget de 5 % à 95 % de confiance ; 29 pour 10 % | auteurs ; recalculé (58,40 et 28,43, arrondis au-dessus) | p. 4 : {{G28}} ; p. 6 : {{G37}} |
| Budget de 1 % à 95 % de confiance : au moins 299 épisodes honnêtes indépendants pour un seuil fini (rang 1) ; 500 épisodes → rang 2 ; 1 000 → rang 5 ; 2 000 → rang 13 ; 5 000 → rang 39 | calcul (formules (5) et (6), p. 4 ; quantile de la loi bêta obtenu par inversion de la loi binomiale) | p. 4 |
| Risque « au moins une alarme » pour 5 % par ligne : 5,0 / 22,6 / 40,1 / 64,2 % pour n = 1 / 5 / 10 / 20 occasions | auteurs ; recalculé | p. 4 : [G27] ; p. 3 : [G26] |
| Pour 1 % par action, sous indépendance : 9,6 / 18,2 / 39,5 / 63,4 / 86,6 % de fausses alarmes par épisode pour 10 / 20 / 50 / 100 / 200 actions | calcul (formule de la proposition 1, p. 3) | p. 3 |
| AgentDojo, budget 10 % : rang 5 sur 100 négatifs, borne certifiée 8,92 %, réalisé 18,67 % ; probabilité 0,001745 sous échangeabilité | auteurs ; recalculé (bornes 0,046560 et 0,089196 ; probabilité 0,001745) | p. 6 : [G35] ; {{G36}} ; p. 10 : [G54] |
| Concentration : au budget de 5 %, taux de faux positifs de 14,29 % dans une suite contre 2,67 % au total | auteurs | p. 7 : [G44] |
| AgentDojo avant test : aire sous la courbe 0,9020 (observable), 0,8918 (sonde), 0,8879 (fusion) | auteurs | p. 7 : [G41] |
| Écart de taux de vrais positifs fusion − observable à 5 % : AgentDojo −0,0263 [−0,0789 ; 0] ; Models Under Pressure +0,2649 [0,1529 ; 0,4268] | auteurs | p. 7 : [G42] ; [G43] |
| ST-WebAgentBench : sonde 0,8738 ; fusion − observable +0,0215 [−0,0097 ; 0,0568] ; 23 négatifs de calibrage, abstention aux deux budgets | auteurs | p. 7 : [G64] ; p. 6 : [G37] ; p. 1 : {{G59}} |
| Coût de capture des activations : latence non mesurable par lot de 1, 0,067 % par lot de 8 ; tenseur de 4 à 41 Mio ; passe avant d'environ 26 ms | auteurs | p. 6 : {{G38}} |
| Sensibilité au nombre de tentatives (observable, 5 %) : 0,357 (k = 1) → 0,053 (k = 10), soit une division par 6,7 ; confondue par le changement de support | auteurs ; calcul du rapport | p. 11 : [G50] ; [G49] |

### 1.6 Ce qui n'a pas été lu

- Le texte des 12 pages est lu en entier. La figure 3 (p. 11, nuage de points) est illisible en texte : légende et axes seulement. Le matériel supplémentaire et l'artefact (registre de criblage, manifestes, code) ne sont pas dans le PDF : non lus.

## 2. 2411.17693v1 — Wen, Hebbar, Larson et collègues, « Adaptive Deployment of Untrusted LLMs Reduces Distributed Threats »

### 2.1 Identité

- Titre, composé en petites capitales et extrait en capitales espacées ; les mots sont ceux du titre des consignes (p. 1) : {{W01}}.
- Douze auteurs (p. 1) : {{W02}}. Affiliations : {{W03}} ; {{W04}}. Les trois premiers : {{W06}}.
- Version et date (p. 1) : {{W05}}.
- Venue : aucune dans ce PDF. Chacune des 44 pages porte l'en-tête {{W07}} ; « ICLR » et « Conference on Learning » : 0 occurrence ; les métadonnées (`pdfinfo`) sont vides.

### 2.2 Nature exacte du macro-protocole (questions des consignes)

- **Deux niveaux** : {{W09}} (p. 1).
- **Pas d'alarme ni d'arrêt** : le macro-protocole choisit, tâche après tâche, la sortie d'un micro-protocole plus sûr ou plus utile selon sa crédence : {{W65}} (p. 2). Les auteurs écartent l'arrêt sur un seul indice : {{W66}} (p. 1).
- **Mise à jour de la crédence** : règle de Bayes sur des hypothèses h = (r, β), où r est le taux de mauvaise conduite et β l'arbitrage entre discrétion et efficacité : {{W20}} (p. 5) ; {{W22}} (p. 6). La vraisemblance est celle des scores du moniteur, {{W69}} (p. 6), estimée en comptant des tranches de scores dans une distribution de référence (algorithme 1, p. 20). Elle est additive en log-cotes : {{W47}} (p. 19). La mise à jour naïve se décalibre ; le correctif refait la suite des mises à jour sur cinq sous-ensembles de la référence : {{W46}} (p. 19) ; {{W72}} (p. 19).
- **A priori** : 50 % sur le modèle bénin, {{W74}} (p. 16) ; sur les hypothèses malveillantes, un a priori « optimal au pire cas » tiré d'un équilibre de Nash contre l'équipe rouge : {{W21}} (p. 6).
- **Modèle de l'attaquant** : une fonction de qualité unique et le choix des meilleures occasions, {{W19}} (p. 5) ; ni état entre tâches ni accès au moniteur, {{W16}} (p. 4) ; politique sans mémoire, {{W50}} (p. 21) et {{W40}} (p. 10) ; taux de mauvaise conduite optimisé contre la défense, {{W28}} (p. 7).
- **Moniteur** : boîte noire. Un modèle de confiance plus faible lit le problème et la solution : {{W42}} (p. 13) ; {{W31}} (p. 8). Le score vient des log-probabilités de « yes » et « no » : {{W51}} (p. 21) ; {{W48}} (p. 19). Pour les modèles Claude, moyenne de huit notes : {{W73}} (p. 19).
- **Garantie de faux positifs** : aucune. La défense reçoit des sorties malveillantes de référence : {{W23}} (p. 6) ; {{W25}} (p. 7) ; {{W41}} (p. 10).
- **Données** : quelques centaines de problèmes APPS (jeu de problèmes de programmation compétitive), 479 dans les annexes ; les mêmes données servent à l'équilibre de Nash, à la validation et au test ; référence et déploiements sont des découpages du même jeu ; les déploiements de 10 000 tâches sont simulés à partir de ces problèmes : {{W44}} (p. 13) ; {{W56}} (p. 41) ; {{W43}} (p. 13) ; {{W45}} (p. 18) ; {{W61}} (p. 17). Les tâches sont indépendantes ; les tâches corrélées sont laissées à des travaux futurs : {{W75}} (p. 10).
- **Bases de comparaison** : crédence figée et seuil statique par tâche : {{W29}} (p. 8) ; {{W30}} (p. 8).
- **Chiffres de sécurité et d'utilité** : voir 2.5.

### 2.3 Affirmations de la recherche affirmative

| # | affirmation de la recherche affirmative | verdict | page | citation exacte |
|---|---|---|---|---|
| 1 | 2411.17693 (version non vue) ; titre ; « Wen, Hebbar et autres (d'après les liens) » ; novembre 2024 | confirmé et complété : version 1 du 26 novembre 2024 ; douze auteurs, Jiaxin Wen, Vivek Hebbar et Caleb Larson à contribution égale, puis Aryan Bhatt, Ansh Radhakrishnan, Mrinank Sharma, Henry Sleight, Shi Feng, He He, Ethan Perez, Buck Shlegeris, Akbir Khan | 1 | {{W01}} ; {{W02}} ; {{W05}} ; {{W06}} |
| 2 | « ICLR 2025 » (International Conference on Learning Representations) | introuvable : cherché « ICLR », « Conference on Learning » et toute mention de venue dans les 44 pages ; chaque page porte l'en-tête « Preprint » | 1 | {{W07}} |
| 3 | « Deux niveaux de protocole » | confirmé | 1 | {{W09}} |
| 4 | Le « macro-protocole » tient une crédence sur l'alignement du modèle non fiable et la met à jour par la règle de Bayes avec les scores du moniteur, tâche après tâche | confirmé ; précision : crédences sur des hypothèses (r, β), vraisemblance des scores estimée sur une distribution de référence | 1 ; 5 ; 6 | {{W10}} ; {{W18}} ; {{W69}} |
| 5 | « contre des menaces distribuées où aucune action seule n'est décisive » | confirmé : ni action catastrophique ni preuve écrasante isolée | 1 | {{W08}} |
| 6 | « Selon le résumé : 80 % de portes dérobées en moins à utilité égale » | confirmé ; précision : « par rapport aux bases non adaptatives » ; chiffre du seul résumé (aucune autre occurrence de « 80% » dans le PDF ; il repose sur des figures illisibles en texte) | 1 | {{W11}} |
| 7 | « Antériorité directe de l'idée « accumuler la preuve dans le temps contre des menaces distribuées » » | confirmé | 2 | {{W12}} ; {{W14}} |
| 8 | « Moniteur en boîte noire » | confirmé | 13 ; 21 | {{W42}} ; {{W51}} |
| 9 | « mise à jour bayésienne qui suppose un modèle de l'attaquant » | confirmé | 5 | {{W19}} |
| 10 | « donc pas de garantie toujours valide calibrée sur épisodes honnêtes » | confirmé et renforcé : aucune garantie de faux positifs d'aucune sorte ; la méthode exige des sorties malveillantes de référence et un a priori optimisé contre l'équipe rouge | 6 ; 7 | {{W23}} ; {{W25}} ; {{W21}} |
| 11 | « pas de sondes » | confirmé : « probe », « activation » et « internal » : 0 occurrence dans les 44 pages | — | recherche plein texte (aucune citation possible d'une absence) |
| 12 | Verdict « occupe en partie l'idée générale ; voisin pour le reste » (H2 ; « 3 ») | corrigé : « voisin » pour H2 (c'est le squelette séquentiel en boîte noire, déjà acquis), avec une réserve ; « voisin » pour L (voir 2.4) | — | voir 2.4 |

### 2.4 Antériorité (R8)

| énoncé | verdict d'antériorité | composantes faites / non faites | pages et citations |
|---|---|---|---|
| H2 | **voisin** (c'est le squelette séquentiel en boîte noire, déjà acquis selon la consigne) ; **réserve** | Faites, en boîte noire : accumulation séquentielle de la preuve sur les tâches par mise à jour bayésienne, additive en log-cotes ; performance qui croît avec la longueur de la séquence ; menace distribuée sans action seule décisive. Non faites : sondes (aucune) ; garantie de faux positifs (aucune, et pas d'alarme) ; calibrage sans exemple de sabotage (non : référence malveillante, a priori contre l'équipe rouge) ; seuil par action à 1 % ; trajectoires d'agent (tâches de code indépendantes, attaquant sans mémoire). Réserve : les auteurs observent que les erreurs d'estimation s'accumulent sur les longues séquences et décalibrent la crédence (constaté pour une mise à jour bayésienne, non pour un processus e) ; et le gain avec la longueur est mesuré dans des conditions favorables (référence tirée du même jeu ; mêmes données pour l'équilibre, la validation et le test). | Faites : [W12], [W14] (p. 2) ; {{W26}} (p. 7) ; {{W34}} (p. 9) ; [W47] (p. 19) ; {{W15}} (p. 2). Non faites : [W65] (p. 2) ; [W23] (p. 6) ; [W16] (p. 4) ; [W75] (p. 10). Réserve : {{W24}} (p. 6) ; [W46] (p. 19) ; [W43] (p. 13) ; [W45] (p. 18) |
| L (« 3 ») | **voisin** | Faite : l'équipe rouge optimise son taux de mauvaise conduite et son arbitrage entre discrétion et efficacité contre la défense, une forme de dosage d'un budget d'attaque dans le temps ; sa meilleure réponse au macro-protocole est de ne soumettre que les portes dérobées les plus discrètes ; contre un seuil statique par tâche, sa meilleure réponse est d'attaquer toujours. Non faites : lemme d'additivité ; puissance fonction de (B, n₀) ; garantie toujours valide ; calendrier (attaquant sans mémoire ni état). | [W28] (p. 7) ; [W20] (p. 5) ; {{W49}} (p. 21) ; {{W60}} (p. 42) ; [W16] (p. 4) ; [W40] (p. 10) |
| H1 (comparateur) | **ne touche pas** (aucun accès interne) ; base de comparaison possible | Le macro-protocole est une base séquentielle en boîte noire, mais il consomme des exemples d'attaque et n'a pas de taux de faux positifs : le comparer à H2 à taux de faux positifs égal demanderait un seuil sur la crédence calibré sur épisodes honnêtes, ce que le papier ne fait pas. Les tâches sont nettes (porte dérobée vérifiable par des tests), pas floues. | [W31] (p. 8) ; [W42] (p. 13) ; [W23] (p. 6) |
| HC1 | deux lectures : **occupe en partie** (instrument seulement) ou **voisin** | Faite : le verdict d'un moniteur de contrôle lu comme score continu par la probabilité des jetons « yes » / « no » (2024). Non faites : pression graduée, familles d'attaque, destination ĉ, régression sur plusieurs intensités, déférence. Lecture « occupe en partie » si « le verdict lu par probabilité du jeton » est une pièce revendiquée en soi ; lecture « voisin » s'il n'est que l'instrument de mesure de la loi. Ce qui tranche : la rédaction de la pièce revendiquée de HC1. Dans les deux cas, cet instrument seul n'est pas revendicable. | [W51] (p. 21) ; [W48] (p. 19) |
| H6 | **voisin** (mécanisme repris de Greenblatt et collègues, 2023) | Faite, à une seule intensité et pour une intervention ciblée (réécriture par le modèle de confiance pour retirer les passages suspects) : le taux de portes dérobées réussies par tentative tombe de 13,4 % à 0,9 % (baisse relative de 93 %, calcul), l'utilité de 47,4 % à 38,1 % (baisse relative de 20 %, calcul). Non faites : intervention non spécifique (paraphrase, ré-échantillonnage, remise à zéro du contexte, bruit d'activations) ; intensité graduée ; marge testée statistiquement. Comparaison indicative : les dénominateurs diffèrent (tableau 7, par tentative ; tableau 8, sécurité par exécution). | {{W67}} (p. 4) ; {{W17}} (p. 4) ; {{W52}} (p. 24) ; {{W53}} (p. 24) ; {{W54}} (p. 41) ; {{W55}} (p. 41) |
| H7 | **ne touche pas** (voisin lointain) | Attaquant sans mémoire, aucune politique de riposte. Seule mesure apparentée : la corrélation entre la discrétion que le modèle non fiable prédit et le score du moniteur (+0,22 et +0,45). | {{W38}} (p. 9) ; {{W68}} (p. 9) ; [W50] (p. 21) |
| HC2, HC2b, HC3, HC4, HC5, HC6, H3, H4′, H5, H8, T, Tr, statistique de population (papier B) | **ne touche pas** | Un seul modèle non fiable, moniteur en boîte noire, aucune sonde, aucune attaque contre le moniteur. Pour HC5 : l'ensemble de micro-protocoles combine des sorties, pas des moniteurs de types d'accès différents. | [W31] (p. 8) ; [W42] (p. 13) |

**H2 — les deux lectures, et ce qui tranche.**

- Lecture « occupe en partie » : si H2 revendiquait l'idée générique « accumuler la preuve sur une séquence contre une menace diffuse, avec un gain qui croît avec la longueur », ce papier l'occuperait, en boîte noire, par une mise à jour bayésienne, sans garantie : {{W62}} (p. 3) ; {{W63}} (p. 2).
- Lecture « voisin », que je retiens : la consigne commune range ce squelette séquentiel en boîte noire parmi les acquis à ne pas compter comme occupation nouvelle, et aucune pièce revendiquée de H2 n'est faite (ni sondes, ni garantie toujours valide, ni calibrage sans sabotage, ni seuil par action à 1 %).
- Ce qui trancherait autrement : une reformulation de H2 qui ferait de l'idée générique une pièce revendiquée.

### 2.5 Chiffres utilisables

| chiffre | nature | page et citation |
|---|---|---|
| 80 % de portes dérobées en moins, à utilité donnée, par rapport aux bases non adaptatives | auteurs (résumé seul ; figures illisibles en texte) | p. 1 : [W11] |
| 98,3 % de la performance du modèle non fiable, porte dérobée acceptée sur moins de 1 % des tâches, séquences de 10 000 tâches | auteurs | p. 2 : {{W13}} |
| 98,4 % de l'utilité et sécurité de 99,2 %, soit 80 actions nuisibles sur 10 000 (moniteur GPT-3.5) | auteurs ; incohérent avec 98,3 % (p. 2) | p. 8 : {{W33}} ; p. 9 : {{W35}} |
| Modèle non fiable seul : sécurité 86,4 % (texte) ; 86,6 ± 2,5 % (tableau 8) | auteurs ; écart interne | p. 8 : {{W32}} ; p. 41 : [W54] |
| Aire sous la courbe du moniteur : 0,94 pour GPT-3.5, puis « 0,94 contre 0,91 » à l'avantage de Claude-3-Opus sur la même page ; Claude-3-Haiku : 0,67 | auteurs ; incohérence interne, non opposable sans la figure 4 | p. 9 : [W35] ; {{W37}} ; {{W36}} |
| Réussite au premier essai : 23,9 % (modèle de confiance GPT-3.5) contre 47,4 % (modèle non fiable) | auteurs | p. 9 : {{W39}} |
| Meilleur que les bases dès 10 tâches observées | auteurs (lecture de figure par les auteurs) | p. 9 : [W34] |
| Coefficient de sécurité α = 1 : choix des micro-protocoles 75 % / 14 % / 12 % ; sécurité 99,24 % ; utilité 46,7 % | auteurs | p. 14 : {{W57}} |
| α = 1 : 76 portes dérobées réussies sur 10 000 tâches ; utilité 46,7 % | auteurs | p. 14 : {{W58}} ; {{W59}} |
| Portes dérobées réussies par tentative (moniteur GPT-3.5) : 566 sur 4 217 (13,4 %) sans réécriture ; 180 sur 21 085 (0,9 %) avec réécriture | auteurs | p. 24 : [W52] ; [W53] |
| Sécurité / utilité : 86,6 / 47,4 sans réécriture ; 99,1 / 38,1 avec réécriture | auteurs | p. 41 : [W54] ; [W55] |
| Corrélation entre discrétion prédite et score du moniteur : +0,22 (GPT-3.5) ; +0,45 (Claude-3-Opus) | auteurs | p. 9 : [W38] ; [W68] |
| 80 essais sur des découpages différents ; 479 problèmes ; 1 000 exécutions pour la base à seuil statique | auteurs | p. 7 : {{W27}} ; p. 41 : [W56] ; p. 42 : {{W64}} |

### 2.6 Réserves (R4)

- Incohérences internes : 98,3 % (p. 2) contre 98,4 % (p. 8 et 9) ; une aire sous la courbe de 0,94 attribuée à GPT-3.5 puis à Claude-3-Opus (p. 9) ; 86,4 % (p. 8) contre 86,6 % (p. 41). Renvois de figures discordants : {{W70}} (p. 8), alors que {{W71}} (p. 8).
- Conditions favorables à l'accumulation bayésienne : référence et déploiements tirés du même jeu ([W45]) ; mêmes données pour l'équilibre, la validation et le test ([W43]) ; 479 problèmes pour des déploiements de 10 000 tâches ([W56], [W61]).
- Le chiffre de 80 % n'apparaît que dans le résumé.

### 2.7 Ce qui n'a pas été lu

- Le texte des 44 pages est lu. Les figures 1, 3, 4, 5, 6 et 7 (p. 2, 7, 8, 40, 43, 44) sont illisibles en texte : légendes seulement ; les points des courbes de Pareto, dont dépendent le 80 % et les gains avec la longueur, ne sont donc pas vérifiés. L'annexe I (p. 24 à 39, exemples de portes dérobées) est lue, sans enjeu pour les énoncés. Le code des auteurs, auquel renvoient les notes 14 et 15 (p. 19), n'est pas lu.

## 3. Pistes R8 tirées de la bibliographie de 2610.04575 (non lues, non opposables)

- [26] Schirmer et collègues, 2026 : {{G65}} (p. 9). Gao le décrit ainsi : [G13] (p. 2). Au dépôt, ce papier n'est cité que pour HC1. À lire pour H2 (composante séquentielle en ligne, garantie).
- [33] Wilhelm et Kao, 2026 : {{G66}} (p. 9). Activations d'agents, états de risque dans le temps, calibrage par le contexte ; absent du dépôt. À lire pour H2.
- [12] PrefixGuard, 2605.06455 : {{G67}} (p. 2). Déjà connu du dépôt.
- Aussi cités par Gao (identifiants relevés dans la liste de références, p. 9, sans contrôle par script). Déjà connus du dépôt : TRACES 2605.27690 (type de la base (iv) de N-007), AgentForesight 2605.08715, 2603.04069, 2607.06807, SLEIGHT-Bench 2605.16626. Absents du dépôt : AgentLens 2606.22673, PVDetector 2607.12624.
- Gao rattache enfin la surveillance à faible taux de faux positifs au contrôle de l'intelligence artificielle (Greenblatt et collègues, sa référence [9], déjà connue) : {{G55}} (p. 2).

## 4. Synthèse (dix lignes au plus)

1. Aucune occupation en entier. Une seule occupation en partie possible, mineure et à deux lectures : le verdict de moniteur lu par probabilité des jetons (HC1), fait dans 2411.17693. H2 n'est occupé par aucun des deux papiers.
2. 2610.04575v1 (Xueping Gao, auteur unique, 3 octobre 2026 ; mis en forme pour DAI ’26, acceptation non énoncée) est voisin de H2 : sondes lisant l'agent qui agit, seuil calibré sur unités négatives, maximum par unité ; ni accumulation, ni garantie toujours valide, ni sabotage, ni horizon ; il écarte explicitement le contrôleur séquentiel.
3. Il déclare antérieurs, sans les revendiquer, le risque « au moins une alarme » par unité et son calibrage : L voisin ; méthode à citer, pas à revendiquer.
4. Contre-indices dans 2610 : H2, tenue du calibrage (8,92 % certifié, 18,67 % réalisé, probabilité 0,001745) ; H1, faible (aucun gain de la sonde sur AgentDojo : −0,0263 [−0,0789 ; 0]).
5. 2411.17693v1 (Wen, Hebbar, Larson et neuf autres ; 26 novembre 2024 ; « Preprint ») est voisin de H2 : c'est le squelette séquentiel boîte noire (bayésien, additif en log-cotes, gain avec la longueur), avec exemples d'attaque, sans garantie de faux positifs ni sondes ; réserve sur l'accumulation des erreurs. L et H6 : voisins.
6. Affirmations corrigées : acceptation à DAI 2026 (non énoncée), « unité trajectoire » et « seul travail », verdicts « occupe en partie » ramenés à « voisin ». Introuvable : ICLR 2025. Le 80 % n'est que dans le résumé.
7. 2411.17693 contient des incohérences internes (98,3 / 98,4 % ; 0,94 / 0,91 ; 86,4 / 86,6 %) : ces chiffres ne sont pas opposables sans les figures.
8. Calculs utiles : un seuil de 1 % certifié à 95 % exige au moins 299 épisodes honnêtes indépendants ; 1 % par action donne 63,4 % de fausses alarmes sur 100 actions (sous indépendance).
9. Contrôle : 149 citations, 0 échec ; mutation : 0 acceptée sur 149. Pistes R8 à lire : 2607.02510 et 2606.06223.

## Contrôle final

{{CONTROLE_FINAL}}
