# Rapport du lecteur neuf — état de l'art, niveau 2, lot 2, C2b « suffixes optimisés »

- **Date** : {{DATE}} (temps universel coordonné, UTC).
- **Lecteur** : sous-agent neuf ; n'a écrit aucun des documents vérifiés. Rien n'a été modifié sous `/home/user/controle-ia` (lecture seule, ni fichier ni git).
- **Notation** : ⟦J4⟧ renvoie à la citation J4 de `citations.json`, contrôlée par script contre le texte de la page indiquée (section « Contrôle des citations »). Les pages sont le rang dans le fichier (`pdftotext -layout`, page par page).

## En-tête — PDF lus et empreintes

Dossier `/home/user/controle-ia/docs/sources/pdf/`. Empreintes sha256 recalculées et comparées par `sha256sum -c` à la liste des consignes : **5 sur 5 conformes**.

| Fichier | Pages | Empreinte sha256 (attendue = obtenue) | Lecture |
|---|---|---|---|
| 2402.14016v2.pdf | 19 | d10f97ce404e460004a35cd0ca4093f7bbd547230986280be1f5f4460fac9b12 | intégrale, annexes comprises |
| 2403.17710v5.pdf | 20 | 7bea71368aec667cdbae6d096ff39a18ca11f7c39d53cab65f999771d7869cc3 | intégrale, annexes comprises |
| 2504.18333v1.pdf | 12 | 96d398709fcb5ff38bb2568249f7a68997b0bac96e1afc7f0b72bf0e63038df7 | intégrale, annexes comprises |
| 2505.13348v1.pdf | 6 | 980c51a243fc8f94f80faed83e1c84784d4193a497966731919fd11286209714 | intégrale |
| 2603.29403v2.pdf | 31 | 7141fad8e02f81bd4e09fec1c810a549e80892db8bc10211a8082b060153f2d2 | intégrale (au-delà du seuil de 30 pages, lue quand même en entier, bibliographie comprise) |

**Non lu** : le contenu graphique des figures (courbes, histogrammes, cartes de chaleur) ; seuls leurs légendes et le texte extractible ont été lus. Aucun verdict ni chiffre de ce rapport ne repose sur une figure.

**Affirmation vérifiée.** `docs/etat-de-l-art-controle-ia-v1.md` (empreinte du fichier lu : a7d6846d14758c13639eccb2daeb47722085636a6601aa159e4132ab71d570ce), ligne 133, conforme mot pour mot aux consignes ; elle se trouve dans la section « 4.1 Occupé (à citer, pas à revendiquer) » du papier C :

> - **Attaques par suffixes optimisés** (autre modèle de menace, à ne pas confondre avec la pression sociale) : JudgeDeceiver, arXiv 2403.17710 (CCS 2024) ; arXiv 2505.13348 ; arXiv 2402.14016 ; arXiv 2504.18333 ; systématisation arXiv 2603.29403.

Elle est décomposée, article par article, en : (a) l'article relève des « attaques par suffixes optimisés » ; (b) il relève d'un « autre modèle de menace » que la pression sociale ; (c) pour 2403.17710, identité « JudgeDeceiver » et venue « CCS 2024 » ; (d) pour 2603.29403, « systématisation ».

---

## 1. arXiv 2402.14016v2 — Raina, Liusie, Gales

**Identité**
- Titre : {{R1}} (p. 1).
- Auteurs (tous) : Vyas Raina et Adian Liusie (contribution égale), Mark Gales ; Université de Cambridge : {{R2}} (p. 1).
- Version et date : {{R3}} (p. 1).
- Venue : **non imprimée dans ce PDF**. Source secondaire, dans le lot : la bibliographie de 2603.29403v2 la place aux actes de la conférence *Empirical Methods in Natural Language Processing* 2024, pages 7499–7517 : {{S8}} (p. 29).

| # | Affirmation du programme | Verdict | Page | Citation exacte |
|---|---|---|---|---|
| 1.1 | Rangé parmi les « attaques par suffixes optimisés » | **confirmé** — précision : phrase universelle ajoutée en fin de texte, optimisée par recherche gloutonne mot à mot (pas par gradient : le gradient glouton par coordonnées, essayé, fait moins bien), apprise sur un modèle substitut puis transférée | 8 ; 4 ; 4 ; 1 | {{R9}}<br>{{R7}}<br>{{R8}}<br>{{R4}} |
| 1.2 | « autre modèle de menace, à ne pas confondre avec la pression sociale » | **confirmé** — précision : les mots trouvés sont élogieux (contenu assertif), sans appel à l'autorité, au consensus ni à l'insistance ; la menace suppose l'accès complet à un modèle substitut | 12 ; 1 | {{R10}}<br>{{R5}} |

**Chiffres utilisables**
- Sur le substitut FlanT5-xl en notation absolue, quatre mots suffisent pour un rang 1 sur presque tous les textes : {{R15}} (p. 6) — nature : auteurs.
- Score moyen avant puis après une attaque de 4 mots (FlanT5-xl, tableau 3) : SummEval global 3,73 → 4,74, {{R16}} ; TopicalChat global 2,93 → 4,63, {{R17}} (p. 6) — auteurs.
- Effet croissant avec le nombre de mots sur le substitut, {{R14}} (p. 6) ; non monotone en transfert, {{R21}} (p. 7) — auteurs.
- Lecture du verdict : espérance du score pondérée par les probabilités normalisées des jetons de score, {{R12}} (p. 3) et {{R11}} (p. 5), sauf pour GPT-3.5, {{R13}} (p. 5) — auteurs (méthode).
- **Aucun taux de succès d'attaque n'est rapporté** : « ASR » et « success rate » sont absents des 19 pages (recherche plein texte) — calcul.

**Réserves (R4)**
- Tableaux 22 (attaque directe sur FlanT5-xl) et 24 (transfert sur GPT-3.5), même phrase TOPIC ABS CNT : identiques chiffre pour chiffre — calcul (comparaison par script) ; {{R19}} ; {{R20}} (p. 17). L'un des deux est vraisemblablement une copie erronée : ne pas utiliser le transfert vers GPT-3.5 sur ce critère.
- Tableau 14 (p. 16) : lignes « 3 mots » et « 4 mots » identiques — calcul.
- Tableau 4 (p. 8), meilleure mesure F1 (moyenne harmonique de la précision P et du rappel R) de la détection par perplexité : {{R18}} — F1 imprimé 81,7, alors que 2PR/(P+R) avec P = 66,2 et R = 84,4 donne 74,2 — calcul ; unités mêlées dans le même tableau (0,635 et 64,7).

**Antériorité (R8)**
- **HC1** — contact partiel, **n'occupe pas**. L'article gradue l'intensité d'attaque (1 à 4 mots optimisés) et lit le verdict par les probabilités des jetons de score : deux composantes méthodologiques de HC1. Mais la « pression » est un suffixe optimisé, pas une pression sociale ; la destination est imposée par l'attaquant (score maximal, rang 1) ; ni destination libre testée contre la cible et contre la moyenne du corpus, ni familles de pression ; le juge note des textes, il ne surveille pas un agent.
- **H2, H1, lemme d'additivité, théorème négatif, transposition jeton → action, HC2b, papier B** — **n'occupe pas** : ni sondes, ni activations, ni cumul séquentiel, ni agents multiples ; la seule défense est un détecteur de perplexité à seuil, texte par texte, évalué par courbes précision-rappel sur un jeu équilibré.

---

## 2. arXiv 2403.17710v5 — JudgeDeceiver

**Identité**
- Titre : {{J1}} (p. 1).
- Auteurs (tous) : {{J2}} (p. 1) ; Jiawen Shi et Zenghui Yuan à contribution égale ; Huazhong University of Science and Technology, University of Notre Dame, Lehigh University, Duke University.
- Version et date : {{J3}} (p. 1).
- Venue : {{J5}} (p. 1) ; identifiant numérique d'objet : {{J25}} (p. 1). La bibliographie de la systématisation précise les pages 660–674 des actes : {{S9}} (p. 30).

| # | Affirmation du programme | Verdict | Page | Citation exacte |
|---|---|---|---|---|
| 2.1 | « JudgeDeceiver, arXiv 2403.17710 » | **confirmé** | 1 | {{J4}} |
| 2.2 | « (CCS 2024) » — conférence de l'Association for Computing Machinery sur la sécurité des ordinateurs et des communications, 2024 | **confirmé** | 1 | {{J5}} |
| 2.3 | Rangé parmi les « attaques par suffixes optimisés » | **confirmé** — précision : séquence injectée optimisée par gradient ; suffixe de 20 jetons par défaut ; préfixe et préfixe + suffixe aussi testés, à efficacité voisine | 1 ; 6 ; 8 ; 3 ; 10 | {{J6}}<br>{{J8}}<br>{{J9}}<br>{{J7}}<br>{{J10}} |
| 2.4 | « autre modèle de menace, à ne pas confondre avec la pression sociale » | **confirmé** — précision : l'attaquant maîtrise une réponse candidate et optimise contre un juge à poids ouverts ; la séquence est initialisée au mot « correct », d'où un contenu assertif, mais sans appel social | 4 ; 6 | {{J11}}<br>{{J22}} |

**Chiffres utilisables** (nature : auteurs, sauf mention)
- Taux de succès moyen 90,8 % et cohérence positionnelle 83,4 % (MT-Bench, juge Mistral-7B) : {{J13}} (p. 3).
- Moyennes du tableau 1 : de 88 % à 98,9 % selon le juge et le jeu de données : {{J24}} et {{J29}} (p. 7).
- Injections manuelles : {{J14}} (p. 8).
- Position de l'injection (suffixe 97 %, préfixe + suffixe 95 %, préfixe 94 %) : [[J10]] (p. 10) — mesurée sur une seule paire question-réponse par défaut : {{J27}} (p. 6).
- Transfert : {{J19}} (p. 10).
- Perplexité par fenêtres : {{J15}} (p. 3).
- Détection par réponse connue : {{J20}} (p. 12) ; réserve mineure : l'ordre ne concorde pas avec le tableau 11, {{J21}} (p. 12), où MT-Bench est à 90 % — calcul (comparaison).

**Antériorité (R8)**
- **H2** — contact, **n'occupe pas** : seuil calibré sur exemples propres seulement, pour au plus 1 % de faux positifs, {{J28}} (p. 12) ; mais texte par texte, sur la perplexité, sans cumul, sans horizon, sans sondes. Donnée utile : avec ce calibrage sur 100 exemples, le taux de faux positifs observé du détecteur de perplexité est 3,4 % sur MT-Bench ([[J21]] ; colonnes : faux négatifs puis faux positifs, pour la réponse connue, la perplexité, la perplexité par fenêtres), pour le juge Mistral-7B, {{J30}}, et sur 500 réponses propres, {{J31}} (p. 12) — auteurs, comparaison.
- **Transposition jeton → action** — contact lointain, **n'occupe pas** : la perplexité par fenêtres signale une réponse dès qu'une fenêtre dépasse le seuil (agrégation par maximum), {{J17}} (p. 12) ; statistique de texte, ni sonde d'activations ni action.
- **Théorème négatif** — contact lointain, **n'occupe pas** : la perte de perplexité adverse fond la séquence dans la distribution des textes propres pour passer sous un seuil, {{J26}} (p. 5) ; attaque adaptative contre une statistique par réponse, pas contre des agrégateurs d'autocorrélation ou de co-élévation.
- **HC1** — contact, **n'occupe pas** : la perte d'amélioration de cible maximise la vraisemblance du jeton d'indice de la réponse visée, {{J12}} (p. 2) ; la probabilité du jeton est l'objectif de l'attaque, pas la lecture du verdict ; ni gradation de pression ni destination libre.
- **H1, lemme d'additivité, HC2b, papier B** — **n'occupe pas** (le transfert entre modèles proches, [[J19]], est mesuré en boîte noire, sans états internes).

---

## 3. arXiv 2504.18333v1 — Maloyan, Namiot

**Identité**
- Titre : {{M1}} (p. 1).
- Auteurs (tous) : {{M2}} (p. 1) ; aucune affiliation imprimée (adresse électronique seule).
- Version et date : {{M3}} (p. 1).
- Venue : aucune imprimée (prépublication).

| # | Affirmation du programme | Verdict | Page | Citation exacte |
|---|---|---|---|---|
| 3.1 | Rangé parmi les « attaques par suffixes optimisés » | **corrigé** — à mettre à la place : « arXiv 2504.18333 (Maloyan et Namiot, 2025) : injections d'invite contre des juges, surtout manuelles (injection directe, bombardement de mots complexes, détournement contextuel), plus une recherche par algorithme génétique en boîte noire ; ni suffixe ni gradient ; deux modèles de menace, auteur du contenu et invite système. » Le mot « suffix » n'apparaît dans aucune des 12 pages (recherche plein texte). | 4 ; 4 ; 4 ; 3 | {{M4}}<br>{{M5}}<br>{{M6}}<br>{{M9}} |
| 3.2 | « autre modèle de menace, à ne pas confondre avec la pression sociale » | **corrigé** — à mettre à la place (suite de la formulation 3.1) : « … ; une partie des chaînes d'attaque recourt à un cadrage d'autorité (« System override », « ADMIN_LEVEL_ACCESS », « Priority: CRITICAL ») : recouvre en partie la famille « autorité » de la pression sociale. » | 3 ; 11 | {{M7}}<br>{{M8}} |

**Chiffres utilisables** (nature : auteurs ; non opposables sans réplication, voir réserves)
- Taux de succès maximal 73,8 % (attaque adaptative par recherche, Gemma-3-4B) : {{M16}} (p. 5).
- Comités de juges : {{M19}} ; {{M18}} (p. 7).
- Invite système contre auteur du contenu : {{M21}} (p. 6).

**Réserves (R4)**
- Le résumé contredit le tableau I : {{M13}} (p. 1), contre {{M14}}, {{M15}} et [[M16]] (p. 5), où l'attaque adaptative dépasse le détournement contextuel sur les deux modèles Gemma (72,3 et 73,8 contre 67,7 et 67,4) — auteurs contre auteurs.
- « Ampleur de manipulation » définie comme écart absolu de score, {{M11}}, {{M22}}, {{M23}} (p. 4), mais rapportée comme taux de changement de verdict, {{M12}} (p. 5).
- Intervalles de confiance trop étroits : {{M17}} (p. 5) ; pour 57,5 % sur n = 200 essais binaires, la demi-largeur binomiale à 95 % est ± 6,9 points, contre ± 4,2 imprimé ; pour 29,8 %, ± 6,3 contre ± 3,1 — calcul (1,96 × racine de p(1 − p)/200).
- Critère de succès indifférent au sens du déplacement : {{M10}} (p. 4).

**Antériorité (R8)**
- **Papier B** — contact partiel, en boîte noire, **n'occupe pas** : robustesse d'un comité de juges selon sa taille (3, 5, 7) et selon que les modèles partagent ou non la même architecture ([[M18]], [[M19]]) ; votes de sortie, aucun état interne ; chiffres sous les réserves ci-dessus.
- **HC1** — contact, **n'occupe pas** : variantes « de sophistication croissante » ([[M4]], échelle ordinale de types d'attaque, pas une dose) ; familles d'attaque comparées, dont un cadrage d'autorité ([[M7]]) ; mais critère indifférent au sens ([[M10]]), ni destination libre testée contre la cible et la moyenne du corpus, ni lecture par probabilité du jeton.
- **H2** — **n'occupe pas** : seuils de perplexité fixés a priori, {{M20}} (p. 5), sans calibrage ni cumul.
- **H1, lemme d'additivité, théorème négatif, transposition jeton → action, HC2b** — **n'occupe pas**.

---

## 4. arXiv 2505.13348v1 — Maloyan, Ashinov, Namiot

**Identité**
- Titre : {{G1}} (p. 1).
- Auteurs (tous) : {{G2}} (p. 1) ; aucune affiliation imprimée.
- Version et date : {{G3}} (p. 1).
- Venue : aucune imprimée (prépublication de 6 pages).

| # | Affirmation du programme | Verdict | Page | Citation exacte |
|---|---|---|---|---|
| 4.1 | Rangé parmi les « attaques par suffixes optimisés » | **confirmé** | 1 | {{G4}} |
| 4.2 | « autre modèle de menace, à ne pas confondre avec la pression sociale » | **confirmé** — précision : vrai pour les deux attaques optimisées, qui supposent un accès aux sorties logit ou aux gradients ; la ligne de base « invite heuristique » est, elle, du langage persuasif (effet faible, environ 5 %) | 4 ; 3 | {{G19}}<br>{{G6}} |

**Chiffres utilisables** (nature : auteurs ; non opposables, voir réserves)
- Tableau I, taux de succès en % (Qwen2.5-3B puis Falcon3-3B) : suffixe aléatoire 1,2 et 1,5 ; mélange des jetons 2,8 et 3,1 ; invite heuristique 5,1 et 5,4 ; manipulation de justification 15,2 et 16,7 ; JudgeDeceiver 22,8 et 24,1 ; sape comparative 31,2 et 32,4 : {{G8}} (p. 4, texte du tableau en ordre de lecture, colonne par colonne) ; {{G7}} (p. 4).
- Effectif non publié : aucun nombre d'exemples dans les 6 pages (recherche plein texte) ; intervalle de confiance non calculable.

**Réserves (R4) — fiabilité de la source**
- Sa bibliographie attribue arXiv 2403.17710 à d'autres auteurs et sous un autre titre, {{G12}} (p. 6), que ceux imprimés sur le PDF de JudgeDeceiver ([[J1]], [[J2]]).
- Deux paires de références partagent un même numéro arXiv avec des titres et auteurs différents : {{G13}} (p. 5) et {{G14}} (p. 6) ; {{G15}} et {{G16}} (p. 6).
- Elle décrit JudgeDeceiver comme des gabarits universels, sans accès aux paramètres ni optimisation par instance : {{G10}} (p. 2) ; {{G11}} (p. 4). Or 2403.17710v5 optimise par gradient ([[J6]]), pour chaque paire question-réponse ([[J18]]), contre des juges à poids ouverts ([[J11]]).
- Elle annonce une optimisation qui se contente des sorties logit, {{G18}}, tout en calculant le gradient par rapport aux plongements des jetons, {{G17}} (p. 3).
- Conséquence : citer pour l'existence de l'attaque par suffixe, pas pour ses taux.

**Antériorité (R8)**
- **HC1** — contact, **n'occupe pas** : l'attaque de sape comparative vise directement la probabilité de décision, {{G5}} (p. 2) ; la probabilité du jeton y est l'objectif de l'attaquant, la mesure reste un taux de bascule de verdict ; ni gradation, ni destination libre ; la ligne de base persuasive ([[G6]]) n'est pas graduée.
- **H2, H1, lemme d'additivité, théorème négatif, transposition jeton → action, HC2b, papier B** — **n'occupe pas**.

---

## 5. arXiv 2603.29403v2 — systématisation

**Identité**
- Titre (imprimé en petites capitales) : {{S1}} (p. 1).
- Auteurs (tous) : {{S2}} (p. 1) ; 1 = Université de Pavie (Italie), 2 = Cochin University of Science and Technology (Inde) ; Serena Nicolazzo autrice correspondante.
- Version et date : {{S3}} (p. 1).
- Venue : aucune ; en-tête : {{S20}} (p. 2).

| # | Affirmation du programme | Verdict | Page | Citation exacte |
|---|---|---|---|---|
| 5.1 | « systématisation arXiv 2603.29403 » | **confirmé** | 1 ; 1 | {{S4}}<br>{{S5}} |
| 5.2 | Systématisation des « attaques par suffixes optimisés » ainsi listées | **corrigé** — à mettre à la place : « systématisation de la sécurité des juges à grand modèle de langage, arXiv 2603.29403 (Al Masoud et al., 2026 ; 45 études retenues sur 863) : elle range 2402.14016, 2403.17710 et 2504.18333 sous « injection d'invite », ne cite pas 2505.13348, et compte le langage persuasif parmi les manipulations adverses du juge. » Recherché sans résultat dans les 31 pages : « Ashinov », « Comparative Undermining », « Justification Manipulation », « 2505.13348 » ; sa seule référence Maloyan est 2504.18333. | 8 ; 29 ; 25 | {{S6}}<br>{{S7}}<br>{{S10}} |

**Chiffres utilisables**
- 863 travaux analysés, 45 retenus, 2020–2026 : [[S5]] (p. 1) — auteurs.
- Ses chiffres de synthèse ne remplacent pas les sources primaires — calcul (comparaison) :
  - {{S13}} (p. 8), prêté à Raina et al. : **introuvable** dans 2402.14016v2, qui ne rapporte aucun taux de succès (section 1) ;
  - {{S14}} (p. 8), prêté à JudgeDeceiver : contredit par le tableau 11 de la source ([[J21]] : perplexité 50 %, perplexité par fenêtres 40 % de faux négatifs sur MT-Bench) et par son propre texte, {{S16}} (p. 11) ;
  - {{S15}} (p. 10) : la source donne de 88 % à 98,9 % ([[J24]]).

**Antériorité (R8)**
- **H1** — **n'occupe pas** : simple suggestion, {{S11}} (p. 24) ; aucune activation nommée, aucune expérience, aucun taux de faux positifs.
- **HC1** — **n'occupe pas**, mais **piste hors lot à vérifier** avant toute revendication : la systématisation résume CALM, {{S18}} (p. 30), qui quantifie notamment des biais de suivisme et d'autorité chez des juges, {{S12}} (p. 14) — des familles de pression sociale ; non vérifié ici (R7, R8). Elle définit aussi le juge « pour agents » comme moniteur d'actions, {{S17}} (p. 4), sans étude de pression.
- **H2, lemme d'additivité, théorème négatif, transposition jeton → action, HC2b, papier B** — **n'occupe pas** (synthèse bibliographique ; les comités de juges n'y apparaissent qu'en résumé de 2504.18333).

---

## Formulation proposée pour la ligne 133 (remplacement exact ; décision de Lazar)

« - **Attaques par suffixes optimisés** (autre modèle de menace que la pression sociale : l'attaquant optimise une séquence ajoutée à la réponse jugée, par gradient ou par recherche, avec accès aux poids du juge ou à un modèle substitut) : JudgeDeceiver, arXiv 2403.17710 (CCS 2024 ; suffixe de 20 jetons par défaut, préfixe aussi testé) ; arXiv 2505.13348 (suffixes par gradient glouton par coordonnées ; bibliographie contredite par les sources, chiffres non opposables) ; arXiv 2402.14016 (phrase universelle ajoutée en fin de texte, apprise par recherche gloutonne sur un modèle substitut puis transférée). Voisin, non assimilable : arXiv 2504.18333 (injections d'invite surtout manuelles et recherche génétique en boîte noire, ni suffixe ni gradient ; une partie des chaînes use d'un cadrage d'autorité). Systématisation de la sécurité des juges : arXiv 2603.29403 (range 2402.14016, 2403.17710 et 2504.18333 sous « injection d'invite » ; ne cite pas 2505.13348 ; compte le langage persuasif parmi les manipulations adverses). »

---

## Contrôle des citations

- **Méthode** (`scripts/verifier_citations.py`) : texte de la page de rang N extrait par `pdftotext -layout` (`texte/<article>/pNN.txt`) ; en cas d'échec, même page extraite en ordre de lecture (`pdftotext` sans mise en page, `texte/<article>/brut/pNN.txt`), nécessaire pour une phrase qui court sur plusieurs lignes d'une colonne dans une page à deux colonnes. Tolérances : blancs (toute suite, y compris aucune) et césures (trait d'union suivi d'un saut de ligne) ; aucune autre normalisation (ni casse, ni guillemets, ni Unicode). Gardes : page absente ou vide → erreur ; citation de moins de 15 caractères non blancs → erreur ; aucun repli silencieux.
- **Test R5 préalable** (`scripts/tester_controle.py`) : **10 sur 10 conformes** — 3 cas justes acceptés (une ligne ; plusieurs lignes d'une page à deux colonnes ; césure réelle « power-/ful »), 4 cas altérés refusés (un mot changé ; bonne citation à la mauvaise page ; un mot ajouté ; une lettre supprimée), 3 gardes déclenchées (page absente, citation vide, citation trop courte).
- **Résultat** : **{{NB_CIT}} citations contrôlées, 0 échec** ({{NB_MISE}} retrouvées en mise en page, {{NB_LECT}} en ordre de lecture) ; {{NB_RAPPORT}} d'entre elles sont utilisées dans ce rapport. Au premier passage, une citation (ligne « CUA 31.2 32.4 » du tableau I de 2505.13348) a été refusée par la garde de longueur ; elle a été remplacée par le tableau entier tel qu'extrait ([[G8]]), sans assouplir la garde.
- **Limite connue** : en ordre de lecture, `pdftotext` supprime certains traits d'union réels en fin de ligne (« 4-word » devient « 4word ») ; les citations qui chevauchent ces coupures ont été évitées plutôt que la tolérance élargie.
- **Cohérence du rapport** : ce rapport est généré par `scripts/generer_rapport.py` ; chaque citation y est recopiée par programme depuis `citations.json`, puis relue dans le rapport et recontrôlée contre sa page avant écriture.
- **Calculs** (`scripts/anomalies.py`) : identité des tableaux 22 et 24 et des lignes 3 et 4 du tableau 14 de 2402.14016 ; F1 recalculés du tableau 4 ; demi-largeurs binomiales de 2504.18333.
- **Fichiers** (dossier de travail) : `rapport.md`, `citations.json`, `empreintes-attendues.txt`, `scripts/`, `texte/`.

---

## Synthèse (dix lignes au plus)

1. Empreintes 5 sur 5 conformes ; les cinq PDF lus en entier (88 pages) ; {{NB_CIT}} citations contrôlées par script, 0 échec (test R5 : 10 sur 10).
2. Confirmé : JudgeDeceiver = arXiv 2403.17710, CCS 2024 ; suffixe optimisé par gradient (20 jetons par défaut ; préfixe testé aussi, 94 % contre 97 %).
3. Confirmé : 2402.14016 (phrase universelle en fin de texte, recherche gloutonne sur substitut, transfert) et 2505.13348 (suffixes par gradient) ; mais 2505.13348 est peu fiable (bibliographie contredite par les PDF du lot, effectif absent) : ne pas en opposer les chiffres.
4. Corrigé : 2504.18333 n'est pas une attaque par suffixe optimisé (injections surtout manuelles et recherche génétique en boîte noire, ni suffixe ni gradient) et mêle un cadrage d'autorité, donc recouvre en partie la pression sociale ; ses chiffres sont incohérents entre résumé, tableaux et intervalles.
5. Corrigé : 2603.29403 systématise la sécurité des juges en général ; elle range trois des quatre travaux sous « injection d'invite », ne cite pas 2505.13348, compte le langage persuasif parmi les manipulations, et ses chiffres de synthèse divergent des sources (« ASR up to ≈ 70% » introuvable chez Raina et al.).
6. Introuvable : aucune affirmation du programme.
7. Zones revendiquées : aucune occupée. Contacts partiels : HC1 (2402.14016 : gradation par nombre de mots et score lu par probabilités de jetons, mais destination imposée et pas de pression sociale) ; papier B (2504.18333 : robustesse d'un comité de juges selon sa taille et son architecture, en boîte noire) ; H2 (2403.17710 : seuil calibré sur 100 exemples propres pour 1 % de faux positifs, 3,4 % observés, sans cumul).
8. Piste hors lot pour HC1 : CALM (Ye et al., 2024 ; biais de suivisme et d'autorité des juges), signalée par la systématisation, à lire avant toute revendication.
9. Remplacement exact proposé pour la ligne 133 ci-dessus (modification du programme : décision de Lazar).
