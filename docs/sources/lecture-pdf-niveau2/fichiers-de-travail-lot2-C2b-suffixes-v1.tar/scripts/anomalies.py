"""Contrôles de cohérence interne (calculs) sur des tableaux imprimés. Lecture seule des textes extraits."""
import re, sys, math, pathlib
T = pathlib.Path(sys.argv[1])  # dossier texte/

def bloc(fichier, debut, fin):
    lignes = (T / fichier).read_text().splitlines()
    out, dedans = [], False
    for l in lignes:
        if debut in l: dedans = True
        if dedans: out.append(l)
        if dedans and fin in l: break
    return out

def rangs(lignes):
    r = {}
    for l in lignes:
        m = re.match(r"\s*(None|\d)\s+((?:\d\.\d\d\s+)+\d+\.\d\d)\s*$", l.strip() and l)
        if m: r[m.group(1)] = m.group(2).split()
    return r

p17 = (T / "2402.14016v2/p17.txt").read_text()
# Table 22 et Table 24 : blocs de lignes précédant leurs légendes respectives
def table_avant(texte, legende):
    lignes = texte.splitlines()
    i = [k for k, l in enumerate(lignes) if legende in l][0]
    bloc = []
    for l in reversed(lignes[:i]):
        if l.strip().startswith("Table") or "#words" in l: 
            if "#words" in l: bloc.append(l)
            break
        bloc.append(l)
    return [l.split() for l in reversed(bloc) if l.strip()]
t22 = table_avant(p17, "Table 22:")
t24 = table_avant(p17, "Table 24:")
print("Table 22 =", t22[1:])
print("Table 24 =", t24[1:])
print("Tables 22 et 24 identiques (hors en-tête) :", t22[1:] == t24[1:])
p16 = (T / "2402.14016v2/p16.txt").read_text()
t14 = table_avant(p16, "Table 14:")
print("Table 14 ligne 3 =", t14[4]); print("Table 14 ligne 4 =", t14[5])
print("Table 14 lignes 3 et 4 identiques (hors étiquette) :", t14[4][1:] == t14[5][1:])
# Table 4 (p.8) : F1 recalculé à partir de P et R
for nom, P, R, F in [("Topic-CNT-2", 66.2, 84.4, 81.7), ("Summ-OVE-2", 53.9, 98.8, 69.6), ("Summ-CON-4", 67.9, 81.9, 74.2), ("Topic-OVE-4", 78.5, 85.1, 81.7)]:
    print(f"Table 4 {nom}: F1 imprimé {F} ; F1 recalculé 2PR/(P+R) = {2*P*R/(P+R):.1f}")
# 2504.18333 : demi-largeur binomiale à 95 % pour n = 200
for nom, p, imprime in [("Gemma-3-27B BI", .575, 4.2), ("Gemma-3-4B ASA", .738, 4.9), ("Claude-3-Opus BI", .298, 3.1), ("GPT-4 BI", .324, 3.2)]:
    hw = 1.96 * math.sqrt(p * (1 - p) / 200) * 100
    print(f"2504.18333 {nom}: ±{imprime} imprimé ; demi-largeur binomiale n=200 : ±{hw:.1f} points")
# moyenne Gemma-3-4B (abstract 65.9 %) et Llama (53.4 %)
print("moyenne Gemma-3-4B (Table I) =", round((66.7+55.5+67.4+73.8)/4, 2))
print("moyenne Llama-3.2-3B (Table I) =", round((60.1+47.5+47.8+58.2)/4, 2))
