"""Génère rapport.md à partir d'un gabarit et de citations.json.

{{ID}} -> ⟦ID⟧ « citation exacte » ; [[ID]] -> ⟦ID⟧ ; {{DATE}}, {{NB_*}} -> valeurs calculées.
Toutes les citations sont recontrôlées contre les pages avant écriture ; un échec, un renvoi
inconnu ou un gabarit mal résolu arrête la génération (aucun repli silencieux).

Usage : python3 -I generer_rapport.py DOSSIER_SCRIPTS DOSSIER_TEXTE CITATIONS GABARIT SORTIE
"""
import datetime
import importlib.util
import json
import pathlib
import re
import sys

scripts, texte, f_cit, f_gab, f_out = map(pathlib.Path, sys.argv[1:6])
spec = importlib.util.spec_from_file_location("vc", scripts / "verifier_citations.py")
vc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(vc)

cit = {c["id"]: c for c in json.loads(f_cit.read_text(encoding="utf-8"))}
modes = {}
for i, c in cit.items():
    r = vc.controler(texte, c["article"], c["page"], c["citation"])
    if r == "ÉCHEC":
        sys.exit(f"ARRÊT : citation {i} en échec")
    modes[i] = r

gab = f_gab.read_text(encoding="utf-8")
cites_dans_rapport = set(re.findall(r"\{\{([A-Z]+\d+)\}\}", gab))
renvois = set(re.findall(r"\[\[([A-Z]+\d+)\]\]", gab))
inconnus = (cites_dans_rapport | renvois) - set(cit)
if inconnus:
    sys.exit(f"ARRÊT : renvois inconnus {sorted(inconnus)}")

valeurs = {
    "DATE": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M"),
    "NB_CIT": str(len(cit)),
    "NB_MISE": str(sum(1 for m in modes.values() if m == "mise en page")),
    "NB_LECT": str(sum(1 for m in modes.values() if m == "ordre de lecture")),
    "NB_RAPPORT": str(len(cites_dans_rapport | renvois)),
}
out = re.sub(r"\{\{([A-Z]+\d+)\}\}", lambda m: f"⟦{m.group(1)}⟧ « {cit[m.group(1)]['citation']} »", gab)
out = re.sub(r"\[\[([A-Z]+\d+)\]\]", lambda m: f"⟦{m.group(1)}⟧", out)
out = re.sub(r"\{\{(DATE|NB_[A-Z]+)\}\}", lambda m: valeurs[m.group(1)], out)
if "{{" in out or "[[" in out:
    sys.exit("ARRÊT : gabarit mal résolu")

# Contre-vérification : chaque « citation » du rapport, relue dans le rapport, repasse le contrôle de page.
paires = re.findall(r"⟦([A-Z]+\d+)⟧ « (.*?) »", out)
for i, t in paires:
    if t != cit[i]["citation"]:
        sys.exit(f"ARRÊT : citation {i} altérée dans le rapport")
    if vc.controler(texte, cit[i]["article"], cit[i]["page"], t) == "ÉCHEC":
        sys.exit(f"ARRÊT : citation {i} du rapport en échec")
f_out.write_text(out, encoding="utf-8")
print(f"rapport écrit : {f_out} ; {len(paires)} citations recopiées et recontrôlées ; "
      f"{len(cites_dans_rapport | renvois)} identifiants utilisés ; "
      f"{valeurs['NB_CIT']} citations au fichier ({valeurs['NB_MISE']} en mise en page, {valeurs['NB_LECT']} en ordre de lecture)")
