"""Contrôle des citations contre le texte extrait de la page indiquée.

Tolérances : uniquement les blancs (toute suite de blancs, y compris aucune) et les césures
(trait d'union suivi d'un saut de ligne). Aucune autre normalisation (ni casse, ni guillemets,
ni ligatures, ni Unicode).

Texte de référence : la page de rang N du fichier, extraite par `pdftotext -layout` (pNN.txt) ;
si la citation court sur plusieurs lignes d'une page à deux colonnes, la même page extraite en
ordre de lecture (`pdftotext` sans -layout, brut/pNN.txt) est aussi essayée. Le mode qui
réussit est rapporté.

Gardes (R5) : page absente -> erreur ; citation de moins de 15 caractères non blancs -> erreur.
Aucun repli silencieux.

Usage : python3 -I verifier_citations.py DOSSIER_TEXTE FICHIER_CITATIONS.json
"""
import json
import pathlib
import re
import sys

ECART = r"(?:\s*(?:-[ \t]*\r?\n)?\s*)"  # blancs, ou césure (trait d'union + saut de ligne)
MIN_CARACTERES = 15


class ErreurControle(Exception):
    pass


def motif(citation: str) -> re.Pattern:
    caracteres = [c for c in citation if not c.isspace()]
    if len(caracteres) < MIN_CARACTERES:
        raise ErreurControle(f"citation trop courte ({len(caracteres)} caractères non blancs)")
    return re.compile(ECART.join(re.escape(c) for c in caracteres))


def lire_page(dossier: pathlib.Path, article: str, page: int, brut: bool) -> str:
    chemin = dossier / article / ("brut" if brut else "") / f"p{page:02d}.txt"
    if not chemin.is_file():
        raise ErreurControle(f"page absente : {chemin}")
    texte = chemin.read_text(encoding="utf-8")
    if not texte.strip():
        raise ErreurControle(f"page vide : {chemin}")
    return texte


def controler(dossier: pathlib.Path, article: str, page: int, citation: str) -> str:
    """Rend 'mise en page', 'ordre de lecture' ou 'ÉCHEC'. Lève ErreurControle sur entrée invalide."""
    m = motif(citation)
    if m.search(lire_page(dossier, article, page, brut=False)):
        return "mise en page"
    if m.search(lire_page(dossier, article, page, brut=True)):
        return "ordre de lecture"
    return "ÉCHEC"


def main() -> int:
    dossier = pathlib.Path(sys.argv[1])
    citations = json.loads(pathlib.Path(sys.argv[2]).read_text(encoding="utf-8"))
    echecs = 0
    for c in citations:
        try:
            r = controler(dossier, c["article"], c["page"], c["citation"])
        except ErreurControle as e:
            r = f"ERREUR ({e})"
        if r not in ("mise en page", "ordre de lecture"):
            echecs += 1
        print(f"{c['id']}\t{c['article']}\tp.{c['page']}\t{r}")
    print(f"TOTAL\t{len(citations)} citations contrôlées\t{echecs} échec(s)")
    return 1 if echecs else 0


if __name__ == "__main__":
    sys.exit(main())
