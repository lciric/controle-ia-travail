"""Test R5 du contrôle des citations : cas juste, cas altérés, gardes.

Usage : python3 -I tester_controle.py DOSSIER_SCRIPTS DOSSIER_TEXTE
"""
import importlib.util
import pathlib
import sys

spec = importlib.util.spec_from_file_location("vc", pathlib.Path(sys.argv[1]) / "verifier_citations.py")
vc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(vc)
T = pathlib.Path(sys.argv[2])

cas = [
    # (description, article, page, citation, résultat attendu)
    ("juste, une ligne", "2403.17710v5", 6,
     "the injected sequence is appended to the target response as a suffix", "succès"),
    ("altéré : un mot changé (suffix -> prefix)", "2403.17710v5", 6,
     "the injected sequence is appended to the target response as a prefix", "ÉCHEC"),
    ("juste mais mauvaise page (p.7 au lieu de p.6)", "2403.17710v5", 7,
     "the injected sequence is appended to the target response as a suffix", "ÉCHEC"),
    ("juste, sur plusieurs lignes d'une page à deux colonnes", "2505.13348v1", 1,
     "Using the Greedy Coordinate Gradient (GCG) optimization method, we craft adversarial suffixes appended to one of the responses being compared.",
     "succès"),
    ("altéré, sur plusieurs lignes : un mot ajouté", "2505.13348v1", 1,
     "Using the Greedy Coordinate Gradient (GCG) optimization method, we craft adversarial suffixes appended to each of the responses being compared.",
     "ÉCHEC"),
    ("césure réelle tolérée (power-/ful écrit powerful)", "2402.14016v2", 1,
     "Large Language Models (LLMs) are powerful zero-shot assessors", "succès"),
    ("césure : lettre supprimée -> échec", "2402.14016v2", 1,
     "Large Language Models (LLMs) are powerfl zero-shot assessors", "ÉCHEC"),
]
ok = 0
for desc, art, page, cit, attendu in cas:
    r = vc.controler(T, art, page, cit)
    obtenu = "ÉCHEC" if r == "ÉCHEC" else "succès"
    bon = obtenu == attendu
    ok += bon
    print(f"[{'OK' if bon else 'FAUX'}] {desc} : attendu {attendu}, obtenu {obtenu} ({r})")

# Gardes : doivent lever une erreur, jamais réussir en silence
gardes = [
    ("page absente (p.99)", "2403.17710v5", 99, "the injected sequence is appended to the target response"),
    ("citation vide", "2403.17710v5", 6, ""),
    ("citation trop courte", "2403.17710v5", 6, "suffix"),
]
for desc, art, page, cit in gardes:
    try:
        r = vc.controler(T, art, page, cit)
        print(f"[FAUX] garde « {desc} » : pas d'erreur levée (résultat {r})")
    except vc.ErreurControle as e:
        ok += 1
        print(f"[OK] garde « {desc} » : erreur levée ({e})")

total = len(cas) + len(gardes)
print(f"BILAN TEST R5 : {ok}/{total} conformes")
sys.exit(0 if ok == total else 1)
