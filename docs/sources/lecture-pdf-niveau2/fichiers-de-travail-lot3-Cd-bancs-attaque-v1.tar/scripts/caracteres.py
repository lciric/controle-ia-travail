import sys, unicodedata, collections
for path in sys.argv[1:]:
    t = open(path, encoding="utf-8").read()
    c = collections.Counter(ch for ch in t if ord(ch) > 127)
    print("==", path.split("/")[-2])
    print("  ", " | ".join(f"U+{ord(k):04X} {unicodedata.name(k,'?')} x{v}" for k, v in c.most_common(30)))
