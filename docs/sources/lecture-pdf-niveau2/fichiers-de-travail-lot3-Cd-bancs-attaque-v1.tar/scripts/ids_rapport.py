import re, sys
rap = open(sys.argv[1], encoding="utf-8").read()
cit = open(sys.argv[2], encoding="utf-8").read()
ids_cit = set(re.findall(r"^### ([MSC]\d\d) \|", cit, flags=re.M))
ids_rap = set(re.findall(r"\[([MSC]\d\d)\]", rap))
print("identifiants dans le rapport :", len(ids_rap), "; dans citations.txt :", len(ids_cit))
print("absents de citations.txt :", sorted(ids_rap - ids_cit))
print("controles mais non cites dans le rapport :", sorted(ids_cit - ids_rap))
