import sys
path, motif = sys.argv[1], sys.argv[2]
for l in open(path, encoding="utf-8"):
    if motif in l:
        print(ascii(l.rstrip()))
