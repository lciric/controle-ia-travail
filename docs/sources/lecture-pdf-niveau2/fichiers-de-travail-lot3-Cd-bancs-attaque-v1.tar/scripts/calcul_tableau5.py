"""Calcul sur le tableau 5 de MonitoringBench (2605.09684v1, page 23 du fichier).

Lit le texte extrait de la page 23, retrouve pour chaque moniteur les 4 taux de la colonne
« Baseline » (ligne du nom) et les 12 taux « Human Strategies / Recon / Refined » (ligne
au-dessus), puis calcule les moyennes ponderees par n (ligne « n ») et des correlations de
rang de Spearman entre moniteurs. Nature de tous les chiffres produits : calcul.
Usage : python3 -I calcul_tableau5.py CHEMIN/p023.txt
"""
import re
import sys

NOM_LIGNE = re.compile(r"^(?P<nom>[A-Za-z][A-Za-z0-9.\- ]*?)\s+(?P<v>\d+\.\d(?:\s+\d+\.\d){3})\s*$")
NOMBRE = re.compile(r"\d+\.\d")


def rangs(valeurs):
    ordre = sorted(range(len(valeurs)), key=lambda i: valeurs[i])
    r = [0.0] * len(valeurs)
    i = 0
    while i < len(ordre):
        j = i
        while j + 1 < len(ordre) and valeurs[ordre[j + 1]] == valeurs[ordre[i]]:
            j += 1
        moyen = (i + j) / 2.0 + 1.0
        for k in range(i, j + 1):
            r[ordre[k]] = moyen
        i = j + 1
    return r


def pearson(x, y):
    n = len(x)
    mx, my = sum(x) / n, sum(y) / n
    sxy = sum((a - mx) * (b - my) for a, b in zip(x, y))
    sxx = sum((a - mx) ** 2 for a in x)
    syy = sum((b - my) ** 2 for b in y)
    return sxy / (sxx * syy) ** 0.5


def spearman(x, y):
    return pearson(rangs(x), rangs(y))


def main():
    lignes = open(sys.argv[1], encoding="utf-8").read().splitlines()
    n = None
    for l in lignes:
        m = re.match(r"^n\s+((?:\d+\s+){15}\d+)\s*$", l.strip())
        if m:
            n = [int(x) for x in m.group(1).split()]
    if n is None or len(n) != 16:
        sys.exit("ligne n introuvable : echec")
    moniteurs = []
    for i, l in enumerate(lignes):
        m = NOM_LIGNE.match(l.strip())
        if not m or m.group("nom") == "n":
            continue
        base = [float(x) for x in m.group("v").split()]
        dessus = [float(x) for x in NOMBRE.findall(lignes[i - 1])]
        if len(dessus) != 12:
            sys.exit("ligne au-dessus de %s mal formee : echec" % m.group("nom"))
        moniteurs.append((m.group("nom"), base, dessus[0:4], dessus[4:8], dessus[8:12]))
    if len(moniteurs) != 13:
        sys.exit("13 moniteurs attendus, %d lus : echec" % len(moniteurs))

    def pond(vals, poids):
        return sum(v * w for v, w in zip(vals, poids)) / sum(poids)

    lignes_sortie = []
    tab = []
    for nom, b, h, r, f in moniteurs:
        wb, wh, wr, wf = pond(b, n[0:4]), pond(h, n[4:8]), pond(r, n[8:12]), pond(f, n[12:16])
        tab.append((nom, wb, wh, wr, wf))
        lignes_sortie.append("%-14s base=%5.1f humain=%5.1f recon=%5.1f affine=%5.1f baisse=%5.1f" % (nom, wb, wh, wr, wf, wb - wf))
    print("n =", n)
    print("\n".join(lignes_sortie))
    base = [t[1] for t in tab]
    aff = [t[4] for t in tab]
    baisse = [t[1] - t[4] for t in tab]
    print("Spearman(base, affine) sur 13 moniteurs = %.3f" % spearman(base, aff))
    print("Spearman(base, baisse base-affine) = %.3f" % spearman(base, baisse))
    rel = [t[4] / t[1] if t[1] > 0 else float("nan") for t in tab]
    garde = [i for i in range(13) if tab[i][1] >= 20.0]
    print("moniteurs avec base >= 20 %% : %s" % ", ".join(tab[i][0] for i in garde))
    print("Spearman(base, affine) sur ces %d moniteurs = %.3f" % (len(garde), spearman([base[i] for i in garde], [aff[i] for i in garde])))
    print("Spearman(base, rapport affine/base) sur ces %d moniteurs = %.3f" % (len(garde), spearman([base[i] for i in garde], [rel[i] for i in garde])))


if __name__ == "__main__":
    main()
