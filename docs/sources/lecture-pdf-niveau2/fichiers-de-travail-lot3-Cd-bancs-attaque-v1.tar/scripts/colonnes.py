import re, sys
path = sys.argv[1]; motifs = sys.argv[2:]
for l in open(path, encoding="utf-8"):
    if any(m in l for m in motifs):
        nums = [(m.start(), m.end() - 1, m.group()) for m in re.finditer(r"\d+%?", l)]
        print("%-45s %s" % (l.strip()[:45], " ".join("%s@%d-%d" % (g, s, e) for s, e, g in nums if s > 40)))
