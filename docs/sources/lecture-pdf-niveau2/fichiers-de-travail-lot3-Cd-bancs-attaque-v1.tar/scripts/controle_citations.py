"""Controle des citations contre le texte extrait page par page (pdftotext -layout).

Tolerances admises, et seulement elles :
  - les blancs (espaces, tabulations, retours a la ligne) sont ignores des deux cotes ;
  - les cesures de fin de ligne : un trait d'union suivi d'un retour a la ligne peut etre
    present ou absent dans la citation ;
  - la normalisation canonique Unicode NFC (e + point suscrit combinant == e point suscrit),
    qui ne change pas le texte.
Tout le reste (mots, chiffres, ponctuation, guillemets typographiques) doit etre identique.

Usage :
  python3 -I controle_citations.py DOSSIER_TEXTES FICHIER_CITATIONS
Format du fichier de citations : blocs commencant par une ligne
  ### identifiant | dossier_article | page
suivie du texte de la citation (une ou plusieurs lignes).
Code de sortie : 0 si toutes les citations sont trouvees, 1 sinon (aucun repli silencieux).
"""
import os
import re
import sys
import unicodedata

CESURE = "\x01"


def squelette_page(texte):
    texte = unicodedata.normalize("NFC", texte)
    texte = re.sub(r"-[ \t]*\r?\n", CESURE, texte)  # trait d'union de fin de ligne
    return re.sub(r"\s+", "", texte)


def motif_citation(citation):
    citation = unicodedata.normalize("NFC", citation)
    caracteres = re.sub(r"\s+", "", citation)
    if not caracteres:
        raise ValueError("citation vide")
    morceaux = []
    for ch in caracteres:
        if ch == "-":
            morceaux.append("(?:-|" + CESURE + ")")
        else:
            morceaux.append(re.escape(ch))
    # une cesure (trait d'union de fin de ligne) peut s'intercaler entre deux caracteres
    return re.compile((CESURE + "?").join(morceaux))


def lire_citations(chemin):
    blocs = []
    courant = None
    with open(chemin, encoding="utf-8") as f:
        for ligne in f:
            if ligne.startswith("### "):
                if courant:
                    blocs.append(courant)
                entete = [x.strip() for x in ligne[4:].split("|")]
                if len(entete) != 3:
                    raise ValueError("en-tete mal forme : " + ligne)
                courant = {"id": entete[0], "article": entete[1], "page": int(entete[2]), "texte": ""}
            elif courant is not None:
                courant["texte"] += ligne
    if courant:
        blocs.append(courant)
    return blocs


def controler(dossier_textes, citation):
    chemin = os.path.join(dossier_textes, citation["article"], "p%03d.txt" % citation["page"])
    if not os.path.isfile(chemin):
        return False, "page absente : " + chemin
    with open(chemin, encoding="utf-8") as f:
        page = squelette_page(f.read())
    if not page:
        return False, "page vide : " + chemin
    if motif_citation(citation["texte"]).search(page):
        return True, "trouvee"
    return False, "introuvable sur la page indiquee"


def main():
    dossier_textes, fichier = sys.argv[1], sys.argv[2]
    citations = lire_citations(fichier)
    if not citations:
        print("AUCUNE CITATION LUE : echec")
        sys.exit(1)
    ids = [c["id"] for c in citations]
    doublons = sorted({i for i in ids if ids.count(i) > 1})
    if doublons:
        print("IDENTIFIANTS EN DOUBLE :", doublons)
        sys.exit(1)
    echecs = []
    for c in citations:
        ok, raison = controler(dossier_textes, c)
        print("%-5s %-8s %s p%-3d %s" % ("OK" if ok else "ECHEC", c["id"], c["article"], c["page"], raison))
        if not ok:
            echecs.append(c["id"])
    print("TOTAL=%d TROUVEES=%d ECHECS=%d %s" % (len(citations), len(citations) - len(echecs), len(echecs), " ".join(echecs)))
    sys.exit(1 if echecs else 0)


if __name__ == "__main__":
    main()
