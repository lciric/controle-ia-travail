"""Contre-vérification mécanique de la dérivation des gabarits de TRACE pour l'environnement (a).

Écrit par le contre-vérificateur (pas par l'auteur de la dérivation). Bibliothèque standard seulement ; à lancer avec
`python3 -I`. Lecture seule : n'écrit rien (sortie sur la sortie standard).

Usage : python3 -I verifier_derivation.py DOSSIER_TRANSCRIPTION DOSSIER_DERIVEES
  DOSSIER_TRANSCRIPTION : .../docs/sources/invites-2606.07054-v1  (contient invites/ et index.json)
  DOSSIER_DERIVEES      : .../trace-derivees/derivees              (gabarits dérivés, differentiel-v1.md, index-v1.json,
                                                                    scripts/deriver-v1.py)

Contrôles :
  1. empreintes : originaux (compagnon .sha256 et index de la transcription), dérivés (index-v1.json, differentiel) ;
  2. octets : UTF-8 strict, sans BOM, sans CR, une seule fin de ligne finale, sans espace de fin de ligne, sans
     tabulation ni caractère de contrôle, sans double espace ;
  3. lignes : différentiel ligne à ligne (difflib.SequenceMatcher, sans « autojunk ») ; l'ensemble des remplacements
     réels doit être égal, au caractère près, à celui que déclare differentiel-v1.md ET à celui du script
     deriver-v1.py (lu par ast, sans l'exécuter) ; toute autre ligne doit être identique octet pour octet ;
  4. dans chaque ligne changée : préfixe et suffixe communs, segment changé (au caractère), inventaire des caractères
     non ASCII (’ – • …) avant et après ;
  5. champs entre accolades : multiensemble des noms, original contre dérivé ;
  6. formats de sortie : JSON d'exemple de B1 et B4 (clés, imbrication, types), « Return plain text only. » de B3 ;
  7. différentiels unifiés recopiés dans differentiel-v1.md contre ceux que recalcule difflib.
Code de sortie 0 seulement si tous les contrôles mécaniques sont conformes.
"""
import ast
import collections
import difflib
import hashlib
import json
import pathlib
import re
import sys
import unicodedata

GARDES = ["B1", "B3-1", "B3-2", "B3-4", "B4"]
RETIRES = ["B2", "B3-3"]
CHAMP = re.compile(r"\{([a-z_]+)\}")       # même motif que trace_lite._CHAMP
ECHECS = []


def echec(msg):
    ECHECS.append(msg)
    print("  ÉCHEC : " + msg)


def ok(msg):
    print("  ok : " + msg)


def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def compagnon(p: pathlib.Path):
    c = pathlib.Path(str(p) + ".sha256")
    if not c.is_file():
        return None
    l = [x for x in c.read_text(encoding="utf-8").splitlines() if x.strip()]
    return l[0].split()[0] if len(l) == 1 else "ILLISIBLE"


def controle_octets(nom: str, b: bytes):
    try:
        t = b.decode("utf-8", errors="strict")
    except UnicodeDecodeError as e:
        echec(f"{nom} : UTF-8 invalide ({e})")
        return None
    pb = []
    if t.startswith("﻿"):
        pb.append("BOM")
    if "\r" in t:
        pb.append("CR")
    if not t.endswith("\n") or t.endswith("\n\n"):
        pb.append("fin de ligne finale non unique")
    for k, l in enumerate(t[:-1].split("\n"), 1):
        if l != l.rstrip(" \t"):
            pb.append(f"espace de fin à la ligne {k}")
        if "\t" in l:
            pb.append(f"tabulation ligne {k}")
        if "  " in l:
            pb.append(f"double espace ligne {k}")
        if any(unicodedata.category(c) in ("Cc", "Cf") for c in l):
            pb.append(f"caractère de contrôle ou de format ligne {k}")
        if any(c in l for c in "   ­"):
            pb.append(f"espace insécable ou trait conditionnel ligne {k}")
    if pb:
        echec(f"{nom} : " + ", ".join(pb))
    else:
        ok(f"{nom} : UTF-8 strict, sans BOM ni CR, fin de ligne finale unique, ni espace de fin, ni tabulation, "
           f"ni double espace, ni caractère de contrôle")
    return t


def non_ascii(s: str) -> collections.Counter:
    return collections.Counter(c for c in s if ord(c) > 127)


def lire_differentiel(texte: str) -> dict:
    """{gabarit: [(ancienne, nouvelle ou None)]} et {gabarit: (sha_orig, sha_derive)} et {gabarit: diff unifié}."""
    decl, shas, unifies = {}, {}, {}
    sections = re.split(r"^## (\S+)\n", texte, flags=re.M)
    for g, corps in zip(sections[1::2], sections[2::2]):
        m = re.search(r"\(sha256 ([0-9a-f]{64})\) ; dérivé : `[^`]+` \(sha256 ([0-9a-f]{64})\)", corps)
        shas[g] = (m.group(1), m.group(2)) if m else None
        paires = []
        for ch in re.split(r"^### Changement \d+\n", corps, flags=re.M)[1:]:
            a = re.search(r"Ligne d'origine :\n\n```text\n(.*?)\n```", ch, flags=re.S)
            n = re.search(r"Ligne dérivée :\n\n```text\n(.*?)\n```", ch, flags=re.S)
            supp = "Ligne supprimée." in ch
            if a is None or (n is None and not supp):
                paires.append(("ILLISIBLE", "ILLISIBLE"))
                continue
            paires.append((a.group(1), None if supp and n is None else n.group(1)))
        decl[g] = paires
        u = re.search(r"Différentiel unifié :\n\n```diff\n(.*?)\n```", corps, flags=re.S)
        unifies[g] = u.group(1) if u else None
    return decl, shas, unifies


def lire_script(chemin: pathlib.Path) -> dict:
    """REMPLACEMENTS de deriver-v1.py, lus par ast (le script n'est pas exécuté)."""
    arbre = ast.parse(chemin.read_text(encoding="utf-8"))
    for n in arbre.body:
        if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "REMPLACEMENTS" for t in n.targets):
            val = ast.literal_eval(n.value)
            out = collections.defaultdict(list)
            for g, a, nv, _ in val:
                out[g].append((a, nv))
            return dict(out)
    raise SystemExit("REMPLACEMENTS introuvable dans le script")


def signature(o):
    """Structure d'une valeur JSON : clés et types, sans les valeurs."""
    if isinstance(o, dict):
        return {k: signature(v) for k, v in o.items()}
    if isinstance(o, list):
        return [signature(v) for v in o]
    return type(o).__name__


def json_exemple(t: str):
    m = re.search(r"Return ONLY valid JSON: (.*)$", t, flags=re.M)
    if m is None:
        return None, None
    return m.group(1), json.loads(m.group(1))


def main():
    trans, der = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
    idx_trans = {x["id"]: x for x in json.loads((trans / "index.json").read_text(encoding="utf-8"))["invites"]}
    idx_der = json.loads((der / "index-v1.json").read_text(encoding="utf-8"))["gabarits"]
    decl, shas_diff, unifies = lire_differentiel((der / "differentiel-v1.md").read_text(encoding="utf-8"))
    script = lire_script(der / "scripts" / "deriver-v1.py")

    print("== 0. Gabarits gardés et retirés")
    if sorted(idx_der) == sorted(GARDES):
        ok(f"index-v1.json porte exactement {GARDES}")
    else:
        echec(f"index-v1.json porte {sorted(idx_der)} au lieu de {GARDES}")
    for g in RETIRES:
        if (der / f"{g}-env-a-v1.txt").exists():
            echec(f"{g} retiré mais un dérivé existe")
    ok(f"retirés : {RETIRES} (aucun fichier dérivé)")

    for g in GARDES:
        print(f"\n== {g}")
        po, pd = trans / "invites" / f"{g}.txt", der / f"{g}-env-a-v1.txt"
        bo, bd = po.read_bytes(), pd.read_bytes()
        ho, hd = sha(bo), sha(bd)
        # 1. empreintes
        verifs = {"compagnon de l'original": compagnon(po) == ho,
                  "index de la transcription": idx_trans[g]["sha256"] == ho,
                  "index-v1.json (original)": idx_der[g]["sha256_original"] == ho,
                  "index-v1.json (dérivé)": idx_der[g]["sha256_derive"] == hd,
                  "differentiel-v1.md (original, dérivé)": shas_diff.get(g) == (ho, hd)}
        for k, v in verifs.items():
            (ok if v else echec)(f"empreinte — {k}")
        print(f"  original {ho}\n  dérivé   {hd}")
        # 2. octets
        to = controle_octets(f"{g} original", bo)
        td = controle_octets(f"{g} dérivé", bd)
        if to is None or td is None:
            continue
        lo, ld = to[:-1].split("\n"), td[:-1].split("\n")
        # 3. lignes
        sm = difflib.SequenceMatcher(None, lo, ld, autojunk=False)
        reels, identiques = [], 0
        for op, i1, i2, j1, j2 in sm.get_opcodes():
            if op == "equal":
                identiques += i2 - i1
                for a, b in zip(lo[i1:i2], ld[j1:j2]):
                    if a.encode("utf-8") != b.encode("utf-8"):
                        echec("ligne « égale » différente en octets (impossible)")
            elif op == "replace":
                if i2 - i1 != j2 - j1:
                    echec(f"remplacement {i2 - i1} → {j2 - j1} lignes (lignes ajoutées ou fusionnées)")
                for a, b in zip(lo[i1:i2], ld[j1:j2]):
                    reels.append((a, b))
            elif op == "delete":
                for a in lo[i1:i2]:
                    reels.append((a, None))
            elif op == "insert":
                for b in ld[j1:j2]:
                    reels.append((None, b))
                    echec(f"ligne insérée sans ligne d'origine : {b[:60]!r}")
        print(f"  lignes : original {len(lo)}, dérivé {len(ld)}, identiques {identiques}, changées {len(reels)}")
        d, s = decl.get(g, []), script.get(g, [])
        (ok if sorted(map(repr, reels)) == sorted(map(repr, d)) else echec)(
            "changements réels = changements déclarés dans differentiel-v1.md (au caractère près)")
        (ok if sorted(map(repr, reels)) == sorted(map(repr, s)) else echec)(
            "changements réels = REMPLACEMENTS de deriver-v1.py (au caractère près)")
        ln = idx_der[g]
        (ok if (ln["lignes_changees"], ln["lignes_supprimees"]) ==
            (sum(b is not None for _, b in reels), sum(b is None for _, b in reels)) else echec)(
            f"décomptes de index-v1.json ({ln['lignes_changees']} changées, {ln['lignes_supprimees']} supprimées)")
        # 4. détail de chaque ligne changée
        for a, b in reels:
            num = lo.index(a) + 1 if a in lo else None
            if b is None:
                print(f"  - ligne {num} SUPPRIMÉE : {a!r}")
                continue
            p = 0
            while p < min(len(a), len(b)) and a[p] == b[p]:
                p += 1
            q = 0
            while q < min(len(a), len(b)) - p and a[-1 - q] == b[-1 - q]:
                q += 1
            print(f"  - ligne {num} : préfixe commun {p} car., suffixe commun {q} car.")
            print(f"      retiré : {a[p:len(a) - q]!r}")
            print(f"      ajouté : {b[p:len(b) - q]!r}")
            na, nb = non_ascii(a), non_ascii(b)
            perdus = {c: na[c] - nb.get(c, 0) for c in na if na[c] > nb.get(c, 0)}
            gagnes = {c: nb[c] - na.get(c, 0) for c in nb if nb[c] > na.get(c, 0)}
            print(f"      non ASCII avant {dict(na)} ; après {dict(nb)}"
                  + (f" ; PERDUS {perdus}" if perdus else "") + (f" ; GAGNÉS {gagnes}" if gagnes else ""))
            if "'" in b[p:len(b) - q] or '"' in b[p:len(b) - q] and '"' not in a[p:len(a) - q]:
                print("      remarque : apostrophe ou guillemet droit dans le segment ajouté")
        # 5. champs
        co, cd = collections.Counter(CHAMP.findall(to)), collections.Counter(CHAMP.findall(td))
        (ok if co == cd else echec)(f"champs (multiensemble) : original {dict(co)} ; dérivé {dict(cd)}")
        # 6. formats de sortie
        jo, jd = json_exemple(to), json_exemple(td)
        if jo[0] is not None or jd[0] is not None:
            so, sd = signature(jo[1]), signature(jd[1])
            (ok if so == sd else echec)(f"structure JSON identique : {json.dumps(sd, ensure_ascii=False)}")
            if jo[1] != jd[1]:
                print(f"  valeurs d'exemple : original {json.dumps(jo[1], ensure_ascii=False)}\n"
                      f"                     dérivé   {json.dumps(jd[1], ensure_ascii=False)}")
            else:
                ok("valeurs d'exemple identiques")
        if g.startswith("B3"):
            (ok if lo[-1] == ld[-1] == "Return plain text only." else echec)("dernière ligne « Return plain text only. »")
        # 7. différentiel unifié recopié
        ud = "\n".join(difflib.unified_diff(to.splitlines(), td.splitlines(), fromfile=f"invites/{g}.txt",
                                            tofile=f"derivees/{g}-env-a-v1.txt", lineterm="", n=0))
        (ok if (ud or "(vide)") == unifies.get(g) else echec)("différentiel unifié de differentiel-v1.md recalculé à l'identique")

    print("\n== BILAN : " + ("CONFORME (contrôles mécaniques)" if not ECHECS else f"{len(ECHECS)} ÉCHEC(S)"))
    for e in ECHECS:
        print("  - " + e)
    return 0 if not ECHECS else 1


if __name__ == "__main__":
    sys.exit(main())
