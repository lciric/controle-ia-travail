# Contrôle indépendant : tables 1 (p. 6) et 5 (p. 17) de 2606.07054v1
t1 = {  # tâche: (bénignes, malveillantes)
 "SSN":(27,27),"Bank":(9,26),"AA":(14,33),"Spam":(34,25),"Election":(9,27),
 "Jira":(24,27),"API":(29,32),"Exp":(9,24),"Perf":(24,28),"Charity":(10,25)}
t5 = {  # TRACE (prec, rec, f1)
 "SSN":(0.481,0.926,0.633),"Bank":(0.719,0.885,0.793),"AA":(0.750,0.909,0.822),
 "Spam":(0.545,0.960,0.696),"Election":(0.733,0.407,0.524),"Jira":(0.543,0.704,0.613),
 "API":(0.554,0.969,0.705),"Exp":(0.679,0.792,0.731),"Perf":(0.634,0.929,0.754),
 "Charity":(0.774,0.960,0.857)}
seq = {"SSN":(1.000,0.778),"Bank":(1.000,0.808),"AA":(1.000,0.758),"Spam":(0.590,0.920),
 "Election":(1.000,0.074),"Jira":(1.000,0.481),"API":(0.824,0.438),"Exp":(0.941,0.667),
 "Perf":(0.889,0.286),"Charity":(1.000,0.640)}
TP=FP=0; B=M=0; fl=[]; recs=[]; f1s=[]
for k,(b,m) in t1.items():
    p,r,f = t5[k]
    tp = round(r*m); fp = round(tp*(1-p)/p)
    # contrôle: précision reconstruite
    pr = tp/(tp+fp) if tp+fp else 0
    assert abs(pr-p) < 0.0006, (k,pr,p)
    TP+=tp; FP+=fp; B+=b; M+=m; recs.append(r); f1s.append(f)
    pa = m/(m+b); fl.append(2*pa/(1+pa))
    print(f"{k:9s} TP={tp:2d}/{m:2d} FP={fp:2d}/{b:2d} ({fp/b:.0%})")
P=TP/(TP+FP); R=TP/M
print("Total FP", FP, "/", B, "=", round(FP/B,4))
print("TRACE poolé: rappel", round(R,4), "précision", round(P,4), "F1", round(2*P*R/(P+R),4))
print("TRACE moyenne par tâche: rappel", round(sum(recs)/10,4), "F1", round(sum(f1s)/10,4))
pa=M/(M+B); print("Tout signaler poolé F1", round(2*pa/(1+pa),4), "; moyenne par tâche", round(sum(fl)/10,4))
# séquentiel poolé
tp=fp=0
for k,(b,m) in t1.items():
    p,r = seq[k]; t=round(r*m); f=round(t*(1-p)/p); tp+=t; fp+=f
print("Séquentiel: rappel poolé", round(tp/M,4), "FP", fp, "/", B, round(fp/B,4))
