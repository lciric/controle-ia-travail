# Contrôle indépendant (Python pur, sans numpy) de fuite_monitor_A.py :
# copule gaussienne AR(1), marginale Beta(a,b) du dépôt, T=300, départ stationnaire.
import math, random, bisect, sys
a, b = 2.0500937599999993, 5.118066239999998
T = 300
N = int(sys.argv[1]) if len(sys.argv) > 1 else 20000
rng = random.Random(int(sys.argv[2]) if len(sys.argv) > 2 else 4100)
# Table de la fonction de répartition de Beta(a,b) (trapèzes sur grille fine) puis inversion par interpolation
G = 200000
lB = math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)
xs = [i / G for i in range(G + 1)]
dens = [0.0] + [math.exp((a-1)*math.log(x) + (b-1)*math.log(1-x) - lB) for x in xs[1:-1]] + [0.0]
cdf = [0.0]
for i in range(1, G + 1):
    cdf.append(cdf[-1] + 0.5 * (dens[i] + dens[i-1]) / G)
tot = cdf[-1]; cdf = [c / tot for c in cdf]
def ppf(u):
    j = bisect.bisect_left(cdf, u)
    if j <= 0: return 0.0
    if j > G: return 1.0
    c0, c1 = cdf[j-1], cdf[j]
    return xs[j-1] + (u - c0) / (c1 - c0) * (xs[j] - xs[j-1]) if c1 > c0 else xs[j]
SQ2 = math.sqrt(2.0)
def traj_stats(phi):
    s = math.sqrt(1 - phi * phi); g = rng.gauss
    z = g(0, 1); tot = 0.0; mx = -1.0
    for t in range(T):
        if t: z = phi * z + s * g(0, 1)
        u = 0.5 * (1 + math.erf(z / SQ2)); u = min(max(u, 1e-7), 1 - 1e-7)
        v = ppf(u); tot += v
        if v > mx: mx = v
    return tot / T, mx
def run(phi):
    m, x = [], []
    for _ in range(N):
        a1, a2 = traj_stats(phi); m.append(a1); x.append(a2)
    return m, x
def auc(xb, xa):
    allv = sorted([(v, 0) for v in xb] + [(v, 1) for v in xa])
    # rangs moyens (ex aequo)
    ranks = [0.0] * len(allv); i = 0
    while i < len(allv):
        j = i
        while j + 1 < len(allv) and allv[j+1][0] == allv[i][0]: j += 1
        r = (i + j) / 2 + 1
        for k in range(i, j + 1): ranks[k] = r
        i = j + 1
    ra = sum(r for r, (_, lab) in zip(ranks, allv) if lab == 1)
    n1, n0 = len(xa), len(xb)
    return (ra - n1 * (n1 + 1) / 2) / (n0 * n1)
def q(v, p):
    w = sorted(v); k = p * (len(w) - 1); f = math.floor(k); c = min(f + 1, len(w) - 1)
    return w[f] + (k - f) * (w[c] - w[f])
mb, xb = run(0.5)
for phi in [0.59, 0.9]:
    ma, xa = run(phi)
    thm = q(mb, 0.99); thx = q(xb, 0.99)
    pm = sum(v >= thm for v in ma) / N; px = sum(v >= thx for v in xa) / N
    print(f"phi_att={phi} (dphi={phi-0.5:.2f}) N={N}+{N}: moyenne puissance@1%={pm:.4f} AUC={auc(mb, ma):.3f} | max AUC={auc(xb, xa):.3f} puissance@1%={px:.4f}", flush=True)
