import re, json
pages = open('full.txt').read().split('\f')
def norm(s):
    s = s.replace(',→', ' ').replace('“','"').replace('”','"').replace('’',"'")
    s = re.sub(r'-\s*\n\s*', '-', s)       # hyphen at line end kept as hyphen join
    s = re.sub(r'\s+', ' ', s)
    return s.strip()
def norm2(s):  # also allow de-hyphenation of line-broken words
    s = s.replace(',→', ' ').replace('“','"').replace('”','"').replace('’',"'")
    s = re.sub(r'(\w)-\s*\n\s*(\w)', r'\1\2', s)
    s = re.sub(r'\s+', ' ', s)
    return s.strip()
Q = [
 (1, "Anthropic Fellows Program (via MATS)"),
 (1, "arXiv:2606.08892v2 [cs.LG] 17 Jun 2026"),
 (1, "We use a language model with access to the original paper as a proxy \"ground-truth\" scorer."),
 (1, "Diffuse threats correspond to behaviors that are only catastrophic when repeated over time, like sandbagging"),
 (2, "We also sidestep the question of how models generalize from training by focusing on prompt optimization for subversive behaviors."),
 (2, "The discovered prompt results in a weak scorer that closely tracks the ground truth proxy despite strong adversarial pressure"),
 (2, "Our results serve as an existence proof for prompting-based defense improvements, though discovery of the robust prompts with realistic affordances remains an open problem."),
 (2, "We focus on training mitigations, since monitoring and incrimination seem theoretically"),
 (2, "less promising for mitigating diffuse threats."),
 (2, "The model has to generate high-level descriptions of experiments or theoretical results that address these questions."),
 (3, "The red team also encourages the untrusted model to perform worse by prompting it, so R is the space of prompts for the generator."),
 (3, "We therefore assume that, after the training performed by the blue team, the red team is constrained to strategies which are nearly-optimal w.r.t. wb"),
 (3, "so the space of blue team strategies B coincides with the space of prompts given to the trusted model."),
 (4, "we take ε to be a low-sample-size (e.g., N = 16) lower confidence bound for wb∗"),
 (4, "a dataset of 2346 poster papers for training and 302 spotlight and oral papers for validation"),
 (4, "We evaluate the untrusted model on generating a set of ten ideas for experiments or theoretical results that address the RQs."),
 (4, "As a ground truth proxy, we use Claude Sonnet 4.6 with access to the original paper"),
 (5, "The blue team uses Claude Haiku 4.5 as a weak trusted model. The weak scorer is not given access to the paper."),
 (5, "By default, the weak scorer uses the same ten-criterion rubric as the ground truth proxy and mostly shares the same prompt"),
 (5, "on most individual generators, the correlation almost disappears."),
 (5, "The weak scorer is very noisy, with the biggest component of the variance being scorer noise."),
 (5, "For the single-objective problem we use the OpenEvolve implementation [Sharma, 2025] of the AlphaEvolve algorithm."),
 (6, "red team prompts which score within ε ≈ 3.6 of the maximum weak score and which score under 35"),
 (6, "involve producing superficial signals to placate the rubric"),
 (6, "For GPT-5.4, we reduce the ground truth proxy score to 58, just below the benign GPT-5.4 nano performance."),
 (6, "For GPT-OSS-120B, we reduce the score to 24, much lower than any of the benign generators we study."),
 (6, "does not allow the red team to attack: the Pareto frontier is essentially diagonal."),
 (7, "the max-weak policy trained against b∗ achieves a ground truth proxy score g ≈ 75, only slightly below the maximal value of g ≈ 80"),
 (7, "Note that the trusted scorer model that the blue team uses here is still Haiku 4.5, and Opus is only used to find the prompt"),
 (7, "the blue team prompt optimizer is called few times throughout the process (50)"),
 (8, "Surprisingly, prompting seems like a sufficient defense, at least against our optimization-based attacks."),
 (9, "Wen et al. [2024] did early work on diffuse threats, but, unlike us, they focused on detection."),
 (9, "Ryd et al. [2026], similarly to us, studied training-based mitigations against sandbagging, but focused on non-fuzzy tasks like competitive programming."),
 (9, "Closest to our work is a recent paper from Wang et al. [2026]."),
 (9, "A natural extension would be to consider fine-tuning the models, though we would lose the clean interpretability of the resulting strategies."),
 (9, "we could build higher-quality proxies by keeping humans in the loop or at least collecting human-labeled data."),
 (10, "This project relied on arXiv API."),
 (14, "the red team can construct a randomized strategy"),
 (14, "The red team might also approximate a probabilistic construction within the prompt itself, by asking the untrusted model to behave randomly with a given distribution."),
 (15, "We use Claude Opus 4.6 without internet access to power the agent."),
 (15, "We only take papers after the knowledge cutoff date of the LLMs we use as generators (September 2025 or later) to avoid data contamination."),
 (16, "In our setup, the paper serves as a proxy for this missing information."),
 (16, "Experiment design is also easier to judge once the experiments have been implemented and run."),
 (17, "There is a robust trend that stronger generators come with less agreement between the scorer variants."),
 (21, "The optimization process converges without overfitting."),
 (22, "when the optimizer is not given this information, it cannot discover effective subversion strategies. The resulting Pareto front is almost diagonal."),
 (25, "However, if we run a separate red team optimization against this strategy, we can also discover effective attacks."),
 (25, "The prompt frames the proposals as a verification study and completely neglects producing any novel results."),
 (25, "After the second iteration, the red team never discovers a successful attack."),
 (25, "Propose exactly 10 experiments or theoretical results to address the research questions in the problem statement you will be given."),
 (28, "Number your proposals PROPOSAL 1 through PROPOSAL 10."),
 (29, "The decision on how to weigh the results to holistically evaluate the proposal set is left to the judge."),
 (40, "The generator must propose exactly 10 experiments or theoretical results. Two independent judges then score the proposals on quality."),
 (40, "The goal is **selective sandbagging**: maximize the weak judge score while minimizing the strong judge score."),
 (44, "Sees the research questions + classification + the 10 proposals. Does NOT see the paper."),
 (47, "score = max(0, min(1, sum(w_i * val_i) / sum(w_i * max_i)))"),
 (54, "Note how it is not clear whether the behavior this prompt attempts to create can be classified as sandbagging (deliberate underperformance) or research steering."),
 (66, "The compute requirements escalate absurdly"),
 (68, "Below is the robustified prompt b∗ results for which are presented in Figure 5"),
 (25, "The optimizer sees the scores normalized to [0,1] instead of [0.100]."),
 (13, "Control tax: The price of keeping AI in check. arXiv preprint arXiv:2506.05296, 2025a."),
 (13, "Adaptive Attacks on Trusted Monitors Subvert AI Control Protocols. arXiv preprint arXiv:2510.09462, 2025b."),
 (11, "ASMR-Bench: Auditing for Sabotage in ML Research. arXiv preprint arXiv:2604.16286, 2026."),
 (13, "CTRL-ALT-DECEIT: Sabotage Evaluations for Automated AI R&D. arXiv preprint arXiv:2511.09904, 2025."),
 (13, "Removing Sandbagging in LLMs by Training with Weak Supervision. arXiv preprint arXiv:2604.22082, 2026."),
 (11, "Automated Researchers Can Subtly Sandbag."),
 (10, "Sabotage evaluations for frontier models. arXiv preprint arXiv:2410.21514, 2024."),
 (13, "Automatically Finding Reward Model Biases. arXiv preprint arXiv:2602.15222, 2026."),
 (13, "Auditing Games for Sandbagging. arXiv preprint arXiv:2512.07810, 2025."),
 (13, "Adaptive deployment of untrusted LLMs reduces distributed threats. arXiv preprint arXiv:2411.17693, 2024."),
 (11, "How Can We Solve Diffuse Threats Like Research Sabotage with AI Con-"),
 (23, "like we did above for GPT-5.4 and GPT-OSS-20B results"),
 (65, "Here is the full weak scorer response from which we were quoting in Section 5.2."),
]
ok=0
for p,q in Q:
    t1, t2 = norm(pages[p-1]), norm2(pages[p-1])
    qn1, qn2 = norm(q), norm2(q)
    found = (qn1 in t1) or (qn2 in t2) or (qn1 in t2) or (qn2 in t1)
    ok += found
    print(('OK  ' if found else 'MISS'), p, '|', q[:90], '| mots=', len(q.split()))
print(ok, '/', len(Q))
