import sys
fn = sys.argv[1]
out = sys.argv[2]
txt = open(fn, encoding='utf-8').read()
pages = txt.split('\f')
with open(out, 'w', encoding='utf-8') as f:
    for i, p in enumerate(pages, 1):
        if not p.strip():
            continue
        f.write(f"\n=================== PAGE {i} ===================\n")
        f.write(p)
print(fn, len(pages))
