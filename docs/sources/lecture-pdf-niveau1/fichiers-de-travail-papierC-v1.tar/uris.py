import re, zlib, sys
fn = sys.argv[1]
data = open(fn,'rb').read()
chunks = [data]
for m in re.finditer(rb'stream\r?\n', data):
    start = m.end()
    end = data.find(b'endstream', start)
    if end < 0: continue
    raw = data[start:end]
    for cand in (raw, raw.rstrip(b'\r\n')):
        try:
            chunks.append(zlib.decompress(cand)); break
        except Exception:
            try:
                d = zlib.decompressobj(); chunks.append(d.decompress(cand)); break
            except Exception:
                pass
uris = set()
for c in chunks:
    for u in re.findall(rb'/URI\s*\((.*?)\)', c, flags=re.S):
        uris.add(u.decode('latin-1'))
for u in sorted(uris):
    print(u)
