import sys
f=sys.argv[1]; a=int(sys.argv[2]); b=int(sys.argv[3]) if len(sys.argv)>3 else a
t=open(f).read().split('\f')
for n in range(a,b+1):
    print(f"=================== PAGE {n} ===================")
    print(t[n-1])
