# Que mesure "KS = 0,013" ? (1) KS empirique par trajectoire ; (2) plancher de bruit du KS a 2 echantillons
# du depot (scores pooles vs 5000 tirages Beta) ; (3) "90e centile benin-vs-benin sur 500 paires" (T = 300).
import numpy as np
from scipy import stats
a, b = 2.0500937599999993, 5.118066239999998
T = 300
rng = np.random.default_rng(np.random.SeedSequence(27182818))
def sample(n, phi):
    z = np.empty((n, T)); z[:, 0] = rng.standard_normal(n)
    s = np.sqrt(1 - phi**2); e = rng.standard_normal((n, T))
    for t in range(1, T):
        z[:, t] = phi * z[:, t-1] + s * e[:, t]
    u = np.clip(stats.norm.cdf(z), 1e-7, 1 - 1e-7)
    return np.clip(stats.beta.ppf(u, a, b), 0, 1)
F = lambda x: stats.beta.cdf(x, a, b)
# (1) KS a un echantillon, par trajectoire : D(F^_att, F_ben) >= 1/(2T)
att = sample(2000, 0.59); ben = sample(2000, 0.5)
def ks1(x):
    x = np.sort(x); n = len(x); Fx = F(x)
    return max((np.arange(1, n+1)/n - Fx).max(), (Fx - np.arange(0, n)/n).max())
d_att = np.array([ks1(r) for r in att]); d_ben = np.array([ks1(r) for r in ben])
print(f"(1) KS par trajectoire T=300 : borne 1/(2T) = {1/(2*T):.5f} ; attaque min {d_att.min():.4f}, mediane {np.median(d_att):.4f}, "
      f"q90 {np.quantile(d_att,.9):.4f} ; benin mediane {np.median(d_ben):.4f}, q90 {np.quantile(d_ben,.9):.4f}")
# (2) KS a deux echantillons comme ks_distance_to_benign : 500x300 scores pooles vs 5000 Beta
res_att, res_ben = [], []
for r in range(200):
    pool_att = sample(500, 0.59).ravel(); pool_ben = sample(500, 0.5).ravel()
    ref = rng.beta(a, b, 5000)
    res_att.append(stats.ks_2samp(pool_att, ref)[0]); res_ben.append(stats.ks_2samp(pool_ben, ref)[0])
res_att, res_ben = np.array(res_att), np.array(res_ben)
print(f"(2) KS pooles 150000 vs 5000 : attaque mediane {np.median(res_att):.4f} [q05 {np.quantile(res_att,.05):.4f}, q95 {np.quantile(res_att,.95):.4f}] ; "
      f"BENIN lui-meme mediane {np.median(res_ben):.4f} [q05 {np.quantile(res_ben,.05):.4f}, q95 {np.quantile(res_ben,.95):.4f}]")
n_eff = 1/(1/5000 + 1/150000)
print(f"    valeur attendue iid ~ 0.8687/sqrt(n_eff) = {0.8687/np.sqrt(n_eff):.4f}")
# (3) benin-vs-benin, 500 paires de trajectoires T=300
bb = sample(1000, 0.5)
d_pairs = np.array([stats.ks_2samp(bb[2*i], bb[2*i+1])[0] for i in range(500)])
print(f"(3) KS benin-vs-benin, 500 paires (T=300 chacune) : mediane {np.median(d_pairs):.4f}, 90e centile {np.quantile(d_pairs,.9):.4f}")
