# Reproduction (lecture seule) de exp_monitor_ab.run_comparison, sans ecriture de fichiers
import sys, os, json, numpy as np
sys.dont_write_bytecode = True
W = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(W, "repo_copy"))
from src.benign import default_benign_model, sample_benign
from src.attack import marginal_preserving_attack, naive_attack, ks_distance_to_benign
from src.monitors import score_trajectories, SequenceClassifier
from src.frontier import compute_auc, compute_detection_power_at_fpr

def run_comparison(model, T, n_benign, n_attack, harm_budget, stealth, spread, rng_seed, target_fpr=0.01, use_naive=False, score_lift=0.15):
    rng = np.random.default_rng(rng_seed)
    benign_arr = sample_benign(model, n_benign, T, rng)
    if use_naive:
        attack_trajs = naive_attack(model, n_attack, T, harm_budget=harm_budget, score_lift=score_lift, rng=rng)
    else:
        attack_trajs = marginal_preserving_attack(model, n_attack, T, harm_budget=harm_budget, stealth=stealth, spread=spread, rng=rng)
    ks = ks_distance_to_benign(attack_trajs, model, rng=rng)
    benign_list = [benign_arr[i] for i in range(n_benign)]
    attack_list = [t.scores for t in attack_trajs]
    n_b_train = n_benign // 2; n_a_train = n_attack // 2
    b_train, b_test = benign_list[:n_b_train], benign_list[n_b_train:]
    a_train, a_test = attack_list[:n_a_train], attack_list[n_a_train:]
    seq_clf = None  # pas de scikit-learn
    bs = score_trajectories(b_test, model, seq_clf=seq_clf)
    as_ = score_trajectories(a_test, model, seq_clf=seq_clf)
    names = list(bs.keys())
    aucs = compute_auc(bs, as_, names)
    powers = {n: compute_detection_power_at_fpr(bs[n], as_[n], target_fpr) for n in names}
    return aucs, powers, ks, len(b_test), len(a_test)

model = default_benign_model(mean=0.286, var=0.025, phi=0.5)
print("Beta params:", model.params, "phi_ben:", model.phi)
print("phi_att (stealth=0.2):", model.phi + 0.2*(0.95-model.phi))
print("SPRT alt phi par defaut:", model.phi + 0.5*(0.95-model.phi))
aucs, powers, ks, nb, na = run_comparison(model, 300, 500, 250, 1.5, 0.2, 150, rng_seed=42)
ref = json.load(open("/home/user/ressources/Gyyz_distributed_sabotage_frontier/results/monitor_ab.json"))["marginal_preserving"]
print("test sizes benign/attack:", nb, na)
print("KS:", ks, "json:", ref["ks_distance"])
for n in aucs:
    print(f"{n:14s} AUC {aucs[n]:.6f} (json {ref['aucs'][n]:.6f})  power {powers[n]:.3f} (json {ref['powers'][n]:.3f})  -> {round(powers[n]*na)}/{na}")
