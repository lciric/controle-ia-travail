# Dispersion de la "puissance a 1 % de faux positifs" estimee comme dans le depot :
# seuil = quantile 0.99 de 250 benins de test, puissance = fraction de 125 attaques >= seuil.
import numpy as np
from scipy import stats
a, b = 2.0500937599999993, 5.118066239999998
T = 300
rng = np.random.default_rng(np.random.SeedSequence(31415926))
def sample(n, phi):
    z = np.empty((n, T)); z[:, 0] = rng.standard_normal(n)
    s = np.sqrt(1 - phi**2); e = rng.standard_normal((n, T))
    for t in range(1, T):
        z[:, t] = phi * z[:, t-1] + s * e[:, t]
    u = np.clip(stats.norm.cdf(z), 1e-7, 1 - 1e-7)
    return z, np.clip(stats.beta.ppf(u, a, b), 0, 1)
def sprt(z, phi0, phi1):
    def ll(phi):
        s2 = 1 - phi*phi; r = z[:, 1:] - phi*z[:, :-1]
        return -0.5*(r*r).sum(1)/s2 - 0.5*(T-1)*np.log(s2)
    return ll(phi1) - ll(phi0)
N = 30000
zb, sb = sample(N, 0.5); za, sa = sample(N, 0.59)
stat = {"a_mean": (sb.mean(1), sa.mean(1)),
        "a_thr0.7": ((sb > 0.7).mean(1), (sa > 0.7).mean(1)),
        "b_sprt(code,phi1=0.725)": (sprt(zb, .5, .725), sprt(za, .5, .725))}
for k, (xb, xa) in stat.items():
    thr = np.quantile(xb, 0.99)
    print(f"{k}: taille reelle au seuil q99 = {(xb >= thr).mean():.4f} ; puissance reelle = {(xa >= thr).mean():.4f}")
    est = []
    for r in range(20000):
        ib = rng.integers(0, N, 250); ia = rng.integers(0, N, 125)
        th = np.quantile(xb[ib], 0.99)
        est.append((xa[ia] >= th).mean())
    est = np.array(est)
    q = np.quantile(est, [0.025, 0.5, 0.975])
    print(f"   estimation 250/125 : mediane {q[1]:.3f}, IC 95% [{q[0]:.3f}, {q[2]:.3f}] ; "
          f"P(est >= 0.048) = {(est >= 0.048-1e-9).mean():.3f} ; P(est >= 0.688) = {(est >= 0.688-1e-9).mean():.4f}")
