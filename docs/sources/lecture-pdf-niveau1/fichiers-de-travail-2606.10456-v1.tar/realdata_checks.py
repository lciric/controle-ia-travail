import sys, os, json, numpy as np
sys.dont_write_bytecode = True
from scipy import stats
W = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(W, "repo_copy"))
from sklearn.metrics import roc_auc_score   # substitut (rangs moyens)
d = json.load(open(os.path.join(W, "repo_copy", "real_traces.json")))
S = np.array(d["scores"]); N, T = S.shape; pool = S.ravel()
atoms, cnt = np.unique(pool, return_counts=True)
print("N,T =", N, T, "| atomes :", dict(zip(atoms.round(2), cnt)), "| masse a 0.4 :", round(cnt[atoms.round(2)==0.4][0]/pool.size, 3))
print("KS(pool reel, Beta(%.2f,%.2f)) = %.3f" % (d["beta_a"], d["beta_b"], stats.kstest(pool, "beta", args=(d["beta_a"], d["beta_b"]))[0]))
# moyenne par position (stationnarite ?)
print("moyenne par pas t (1..24) :", np.round(S.mean(0), 3))
print("ANOVA position (F, p) :", stats.f_oneway(*[S[:, t] for t in range(T)]))
# phi : moyenne des autocorrelations par trajectoire (comme gen_real_traces.py) vs estimateur poole
def ac1(x):
    x = x - x.mean(); v = (x**2).sum()
    return 0.0 if v < 1e-9 else (x[:-1]*x[1:]).sum()/v
print("phi (moyenne par trajectoire, code) =", round(np.mean([ac1(r) for r in S]), 4),
      "| phi poole (centrage global) =", round(np.mean((S[:, :-1]-pool.mean())*(S[:, 1:]-pool.mean()))/pool.var(), 4))
# --- reproduction de exp_realdata_detect.py (memes fonctions, meme graine) ---
xs = np.sort(pool); n = len(xs)
def cdf(s): return np.clip(np.searchsorted(xs, s, side="right")/(n+1.0), 1e-4, 1-1e-4)
def quant(u): return np.interp(np.clip(u, 0, 1), np.linspace(0, 1, n), xs)
def to_z(t): return stats.norm.ppf(cdf(np.asarray(t)))
def sample_attack(nn, TT, phi, rng):
    out = []; s = float(np.sqrt(max(1-phi*phi, 1e-6)))
    for _ in range(nn):
        z = np.empty(TT); z[0] = rng.standard_normal()
        for t in range(1, TT): z[t] = phi*z[t-1] + s*rng.standard_normal()
        out.append(quant(stats.norm.cdf(z)))
    return np.array(out)
def b_autocorr(z, K=3):
    z = z - z.mean(); v = (z**2).mean()
    return 0.0 if v < 1e-9 else float(sum((z[:-l]*z[l:]).mean()/v for l in range(1, min(K+1, len(z)))))
def b_sprt(z, p0, p1):
    def ll(p):
        s2 = 1-p*p; r = z[1:]-p*z[:-1]; return -0.5*np.sum(r*r)/s2 - 0.5*(len(z)-1)*np.log(s2)
    return ll(p1) - ll(p0)
phi_real = d["lag1_autocorr"]; phi_att = min(0.9, phi_real + 0.25)
rng = np.random.default_rng(0)
att = sample_attack(N, T, phi_att, rng)
print("KS(attaque, reel) =", round(stats.ks_2samp(att.ravel(), pool)[0], 6), "(json 0.009722)")
def auc(f, B, A): return roc_auc_score(np.r_[np.zeros(len(B)), np.ones(len(A))], np.r_[[f(x) for x in B], [f(x) for x in A]])
print("AUC a_mean %.4f a_max %.4f a_topk %.4f" % (auc(np.mean, S, att), auc(np.max, S, att), auc(lambda s: np.mean(np.sort(s)[-4:]), S, att)))
print("AUC b_autocorr %.4f b_sprt(oracle) %.4f" % (auc(lambda s: b_autocorr(to_z(s)), S, att), auc(lambda s: b_sprt(to_z(s), phi_real, phi_att), S, att)))
# --- valeurs hors support creees par l'interpolation du quantile ---
off = ~np.isin(np.round(att, 10), np.round(atoms, 10))
print("attaque : fraction de scores hors des 7 atomes = %.4f ; trajectoires (T=24) avec >=1 valeur hors support = %d/%d" % (off.mean(), off.any(1).sum(), N))
big = sample_attack(5000, 24, phi_att, np.random.default_rng(1))
offb = ~np.isin(np.round(big, 10), np.round(atoms, 10))
print("   grand echantillon (5000 traj.) : fraction hors support = %.4f ; P(traj. avec >=1 hors support) = %.3f ; benin reel : 0" % (offb.mean(), offb.any(1).mean()))
# --- le "benin" de la figure 7c est synthetique : comparer a T=24 reel vs synthetique ---
syn_b = sample_attack(300, 24, phi_real, np.random.default_rng(124))
print("T=24 : AUC b_autocorr reel-benin vs attaque = %.3f ; synthetique-benin vs attaque = %.3f" % (
      auc(lambda s: b_autocorr(to_z(s)), S, att), auc(lambda s: b_autocorr(to_z(s)), syn_b, att)))
print("T=24 : AUC b_sprt     reel-benin vs attaque = %.3f ; synthetique-benin vs attaque = %.3f" % (
      auc(lambda s: b_sprt(to_z(s), phi_real, phi_att), S, att), auc(lambda s: b_sprt(to_z(s), phi_real, phi_att), syn_b, att)))
# statistique SPRT sur benin reel vs benin synthetique (meme modele) : decalage ?
lr_real = np.array([b_sprt(to_z(s), phi_real, phi_att) for s in S]); lr_syn = np.array([b_sprt(to_z(s), phi_real, phi_att) for s in syn_b])
print("LLR SPRT moyen : benin reel %.3f, benin synthetique %.3f ; var(z) reel %.3f vs synth %.3f" % (lr_real.mean(), lr_syn.mean(),
      np.mean([to_z(s).var() for s in S]), np.mean([to_z(s).var() for s in syn_b])))
