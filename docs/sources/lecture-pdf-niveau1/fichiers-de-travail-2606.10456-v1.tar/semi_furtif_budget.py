# Attaque semi_stealthy_attack du depot (figure 4 / tableau 3) : copule AR(1) phi=0.59 + decalage de
# min(0.30, 0.3*H/K) sur les K scores les plus hauts (rang), borne a 1. H = 2 => budget total 0.6 si K >= 2.
import numpy as np
from scipy import stats
a, b = 2.0500937599999993, 5.118066239999998
T = 300; H = 2.0
rng = np.random.default_rng(np.random.SeedSequence(16180339))
def sample(n, phi):
    z = np.empty((n, T)); z[:, 0] = rng.standard_normal(n)
    s = np.sqrt(1 - phi**2); e = rng.standard_normal((n, T))
    for t in range(1, T):
        z[:, t] = phi * z[:, t-1] + s * e[:, t]
    return np.clip(stats.beta.ppf(np.clip(stats.norm.cdf(z), 1e-7, 1-1e-7), a, b), 0, 1)
def auc(xb, xa):
    r = stats.rankdata(np.r_[xb, xa]); n1 = len(xa); n0 = len(xb)
    return (r[n0:].sum() - n1*(n1+1)/2) / (n0*n1)
N = 20000
sb = sample(N, 0.5); base = sample(N, 0.59)
for phi_label, att_base in [("phi_att=0.59 (code)", base)]:
    print(phi_label)
    for K in [1, 2, 10, 50, 150, 300]:
        lift = min(0.30, H / K * 0.3)
        sa = att_base.copy()
        idx = np.argsort(sa, axis=1)[:, T-K:]
        rows = np.arange(N)[:, None]
        sa[rows, idx] = np.clip(sa[rows, idx] + lift, 0, 1)
        tot = (sa - att_base).sum(1).mean()
        m_b, m_a = sb.mean(1), sa.mean(1); x_b, x_a = sb.max(1), sa.max(1)
        thr_m = np.quantile(m_b, .99); thr_x = np.quantile(x_b, .99)
        print(f"  K={K:3d} decalage/pas={lift:.4f} budget total realise={tot:.3f} | moyenne AUC={auc(m_b, m_a):.3f} puiss@1%={(m_a>=thr_m).mean():.3f}"
              f" | max AUC={auc(x_b, x_a):.3f} puiss@1%={(x_a>=thr_x).mean():.3f}")
