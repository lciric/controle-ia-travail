# Fuite des statistiques "Monitor A" sous la copule AR(1) du depot (marginale par pas preservee seulement).
# Grand Monte-Carlo vectorise ; memes definitions que src/monitors.py (top-k: k=T//10 dans le code, k=15 dans le papier).
import numpy as np
from scipy import stats
a, b = 2.0500937599999993, 5.118066239999998   # default_benign_model(mean=0.286, var=0.025)
T = 300
rng = np.random.default_rng(np.random.SeedSequence(20261004))

def sample(n, phi, rng):
    z = np.empty((n, T)); z[:, 0] = rng.standard_normal(n)
    s = np.sqrt(1 - phi**2)
    e = rng.standard_normal((n, T))
    for t in range(1, T):
        z[:, t] = phi * z[:, t-1] + s * e[:, t]
    u = np.clip(stats.norm.cdf(z), 1e-7, 1 - 1e-7)
    return z, np.clip(stats.beta.ppf(u, a, b), 0, 1)

def auc(xb, xa):
    r = stats.rankdata(np.r_[xb, xa]); n1 = len(xa); n0 = len(xb)
    return (r[n0:].sum() - n1*(n1+1)/2) / (n0*n1)

def stats_A(s):
    srt = np.sort(s, axis=1)
    return {"a_mean": s.mean(1), "a_max": s.max(1),
            "a_top30": srt[:, -30:].mean(1), "a_top15": srt[:, -15:].mean(1),
            "a_thr0.7": (s > 0.7).mean(1)}

def sprt(z, phi0, phi1):
    def ll(phi):
        s2 = 1 - phi*phi; r = z[:, 1:] - phi*z[:, :-1]
        return -0.5*(r*r).sum(1)/s2 - 0.5*(T-1)*np.log(s2)
    return ll(phi1) - ll(phi0)

N = 40000
zb, sb = sample(N, 0.5, rng)
for phi_att in [0.59, 0.725, 0.9]:
    za, sa = sample(N, phi_att, rng)
    A_b, A_a = stats_A(sb), stats_A(sa)
    print(f"\n=== phi_ben=0.5, phi_att={phi_att} (delta={phi_att-0.5:.3f}), T={T}, N={N}+{N}")
    for k in A_b:
        thr_hi = np.quantile(A_b[k], 0.99); thr_lo = np.quantile(A_b[k], 0.01)
        p_hi = (A_a[k] >= thr_hi).mean(); p_lo = (A_a[k] <= thr_lo).mean()
        print(f"  {k:9s} AUC={auc(A_b[k], A_a[k]):.3f}  puissance unilaterale haute @1%={p_hi:.4f}  basse @1%={p_lo:.4f}  "
              f"ecart-type att/ben={A_a[k].std()/A_b[k].std():.3f}  moyenne ben/att={A_b[k].mean():.4f}/{A_a[k].mean():.4f}")
    for lab, p1 in [("SPRT code (phi1=0.725)", 0.725), ("SPRT oracle (phi1=phi_att)", phi_att)]:
        lb, la = sprt(zb, 0.5, p1), sprt(za, 0.5, p1)
        thr = np.quantile(lb, 0.99)
        print(f"  {lab:28s} AUC={auc(lb, la):.4f}  puissance@1%={(la >= thr).mean():.4f}")
