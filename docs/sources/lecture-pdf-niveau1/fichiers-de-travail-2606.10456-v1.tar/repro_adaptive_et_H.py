import sys, os, json, numpy as np
sys.dont_write_bytecode = True
W = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(W, "repo_copy"))
from src.benign import default_benign_model, sample_benign
from src.attack import marginal_preserving_attack, semi_stealthy_attack, ks_distance_to_benign
from src.monitors import score_trajectories
from src.frontier import compute_auc, compute_detection_power_at_fpr
model = default_benign_model(mean=0.286, var=0.025, phi=0.5)
# (G) scores identiques quel que soit H (meme graine) ?
ref = None
for H in [0.0, 0.2, 1.5, 3.0]:
    tr = marginal_preserving_attack(model, 50, 300, harm_budget=H, stealth=0.2, spread=150, rng=np.random.default_rng(42))
    arr = np.array([t.scores for t in tr])
    if ref is None: ref = arr
    print(f"H={H}: scores identiques a H=0 ? {np.array_equal(arr, ref)} ; harm somme={tr[0].total_harm:.2f} ; "
          f"harm porte par les {int((tr[0].harm>0).sum())} plus hauts scores ? {set(np.argsort(tr[0].scores)[-150:]) == set(np.nonzero(tr[0].harm)[0]) if H>0 else '-'}")
for sp in [1, 150, 300]:
    tr = marginal_preserving_attack(model, 50, 300, harm_budget=2.0, stealth=0.2, spread=sp, rng=np.random.default_rng(42))
    print(f"spread={sp}: scores identiques ? {np.array_equal(np.array([t.scores for t in tr]), ref)}")
# (E) frontiere adaptative : quelle statistique A donne a_best ?
PHI_B, PHI_MAX = 0.5, 0.95
for dp in [0.09, 0.25, 0.40]:
    rng = np.random.default_rng(42 + int(dp*1000)); n_traj = 500; T = 300
    st = float(np.clip(dp/(PHI_MAX-PHI_B), 0, 1))
    ben = sample_benign(model, n_traj, T, rng)
    atk = marginal_preserving_attack(model, n_traj, T, harm_budget=1.5, stealth=st, spread=T//2, rng=rng)
    bl = [ben[i] for i in range(n_traj)][n_traj//2:]; al = [t.scores for t in atk][n_traj//2:]
    bs = score_trajectories(bl, model); as_ = score_trajectories(al, model)
    au = compute_auc(bs, as_)
    a_keys = [k for k in au if k.startswith("a_")]
    best = max(a_keys, key=lambda k: abs(au[k]-0.5))
    print(f"delta_phi={dp}: AUC A = " + ", ".join(f"{k} {au[k]:.3f}" for k in a_keys) + f" -> a_best = {abs(au[best]-0.5)+0.5:.4f} ({best}) ; b_autocorr {au['b_autocorr']:.4f} ; b_sprt {au['b_sprt']:.4f}")
print("json a_best_auc :", json.load(open('/home/user/ressources/Gyyz_distributed_sabotage_frontier/results/adaptive_redteam.json'))['frontier']['a_best_auc'])
