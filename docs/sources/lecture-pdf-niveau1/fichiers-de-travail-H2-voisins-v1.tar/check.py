import re, sys, json
W = "/tmp/claude-0/-home-user-cplt-run-2026-09-03/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/lecture-H2"
def norm(s):
    s = s.replace("­", "")
    s = re.sub(r"-\n\s*", "", s)   # join hyphenated line breaks
    s = re.sub(r"\s+", " ", s)
    return s
def check(paper, page, quote):
    hits = []
    for mode in ("raw", "layout"):
        d = f"{W}/{paper}.raw" if mode == "raw" else f"{W}/{paper}"
        try:
            t = open(f"{d}/p{page:02d}.txt", encoding="utf-8").read()
        except FileNotFoundError:
            continue
        if norm(quote) in norm(t):
            hits.append(mode)
    return hits
quotes = json.load(open(sys.argv[1]))
for q in quotes:
    h = check(q[0], q[1], q[2])
    n = len(q[2].split())
    print(("OK  " if h else "FAIL"), q[0], "p.%d" % q[1], f"[{n} mots]", "|", q[2][:110], "|", h)
