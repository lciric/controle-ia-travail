# Recalculs à partir des valeurs imprimées (tableaux 21, 22, 23, 25 de 2605.08647v1).
src = {"GPT":(85,45),"Gemini":(86,56),"Qwen":(96,64),"Llama":(67,37)}
drop = {"GPT":(.16,.33),"Gemini":(.08,.27),"Qwen":(.03,.16),"Llama":(.40,.65)}
print("somme des arêtes sources du tableau 23 :", sum(a+b for a,b in src.values()), "(texte p. 8 : n=540)")
for m in src:
    l,c = drop[m]; print(m, "rapport DAG/chaîne (tableau 23, arrondis) : %.2f" % (c/l),
      "| arêtes perdues chaîne ~%.0f sur %d" % (l*src[m][0], src[m][0]),
      "| survie extrapolée à taux constant, 1..4 relais :", [round((1-l)**k,2) for k in (1,2,3,4)])
ech = {"GPT":(25,11,8,6,49.4),"Gemini":(19,8,2,9,64.4),"Qwen":(10,6,0,4,81.7),"Llama":(36,22,12,2,20.7)}
tot = sum(v[0] for v in ech.values()); up = sum(v[2] for v in ech.values()); syn = sum(v[1] for v in ech.values())
print("échecs DAG convergent :", tot, "| synthèse :", syn, "(%.0f %%)" % (100*syn/tot), "| amont :", up, "(%.0f %%)" % (100*up/tot),
      "| racine muette (21 des 22 pertes amont) : %.0f %% des échecs" % (100*21/tot))
for m,(n,s,u,p,rtd) in ech.items():
    assert n == s+u+p
    parf = 45-n; reste = rtd/100*45 - parf
    print(m, "tâches parfaites", parf, "sur 45 ; score restant %.2f réparti sur %d échecs (dont %d partiels)" % (reste, n, p),
          "-> cohérent" if -0.3 <= reste <= p else "-> INCOHERENT")
