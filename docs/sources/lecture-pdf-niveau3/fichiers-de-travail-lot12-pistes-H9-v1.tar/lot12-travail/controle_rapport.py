# Second contrôle : tout passage « ... » du rapport suivi d'un identifiant (Axx/Txx) est inclus dans la
# citation contrôlée de cet identifiant, et la page dite est la bonne ; tout identifiant cité existe ;
# les passages « ... » de 4 mots anglais ou plus sans identifiant sont listés.
import json, re, sys
sys.path.insert(0, sys.argv[3]); from controle_citations import norm
cs = {c["id"]: c for c in json.load(open(sys.argv[1]))}
t = open(sys.argv[2], encoding="utf-8").read()
ech = 0; n = 0
for m in re.finditer(r"« ([^»]+?) »[ ,]*\(?((?:[AT]\d\d)(?:, [AT]\d\d)*)(?:, p\. (\d+))?", t):
    q, ids, p = m.group(1), m.group(2).split(", "), m.group(3)
    n += 1; i = ids[0]
    if i not in cs or norm(q) not in norm(cs[i]["citation"]): ech += 1; print("ECHEC inclusion", i, "|", q[:80])
    elif p and int(p) != cs[i]["page"]: ech += 1; print("ECHEC page", i, p, cs[i]["page"])
for i in set(re.findall(r"\b([AT]\d\d)\b", t)):
    if i not in cs: ech += 1; print("ECHEC identifiant inconnu", i)
sans = [q for q in re.findall(r"« ([^»]+?) »(?![ ,]*\(?[AT]\d\d)", t) if len(re.findall(r"\b(?:the|of|and|is|a|to|in|that|not)\b", q)) >= 3]
for q in sans: print("SANS IDENTIFIANT (à regarder) :", q[:100])
print("tous les passages sans identifiant :", re.findall(r"« ([^»]+?) »(?![ ,]*\(?[AT]\d\d)", t))
print("passages entre guillemets rattachés :", n, "| échecs :", ech, "| passages anglais sans identifiant :", len(sans))
sys.exit(1 if ech else 0)
