# Contrôle : chaque citation figure dans le texte de la page citée, extrait par pdftotext.
# Usage : python3 -I controle_citations.py citations.json DOSSIER_PDF   |   --autotest DOSSIER_PDF
import json, subprocess, sys, unicodedata, re
def norm(s):
    s = unicodedata.normalize("NFKC", s)
    for a, b in (("’","'"),("‘","'"),("“",'"'),("”",'"'),("–","-"),("—","-"),("­","")):
        s = s.replace(a, b)
    return re.sub(r"[\s\-]+", "", s)
_cache = {}
def page(pdf, n, mode):
    k = (pdf, n, mode)
    if k not in _cache:
        cmd = ["pdftotext"] + ([mode] if mode else []) + ["-f", str(n), "-l", str(n), pdf, "-"]
        _cache[k] = norm(subprocess.run(cmd, capture_output=True, text=True, check=True).stdout)
    return _cache[k]
def trouve(dossier, pdf, n, cit):
    c = norm(cit)
    if len(c) < 6: return None
    for mode in ("-layout", "", "-raw"):
        if c in page(dossier + "/" + pdf, n, mode): return mode or "defaut"
    return None
def autotest(d):
    ok = trouve(d, "2605.08647v1.pdf", 17, "It measures turn-level violation incidence, not time-to-first-failure or severity.")
    alt = trouve(d, "2605.08647v1.pdf", 17, "It measures turn-level violation incidence, not time-to-last-failure or severity.")
    mp = trouve(d, "2605.08647v1.pdf", 16, "It measures turn-level violation incidence, not time-to-first-failure or severity.")
    print("cas juste :", ok, "| cas altéré :", alt, "| cas juste, mauvaise page :", mp)
    assert ok and alt is None and mp is None
    print("AUTOTEST CONFORME")
if __name__ == "__main__":
    if sys.argv[1] == "--autotest": autotest(sys.argv[2]); sys.exit(0)
    cs = json.load(open(sys.argv[1])); ech = 0; modes = {}
    for c in cs:
        m = trouve(sys.argv[2], c["pdf"], c["page"], c["citation"])
        if m is None: ech += 1; print("ECHEC", c["id"], c["pdf"], "p.", c["page"], "|", c["citation"])
        else: modes[m] = modes.get(m, 0) + 1
    print("citations contrôlées :", len(cs), "| échecs :", ech, "| modes :", modes)
    sys.exit(1 if ech else 0)
