#!/usr/bin/env python3
"""Contrôle des citations du rapport lot1-HC2 (MIRAGE, Karne).

Pour chaque entrée (identifiant, fichier PDF, page, citation exacte), vérifie
que la citation figure dans le texte de la page extrait par pdftotext.

Normalisation appliquée des deux côtés (page et citation) :
  - Unicode NFKC (défait les ligatures fi, fl, ff...) ;
  - apostrophes et guillemets typographiques ramenés aux formes droites ;
  - suppression des traits d'union (U+002D, U+2010, U+2011, U+00AD), ce qui
    défait les césures de fin de ligne ;
  - suppression de tous les blancs (sauts de ligne, espaces des petites
    capitales comme « M IRAGE »).
Les lettres, chiffres, signes de ponctuation et symboles restants doivent
coïncider exactement, dans l'ordre.

Trois extractions de la page sont essayées : « -layout », défaut (ordre de
lecture, utile pour les pages à deux colonnes où « -layout » entrelace les
colonnes), « -raw ». Le journal dit laquelle a servi.

Usage : python3 -I controle_citations.py DOSSIER_PDF citations.json journal.txt
        python3 -I controle_citations.py --autotest DOSSIER_PDF
"""
import json
import subprocess
import sys
import unicodedata

MODES = (("layout", ["-layout"]), ("defaut", []), ("raw", ["-raw"]))
TRAITS = dict.fromkeys(map(ord, "-‐‑­"), None)
QUOTES = {ord("’"): "'", ord("‘"): "'", ord("“"): '"', ord("”"): '"'}


def normaliser(texte):
    t = unicodedata.normalize("NFKC", texte)
    t = t.translate(QUOTES).translate(TRAITS)
    return "".join(t.split())


_cache = {}


def page_texte(pdf, page, options):
    cle = (pdf, page, tuple(options))
    if cle not in _cache:
        r = subprocess.run(
            ["pdftotext", *options, "-f", str(page), "-l", str(page), pdf, "-"],
            capture_output=True, check=True)
        _cache[cle] = normaliser(r.stdout.decode("utf-8", "replace"))
    return _cache[cle]


def controler(pdf, page, citation):
    """Rend le nom du mode où la citation est trouvée, ou None."""
    cible = normaliser(citation)
    if len(cible) < 8:
        return None  # citation trop courte pour être probante
    for nom, options in MODES:
        if cible in page_texte(pdf, page, options):
            return nom
    return None


def autotest(dossier):
    pdf = dossier + "/2606.10304v1.pdf"
    juste = "Per-token scores are aggregated using a 5-token max-burst rule"
    altere = "Per-token scores are aggregated using a 7-token max-burst rule"
    ok_juste = controler(pdf, 4, juste) is not None
    ok_altere = controler(pdf, 4, altere) is None
    mauvaise_page = controler(pdf, 5, juste) is None
    print("autotest cas juste trouvé :", ok_juste)
    print("autotest cas altéré rejeté :", ok_altere)
    print("autotest cas juste sur mauvaise page rejeté :", mauvaise_page)
    return 0 if (ok_juste and ok_altere and mauvaise_page) else 1


def main(argv):
    if len(argv) == 3 and argv[1] == "--autotest":
        return autotest(argv[2])
    dossier, f_citations, f_journal = argv[1:4]
    with open(f_citations, encoding="utf-8") as f:
        citations = json.load(f)
    lignes, echecs = [], 0
    for c in citations:
        mode = controler(dossier + "/" + c["pdf"], c["page"], c["citation"])
        if mode is None:
            echecs += 1
        lignes.append("%s\t%s\tp.%d\t%s\t%s" % (
            "OK" if mode else "ECHEC", c["id"], c["page"], mode or "-", c["citation"]))
    bilan = "citations contrôlées : %d ; échecs : %d" % (len(citations), echecs)
    with open(f_journal, "w", encoding="utf-8") as f:
        f.write("\n".join(lignes) + "\n" + bilan + "\n")
    for l in lignes:
        if l.startswith("ECHEC"):
            print(l)
    print(bilan)
    return 1 if echecs else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
