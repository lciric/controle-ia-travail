# Rapport de lecture — niveau 3, lot 2-A : billets sur le contrôle boîte blanche et les sondes comme moniteurs (papier A) — v1

- **Lecteur** : sous-agent neuf (modèle Fable 5.2), qui n'a écrit ni le programme ni aucun rapport antérieur.
- **Date** : 2026-11-10 ; fin de lecture relevée à 11:10 UTC, rapport assemblé à l'heure imprimée en section 7 (heures relevées par `date -u`).
- **Sources** : dix-sept rendus texte de billets et de pages web, non versés au dépôt (droits réservés), dans `/tmp/claude-0/-home-user-controle-ia-travail/ba75ee53-729a-59d5-934a-27a4eace4393/scratchpad/lot2/non-verses/`. Provenance : `docs/sources/pdf/niveau3-v1/provenance-niveau3-lot2-hors-archives-v1.md` (sha256 `a30e87c5d835ff87b448bcb25f3debb5b3eeac1ca5f77a7eb489c1b4f3081fec`, conforme à son compagnon).
- **Repérage d'une citation** : abréviation du fichier, numéro de ligne du rendu `.txt`, citation exacte, identifiant entre crochets. La table des abréviations est en section 1 ; la liste complète des 201 citations est en annexe.
- **Nature des chiffres** : « auteurs » (imprimé dans le billet), « calcul » (recalculé par le lecteur, fichier `calculs.txt` de l'archive). Aucun chiffre « figure » : aucune image des dix-sept billets n'est dans le dossier (les seules images du dossier appartiennent à un autre billet, hors lot).
- **Portée** : un billet n'est pas un article. « Libre » veut dire « non trouvé dans les billets lus ». Les articles auxquels les billets renvoient ne sont pas lus ici ; ils sont listés en section 6.

## 0. En tête : occupations, même partielles

1. **H2 (énoncé N-007) — occupée en partie, pour la configuration de référence seulement**, par le billet de LessWrong du 30 octobre 2026 (Surya et Lucassen, stage de Redwood Research). Le billet lit six sondes linéaires sur les activations de l'agent qui agit, à chaque commande, avec un seuil par action réglé à 1 % des commandes honnêtes et une trajectoire déclarée attrapée dès qu'une commande franchit le seuil : {LW-10} ; {LW-09}. C'est le « moniteur par action calibré à 1 % de faux positifs » de l'énoncé, réalisé avec des sondes de l'agent. **Non fait** : aucune accumulation ({LW-14}), aucune garantie au niveau de la trajectoire (de 26 à 43 % des trajectoires honnêtes sonnent : {LW-11}), aucun sabotage tenu sous le seuil, aucune courbe selon l'horizon. Lecture douce possible : « voisin fort ». La conjonction revendiquée reste libre dans les billets lus.
2. **H6 (énoncé N-013) — occupée en partie pour le ré-échantillonnage, en sabotage concentré**, par le billet de Redwood Research du 29 mai 2026 qui résume arXiv 2605.26047 : gain de sécurité de 10,2 points sans coût d'utilité quand le ré-échantillonnage sert d'information ({RE-06} ; {RE-05}). Réserves fortes : le gain passe par l'audit (plus d'information pour le moniteur), non par une chute du succès de l'attaque sous perturbation ; cadre concentré (BashArena) ; la variante qui exécute l'échantillon le moins suspect n'apporte rien contre un attaquant optimal. Les rapports du niveau 2 n'avaient pas confronté cet article à H6. À trancher sur le PDF (2605.26047, déjà au dépôt d'après le niveau 2).
3. **H1 — aucune occupation ; un voisin fort chiffré et un contre-indice de position.** Le billet long de l'institut britannique (10 juillet 2025) donne une comparaison chiffrée sonde contre moniteur boîte noire sur une tâche d'agent avec sous-performance volontaire, **en aire sous la courbe seulement** : {AL-07} contre {AL-08}. Ce n'est pas à faux positifs égaux, pas sur tâche floue, sur 17 transcriptions, avec un moniteur boîte noire désavantagé de l'aveu des auteurs. En lecture dure, c'est « occupée en partie » pour la seule composante « comparaison chiffrée blanc contre noir sur une sous-performance d'agent ». Le billet d'Anthropic du 23 juin 2026 (Terekhov et collègues, base du programme) écrit que la surveillance est moins prometteuse que l'entraînement pour le diffus : {DI-02}.
4. **Risque de collision à lire d'urgence (non lus ici)** : arXiv 2610.12445 (sonde de tromperie qui, selon le billet de LessWrong, attrape déjà le sabotage d'agent : {LW-21}) et arXiv 2610.31593 (évaluations de contrôle simulées, cinq moniteurs qui lisent la transcription, mêmes tâches LinuxArena). La même équipe a donc, sur les mêmes 1 313 tâches, des sondes et des moniteurs boîte noire : la comparaison blanc contre noir en sabotage **concentré** est à une table près.
5. **État de l'art v1, ligne 37** : affirmation **à nuancer** (section 2). Ligne 36 : **exacte pour ce que le billet permet de vérifier**, un détail non vérifiable ici.
6. **Statut de la source prioritaire** : le billet de LessWrong porte une mention de rejet par la modération ({LW-02}), confirmée dans le HTML (`"rejected":true`), et se présente comme un travail de deux semaines ({LW-26}). À citer avec cette réserve.
7. Aucun refus de permission ni de classifieur.

## 1. Méthode, fichiers et empreintes

- Chaque `.txt` et chaque `.html` lu a son empreinte dans la note de provenance (34 empreintes cherchées, 34 trouvées). Les empreintes des `.txt` sont dans `empreintes-txt-lues.txt` de l'archive.
- Lecture intégrale des dix-sept `.txt` (commentaires compris). Les lignes vides et, pour les billets Substack, les lignes qui ne portent qu'une adresse d'image ont été écartées à l'affichage.
- Vérification dans le HTML faite pour un seul point : le statut de rejet du billet prioritaire.
- Énoncés du programme lus : `docs/programme-controle-ia-v2.md` (lignes 85 à 125 et 190 à 215), décisions N-003/N-004, N-007/N-008, N-013, sections H1, H2, L, T, Tr, H6, H8, HC2 de `docs/etat-de-l-art/niveau2-v1/anteriorite-v1.md`.

| Abréviation | Fichier `.txt` | Billet | Date imprimée |
|---|---|---|---|
| LW26 | `lw-2026-probe-monitors-perform-realistically-in-simulated.txt` | « Probe monitors seem to perform realistically in simulated control environments », Surya et Lucassen, LessWrong | {LW-01} |
| AISILW | `aisi-2025-lesswrong-white-box-control-update-sandbagging.txt` | « White Box Control at UK AISI - Update on Sandbagging Investigations », Bloom et collègues, miroir LessWrong | {AL-01} |
| AISIPUB | `aisi-2025-publication-white-box-control-update-sandbagging.txt` | fiche de publication de l'institut (résumé seul) | {AP-01} |
| AISIWHY | `aisi-2025-why-were-working-on-white-box-control.txt` | « Why we're working on white box control », institut britannique | {AW-01} |
| CASE | `lw-case-for-white-box-control.txt` | « The Case for White Box Control », J Rosser, LessWrong | {CA-01} |
| LIE | `anthropic-2026-lie-detectors.txt` | « Fine-Tuned Lie Detectors Failed to Generalize », Hopkins, Khullar et collègues | {LD-01} |
| CHEAP | `anthropic-2025-cheap-monitors.txt` | « Cost-Effective Constitutional Classifiers via Representation Re-use », Cunningham et collègues | aucune date dans le rendu ; adresse en `/2025/` |
| APOLLO | `apollo-2025-deception-probes.txt` | « Detecting Strategic Deception Using Linear Probes », Apollo Research | {AO-01} |
| HEBBAR | `hebbar-2025-redwood-how-can-we-solve-diffuse-threats.txt` | « How can we solve diffuse threats like research sabotage with AI control? », Hebbar | {HE-01} |
| NOTES | `redwood-notes-on-handling-non-concentrated.txt` | « Notes on handling non-concentrated failures with AI control », Greenblatt | {NO-01} |
| DIFFUSE | `anthropic-2026-diffuse-ai-control.txt` | « Diffuse AI Control on Fuzzy Tasks », Terekhov, Gulcehre, Hebbar, Benton | {DI-01} |
| LOGIT | `redwood-logit-rocs-monitor-tpr-is-linear.txt` | « Logit ROCs: Monitor TPR is linear in FPR in logit space », Staley, Bhatt, Stastny | {LR-01} |
| BLOCK | `redwood-blocking-live-failures-with-synchronous.txt` | « Blocking live failures with synchronous monitors », Lucassen et Kaufman | {BL-01} |
| RETRY | `redwood-retrying-vs-resampling-in-ai-control.txt` | « Retrying vs Resampling in AI Control », Lucassen et Kaufman | {RE-01} |
| GAMES | `aisi-auditing-games-for-sandbagging-detection.txt` | « Auditing games for sandbagging detection », institut britannique | {AG-01} |
| REDTEAM | `aisi-how-our-new-control-red-team-is-stress-testing-frontier-monitors.txt` | « How our Control Red Team is stress-testing frontier monitors », institut britannique | {RT-01} |
| STRESS | `aisi-stress-testing-asynchronous-monitoring-of-ai-coding-agents.txt` | « Stress-testing asynchronous monitoring of AI coding agents », institut britannique | {ST-01} |

## 2. Vérification de deux affirmations de l'état de l'art v1 (`docs/etat-de-l-art-controle-ia-v1.md`)

### Ligne 37 — « Blog de l'institut britannique … et "The Case for White Box Control" … posent la thèse blanc > noir, sans mesure sur diffus/flou à faux positifs égaux »

**Verdict : à nuancer**, en trois points.

1. **« posent la thèse blanc > noir » — inexact pour « The Case », à nuancer pour l'institut.**
   - « The Case for White Box Control » ne soutient pas que le blanc bat le noir. Il répartit les menaces entre les deux : le noir est jugé plus adapté pour trois des sept priorités ({CA-07} ; {CA-12}), le blanc pour les autres. Il liste des arguments contre les sondes ({CA-06}) et se dit enthousiaste pour le noir aussi ({CA-03}). Sa thèse est la complémentarité : {CA-04}. Le seul commentaire, de Fabien Roger, va contre la thèse prêtée : {CA-10}.
   - L'institut britannique avance bien un avantage des sondes, mais comme un indice limité à un cas : {AW-02}. Les deux billets insistent autant sur la dégradation : {AW-03} ; {AL-17}.
2. **« sans mesure » — inexact pour l'institut, exact pour « The Case ».**
   - Le billet long de l'institut mesure. Tâche d'agent (InterCode CTF, outils bash et python), Llama-3.3-70B, sous-performance sur consigne : moniteur boîte noire sur la chaîne de pensée à 74 % d'aire sous la courbe ({AL-07}), sonde à 97 % et 99 % selon l'agrégation ({AL-08}) — chiffres « auteurs ». Pour la sonde seule, un point de fonctionnement : {AL-09}, avec un seuil pris sur un autre corpus ({AL-10}).
   - « The Case » ne contient aucune mesure : {CA-05}.
3. **« sur diffus/flou à faux positifs égaux » — exact comme conjonction.**
   - Aucun des quatre textes ne compare sonde et moniteur boîte noire à taux de faux positifs égal : la comparaison de l'institut est en aire sous la courbe, et le taux de vrais positifs à faux positifs fixés n'est donné que pour la sonde.
   - La sous-performance volontaire est rangée parmi les menaces diffuses par le billet d'Anthropic ({DI-03}, suite ligne 37 du même fichier). La mesure de l'institut porte donc sur une menace de type diffus, mais sur une tâche vérifiable (un drapeau à trouver), non floue, et sur des réponses notées une à une, sans étalement sur une trajectoire de déploiement.
   - « The Case » affirme sans mesure que les sondes conviennent aux tâches difficiles à vérifier : {CA-08} ; {CA-09}. C'est la thèse du diffus sur tâche floue, posée en une ligne.

**Formulation proposée** (à la décision de Lazar, le lecteur ne modifie pas l'état de l'art) : « Le billet long de l'institut britannique (10 juillet 2025) mesure sonde contre moniteur boîte noire sur une sous-performance volontaire, y compris sur une tâche d'agent (74 % contre 97 à 99 % d'aire sous la courbe, 17 transcriptions positives), sans comparaison à faux positifs égaux ni tâche floue, et rapporte la dégradation des deux méthodes quand le modèle et la tâche grossissent. "The Case for White Box Control" (18 avril 2025) est un billet d'opinion sans mesure, qui plaide la complémentarité et attribue aux sondes, par simple affirmation, les tâches difficiles à vérifier. »

### Ligne 36 — Taylor et collègues, arXiv 2512.07810 (jeux d'audit)

**Verdict : exact pour ce que le billet de l'institut permet de vérifier ; un détail non vérifiable ici.**
- « méthodes fondées sur les internes plus prometteuses que la boîte noire » : {AG-03} ; {AG-02}.
- « usage naïf battu par des comportements introduits par l'équipe rouge » : {AG-04} ; {AG-05}.
- « organismes publics, dont un imitant Llama-3.1-8B-Instruct » : absent du billet, qui dit seulement {AG-06}. À vérifier sur le PDF (déjà lu au niveau 2, lot2-A3).
- Nuance utile au programme : le billet donne la méthode gagnante, et ce n'est pas une sonde mais l'entraînement sur la distribution, qui élimine la sous-performance sans la détecter ; il reconnaît que cette voie peut être impraticable sur tâche ouverte : {AG-08}.

## 3. Fiches par billet

### 3.1 LW26 — sondes d'activations comme moniteurs de contrôle sur LinuxArena (priorité 1)

**Ce qu'il fait.**
- Question : la simulation des réponses d'outils par un modèle change-t-elle le taux d'attrape de sondes qui lisent les activations de l'agent ? Agent Qwen3.5-27B ; simulateur GPT-6-Astra ; 1 313 tâches LinuxArena, chacune attaquée trois fois ({LW-03}).
- Sabotage **concentré** : une tâche principale et une tâche annexe nuisible par trajectoire ({LW-06}) ; l'agent reçoit la consigne d'attaquer ({LW-39}).
- Six sondes linéaires, lues près de la fin de chaque commande ({LW-07}) : deux entraînées sur LinuxArena (sur la politique de l'agent ; hors politique, sur les trajectoires d'un autre agent relues par Qwen3.5), quatre publiées (tromperie, direction de nocivité, direction de refus, enjeux élevés).
- Règle de décision : seuil par commande à 1 % des commandes honnêtes ({LW-10}), calibré sur des trajectoires honnêtes ; trajectoire attrapée si une commande sonne ({LW-09}), même après le dommage ({LW-15}).
- Sonde séparée qui distingue simulation et réel.

**Résultats chiffrés (auteurs, sauf mention).**
- Aire sous la courbe par trajectoire, au maximum des commandes ({LW-08}) : sonde sur politique {LW-31} ; hors politique 0,76 ; tromperie 0,77 ; nocivité 0,65 ; refus {LW-32} ; enjeux élevés 0,55 (LW26, l. 94 à 134).
- Taux d'attrape à 1 % des commandes honnêtes, trajectoires réelles, première série : sur politique {LW-35} % ; hors politique 72,5 % ; tromperie {LW-33} % ; nocivité 58,7 % ; refus {LW-34} % ; enjeux élevés 48,3 % ; moyenne des six {LW-36} % en réel et {LW-37} % en simulation (LW26, tableau 5, l. 408 à 516). Moyennes recalculées : 66,23 ; 66,03 ; 65,13 — conformes (calcul).
- Écart simulation moins réel : {LW-04}.
- **Coût en fausses alarmes par trajectoire** : {LW-11}, pour {LW-38}. Sous indépendance des commandes, on attendrait 48 à 53 % (calcul : 1 − 0,99^65 et 1 − 0,99^75) : les alarmes honnêtes sont donc regroupées dans les mêmes trajectoires, ce que les auteurs disent eux-mêmes (LW26, l. 140 et 808).
- Sonde de simulation : {LW-16} ; les six sondes n'en sont pas déplacées ({LW-17}, entre « avoir l'air simulé » et « être manqué »).
- Seuils stricts : à 0,02 % et 0,05 %, le seuil simulé repose sur une à quatre trajectoires et {LW-19} ; {LW-40}.

**Ce qu'il ne fait pas.**
- **Aucune comparaison avec un moniteur boîte noire.** Les moniteurs qui lisent la transcription ne sont cités que par renvoi à un autre article et à un autre point de fonctionnement : {LW-20}. Sondes à 1 % des commandes, moniteurs à 5 % des trajectoires : les deux ne sont pas comparables tels quels.
- **Aucune accumulation ni test séquentiel** : {LW-14}. Agrégation par le maximum sur les commandes ; moyenne sur les jetons pour la lecture des sorties d'outils ({LW-41}) ; moyenne des actions pour la seule sonde de simulation ({LW-42}).
- Aucun sabotage diffus, aucune tâche floue, aucun attaquant qui vise les sondes, aucune garantie de faux positifs par trajectoire, aucune courbe de rappel selon l'horizon.
- Aucune mesure de la conscience d'évaluation : la sonde essayée n'a pas répondu ({LW-22}).

**Limites reconnues.** Un agent, un simulateur, un jeu d'environnements ; six sondes non indépendantes ({LW-29}) ; écart non montré équivalent à zéro (LW26, l. 816) ; 47 tâches écartées ; stratégies d'attaque non comparées.

**Incohérences et résultats trop beaux (symétrie).**
- **Sonde sur politique à 99,8 % : trop beau, réserve.** Elle est entraînée en étiquetant « attaque » toute commande d'une trajectoire d'attaque ({LW-12}), et lit des activations qui reflètent tout le contexte ({LW-13}), consigne d'attaque comprise. Elle sonne sur une commande anodine d'une trajectoire d'attaque ({LW-27}) et tient à 98,6 % avec un dixième des données ({LW-18}). Lecture la plus simple : elle détecte la présence de la consigne dans le contexte, non l'acte de sabotage. Les auteurs ne discutent pas cette lecture. Elle rejoint le contre-indice de portée de 2509.21344 (niveau 2) et l'objection de Sam Marks sous le billet de l'institut ({AL-19}).
- **Deux sondes sur six sont au niveau du hasard par trajectoire.** Refus à 42,8 % et enjeux élevés à 48,3 % d'attrape, quand 26 à 43 % des trajectoires honnêtes sonnent ; le billet le signale par un repère sur sa figure ({LW-44}), dont la valeur par sonde n'est pas imprimée. La « moyenne des six » mêle donc des sondes informatives et des sondes nulles.
- Décomptes cohérents : 1 310 et 1 306 trajectoires attrapées sur 1 313 redonnent 99,77 % et 99,47 % (calcul, d'après {LW-28}).
- Les trajectoires d'attaque et honnêtes n'ont pas la même longueur ({LW-45} ; 65 à 75 commandes honnêtes) et les trajectoires longues sont plus attrapées ({LW-25}) : la longueur est un facteur de confusion du maximum, non corrigé.
- Statut : billet rejeté par la modération ({LW-02}), travail de deux semaines ({LW-26}), revendication de primauté ({LW-05}) limitée à la question simulation contre réel.

**Questions de la consigne.** (a) Aucune comparaison sonde contre boîte noire ; sabotage concentré. (b) Maximum sur les commandes, sans lissage ; aucune somme cumulée, aucun test séquentiel. (c) Travaux annoncés : même question avec un agent plus capable ({LW-24}) ; rien sur la comparaison ni sur l'accumulation. Usage visé des sondes : premier étage d'une cascade ({LW-23} ; {LW-43}).

**Verdicts.**
- H1 : **voisin** (sondes de l'agent comme moniteurs de contrôle sur trajectoires, sans bras boîte noire, concentré). Risque de collision par les articles compagnons (section 6).
- H2 : **occupée en partie** — configuration de référence faite (sondes de l'agent qui agit, seuil par action à 1 % calibré sur l'honnête, maximum sur la trajectoire) ; accumulation additive, garantie toujours valide, sabotage sous le seuil, rappel selon l'horizon : non faits. Donnée utile à H2 : 1 % par action devient 26 à 43 % par trajectoire.
- H8 : **voisin**. Le billet touche l'axe « intention contre conscience d'évaluation » par un côté : les activations portent la trace de la simulation ({LW-30}) sans que les sondes d'attaque en soient déplacées. Il ne mesure pas un construit pour en prédire la robustesse adverse. Indice plutôt favorable aux sondes sur ce point, à tempérer par la réserve sur la sonde sur politique.
- Tr : **voisin** (maximum au niveau action puis trajectoire, employé sans attaquant adaptatif et sans comparaison d'agrégations).
- L, T : **voisin lointain** (donnée empirique : dépendance positive des alarmes à l'intérieur d'une trajectoire honnête).
- HC2 : **ne touche pas** (renvoi à lire : sensibilité des sondes aux fautes de frappe, arXiv 2609.15994, LW26, l. 774).

### 3.2 AISILW, AISIPUB, AISIWHY — institut britannique, 10 juillet 2025

**Ce qu'ils font.** Notes de laboratoire ({AL-02}) en quatre parties : sous-performance sur consigne, tâches simples, Llama-3.1-8B ; passage à Llama-3.3-70B et à une tâche d'agent ; organismes réglés pour sous-performer ; recherche de sous-performance dans les évaluations passées par un moniteur boîte noire. AISIWHY en est le résumé public ; AISIPUB n'est qu'une fiche ({AP-02}).

**Résultats chiffrés (auteurs).**
- Tâches simples : {AL-20} ; {AL-03} ; aucun chiffre dans le texte, un nuage de points en figure ({AL-23}).
- Tâche d'agent : 78 échantillons, {AL-24}, {AL-06} positives ; moniteur boîte noire à 74 % d'aire sous la courbe ({AL-07}) ; sonde à 97 % (moyenne) et 99 % (maximum) ({AL-08}) ; sonde seule au seuil importé : {AL-09}. Écart : 23 à 25 points d'aire (calcul). 88 % de 17 correspond à 15 transcriptions (calcul).
- Organismes réglés : dégradation des sondes, sans chiffre dans le texte ({AL-13}).

**Ce qu'ils ne font pas.** Pas de comparaison à faux positifs égaux ; pas de tâche floue ; pas d'étalement sur une trajectoire de déploiement ; pas d'attaquant ; aucune accumulation entre échantillons (seulement annoncée).

**Limites reconnues.** Moniteur boîte noire désavantagé : il ne voit pas la consigne, la sonde en garde la trace ({AL-05}) ; il est peu travaillé ({AL-18}). Seuil mal fondé ({AL-21}). Cadre jouet ({AW-04}). Motif avancé pour le blanc : la sous-performance {AW-06} ; le noir n'est pas écarté ({AW-07}) et le rôle du blanc reste au conditionnel ({AW-08}). Dégradation des deux méthodes avec la taille et la complexité ({AL-04} ; {AL-12}).

**Incohérences et résultats trop beaux.**
- Aire de 97 à 99 % sur 17 positifs, avec une sonde qui peut lire la consigne : trop beau, réserve (même mécanisme que pour LW26 ; objection {AL-19}).
- « recall at 1% TPR » ({AL-13}) : coquille probable pour « 1 % de faux positifs ».
- Le résumé AISIWHY dit que la précision du moniteur blanc baisse sur la tâche d'agent ; le billet long y rapporte pourtant une aire de 97 à 99 %, supérieure à celle du noir. La « baisse » vise le point de fonctionnement et la marge entre distributions, non l'aire : les deux textes ne se contredisent pas, mais le résumé seul induirait en erreur.

**Questions de la consigne.** (a) Oui, comparaison chiffrée sonde contre moniteur boîte noire, en aire sous la courbe, sur une sous-performance sur consigne (menace de type diffus, tâche vérifiable) ; pas à faux positifs égaux. (b) Moyenne et maximum sur les jetons d'une transcription ; le « problème d'agrégation » est nommé ({AL-11} ; {AL-22}). (c) Oui : accumulation des scores de sondes entre échantillons d'une évaluation ({AL-14} ; {AL-15}) ; sondage sur questions de suivi ; protocoles d'usage ({AL-25}) ; jeux rouge contre bleu ({AW-05}), parus depuis (GAMES, arXiv 2512.07810).

**Verdicts.**
- H1 : **voisin fort** ; en lecture dure, **occupée en partie** pour la composante « comparaison chiffrée blanc contre noir sur sous-performance d'agent ». Non fait : faux positifs égaux, agrégation égale, tâche floue, sabotage étalé. Contre-indices internes : dégradation des deux méthodes ; construit douteux de la sonde ({AL-16}).
- H2 : **voisin** (annonce d'une accumulation de scores de sondes entre échantillons, note 10 ; aucune garantie, aucun résultat). À surveiller : c'est l'annonce la plus proche de H2 dans le lot ; l'article de décembre 2025 est à relire sur ce point précis.
- H8 : **voisin** (question du construit posée : intention de tromper ou simple erreur, consigne ou cognition ; non reliée à la robustesse adverse).
- Tr : **voisin** (moyenne contre maximum au niveau jeton, faux positifs du maximum).
- Autres : ne touche pas.

### 3.3 CASE — « The Case for White Box Control », 18 avril 2025

Billet d'opinion d'un auteur seul, premier billet de l'auteur, sans expérience. Thèse : les méthodes boîte blanche pourraient détecter la tromperie absente des sorties ({CA-02}) et se combinent au noir ({CA-04}). Il propose les sondes comme moniteurs de confiance pour le code piégé ({CA-11}) et pour les tâches difficiles à vérifier ({CA-08}), sans mesure. (a) Aucune comparaison chiffrée. (b) Aucune agrégation sur trajectoire ; seule mention : prédiction au fil des jetons et arrêt de la génération (CASE, l. 99). (c) Aucune annonce.

**Verdicts.** H1 : **voisin au niveau de l'idée** (thèse posée pour le diffus et le flou en une ligne ; aucune mesure ; commentaire contraire de Fabien Roger, {CA-10}). Autres : ne touche pas.

### 3.4 LIE — « Fine-Tuned Lie Detectors Failed to Generalize », 21 août 2026

**Ce qu'il fait.** Détecteurs de mensonge obtenus par réglage fin du modèle lui-même sur une question (« as-tu menti ? »), sur ses propres mensonges, douze cadres, environ 200 000 exemples ; pas de sonde d'activations ({LD-04}). Résultat : {LD-03} ; le détecteur dépasse à peine la consigne simple hors distribution ({LD-10}), base de 0,46 à 0,80 ({LD-09}). Le transfert suit la ressemblance de surface ({LD-05} ; {LD-06}). La lecture à la troisième personne bat l'auto-déclaration ({LD-11}).

**Limites reconnues.** Étiquettes bruitées ({LD-08}) ; cadres contrôlés ({LD-12}) ; les approches par représentations ne sont pas testées ({LD-07}).

**Incohérence.** Le tableau d'accord avec l'annotateur est illisible dans le rendu (colonnes collées, LIE, l. 497 à 507) : aucun chiffre n'en est repris.

**Questions.** (a) Non : pas de sonde ; la comparaison est entre détecteur réglé et modèle interrogé par consigne, en aire sous la courbe, sur des réponses isolées. (b) Non. (c) Non.

**Verdicts.** H8 : **voisin** (ce que le détecteur a appris, la forme de surface du cadre, explique après coup son transfert ; ni sondes, ni attaque, ni prédiction faite avant la mesure). Phrase à citer : {LD-13}. H1 : **ne touche pas** (mais rappel utile : le plus grand modèle, interrogé par simple consigne, atteint 0,98 à 0,99 d'aire sur ces cadres, LIE, l. 394 ; le résumé dit : {LD-02}). HC2 : ne touche pas.

### 3.5 CHEAP — classifieurs à bas coût par réemploi des représentations (2025)

**Ce qu'il fait.** Détection de contournements (armes biologiques) sur l'entrée seulement ({CM-09}) : sondes linéaires sur activations, dernière couche réentraînée, cascades à deux étages. Trois sondes : moyenne des jetons, moyenne mobile exponentielle puis maximum, suffixe. Mesure : aire sous la courbe en espace logarithmique, faux positifs de 0,001 à 0,1 ({CM-07}).

**Résultats (auteurs, qualitatifs dans le texte).** {CM-01} ; la sonde à moyenne mobile se place entre deux classifieurs dédiés ({CM-10}) ; la moyenne simple est la pire ({CM-06}), parce que le signal se dilue sur les entrées longues ({CM-04}). Les valeurs sont dans les figures, absentes du dossier.

**Limites reconnues.** Aucune attaque adaptative ({CM-02}) ; la robustesse des sondes pourrait être pire ({CM-03}) ; la cascade ouvre une attaque sur le premier étage ({CM-08}). Coûts illustratifs seulement.

**Questions.** (a) Oui pour « sonde contre classifieur boîte noire dédié » sur toute une plage de faux positifs, mais sur des requêtes d'utilisateurs, pas sur un sabotage d'agent. (b) Agrégation au niveau jeton dans une entrée : {CM-05}, puis maximum ; aucune trajectoire. (c) Non, sinon l'appel à des essais adverses.

**Verdicts.** H1 : **voisin** (forme de la comparaison à faibles faux positifs ; objet : mésusage, entrée seule ; résultat : la sonde vaut un petit classifieur, pas le meilleur). Tr : **voisin** (prémisse au niveau jeton : la moyenne dilue, moyenne mobile puis maximum ; déjà connue du niveau 2 par 2506.10805). HC2 : **voisin** (les auteurs disent ne pas avoir testé l'attaque et craindre pour les sondes). H2 : ne touche pas (la moyenne mobile porte sur les jetons d'une entrée, sans garantie).

### 3.6 APOLLO — sondes de tromperie (6 février 2025)

Page de présentation de l'article arXiv 2502.03407, sans chiffre. Points utiles : la sonde capte en partie le texte « lié à la tromperie » ({AO-02}) ; la moyenne des jetons peut se tromper quand le détail par jeton est raisonnable ({AO-04}) ; la base boîte noire fait jeu égal ({AO-03}). (a) Comparaison qualitative, sans gain blanc sur noir, sur des réponses où la tromperie se lit dans la transcription. (b) Moyenne par jeton. (c) Souhait : cadres où la tromperie ne se voit pas dans la transcription ({AO-05}).

**Verdicts.** H1 : **voisin, contre-indice faible** (parité avec GPT-4o, base moins travaillée). H8 : **voisin** (construit de surface nommé). Les chiffres que l'état de l'art v1 prête à cet article (ligne 33) ne figurent pas dans cette page : ils relèvent du PDF.

### 3.7 HEBBAR — menaces diffuses (30 avril 2025)

**Ce qu'il fait.** Billet conceptuel, sans expérience. Définit la menace diffuse ({HE-02}), l'axe concentré–diffus, et une frontière de Pareto entre nombre d'actions et discrétion ({HE-07}). Deux parades : entraînement en ligne et incrimination.

**Phrase clé pour H2 et L.** L'incrimination par accumulation de faibles soupçons est jugée impossible sans référence honnête : {HE-03} ; elle ne deviendrait possible que {HE-04}. L'auteur en conclut : {HE-05}. C'est, en creux, la condition de H2 (seuil calibré sur des épisodes honnêtes du même agent) ; l'auteur ne la croit pas disponible et n'envisage ni sonde ni test séquentiel.

**Questions.** (a) Non. (b) Non (idée d'accumulation évoquée et écartée ; entraînement renforcé sur les actions les plus suspectes, {HE-08}). (c) Non.

**Verdicts.** H2 : **voisin, avec contre-indice de position** (l'accumulation de soupçons faibles est jugée non praticable sans connaître la loi honnête ; aucune mesure). L : **voisin** (arbitrage nombre d'actions contre discrétion, {HE-06} ; qualitatif, sans statistique ni budget). T : **voisin lointain** ({HE-09}). H1 : ne touche pas (aucune mention des activations).

### 3.8 NOTES — défaillances non concentrées (29 mars 2025)

**Ce qu'il fait.** Notes conceptuelles sur l'audit en ligne, l'entraînement en ligne, le débat. Mentionne les sondes une fois, comme moyen de choisir les actions à auditer ({NO-02}).

**Points utiles.**
- Audit sans entraînement : contrôle des fausses alertes à partir d'une loi a priori des scores d'un modèle honnête ({NO-03}), avec la même difficulté que chez Hebbar ({NO-04}), et réponse à un motif systématique ({NO-09}).
- Budget de l'attaquant : {NO-05} — forme additive en logarithme ; puis un budget en « bits » ({NO-10}), que l'auteur ne tient pas pour acquis ({NO-06}).
- Détection trop tardive : {NO-07} — voisin de la clause « alarme avant le dommage » de N-004.
- Sabotage indiscernable par les scores : {NO-08} — germe de la moitié négative de T.

**Questions.** (a) Non. (b) Non (aucune statistique). (c) Non.

**Verdicts.** L : **voisin** (budget additif heuristique, détection à temps ; ni énoncé ni sonde). T : **voisin** (moitié négative, non revendiquée). H2 : **voisin** (contrôle des fausses alertes sur référence honnête, posé en principe). H1 : ne touche pas.

### 3.9 DIFFUSE — « Diffuse AI Control on Fuzzy Tasks », 23 juin 2026 (base du programme, arXiv 2606.08892)

**Ce qu'il fait.** Jeu entre une équipe bleue (consigne d'un noteur faible de confiance, Haiku 4.5 : {DI-05}) et une équipe rouge (consigne du générateur, Opus 4.6), sur des propositions d'expériences ({DI-11}) ; vérité approchée par Sonnet 4.6 avec l'article ({DI-04}). L'attaquant est contraint de rester près du score faible optimal : {DI-10}. Résultats qualitatifs dans le texte : attaques qui font noter Opus 4.6 plus bas que GPT-OSS-20B par la vérité approchée ({DI-06}) ; consigne bleue robuste trouvée, mais avec un accès irréaliste ({DI-07}). Aucun chiffre dans le texte du billet (valeurs en figures, absentes du dossier).

**Ce qu'il ne fait pas.** Aucune activation, aucune sonde, aucun moniteur par action, aucune trajectoire ni horizon mesuré (malgré {DI-08}), aucun taux de faux positifs. La « détection » n'est pas l'objet : le cadre est l'entraînement contre un score.

**Position.** {DI-02} (suite ligne 61). Pistes bleues citées : débat, cognition factorisée, surveillance non fiable ({DI-09}) ; pas de boîte blanche.

**Questions.** (a) Non. (b) Non. (c) Non pour ces points.

**Verdicts.** H1 : **ne touche pas la mesure ; contre-indice de position** (la surveillance est dite moins prometteuse que l'entraînement pour le diffus ; opinion appuyée sur deux références, sans mesure propre). H2 : ne touche pas. T : **voisin lointain** (attaquant contraint sur la moyenne d'un score, dommage mesuré ailleurs : forme « statistique préservée, dommage libre »). L : ne touche pas. L'adaptativité de l'attaquant est dite nécessaire ({DI-12}) : à retenir pour le bras d'attaque du papier A.

### 3.10 LOGIT — courbes de discrimination en espace logit (12 avril 2026)

**Ce qu'il fait.** Moniteur de confiance boîte noire, note de 0 à 100 par action, BashArena (400 trajectoires d'attaque pour chacune de 4 tâches annexes, {LR-10}) et LinuxArena (96 honnêtes, 111 attaques). Loi empirique : {LR-02}, soit des scores honnêtes et d'attaque de loi logistique. Convention : vrais positifs par trajectoire ({LR-03}), faux positifs par action ({LR-04}), budgets très bas ({LR-05}). Aucun chiffre de performance dans le texte.

**Points utiles à H2 et L.** Même convention que LW26 : seuil par action, trajectoire attrapée au maximum. La loi nulle d'une attaque manquée est simulée comme le maximum d'autant de tirages que la trajectoire a d'actions ({LR-06}) : dépendance explicite du maximum à la longueur, sous indépendance supposée. Le jeu d'attaque ne garde que le pas le plus suspect ({LR-11}).

**Limites reconnues.** Loi valable à attaquant, tâche, moniteur et consigne fixés ({LR-07}) ; rompue si la discrétion varie ({LR-08}) ; moniteurs faibles qui manquent l'attaque ({LR-09}). La consigne d'attaque suggère elle-même d'étaler l'attaque ({LR-12}), sans mesure par degré d'étalement.

**Questions.** (a) Non (aucune sonde). (b) Maximum sur les actions, boîte noire ; aucune somme. (c) Non.

**Verdicts.** H2 : **voisin** (convention du moniteur par action et du maximum, boîte noire, concentré). L : **voisin** (loi du maximum selon la longueur, descriptif ; outil d'extrapolation aux faibles faux positifs utile au préenregistrement de G1). H6, H1 : ne touche pas.

### 3.11 BLOCK — défaillances immédiates et moniteurs synchrones (30 mars 2026)

Billet de cadrage, sans mesure. Distingue détection et prévention, latence d'attaque, taux de dommage ({BL-03}), défaillances immédiates ({BL-02}). Les moniteurs bloquants lisent action par action ({BL-04}). Un commentaire relève que l'expérience subtilement faussée n'a pas de point de contrôle naturel ({BL-05}). (a), (b), (c) : non.

**Verdicts.** L (clause « alarme avant le dommage ») : **voisin** (vocabulaire : délai de grâce, taux de dommage ; aucun énoncé). H2, H6 : ne touche pas.

### 3.12 RETRY — réessai contre ré-échantillonnage (29 mai 2026, résumé d'arXiv 2605.26047)

**Ce qu'il fait.** BashArena, {RE-12} ; tâches annexes traitées comme défaillances immédiates ; budget d'audit de 0,3 % des pas ({RE-08}).

**Résultats (auteurs).**
- Agrégation des ré-échantillons : {RE-02} ; le bon choix dépend des corrélations ({RE-10}).
- Audit après trois alertes : {RE-03} ; explication : {RE-04} ; la décision d'audit ne dépend d'aucun score passé ({RE-13}).
- Ré-échantillonnage : {RE-06}, dont 6,2 points pour un dixième du coût (soit 61 % du gain, calcul) ; {RE-05} ; exécuter l'échantillon le moins suspect : {RE-11}.
- Réessai avec retour du moniteur : {RE-07} ; même sans retour, fuite d'information ({RE-09}).

**Ce qu'il ne fait pas.** Aucune sonde ; aucun sabotage diffus ; pas de sélection d'attaque dans l'essentiel des résultats ; pas de courbe « succès de l'attaque contre utilité » selon l'intensité d'une perturbation.

**Questions.** (a) Non. (b) Maximum ou minimum sur des ré-échantillons d'un même pas ; comptage d'alertes sur l'historique, sans gain ; aucune somme cumulée ni garantie. (c) Travaux annoncés sur les protocoles de réessai et la stratégie d'abandon.

**Verdicts.**
- H6 : **occupée en partie** (lecture dure) pour le ré-échantillonnage : un gain de sécurité à coût d'utilité nul est publié, à deux intensités de coût. Réserves : cadre concentré ; gain obtenu par l'audit et non par l'affaiblissement de l'attaque ; la variante « exécuter le moins suspect », seule à réduire directement la progression de l'attaque, ne gagne que peu et rien contre un attaquant optimal ; le réessai n'offre aucune marge. Lecture douce : « voisin fort ». Ce qui resterait revendicable : la marge mesurée comme chute du succès du sabotage **diffus** plus rapide que l'utilité, à intensité fixée, sans passer par l'audit.
- H2 : **contre-indice** déjà au dossier (lot2-A1), précisé : compter les alertes passées n'aide pas quand le moniteur lit déjà l'historique. Portée : boîte noire, concentré ; une sonde lit, elle aussi, un état qui reflète l'historique ({LW-13}), ce qui rend la question ouverte pour H2.
- T : **voisin** (agrégateur optimal selon des corrélations que l'attaquant choisit ; déjà relevé au niveau 2).
- H7 (hors lot, pour mémoire) : la riposte visible fuit de l'information.

### 3.13 GAMES — jeux d'audit de la sous-performance (9 décembre 2025, résumé d'arXiv 2512.07810)

Cinq modèles à verrou par mot de passe ({AG-06}), dix méthodes. Boîte noire : échec ({AG-02} ; {AG-07}). Boîte blanche : plus prometteuse ({AG-03}), puis mise en défaut par des comportements de diversion ({AG-04} ; {AG-05}). Aucun chiffre dans le billet. (a) Comparaison qualitative, par modèle entier, sur sous-performance ; pas de faux positifs fixés. (b) Non décrit. (c) Appel à des sondes plus robustes.

**Verdicts.** H1 : **voisin** (énoncé qualitatif blanc plus prometteur que noir pour la sous-performance, avec contre-résultat ; conforme au verdict du niveau 2 sur le PDF). H8 : **voisin** (sondes trompées par des corrélats introduits à dessein). HC2 : **voisin** (faux positifs provoqués par l'équipe rouge, par entraînement du modèle et non par contenu). H2 : ne touche pas.

### 3.14 REDTEAM — équipe rouge du contrôle (23 juillet 2026)

Moniteurs visés : modèles de langage qui lisent actions ou raisonnement ({RT-02}) ; aucune sonde. Failles trouvées dans chaque version ({RT-03}) ; recherche évolutive d'attaques ({RT-04}) ; bruit du score à prendre en compte ({RT-05}) ; estimation de la sécurité d'ensemble ouverte ({RT-06}). (a), (b) : non. (c) Travaux annoncés côté attaque.

**Verdicts.** H1, H2 : **ne touche pas** (contexte : la base boîte noire de G1 doit être éprouvée par une recherche d'attaques, pas par des attaques à consigne fixe). HC2 : ne touche pas (aucune sonde).

### 3.15 STRESS — surveillance asynchrone d'agents de code (16 décembre 2025, résumé d'arXiv 2512.13526)

Agent Claude 4.1 Opus, moniteur Claude 3.7 Sonnet, taux de faux positifs imposé à 1 % ({ST-02}) ; l'équipe rouge ne modifie que la consigne ({ST-05}). Le moniteur de la première manche manquait jusqu'à 67 % des attaques, celui de la troisième 6 % au pire ({ST-03}). Un moniteur faible synchrone bat le meilleur asynchrone ({ST-04}). (a) Non (boîte noire seule, sabotage concentré). (b) Non décrit dans le billet. (c) Attaques automatisées, réglage fin côté rouge ({ST-06}).

**Verdicts.** H1 : **voisin de contexte** (comparateur boîte noire à 1 % de faux positifs, concentré). H2 : ne touche pas.

## 4. Verdicts d'ensemble par énoncé (billets du lot seulement)

| Énoncé | Verdict d'ensemble | Sources décisives | Ce qui change |
|---|---|---|---|
| **H1** | **Non occupée.** Voisin fort : AISILW (comparaison en aire sous la courbe, sous-performance d'agent). Contre-indice de position : DIFFUSE. Contre-indice faible : APOLLO (parité). | AISILW l. 193-195 ; DIFFUSE l. 60 ; APOLLO l. 107 ; LW26 (pas de bras noir) | Rien dans l'énoncé. À citer : la mesure de l'institut, avec ses réserves. Urgence : lire 2610.12445 et 2610.31593. |
| **H2 (N-007)** | **Occupée en partie pour la configuration de référence** (LW26) ; conjonction revendiquée libre. Contre-indice de position : HEBBAR. Annonce voisine : AISILW, note 10. | LW26 l. 136, 252, 254 ; HEBBAR l. 87 ; AISILW l. 407 ; RETRY l. 99 | Le « moniteur par action à 1 % sur sondes de l'agent, maximum sur la trajectoire » se cite, ne se revendique pas. Reste revendicable, inchangé : accumulation additive toujours valide, actions sous le seuil, rappel croissant avec l'horizon, calibrage sans exemple de sabotage. |
| **H8** | **Non occupée.** Voisins : LW26 (trace de simulation sans effet sur les sondes), LIE (la surface explique le transfert), AISILW et APOLLO (construit douteux). | LW26 l. 152, 404 ; LIE l. 436 ; AISILW l. 135, 454 | Rien. LW26 est à citer comme premier contrôle « simulation contre réel » pour des sondes. |
| **HC2** | **Ne touche pas** (aucune attaque par contenu sur une sonde dans le lot). Voisins : CHEAP (crainte exprimée), GAMES (faux positifs provoqués par entraînement). | CHEAP l. 37 ; GAMES l. 75 | Rien. |
| **H6 (N-013)** | **Occupée en partie pour le ré-échantillonnage, en concentré** (RETRY, lecture dure) ; à trancher sur le PDF. | RETRY l. 63, 94, 105, 120, 122 | Si la lecture dure est retenue : préciser que la marge revendiquée porte sur le sabotage diffus et se mesure sur le succès de l'attaque, hors audit. Décision de Lazar (modification de revendication). |
| **L (N-004)** | **Non occupée.** Voisins : NOTES (budget additif heuristique, détection trop tardive), HEBBAR (nombre contre discrétion), LOGIT (maximum selon la longueur), LW26 (dépendance des alarmes dans une trajectoire). | NOTES l. 149, 151, 161 ; HEBBAR l. 71, 75 ; LOGIT l. 120 | Rien. Deux précédents conceptuels à citer (Greenblatt, Hebbar). |
| **T (N-003)** | **Non occupée.** Voisins lointains de la moitié négative, non revendiquée : NOTES, DIFFUSE, RETRY. | NOTES l. 147 ; DIFFUSE l. 111 ; RETRY l. 92 | Rien. |
| **Tr** | **Non occupée.** Voisins : LW26 (maximum action puis trajectoire, sans attaquant), CHEAP et AISILW (moyenne, maximum, moyenne mobile au niveau jeton). | LW26 l. 136, 252 ; CHEAP l. 55 ; AISILW l. 206 | Rien. |

**Bases de G1 (N-007, N-056), pour mémoire.** La cascade « sonde en premier étage, puis moniteur qui lit la transcription » est décrite comme usage courant (LW26, l. 770 et 806 ; CHEAP, cascades à deux étages) : la base (ii) est une pratique publiée, à citer.

## 5. Réponse groupée aux trois questions de la consigne

| Billet | (a) comparaison chiffrée sonde contre boîte noire, à faux positifs égaux | Type de sabotage | (b) agrégation de scores de sondes sur une trajectoire | (c) annonce |
|---|---|---|---|---|
| LW26 | non (aucun bras boîte noire) | concentré (tâche annexe) | maximum sur les commandes ; aucun lissage ; aucune garantie par trajectoire | agent plus capable |
| AISILW, AISIWHY | oui en aire sous la courbe (74 % contre 97 à 99 %) ; non à faux positifs égaux | sous-performance sur consigne, tâche vérifiable | moyenne et maximum sur les jetons d'une transcription | accumulation entre échantillons, protocoles, jeux rouge contre bleu |
| CASE | non | — | non | non |
| LIE | non (pas de sonde) | mensonges en réponse isolée | non | non |
| CHEAP | oui sur une plage de faux positifs, contre classifieurs dédiés ; valeurs en figures | mésusage (requêtes) | moyenne mobile puis maximum, sur les jetons d'une entrée | essais adverses souhaités |
| APOLLO | qualitative : parité avec GPT-4o | tromperie en réponse isolée | moyenne par jeton | cadres sans indice dans la transcription |
| HEBBAR, NOTES | non | diffus (conceptuel) | non ; accumulation évoquée et jugée impraticable sans référence honnête | non |
| DIFFUSE | non | diffus sur tâche floue | non | non |
| LOGIT, BLOCK, RETRY, STRESS, REDTEAM | non (boîte noire seule) | concentré | boîte noire : maximum sur les actions ; maximum ou minimum sur ré-échantillons ; trois alertes sans gain | réessai, attaques automatisées |
| GAMES | qualitative, par modèle | sous-performance (verrou par mot de passe) | non décrit | sondes plus robustes |

**Constat d'ensemble.** Dans les dix-sept textes : aucune comparaison sonde contre moniteur boîte noire à faux positifs égaux sur un sabotage diffus ; aucune somme cumulée ni test séquentiel à garantie sur des scores de sondes le long d'une trajectoire ; une seule annonce proche (institut britannique, accumulation entre échantillons).

## 6. Pistes à lire, non lues ici (renvois des billets, non opposables)

- **arXiv 2610.12445** — sonde de tromperie avec poids publiés pour Qwen3.5-27B ; selon LW26 (l. 770), attrape le sabotage d'agent sur SHADE-Arena et BashArena. **Priorité 1 pour H1** (et pour la ligne « Liars' Bench et SHADE-Arena à T0.8 » de N-061).
- **arXiv 2610.31593** — évaluations de contrôle simulées ; cinq moniteurs qui lisent la transcription sur LinuxArena (LW26, l. 48 et 766). Priorité 1 avec le précédent.
- **arXiv 2609.15994** — sondes qui perdent en précision sur de simples fautes de frappe (LW26, l. 774) : pour HC2 et H8.
- **Rapport de risque d'Anthropic d'août 2026** — sonde qui trie les appels d'outils pour un moniteur (LW26, l. 770) : cascade en production.
- **arXiv 2512.07810** (déjà lu au niveau 2) — à relire sur un seul point : l'accumulation de scores de sondes entre échantillons annoncée dans AISILW, note 10.
- **arXiv 2605.26047** (déjà lu au niveau 2 pour H2 et T) — à relire pour H6.
- **arXiv 2512.22154** (latence d'attaque, synchrone contre asynchrone), **2512.13526**, **2604.15384** (LinuxArena) — contexte.

## 7. Contrôle des citations

- Script : `controle_citations.py` (archive), lancé par `python3 -I`. Il vérifie que chaque citation figure dans la ligne citée du rendu `.txt` après normalisation (Unicode, guillemets et apostrophes, espaces), que chaque citation du fichier figure mot pour mot dans ce rapport, et que tout identifiant du rapport existe dans le fichier de citations.
- Essais préalables : cas juste, 0 échec (attendu 0) ; citation altérée, 1 échec (attendu 1) ; ligne décalée, 1 échec (attendu 1).
- Premier passage sur les textes : 201 citations, 2 échecs (une ligne mal relevée, une citation à cheval sur deux lignes) ; corrigées.
- **Résultat final : @@RESULTAT@@.**
- Heure de l'assemblage : @@HEURE@@ (relevée par `date -u`).

## Annexe — liste complète des citations contrôlées

| Identifiant | Fichier | Ligne | Citation exacte |
|---|---|---|---|
@@ANNEXE@@
