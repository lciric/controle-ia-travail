"""Assemble le rapport : remplace {ID} par « citation » (ABR, l. N) [ID] et ajoute l'annexe.
python3 -I assembler_rapport.py citations.tsv rapport-gabarit.md sortie.md "RESULTAT" "HEURE" """
import re, sys
tsv, gab, sortie, resultat, heure = sys.argv[1:6]
cit = {}
ordre = []
for l in open(tsv, encoding="utf-8"):
    l = l.rstrip("\n")
    if l.strip():
        i, a, n, t = l.split("\t", 3)
        cit[i] = (a, n, t); ordre.append(i)
g = open(gab, encoding="utf-8").read()
vus = set()
def rempl(m):
    i = m.group(1)
    if i not in cit:
        raise SystemExit("identifiant inconnu dans le gabarit : " + i)
    vus.add(i)
    a, n, t = cit[i]
    return f"« {t} » ({a}, l. {n}) [{i}]"
g = re.sub(r"\{([A-Z]{2}-\d{2})\}", rempl, g)
lignes = []
for i in ordre:
    a, n, t = cit[i]
    assert "|" not in t, i
    lignes.append(f"| {i} | {a} | {n} | {t} |")
g = g.replace("@@ANNEXE@@", "\n".join(lignes)).replace("@@RESULTAT@@", resultat).replace("@@HEURE@@", heure)
open(sortie, "w", encoding="utf-8").write(g)
print("citations employées dans le corps :", len(vus), "sur", len(ordre))
print("non employées dans le corps :", " ".join(i for i in ordre if i not in vus))
