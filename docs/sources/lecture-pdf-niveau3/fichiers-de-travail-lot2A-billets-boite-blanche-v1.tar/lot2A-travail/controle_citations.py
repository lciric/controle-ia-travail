"""Contrôle des citations du rapport lot 2-A (billets). Lancer : python3 -I controle_citations.py DOSSIER_TXT citations.tsv [rapport.md]
Chaque citation (identifiant, fichier, ligne, texte exact) doit figurer dans la ligne citée du rendu .txt,
après normalisation (Unicode NFKC, guillemets et apostrophes typographiques, espaces).
Si un rapport est donné : toute citation du fichier doit y figurer mot pour mot, et tout identifiant
[XX-nn] du rapport doit exister dans le fichier de citations."""
import re, sys, unicodedata, hashlib

FICHIERS = {
 "LW26": "lw-2026-probe-monitors-perform-realistically-in-simulated.txt",
 "AISILW": "aisi-2025-lesswrong-white-box-control-update-sandbagging.txt",
 "AISIPUB": "aisi-2025-publication-white-box-control-update-sandbagging.txt",
 "AISIWHY": "aisi-2025-why-were-working-on-white-box-control.txt",
 "CASE": "lw-case-for-white-box-control.txt",
 "LIE": "anthropic-2026-lie-detectors.txt",
 "CHEAP": "anthropic-2025-cheap-monitors.txt",
 "APOLLO": "apollo-2025-deception-probes.txt",
 "HEBBAR": "hebbar-2025-redwood-how-can-we-solve-diffuse-threats.txt",
 "NOTES": "redwood-notes-on-handling-non-concentrated.txt",
 "DIFFUSE": "anthropic-2026-diffuse-ai-control.txt",
 "LOGIT": "redwood-logit-rocs-monitor-tpr-is-linear.txt",
 "BLOCK": "redwood-blocking-live-failures-with-synchronous.txt",
 "RETRY": "redwood-retrying-vs-resampling-in-ai-control.txt",
 "GAMES": "aisi-auditing-games-for-sandbagging-detection.txt",
 "REDTEAM": "aisi-how-our-new-control-red-team-is-stress-testing-frontier-monitors.txt",
 "STRESS": "aisi-stress-testing-asynchronous-monitoring-of-ai-coding-agents.txt",
}

def norm(s):
    s = unicodedata.normalize("NFKC", s)
    for a, b in (("’", "'"), ("‘", "'"), ("“", '"'), ("”", '"'), (" ", " "), ("‍", "")):
        s = s.replace(a, b)
    return re.sub(r"\s+", " ", s).strip()

def charger(chemin):
    out = []
    with open(chemin, encoding="utf-8") as f:
        for l in f:
            l = l.rstrip("\n")
            if not l.strip():
                continue
            ident, abr, ligne, texte = l.split("\t", 3)
            out.append((ident, abr, int(ligne), texte))
    return out

def verifier(dossier, citations, rapport=None):
    cache, echecs = {}, []
    for ident, abr, ligne, texte in citations:
        if abr not in cache:
            with open(f"{dossier}/{FICHIERS[abr]}", encoding="utf-8") as f:
                cache[abr] = f.read().split("\n")
        lignes = cache[abr]
        if not (1 <= ligne <= len(lignes)) or norm(texte) not in norm(lignes[ligne - 1]):
            echecs.append((ident, "absente de la ligne citée"))
    if rapport is not None:
        with open(rapport, encoding="utf-8") as f:
            r = f.read()
        rn = norm(r)
        connus = {c[0] for c in citations}
        for ident, abr, ligne, texte in citations:
            if norm(texte) not in rn:
                echecs.append((ident, "citation absente du rapport"))
        for ident in sorted(set(re.findall(r"\[([A-Z]{2}-\d{2})\]", r))):
            if ident not in connus:
                echecs.append((ident, "identifiant du rapport inconnu du fichier de citations"))
    return echecs

if __name__ == "__main__":
    dossier, tsv = sys.argv[1], sys.argv[2]
    rapport = sys.argv[3] if len(sys.argv) > 3 else None
    cit = charger(tsv)
    if "--essai" in sys.argv:
        juste = [cit[3]]
        altere = [(cit[3][0], cit[3][1], cit[3][2], cit[3][3].replace("1.0 points lower", "1.5 points lower"))]
        decale = [(cit[3][0], cit[3][1], cit[3][2] + 2, cit[3][3])]
        a, b, c = verifier(dossier, juste), verifier(dossier, altere), verifier(dossier, decale)
        print("essai cas juste : échecs =", len(a), "(attendu 0)")
        print("essai cas altéré : échecs =", len(b), "(attendu 1)")
        print("essai ligne décalée : échecs =", len(c), "(attendu 1)")
        sys.exit(0 if (len(a), len(b), len(c)) == (0, 1, 1) else 1)
    e = verifier(dossier, cit, rapport)
    print(f"citations contrôlées : {len(cit)} ; échecs : {len(e)}")
    for x in e:
        print("ECHEC", x)
    sys.exit(1 if e else 0)
