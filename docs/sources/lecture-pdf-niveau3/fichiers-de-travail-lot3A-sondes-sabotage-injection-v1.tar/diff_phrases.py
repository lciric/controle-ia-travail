import sys,re,unicodedata
def norm(t):
    t=unicodedata.normalize('NFKC',t)
    t=t.replace('­','')
    t=re.sub(r'-\n(?=[a-z])','',t)
    t=re.sub(r'\s+',' ',t)
    return t
def phrases(path):
    pages=open(path,encoding='utf-8',errors='replace').read().split('\f')
    out=[]
    for i,p in enumerate(pages):
        for s in re.split(r'(?<=[.!?:]) (?=[A-Z(“"])',norm(p)):
            s=s.strip()
            if len(s)>=40: out.append((i+1,s))
    return out
a=phrases(sys.argv[1]); b=phrases(sys.argv[2])
sa={s for _,s in a}; sb={s for _,s in b}
mode=sys.argv[3]
if mode=='stats':
    print('phrases A',len(a),'B',len(b),'A seules',sum(1 for _,s in a if s not in sb),'B seules',sum(1 for _,s in b if s not in sa))
elif mode=='B':
    lo,hi=int(sys.argv[4]),int(sys.argv[5])
    for p,s in b:
        if s not in sa and lo<=p<=hi: print('[p%d] %s'%(p,s[:700]))
elif mode=='A':
    lo,hi=int(sys.argv[4]),int(sys.argv[5])
    for p,s in a:
        if s not in sb and lo<=p<=hi: print('[p%d] %s'%(p,s[:700]))
