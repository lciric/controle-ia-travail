# Journal du lot 3-A (heures relevées par date -u)
- 2026-11-10 11:06 UTC : consigne commune et interdits lus ; empreintes des neuf PDF conformes.
- Extraction : pdftotext (mode -layout et mode brut), pages marquées ; les extraits de texte (dossiers txt/ et brut/) ne sont pas dans l'archive : ils se régénèrent depuis les PDF.
- Différences de versions : diff_phrases.py (phrases normalisées propres à chaque version).
- Citations : brouillon.py -> brouillon.json -> localiser -> citations.json -> verifier. 131 contrôlées, 0 échec ; un échec au premier passage (F4-27) remplacé.
- Tableau 6 de 2610.12445v4 relu en image (page 26).
- Aucun refus, aucune commande git, aucun appel réseau ni de modèle.
- Fin : 2026-11-10T11:16Z.
