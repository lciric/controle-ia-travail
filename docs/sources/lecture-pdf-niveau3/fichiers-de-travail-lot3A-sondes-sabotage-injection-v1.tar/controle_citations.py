#!/usr/bin/env python3
"""Contrôle des citations du rapport lot 3-A.
Usage : python3 -I controle_citations.py verifier citations.json
        python3 -I controle_citations.py localiser brouillon.json citations.json
        python3 -I controle_citations.py autotest
Une citation est tenue pour présente si, après normalisation (NFKC pour les ligatures,
guillemets et tirets unifiés, césures et espaces retirés), elle figure dans le texte de la
page extrait par pdftotext (mode -layout, ou mode brut pour les pages à deux colonnes)."""
import json, re, subprocess, sys, unicodedata
DEPOT = '/home/user/controle-ia-travail/'
PDF = {
 'F4': 'docs/sources/pdf/niveau3-v1/lot3/2610.12445v4.pdf',
 'F1': 'docs/sources/pdf/2610.12445v1.pdf',
 'K2': 'docs/sources/pdf/niveau3-v1/lot3/2607.07368v2.pdf',
 'K1': 'docs/sources/pdf/2607.07368v1.pdf',
 'S':  'docs/sources/pdf/niveau3-v1/lot3/2610.37679v1.pdf',
 'B':  'docs/sources/pdf/niveau3-v1/lot3/2611.11172v1.pdf',
 'L':  'docs/sources/pdf/niveau3-v1/lot3/2610.18408v1.pdf',
 'C':  'docs/sources/pdf/niveau3-v1/lot3/2606.12618v2.pdf',
 'M':  'docs/sources/pdf/niveau3-v1/lot2/2606.30449v1.pdf',
}
_cache = {}
def norm(t):
    t = unicodedata.normalize('NFKC', t)
    for a, b in (('‘', "'"), ('’', "'"), ('“', '"'), ('”', '"'),
                 ('–', '-'), ('—', '-'), ('−', '-'), ('­', '')):
        t = t.replace(a, b)
    t = t.replace('-', '')
    return re.sub(r'\s+', '', t)
def pages(cle, mode):
    k = (cle, mode)
    if k not in _cache:
        cmd = ['pdftotext'] + (['-layout'] if mode == 'layout' else []) + [DEPOT + PDF[cle], '-']
        out = subprocess.run(cmd, capture_output=True).stdout.decode('utf-8', 'replace')
        _cache[k] = [norm(p) for p in out.split('\f')]
    return _cache[k]
def present(cle, page, citation):
    q = norm(citation)
    if not q: return False
    for mode in ('layout', 'brut'):
        ps = pages(cle, mode)
        if 1 <= page <= len(ps) and q in ps[page - 1]:
            return True
    return False
def ou(cle, citation):
    q = norm(citation); r = set()
    for mode in ('layout', 'brut'):
        for i, p in enumerate(pages(cle, mode)):
            if q in p: r.add(i + 1)
    return sorted(r)
def verifier(chemin):
    cs = json.load(open(chemin, encoding='utf-8')); echecs = 0
    for c in cs:
        ok = present(c['pdf'], c['page'], c['citation'])
        if not ok:
            echecs += 1
            print('ECHEC', c['id'], c['pdf'], 'p.', c['page'], '| trouvée p.', ou(c['pdf'], c['citation']), '|', c['citation'][:90])
    print('citations contrôlées : %d ; échecs : %d' % (len(cs), echecs))
    return echecs
def autotest():
    juste = ('B', 1, 'We train step-specific logistic-regression probes only on benign and non-defended trajectories')
    altere = ('B', 1, 'We train step-specific logistic-regression probes only on benign and defended trajectories')
    mauvaise_page = ('B', 4, juste[2])
    r = [present(*juste), present(*altere), present(*mauvaise_page)]
    print('cas juste trouvé :', r[0], '; cas altéré trouvé :', r[1], '; cas juste sur mauvaise page trouvé :', r[2])
    assert r == [True, False, False], 'autotest en échec'
    print('autotest : conforme (juste accepté, altéré rejeté, mauvaise page rejetée)')
if __name__ == '__main__':
    if sys.argv[1] == 'autotest': autotest()
    elif sys.argv[1] == 'verifier': sys.exit(1 if verifier(sys.argv[2]) else 0)
    elif sys.argv[1] == 'localiser':
        br = json.load(open(sys.argv[2], encoding='utf-8')); out = []
        for c in br:
            p = ou(c['pdf'], c['citation'])
            print(c['id'], p if p else 'INTROUVABLE : ' + c['citation'][:80])
            out.append({'id': c['id'], 'pdf': c['pdf'], 'fichier': PDF[c['pdf']], 'page': (c.get('page') or (p[0] if p else 0)), 'citation': c['citation']})
        json.dump(out, open(sys.argv[3], 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
