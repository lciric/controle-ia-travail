"""Découpe le texte par page (pdftotext -layout) en phrases normalisées, avec la page."""
import re, sys, os, unicodedata
def norm(s):
    s = unicodedata.normalize("NFKC", s)
    s = s.replace("­", "")
    s = re.sub(r"-\s*\n\s*", "", s)
    s = re.sub(r"\s+", " ", s)
    return s.strip()
def phrases(d):
    out = []
    for f in sorted(os.listdir(d)):
        p = int(f[1:4])
        t = norm(open(os.path.join(d, f), encoding="utf-8", errors="replace").read())
        for ph in re.split(r"(?<=[.!?:]) (?=[A-Z(\[])", t):
            ph = ph.strip()
            if len(ph) >= 25:
                out.append((p, ph))
    return out
if __name__ == "__main__":
    d, sortie = sys.argv[1], sys.argv[2]
    with open(sortie, "w", encoding="utf-8") as g:
        for p, ph in phrases(d):
            g.write(f"{ph}\n")
    with open(sortie + ".pages", "w", encoding="utf-8") as g:
        for p, ph in phrases(d):
            g.write(f"p{p}\t{ph}\n")
