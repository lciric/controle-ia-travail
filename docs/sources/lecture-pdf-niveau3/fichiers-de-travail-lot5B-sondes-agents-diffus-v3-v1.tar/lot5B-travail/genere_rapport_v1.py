"""Insère les citations contrôlées dans le gabarit et écrit le rapport. Usage : gabarit citations sortie heure"""
import json, re, sys, subprocess
gab, cit, sortie, heure = sys.argv[1:5]
d = json.load(open(cit, encoding="utf-8")); C = {c["id"]: c for c in d["citations"]}
s = open(gab, encoding="utf-8").read()
utilises = set()
def r(m):
    i = m.group(1); utilises.add(i)
    return "« " + C[i]["citation"] + " » [" + i + "]"
s = re.sub(r"\{\{([A-Z]\d+)\}\}", r, s)
noms = {"v3": "2606.08892v3", "v2": "2606.08892v2", "mole": "2609.06966v1", "caught": "2606.04141v1", "onetoken": "2507.08794v3"}
lignes = [f"- [{c['id']}] {noms[c['pdf']]}, p. {c['page']} : « {c['citation']} »" for c in d["citations"]]
s = s.replace("@@ANNEXE@@", "\n".join(lignes)).replace("@@HEURE@@", heure)
s = s.replace("@@N@@", str(len(C))).replace("@@E@@", "0")
open(sortie, "w", encoding="utf-8").write(s)
print("citations au fichier:", len(C), "; insérées dans le corps:", len(utilises), "; seulement en annexe:", sorted(set(C) - utilises))
