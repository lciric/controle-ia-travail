# Journal du lot 5-B (lecteur neuf) — v1

Heures relevées par `date -u`.

- 2026-11-10 10:57 : empreintes des cinq PDF vérifiées contre les compagnons `.sha256` (cinq concordances) ; extraction page par page (`pdftotext -layout`) dans `txt/` (non archivé, régénérable).
- Lecture : 2606.08892v3 p. 1 à 54 et 80 à 84 en entier ; p. 55 à 79 en diagonale (consignes et exemples d'annexe, communs à la v2 sauf I.8 et I.9) et par comparaison automatique. 2609.06966v1 en entier sauf références (p. 13 à 15, parcourues) et tableau 8 des modèles (parcouru). 2606.04141v1 en entier. 2507.08794v3 en entier sauf références (p. 11 à 14, parcourues) et figures 7 à 9 (courbes par clé, non lues à l'image).
- Comparaison v2/v3 : `phrases_v1.py`, `compare_v1.py` (sorties `v3-pas-dans-v2.txt`, `v2-pas-dans-v3.txt`), `chiffres_v1.py`, `titres-v2.txt`, `titres-v3.txt`.
- Contrôle des citations : `controle_citations_v1.py` ; essai `essai_controle_v1.json` (un cas juste réussi, un cas altéré et une mauvaise page en échec, comme attendu) ; premier passage sur 106 citations : 3 échecs (K03, K13, K16 : page ou coupure de colonne), corrigés ; passage final : 115 citations, 0 échec, 0 absente du rapport.
- Calculs du lecteur : `calculs_v1.py`, sortie `calculs-sortie-v1.txt`.
- Rapport produit par `genere_rapport_v1.py` à partir de `gabarit-rapport-lot5B-v1.md` et `citations-lot5B-v1.json`.
- Aucun appel réseau, aucun appel de modèle, aucune commande git, aucune recherche récursive dans le dépôt. Aucun refus de permission ni de classifieur.
- Une fausse piste écartée : l'absence apparente de la ligne « . » dans les tableaux 17 et 19 de 2507.08794v3 venait d'un filtre d'affichage du lecteur ; la ligne existe (vérifié sur le texte de la page).
- Clôture du journal : 2026-11-10 11:10:34.
