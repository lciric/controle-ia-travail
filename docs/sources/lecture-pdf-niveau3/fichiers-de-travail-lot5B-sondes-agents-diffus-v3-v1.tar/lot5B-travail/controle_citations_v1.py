"""Contrôle des citations du rapport du lot 5-B.

Pour chaque citation (PDF, page, texte exact), vérifie qu'elle figure dans le texte de la page
extrait par pdftotext (mode -layout, puis mode ordre de lecture pour les pages à deux colonnes),
après normalisation des espaces, ligatures et césures. Vérifie aussi que chaque citation figure
mot pour mot dans le rapport, si un rapport est donné.
Usage : python3 -I controle_citations_v1.py citations.json [rapport.md]
"""
import json, re, subprocess, sys, unicodedata

def normaliser(s, sans_tirets=False):
    s = unicodedata.normalize("NFKC", s)
    s = s.replace("­", "")
    for a, b in (("‘", "'"), ("’", "'"), ("“", '"'), ("”", '"'), ("′", "'"),
                 ("−", "-"), ("–", "-"), ("—", "-"), ("‐", "-"), ("‑", "-")):
        s = s.replace(a, b)
    if sans_tirets:
        s = s.replace("-", "")
    else:
        s = re.sub(r"-\s*\n\s*", "", s)      # césure de fin de ligne
    return re.sub(r"\s+", "", s)

_cache = {}
def texte_page(pdf, page, mode):
    cle = (pdf, page, mode)
    if cle not in _cache:
        cmd = ["pdftotext"] + (["-layout"] if mode == "layout" else []) + ["-f", str(page), "-l", str(page), pdf, "-"]
        _cache[cle] = subprocess.run(cmd, capture_output=True, text=True, check=True).stdout
    return _cache[cle]

def controler(pdf, page, citation):
    """Renvoie (ok, façon)."""
    for mode in ("layout", "lecture"):
        t = texte_page(pdf, page, mode)
        if normaliser(citation) in normaliser(t):
            return True, mode + "/strict"
    for mode in ("layout", "lecture"):
        t = texte_page(pdf, page, mode)
        if normaliser(citation, True) in normaliser(t, True):
            return True, mode + "/sans-tirets"
    return False, "absent"

def main():
    args = [a for a in sys.argv[1:] if a != "-v"]
    spec = json.load(open(args[0], encoding="utf-8"))
    rapport = open(args[1], encoding="utf-8").read() if len(args) > 1 else None
    echecs = 0; n = 0; hors_rapport = 0
    for c in spec["citations"]:
        pdf = spec["pdf"][c["pdf"]]
        ok, facon = controler(pdf, c["page"], c["citation"])
        n += 1
        dans = True
        if rapport is not None:
            dans = c["citation"] in rapport
            if not dans: hors_rapport += 1
        if not ok: echecs += 1
        if not ok or not dans or "-v" in sys.argv:
            print(f'{"OK " if ok else "ECHEC"} {c["id"]} {c["pdf"]} p.{c["page"]} [{facon}]' + ("" if dans else " [ABSENTE DU RAPPORT]") + f' :: {c["citation"][:90]}')
    print(f"citations contrôlées : {n} ; échecs : {echecs}" + (f" ; absentes du rapport : {hors_rapport}" if rapport is not None else ""))
    return 1 if (echecs or hors_rapport) else 0

if __name__ == "__main__":
    sys.exit(main())
