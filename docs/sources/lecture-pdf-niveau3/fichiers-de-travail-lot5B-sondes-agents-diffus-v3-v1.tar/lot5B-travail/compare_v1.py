"""Phrases de v3 absentes de v2 et inversement (appariement exact puis approché), avec la page."""
import sys, difflib, re
def lire(f): return [l.rstrip("\n").split("\t",1) for l in open(f, encoding="utf-8")]
a = lire("phrases-v2.txt.pages"); b = lire("phrases-v3.txt.pages")
def cle(s): return re.sub(r"[^a-z0-9]", "", s.lower())
A = {cle(s) for _, s in a}; B = {cle(s) for _, s in b}
def absents(x, Y, Ybrut, nom):
    Yl = [cle(s) for _, s in Ybrut]
    n = 0
    with open(nom, "w", encoding="utf-8") as g:
        for p, s in x:
            k = cle(s)
            if k in Y: continue
            m = difflib.get_close_matches(k, Yl, n=1, cutoff=0.6)
            statut = "MODIFIEE" if m else "SANS-PAREIL"
            g.write(f"{p}\t{statut}\t{s}\n")
            if m:
                i = Yl.index(m[0]); g.write(f"\t  ~ {Ybrut[i][0]}\t{Ybrut[i][1]}\n")
            n += 1
    return n
print("v3 pas dans v2:", absents(b, A, a, "v3-pas-dans-v2.txt"))
print("v2 pas dans v3:", absents(a, B, b, "v2-pas-dans-v3.txt"))
