"""Calculs du lecteur (lot 5-B). Chiffres d'entrée : tableaux imprimés des PDF (pages au rapport)."""
def rangs(x):
    s=sorted(range(len(x)),key=lambda i:x[i]); r=[0]*len(x); i=0
    while i<len(s):
        j=i
        while j+1<len(s) and x[s[j+1]]==x[s[i]]: j+=1
        for k in range(i,j+1): r[s[k]]=(i+j)/2+1
        i=j+1
    return r
def spearman(a,b):
    ra,rb=rangs(a),rangs(b); n=len(a); ma=sum(ra)/n; mb=sum(rb)/n
    num=sum((x-ma)*(y-mb) for x,y in zip(ra,rb)); da=sum((x-ma)**2 for x in ra)**.5; db=sum((y-mb)**2 for y in rb)**.5
    return num/(da*db)
noms=["Master-RM-32B","Master-RM-7B","Multi-sub RM","General-Verifier","Omni-Judge","Qwen2.5-72B","Qwen2.5-7B","LLaMA3-70B","LLaMA3-8B","GPT-4o"]
kappa=[0.87,0.90,0.91,0.70,0.81,0.88,0.80,0.81,0.73,0.90]   # 2507.08794v3, tableau 2a, p. 8 (accord avec l'humain)
fpr=[0.8,0.1,1.1,9.7,14.3,66.8,12.6,80.6,76.9,14.6]          # tableau 1, p. 7, ligne « Overall Avg »
print("Spearman kappa humain vs FPR moyen, 10 juges:", round(spearman(kappa,fpr),3))
i=[k for k,n in enumerate(noms) if not n.startswith("Master")]
print("idem sans les deux Master-RM (8 juges):", round(spearman([kappa[k] for k in i],[fpr[k] for k in i]),3))
print("moyenne Qwen72B:", round((51.4+62.3+87.6+78.7+54.0)/5,2), "GPT-4o:", round((10.4+20.2+21.5+17.5+3.6)/5,2))
print("MOLE comptes actifs par jour de test:", round(2106/15,1), "part revue K=10:", round(10/(2106/15)*100,1), "%")
print("MOLE gains RQ5:", round(.298/.187-1,3), round(.586/.357-1,3), round(.269/.181-1,3), "; routage:", round(.629/.571-1,3))
print("MOLE prévalence test:", round(45/2106*100,2), "%")
print("Terekhov tableau 1, v3 ICLR:", 24+253+1903+280, "=", 120+2340, "; v2:", 120+2347, "; total v3:", 33+289+2027+293, "=", 302+2340)
print("Caught NIMBUS: 0.90*50 =", .9*50)
