"""Paires « MODIFIEE » où les nombres diffèrent entre v3 et v2."""
import re
L = open("v3-pas-dans-v2.txt", encoding="utf-8").read().split("\n")
i = 0
while i < len(L) - 1:
    a = L[i].split("\t")
    if len(a) >= 3 and a[1] == "MODIFIEE" and L[i+1].startswith("\t"):
        b = L[i+1].split("\t")
        na = sorted(re.findall(r"\d+(?:[.,]\d+)?", a[2])); nb = sorted(re.findall(r"\d+(?:[.,]\d+)?", b[-1]))
        if na != nb:
            sa, sb = set(na) - set(nb), set(nb) - set(na)
            if sa or sb:
                print(a[0], "v3 seuls:", sorted(sa), "| v2 seuls:", sorted(sb), "|", a[2][:160])
        i += 2
    else:
        i += 1
