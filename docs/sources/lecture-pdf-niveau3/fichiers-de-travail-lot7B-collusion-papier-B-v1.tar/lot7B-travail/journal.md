# Journal — lot 7-B (lecteur neuf), 10 novembre 2026

Heures relevées par `date -u`.

- 11:04 UTC — consigne commune et interdits communs v2 lus ; énoncés du programme (lignes 85 à 125, 190 à 215), décision N-013, sections H6, H8, HC4, H3, H4′, H5, H7, statistique de population de l'antériorité de niveau 2 lus.
- Empreintes des six PDF vérifiées (`sha256sum -c`) : six OK.
- Extraction `pdftotext` (mode -layout pour tous ; mode ordre de lecture en plus pour 2609.03035 v1 et v2 et pour 2602.15198, à deux colonnes ou mal rendus) ; lecture intégrale des cinq articles et de la v1.
- 2609.03035 : `diff` v1/v2 par lignes et par mots ; cartes de chaleur de la v2 (images) lues par l'outil de lecture de PDF, pages 14, 16, 19, 21 ; cartes de la v1 lues dans le texte extrait (pages 12, 14, 15, 17). Constat : rappels à seuil fixe remplacés entre versions à AUROC quasi inchangées.
- 11:10 UTC — script de contrôle des citations écrit ; auto-essai : cas juste accepté, cas altéré refusé, mauvaise page refusée ; premier passage : 130 citations, 0 échec.
- Gabarit du rapport écrit ; trois corrections avant construction (H6 : chiffres de Mini-HF au lieu d'un mélange de deux environnements ; 2610.24052 : taille des équipes ; une citation du résumé de 2611.02153 passée sous contrôle, A29).
- 2026-11-10 11:14 UTC — rapport construit par `construire_rapport.py` (citations insérées par programme) ; contrôle final : 131 citations, 0 échec.
- Aucun refus de permission ni de classifieur. Aucune commande git, aucun appel réseau, aucun appel de modèle, aucune recherche récursive dans le dépôt, aucun fichier ouvert hors de ceux nommés par la consigne.
- Non fait : figures 6, 8, 10, 12 de 2609.03035 v2 non relevées cellule par cellule ; figures de 2610.24052 et de Colosseum lues par texte extrait et légendes ; PDF de NARCBench non ouvert (hors consigne).
