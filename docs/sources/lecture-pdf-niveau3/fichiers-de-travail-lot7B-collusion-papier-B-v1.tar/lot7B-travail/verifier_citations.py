#!/usr/bin/env python3
"""Contrôle des citations du rapport lot 7-B.
Usage : python3 -I verifier_citations.py citations.json   (ou --auto-essai)
Chaque citation (pdf, page, texte) doit figurer dans le texte de la page
extrait par pdftotext (mode -layout ou mode ordre de lecture), après
normalisation : NFKC, ligatures, guillemets, tirets et césures, espaces.
"""
import json, subprocess, sys, unicodedata

RACINE = "/home/user/controle-ia-travail/docs/sources/pdf/"
PDFS = {
    "2611.02153v1": RACINE + "niveau3-v1/lot7/2611.02153v1.pdf",
    "2611.10620v1": RACINE + "niveau3-v1/lot7/2611.10620v1.pdf",
    "2609.03035v2": RACINE + "niveau3-v1/lot6/2609.03035v2.pdf",
    "2609.03035v1": RACINE + "2609.03035v1.pdf",
    "2610.24052v1": RACINE + "niveau3-v1/lot7/2610.24052v1.pdf",
    "2602.15198v2": RACINE + "niveau3-v1/lot7/2602.15198v2.pdf",
}
_cache = {}

def normaliser(s):
    s = unicodedata.normalize("NFKC", s)
    for a, b in (("’", "'"), ("‘", "'"), ("“", '"'), ("”", '"'),
                 ("–", "-"), ("—", "-"), ("−", "-"), ("­", "")):
        s = s.replace(a, b)
    # césures et tirets : on retire tous les tirets et tous les blancs des deux côtés
    s = s.replace("-", "")
    return "".join(s.split())

def page(pdf, n):
    cle = (pdf, n)
    if cle not in _cache:
        textes = []
        for mode in (["-layout"], []):
            r = subprocess.run(["pdftotext", *mode, "-f", str(n), "-l", str(n), PDFS[pdf], "-"],
                               capture_output=True, text=True)
            textes.append(normaliser(r.stdout))
        _cache[cle] = textes
    return _cache[cle]

def controle(c):
    cible = normaliser(c["texte"])
    return len(cible) >= 12 and any(cible in t for t in page(c["pdf"], c["page"]))

def auto_essai():
    juste = {"pdf": "2611.02153v1", "page": 8, "texte": "This makes J-PACT a sequential detector."}
    faux = {"pdf": "2611.02153v1", "page": 8, "texte": "This makes J-PACT a supervised detector."}
    mauvaise_page = {"pdf": "2611.02153v1", "page": 3, "texte": "This makes J-PACT a sequential detector."}
    a, b, c = controle(juste), controle(faux), controle(mauvaise_page)
    print("auto-essai : cas juste =", a, "; cas altéré =", b, "; bonne citation, mauvaise page =", c)
    return a and not b and not c

if __name__ == "__main__":
    if not auto_essai():
        print("AUTO-ESSAI EN ÉCHEC"); sys.exit(2)
    if len(sys.argv) > 1 and sys.argv[1] != "--auto-essai":
        cits = json.load(open(sys.argv[1], encoding="utf-8"))
        echecs = [c for c in cits if not controle(c)]
        for c in echecs:
            print("ÉCHEC", c["id"], c["pdf"], "p.", c["page"], "::", c["texte"][:90])
        print("citations contrôlées : %d ; échecs : %d" % (len(cits), len(echecs)))
        sys.exit(1 if echecs else 0)
