#!/usr/bin/env python3
"""Construit le rapport à partir du gabarit : chaque {{ID}} est remplacé par la
citation exacte de citations.json, suivie de son identifiant et de sa page.
Refuse de construire si un identifiant manque ou si le contrôle des citations échoue."""
import json, re, subprocess, sys
d, sortie, heure = sys.argv[1], sys.argv[2], sys.argv[3]
cits = {c["id"]: c for c in json.load(open(d + "/citations.json", encoding="utf-8"))}
r = subprocess.run([sys.executable, "-I", d + "/verifier_citations.py", d + "/citations.json"], capture_output=True, text=True)
open(d + "/sortie-controle-citations.txt", "w", encoding="utf-8").write(r.stdout + r.stderr)
if r.returncode != 0:
    print(r.stdout); sys.exit("contrôle des citations en échec : rapport non construit")
t = open(d + "/rapport-gabarit.md", encoding="utf-8").read()
utilises = set()
def remplace(m):
    c = cits[m.group(1)]; utilises.add(c["id"])
    return "« %s » (%s, p. %d)" % (c["texte"], c["id"], c["page"])
t = re.sub(r"\{\{([A-Z][0-9]+)\}\}", remplace, t)
annexe = ["| id | PDF | page | citation exacte |", "|---|---|---|---|"]
for c in cits.values():
    annexe.append("| %s | %s | %d | %s |" % (c["id"], c["pdf"], c["page"], c["texte"].replace("|", "\\|")))
t = t.replace("@@ANNEXE@@", "\n".join(annexe)).replace("@@NB@@", str(len(cits))).replace("@@HEURE_FIN@@", heure)
assert "{{" not in t and "@@" not in t
open(sortie, "w", encoding="utf-8").write(t)
print("rapport écrit ;", len(cits), "citations en annexe ;", len(utilises), "insérées dans le corps")
