#!/usr/bin/env python3
"""Vérifie que chaque citation étiquetée du rapport (« texte » [ID, p. N]) figure à l'identique,
avec la même page, dans le fichier des citations contrôlées. Usage : python3 -I controle_rapport_v1.py RAPPORT CITATIONS"""
import re, sys
rap = open(sys.argv[1], encoding="utf-8").read()
cit = {}
for l in open(sys.argv[2], encoding="utf-8"):
    l = l.rstrip("\n")
    if l.strip() and not l.startswith("#"):
        i, pdf, page, txt = l.split("|", 3); cit[i] = (page, txt)
n = bad = 0; vus = set()
for m in re.finditer(r"«\s([^«»]+?)\s»\s\[([A-Z]\d+), p\. (\d+)\]", rap):
    txt, i, page = m.groups(); n += 1; vus.add(i)
    if i not in cit or cit[i] != (page, txt):
        bad += 1; print("ECART", i, page, txt[:60])
# étiquettes sans guillemets conformes
for m in re.finditer(r"\[([A-Z]\d+), p\. \d+\]", rap):
    if m.group(1) not in vus: bad += 1; print("ETIQUETTE NON APPARIEE", m.group(1))
print(f"citations étiquetées dans le rapport : {n} ; identifiants distincts : {len(vus)} ; écarts : {bad} ; au fichier mais non employées : {sorted(set(cit)-vus)}")
sys.exit(1 if bad else 0)
