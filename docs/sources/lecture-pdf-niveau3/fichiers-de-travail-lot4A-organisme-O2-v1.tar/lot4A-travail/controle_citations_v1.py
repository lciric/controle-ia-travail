#!/usr/bin/env python3
"""Contrôle des citations du rapport lot 4-A : chaque citation (PDF, page, texte exact)
doit figurer dans le texte de la page extrait par pdftotext (-layout, puis ordre de lecture),
après normalisation (Unicode NFKC donc ligatures, guillemets, espaces, césures de fin de ligne).
Usage : python3 -I controle_citations_v1.py DOSSIER_PDF FICHIER_CITATIONS [--chercher]
Format du fichier : id|pdf|page|citation   (lignes vides et lignes # ignorées)."""
import re, subprocess, sys, unicodedata

def norm_base(s):
    s = unicodedata.normalize("NFKC", s)
    for a, b in (("’", "'"), ("‘", "'"), ("“", '"'), ("”", '"'),
                 ("–", "-"), ("—", "-"), ("−", "-"), ("­", "")):
        s = s.replace(a, b)
    return s

def variantes(page):
    p = norm_base(page)
    v1 = re.sub(r"-\s*\n\s*", "", p)      # césure recollée sans trait d'union
    v2 = re.sub(r"-\s*\n\s*", "-", p)     # trait d'union gardé
    return [re.sub(r"\s+", " ", v) for v in (v1, v2)]

def norm_cit(c):
    return re.sub(r"\s+", " ", norm_base(c)).strip()

_cache = {}
def texte_page(pdf, n, mode):
    k = (pdf, n, mode)
    if k not in _cache:
        cmd = ["pdftotext"] + (["-layout"] if mode == "layout" else []) + ["-f", str(n), "-l", str(n), pdf, "-"]
        _cache[k] = subprocess.run(cmd, capture_output=True, text=True).stdout
    return _cache[k]

def nb_pages(pdf):
    out = subprocess.run(["pdfinfo", pdf], capture_output=True, text=True).stdout
    return int(re.search(r"Pages:\s+(\d+)", out).group(1))

def present(pdf, n, cit):
    c = norm_cit(cit)
    for mode in ("layout", "lecture"):
        for v in variantes(texte_page(pdf, n, mode)):
            if c in v:
                return True
    return False

def main():
    dossier, fichier = sys.argv[1], sys.argv[2]
    chercher = "--chercher" in sys.argv
    total = echecs = 0
    for ligne in open(fichier, encoding="utf-8"):
        ligne = ligne.rstrip("\n")
        if not ligne.strip() or ligne.startswith("#"):
            continue
        ident, pdf, page, cit = ligne.split("|", 3)
        chemin = f"{dossier}/{pdf}"
        total += 1
        if present(chemin, int(page), cit):
            print(f"OK    {ident} {pdf} p.{page}")
        else:
            echecs += 1
            msg = ""
            if chercher:
                ou = [n for n in range(1, nb_pages(chemin) + 1) if present(chemin, n, cit)]
                msg = f" (trouvée p. {ou})" if ou else " (introuvable)"
            print(f"ECHEC {ident} {pdf} p.{page}{msg} :: {cit[:70]}")
    print(f"citations contrôlées : {total} ; échecs : {echecs}")
    sys.exit(1 if echecs else 0)

if __name__ == "__main__":
    main()
