# Journal du lecteur, lot 4-A (heures par date -u, 10 novembre 2026)
- 11:12 lecture de la consigne commune, des interdits v2, de N-064, N-065, N-058, de la note POPPER ; empreintes des neuf PDF vérifiées (neuf OK) ; extraction page par page (pdftotext -layout) dans txt/.
- lecture : Sargsyan, CONFIRM, « Hard to Fool », 2611.04420 en entier ; N×N, CADS, Hegazy, 2610.11289, 2611.00643 : corps en entier, annexes en partie et par recherche de termes (détail au § 1 du rapport).
- script de contrôle écrit, essayé sur un cas juste (code 0) et un cas altéré (code 1) ; 116 citations, 0 échec après correction de deux pages (D14, Y13) et de trois libellés alignés sur le rapport (C12, N6, P7).
- second contrôle rapport ↔ fichier de citations : 116 étiquettes, 0 écart.
- 11:20 rapport fini ; archive et scellement.
- Aucun refus de permission ni de classifieur. Aucun appel réseau ni de modèle. Aucune commande git.
