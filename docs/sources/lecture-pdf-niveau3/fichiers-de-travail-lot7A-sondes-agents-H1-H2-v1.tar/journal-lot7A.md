# Journal du lot 7-A (heures relevées par date -u, 10 novembre 2026)
- 11:04 UTC : empreintes des trois PDF vérifiées contre les compagnons ; extraction page par page (pdftotext -layout dans pages/, ordre de lecture dans brut/, copies resserrées dans lus/).
- Lecture intégrale : 2610.17301v1 (42 p.), 2610.40588v1 (49 p.), 2610.39377v1 (33 p.). Fichiers du dépôt ouverts : consigne commune, interdits communs v2, programme v2 (lignes 85-125, 190-215), décisions N-007/N-008, N-013, N-056, antériorité niveau 2 (en-tête, H1, H2, Tr, H8, HC3). Aucun fichier du bras d'attaque ouvert ; aucune recherche récursive ; aucun appel réseau ni de modèle ; aucune commande git.
- 11:07 UTC : script de contrôle des citations écrit, garde essayée (juste, altéré, mauvaise page), 73 citations, 0 échec.
- 11:09 UTC : rapport écrit, archive et scellement.
- Refus rencontrés : aucun.
