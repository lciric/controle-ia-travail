"""Contrôle des citations du lot 7-A : chaque citation doit figurer dans le texte de sa page
(pdftotext, mise en page ou ordre de lecture), après normalisation. Lancer avec python3 -I."""
import json, sys, unicodedata, re, pathlib

def norm(s):
    s = unicodedata.normalize("NFKC", s)
    for a, b in (("’", "'"), ("‘", "'"), ("“", '"'), ("”", '"'), ("−", "-"), ("–", "-"), ("—", "-"), ("­", "")):
        s = s.replace(a, b)
    s = s.replace("-", "")          # césures et traits d'union
    return re.sub(r"\s+", "", s)    # espaces et sauts de ligne

def page_texts(base, pdf, page):
    out = []
    for d in ("pages", "brut"):
        p = pathlib.Path(base) / d / f"{pdf}-p{page:02d}.txt"
        if p.exists():
            out.append(p.read_text(encoding="utf-8", errors="replace"))
    return out

def controle(base, cits):
    echecs = []
    for c in cits:
        q = norm(c["q"])
        if len(q) < 12 or not any(q in norm(t) for t in page_texts(base, c["pdf"], c["page"])):
            echecs.append(c["id"])
    return echecs

if __name__ == "__main__":
    base, fichier = sys.argv[1], sys.argv[2]
    cits = json.loads(pathlib.Path(fichier).read_text(encoding="utf-8"))
    # essais de la garde : un cas juste, un cas altéré (échec attendu), une mauvaise page (échec attendu)
    juste = [cits[0]]
    altere = [dict(cits[0], id="ALT", q=cits[0]["q"].replace("0.94", "0.49"))]
    mauvaise_page = [dict(cits[0], id="PAGE", page=cits[0]["page"] + 1)]
    assert controle(base, juste) == [], "le cas juste devrait passer"
    assert controle(base, altere) == ["ALT"], "le cas altéré devrait échouer"
    assert controle(base, mauvaise_page) == ["PAGE"], "la mauvaise page devrait échouer"
    print("essais de la garde : cas juste passé, cas altéré refusé, mauvaise page refusée")
    ech = controle(base, cits)
    print(f"citations contrôlées : {len(cits)} ; échecs : {len(ech)} {ech}")
    if "--annexe" in sys.argv:
        for c in cits:
            print(f"| {c['id']} | {c['pdf']} | {c['page']} | « {c['q']} » |")
    sys.exit(1 if ech else 0)
