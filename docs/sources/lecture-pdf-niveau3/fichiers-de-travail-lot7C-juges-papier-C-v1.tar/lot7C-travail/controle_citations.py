#!/usr/bin/env python3
"""Contrôle des citations du rapport lot 7-C.
Usage : python3 -I controle_citations.py citations.json DOSSIER_PDF [--localiser]
Chaque citation : {"id", "pdf", "page", "citation"}. La citation doit figurer dans le texte
de la page extrait par pdftotext (mode -layout, ou mode par défaut pour les pages à deux colonnes),
après normalisation (NFKC, ligatures, guillemets, tirets, césures, espaces)."""
import json, re, subprocess, sys, unicodedata

def extraire(pdf, page, layout=True):
    cmd = ["pdftotext"] + (["-layout"] if layout else []) + ["-f", str(page), "-l", str(page), pdf, "-"]
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout

def normaliser(t, cesure):
    t = unicodedata.normalize("NFKC", t)
    for a, b in (("­", ""), ("’", "'"), ("‘", "'"), ("“", '"'), ("”", '"'), ("–", "-"), ("—", "-"), ("−", "-"), ("‐", "-"), ("‑", "-")):
        t = t.replace(a, b)
    t = re.sub(r"-\s*\n\s*", cesure, t)   # césure de fin de ligne : supprimée ("") ou gardée ("-")
    t = re.sub(r"\s+", " ", t)
    return t.strip()

def variantes(texte):
    return [normaliser(texte, ""), normaliser(texte, "-")]

def contient(pdf, page, citation):
    c = normaliser(citation, "-")
    for layout in (True, False):
        for v in variantes(extraire(pdf, page, layout)):
            if c in v:
                return True
    return False

def nb_pages(pdf):
    s = subprocess.run(["pdfinfo", pdf], capture_output=True, text=True, check=True).stdout
    return int(re.search(r"Pages:\s+(\d+)", s).group(1))

def main():
    fichier, dossier = sys.argv[1], sys.argv[2]
    localiser = "--localiser" in sys.argv
    cits = json.load(open(fichier, encoding="utf-8"))
    echecs = 0
    for c in cits:
        pdf = dossier.rstrip("/") + "/" + c["pdf"]
        ok = contient(pdf, c["page"], c["citation"])
        if not ok:
            echecs += 1
            msg = f"ECHEC {c['id']} {c['pdf']} p.{c['page']}"
            if localiser:
                ou = [p for p in range(1, nb_pages(pdf) + 1) if contient(pdf, p, c["citation"])]
                msg += f" ; trouvée pages {ou}"
            print(msg)
    print(f"citations contrôlées : {len(cits)} ; échecs : {echecs}")
    return 1 if echecs else 0

if __name__ == "__main__":
    sys.exit(main())
