#!/usr/bin/env python3
"""Vérifie que chaque citation « … » (p. N) [ID] du rapport est, mot pour mot et page pour page, une entrée de citations.json,
et liste les passages entre guillemets français en anglais qui ne portent pas d'identifiant."""
import json, re, sys
t = open(sys.argv[1], encoding="utf-8").read()
c = {x["id"]: x for x in json.load(open(sys.argv[2], encoding="utf-8"))}
ko = 0; vus = set()
for m in re.finditer(r"« ([^»]+?) » \(p\. (\d+)\) \[([A-Z]\d+)\]", t):
    q, p, i = m.group(1), int(m.group(2)), m.group(3); vus.add(i)
    if i not in c or c[i]["citation"] != q or c[i]["page"] != p:
        ko += 1; print("DIVERGENCE", i, p, q[:60])
ids = set(re.findall(r"\[([A-Z]\d+)\]", t))
print("identifiants cités dans le rapport :", len(ids), "; appariés texte+page :", len(vus), "; divergences :", ko)
print("cités sans motif complet :", sorted(ids - vus))
print("entrées de citations.json non utilisées :", sorted(set(c) - ids))
sans = [m.group(0)[:90] for m in re.finditer(r"« [^»]+ »(?! \(p\. \d+\) \[)(?!, p\. \d+ \[)", t)]
print("guillemets sans identifiant :"); [print("  ", s) for s in sans]
