#!/usr/bin/env python3
"""Calcul du lecteur (nature « calcul ») : sur le tableau 13 de 2610.29178v1 (p. 35), le taux de blocage
sous gabarits non optimisés classe-t-il les familles de moniteurs comme le taux sous charges optimisées
contre la famille elle-même ? Quatre familles seulement : non concluant par construction."""
T={"Qwen":[0.067,0.050,0.067,0.017,0.100,0.017,0.083,0.100],"Gemma":[0,0,0,0,0.017,0,0.017,0],
   "Llama":[0.017,0.017,0.017,0.067,0.050,0.017,0.017,0.033],"Ministral":[0.717,0.900,0.667,0.867,0.650,0.867,0.683,0.867]}
O={"Qwen":[0.517,0.750],"Gemma":[0.000,0.250],"Llama":[0.817,0.067],"Ministral":[0.917,1.000]}
def rangs(d):
    o=sorted(d,key=lambda k:-d[k]); return {k:i+1 for i,k in enumerate(o)}
mt={k:sum(v)/len(v) for k,v in T.items()}
for nom,m in (("maximum des deux charges optimisées propres",{k:max(v) for k,v in O.items()}),
              ("moyenne des deux charges optimisées propres",{k:sum(v)/2 for k,v in O.items()})):
    r1,r2=rangs(mt),rangs(m); d2=sum((r1[k]-r2[k])**2 for k in r1)
    print(nom,"| gabarits:",{k:round(v,3) for k,v in mt.items()},"| optimisées:",{k:round(v,3) for k,v in m.items()},"| Spearman =",1-6*d2/(4*15))
