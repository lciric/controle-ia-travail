# Journal du lot 7-C
- Début : 2026-11-10 11:04 UTC (date -u). Fin : 2026-11-10T11:14Z (date -u).
- Empreintes des cinq PDF vérifiées contre les compagnons .sha256 : conformes.
- Lecture intégrale par pdftotext -layout page par page (dossier texte/ : .txt brut, .lu espaces réduits) ; pages lues en image : 2602.08877 p. 5-6 ; 2603.19262 p. 4-10.
- Contrôle des citations : essai juste réussi, essai altéré en échec (attendu) ; premier passage 100 citations, 5 échecs (2603.19262, colonnes entrelacées), corrigées en fragments d'une ligne ; passage final 107 citations, 0 échec.
- Contrôle rapport contre citations.json (texte et page) : 0 divergence.
- Calcul du lecteur : calcul_hc6_tableau13.py (Spearman sur quatre familles, non concluant).
- Aucun refus, aucun appel réseau, aucun appel de modèle, aucune commande git.
