# Second contrôle : toute chaîne entre guillemets « … » du rapport qui est en anglais (au moins 3 mots ASCII)
# doit être incluse, après normalisation, dans une citation de citations.json (elle-même contrôlée sur PDF).
# Usage : python3 -I controle_rapport.py RAPPORT citations.json
import json, re, sys, unicodedata
def norm(s):
    s=unicodedata.normalize("NFKC",s)
    for a,b in (("’","'"),("‘","'"),("“",'"'),("”",'"'),("−","-")): s=s.replace(a,b)
    return re.sub(r"[\s\-]+","",s)
txt=open(sys.argv[1],encoding="utf-8").read()
cits=[norm(c["citation"]) for c in json.load(open(sys.argv[2],encoding="utf-8"))]
fr=re.compile(r"[éèêàùçîôâûœ]| (la|le|les|une|des|est|du|sans|avec|pour|et|au|de|en|donc) ", re.I)
ch=re.findall(r"«\s*(.+?)\s*»", txt, flags=re.S)
n=0; ech=[]
for c in ch:
    if fr.search(" "+c+" ") or len(c.split())<3: continue
    n+=1
    if not any(norm(c) in k for k in cits): ech.append(c)
for e in ech: print("NON COUVERTE:", e[:120])
print(f"chaînes anglaises entre guillemets: {n} ; non couvertes: {len(ech)} ; chaînes entre guillemets au total: {len(ch)}")
sys.exit(1 if ech else 0)
