# Contrôle des citations : chaque citation doit figurer dans le texte de la page citée.
# Usage : python3 -I controle_citations.py DOSSIER_PDF citations.json [--autotest]
import json, subprocess, sys, unicodedata, re
def norm(s):
    s = unicodedata.normalize("NFKC", s)
    for a, b in (("’","'"),("‘","'"),("“",'"'),("”",'"'),("−","-"),("­","")):
        s = s.replace(a, b)
    s = s.replace("ﬁ","fi").replace("ﬂ","fl")
    return re.sub(r"[\s\-]+", "", s)   # blancs et traits d'union retirés (césures)
_cache = {}
def page(dossier, pdf, p, mode):
    k = (pdf, p, mode)
    if k not in _cache:
        opts = {"layout":["-layout"], "defaut":[], "raw":["-raw"]}[mode]
        r = subprocess.run(["pdftotext", *opts, "-f", str(p), "-l", str(p), f"{dossier}/{pdf}", "-"],
                           capture_output=True, text=True)
        _cache[k] = norm(r.stdout)
    return _cache[k]
def trouve(dossier, c):
    q = norm(c["citation"])
    if len(q) < 6: return None
    for mode in ("layout", "defaut", "raw"):
        if q in page(dossier, c["pdf"], c["page"], mode): return mode
    return None
def main():
    dossier, fichier = sys.argv[1], sys.argv[2]
    cits = json.load(open(fichier, encoding="utf-8"))
    if "--autotest" in sys.argv:
        juste = cits[0]
        alt = dict(juste, citation=juste["citation"].replace("hierarchy depth", "hierarchy width"))
        assert alt["citation"] != juste["citation"]
        mauvaise_page = dict(juste, page=juste["page"] + 5)
        r = [("cas juste", trouve(dossier, juste), True), ("cas altéré", trouve(dossier, alt), False),
             ("cas juste, mauvaise page", trouve(dossier, mauvaise_page), False)]
        ok = True
        for nom, res, attendu in r:
            bon = (res is not None) == attendu
            ok &= bon
            print(f"{nom}: trouvé={res} attendu_trouvé={attendu} -> {'conforme' if bon else 'NON CONFORME'}")
        sys.exit(0 if ok else 1)
    modes, echecs = {}, []
    for c in cits:
        m = trouve(dossier, c)
        if m is None: echecs.append(c["id"]); print("ECHEC", c["id"], c["pdf"], "p.", c["page"])
        else: modes[m] = modes.get(m, 0) + 1
    print(f"citations contrôlées: {len(cits)} ; échecs: {len(echecs)} ; modes: {modes}")
    sys.exit(1 if echecs else 0)
main()
