# Journal du lot 7-D (H9, délégation) — fichiers de travail

Heures relevées par `date -u`. Clôture : 2026-11-10 11:11 UTC.

- Consigne commune et interdits communs v2 lus en entier. Énoncé de H9 lu dans docs/decisions/decision-N-035-v1.md. Programme v2, lignes 85-125 et 190-215 lues. anteriorite-v1.md : titres relevés, aucune section H9 (recherche dans ce seul fichier).
- Empreintes des cinq PDF vérifiées contre les compagnons : conformes.
- Texte extrait page par page (pdftotext -layout) dans texte/ ; concaténations par article (*-tout.txt) ; les cinq articles lus en entier, annexes et bibliographies comprises.
- construire_citations.py -> citations.json (141 citations) ; controle_citations.py : essai (juste, altéré, mauvaise page) conforme ; 141 contrôlées, 0 échec.
- controle_rapport.py : 53 chaînes anglaises entre guillemets du rapport, toutes incluses dans une citation contrôlée. Quatre citations contrôlées ne sont pas appelées par identifiant dans le rapport (L16, S30 : titres ; X08, Y01).
- calculs.py : moyennes par profondeur (MasDrift, tableau 13), recoupement du tableau 18 avec les taux de perte, sommes du tableau 3 de Ying.
- Écarts relevés : MasDrift, tableau 18 non réconciliable avec les tableaux 13 et 21 pour Qwen, Sol, DeepSeek ; Ying, « RE + PE + FE = 100% » contredit par le tableau 3, « 61.2% » sans tableau, tampon de date d'août pour un identifiant de septembre.
- Pistes non lues (hors lot) : arXiv 2605.08647 (AgentCollabBench), 2605.05440 (Tallam), Xu et collègues 2026, Cemri 2025, Hammond 2025 ; versions 1 de MasDrift et de Sun.
- Aucun appel réseau, aucun appel de modèle, aucune commande git, aucune recherche récursive dans le dépôt. Aucun refus rencontré.
- Remarque d'horloge : deux relevés successifs de `date -u` en cours de travail ont donné 11:04 puis 11:07 pour un intervalle ressenti plus long ; les heures écrites sont celles relevées, sans correction.
