# Recalculs (nature « calcul ») à partir des tableaux 3, 4, 13, 18, 21 de MasDrift et des tableaux 3, 4 de Ying.
m5=["DeepSeek","Qwen","Nano","Gemini","Sol"]
# tableau 13, p. 21 : (UA, OD, CL, Cmp) par architecture, 6 configurations (5 homogènes + Sol-Nano)
T={"N2":[(2.3,14.2,3.5,89.7),(0.5,0.5,1.5,90.2),(1.0,0.7,0.5,83.8),(0.0,0.0,2.5,79.7),(0.0,0.0,40.0,91.5),(0.2,0.0,41.3,92.2)],
"N4":[(1.5,16.5,4.8,88.3),(0.5,0.3,1.7,92.3),(1.3,0.8,0.7,81.8),(0.2,0.0,1.8,79.0),(0.5,0.5,44.5,90.0),(0.3,0.3,44.2,90.2)],
"N8":[(1.2,18.0,4.2,87.5),(0.3,0.3,0.8,91.2),(0.8,0.5,0.7,81.8),(0.0,0.0,2.0,78.3),(0.5,0.5,42.0,89.5),(0.0,0.0,40.5,90.0)],
"N4-t":[(2.2,9.5,3.2,89.3),(0.2,0.2,0.2,92.2),(0.8,0.3,0.7,82.3),(0.0,0.0,1.0,74.5),(0.0,0.0,45.0,90.0),(0.3,0.2,46.8,88.3)],
"L1":[(6.0,8.0,6.8,98.5),(0.8,0.3,0.7,95.3),(6.0,4.3,1.0,95.7),(0.8,0.3,1.7,82.2),(0.0,0.0,63.5,98.0),(2.7,1.5,57.0,96.7)],
"L2":[(15.7,10.7,9.8,99.7),(14.5,11.2,1.2,99.5),(7.7,5.0,1.5,97.7),(19.3,16.0,2.3,93.7),(1.5,0.5,37.0,100.0),(32.0,25.8,37.5,98.8)],
"L3":[(26.2,10.3,9.2,99.8),(33.5,25.3,1.3,99.5),(15.3,10.0,2.7,99.0),(23.0,19.0,1.0,94.5),(1.0,1.0,50.5,100.0),(39.5,32.2,67.5,99.5)],
"L2-t":[(20.7,12.7,12.8,99.5),(18.3,12.8,1.7,99.5),(8.5,6.7,1.7,98.0),(14.2,12.3,1.2,93.8),(1.5,1.5,35.0,98.5),(25.3,21.7,41.7,97.5)]}
print("Moyenne sur les 5 configurations homogènes, par architecture (UA, CL, Cmp) :")
for a,v in T.items():
    ua=sum(x[0] for x in v[:5])/5; cl=sum(x[2] for x in v[:5])/5; c=sum(x[3] for x in v[:5])/5
    print(f"  {a:5s} UA={ua:5.2f} CL={cl:5.2f} Cmp={c:5.2f}")
print("CL moyenne hors Sol (4 configurations) par profondeur :")
for a in ("L1","L2","L3"):
    print(f"  {a} CL={sum(x[2] for x in T[a][:4])/4:.2f}  UA={sum(x[0] for x in T[a][:4])/4:.2f}")
noms=m5+["Sol-Nano"]
print("Pertes attendues = somme sur 8 architectures de CL% x 600 (si tous les runs sont jugés), contre n du tableau 18 :")
n18={"DeepSeek":110,"Qwen":733,"Nano":56,"Sol-Nano":2259,"Gemini":77,"Sol":715}
tot=0
for i,nm in enumerate(noms):
    e=sum(T[a][i][2] for a in T)*6; tot+=e
    print(f"  {nm:9s} attendu={e:7.1f}  tableau18={n18[nm]}  CL moyenne={sum(T[a][i][2] for a in T)/8:.2f}")
print("  total attendu=%.1f tableau18=3950"%tot)
for fam,archs,n in (("Peer",["N2","N4","N8","N4-t"],2212),("Cent L1",["L1"],503),("Cent L2 (+L2-t)",["L2","L2-t"],694),("Cent L2 seul",["L2"],694),("Cent L3",["L3"],541)):
    e=sum(sum(x[2] for x in T[a]) for a in archs)*6
    print(f"  {fam:16s} attendu={e:7.1f} tableau18={n}")
print("Ying, tableau 3 : RE+PE+FE et 100-FR")
for nm,fr,re_,pe,fe in (("Claude",71.43,24.49,0.00,4.08),("GPT",28.57,14.29,20.41,36.73),("Gemini",34.69,22.45,14.29,28.57),("Qwen",18.37,8.16,10.20,63.27),("DeepSeek",10.20,8.16,4.08,77.55),("Kimi",57.14,16.33,6.12,20.41)):
    print(f"  {nm:9s} RE+PE+FE={re_+pe+fe:6.2f}  100-FR={100-fr:6.2f}")
print("Ying : 1 tâche sur 49 = %.2f %% ; 30.61%%=%d/49 ; 77.55%%=%d/49"%(100/49,round(.3061*49),round(.7755*49)))
print("Sun, tableau 7 : désactivation par nombre de relais simulés 0,1,2,3,4 = 0.0, 25.0, 100.0, 100.0, 100.0 ; action interdite = 0.0, 0.0, 54.2, 83.3, 79.2 (n=48 par bras)")
