"""Contrôle des citations du rapport lot 2-B.
Usage : python3 -I controle_citations_lot2B_v1.py DOSSIER_DES_TXT FICHIER_CITATIONS [--essai]
Chaque citation (fichier .txt, ligne, texte) doit figurer dans le texte des lignes [ligne, ligne+FENETRE]
du fichier .txt, après normalisation (espaces, apostrophes et guillemets typographiques, tirets, ligatures).
En second contrôle, on dit si la citation figure aussi dans le HTML brut (balises ôtées)."""
import html, re, runpy, sys, unicodedata
FENETRE = 6
def norm(s):
    s = unicodedata.normalize('NFKC', s)
    for a, b in (('’', "'"), ('‘', "'"), ('“', '"'), ('”', '"'), ('–', '-'), ('—', '-'), ('−', '-'), (' ', ' '), ('­', '')):
        s = s.replace(a, b)
    return re.sub(r'\s+', ' ', s).strip()
def controle(dossier, cits):
    echecs, html_abs = [], []
    cache = {}
    for ident, fichier, ligne, texte in cits:
        if fichier not in cache:
            lignes = open(dossier + '/' + fichier, encoding='utf-8').read().split('\n')
            try:
                brut = open(dossier + '/' + fichier[:-4] + '.html', encoding='utf-8', errors='replace').read()
                brut = norm(html.unescape(re.sub(r'<[^>]+>', ' ', brut)))
            except OSError:
                brut = None
            cache[fichier] = (lignes, brut)
        lignes, brut = cache[fichier]
        bloc = norm(' '.join(lignes[ligne - 1: ligne - 1 + FENETRE + 1]))
        premiere = norm(lignes[ligne - 1]) if 0 < ligne <= len(lignes) else ''
        c = norm(texte)
        # la citation doit être dans le bloc ET commencer sur la ligne citée (un début d'au moins 12 caractères y figure)
        ok = c in bloc and (c[:12] in premiere or c in premiere)
        if not ok:
            echecs.append((ident, fichier, ligne, texte))
        elif brut is not None and c not in brut:
            html_abs.append(ident)
    return echecs, html_abs
if __name__ == '__main__':
    dossier, fic = sys.argv[1], sys.argv[2]
    cits = runpy.run_path(fic)['CITATIONS']
    if '--essai' in sys.argv:
        juste = [cits[1]]
        altere = [(cits[1][0], cits[1][1], cits[1][2], cits[1][3].replace('slight', 'large'))]
        decale = [(cits[1][0], cits[1][1], cits[1][2] + 40, cits[1][3])]
        e1, _ = controle(dossier, juste); e2, _ = controle(dossier, altere); e3, _ = controle(dossier, decale)
        print('essai juste : echecs =', len(e1), '(attendu 0)')
        print('essai altere (mot change) : echecs =', len(e2), '(attendu 1)')
        print('essai decale (mauvaise ligne) : echecs =', len(e3), '(attendu 1)')
        sys.exit(0 if (len(e1), len(e2), len(e3)) == (0, 1, 1) else 1)
    echecs, html_abs = controle(dossier, cits)
    print('citations controlees :', len(cits), '; echecs :', len(echecs))
    for e in echecs:
        print('ECHEC', e)
    print('citations presentes dans le .txt mais non retrouvees telles quelles dans le HTML sans balises :', len(html_abs), html_abs)
    sys.exit(1 if echecs else 0)
