"""Valeurs clés tirées des données Plotly du billet de Gasteiger et collègues (nature : figure).
Usage : python3 -I extraire_valeurs_cles_gasteiger_v1.py DONNEES_JSON SORTIE_JSON"""
import json, sys
d = json.load(open(sys.argv[1]))
out = {}
f1 = d[0]
out['figure_1_soupcon_contre_performance'] = {t['name'].replace('<br>', ' '): {'performance': round(t['x'][0], 4), 'soupcon_1_a_10': round(t['y'][0], 3), 'ic95_perf_plus': round(t['error_x']['array'][0], 4), 'ic95_soupcon_plus': round(t['error_y']['array'][0], 3), 'ic95_soupcon_moins': round(t['error_y']['arrayminus'][0], 3)} for t in f1['traces']}
f11 = d[10]
out['figure_11_annexe_zero_exemple_claude_3_7'] = {t['name']: {'performance': round(t['x'][0], 4), 'soupcon_1_a_10': round(t['y'][0], 3)} for t in f11['traces']}
f4 = d[3]
out['figure_4_un_exemple'] = {t['name']: {'performance': round(t['x'][0], 4), 'soupcon_1_a_10': round(t['y'][0], 3)} for t in f4['traces']}
f8 = d[7]
out['figure_8_fraction_de_preferences_correctes_des_juges'] = {t['name']: {j: {'fraction': round(v, 4), 'ic95_plus': round(e, 4)} for j, v, e in zip(t['x'], t['y'], t['error_y']['array'])} for t in f8['traces']}
roc = {}
for t in d[4]['traces']:
    mon = t['hovertemplate'].split('Monitor=')[1].split('<br>')[0]
    best = {a: max([y for x, y in zip(t['x'], t['y']) if x <= a] or [0]) for a in (0.01, 0.05, 0.10)}
    roc[t['name'] + ' | moniteur ' + mon] = {('rappel_max_a_faux_positifs_<=_%g' % a): round(v, 4) for a, v in best.items()}
out['figure_5_roc_calcul_du_lecteur'] = roc
json.dump(out, open(sys.argv[2], 'w'), ensure_ascii=False, indent=1)
print(json.dumps(out['figure_5_roc_calcul_du_lecteur'], indent=0)[:1500])
