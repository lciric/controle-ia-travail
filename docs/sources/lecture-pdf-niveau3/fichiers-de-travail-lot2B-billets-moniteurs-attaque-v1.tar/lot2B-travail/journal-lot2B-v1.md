# Journal du lecteur — lot 2-B (v1)
- 2026-11-10T11:17Z (date -u) : fin de rédaction. Heure de début non relevée (premier fichier de travail daté de 11:07 UTC par le système de fichiers). En-tête du rapport corrigé sur ce point avant remise, puis rapport et archive rescellés (fichiers jamais versés ni remis auparavant).
- Empreintes : 15 .txt, 15 .html, 19 PNG contrôlés contre la note de provenance ; 49 concordances sur 49.
- Lus en entier : les 15 fichiers .txt du lot (pour 9 d'entre eux, affichage sans les lignes vides ni les lignes de métadonnées répétées « og » et « twitter »).
- Figures : les 19 PNG du billet de Gasteiger regardés ; les 12 figures Plotly du HTML extraites par extraire_figures_gasteiger_v1.py ; valeurs clés dans valeurs-cles-figures-gasteiger-v1.json.
- Citations : deux numéros de ligne corrigés après un premier contrôle (G16 : 880 -> 882 ; V8 : 166 -> 168) ; contrôle final : 192 citations, 0 échec.
- Aucun appel réseau, aucun appel de modèle, aucune commande git modifiante, aucune recherche récursive ; aucun refus.
- Non lus : les articles arXiv que les billets résument ; les figures des autres billets (non récupérées).
