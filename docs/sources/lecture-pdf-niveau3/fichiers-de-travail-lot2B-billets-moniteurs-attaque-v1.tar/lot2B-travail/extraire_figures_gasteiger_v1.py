"""Extrait les données des 12 figures Plotly incorporées au HTML du billet de Gasteiger et collègues.
Usage : python3 -I extraire_figures_gasteiger_v1.py FICHIER_HTML SORTIE_JSON
Les valeurs extraites sont de nature « figure » (données du graphique, non imprimées dans le texte)."""
import json, re, sys
h = open(sys.argv[1], encoding='utf-8').read()
dec = json.JSONDecoder()
out = []
for i, m in enumerate(re.finditer(r'Plotly\.newPlot\(\s*"([0-9a-f-]+)",\s*', h)):
    data, end = dec.raw_decode(h, m.end())
    cap = re.search(r'<figcaption[^>]*>(.*?)</figcaption>', h[end:end + 60000], re.S)
    out.append({'indice': i + 1, 'id': m.group(1), 'legende': ' '.join(cap.group(1).split()) if cap else None, 'traces': data})
json.dump(out, open(sys.argv[2], 'w'), ensure_ascii=False, indent=1)
print(len(out), 'figures')
