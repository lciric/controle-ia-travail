# Rapport de lecture — lot 5-A : détection séquentielle et multi-agents (niveau 3 de l'état de l'art) — v1

Écrit le 2026-11-10 vers 11:05 UTC (heure relevée par `date -u`). Lecteur neuf : je n'ai écrit ni le programme ni aucun rapport antérieur.

Les renvois entre crochets ([G14], [C21]…) désignent les citations exactes de l'annexe A, chacune avec son fichier et sa page (page 1 = première page du fichier).

## 0. En tête : ce qu'il faut voir d'abord

**Aucun des six articles ne lit un état interne.** Les six accumulent ou jugent des signaux de sortie (gains d'un jeu, réponses plongées, traits de surface du texte, scores de classifieurs de texte). La conjonction de H2 (énoncé N-007) n'est occupée par aucun.

**Occupations partielles, toutes en boîte noire, à porter devant Lazar :**

1. **H2 — occupée en partie, en boîte noire, par 2606.20746 (Corll)**, et l'article apporte en même temps un **contre-indice conditionnel**.
   - Fait : somme cumulée de Page (remise à zéro, dérive prise sur le bénin seul) de scores par événement figés, sur des trajectoires d'agents à outils, pour des directives dont chacune reste sous le seuil par événement ; comparaison au maximum ([C1], [C6], [C8]).
   - Non fait : sondes ou états internes ; garantie toujours valide (l'auteur l'exclut : [C21]) ; seuil par action à 1 % de faux positifs ; rappel selon l'horizon ; sabotage par l'agent lui-même (ce sont des textes greffés).
   - Contre-indice : l'accumulation amplifie une marge qui existe déjà sous le seuil, elle n'en crée pas ([C5], [C16]) ; résultat nul sur le second axe ([C15]) ; le résultat positif tient à quatre trajectoires sur trois tâches, sans puissance ([C13], [C19]).
2. **Statistique spatio-temporelle du papier B (E3.1, « le cœur vierge ») — squelette occupé en partie, en boîte noire, par deux articles.**
   - 2601.05427 (Gauthier, Bach, Jordan ; ICML 2026 imprimé, [G2]) : un processus e par agent et par déviation, garantie toujours valide par l'inégalité de Ville, combinaison entre agents par la procédure e-BH arrêtée à un temps commun ; l'alarme vient plus tôt quand plusieurs processus montent ensemble ([G5], [G6], [G18]). Signal : gains et actions d'un jeu, pas un modèle de langue.
   - 2605.11135 (Helm, Priebe, Duderstadt ; NeurIPS 2026 imprimé, [H3]) : une statistique de population (distribution des agents dans un espace de plongement de leurs réponses) suivie dans le temps par une carte de contrôle ; accès boîte noire déclaré ([H4]).
   - Non fait par les deux : états internes, sondes, copies d'un même modèle lues en parallèle, comparaison au séquentiel par agent et à la coupe transversale, adversaire qui s'adapte au moniteur.
3. **H3 — occupée en partie, en boîte noire (lecture dure), par 2605.11135** : contamination et taux d'alarme selon la taille du système (cent à cent mille agents) à nombre d'agents dormants constant ([H23], [H26]). Lecture « voisin » défendable : N y est la taille de la population honnête, pas le nombre d'agents entre lesquels un budget de sabotage se répartit ; simulation sans modèle de langue ([H27]). Le programme dit déjà que « les courbes boîte noire sont publiées ».
4. **T — voisin fort, moitié négative en boîte noire, par 2605.11135** : théorème d'existence d'une défection lente non détectée par toute carte à référence glissante, et remarque sur la somme cumulée ([H11], [H12]). Aucune des quatre pièces revendiquées de N-003 n'y figure.

**Limite reconnue qui n'est pas un trou du champ.** Helm et collègues écrivent que l'accès aux activations internes « pourrait » détecter plus tôt et que le compromis apprentissage-sécurité y est une question ouverte ([H17], [H18]) ; Xie range les représentations internes parmi les raffinements optionnels ([X3], [X4]). Ce sont des invitations, pas des preuves que la zone est vide.

## 1. Méthode et réserves sur ma propre lecture

- Empreintes des six PDF vérifiées par `sha256sum -c` contre les compagnons `.sha256` du dossier : six « OK ».
- Extraction page par page par `pdftotext -layout -f N -l N` et, pour la lecture des pages à deux colonnes, par `pdftotext -f N -l N` (ordre de lecture).
- **Écart à la consigne « lire en entier », déclaré.** Pour 2601.05427, j'ai lu ligne à ligne les pages 1 à 14, 22 et 23 (annexes D et E), 30, 31, 34 à 36. Les pages de preuves et de rappels (15 à 21, 24 à 29, 32, 33) et la fin des détails d'expérience (37 à 41) n'ont été parcourues que par leurs titres de section et par une recherche de mots (adversaire, modèle de langue, activation, collusion, indépendance, permutation, échangeabilité, budget). Je n'ai donc pas vérifié les preuves. Les cinq autres articles ont été lus en entier ; les pages de références (2605.11135 p. 11 et 12, 2607.24893 p. 12, 2604.08608 p. 10 et 11, 2606.20746 p. 15 et 16) ont été parcourues, et certaines lignes de tableaux mal rendues n'ont été relues qu'en mode `-layout` (tableaux 3 et 4 de 2607.24893). Aucune figure n'a été ouverte en image : aucun chiffre de ce rapport n'est « lu sur une figure ».
- Contrôle des citations : script `controle_citations_lot5A_v1.py`, lancé par `python3 -I`. Garde essayée d'abord sur un cas juste (passe), sur le même cas altéré (échec attendu, obtenu) et sur une mauvaise page (échec attendu, obtenu). **119 citations contrôlées, 0 échec** (90 trouvées en mode `-layout`, 29 en ordre de lecture seulement, à cause de l'entrelacement des colonnes). Deux citations avaient échoué au premier passage et ont été corrigées (une page fausse pour [C6], une exposant parasite dans [H19]).
- Nature des chiffres : tout chiffre ci-dessous est « auteurs » (imprimé), sauf mention « calcul ».

## 2. Les six articles

### 2.1 — 2601.05427v3, Gauthier, Bach, Jordan, « Anytime Detection of Strategic Deviations in Multi-Agent Systems » (41 pages)

Venue imprimée : actes de la 43ᵉ conférence internationale sur l'apprentissage automatique (ICML), 2026 [G2].

**Réponses aux quatre questions.**
- Signal accumulé : sortie observable, jamais un état interne. Dans les jeux répétés, un incrément de regret calculé sur les gains, qui exige les gains contrefactuels ([G4], [G7], [G10]) ; dans les jeux stochastiques, un rapport de vraisemblance entre la politique cible et une politique déviante, qui exige de connaître la politique cible ([G8], [G11]). Aucun modèle de langue : jeu 2 × 2, pierre-feuille-ciseaux à vingt joueurs, football sur grille, prédateur-proie ([G20]). Le seul lien avec les modèles de langue est une référence à un audit de facturation par e-valeurs ([G16]).
- Garantie : oui, toujours valide. Surmartingale de test, inégalité de Ville, contrôle du taux d'erreur par famille à tout instant ([G1], [G5]) ; martingale exacte dans le cas des rapports de vraisemblance ([G9]) ; contrôle du taux de fausses découvertes par e-BH arrêtée à un temps commun ([G6]).
- Agents : plusieurs (un processus par joueur et par déviation).
- Adversaire adaptatif : non. Les profils d'actions sont supposés indépendants et de même loi à chaque tour ([G3]) ; la déviation est stationnaire et active dès le début ([G14]) ; la réaction d'agents qui apprennent aux détections est renvoyée aux travaux futurs ([G12]).

**Résultats (auteurs).** Sous l'hypothèse nulle, 3 fausses alarmes sur 300 exécutions de 4 000 tours, soit 0,01 pour un niveau visé de 0,2 ([G17]). Jeu à vingt joueurs et soixante hypothèses : temps moyen de détection de 2 025 tours pour le contrôle par famille contre 1 248 pour e-BH ([G21]) ; accélération de 1,15 fois sur le jeu 2 × 2 ([G19]). Temps de détection en 1/ε² pour une déviation de taille ε (théorème 3.4, non vérifié par moi).

**Ce qu'il ne fait pas.** Pas de rupture en cours de route : les auteurs se disent distincts des méthodes de détection de rupture (somme cumulée de Page) et alignés sur le test séquentiel de Wald, « plutôt que les récurrences additives » ([G13], [G14], [G15]). Pas de dépendance entre tours, pas d'effet épisode. Le détecteur signale où les incitations sont violées, pas qui a dévié : dans le jeu à vingt joueurs, les alarmes tombent sur les quinze joueurs conformes ([G22], [G23]).

**Limites reconnues.** Gains contrefactuels requis ; politique cible connue requise ; déviations stationnaires seulement ([G10], [G11], [G12]). Une marge strictement positive est nécessaire : une déviation arbitrairement petite repousse l'alarme sans borne ([G24]).

**Réserves.** Le taux de fausses alarmes de 0,01 pour 0,2 visé montre une garantie très conservatrice (les auteurs l'attribuent au petit paramètre de mise) ; ce n'est pas un résultat « trop beau », c'est un coût de puissance. Rien d'incohérent relevé dans les pages lues.

### 2.2 — 2605.11135v2, Helm, Priebe, Duderstadt, « Control Charts for Multi-agent Systems » (19 pages)

Venue imprimée : 40ᵉ conférence NeurIPS, 2026 [H3] ; version 2 datée du 5 novembre 2026 sur la première page.

**Réponses aux quatre questions.**
- Signal : boîte noire, déclarée ([H4]). Réponses des agents à un jeu de questions, plongées par un modèle de plongement de texte, puis réduites à une trajectoire d'ensemble du système. Les activations internes ne sont citées que comme une autre façon de plonger des modèles dans des travaux antérieurs ([H5]).
- Garantie : non toujours valide. Carte de contrôle de Shewhart à k écarts types, avec une référence fixe ou une fenêtre glissante ; le taux de fausse alarme est donné instant par instant sous hypothèse d'observations indépendantes et de même loi, hypothèse que les auteurs disent non observée ([H20]). De plus les plongements sont ajustés sur tous les instants à la fois, donc la statistique à l'instant t dépend du futur ([H6]).
- Agents : plusieurs ; cinq agents avec un modèle de langue (gpt-4o-mini, [H7]) dans l'expérience principale, puis de cent à cent mille agents par une fonction de substitution sans modèle de langue ([H9], [H27]).
- Adversaire : agents dormants qui répondent par une phrase témoin selon un calendrier fixé d'avance, rapide ou lent ([H8]). Pas d'adversaire qui s'adapte au moniteur, pas d'adversaires coordonnés ([H16]).

**Résultats (auteurs).**
- Une référence fixe déclenche de fausses alarmes quand les agents apprennent ; une référence glissante absorbe un décalage persistant ([H10]) et laisse passer une défection lente ([H1], [H2]).
- Théorème 1 (existence d'une défection non détectée) : un calendrier à taux constant étalé sur L fenêtres atteint un déplacement cible avec un nombre attendu de défections qui ne dépend pas de L ([H14], [H29]), tandis que le décalage vu dans toute fenêtre tend vers zéro. Remarque : la même absorption vaut pour une somme cumulée à référence glissante, et un adversaire qui reste sous la tolérance de la somme cumulée empêche la charge de monter ; une somme cumulée à référence fixe accumule la dérive légitime ([H11], [H12], [H13]).
- « Théorème 2 » (compromis apprentissage-sécurité) et conjecture qu'aucune procédure ne satisfait les deux exigences contre tout adversaire ([H15]) ; la direction inverse n'est pas formalisée ([H21]).
- Annexe C : cent agents dormants dans un système de cent mille agents (un millième) contaminent 57 % des agents honnêtes pour un rapport d'alarme de 0,65 ([H23]) ; avec dix agents dormants la contamination se dilue quand le système grandit, et elle suit la fraction adverse et la topologie plutôt que la taille ([H26]) ; un seul agent dormant contamine tout le système quand le jeu de questions est petit ([H25]).

**Limites reconnues.** Graphe complet, adversaire simple, agents simplifiés, cadre boîte noire ([H16], [H17], [H18]) ; pas de localisation de l'agent responsable ([H19]) ; hypothèses 3 à 5 posées et non dérivées.

**Incohérences et réserves.**
- La liste des contributions annonce trois contributions mais est numérotée de 2 à 5, avec la même contribution imprimée deux fois (p. 2) ; une phrase est fautive ([H28]). Signes d'une version en cours de révision.
- Le « théorème 2 » n'a pas de démonstration propre : il réunit le théorème 1 et un argument de loi des grands nombres ; la thèse générale est une conjecture ([H15]).
- Le résultat à grande échelle repose sur une fonction de substitution, validée « qualitativement » sur une figure que je n'ai pas ouverte ([H9]).
- Les cas « détectables » de l'annexe C reposent sur un à quatre alarmes et ne sont pas significatifs, de l'aveu des auteurs ([H24]).
- Le théorème 1 suppose des observations indépendantes et de même loi que les auteurs disent eux-mêmes non observées ([H20]).

### 2.3 — 2606.07624v1, Xie, « Sequential statistical inference for Large Language Models: Representation, validity, and monitoring » (6 pages)

Venue imprimée : discussion invitée préparée pour *The American Statistician* [X1]. Texte de position, sans expérience ni résultat ([X2]).

**Réponses aux quatre questions.**
- Signal : un score défini sur l'historique observable des interactions. Les représentations internes sont nommées, pour être rangées au second plan : utiles « quand elles sont disponibles », propres à chaque modèle, « raffinements optionnels » ([X3], [X4]).
- Garantie : le raisonnement toujours valide est recommandé en une phrase, par renvoi à Howard et collègues ([X5]) ; l'alarme est un temps d'arrêt dont le seuil contrôle les fausses alarmes sous un régime de référence ([X6]). Rien n'est construit.
- Agents : un système ; les cartes de contrôle multi-agents de Helm et collègues sont citées en une phrase ([X7]).
- Adversaire : les « usages adverses » sont mentionnés comme une cause de dérive ([X8]) ; aucun modèle d'adversaire.

**Ce qu'il ne fait pas.** Aucune mesure, aucun agent, aucun sabotage, aucune sonde. Rien à signaler au titre des résultats trop beaux : il n'y a pas de résultat.

### 2.4 — 2607.24893v2, Fernandez Arias, Mistry, Wang, Hu, « Early Detection of Distributed Backdoors in Multi-Agent LLM Systems: A Characterization Study » (12 pages)

Aucune venue imprimée (prépublication, version 2 du 2 octobre 2026).

**Réponses aux quatre questions.**
- Signal : boîte noire, traits de surface du texte des observations d'outils (longueur, entropie de Shannon, part de caractères base64), lus par un classifieur à arbres sur un préfixe croissant de la trajectoire ; ou texte brut lu par un modèle réglé. Les activations internes ne sont citées que comme une famille de défenses antérieures qui jugent un artefact isolé ([F3]).
- Garantie : aucune. Le score est une probabilité de classifieur recalculée sur chaque préfixe, l'alarme est le premier franchissement d'un seuil ; les fausses alarmes sont mesurées hors pli. Ce n'est pas une accumulation additive : c'est un classifieur supervisé, entraîné avec des exemples d'attaque.
- Agents : plusieurs (un gestionnaire et trois sous-agents), mais le défenseur lit un seul flux d'événements réunis ([F7]).
- Adversaire : fixe. L'attaquant contrôle des outils empoisonnés et l'assemblage après l'exécution, pas les agents ni le moniteur ([F6]). Les agents ne sabotent pas : leur raisonnement est normal. La variante « mots ordinaires » est une réécriture hors ligne des journaux, pas une nouvelle exécution ([F10]).

**Résultats (auteurs).** 2 082 trajectoires, 14 pas en moyenne, cinq modèles ouverts, deux environnements d'outils ([F8], [F9]). Détecteur entraîné sur préfixes : 99,5 % des 428 attaques réussies signalées, médiane de douze pas restants, 1,1 % de fausses alarmes sur les exécutions sans fragment, mais 80,5 % sur les exécutions avec fragments qui n'ont pas abouti, soit 27,6 % au total ([F1], [F11], [F12]). Sur le texte chiffré, un détecteur qui ne lit que l'observation courante fait aussi bien que le préfixe ([F4]) ; sur la variante en mots ordinaires, longueur retirée, le préfixe fait 44,4 % contre 30,4 % ([F13]). Les détecteurs d'anomalie ajustés sur les exécutions propres seules sont au niveau du hasard ou en dessous ([F16]) ; un garde-fou du commerce signale 91,8 % des exécutions sans discernement ([F15]).

**Limites reconnues.** Une seule famille d'attaque ([F19]) ; les trajectoires ne sont jamais appariées en longueur ; la fenêtre d'alerte existe parce que l'assemblage a lieu après l'exécution ; le signal tient à la surface de l'attaque et non à sa structure répartie ([F2], [F14]).

**Incohérences et réserves.**
- Le titre du résultat (99,5 % à environ 1 % de fausses alarmes) ne vaut que pour les exécutions sans fragment : le même détecteur signale 80,5 % des exécutions qui portaient des fragments sans aboutir ([F11]). Il détecte l'injection, pas l'attaque réussie.
- Le détecteur entraîné sur préfixes s'allume au pas 1 en médiane ([F11]), alors que le détecteur entraîné sur exécutions complètes s'allume au pas 8, « six pas après la première injection » ([F20]), ce qui place l'injection médiane vers le pas 2 (calcul sur des médianes, donc approximatif) ; or seules 0,9 % des détections seraient antérieures à l'injection ([F21]). Les trois chiffres ne se recoupent pas sans une convention de numérotation que l'article ne donne pas. Réserve.
- Les comparaisons entre le classifieur à arbres et le modèle réglé reposent sur des protocoles de rééchantillonnage différents (dit par les auteurs).

### 2.5 — 2604.08608v2, Ahad et collègues, « Semantic Intent Fragmentation: A Single-Shot Compositional Attack on Multi-Agent AI Pipelines » (11 pages)

Venue imprimée : accepté au symposium d'été 2026 de l'AAAI « AI Agents for the Cyber Battlefield » [S3].

**Réponses aux quatre questions.**
- Signal : boîte noire, scores de classifieurs de texte par sous-tâche, puis un juge génératif au niveau du plan entier et une analyse de flux d'information par règles. Aucun état interne (le mot « probe » y désigne une question posée à l'orchestrateur).
- Garantie : aucune ; rien de séquentiel. Le contrôle se fait une fois, entre la génération du plan et le premier envoi.
- Agents : un orchestrateur et trois sous-agents, simulés par des modèles interrogés par consigne ([S14]).
- Adversaire : un utilisateur légitime qui envoie une seule demande et ne fait plus rien ([S1]) ; non adaptatif. L'attaque ne prétend pas échapper à toute défense ([S7]).

**Résultats (auteurs).** 10 scénarios sur 14 (71 %) produisent un plan contraire à la politique alors que chaque sous-tâche passe les classifieurs ([S2]) ; le juge de plan et l'analyse de flux détectent les 10 attaques confirmées, 0 fausse alarme sur 8 contrôles bénins ([S4], [S9]).

**Incohérences et résultats trop beaux — réserve forte.**
- **Circularité.** Un scénario n'est compté comme attaque que si le juge de plan le déclare dangereux ([S5]) ; ce même juge est ensuite crédité d'avoir détecté toutes les attaques confirmées ([S4]). Le « 10 sur 10 » est vrai par définition. Le taux de fausses alarmes de 0 % repose sur huit contrôles écrits par les auteurs ([S9]).
- **Théorèmes.** Le théorème 1 reformule la définition du score de fragmentation ; le théorème 2 est « prouvé » par les dix cas observés ([S6]). L'affirmation qu'aucune amélioration d'un classifieur par sous-tâche ne peut combler l'écart ([S15]) est contredite dans l'article même : un juge génératif reconnaît l'intention de la troisième sous-tâche prise isolément dans 14 cas sur 14, et aucun cas n'est « purement » compositionnel ([S12], [S13]).
- **Chiffres.** 71 % contre 44 % est appelé un écart de 28 points ([S8]) : 27 points (calcul). « 8 des 87 sous-tâches » ([S11]) alors que 14 scénarios et 8 contrôles à trois sous-tâches font 66 (calcul). Un classifieur signale 16 des 42 sous-tâches d'attaque ([S10]) alors que le résumé dit que chaque sous-tâche passe six familles de classifieurs ([S2]) : seules deux familles sont dans le critère.
- Échantillon de 14 scénarios, tous simulés ([S14]).

Ces chiffres ne sont pas opposables.

### 2.6 — 2606.20746v1, Corll, « Amplify, Don't Create: Temporal Accumulation for Slow-Burn Prompt Injection » (16 pages)

Aucune venue imprimée (prépublication datée du 23 juin 2026, auteur seul).

**Réponses aux quatre questions.**
- Signal : boîte noire. Score par événement d'un détecteur de texte figé : un classifieur linéaire sur n-grammes de caractères et une tête de contraste sur plongements, combinés par le maximum ([C2]). Aucun état interne de l'agent.
- Garantie : aucune. Deux statistiques par trajectoire : le pic, et la « persistance », une somme cumulée de Page remise à zéro dont la dérive est la médiane des scores bénins ([C1], [C8]). L'auteur écrit que ce n'est pas un détecteur en ligne à taux de fausse alarme calibré ([C21]). Le seuil par événement (0,50) est verrouillé par un balayage, sans cible à 1 % ([C22]).
- Agents : un seul agent à outils.
- Adversaire : à moitié adaptatif. Le générateur de greffes n'interroge qu'un détecteur de cloisonnement d'une autre famille ([C7]) ; la discrétion face au détecteur évalué n'est obtenue que par transfert. L'attaquant ne s'adapte pas à l'accumulateur. Les directives sont des textes greffés sur des trajectoires propres, pas un sabotage produit par l'agent.

**Résultats (auteurs).**
- Attaques concentrées (9 trajectoires d'attaque, 40 bénignes, [C10]) : la meilleure statistique de trajectoire dépasse le détecteur par événement de 0,092 en aire sous la courbe, intervalle à 95 % [0,025 ; 0,155] ; la persistance et le pic sont à égalité, +0,031, intervalle [−0,033 ; 0,100] ([C11], [C12]).
- Attaques étalées, axe « exfiltration d'un dépôt git » : aire de 0,708 pour l'écart de persistance, sur quatre trajectoires d'attaque et six leurres bénins ([C4]) ; deux leurres dépassent deux attaques ([C14]) ; l'auteur dit le résultat descriptif et sans puissance ([C13]).
- Axe élargi : aire de 0,167, les trois écarts de persistance valent exactement 0 ([C15]).
- Mécanisme : la somme ne compte que la masse au-dessus de la dérive bénigne ; une greffe poussée sous la dérive n'ajoute rien, quel qu'en soit le nombre ([C9]) ; la bande utile fait environ 0,05 de large ([C17]). D'où la thèse : amplifier une marge, pas en créer ([C5], [C16]).

**Limites reconnues.** Trois tâches indépendantes et quatre trajectoires ([C19]) ; un seul détecteur et un seul juge de plancher ([C20]) ; scores par événement non revérifiés par le contrôle indépendant ; avertissement sur la pseudo-réplication ([C18]).

**Réserves.** L'article est d'une prudence inhabituelle et ne présente pas de résultat trop beau. À l'inverse, le résultat positif est trop mince pour être cité comme un effet mesuré : il porte la thèse comme un mécanisme, pas comme une mesure. La chaîne de calcul n'est pas publiée en entier (les reçus par événement sont retenus).

## 3. Verdicts par énoncé et par article

Vocabulaire : « ne touche pas », « voisin », « contre-indice », « occupée en partie », « occupée ».

### H2 — accumulation additive toujours valide de scores de sondes de l'agent qui agit (énoncé N-007)

| source | verdict | composantes faites | composantes non faites | pages |
|---|---|---|---|---|
| 2606.20746 (Corll) | **occupée en partie, en boîte noire ; contre-indice conditionnel** | somme cumulée de scores par événement sur trajectoire d'agent ; chaque événement sous le seuil par construction ; dérive calibrée sur le bénin seul ; comparaison au maximum | sondes ; garantie toujours valide (exclue par l'auteur) ; seuil par action à 1 % ; rappel selon l'horizon ; sabotage par l'agent ; contre-indice : l'accumulation ne crée pas de marge, bande utile étroite, résultat nul hors d'un axe | 1, 4, 6, 7, 8, 9, 13 |
| 2601.05427 (Gauthier et al.) | voisin (outil) | processus e multiplicatif à garantie toujours valide, sur plusieurs agents | états internes ; modèle de langue ; rupture en cours de trajectoire (écartée par les auteurs) ; dépendance ; adversaire ; calibrage empirique sur épisodes honnêtes | 1, 2, 4, 9, 13 |
| 2605.11135 (Helm et al.) | voisin ; **contre-indice conditionnel** sur le calibrage | suivi séquentiel boîte noire ; un calibrage fixe déclenche de fausses alarmes dès que la base honnête dérive, une base glissante absorbe l'attaque lente | sondes ; accumulation toujours valide ; seuil à 1 % ; sans objet si l'on calibre et lit sur des épisodes honnêtes de même régime | 1, 7, 8, 10 |
| 2607.24893 (Fernandez Arias et al.) | voisin ; **contre-indice de portée limitée** | alerte en cours de trajectoire sur préfixes ; fausses alarmes à 1 % sur exécutions propres ; lire tout le préfixe n'apporte rien quand un pas isolé suffit, et les détecteurs calibrés sur le propre seul échouent | sondes ; accumulation additive ; garantie ; calibrage sans exemple d'attaque ; sabotage par l'agent | 1, 2, 7, 8, 9 |
| 2606.07624 (Xie) | voisin (idée proposée, non réalisée) | scores séquentiels, alarme par temps d'arrêt, raisonnement toujours valide recommandé ; représentations internes nommées comme source de scores optionnelle | toute mesure ; agent ; sabotage | 3, 4, 5 |
| 2604.08608 (Ahad et al.) | voisin faible | régime « chaque sous-tâche passe le classifieur » | accumulation ; sondes ; garantie ; séquentiel | 1, 3 |

**Verdict d'ensemble H2 : non occupée.** La conjonction de N-007 n'est dans aucune des six sources. Une occupation partielle de plus en boîte noire (Corll), qui s'ajoute à celles déjà au tableau (SafeDream, Kulkarni, FIPER…).

**Ce qui change dans la formulation de ce qui reste revendicable** : rien dans l'énoncé. Deux ajouts de prudence, à proposer au préenregistrement de G1 :
- citer Corll pour le squelette « somme cumulée de scores sous le seuil, dérive prise sur le bénin, contre le maximum », et reprendre sa condition comme hypothèse à tester et non comme acquis : H2 ne peut tenir que si les scores de sonde des actions sabotées sont élevés sous le seuil ; si les sondes donnent aux actions sabotées et honnêtes les mêmes scores, aucune accumulation n'y changera rien ;
- citer Helm et collègues pour le risque de base honnête qui dérive : la garantie de H2 est calibrée sur des épisodes honnêtes entiers, elle ne vaut que si le régime honnête du déploiement est celui du calibrage.

### L — lemme d'additivité, énoncé adverse (N-004)

| source | verdict | fait | non fait | pages |
|---|---|---|---|---|
| 2605.11135 | voisin | un budget attendu de défections indépendant de la durée d'étalement, étalé jusqu'à être invisible dans toute fenêtre ; la somme cumulée à référence fixe accumule, à référence glissante absorbe | énoncé additif exact ; borne toujours valide ; coût du report ; scores de sondes | 8, 9, 16, 17 |
| 2606.20746 | voisin | séparation mesurée entre somme cumulée et maximum sur greffes étalées (écart de persistance 0,708 contre écart de pic 0,417, quatre contre six) ; arithmétique de la tolérance : rien n'est compté sous la dérive | budget total ; invariances ; garantie ; puissance (non testée) | 1, 4, 6, 7, 9 |
| 2601.05427 | voisin (outils) | temps de détection borné en fonction de la marge et du seuil ; marge strictement positive nécessaire ; le seuil croît avec le nombre d'hypothèses suivies | répartition d'un budget ; calendrier ; adversaire | 5, 23 |
| 2607.24893 | voisin faible | moyenner des traits sur la trajectoire dilue une signature portée par un ou deux pas | énoncé statistique | 9 |
| 2606.07624 ; 2604.08608 | ne touche pas | — | — | — |

**Verdict d'ensemble L : non occupée ; trois voisins de plus.** L'énoncé adverse complet appliqué aux scores de sondes reste revendicable. Le point L3 (« le calendrier compte », étaler aide l'attaquant) a un parent publié en boîte noire chez Helm et collègues, à citer.

### T — théorème négatif (N-003)

| source | verdict | fait | non fait | pages |
|---|---|---|---|---|
| 2605.11135 | **voisin fort** (moitié négative, en boîte noire, par un autre mécanisme) | théorème d'existence : toute carte dont la référence est réestimée sur une fenêtre récente laisse passer une défection assez lente, par invariance de position ; remarque sur la somme cumulée et sa tolérance ; conjecture d'impossibilité générale | sous-groupes de permutations ; unification temps × agents ; classes C et K ; garanties locales face à un attaquant adaptatif (la direction inverse est dite non formalisée) ; activations | 7, 8, 9, 10 |
| 2606.20746 | voisin | une somme cumulée est aveugle à toute greffe tenue sous sa dérive ; l'accumulation n'aide que dans une bande étroite | théorème ; pièces revendiquées | 4, 8, 9 |
| 2604.08608 | voisin (moitié négative, sans valeur de preuve) | affirmation qu'un contrôle par sous-tâche est aveugle à un dommage de composition | « théorèmes » tautologiques ou prouvés par dix cas, contredits dans l'article | 3, 9 |
| 2607.24893 | voisin | renvoi à 2607.11751 pour l'aveuglement local ; ici les fragments restent visibles localement | énoncé | 3 |
| 2601.05427 ; 2606.07624 | ne touche pas | — | — | — |

**Verdict d'ensemble T : non occupée.** Les quatre pièces de N-003 restent revendicables. À ajouter aux citations : le théorème 1 de Helm et collègues comme résultat négatif voisin, d'un mécanisme différent (dérive de la référence, pas invariance par permutation). Leur phrase sur la direction inverse non formalisée ([H21]) est une limite reconnue par eux, pas la preuve que T3 est sans précédent.

### H1 — gain de la boîte blanche sur la boîte noire

Les six articles : **ne touche pas**. Aucun ne compare un accès interne à un accès externe. Helm et collègues ([H17], [H18]) et Xie ([X3]) nomment l'accès interne comme une piste ; Fernandez Arias et collègues montrent en boîte noire qu'un détecteur peut ne mesurer que la longueur du texte ([F14]), ce qui conforte l'exigence du programme d'un prédicteur sur les traits du texte (N-029), sans rien dire de H1.

### H3 — courbe de sécurité selon le nombre d'agents, à budget constant

| source | verdict | fait | non fait | pages |
|---|---|---|---|---|
| 2605.11135 | **occupée en partie, en boîte noire** (lecture dure ; lecture « voisin » défendable) | contamination et rapport d'alarme selon la taille du système (10² à 10⁵) et le degré moyen, à 1, 10 ou 100 agents dormants | courbe boîte blanche ; budget de sabotage réparti entre N agents (ici N est la population honnête) ; agents à modèle de langue (fonction de substitution) ; détection significative | 18, 19 |
| 2601.05427 | voisin faible | seuil et temps de détection qui croissent avec le nombre de joueurs et d'actions ; essai à 20 joueurs | sabotage ; budget ; comparaison blanc / noir | 4, 5, 34, 35 |
| 2607.24893 ; 2604.08608 | ne touche pas (quatre fragments sur trois sous-agents, trois sous-tâches : aucun balayage) | — | — | — |
| 2606.07624 ; 2606.20746 | ne touche pas | — | — | — |

**Verdict d'ensemble H3 : inchangé.** Les deux courbes (boîte blanche et boîte noire) en N à budget total constant restent revendicables ; une courbe boîte noire de plus est publiée, d'un sens différent de N.

### H4′ — diversification contre coordination

Les six articles : **ne touche pas**. Helm et collègues ne citent l'hétérogénéité des modèles de base que parmi leurs simplifications. Verdict d'ensemble inchangé.

### H5 — nombre × diversité des moniteurs

| source | verdict | fait | non fait | pages |
|---|---|---|---|---|
| 2606.20746 | voisin | transfert d'une attaque cloisonnée contre une famille de détecteur vers une autre famille, mesuré (1 fuite sur 24 greffes, 0 sur 23) ; détecteur d'ensemble par maximum de deux familles | sécurité selon M ; diversité effective ; panel de sondes | 3, 9, 10 |
| 2605.11135 | voisin lointain | suggestion de faire tourner ensemble deux cartes différentes pour réduire les calendriers qui échappent aux deux ([H22]) | toute mesure | 10 |
| les quatre autres | ne touche pas | — | — | — |

Verdict d'ensemble inchangé.

### H7 — riposte et fuite d'information

| source | verdict | fait | non fait | pages |
|---|---|---|---|---|
| 2601.05427 | voisin lointain | la réaction d'agents qui apprennent aux détections est nommée comme travail futur | toute mesure | 9 |
| 2605.11135 | voisin lointain | conjecture d'un jeu entre moniteur et adversaire ; adversaire adaptatif exclu | toute mesure | 10 |
| 2606.20746 | voisin lointain | le générateur n'a accès qu'à un détecteur de cloisonnement, jamais aux verdicts du détecteur évalué | politique de riposte ; information mutuelle ; pente d'adaptation | 3, 5 |
| les trois autres | ne touche pas | — | — | — |

Verdict d'ensemble inchangé.

### Statistique de population du papier B — co-élévation d'états internes entre copies ; statistique spatio-temporelle (E3.1)

| source | verdict | fait | non fait | pages |
|---|---|---|---|---|
| 2601.05427 | **occupée en partie pour le squelette statistique** (lecture dure ; lecture « voisin fort, outil » défendable) | un processus e par agent, garantie toujours valide, combinaison entre agents par e-BH à temps d'arrêt commun, alarme plus précoce quand plusieurs processus montent ensemble ; essai à 20 joueurs | états internes ; copies d'un modèle ; modèle de langue ; adversaire ; dépendance entre tours ; localisation du fautif (les alarmes tombent sur les joueurs conformes) ; comparaison à la coupe transversale | 4, 5, 6, 31, 34, 35, 36 |
| 2605.11135 | **occupée en partie, en boîte noire** | statistique de population (distribution des agents dans un espace de plongement de leurs réponses) suivie dans le temps ; jusqu'à cent mille agents en simulation | états internes ; co-élévation de scores de sondes ; garantie toujours valide ; comparaison au séquentiel par agent (renvoyée aux travaux futurs, [H19]) ; adversaires coordonnés | 2, 3, 4, 10, 18 |
| 2607.24893 | voisin (résultat négatif) | flux réuni de tous les agents ; le signal ne vient pas de la mise en commun entre agents ([F14]) ; un détecteur bâti pour la structure coordonnée est laissé ouvert | statistique entre agents ; états internes | 4, 8, 10, 11 |
| 2604.08608 | voisin faible | contrôle conjoint du plan contre contrôle par sous-tâche | statistique ; états internes | 1, 3 |
| 2606.07624 ; 2606.20746 | ne touche pas | — | — | — |

**Verdict d'ensemble : la co-élévation d'états internes entre copies, lue par des sondes, n'est occupée par aucune des six sources. Mais le « cœur vierge » de E3.1 ne l'est plus pour son squelette.** Formulation proposée de ce qui reste revendicable :

> La statistique spatio-temporelle **sur les scores de sondes de copies d'un même modèle**, comparée au séquentiel par agent seul et à la coupe transversale, avec une garantie toujours valide tenue sous dépendance et face à un attaquant qui répartit son budget. Le squelette boîte noire est publié et se cite : processus e par agent combinés par e-BH à temps d'arrêt commun (2601.05427) ; statistique de population suivie par carte de contrôle (2605.11135).

C'est une **modification de revendication**, donc un nœud : je la signale, je ne la tranche pas.

## 4. Synthèse en une ligne par énoncé

- **H2** : non occupée ; une occupation partielle de plus en boîte noire (2606.20746), avec un contre-indice conditionnel (l'accumulation amplifie une marge, n'en crée pas).
- **L** : non occupée ; voisins 2605.11135, 2606.20746, 2601.05427.
- **T** : non occupée ; voisin fort 2605.11135 (théorème négatif boîte noire d'un autre mécanisme).
- **H1** : non touchée.
- **H3** : inchangée ; une courbe boîte noire en N de plus (2605.11135, simulation sans modèle de langue).
- **H4′** : non touchée.
- **H5** : inchangée ; voisin 2606.20746.
- **H7** : inchangée ; voisins lointains.
- **Statistique de population, papier B** : co-élévation d'états internes non occupée ; **squelette de la statistique spatio-temporelle occupé en partie en boîte noire** (2601.05427, 2605.11135) — reformulation proposée, nœud à trancher par Lazar.

## 5. Refus et incidents

Aucun refus de permission ni de classifieur. Aucune commande git, aucun appel réseau, aucun appel de modèle. Deux sorties de commande trop longues ont été enregistrées par l'outil hors du dossier de travail (fichiers temporaires de l'outil, relus aussitôt) ; rien d'autre n'a été écrit hors des chemins de sortie.

