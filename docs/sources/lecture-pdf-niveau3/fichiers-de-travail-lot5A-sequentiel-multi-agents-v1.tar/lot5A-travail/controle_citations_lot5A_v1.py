#!/usr/bin/env python3
"""Contrôle des citations du rapport du lot 5-A (niveau 3 de l'état de l'art).

Usage : python3 -I controle_citations_lot5A_v1.py DOSSIER_PDF FICHIER_CITATIONS.tsv [--essai]

Chaque ligne du fichier de citations : identifiant <TAB> fichier PDF <TAB> page <TAB> citation exacte.
La citation est cherchée dans le texte de la page extrait par `pdftotext -layout -f N -l N`
puis, à défaut, par `pdftotext -f N -l N` (ordre de lecture, utile pour les pages à deux colonnes
où le mode -layout entrelace les colonnes). La voie qui a réussi est imprimée.
Normalisation appliquée aux deux côtés : forme NFKC (ligatures), apostrophes et guillemets
typographiques ramenés à l'ASCII, tirets et signes moins supprimés (césures), espaces supprimés.
"""
import subprocess
import sys
import unicodedata


def normaliser(texte):
    t = unicodedata.normalize("NFKC", texte)
    for a, b in (("’", "'"), ("‘", "'"), ("“", '"'), ("”", '"'),
                 ("­", ""), ("−", "-"), ("–", "-"), ("—", "-"), ("‐", "-"), ("‑", "-")):
        t = t.replace(a, b)
    t = t.replace("-", "")
    return "".join(t.split())


def texte_page(pdf, page, layout):
    cmd = ["pdftotext"] + (["-layout"] if layout else []) + ["-f", str(page), "-l", str(page), pdf, "-"]
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, check=True)
    return r.stdout.decode("utf-8", errors="replace")


def controler(dossier, lignes):
    cache = {}
    echecs = 0
    voies = {"layout": 0, "ordre de lecture": 0}
    for ident, fichier, page, citation in lignes:
        trouve = None
        for nom, layout in (("layout", True), ("ordre de lecture", False)):
            cle = (fichier, page, layout)
            if cle not in cache:
                cache[cle] = normaliser(texte_page(dossier + "/" + fichier, page, layout))
            if normaliser(citation) and normaliser(citation) in cache[cle]:
                trouve = nom
                break
        if trouve:
            voies[trouve] += 1
            print("OK    %-5s %s p.%s (%s)" % (ident, fichier, page, trouve))
        else:
            echecs += 1
            print("ECHEC %-5s %s p.%s : %s" % (ident, fichier, page, citation[:90]))
    return echecs, voies


def lire(chemin):
    lignes = []
    with open(chemin, encoding="utf-8") as f:
        for brute in f:
            brute = brute.rstrip("\n")
            if not brute or brute.startswith("#"):
                continue
            ident, fichier, page, citation = brute.split("\t", 3)
            lignes.append((ident, fichier, int(page), citation))
    return lignes


def main():
    dossier, chemin = sys.argv[1], sys.argv[2]
    lignes = lire(chemin)
    if "--essai" in sys.argv:
        # Essai de la garde : un cas juste doit passer, le même cas altéré doit échouer.
        ident, fichier, page, citation = lignes[0]
        e1, _ = controler(dossier, [("juste", fichier, page, citation)])
        altere = citation.replace("e", "a", 3) + " zzz"
        e2, _ = controler(dossier, [("alter", fichier, page, altere)])
        e3, _ = controler(dossier, [("page", fichier, page + 3, citation)])
        ok = (e1 == 0 and e2 == 1 and e3 == 1)
        print("ESSAI DE LA GARDE : %s (juste=%d échec, altéré=%d échec, mauvaise page=%d échec)" % ("REUSSI" if ok else "RATE", e1, e2, e3))
        sys.exit(0 if ok else 2)
    echecs, voies = controler(dossier, lignes)
    print("TOTAL : %d citations contrôlées, %d échec(s) ; voies : %s" % (len(lignes), echecs, voies))
    sys.exit(0 if echecs == 0 else 1)


if __name__ == "__main__":
    main()
