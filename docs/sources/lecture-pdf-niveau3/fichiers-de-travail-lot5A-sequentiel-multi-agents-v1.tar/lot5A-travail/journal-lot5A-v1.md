# Journal du lot 5-A (heures relevées par date -u)

- 2026-11-10T10:57Z : consigne commune et interdits lus ; empreintes des six PDF vérifiées (six OK) ; énoncés lus (programme l. 85-125 et 190-215, décisions N-003/N-004, N-007/N-008, N-013, sections de anteriorite-v1.md).
- Extraction : txt/ (pdftotext -layout, par page) et brut/ (pdftotext sans -layout, par page).
- Lecture : voir la section 1 du rapport pour l'écart déclaré (annexes de preuves de 2601.05427 parcourues par titres et mots-clés seulement).
- Contrôle des citations : premier passage 119 citations, 2 échecs (C6 page fausse, H19 exposant parasite), corrigés ; second passage 0 échec. Garde essayée (juste, altéré, mauvaise page).
- 2026-11-10T11:04Z : rapport écrit, archive et scellement.
- Aucun refus. Aucune commande git, aucun réseau, aucun modèle.
