"""Controle des citations du mandat Tr (lecteur, modele A).
Usage : python3 -I verifier_citations_Tr_v1.py CITATIONS.json DOSSIER_PDF [DOSSIER_PDF ...]
Pour chaque citation : verifie l'empreinte du PDF, extrait la page par pdftotext
(avec et sans -layout), normalise (NFKC, ligatures, apostrophes, guillemets, tirets,
cesures, espaces) et cherche la citation normalisee. Code de sortie 1 si un echec.
"""
import hashlib, json, os, re, subprocess, sys, unicodedata

def norm(t):
    t = unicodedata.normalize("NFKC", t)
    for a, b in {"’": "'", "‘": "'", "“": '"', "”": '"', "′": "'",
                 "–": "-", "—": "-", "−": "-", "­": "", "‐": "-", "‑": "-",
                 "ﬁ": "fi", "ﬂ": "fl", "ﬀ": "ff", "ﬃ": "ffi", "ﬄ": "ffl"}.items():
        t = t.replace(a, b)
    return t

def variantes(texte):
    t = norm(texte)
    garde = re.sub(r"\s+", " ", t).strip()                      # cesure gardee : "red- teaming" -> "red- teaming"
    garde2 = re.sub(r"-\s*\n\s*", "-", t); garde2 = re.sub(r"\s+", " ", garde2).strip()  # "red-teaming"
    coupe = re.sub(r"-\s*\n\s*", "", t); coupe = re.sub(r"\s+", " ", coupe).strip()      # "teaming" recolle
    return [garde, garde2, coupe]

def page(pdf, n, layout):
    cmd = ["pdftotext"] + (["-layout"] if layout else []) + ["-f", str(n), "-l", str(n), pdf, "-"]
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout

def main():
    cit = json.load(open(sys.argv[1], encoding="utf-8"))
    dossiers = sys.argv[2:]
    def trouve(nom):
        for d in dossiers:
            p = os.path.join(d, nom)
            if os.path.isfile(p):
                return p
        raise FileNotFoundError(nom)
    echecs = 0
    cache = {}
    for i, c in enumerate(cit):
        chemin = trouve(c["pdf"])
        if chemin not in cache:
            cache[chemin] = hashlib.sha256(open(chemin, "rb").read()).hexdigest()
        if cache[chemin] != c["sha256"]:
            print(f"ECHEC {i} empreinte {c['pdf']}"); echecs += 1; continue
        q = re.sub(r"\s+", " ", norm(c["citation"])).strip()
        ok = False
        for layout in (True, False):
            for v in variantes(page(chemin, c["page"], layout)):
                if q in v:
                    ok = True; break
            if ok: break
        print(("OK    " if ok else "ECHEC ") + f"{i} {c['pdf']} p.{c['page']} : {c['citation'][:70]}")
        if not ok: echecs += 1
    print(f"TOTAL {len(cit)} citations, {echecs} echec(s)")
    sys.exit(1 if echecs else 0)

if __name__ == "__main__":
    main()
