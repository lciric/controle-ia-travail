# Journal du lecteur — mandat Tr, version 2 — modèle A (contre-lecteur : modèle B ; A ≠ B)

Journal écrit à 2026-11-13T23:33:29Z (date -u dans la commande d'écriture).

- 2026-11-13T23:26:32Z : empreintes vérifiées : contre-lecture 2a530bfe…5cb44, archive de contre-lecture 956e62f7…114dc, rapport v1 d04e2ef3…a670 (conformes). Archive de contre-lecture extraite dans contre-lecture-extraite/. Contre-lecture lue en entier.
- Pages relues contre les constats : 2601.04603 p. 5, 6, 7, 8, 9, 10, 11, 15, 16, 17 ; recherche par mots (coefficient, décroissance, demi-vie, alpha, facteur de lissage, moyenne mobile exponentielle) sur les 17 pages : aucun coefficient imprimé. 2609.19101 p. 3, 5, 6, 9, 10, 11, 13, 14, 17, 18, 24, 28, 37 (dont « cosine similarity » p. 14 et produit scalaire p. 6). 2603.04069 p. 4, 5, 6, 9.
- 2026-11-13T23:27:45Z : 37 citations nouvelles ajoutées aux 49 de la version 1 ; essais juste (code 0) et altéré (code 1) ; contrôle : 86 citations, 0 échec.
- Redémarrage du conteneur signalé par le coordinateur ; reprise à 2026-11-13T23:30:03Z : ni rapport-Tr-v2.md ni fichiers-de-travail-Tr-v2.tar n'existaient dans le dossier de sortie (ls de ce seul dossier). La même commande a listé par mégarde les noms des fichiers du dossier des pièces lot10/ (hors dépôt) : aucun autre PDF ouvert. Empreintes des trois PDF, de la consigne et de la contre-lecture revérifiées : conformes. Dossier de travail intact.
- Rapport v2 écrit ; décisions : A à J « corrigé » (C avec une réserve gardée dans la correction : lien fenêtre d'entraînement / lissage d'inférence non imprimé). Lettre de l'énoncé : « non trouvé dans les pièces lues », divergence maintenue avec le contre-lecteur (« occupé en partie »).
- 2026-11-13T23:33:29Z : contrôle final relancé sur citations-Tr-v2.json : 86 citations, 0 échec.
- Aucune commande git, aucun réseau, aucun appel de modèle, aucun refus.
