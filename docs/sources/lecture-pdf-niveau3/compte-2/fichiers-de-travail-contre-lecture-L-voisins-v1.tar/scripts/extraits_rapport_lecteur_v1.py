"""Verifie que tout extrait entre guillemets francais du rapport du lecteur qui contient des mots anglais
figure dans son JSON de citations. Usage : python3 -I ... rapport.md citations.json"""
import json, re, sys, unicodedata
def n(s):
    s = unicodedata.normalize("NFKC", s)
    for a, b in {"’": "'", "‘": "'", "“": '"', "”": '"', "–": "-", "—": "-"}.items():
        s = s.replace(a, b)
    return " ".join(s.split())
txt = open(sys.argv[1], encoding="utf-8").read()
cit = {n(c["citation"]) for c in json.load(open(sys.argv[2], encoding="utf-8"))}
ext = re.findall(r"«\s*(.*?)\s*»", txt, flags=re.S)
hors = [e for e in ext if n(e) not in cit]
print(f"extraits entre guillemets : {len(ext)} ; hors JSON : {len(hors)}")
for e in hors:
    print("HORS JSON :", e[:120])
