"""Assemble le rapport : table des citations depuis le JSON, heures passees en arguments.
Verifie que tout extrait entre guillemets francais contenant une citation anglaise figure dans le JSON.
Usage : python3 -I ... gabarit.md citations.json sortie.md DEBUT FIN"""
import json, re, sys, unicodedata
gab, cj, sortie, debut, fin = sys.argv[1:6]
def n(s):
    return " ".join(unicodedata.normalize("NFKC", s).split())
cit = json.load(open(cj, encoding="utf-8"))
t = open(gab, encoding="utf-8").read()
lignes = ["| id | pièce | page | citation exacte |", "|---|---|---|---|"]
for i, c in enumerate(cit, 1):
    lignes.append(f"| C{i} | `{c['pdf']}` | {c['page']} | {c['citation']} |")
t = t.replace("@@TABLE@@", "\n".join(lignes)).replace("@@DEBUT@@", debut).replace("@@FIN@@", fin)
ens = {n(c["citation"]) for c in cit}
corps = t.split("## Annexe")[0]
ext = re.findall(r"«\s*(.*?)\s*»", corps, flags=re.S)
hors = [e for e in ext if n(e) not in ens]
print(f"extraits : {len(ext)} ; dans le JSON : {len(ext) - len(hors)} ; hors JSON : {len(hors)}")
for e in hors:
    print("HORS JSON :", e[:110])
ids = sorted({int(x) for x in re.findall(r"C(\d+)", corps)})
print("identifiants cites :", len(ids), "max", max(ids), "; non cites :", [i for i in range(1, len(cit) + 1) if i not in ids])
if "@@" in t:
    sys.exit("jeton restant")
open(sortie, "x", encoding="utf-8").write(t)
