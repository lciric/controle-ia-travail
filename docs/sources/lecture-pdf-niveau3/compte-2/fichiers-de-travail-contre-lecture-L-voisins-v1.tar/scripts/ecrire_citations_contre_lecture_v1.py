"""Ecrit citations-contre-lecture-L-voisins-v1.json (modele B). Usage : python3 -I ... sortie.json"""
import json, sys
K = ("ker-2006-batch-steganography-pooled-steganalysis.pdf", "a6ab71a257034976636aad130fb9a7715a45d3dd06cb69cf046475f8f231a2aa")
A = ("1202.6423v4.pdf", "ab6caeadb380ec322fb6d9400cde5aa04d6e32ddbb55a869c7efd6f3eebd1c49")
H = ("1906.08938v2.pdf", "3fbaedd9705420fff23cbadb9c7d3de2240c2714c23440cbf133718534194ea9")
B = ("2605.16140v1.pdf", "1f70a3284a2eca0b62cded4dd43e6f88cc6930e3275349a17bee76850860a72a")
C = [
 (K, 1, "J. Camenisch et al. (Eds.): IH 2006, LNCS 4437, pp. 265–281, 2007."),
 (K, 1, "Springer-Verlag Berlin Heidelberg 2007"),
 (K, 3, "the distribution of the detector response only depends on p in the form of a shift, so that the (additive) estimation error is independent of the true value."),
 (K, 4, "there is both a shape change and a negative bias for higher rates"),
 (K, 4, "all cover objects have the same capacity"),
 (K, 4, "the Steganographer has no control over the objects themselves, and chooses which to embed in at random."),
 (K, 4, "We also assume that the Steganographer wants to embed a fixed total amount of secret data"),
 (K, 4, "is the proportionate bandwidth."),
 (K, 5, "This suggests the study of sequential embedding and tests. We reserve this topic for future work"),
 (K, 5, "we believe that the practice of sequential steganography and steganalysis may be rather different from the fixed-size batch problems studied here."),
 (K, 7, "It is immediate that"),
 (K, 7, "given the shift hypothesis, the distributional shape of"),
 (K, 7, "does not depend on r or p. Therefore, the Steganographer has no reason to select any particular value of r and p, as long as they multiply to his bandwidth constraint B."),
 (K, 7, "Suppose that all Xi are independent and identically distributed"),
 (K, 7, "under the null hypothesis is approximately B."),
 (K, 7, "As long as ν > 1, evidence does accumulate, but the rate at which this happens, as N increases, depends critically on whether ν is greater, or less, than 2."),
 (K, 11, "The total amount of data hidden by the Steganographer is proportional to"),
 (K, 11, "To fix the risk of detection, we must"),
 (K, 11, "in this case the discrimination of the average statistic increases only as a power law"),
 (K, 12, "is well modelled by a t-distribution with ν = 1.61"),
 (K, 14, "Also, the average method cannot punish the Steganographer for using a suboptimal embedding strategy."),
 (K, 14, "Because performance of the average detector does not depend on r, we can pick only a single value of r and plot the false positive rate as N varies."),
 (K, 15, "the number of observations greater than 1 is quite sensitive to embedding at p = 1, although worthless for other batch parameters."),
 (K, 15, "for example the pooling method of counting observations greater than some threshold"),
 (K, 15, "because this leads to a game theoretical setup which can be intractable."),
 (K, 15, "In future work we should consider allowing the Steganographer to vary the amount of data embedded in each object (this results in a larger mixture)"),
 (K, 16, "there could be an amplification of the statistical traces, which we might exploit."),
 (K, 17, "and all are independent."),
 (A, 1, "arXiv:1202.6423v4 [cs.IT] 20 Mar 2013"),
 (A, 2, "symbols in covertext of size n may safely be modified"),
 (A, 8, "is the Fisher information that an observation of noise carries about its power."),
 (A, 14, "This result was extended to Markov"),
 (A, 14, "both laws follow from the property that relative entropy is locally quadratic"),
 (A, 15, "Suppose Alice employs an arbitrary codebook"),
 (A, 15, "but he is oblivious to her signal properties and employs only a simple power detector."),
 (A, 16, "determines its detectability by this detector, and that our result applies to all codewords with power of the same order."),
 (A, 16, "We bound it using (13) and (14) with Chebyshev’s Inequality"),
 (A, 21, "under additional constraints such as delay should be analyzed."),
 (A, 24, "This product is the average symbol power used by Alice."),
 (A, 27, "The square root law does not require a linear key"),
 (A, 27, "Reliable deniable communication: Hiding messages in noise"),
 (A, 27, "A. D. Ker, “A capacity result for batch steganography,” IEEE Signal Processing Letters, vol. 14, no. 8, pp. 525–528, Aug."),
 (H, 15, "Sel. Areas Commun., vol. 31, no. 9, pp. 1921–1930, Sep. 2013."),
 (B, 34, "A. Ker, “A capacity result for batch steganography,” IEEE Signal Processing Letters, vol. 14, no. 8, pp. 525–528, 2007."),
]
out = [{"pdf": p[0], "sha256": p[1], "page": pg, "citation": c} for (p, pg, c) in C]
json.dump(out, open(sys.argv[1], "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(out))
