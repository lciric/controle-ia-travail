"""Contre-calcul (modele B) : detecteur de puissance S = moyenne des carres (Bash et collegues, p. 15-16)
et statistique somme, sous deux contraintes de budget.
(a) energie totale fixee (somme des f_i^2) : la loi de S ne depend pas de la repartition (khi-deux decentre).
(b) budget LINEAIRE fixe (somme des delta_i = B, celui du lemme L) : la somme est invariante,
    le detecteur de puissance ne l'est pas (energie = B^2/m pour m decalages egaux).
Graines : numpy.random.SeedSequence, derivees par cas. Aucun reseau, aucun modele."""
import json, sys
import numpy as np

RACINE = 20261114
n, sigma, rep = 200, 1.0, 200000
ss = np.random.SeedSequence(RACINE)
enfants = ss.spawn(8)
out = {"racine": RACINE, "n": n, "sigma": sigma, "repetitions": rep, "numpy": np.__version__}

def stats(f, graine):
    rng = np.random.default_rng(graine)
    y = rng.normal(0.0, sigma, size=(rep, n)) + f[None, :]
    return (y ** 2).mean(axis=1), y.sum(axis=1)

# seuils sous l'hypothese nulle (niveau 0,05), tires a part
S0, T0 = stats(np.zeros(n), enfants[0])
cS, cT = np.quantile(S0, 0.95), np.quantile(T0, 0.95)

# (a) energie totale E fixee, trois repartitions
E = 40.0
reps_a = {"concentree (1 symbole)": np.r_[np.sqrt(E), np.zeros(n - 1)],
          "etalee (n symboles)": np.full(n, np.sqrt(E / n)),
          "inegale (10 symboles, signes alternes)": np.r_[np.sqrt(E * np.arange(1, 11) / 55.0) * (-1) ** np.arange(10), np.zeros(n - 10)]}
out["a_energie_fixee"] = {}
for k, (nom, f) in enumerate(reps_a.items()):
    S, T = stats(f, enfants[1 + k])
    out["a_energie_fixee"][nom] = {"energie": float((f ** 2).sum()), "somme_lineaire": float(f.sum()),
        "puissance_detecteur_puissance": float((S >= cS).mean()), "quantiles_S": [float(q) for q in np.quantile(S, [0.1, 0.5, 0.9])],
        "puissance_somme": float((T >= cT).mean())}

# (b) budget lineaire B fixe, m decalages egaux
B = 25.0
out["b_budget_lineaire_fixe"] = {}
for k, m in enumerate([1, 10, 200]):
    f = np.r_[np.full(m, B / m), np.zeros(n - m)]
    S, T = stats(f, enfants[4 + k])
    out["b_budget_lineaire_fixe"][f"m={m}"] = {"energie": float((f ** 2).sum()), "somme_lineaire": float(f.sum()),
        "puissance_detecteur_puissance": float((S >= cS).mean()), "puissance_somme": float((T >= cT).mean())}
json.dump(out, sys.stdout, indent=1, ensure_ascii=False)
