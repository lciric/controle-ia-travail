"""Controle independant des citations (contre-lecture L voisins, modele B).
Usage : python3 -I controle_citations_contre_lecture_v1.py citations.json DOSSIER_PDF [DOSSIER_PDF ...]
Chaque citation {pdf, sha256, page, citation} doit figurer dans le texte de la page extrait par
pdftotext, avec ou sans -layout, apres normalisation (ligatures, apostrophes, guillemets, tirets,
cesures de fin de ligne, espaces). Sortie 0 seulement si zero echec."""
import hashlib
import json
import os
import re
import subprocess
import sys
import unicodedata

REMPL = {"’": "'", "‘": "'", "“": '"', "”": '"', "–": "-", "—": "-",
         "‐": "-", "‑": "-", "−": "-", "­": "", " ": " ", "'": "'"}


def normaliser(texte):
    t = unicodedata.normalize("NFKC", texte)
    for a, b in REMPL.items():
        t = t.replace(a, b)
    return " ".join(t.split())


def recoller(texte):
    # cesure de fin de ligne : "embed- ding" -> "embedding"
    return re.sub(r"(?<=[A-Za-z])- (?=[a-z])", "", texte)


def texte_page(chemin, page, layout):
    cmd = ["pdftotext", "-f", str(page), "-l", str(page)]
    if layout:
        cmd.append("-layout")
    cmd += [chemin, "-"]
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout


def trouver(nom, dossiers):
    for d in dossiers:
        c = os.path.join(d, nom)
        if os.path.isfile(c):
            return c
    return None


def main(chemin_json, dossiers):
    with open(chemin_json, encoding="utf-8") as f:
        citations = json.load(f)
    echecs = 0
    cache_sha, cache_txt = {}, {}
    for i, c in enumerate(citations, 1):
        chemin = trouver(c["pdf"], dossiers)
        if chemin is None:
            print(f"ECHEC {i:3d} fichier introuvable {c['pdf']}")
            echecs += 1
            continue
        if chemin not in cache_sha:
            with open(chemin, "rb") as f:
                cache_sha[chemin] = hashlib.sha256(f.read()).hexdigest()
        if cache_sha[chemin] != c["sha256"]:
            print(f"ECHEC {i:3d} empreinte {c['pdf']}")
            echecs += 1
            continue
        cible = normaliser(c["citation"])
        ok = False
        for layout in (True, False):
            cle = (chemin, c["page"], layout)
            if cle not in cache_txt:
                cache_txt[cle] = normaliser(texte_page(chemin, c["page"], layout))
            page = cache_txt[cle]
            if cible in page or recoller(cible) in recoller(page):
                ok = True
                break
        if ok:
            print(f"OK    {i:3d} {c['pdf']} p.{c['page']} {c['citation'][:80]}")
        else:
            print(f"ECHEC {i:3d} {c['pdf']} p.{c['page']} {c['citation'][:80]}")
            echecs += 1
    print(f"TOTAL citations={len(citations)} echecs={echecs}")
    return echecs


if __name__ == "__main__":
    sys.exit(1 if main(sys.argv[1], sys.argv[2:]) else 0)
