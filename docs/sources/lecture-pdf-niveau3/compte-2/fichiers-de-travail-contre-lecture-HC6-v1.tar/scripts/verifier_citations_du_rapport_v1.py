"""Verifie que chaque passage anglais entre guillemets francais du rapport du lecteur est une sous-chaine
d'une citation de son fichier JSON (meme page non exigee ici). Usage : python3 -I ce_script RAPPORT.md CITATIONS.json"""
import json, re, sys, unicodedata
def n(t):
    t = unicodedata.normalize("NFKC", t)
    for a in "‘’": t = t.replace(a, "'")
    for a in "‐‑‒–—−": t = t.replace(a, "-")
    return re.sub(r"\s+", " ", t).strip().casefold()
rap = open(sys.argv[1], encoding="utf-8").read(); cits = [n(c["citation"]) for c in json.load(open(sys.argv[2], encoding="utf-8"))]
ANG = re.compile(r"\b(the|of|and|is|are|a|to|on|in|we|our)\b", re.I)
tot = bad = 0
for m in re.finditer(r"«\s*(.+?)\s*»", rap, re.S):
    q = m.group(1)
    if len(ANG.findall(q)) < 3 or re.search(r"[éèàùçêô]", q): continue
    tot += 1
    if not any(n(q) in c for c in cits):
        bad += 1; print("HORS JSON :", q[:120])
print("passages anglais :", tot, "; hors du fichier de citations :", bad)
