"""Recalculs du contre-lecteur (modele B) sur les valeurs imprimees de 2608.11247v1
(tableaux 1, 2, 4, 6 ; coefficients imprimes p. 5, 6, 14). Python pur, lance par python3 -I."""
import math

def ols(x, y):
    n = len(x); mx = sum(x)/n; my = sum(y)/n
    sxx = sum((a-mx)**2 for a in x); sxy = sum((a-mx)*(b-my) for a, b in zip(x, y))
    syy = sum((b-my)**2 for b in y)
    sl = sxy/sxx; ic = my - sl*mx
    r2 = sxy*sxy/(sxx*syy)
    res = [b-(ic+sl*a) for a, b in zip(x, y)]
    return sl, ic, r2, res, mx, sxx

def pearson(x, y):
    n = len(x); mx = sum(x)/n; my = sum(y)/n
    return sum((a-mx)*(b-my) for a, b in zip(x, y))/math.sqrt(sum((a-mx)**2 for a in x)*sum((b-my)**2 for b in y))

def rangs(v):
    idx = sorted(range(len(v)), key=lambda i: v[i]); r = [0.0]*len(v); i = 0
    while i < len(v):
        j = i
        while j+1 < len(v) and v[idx[j+1]] == v[idx[i]]: j += 1
        for k in range(i, j+1): r[idx[k]] = (i+j)/2+1
        i = j+1
    return r

def spearman(x, y): return pearson(rangs(x), rangs(y))

def p_bilaterale(r, n):
    """p bilaterale du r de Pearson, loi de Student a n-2 degres, integration numerique."""
    df = n-2; t = abs(r)*math.sqrt(df/(1-r*r))
    c = math.gamma((df+1)/2)/(math.sqrt(df*math.pi)*math.gamma(df/2))
    f = lambda u: c*(1+u*u/df)**(-(df+1)/2)
    N = 200000; b = t; h = b/N
    s = f(0)+f(b)+sum((4 if i % 2 else 2)*f(i*h) for i in range(1, N))
    return 1-2*(s*h/3)

NOMS = ["sans intervention", "Devil", "QuestionDist", "EmpPersona", "Reflection", "Anchored", "Reasoning"]
# Tableau 6 p. 13 : (Res, Rec)
T6 = {
 "apparie": {
  "MMLU": [(74.9,59.6),(76.4,55.9),(80.0,53.8),(79.4,50.1),(82.8,44.3),(79.8,48.9),(77.5,61.8)],
  "GPQA": [(41.1,70.0),(40.3,66.3),(44.9,64.6),(49.1,59.2),(49.4,54.0),(45.7,58.8),(45.8,60.0)],
  "SimpleQA": [(17.8,94.3),(17.9,93.3),(19.6,93.7),(23.2,87.9),(27.8,86.3),(22.9,88.7),(23.7,86.9)]},
 "complet": {
  "MMLU": [(75.3,59.1),(76.7,55.0),(80.3,53.3),(79.8,49.8),(82.4,43.8),(80.2,48.2),(77.5,61.8)],
  "GPQA": [(41.1,70.0),(40.3,66.3),(45.0,64.6),(49.1,59.2),(49.4,54.0),(45.7,58.8),(45.8,60.0)],
  "SimpleQA": [(20.0,95.1),(21.2,94.2),(21.8,94.3),(25.5,89.1),(29.8,87.6),(25.5,89.9),(23.7,86.9)]}}
# Tableau 2 p. 7 : (dRes, dRec) pour Devil, QD, EP, Refl, Anch, Reasoning
T2 = {"MMLU": [(1.5,-3.7),(5.1,-5.8),(4.5,-9.5),(7.9,-15.3),(4.9,-10.7),(2.6,2.2)],
      "GPQA": [(-0.7,-3.7),(3.9,-5.4),(8.0,-10.8),(8.3,-16.0),(4.6,-11.2),(4.7,-10.0)],
      "SimpleQA": [(0.1,-1.0),(1.8,-0.5),(5.4,-6.4),(10.0,-8.0),(5.1,-5.6),(5.9,-7.3)]}

print("== 1. Frontiere (tableau 6) : R2 imprimes 0.88 / 0.80 / 0.90 ; ecarts imprimes +3.3 / -0.6 / -1.9")
for bloc in ("apparie", "complet"):
    for jeu, v in T6[bloc].items():
        res = [a for a, _ in v[:6]]; rec = [b for _, b in v[:6]]
        sl, ic, r2, e, mx, sxx = ols(rec, res)
        gap = v[6][0]-(ic+sl*v[6][1])
        print(f"{bloc:8s} {jeu:9s} pente {sl:+.3f} R2 {r2:.3f} ecart raisonnement {gap:+.2f} ; etendue receptivite {min(rec):.1f}-{max(rec):.1f}")

print("== 2. Chaque point retire a son tour (bloc apparie) : erreur de la droite des 5 autres, contre erreur de la moyenne des 5 autres")
for jeu, v in T6["apparie"].items():
    res = [a for a, _ in v[:6]]; rec = [b for _, b in v[:6]]
    ed = []; em = []
    for k in range(6):
        x = [rec[i] for i in range(6) if i != k]; y = [res[i] for i in range(6) if i != k]
        sl, ic, r2, e, mx, sxx = ols(x, y)
        s = math.sqrt(sum(u*u for u in e)/3)
        sp = s*math.sqrt(1+1/5+(rec[k]-mx)**2/sxx)
        err = res[k]-(ic+sl*rec[k]); errm = res[k]-sum(y)/5
        ed.append(err); em.append(errm)
        print(f"{jeu:9s} sans {NOMS[k]:17s} erreur droite {err:+.2f} (ecart-type residuel {s:.2f}, ecart-type de prediction {sp:.2f}, t {err/sp:+.2f}) ; erreur moyenne {errm:+.2f}")
    rq = lambda z: math.sqrt(sum(u*u for u in z)/len(z))
    print(f"{jeu:9s} racine de l'erreur quadratique : droite {rq(ed):.2f} ; moyenne {rq(em):.2f} ; rapport {rq(ed)/rq(em):.2f}")

print("== 3. Tableau 2 contre differences du tableau 6 apparie (ecart imprime moins difference des moyennes)")
for jeu in T2:
    b = T6["apparie"][jeu]
    d = [(round(T2[jeu][i][0]-(b[i+1][0]-b[0][0]), 2), round(T2[jeu][i][1]-(b[i+1][1]-b[0][1]), 2)) for i in range(6)]
    print(jeu, d)
print("Reflection, points de receptivite perdus par point de resistance gagne : MMLU %.2f GPQA %.2f SimpleQA %.2f" % (15.3/7.9, 16.0/8.3, 8.0/10.0))

print("== 4. Tableau 4 (conformite sous quatre pairs unanimes), 23 modeles dans l'ordre imprime")
ARCH = "M M D D D H M M D D D D D D M M D D M M M H D".split()
T4 = [(83.7,97.6,65.9),(59.0,93.8,80.0),(58.5,96.0,84.3),(56.9,88.7,90.1),(31.6,75.2,84.8),(26.9,61.9,93.1),(25.7,72.9,69.1),(21.7,70.8,91.5),(21.5,76.0,78.9),(19.7,58.7,79.6),(19.5,49.6,80.5),(18.8,59.4,77.6),(16.1,57.6,55.0),(13.4,50.3,55.9),(9.2,38.9,68.3),(8.8,28.0,76.3),(8.7,42.0,57.2),(6.0,30.2,61.1),(5.7,38.7,65.1),(5.1,21.7,57.6),(3.4,23.9,43.8),(2.6,17.7,53.3),(1.8,10.1,63.0)]
col = lambda j: [r[j] for r in T4]
print("n", len(T4), "moyennes (imprime 22.8 / 54.8 / 71.0) :", ["%.2f" % (sum(col(j))/23) for j in range(3)])
for a in "DMH":
    for j, jeu in enumerate(("MMLU", "GPQA", "SimpleQA")):
        v = [T4[i][j] for i in range(23) if ARCH[i] == a]; m = sum(v)/len(v)
        sd = math.sqrt(sum((u-m)**2 for u in v)/(len(v)-1)) if len(v) > 1 else float("nan")
        print(f"architecture {a} n {len(v)} {jeu} moyenne {m:.1f} ecart-type {sd:.1f}")
print("imprime p. 13-14 : D 22.7 (18.1), M 24.7 (28.2), H 14.7 sur MMLU ; 57.8, 54.0, 39.8 sur GPQA ; 72.3, 68.6, 73.2 sur SimpleQA")
for (i, j, n) in [(0,1,"MMLU-GPQA"),(0,2,"MMLU-SimpleQA"),(1,2,"GPQA-SimpleQA")]:
    rho = spearman(col(i), col(j))
    print(f"{n} Spearman {rho:.3f} (rho2 {rho*rho:.2f}, p {p_bilaterale(rho,23):.5f}) Pearson {pearson(col(i),col(j)):.3f}")
print("GPQA > MMLU :", sum(r[1] > r[0] for r in T4), "modeles ; SimpleQA > MMLU :", sum(r[2] > r[0] for r in T4))
# tiers : parmi les modeles du tiers le plus conforme sur un jeu, combien le sont sur l'autre
def tiers(j):
    o = sorted(range(23), key=lambda i: -T4[i][j]); return set(o[:8])
for (i, j, n) in [(0,1,"MMLU-GPQA"),(0,2,"MMLU-SimpleQA"),(1,2,"GPQA-SimpleQA")]:
    print(n, "recouvrement des 8 modeles les plus conformes :", len(tiers(i) & tiers(j)), "sur 8")

print("== 5. Valeurs p imprimees, recalculees a partir de r et n = 23 (57 pour les matieres)")
for r, n, imp in [(-0.64,23,"0.001"),(-0.49,23,"0.017"),(-0.42,23,"0.045"),(-0.32,23,"0.137"),(-0.44,23,"(apres retrait de l'architecture)"),(-0.34,23,"(idem)"),(-0.17,23,"non imprime"),(0.67,23,"non imprime"),(-0.92,57,"<1e-23")]:
    pv = p_bilaterale(r, n); print(f"r {r:+.2f} n {n} p {('inferieure a 1e-12 (limite numerique)' if pv < 1e-12 else format(pv, '.3g'))} ; imprime {imp} ; r2 {r*r:.2f}")

print("== 6. Bornes de la correlation directe resistance-receptivite entre modeles, sachant seulement leurs correlations avec l'exactitude")
for jeu, a, b in [("MMLU",0.67,-0.42),("GPQA",0.51,-0.32),("SimpleQA",0.06,0.00)]:
    c = math.sqrt((1-a*a)*(1-b*b))
    print(f"{jeu}: r(res,exact) {a:+.2f}, r(rec,exact) {b:+.2f} -> r(res,rec) entre {a*b-c:+.2f} et {a*b+c:+.2f}")

print("== 7. Coherence du decoupage par item p. 6 (reponse tenue sous un pair) avec le tableau 1")
for jeu, tenu, reste, tot, un in [("MMLU",14.7,73.4,22.8,11.2),("GPQA",34.4,84.0,54.8,36.5)]:
    p = (reste-tot)/(reste-tenu)
    print(f"{jeu}: part implicite des reponses tenues sous un pair {100*p:.1f} % ; non tenues {100*(1-p):.1f} % (conformite sous un pair, tableau 1 : {un} %) ; rapport des taux {reste/tenu:.1f}")
print("Tableau 1 : effet du dissident MMLU %.1f, SimpleQA %.1f (imprime 7.5 et 16.0) ; raisonne moins nu MMLU %.1f (imprime 2.1)" % (22.8-15.3, 71.0-54.9, 24.9-22.8))
print("resistance + conformite sans intervention : MMLU %.1f GPQA %.1f SimpleQA apparie %.1f complet %.1f" % (74.9+22.8, 41.1+54.8, 17.8+71.0, 20.0+71.0))
