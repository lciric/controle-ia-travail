"""Controle des citations du contre-lecteur (modele B), ecrit sans reprendre le script du lecteur.
Usage : python3 -I controle_citations_contre_lecture_v1.py CITATIONS.json DOSSIER_PDF
Chaque citation doit figurer dans le texte de sa page (pdftotext avec et sans -layout).
Niveaux : 1 = apres normalisation (espaces, ligatures, apostrophes, guillemets, tirets, cesures de fin de ligne) ;
2 = comme 1, tous les tirets retires (mots composes coupes en fin de ligne) ;
3 = comme 2, tous les espaces retires (colonnes entrelacees). Code de retour 1 au moindre echec."""
import hashlib, json, os, re, subprocess, sys, unicodedata

TABLE = {}
for a, b in (("ﬀ", "ff"), ("ﬁ", "fi"), ("ﬂ", "fl"), ("ﬃ", "ffi"), ("ﬄ", "ffl"), ("­", "")):
    TABLE[ord(a)] = b
for c in "‘’‚‛′´`": TABLE[ord(c)] = "'"
for c in "“”„‟″«»": TABLE[ord(c)] = '"'
for c in "‐‑‒–—―−": TABLE[ord(c)] = "-"

def n1(t):
    t = unicodedata.normalize("NFKC", t).translate(TABLE)
    t = re.sub(r"(?<=\w)-\s*\n\s*(?=\w)", "", t)
    return re.sub(r"\s+", " ", t).strip().casefold()
def n2(t): return re.sub(r"\s+", " ", n1(t).replace("-", "")).strip()
def n3(t): return n2(t).replace(" ", "")

def textes(pdf, page):
    for opt in (["-layout"], []):
        yield subprocess.run(["pdftotext"] + opt + ["-f", str(page), "-l", str(page), pdf, "-"],
                             capture_output=True, text=True, check=True).stdout

def controle(c, dossier, cache={}):
    pdf = os.path.join(dossier, os.path.basename(c["pdf"]))
    if pdf not in cache:
        with open(pdf, "rb") as f: cache[pdf] = hashlib.sha256(f.read()).hexdigest()
    if cache[pdf] != c["sha256"]: return 0, "empreinte differente"
    if not c["citation"].strip() or len(n3(c["citation"])) < 12: return 0, "citation trop courte"
    tx = list(textes(pdf, int(c["page"])))
    for niveau, f in ((1, n1), (2, n2), (3, n3)):
        q = f(c["citation"])
        if any(q in f(t) for t in tx): return niveau, "niveau %d" % niveau
    return 0, "absente de la page"

def main():
    cits = json.load(open(sys.argv[1], encoding="utf-8")); echecs = 0; par = {1: 0, 2: 0, 3: 0}
    for i, c in enumerate(cits, 1):
        niv, motif = controle(c, sys.argv[2])
        if niv: par[niv] += 1
        else: echecs += 1
        print("%02d p.%2d %s [%s] %s" % (i, c["page"], "OK   " if niv else "ECHEC", motif, c["citation"][:72]))
    print("TOTAL %d citations ; %d OK (niveau 1 : %d, niveau 2 : %d, niveau 3 : %d) ; %d echec(s)" % (len(cits), len(cits)-echecs, par[1], par[2], par[3], echecs))
    sys.exit(1 if echecs else 0)

if __name__ == "__main__": main()
