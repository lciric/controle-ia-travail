# Journal du contre-lecteur — rapport HC6 contre 2608.11247v1 (modèle B)

Début (date du dossier d'extraction, `date -u -r`) : 2026-11-13 23:13:52 UTC. Fin de rédaction (`date -u`) : 2026-11-13 23:21:24 UTC.

## Fichiers ouverts
Consigne commune du compte 2 (en entier, empreinte conforme) ; rapport-HC6-v1.md et son archive (empreintes conformes) ; programme v2 l. 85-125 et 190-215 ; décision N-005/N-006 l. 22-56 ; décision N-013 l. 86-95 ; état de l'art vérifié niveau 3 l. 449-463 ; sa contre-lecture l. 558-575 ; la pièce et son compagnon.
Lecture fautive déclarée : une recherche de motifs pour vérifier mes numéros de ligne a affiché, hors plages, les lignes 64, 78, 102, 119, 139, 148, 156, 164, 194, 202, 214, 230 de l'état de l'art vérifié niveau 3, la ligne 257 du programme, la ligne 20 de la décision N-005/N-006. Non utilisées.
Non ouverts : interdits-communs-v2.md (non nommé par mon mandat) ; anteriorite-v1.md (lu par le lecteur, non nommé par mon mandat).
Aucune commande git, aucun réseau, aucun appel de modèle, aucune recherche récursive dans le dépôt.

## Pièce
2608.11247v1.pdf, 17 pages, sha256 698fdcbd01ed6141535b76012d5aaced574691a8fba192f7e65020987e46f8f9, conforme au compagnon.
Lues ligne à ligne : p. 1-9 (corps), 12-17. Parcourues par mots : p. 9 (colonne droite), 10, 11 (références ; début de l'annexe A lu). Lues sur l'image : p. 5, 6, 7, 15, 16.
Comptage de racines par page : optimi p. 2 (1) ; persua p. 2, 5 (3), 10 ; generat p. 3, 4, 9 (2), 12 (2), 17 ; predict p. 3, 4, 5 (2), 7, 8, 14, 16 ; robust p. 9, 15 ; adaptive p. 11 (titre d'une référence) ; aucune occurrence de adversar, attack, monitor, jailbreak, manipulat, benign, safety, oversight, transfer, held-out, generaliz, deceiv, decept.

## Trouvailles par rapport au rapport
- p. 3 et 9 : sur SimpleQA, la réponse fausse des pairs est générée par un modèle extérieur (constat A).
- p. 6 : découpage par item, tenue sous un pair contre tenue sous quatre (constat B).
- p. 5 : corrélations de rangs entre jeux, fortes et positives (constat C).
- sens de « bénin » non fixé par les lignes lues de l'énoncé (constat D).
- p. 7 : intervalle de l'écart sur MMLU non imprimé, phrase fautive (constat F).

## Recalculs
scripts/recalculs_contre_lecteur_v1.py, Python pur, python3 -I ; sortie recalculs-contre-lecteur-v1.txt. Tous les chiffres du lecteur retrouvés.

## Contrôle des citations
scripts/controle_citations_contre_lecture_v1.py, python3 -I. Cas juste : 2 sur 2, code 0. Cas altéré (mot changé, mauvaise page, empreinte fausse, mots inversés) : 4 échecs sur 4, code 1. Mes citations : 39, 0 échec (37 au niveau 1, 2 au niveau 2). Citations du lecteur repassées par mon script : 49, 0 échec. Passages anglais du rapport du lecteur : 24, tous dans son fichier de citations.
