#!/usr/bin/env python3
"""Contrôle des citations (contre-lecture 4-B partie 1, v1).
Usage : python3 -I controle_citations_contre_lecture_v1.py <dossier des PDF> <fichier JSON>
Pour chaque objet {pdf, sha256, page, citation} : vérifie l'empreinte du PDF, puis que la citation
figure dans le texte de la page (pdftotext avec et sans -layout) après normalisation.
Code de sortie 0 si zéro échec, 1 sinon."""
import hashlib, json, os, re, subprocess, sys, unicodedata

def normaliser(t):
    t = unicodedata.normalize("NFKC", t)
    for a, b in (("ﬁ", "fi"), ("ﬂ", "fl"), ("ﬀ", "ff"), ("ﬃ", "ffi"), ("ﬄ", "ffl")):
        t = t.replace(a, b)
    t = re.sub("[‘’‛ʼ`´]", "'", t)
    t = re.sub("[“”„«»]", '"', t)
    t = re.sub("[‐‑‒–—−­]", "-", t)
    t = re.sub(r"-\s*\n\s*", "", t)          # césure de fin de ligne
    t = re.sub(r"\s+", " ", t)
    return t.strip().lower()

def sans_tirets_espaces(t):
    return re.sub(r"[-\s]", "", t)

def texte_page(pdf, page, layout):
    cmd = ["pdftotext"] + (["-layout"] if layout else []) + ["-f", str(page), "-l", str(page), pdf, "-"]
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout

def main():
    dossier, fichier = sys.argv[1], sys.argv[2]
    with open(fichier, encoding="utf-8") as f:
        citations = json.load(f)
    echecs = 0
    empreintes = {}
    for i, c in enumerate(citations, 1):
        pdf = os.path.join(dossier, c["pdf"])
        if c["pdf"] not in empreintes:
            with open(pdf, "rb") as f:
                empreintes[c["pdf"]] = hashlib.sha256(f.read()).hexdigest()
        ok_empreinte = empreintes[c["pdf"]] == c["sha256"]
        cible = normaliser(c["citation"])
        trouve = False
        for layout in (True, False):
            page = normaliser(texte_page(pdf, c["page"], layout))
            if cible in page or sans_tirets_espaces(cible) in sans_tirets_espaces(page):
                trouve = True
                break
        etat = "OK" if (trouve and ok_empreinte) else "ECHEC"
        if etat == "ECHEC":
            echecs += 1
        print(f"{etat} {i:3d} {c['pdf']} p.{c['page']} empreinte={'ok' if ok_empreinte else 'FAUSSE'} : {c['citation'][:70]}")
    print(f"TOTAL {len(citations)} citations, {echecs} échec(s)")
    sys.exit(1 if echecs else 0)

main()
