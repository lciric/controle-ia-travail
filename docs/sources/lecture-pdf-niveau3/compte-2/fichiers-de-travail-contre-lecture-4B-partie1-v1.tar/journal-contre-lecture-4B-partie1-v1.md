# Journal du contre-lecteur — lot 4-B, partie 1 sur 2 (v1)

Rôle : contre-lecteur, modèle B (auteur du rapport : modèle A). Heures relevées par `date -u`.

## Chronologie
- Consigne commune vérifiée (`cb0623c4…`, conforme) et lue en entier ; rapport (`e38c042f…`) et archive du lecteur (`b02839ed…`) conformes ; archive extraite dans `archive-A/` (dossier vide créé pour elle ; scripts tenus à part dans `outils/`).
- `interdits-communs-v2.md` non ouvert : la consigne le cite dans la méthode du lecteur, mon mandat ne le nomme pas ; lecture la plus stricte tenue (fichiers du mandat seulement).
- Fichiers du dépôt lus : N-065 l. 1-29 ; N-067 titres (`grep -n '^#'` sur ce seul fichier) puis l. 9-26 et 35-93 ; état de l'art niveau 3 l. 464-522 ; sa contre-lecture l. 607-634.
- 2026-11-14 00:16:54 UTC : empreintes des quatre PDF contrôlées contre les compagnons (conformes).
- Textes extraits page par page (`pdftotext -layout`) dans `textes/` (non archivé).
- 2609.28614 : p. 1-16 et 19-33 lues ligne à ligne ; p. 17-18 (références) lues pour les voisins ; p. 7 et 11 relues en image (outil Read).
- 2606.13044 : p. 6-11 et 25 ligne à ligne ; 35 pages par recherche de termes. 2510.18003 : p. 3, 4, 6, 9 ; 16 pages par termes. 2604.22080 : p. 3-4 ; 11 pages par termes.
- 2026-11-14 00:20:32 UTC : script testé (cas juste : 0 échec, code 0 ; cas altéré : 4 échecs attendus, 4 obtenus, code 1) ; 51 citations, 0 échec ; les 71 citations du lecteur recontrôlées par mon script : 0 échec.
- Contrôle programmatique : tout extrait entre « » de la contre-lecture absent du JSON est du français (liste relue). 47 des 51 citations contrôlées sont reprises dans le texte ; 4 sont contrôlées sans être reprises.
- Aucun homonyme des deux sorties dans le dossier de versement (`ls` sur les deux noms et leurs compagnons) avant scellement.

## Recalculs (nature « calcul »)
- Figure 3 de 2609.28614 (p. 7, image) : 12 + 10 + 9 + 9 + 7 + 7 + 7 × 6 + 3 × 5 + 3 = 114 ; points de l'autre couleur comptés : 3 + 2 + 1 + 1 + 2 = 9 ; 114 − 9 = 105.
- 9/306 = 2,94 % ; 105/340 = 30,9 % ; 103/340 = 30,3 % ; 104/340 = 30,6 % ; 30,5 % × 340 = 103,7.
- Intervalles de Wilson à 95 % : 33/505 → [4,7 ; 9,0] (conforme aux auteurs) ; 38/505 → [5,5 ; 10,2] ; 5/56 → [3,9 ; 19,3] ; 51/56 → [80,7 ; 96,1] ; 39/44 → [76,0 ; 95,0].
- Tableau 11 de 2606.13044 (p. 25) : (1,63 + 1,87 + 1,93 + 1,60 + 0,97) / 5 / 2 = 0,80, conforme.

## Recherches actives des composantes dites non trouvées
- 2609.28614, texte entier : termes de l'audit, du recalcul, de l'épreuve statistique, du nul, de la multiplicité ; trouvés : audit (p. 5, 6, 7, 11, 13, 15, 26, 27, 28, 31), tâche de p-hacking (p. 20), `idea_pitch` (p. 19, 27). Aucune attaque informée de l'audit, aucune courbe de l'audit par tour, aucun juge-tournoi.
- Trois autres pièces : termes d'un juge non génératif, d'un recalcul, d'une exécution, d'une épreuve statistique, d'un tournoi : rien qui touche les composantes (b), (c), (f).
- 2026-11-14 00:23:42 UTC : fin ; archive constituée (scripts, JSON, journal, sortie du contrôle, cas d'essai ; sans PDF ni textes extraits), puis scellement.
