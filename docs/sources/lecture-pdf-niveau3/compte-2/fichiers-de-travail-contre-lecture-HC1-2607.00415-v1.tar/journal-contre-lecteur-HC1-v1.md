# Journal du contre-lecteur — HC1, pièce 2607.00415 v1 (modèle B)

Heures relevées par `date -u` dans la commande qui écrit ce fichier : extraction de l'archive du lecteur 2026-11-13 23:02:44 UTC ; contrôle des citations 2026-11-13 23:07:59 UTC ; journal écrit 2026-11-13 23:11:08 UTC.

## Étapes
1. Consigne commune : empreinte vérifiée (conforme), lue en entier. Le fichier des interdits communs v2 n'est pas dans mon mandat : non ouvert.
2. Rapport du lecteur et archive : empreintes vérifiées (conformes) ; archive extraite dans `archive-lecteur/` ; journal, scripts, sorties et citations lus.
3. Fichiers de l'énoncé lus aux lignes du mandat, par `sed -n` (programme l. 85-125 ; N-005 et N-006 l. 22-75 ; N-013 l. 18-32 ; N-023 en entier ; N-068 l. 1-72 ; état de l'art de niveau 3 l. 329-360 ; sa contre-lecture l. 472-508).
4. PDF : empreinte du compagnon = empreinte calculée ; 15 pages. Texte extrait page par page, avec et sans `-layout` (dossier `textes/`, hors archive) ; pages 1 à 15 lues ligne à ligne.
5. Figures : images extraites par `pdfimages -png` (dossier `images/`, hors archive), composées sur fond blanc et rognées (`scripts/rogner.py`, `scripts/rogner2.py`, dossier `rognures/`, hors archive) ; relues à la résolution d'origine : 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13 (quatre rangées), 14 (quatre rangées), 15 (quatre rangées), 18 (premier panneau). Pages 2 à 4 vues aussi par l'outil Read sur le PDF. Non relues : figures 16, 17, 19, second panneau de la figure 18, figures 1, 7, 20, 21 (texte seulement).
6. Recherche par mots sur le texte complet (`grep` dans `textes/`) : judg, monitor, evaluat, agent, regress, confidence interval, error bar, seed, signific, slope, dose, linear, retrain, trained on, temperature, split, 5000, sample, std, shaded, attack, advers, jailbreak, flip-eligible, defin, control, placebo, neutral. Occurrences hors bibliographie : « agent » p. 2 (état de l'art) ; « evaluat » p. 2, 3, 10 à 13 (évaluation des sorties et des sondes) ; « linear » p. 1, 3, 7 (sondes) ; « signific » p. 4 (« significantly », sans test) ; « control » p. 1 (« controlled »), p. 4 (vecteurs aléatoires) ; « flip-eligible » p. 11, 12, 13 (légendes). Aucune : regress, confidence interval, error bar, seed, slope, dose, retrain, temperature, split, 5000, std, shaded, attack, advers, jailbreak, placebo, neutral.
7. Script de contrôle des citations écrit par moi (`scripts/controle_citations_cl.py`), testé sur `test-cas-cl.json` : cas juste réussi, cas altéré en échec, page fausse en échec (`sortie-test-cl.txt`).
8. Citations du lecteur rejouées par mon script : 57 sur 57 (`sortie-rejeu-citations-lecteur.txt`).
9. Mes citations : 36, 0 échec au premier passage (`citations-contre-lecture-HC1-v1.json`, `sortie-controle-cl-v1.txt`).
10. Calculs (`scripts/calculs_cl.py`, `sortie-calculs-cl.txt`), lancés par `python3 -I`.
11. Rédaction (`scripts/retouches.py` applique trois retouches et l'en-tête des heures).

## Incidents
Aucun refus, aucune ouverture fautive, aucune commande git, aucun réseau, aucun appel de modèle.
