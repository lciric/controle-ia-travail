"""Controle des citations du contre-lecteur (ecrit sans reprendre le script du lecteur).
Usage : python3 -I controle_citations_cl.py CITATIONS.json DOSSIER_DES_PDF
Chaque citation doit figurer dans le texte de sa page (pdftotext, avec et sans -layout),
apres normalisation des espaces, ligatures, cesures, apostrophes et tirets."""
import hashlib, json, os, re, subprocess, sys, unicodedata

def lisse(t):
    t = unicodedata.normalize("NFKC", t)
    t = t.translate({ord(c): "'" for c in "‘’‚‛′`´"})
    t = t.translate({ord(c): '"' for c in "“”„‟″"})
    t = t.translate({ord(c): "-" for c in "‐‑‒–—―−"})
    return t.replace("­", "")

def souple(t):   # espaces ramenes a un, cesure de fin de ligne recollee
    t = lisse(t)
    t = re.sub(r"([A-Za-z])-\s*\n\s*([a-z])", r"\1\2", t)
    return re.sub(r"\s+", " ", t).strip().lower()

def serre(t):    # ni espaces ni tirets
    return re.sub(r"[\s\-]+", "", lisse(t)).lower()

def page(pdf, n, layout):
    c = ["pdftotext"] + (["-layout"] if layout else []) + ["-f", str(n), "-l", str(n), pdf, "-"]
    return subprocess.run(c, capture_output=True, text=True, check=True).stdout

def main():
    cits = json.load(open(sys.argv[1], encoding="utf-8"))
    rate = 0
    empreintes = {}
    for i, c in enumerate(cits, 1):
        pdf = os.path.join(sys.argv[2], c["pdf"])
        if pdf not in empreintes:
            empreintes[pdf] = hashlib.sha256(open(pdf, "rb").read()).hexdigest()
        ok = False
        if empreintes[pdf] == c["sha256"] and c["citation"].strip():
            for layout in (False, True):
                t = page(pdf, c["page"], layout)
                if souple(c["citation"]) in souple(t) or (len(serre(c["citation"])) >= 12 and serre(c["citation"]) in serre(t)):
                    ok = True
        rate += (not ok)
        print(f"{'OK    ' if ok else 'ECHEC '} {i:3d} p.{c['page']:2d} {c['citation'][:70]!r}")
    print(f"BILAN : {len(cits)} citations, {rate} echec(s)")
    return 1 if rate else 0

sys.exit(main())
