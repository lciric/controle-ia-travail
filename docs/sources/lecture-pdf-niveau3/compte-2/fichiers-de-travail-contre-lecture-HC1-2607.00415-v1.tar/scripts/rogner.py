import sys
from PIL import Image
src, dst = sys.argv[1], sys.argv[2]
def blanc(n):
    im = Image.open(f"{src}/img-{n:03d}.png").convert("RGB")
    try:
        m = Image.open(f"{src}/img-{n+1:03d}.png").convert("L")
        if m.size == im.size:
            bg = Image.new("RGB", im.size, (255, 255, 255)); bg.paste(im, mask=m); im = bg
    except Exception as e:
        print("pas de masque", n, e)
    return im
for n, nom in [(1, "fig2"), (5, "fig4"), (7, "fig5"), (9, "fig6")]:
    blanc(n).save(f"{dst}/{nom}.png")
for n, nom in [(21, "fig13"), (23, "fig14"), (25, "fig15")]:
    im = blanc(n); w, h = im.size
    for r in range(4):
        im.crop((0, int(h * r / 4), w, int(h * (r + 1) / 4) + 20)).save(f"{dst}/{nom}-rang{r+1}.png")
