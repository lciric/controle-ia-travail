import sys
from PIL import Image
src, dst = sys.argv[1], sys.argv[2]
for n, nom in [(3, "fig3"), (11, "fig8"), (13, "fig9"), (15, "fig10"), (17, "fig11"), (19, "fig12"), (27, "p13a"), (29, "p13b"), (31, "p13c"), (33, "p13d"), (35, "p13e"), (37, "p13f"), (39, "p14a"), (41, "p14b")]:
    try:
        im = Image.open(f"{src}/img-{n:03d}.png").convert("RGB")
        m = Image.open(f"{src}/img-{n+1:03d}.png").convert("L")
        bg = Image.new("RGB", im.size, (255, 255, 255)); bg.paste(im, mask=m)
        if bg.size[0] > 2000: bg = bg.resize((1800, int(bg.size[1] * 1800 / bg.size[0])))
        bg.save(f"{dst}/{nom}.png")
    except Exception as e:
        print(nom, e)
