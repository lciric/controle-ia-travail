import sys
p = sys.argv[1]; t = open(p, encoding="utf-8").read()
R = [
 ("≈ 0,10-0,15 à la couche 13 chez Llama sous le médecin (base ≈ 0,55), ≈ 0,23 sous les trois autres ;",
  "≈ 0,10-0,15 à la couche 13 chez Llama sous le médecin (base ≈ 0,55), ≈ 0,23 sous chef résident et 3e année (pas de creux sous 1re année) ;"),
 ("(figure 11, courbes avec indice et de base confondues jusqu'à la couche 28)",
  "(figure 11, courbes avec indice et de base presque confondues jusqu'aux couches 23 à 28 selon le niveau)"),
 ("— sur les questions basculées sous le médecin, ce qui fixe le point haut par construction.",
  "— sur les questions basculées sous le médecin (déduit de la concordance avec les panneaux « médecin » des figures 10 à 12 ; les légendes ne le disent pas), ce qui fixe le point haut par construction."),
]
for a, b in R:
    assert t.count(a) == 1, a
    t = t.replace(a, b)
i = t.index("- **Date et heures**"); j = t.index("\n", i)
t = t[:i] + sys.argv[2] + t[j:]
open(p, "w", encoding="utf-8").write(t)
