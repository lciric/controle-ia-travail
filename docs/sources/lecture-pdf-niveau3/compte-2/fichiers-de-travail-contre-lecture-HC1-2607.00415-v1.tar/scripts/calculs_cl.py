"""Recalculs du contre-lecteur. Effectifs relus par moi sur les titres des panneaux
des figures 13 (p. 11), 14 (p. 12), 15 (p. 13), images extraites du PDF ; valeurs des
barres relues sur les figures 2 (p. 2), 5 et 6 (p. 4). Nature : calcul."""
from math import log, sqrt
E = {  # (basculees, resistees) par persona : medecin, chef resident, 3e annee, 1re annee
 "Gemma": [(1287, 1635), (291, 2631), (117, 2805), (68, 2854)],
 "Llama": [(2412, 730), (744, 2398), (738, 2404), (270, 2872)],
 "Qwen":  [(1577, 1431), (728, 2280), (406, 2602), (265, 2743)],
}
NOMS = ["medecin", "chef resident", "3e annee", "1re annee"]
FIG2 = {  # exactitudes lues (%), et ligne de base lue (%)
 "Gemma": ([33.5, 54.0, 58.5, 61.0], 58.5), "Llama": ([14.7, 49.0, 49.4, 60.5], 63.0), "Qwen": ([29.3, 47.3, 54.0, 57.0], 60.2)}
FIG6_SANS = {"Gemma": {"chef resident": 86, "1re annee": 97}, "Llama": {"chef resident": 80, "1re annee": 93}, "Qwen": {"chef resident": 78, "1re annee": 94}}
TEXTE_P2 = {"Llama": 15, "Qwen": 29, "Gemma": 34}
def wilson(k, n, z=1.96):
    p = k / n; d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d; h = z * sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return c - h, c + h
print("1. Taux de bascule et exactitude restante sur les questions correctes sans indice")
for m, L in E.items():
    tot = {a + b for a, b in L}; assert len(tot) == 1, tot
    n = tot.pop(); print(f"  {m} : {n} questions correctes sans indice (somme identique pour les quatre personas)")
    for nom, (a, b) in zip(NOMS, L):
        lo, hi = wilson(a, n)
        print(f"    {nom:14s} bascule {a:4d}/{n} = {100*a/n:5.1f} % [Wilson 95 % : {100*lo:4.1f} ; {100*hi:4.1f}]  exactitude restante {100*b/n:5.1f} %  logit {log(a/b):+.2f}")
    lg = [log(a / b) for a, b in L]
    print("    pas en logit, du bas vers le haut :", " ; ".join(f"{lg[i]-lg[i+1]:+.2f}" for i in (2, 1, 0)),
          "| pas en points de pourcentage :", " ; ".join(f"{100*(L[i][0]-L[i+1][0])/n:+.1f}" for i in (2, 1, 0)))
print("\n2. Texte p. 2 (15 / 29 / 34 %) contre exactitude restante sur les questions correctes")
for m, v in TEXTE_P2.items():
    a, b = E[m][0]; print(f"  {m} : texte {v} % ; effectifs {100*b/(a+b):.1f} % ; ecart {100*b/(a+b)-v:+.1f} points")
print("\n3. Figure 2 lue comme exactitude sur toutes les questions : base x exactitude restante")
for m, (vals, base) in FIG2.items():
    n = sum(E[m][0]); print(f"  {m} : base lue {base} % -> total implicite {n/(base/100):.0f} questions")
    for nom, v, (a, b) in zip(NOMS, vals, E[m]):
        pred = base * b / (a + b)
        print(f"    {nom:14s} figure 2 : {v:4.1f} % ; base x restante : {pred:4.1f} % ; ecart {v-pred:+.1f}")
print("\n4. Figure 6, barres « No hook » contre exactitude restante des effectifs des figures 13 a 15")
for m, d in FIG6_SANS.items():
    for nom, v in d.items():
        a, b = E[m][NOMS.index(nom)]; print(f"  {m} {nom:14s} barre {v} % ; effectifs {100*b/(a+b):.1f} % ; ecart {v-100*b/(a+b):+.1f}")
print("\n5. Llama, chef resident contre 3e annee : 744 contre 738 bascules sur 3142")
n = 3142; p1, p2 = 744 / n, 738 / n; se = sqrt(p1 * (1 - p1) / n + p2 * (1 - p2) / n)
print(f"  difference {100*(p1-p2):.2f} point ; erreur type non appariee {100*se:.2f} ; z = {(p1-p2)/se:.2f} (borne : le plan est apparie, covariance inconnue)")
print("\n6. Largeur d'un intervalle de Wilson a 95 % pour une exactitude de sonde lue sur un petit sous-ensemble")
for n, p in [(68, 0.45), (117, 0.35), (291, 0.20), (265, 0.25), (270, 0.80)]:
    lo, hi = wilson(round(p * n), n); print(f"  n = {n:3d}, exactitude lue {p:.2f} -> [{lo:.2f} ; {hi:.2f}]")
