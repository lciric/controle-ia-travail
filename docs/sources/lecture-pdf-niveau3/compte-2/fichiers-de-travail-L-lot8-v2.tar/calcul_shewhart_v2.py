# Calcul v2 (verification du constat B) : formule du theoreme 1 de 1906.08938v2 (p. 7, lue sur le PDF),
# Q_L(q) = (1 - g^(-1/(1+q)))^L, g = 500, energie q*L = E fixee.
# (i) part des fausses alarmes de la fenetre : (1 - 1/g)^L sans emission ;
# (ii) fenetre fixe de n pas, emission repartie sur m pas : alarme = 1 - (1 - 1/g)^(n-m) * Q_m(E/m).
g, n = 500.0, 100
Q = lambda L, q: (1 - g ** (-1 / (1 + q))) ** L
for E in (1.5, 3.0):
    print(f"E={E} (i) fenetre variable : L, Q, base sans emission, ecart")
    prev = None; mono = True
    for L in range(1, 201):
        b = (1 - 1 / g) ** L; e = b - Q(L, E / L)
        if prev is not None and e > prev + 1e-15: mono = False
        prev = e
        if L in (1, 10, 100, 200): print(f"  L={L:3d} Q={Q(L, E/L):.4f} base={b:.4f} ecart={e:.4f}")
    print(f"  ecart decroissant sur L=1..200 : {mono}")
    print(f"E={E} (ii) fenetre fixe n={n} : m, alarme ; sans emission {1-(1-1/g)**n:.4f}")
    prev = None; mono = True
    for m in range(1, n + 1):
        a = 1 - (1 - 1 / g) ** (n - m) * Q(m, E / m)
        if prev is not None and a > prev + 1e-15: mono = False
        prev = a
        if m in (1, 2, 10, 50, 100): print(f"  m={m:3d} alarme={a:.4f}")
    print(f"  alarme decroissante en m : {mono}")
