"""Remplit le gabarit : chaque {Cn} est remplace par la citation exacte n de citations-L-v2.json, entre guillemets."""
import hashlib, json, re, sys
heure = sys.argv[1]
cites = json.load(open("citations-L-v2.json", encoding="utf-8"))
nb_ech = int(sys.argv[2])
s = open("gabarit-rapport-L-v2.md", encoding="utf-8").read()
def rempl(m):
    c = cites[int(m.group(1)) - 1]
    return "« " + c["citation"] + " »"
s = re.sub(r"\{C(\d+)\}", rempl, s)
lignes = ["| n° | pièce | page | citation exacte |", "|---|---|---|---|"]
for i, c in enumerate(cites, 1):
    lignes.append(f"| C{i} | `{c['pdf']}` | {c['page']} | {c['citation'].replace('|', '/')} |")
s = s.replace("{TABLE_CIT}", "\n".join(lignes))
s = s.replace("{HEURE_FIN}", heure).replace("{NB_CIT}", str(len(cites))).replace("{NB_ECH}", str(nb_ech))
s = s.replace("{SHA_JSON}", hashlib.sha256(open("citations-L-v2.json", "rb").read()).hexdigest())
assert not re.search(r"\{(C\d+|HEURE_FIN|NB_CIT|NB_ECH|SHA_JSON|TABLE_CIT)\}", s), "gabarit non rempli"
open("rapport-L-lot8-v2.md", "w", encoding="utf-8").write(s)
print("ecrit", len(s))
