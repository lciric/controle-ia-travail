"""citations-L-v2.json = les 55 citations de la v1 (memes numeros C1-C55) + les nouvelles (C56 et suivantes)."""
import json
H = {"1906.08938v2.pdf": "3fbaedd9705420fff23cbadb9c7d3de2240c2714c23440cbf133718534194ea9",
     "2605.16140v1.pdf": "1f70a3284a2eca0b62cded4dd43e6f88cc6930e3275349a17bee76850860a72a",
     "math-0410072v1.pdf": "cfcca06ea5e2b3852549dd896f381b2141c82fffa787787fc6fb6a5db560cbbf"}
A, B, C = "1906.08938v2.pdf", "2605.16140v1.pdf", "math-0410072v1.pdf"
v1 = json.load(open("citations-L-v1.json", encoding="utf-8"))
nouv = [
 (B, 14, "where the instantaneous cost depends only on the current probing probability βi and channel state"),  # C56
 (B, 14, "the probing sequence should both use low probing intensity and avoid inducing statistically detectable structure"),  # C57
 (B, 21, "dropping the pre-change part of ECB"),  # C58
 (B, 21, "On the other hand, from Cauchy-Schwarz inequality,"),  # C59
 (B, 17, "but the observations are drawn from the pre-change distribution for all"),  # C60
 (B, 18, "representing the history of Alice’s causal information joined with oracle knowledge of the changepoint"),  # C61
 (B, 7, "we assume that Eve has full knowledge of Alice’s active policy"),  # C62
 (B, 7, "translates to the equality of PMFs"),  # C63
 (A, 4, "only depends on the instantaneous sample observation and is"),  # C64
 (A, 5, "the detection procedure is equivalent to sequentially comparing the received signal power to a pre-designed threshold"),  # C65
 (A, 6, "With the Shewhart test, the following theorem characterizes"),  # C66
 (A, 10, "monotonically decreasing in both q and L."),  # C67
 (A, 13, "is maximized in the middle of the feasible region of L."),  # C68
 (A, 10, "Corollary 3: Under the SR test, if"),  # C69
 (A, 10, "there exists a θ-covert (q, L)-system."),  # C70
 (A, 14, "converges to a quasi-stationary distribution"),  # C71
 (A, 14, "SR test is not sensitive to a statistical change that occurs at the beginning of the detection procedure"),  # C72
 (A, 5, "We refer to such an event as timely detection."),  # C73
 (A, 6, "Willie’s detection process makes sense only when timely detection occurs"),  # C74
 (A, 1, "bits covertly and reliably to Bob in n channel usages"),  # C75
 (A, 1, "when Willie does not exactly know when Alice starts to transmit (if she does)"),  # C76
 (A, 2, "the beginning of which is random and unknown to Willie"),  # C77
 (A, 15, "B. A. Bash, D. Goeckel, and D. Towsley, “LPD communication when the warden does not know when,”"),  # C78
 (A, 15, "B. A. Bash, D. Goeckel, and D. Towsley, “Covert communication gains from adversary’s ignorance of transmission time,”"),  # C79
 (B, 1, "from steganography [1]–[3] to covert communications [4]–[6]"),  # C80
 (B, 34, "A. Ker, “A capacity result for batch steganography,” IEEE Signal Processing Letters, vol. 14, no. 8, pp. 525–528, 2007."),  # C81
 (B, 1, "ability to perform stealthy attacks in cyber-physical systems [15], [16]"),  # C82
 (B, 35, "Security in stochastic control systems: Fundamental limitations and performance"),  # C83
 (C, 9, "Two detection boundaries are only different when"),  # C84
 (C, 10, "so that Mn is inefficient if"),  # C85
 (C, 11, "is unable to separate"),  # C86
 (C, 22, "such as in watermarking and steganography, could reasonably use the model"),  # C87
 (C, 14, "Section 4 describes some simulation experiments."),  # C88
 (A, 6, "for a given data packet to be transmitted, Alice need only consider the events of timely detection and missed detection"),  # C89
 (B, 32, "intuitively the ECB is overwhelmingly dominated by the post-change detection period"),  # C90
 (B, 21, "if possible (e.g., with oracle knowledge of the changepoint), Alice should try to"),  # C91
 (B, 35, "K.-W. Huang, H.-M. Wang, D. Towsley, and H. V. Poor, “LPD communication: A sequential change-point detection perspective,”"),  # C92
 (A, 12, "set the ARL2FA of Willie’s detector γ = 500"),  # C93
 (A, 15, "K. S. K. Arumugam and M. R. Bloch, “Keyless asynchronous covert communication,”"),  # C94
 (A, 15, "B. A. Bash, D. Goeckel, and D. Towsley, “Limits of reliable communication with low probability of detection on AWGN channels,”"),  # C95
 (B, 35, "H. Rao and L. Wang, “An Extensible Covert Communication Scheme Over the AWGN Channel With Feedback,”"),  # C96
 (B, 35, "“Quickest change detection in the presence of covert adversaries,”"),  # C97
 (B, 35, "“Quickest change detection in continuous-time in presence of a covert adversary,”"),  # C98
]
out = v1 + [{"pdf": p, "sha256": H[p], "page": g, "citation": c} for p, g, c in nouv]
json.dump(out, open("citations-L-v2.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(out))
