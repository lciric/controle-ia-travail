"""Verifie que chaque extrait entre guillemets du rapport figure dans le JSON des citations
(sous-chaine d'une citation controlee, apres normalisation), et liste les autres pour relecture."""
import json, re, sys, unicodedata
def norm(s):
    s = unicodedata.normalize("NFKC", s).replace("’", "'").replace("‘", "'")
    return re.sub(r"\s+", " ", s).strip()
rap = open(sys.argv[1], encoding="utf-8").read()
cits = [norm(c["citation"]) for c in json.load(open(sys.argv[2], encoding="utf-8"))]
extraits = re.findall(r"«\s*(.*?)\s*»", rap, flags=re.S)
dans, hors = 0, []
for e in extraits:
    n = norm(e)
    if any(n in c for c in cits):
        dans += 1
    else:
        hors.append(n)
print(f"{len(extraits)} extraits ; {dans} dans le JSON ; {len(hors)} hors JSON (a relire : francais attendu)")
for h in sorted(set(hors)):
    print("  HORS:", h)
