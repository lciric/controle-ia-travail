"""Controle des citations : chaque citation doit figurer dans le texte de sa page
(pdftotext avec et sans -layout), apres normalisation des espaces, ligatures,
cesures, apostrophes et tirets. Usage : python3 -I controle_citations.py DOSSIER_PDF citations.json"""
import hashlib, json, re, subprocess, sys, unicodedata, os

TIRETS = dict.fromkeys(map(ord, "‐‑‒–—―−"), "-")
APOS = {ord("‘"): "'", ord("’"): "'", ord("‛"): "'", ord("′"): "'",
        ord("“"): '"', ord("”"): '"', ord("„"): '"', ord("«"): '"', ord("»"): '"'}

def norm(s):
    s = unicodedata.normalize("NFKC", s)
    s = s.replace("­", "")
    s = s.translate(TIRETS).translate(APOS)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def variantes(texte):
    a = norm(texte)
    b = re.sub(r"(\w)- (\w)", r"\1\2", a)       # cesure supprimee
    c = re.sub(r"(\w)- (\w)", r"\1-\2", a)      # cesure gardee comme trait d'union
    return [a, b, c]

def page(pdf, n, layout):
    cmd = ["pdftotext"] + (["-layout"] if layout else []) + ["-f", str(n), "-l", str(n), pdf, "-"]
    return subprocess.run(cmd, capture_output=True, text=True).stdout

def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()

def trouver(dossier, nom):
    for racine, _, fichiers in os.walk(dossier):
        if nom in fichiers:
            return os.path.join(racine, nom)
    return None

def main():
    dossier, js = sys.argv[1], sys.argv[2]
    cits = json.load(open(js, encoding="utf-8"))
    echecs = 0
    cache = {}
    for i, c in enumerate(cits):
        p = trouver(dossier, c["pdf"])
        if p is None:
            print(f"ECHEC {i}: PDF introuvable {c['pdf']}"); echecs += 1; continue
        if p not in cache:
            cache[p] = sha(p)
        if cache[p] != c["sha256"]:
            print(f"ECHEC {i}: empreinte differente {c['pdf']}"); echecs += 1; continue
        cit = norm(c["citation"])
        ok = None
        for layout in (False, True):
            for v in variantes(page(p, c["page"], layout)):
                if cit in v:
                    ok = "layout" if layout else "brut"; break
            if ok: break
        if ok:
            print(f"OK    {i}: {c['pdf']} p.{c['page']} [{ok}] {cit[:70]}")
        else:
            print(f"ECHEC {i}: {c['pdf']} p.{c['page']} {cit[:90]}"); echecs += 1
    print(f"TOTAL {len(cits)} citations, {echecs} echec(s)")
    sys.exit(1 if echecs else 0)

if __name__ == "__main__":
    main()
