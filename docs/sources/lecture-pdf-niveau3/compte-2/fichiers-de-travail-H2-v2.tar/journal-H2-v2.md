# Journal du lecteur — mandat H2, version 2 — modèle A (contre-lecteur : modèle B ; A ≠ B)

Reprise : 2026-11-14 00:01:20 UTC (date -u). Journal écrit le 2026-11-14 00:08:46 UTC (date -u).

## Fichiers du dépôt ouverts pour la version 2
- contre-lecture-rapport-H2-v1.md : empreinte vérifiée 708b48c2…1bf1def, conforme ; lue en entier (215 lignes).
- fichiers-de-travail-contre-lecture-H2-v1.tar : empreinte vérifiée 47171de8…5f07, conforme ; extraite dans contre-lecture-extrait/ (sous-dossier neuf), journal et sorties lus comme données.
- Aucun autre fichier du dépôt ; aucune commande git, aucun réseau, aucun appel de modèle, aucune recherche récursive dans le dépôt.
- Le rapport v1 et son archive ne sont pas touchés.

## PDF relus (empreintes déjà vérifiées, inchangées)
- 2604.01151v2.pdf : 29 pages ligne à ligne (p. 1-29, annexes A à I).
- 2604.01151v4.pdf : 47 pages ligne à ligne (p. 1-47, annexes A à R, preuves Q et R).
- 2604.01151v1.pdf : lu en entier lors de la version 1 (texte encore en contexte) ; p. 8-9 réexaminées.
- 2110.00115v6.pdf : p. 1, 11, 16-20, 26, 29, 32, 38 réexaminées (lu en entier lors de la version 1).
- 2501.03982v5.pdf : p. 2-4, 12, 18 réexaminées (lu en entier lors de la version 1).

## Décisions par lettre
A corrigé ; B corrigé ; C corrigé ; D corrigé ; E réserve maintenue (corrections de fond faites, généralité de la formule « bat » non établie) ; F corrigé ; G corrigé ; H corrigé ; I corrigé ; J corrigé ; K corrigé.

## Contrôle des citations
- scripts/controle_citations.py (repris de la version 1), relancé sur essai/juste.json (0 échec) et essai/altere.json (2 échecs attendus).
- citations-H2-v2.json : 126 citations, 0 échec (controle-citations-sortie.txt). Une citation candidate (2110.00115 p. 9) a échoué et a été retirée sans être utilisée.
- Audit des guillemets du rapport v2 (guillemets-sortie.txt) : 179 extraits ; 153 dans le JSON ; 26 hors JSON, tous en français, relus un à un.

## Archive
Scripts, JSON, journal, sorties de contrôle, cas d'essai ; sans PDF, sans texte extrait, sans image ; l'extrait de l'archive de la contre-lecture n'y est pas repris.
