# Journal du lecteur — lot 4-B, partie 1 sur 2 (v2, contre-lecture intégrée)

Lecteur : modèle A ; contre-lecteur : modèle B ; A ≠ B. Heures relevées par `date -u`. Le journal v1 (`journal-4B-partie1-v1.md`) est repris tel quel dans l'archive.

- 2026-11-14 00:25:08 UTC : `ls` du seul dossier `compte-2/` : aucun `rapport-4B-partie1-v2.md` ni `fichiers-de-travail-4B-partie1-v2.tar`. Empreintes vérifiées : contre-lecture `e9c5ad74…` et archive `a5078ead…`, conformes.
- Contre-lecture lue en entier (150 lignes) ; archive extraite dans le sous-dossier neuf `contre-lecture-extraite-v1/` (journal, JSON, scripts, sortie du contrôle lus ; le contre-lecteur a recontrôlé mes 71 citations : 0 échec).
- 2609.28614 relu : p. 2-7, 10-13, 19-20, 26-28 (texte `pdftotext`) ; figure 8 (p. 11) relue en image. 2606.13044 p. 4 et 25 relues. Références p. 16-17 de 2609.28614 relues pour les voisins.
- Recalculs (calcul) : Wilson à 95 % : 33/505 [4,7 ; 9,0] ; 38/505 [5,5 ; 10,2] ; 51/56 = 91,1 % [80,7 ; 96,1] ; 5/56 = 8,9 % [3,9 ; 19,3] ; 39/44 = 88,6 % [76,0 ; 95,0] ; 492/505 = 97,4 % ; 103/340 = 30,29 % ; 104/340 = 30,59 %. Tous conformes à ceux du contre-lecteur.
- Citations v2 : 97 (71 de la v1 + 26 ajoutées) ; contrôle par `controle_citations_v1.py` (inchangé, testé en v1) : 0 échec (`sortie-controle-citations-v2.txt`). Contrôle programmatique : tout extrait entre « » du rapport v2 absent du JSON est du français (liste relue) ; une entrée et une seule par lettre de A à K dans la section 8.
- Décisions : A à K « corrigé » (onze) ; aucune « réserve maintenue » au sens du tableau ; pour G et H, la réserve de fond est gardée dans le texte corrigé.
- 2026-11-14 00:29:16 UTC : fin ; archive v2 constituée (scripts, JSON v2, journaux v1 et v2, sorties des contrôles v1 et v2, cas d'essai ; sans PDF, texte extrait ni image), puis scellement unique du rapport v2 et de l'archive v2.
