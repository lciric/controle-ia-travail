"""Contrôle des citations : chaque citation doit figurer dans le texte de sa page
(pdftotext avec et sans -layout), après normalisation. Usage :
python3 -I controle_citations_v1.py CITATIONS.json DOSSIER_PDF [DOSSIER_PDF...]"""
import json, subprocess, sys, re, unicodedata, hashlib, os

def normaliser(t):
    t = unicodedata.normalize("NFKC", t)  # ligatures (fi, fl...) et formes de compatibilité
    for a, b in {"’": "'", "‘": "'", "“": '"', "”": '"', "«": '"', "»": '"',
                 "–": "-", "—": "-", "−": "-", "‐": "-", "‑": "-", "­": ""}.items():
        t = t.replace(a, b)
    t = re.sub(r"(\w)-\s*\n\s*(\w)", r"\1\2", t)  # césures en fin de ligne
    t = re.sub(r"\s+", " ", t)
    return t.strip()

def compact(t):
    return re.sub(r"\s+", "", normaliser(t))

def texte_page(pdf, page, layout):
    cmd = ["pdftotext"] + (["-layout"] if layout else []) + ["-f", str(page), "-l", str(page), pdf, "-"]
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout

def trouver(nom, dossiers):
    for d in dossiers:
        for racine, _, fichiers in os.walk(d):
            if nom in fichiers:
                return os.path.join(racine, nom)
    return None

def main():
    cits = json.load(open(sys.argv[1], encoding="utf-8"))
    dossiers = sys.argv[2:]
    cache, echecs = {}, 0
    for i, c in enumerate(cits):
        chemin = trouver(c["pdf"], dossiers)
        ok = False
        if chemin:
            emp = hashlib.sha256(open(chemin, "rb").read()).hexdigest()
            if emp == c["sha256"]:
                cible = normaliser(c["citation"])
                for layout in (True, False):
                    cle = (chemin, c["page"], layout)
                    if cle not in cache:
                        cache[cle] = texte_page(chemin, c["page"], layout)
                    page = cache[cle]
                    if cible in normaliser(page) or compact(c["citation"]) in compact(page):
                        ok = True
                        break
        if not ok:
            echecs += 1
            print("ECHEC", i, c["pdf"], c["page"], c["citation"][:80])
    print(f"{len(cits)} citations, {echecs} échec(s)")
    sys.exit(1 if echecs else 0)

if __name__ == "__main__":
    main()
