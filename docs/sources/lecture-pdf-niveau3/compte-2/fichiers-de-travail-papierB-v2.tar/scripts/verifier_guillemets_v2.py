import json, re, sys
r = open(sys.argv[1], encoding="utf-8").read()
cits = [c["citation"] for c in json.load(open(sys.argv[2], encoding="utf-8"))]
fr = set("le la les des une un du de et est pas sur dans par pour ou ne que qui au aux".split())
n = bad = 0
for q in re.findall(r"«\s*(.+?)\s*»", r, flags=re.S):
    mots = re.findall(r"[A-Za-z']+", q)
    if not mots or sum(m.lower() in fr for m in mots) > 0 and not re.search(r"\b(the|of|and|is|we|in|to)\b", q):
        continue
    if not re.search(r"\b(the|of|and|is|we|in|to|a|our|it|for|not|at|on|as)\b", q, flags=re.I) and len(mots) < 3:
        # titres ou expressions courtes : vérifier aussi
        pass
    n += 1
    if q not in cits:
        bad += 1
        print("ABSENT :", q[:120])
print(n, "extraits anglais repérés,", bad, "absents du JSON")
