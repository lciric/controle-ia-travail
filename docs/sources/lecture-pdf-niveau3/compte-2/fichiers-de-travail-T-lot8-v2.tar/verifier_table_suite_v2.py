"""Vérifie que la table « Suite donnée à la contre-lecture » a exactement une entrée par lettre A à J, avec une décision admise."""
import re, sys
from pathlib import Path
s = Path(sys.argv[1]).read_text(encoding="utf-8")
sec = s.split("## Suite donnée à la contre-lecture", 1)[1].split("\n## ", 1)[0]
lignes = [l for l in sec.splitlines() if re.match(r"^\| [A-Z] — ", l)]
lettres = [l[2] for l in lignes]
ok = True
for c in "ABCDEFGHIJ":
    n = lettres.count(c)
    dec = [l.split("|")[3].strip() for l in lignes if l[2] == c]
    print(c, n, dec)
    ok &= n == 1 and dec[0] in ("corrigé", "réserve maintenue")
print("TABLE", "OK" if ok and len(lignes) == 10 else "ECHEC")
sys.exit(0 if ok else 1)
