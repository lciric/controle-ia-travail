"""Contrôle des citations du rapport T (lot 8), v1.

Usage : python3 -I verifier_citations_v1.py DOSSIER_PDF citations.json [--chercher]
Pour chaque citation {pdf, sha256, page, citation} : vérifie l'empreinte du PDF,
extrait la page par pdftotext (avec et sans -layout), normalise (espaces,
ligatures, césures, apostrophes, guillemets, tirets) et cherche la citation
normalisée dans le texte normalisé de la page. Code de sortie 0 si zéro échec.
Avec --chercher, une citation en échec est cherchée sur toutes les pages (aide).
"""
import hashlib
import json
import re
import subprocess
import sys
import unicodedata
from pathlib import Path

LIGATURES = {"ﬀ": "ff", "ﬁ": "fi", "ﬂ": "fl", "ﬃ": "ffi",
             "ﬄ": "ffl", "ﬅ": "st", "ﬆ": "st"}
APOS = "‘’‚‛′´`"
GUIL = "“”„‟«»"
TIRETS = "‐‑‒–—―−­"


def normaliser(t: str, garder_trait: bool = False) -> str:
    t = unicodedata.normalize("NFKC", t)
    for k, v in LIGATURES.items():
        t = t.replace(k, v)
    for c in APOS:
        t = t.replace(c, "'")
    for c in GUIL:
        t = t.replace(c, '"')
    for c in TIRETS:
        t = t.replace(c, "-")
    t = t.replace("\f", " ")
    # césures en fin de ligne : « exchangeabil-\nity » -> « exchangeability »
    if garder_trait:  # trait d'union réel coupé en fin de ligne : « e-\nprocesses »
        t = re.sub(r"(\w)-\s*\n\s*(\w)", r"\1-\2", t)
    else:
        t = re.sub(r"(\w)-\s*\n\s*(\w)", r"\1\2", t)
    t = re.sub(r"\s+", " ", t)
    # espaces parasites avant la ponctuation (rendu -layout)
    t = re.sub(r"\s+([,.;:)\]])", r"\1", t)
    t = re.sub(r"([(\[])\s+", r"\1", t)
    return t.strip().lower()


def page_texte(pdf: Path, page: int, layout: bool) -> str:
    cmd = ["pdftotext", "-q", "-f", str(page), "-l", str(page)]
    if layout:
        cmd.append("-layout")
    cmd += [str(pdf), "-"]
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout


def nb_pages(pdf: Path) -> int:
    out = subprocess.run(["pdfinfo", str(pdf)], capture_output=True, text=True, check=True).stdout
    return int(re.search(r"Pages:\s+(\d+)", out).group(1))


def trouve(pdf: Path, page: int, cit: str) -> bool:
    c = normaliser(cit)
    for layout, garder in ((False, False), (False, True), (True, False), (True, True)):
        p = normaliser(page_texte(pdf, page, layout), garder)
        if c in p or c.replace("- ", "-") in p.replace("- ", "-"):
            return True
        # variante sans aucune espace (rendu -layout qui éclate les mots)
        if c.replace(" ", "") in p.replace(" ", ""):
            return True
    return False


def main() -> int:
    dossier = Path(sys.argv[1])
    cits = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
    chercher = "--chercher" in sys.argv
    empreintes = {}
    echecs = 0
    for i, e in enumerate(cits, 1):
        pdf = dossier / e["pdf"]
        if pdf.name not in empreintes:
            empreintes[pdf.name] = hashlib.sha256(pdf.read_bytes()).hexdigest()
        ok_sha = empreintes[pdf.name] == e["sha256"]
        ok = ok_sha and trouve(pdf, int(e["page"]), e["citation"])
        statut = "OK" if ok else ("ECHEC-EMPREINTE" if not ok_sha else "ECHEC")
        print(f"{i:3d} {statut:6s} {e['pdf']} p.{e['page']} : {e['citation'][:70]}")
        if not ok:
            echecs += 1
            if chercher and ok_sha:
                pages = [p for p in range(1, nb_pages(pdf) + 1) if trouve(pdf, p, e["citation"])]
                print(f"      trouvée sur les pages : {pages}")
    print(f"TOTAL {len(cits)} citations, {echecs} échec(s)")
    return 0 if echecs == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
