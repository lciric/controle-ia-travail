"""Vérifie que toute citation entre guillemets anglais du rapport figure, mot pour mot, dans citations-T-v1.json."""
import json, re, sys
from pathlib import Path
rap = Path(sys.argv[1]).read_text(encoding="utf-8")
cits = {e["citation"] for e in json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))}
trouvees = re.findall(r"“(.+?)”", rap)
manque = [t for t in trouvees if t not in cits]
print(f"{len(trouvees)} citations entre guillemets anglais dans le rapport ; {len(manque)} absentes du JSON")
for m in manque: print("ABSENTE :", m)
inutil = [c for c in cits if c not in trouvees]
print(f"{len(inutil)} citations du JSON non reprises dans le rapport")
for m in inutil: print("NON REPRISE :", m)
sys.exit(1 if manque else 0)
