"""Calcul (modele A), verification analytique du constat B : detecteur de puissance S = moyenne des carres
(Bash et collegues, p. 15-16). Sous l'alternative, n*S/sigma^2 suit un khi-deux decentre a n degres de liberte,
de decentrage E/sigma^2 (E = somme des carres des symboles) : sa loi ne depend que de E.
(a) cas du contre-lecteur : n = 200, sigma = 1, niveau 0,05, budget lineaire B = 25 reparti en m decalages egaux,
    energie E = B^2/m ; puissance de la somme : 1 - Phi(z_0.95 - B/sqrt(n)), independante de m.
(b) espace des scores X_i = y_i^2 : decalage moyen de X_i = f_i^2, somme des decalages = E (budget lineaire sur X),
    variance de X_i = 2 + 4 f_i^2 (lineaire aussi) : la loi de la somme des X ne depend que de E.
Aucune simulation : formules fermees (scipy)."""
import json, sys
from scipy import stats
import numpy as np
n, sig, a = 200, 1.0, 0.05
c = stats.chi2.ppf(1 - a, n)
out = {"n": n, "niveau": a, "seuil_khi2": float(c), "scipy": __import__("scipy").__version__}
B = 25.0
out["a_budget_lineaire_B25"] = {f"m={m}": {"energie": B * B / m, "puissance_detecteur_puissance": float(stats.ncx2.sf(c, n, B * B / m)),
                                "puissance_somme": float(stats.norm.sf(stats.norm.ppf(1 - a) - B / np.sqrt(n)))} for m in (1, 10, 200)}
out["b_energie_fixee_E40"] = {"puissance_detecteur_puissance_toute_repartition": float(stats.ncx2.sf(c, n, 40.0))}
json.dump(out, sys.stdout, indent=1)
