import hashlib, json, re, sys
heure, nb_ech = sys.argv[1], int(sys.argv[2])
cites = json.load(open("citations-L-voisins-v2.json", encoding="utf-8"))
num = json.load(open("numeros-citations-voisins-v2.json"))
s = open("gabarit-rapport-L-voisins-v2.md", encoding="utf-8").read()
def rempl(m):
    return "« " + cites[num[m.group(1)] - 1]["citation"] + " »"
s = re.sub(r"\{([KAR]\d+)\}", rempl, s)
inv = {v: k for k, v in num.items()}
lignes = ["| id | n° JSON | pièce | page | citation exacte |", "|---|---|---|---|---|"]
for i, c in enumerate(cites, 1):
    lignes.append(f"| {inv[i]} | {i} | `{c['pdf']}` | {c['page']} | {c['citation'].replace('|', '/')} |")
s = s.replace("{TABLE_CIT}", "\n".join(lignes)).replace("{HEURE_FIN}", heure).replace("{NB_CIT}", str(len(cites))).replace("{NB_ECH}", str(nb_ech))
s = s.replace("{SHA_JSON}", hashlib.sha256(open("citations-L-voisins-v2.json", "rb").read()).hexdigest())
assert not re.search(r"\{([KAR]\d+|HEURE_FIN|NB_CIT|NB_ECH|SHA_JSON|TABLE_CIT)\}", s)
open("rapport-L-voisins-v2.md", "w", encoding="utf-8").write(s)
c = set(x["citation"] for x in cites); n = 0
for m in re.findall(r"«\s(.*?)\s»", s):
    if m not in c and re.search(r"[A-Za-z]{3,} (the|of|and|is|for|to|a|on|from)\b|\b(the|of|and)\b", m): print("ANGLAIS HORS JSON:", m[:90]); n += 1
refs = set(re.findall(r"\[([KAR]\d+)\]", s.split("## Annexe")[0])); print("renvois inconnus:", sorted(refs - set(num)), "hors json anglais:", n, "taille", len(s))
