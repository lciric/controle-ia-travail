# Journal du lecteur HC5 (modèle A) — v1

Écrit le 2026-11-13 à 22:56:47 UTC (relevé par date -u dans la commande d'écriture).

## Déroulé
1. Consigne commune du compte 2 : empreinte vérifiée `cb0623c4aff841a815dc628691f407308acbeeeceb274db96d1f2ba3c8c77ff5` (identique au compagnon) ; lue en entier.
2. `interdits-communs-v2.md` lu en entier ; la consigne du compte 2 est plus stricte sur git (aucune commande) : tenue.
3. Lignes nommées seulement : programme v2 l. 85-125 et 190-215 ; N-005/N-006 l. 76-90 ; N-013 l. 56-68 ; antériorité niveau 2 l. 293-312 ; état de l'art niveau 3 l. 432-448 ; contre-lecture niveau 3 l. 536-557 (constat M9).
4. Empreintes des deux PDF vérifiées contre leurs compagnons `.sha256` (identiques), 17 pages chacun (pdfinfo).
5. Extraction page à page par `pdftotext -layout -f N -l N` dans `textes/` (non archivé).
6. Lecture : voir l'étendue ci-dessous.
7. Script de contrôle des citations écrit, testé sur un cas juste (1 citation, 0 échec, code 0) et sur trois cas altérés (mot changé, page fausse, empreinte fausse : 3 échecs, code 1).
8. 44 citations écrites ; premier passage : 1 échec (citation n° 7, mot « now » omis et majuscule : citation mal recopiée par moi) ; corrigée par une sous-chaîne exacte ; une citation contenant un symbole grec remplacée par une sous-chaîne sans symbole ; second passage : 44 citations, 0 échec.
9. Recalcul (nature « calcul ») des taux de vulnérabilité et de leurs intervalles exacts de Poisson à 95 % (bibliothèque standard ; la première version du script appelait une bibliothèque absente et a échoué, réécrite sans elle).

## Étendue lue
- 2601.04603v1.pdf : pages 1 à 17 lues ligne à ligne par pdftotext -layout (texte, notes, annexes A à F) ; pages 11 à 13 (remerciements, contributions, bibliographie) parcourues par mots ; pages 7 et 8 vues en image (figures 2 et 3 lues sur la figure). Figures 4 (p. 14), 5 (p. 16), 6 (p. 17) non vues en image : seuls leurs légendes et le texte sont lus.
- 2608.11247v1.pdf : pages 1 à 9 et 13 à 16 lues ligne à ligne ; pages 9 (colonne droite) à 12 et 17 (bibliographie, liste des modèles, licences) parcourues par mots ; aucune figure vue en image (figures 1 à 8) : les coordonnées de la figure 5 sont lues dans le tableau 6 (p. 13).

## Choix d'écriture
- Aucun nom de modèle écrit dans les fichiers (consigne, interdits) : les modèles des articles sont désignés par leur rôle (« le modèle protégé », « un petit classifieur externe »). Aucune citation contrôlée ne contient de nom de modèle.
- Aucun autre PDF ouvert ; aucun fichier hors des fichiers nommés ; aucune commande git ; aucun réseau.

## Ajout (2026-11-13 22:58:53 UTC, relevé par date -u)
- Trois citations ajoutées (passages cités dans le rapport) : contrôle final 47 citations, 0 échec (sortie-controle-citations-v1.txt). Empreinte du JSON : 3417ec306956501c72dbaa6006db6e7235e3098464546e7025047a048d61ba75.
