"""Recalculs (nature : calcul) sur les chiffres imprimes de 2601.04603v1, tableau 1 et p. 4, 5, 9.
Intervalle exact de Poisson (Garwood) par bissection, bibliotheque standard seulement."""
import math

def cdf(k, mu):
    return sum(math.exp(-mu) * mu**i / math.factorial(i) for i in range(k + 1))

def bisect(f, a, b):
    for _ in range(200):
        m = (a + b) / 2
        if f(a) * f(m) <= 0: b = m
        else: a = m
    return (a + b) / 2

def garwood(k):
    bas = 0.0 if k == 0 else bisect(lambda mu: (1 - cdf(k - 1, mu)) - 0.025, 1e-9, 100)
    haut = bisect(lambda mu: cdf(k, mu) - 0.025, 1e-9, 100)
    return bas, haut

cas = {"derniere generation (p.4)": (13, 695), "classifieur d'echange (p.4)": (2, 226),
       "cascade a deux etages (p.5)": (5, 569), "systeme de production (p.9)": (1, 198)}
for nom, (k, milliers) in cas.items():
    bas, haut = garwood(k)
    print(f"{nom}: {k}/{milliers}k = {k/milliers:.5f} par millier ; IC95 exact de Poisson [{bas/milliers:.5f}, {haut/milliers:.5f}]")
