"""Contrôle des citations : python3 -I verifier... JSON DOSSIER_PDF
Chaque citation doit figurer dans le texte de sa page (pdftotext avec et sans -layout),
après normalisation (espaces, ligatures, césures, apostrophes, tirets, guillemets)."""
import json, subprocess, sys, unicodedata, hashlib, os, re

def norm(s):
    s = unicodedata.normalize("NFKC", s)
    for a, b in (("ﬁ", "fi"), ("ﬂ", "fl"), ("ﬀ", "ff"), ("ﬃ", "ffi"), ("ﬄ", "ffl")):
        s = s.replace(a, b)
    s = re.sub(r"[‘’‛′`´']", "'", s)
    s = re.sub(r"[“”„″\"]", '"', s)
    s = re.sub(r"[‐‑‒–—−­-]", "", s)  # tirets et césures
    s = re.sub(r"\s+", "", s)
    return s.lower()

def texte(pdf, page, layout):
    cmd = ["pdftotext"] + (["-layout"] if layout else []) + ["-f", str(page), "-l", str(page), pdf, "-"]
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout

def main():
    chemin_json, dossier = sys.argv[1], sys.argv[2]
    cits = json.load(open(chemin_json, encoding="utf-8"))
    echecs = 0
    cache = {}
    for c in cits:
        pdf = os.path.join(dossier, c["pdf"])
        h = hashlib.sha256(open(pdf, "rb").read()).hexdigest()
        ok = h == c["sha256"]
        if ok:
            cle = (pdf, c["page"])
            if cle not in cache:
                cache[cle] = [norm(texte(pdf, c["page"], True)), norm(texte(pdf, c["page"], False))]
            n = norm(c["citation"])
            ok = len(n) > 0 and any(n in t for t in cache[cle])
        if not ok:
            echecs += 1
            print("ECHEC p.%s : %s" % (c["page"], c["citation"]))
    print("citations : %d ; échecs : %d" % (len(cits), echecs))
    sys.exit(1 if echecs else 0)

main()
