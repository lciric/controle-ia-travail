import json, re, sys, unicodedata
def n(s):
    s = unicodedata.normalize("NFKC", s); s = re.sub(r"[‘’']", "'", s)
    return re.sub(r"\s+", " ", s).strip()
rap = open(sys.argv[1], encoding="utf-8").read()
cits = {n(c["citation"]) for c in json.load(open(sys.argv[2], encoding="utf-8"))}
pas = re.findall(r"«\s*(.*?)\s*»", rap, flags=re.S)
abs_ = [p for p in pas if n(p) not in cits]
print("%d passages ; %d dans le JSON ; %d absents" % (len(pas), len(pas) - len(abs_), len(abs_)))
for p in abs_: print("ABSENT :", p)
