Journal du contre-lecteur (modèle B) — contre-lecture HC4 / 2609.15994 v1
Début : sortie de date -u de la commande de préparation : Sat Nov 14 06:39:24 UTC 2026 (recopiée de la sortie). Empreintes de la consigne, du rapport, de l'archive et du PDF conformes.
Premier contrôle des citations (1 échec p. 9, césure entre colonnes, citation raccourcie) : sortie de date -u : Sat Nov 14 06:42:35 UTC 2026 (recopiée de la sortie).
Étendue lue : p. 1-8 et 10-18 ligne à ligne (pdftotext sans -layout, puis -layout pour p. 13-18) ; p. 9 par mots ; images p. 4, 5, 6, 7 ; recherche des mots cost et quer sur les 18 pages.
Essais du script : cas juste 0 échec ; deux cas altérés (chiffre changé, page fausse) 2 échecs, attendus. JSON du lecteur relu : 107 citations, 0 échec.
Recalculs : part malveillante 32,36 % ; moyennes du tableau 16 : 38,86 / 35,36 / 33,60 ; 3,70/0,60 = 6,17 ; 47,2-4,5 = 42,7 ; 38,9-3,5 = 35,4 ; 27/294 = 9,18 % ; (0,20+0,16+0,08)*49 = 21,56.
Fichier non ouvert : interdits-communs-v2.md (non nommé par le mandat).
Contrôle final : citations : 46 ; échecs : 0 ; guillemets : 74 passages ; 38 dans le JSON ; 36 absents
Fin de rédaction, copie et archive : Sat Nov 14 06:44:57 UTC 2026
