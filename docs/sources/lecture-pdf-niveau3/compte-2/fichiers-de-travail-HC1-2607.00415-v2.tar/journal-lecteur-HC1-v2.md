# Journal du lecteur — HC1, pièce 2607.00415 v1 — version 2 du rapport (modèle A)

Heures relevées par `date -u` : reprise 2026-11-13 23:13:27 UTC ; calculs v2 23:15:11 UTC ; rédaction commencée 23:15:36 UTC ; contrôle de la table de suite 23:17:55 UTC ; journal écrit 23:18:11 UTC.

## Étapes
1. Empreintes vérifiées : contre-lecture e4beb545… (conforme) ; archive du contre-lecteur 9985fb84… (conforme) ; rapport v1 67192c4a… (conforme).
2. Archive du contre-lecteur extraite dans un sous-dossier neuf (`contre-lecture-extraite/`) ; non reprise dans mon archive.
3. Contre-lecture lue en entier (186 lignes).
4. Figures 10, 11, 12 : images d'origine extraites par pdfimages (2084 × 1369), composées sur fond blanc, vues panneau par panneau (figure 12) et en planche entière (figures 10 et 11). Figure 18 relue (rendu 300 points par pouce).
5. Calculs v2 (`scripts/calculs_v2.py`, `sortie-calculs-v2.txt`) : taux de bascule, pas en points et en logit, erreur type Llama 744 / 738, figure 2 barre par barre et totaux implicites, bornes de la figure 6 sous l'hypothèse « sous-ensemble basculé sous le médecin ».
6. Citations v2 : 69 (57 de la v1 + 12 nouvelles), contrôlées par le script inchangé : 0 échec (`sortie-controle-citations-v2.txt`).
7. Rapport v2 écrit ; table de suite vérifiée par programme (une entrée par lettre A à N, cinq colonnes, décision dans {corrigé, réserve maintenue}).

## Lectures de figures v2 (nature « figure »)
- Fig. 12 (Llama), dernière couche et couches 17-31 : médecin P(correct) ≈ 0,07-0,10, P(indiquée) ≈ 0,84-0,92 ; chef résident P(correct) ≈ 0,47-0,62, P(indiquée) ≈ 0,25-0,31 ; 3e année ≈ 0,44-0,60 contre ≈ 0,28-0,36 ; 1re année ≈ 0,55-0,75 contre ≈ 0,05-0,11 (sous la base P(indiquée)).
- Fig. 10 (Gemma), dernière couche : P(indiquée) ≈ 0,94 / 0,76 / 0,47 / 0,08 ; P(correct) ≈ 0,04 / 0,11 / 0,23 / 0,31.
- Fig. 11 (Qwen), dernière couche : P(indiquée) ≈ 0,94 / 0,81 / 0,69 / 0,53 ; courbes avec indice ≈ base jusqu'aux couches 25 à 28.
- Fig. 18 (Gemma) : médecin – 1re année ≈ 0,56-0,57 à la couche 28, minimum ≈ 0,535 à la couche 29 ; médecin – chef résident ≈ 0,83.

## Incidents
Aucun refus, aucune ouverture fautive, aucune commande git, aucun réseau, aucun appel de modèle. Rien d'autre écrit dans le dépôt que le rapport v2, l'archive v2 et leurs compagnons.
