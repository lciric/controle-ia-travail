import math
# Effectifs lus sur les titres des panneaux des figures 13 (Gemma), 14 (Llama), 15 (Qwen) : (basculees, resistees)
F = {
 "Gemma": [(1287, 1635), (291, 2631), (117, 2805), (68, 2854)],
 "Llama": [(2412, 730), (744, 2398), (738, 2404), (270, 2872)],
 "Qwen":  [(1577, 1431), (728, 2280), (406, 2602), (265, 2743)],
}
NOMS = ["medecin", "chef resident", "3e annee", "1re annee"]
lg = lambda p: math.log(p / (1 - p))
print("1. Taux de bascule (%) et pas en logit, du bas vers le haut")
for m, d in F.items():
    N = sum(d[0]); taux = [a / N for a, b in d]
    print(f"  {m} (N={N}) :", " / ".join(f"{100*t:.1f}" for t in taux))
    asc = taux[::-1]
    print("     pas en points :", [round(100*(asc[i+1]-asc[i]), 1) for i in range(3)],
          " pas en logit :", [round(lg(asc[i+1]) - lg(asc[i]), 2) for i in range(3)])
# Llama chef resident contre 3e annee : erreur type non appariee (borne)
N = 3142; p1, p2 = 744/N, 738/N
print("2. Llama 744 contre 738 : ecart", round(100*(p1-p2), 2), "point ; erreur type non appariee",
      round(100*math.sqrt(p1*(1-p1)/N + p2*(1-p2)/N), 2), "point")
# Figure 2 (lectures du lecteur v2, arrondies) : bases et barres, ordre medecin..1re annee
FIG2 = {"Gemma": (58.5, [33.5, 54.0, 58.5, 61.0]), "Llama": (63.0, [14.7, 49.0, 49.4, 60.5]), "Qwen": (60.2, [29.3, 47.3, 54.0, 57.0])}
print("3. Figure 2 : barre lue moins (base x part restante des questions correctes) ; total implicite")
for m, (base, barres) in FIG2.items():
    d = F[m]; N = sum(d[0])
    pred = [base * b / N for a, b in d]
    print(f"  {m} : ecarts", [round(x - y, 1) for x, y in zip(barres, pred)], " total implicite", round(N / (base/100)))
# Figure 6 : bornes inferieures de l'exactitude 'No hook' si RQ4 porte sur le sous-ensemble bascule sous le medecin
print("4. Figure 6 : bornes si l'echantillon de RQ4 est le sous-ensemble bascule sous le medecin")
FIG6 = {"Gemma": (97, 86), "Qwen": (94, 78), "Llama": (93, 80)}
for m, (nh1, nhr) in FIG6.items():
    d = F[m]; nphys = d[0][0]
    b1 = 100*(1 - d[3][0]/nphys); br = 100*(1 - d[1][0]/nphys)
    r1 = 100*d[3][1]/sum(d[3]); rr = 100*d[1][1]/sum(d[1])
    print(f"  {m} : 1re annee lue {nh1} ; borne sous-ensemble >= {b1:.1f} ; ensemble entier {r1:.1f} | chef resident lue {nhr} ; borne >= {br:.1f} ; ensemble entier {rr:.1f}")
