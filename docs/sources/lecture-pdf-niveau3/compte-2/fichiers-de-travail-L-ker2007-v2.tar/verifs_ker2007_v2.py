"""Calcul (modele A) : verification des chiffres de la p. 4 de Ker 2007 (bornes (6) et (7)) et de l'exemple
du contre-lecteur sur le compte des signes (constat D). Formes fermees, aucun tirage."""
import json, math, sys
from scipy import stats
# Student 2 ddl, echelle 0,01 : psi(x) = 1e2 (2 + 1e4 x^2)^(-3/2) (p. 4, lu sur le PDF)
psi = lambda x: 1e2 * (2 + 1e4 * x * x) ** -1.5
Psi = lambda x: stats.t.cdf(x / 0.01, 2)
A = min(psi(-1 + i / 1e5) for i in range(100001))  # min de psi sur [-1, 0]
q, qb = 1 - Psi(0.0), 1 - Psi(-1.0)
a, b = 0.05, 0.5
g6 = math.sqrt(qb * (1 - q)) / A * (-stats.norm.ppf(b) - stats.norm.ppf(a) * math.sqrt((1 - q) / (1 - qb)))
d = a * math.log(a / (1 - b)) + (1 - a) * math.log((1 - a) / b)
g7 = math.sqrt(2 * d / 15000.0)
# compte des signes, erreur gaussienne reduite, N = 100, total des proportions 2
eg = 100 * stats.norm.cdf(0.02); co = 98 * 0.5 + 2 * stats.norm.cdf(1.0)
json.dump({"A": A, "q": q, "q_barre": qb, "gamma_borne_6": g6, "gamma_borne_7": g7, "rapport": g6 / g7,
           "esperance_compte_egale": eg, "esperance_compte_concentree": co}, sys.stdout, indent=1)
