"""Ecrit le JSON des citations de la contre-lecture (modele B). Usage : python3 -I ce_script.py SORTIE.json"""
import json, sys
PDF = "ker-2007-capacity-result-batch-steganography.pdf"
SHA = "73113e2de45bf7b9dd93350238b07a2c45f00d29f62b2be1457d042ce2dd98e9"
C = [
 (1, "A Capacity Result for Batch Steganography"),
 (1, "We further assume that the estimation error distribution does not depend on the true value being estimated."),
 (1, "We say that a Steganographer’s embedding strategy is a choice of"),
 (1, "Any such test is called a pooling strategy."),
 (1, "Note that the covers are considered uniform, not only in their capacity but also to prevent the Steganographer embedding adaptively."),
 (1, "are assumed independent."),
 (1, "In [1] we also imposed the constraint that all cover objects used for embedding had to contain the same amount of payload: the “uniform embedding” assumption. We relax this latter condition in this paper."),
 (2, "risk of detection increases. But the investigation was limited"),
 (2, "we are only able to determine capacity a) asymptotically and b) without regard to the multiplicative constant of"),
 (2, "at least twice continuously differentiable"),
 (2, "There is a pooling strategy for the Warden such that, no matter what the Steganographer’s embedding strategy,"),
 (2, "There is an embedding strategy for the Steganographer such that, no matter what the Warden’s pooling strategy,"),
 (2, "It is a modification of the simplest pooling strategy investigated in [1] and certainly is not an “optimal” strategy in practice."),
 (2, "The Warden will count the number of positive estimates"),
 (2, "the type-I and type-II errors are bounded by"),
 (2, "we have a sum of not-identically distributed random variables so we cannot use the central limit theorem as in [1]."),
 (2, "which not only gives asymptotic behaviour but also bounds the difference from the asymptotic distribution function."),
 (2, "Then there is some constant"),
 (2, "which, for sufficiently large"),
 (3, "The Steganographer’s embedding strategy is simply to split the payload equally between all covers."),
 (3, "This will suffice to bound the Warden’s ability to perform (2), no matter what pooling strategy they use."),
 (3, "embedding strategy, identically distributed"),
 (3, "Note that we do not require that the error has zero mean"),
 (3, "such a bound exists for many common distributions with infinite support including Gaussian, Cauchy, Logistic, and the Student"),
 (4, "If we pass to the limit we can tighten (4) to"),
 (4, "It turns out that these two bounds on detection reliability are a long way apart."),
 (4, "we note that it is the extravagant inequalities in Section II-A which are primarily responsible for the gap."),
 (4, "so there is no UMP test; the results in [1] illustrate vividly how the performance of a pooling strategy can be heavily dependent on the embedding strategy."),
 (4, "is known to both parties, before any embedding takes place."),
 (4, "This sequential setting is a little different from the batch setting considered here, and further work will be needed to study it."),
]
json.dump([{"pdf": PDF, "sha256": SHA, "page": p, "citation": c} for p, c in C],
          open(sys.argv[1], "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(C))
