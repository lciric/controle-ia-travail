"""Produit le rapport de contre-lecture a partir du gabarit : heure passee en argument, annexe tiree du JSON.
Verifie aussi que tout extrait entre guillemets francais figure dans le JSON. Usage : python3 -I ce_script.py GABARIT JSON HEURE SORTIE"""
import json, re, sys
gab, js, heure, sortie = sys.argv[1:5]
cit = [c["citation"] for c in json.load(open(js, encoding="utf-8"))]
t = open(gab, encoding="utf-8").read()
annexe = "\n".join(f"| C{i} | {c_['page']} | {c_['citation']} |" for i, c_ in enumerate(json.load(open(js, encoding="utf-8")), 1))
t = t.replace("@@HEURE@@", heure).replace("@@ANNEXE@@", annexe)
hors = [m for m in re.findall(r"«\s*(.*?)\s*»", t, flags=re.S) if m not in cit]
print("extraits entre guillemets francais hors JSON :", len(hors))
for h in hors: print("  -", h)
nums = sorted({int(n) for grp in re.findall(r"\[C([0-9, C]+)\]", t) for n in re.findall(r"\d+", grp)})
print("citations appelees :", len(nums), "sur", len(cit), "; manquantes :", [i for i in range(1, len(cit) + 1) if i not in nums])
open(sortie, "x", encoding="utf-8").write(t)
