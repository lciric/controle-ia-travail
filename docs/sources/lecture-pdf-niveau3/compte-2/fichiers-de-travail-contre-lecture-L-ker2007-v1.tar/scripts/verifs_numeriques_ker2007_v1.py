"""Recalcul des chiffres de la page 4 et de la condition sur (log psi)'' (contre-lecteur, modele B)."""
import math
from statistics import NormalDist
ph = NormalDist()
# Student 2 degres, echelle 0,01 : psi(x) = 100 (2 + 1e4 x^2)^(-3/2)
psi = lambda x: 100 * (2 + 1e4 * x * x) ** -1.5
A = psi(-1.0)
qb = 1 - (0.5 + (-100) / (2 * math.sqrt(2 + 1e4)))  # 1 - Psi(-1), Psi(x)=1/2 + t/(2 sqrt(2+t^2)), t=100x
q = 0.5
a, b = 0.05, 0.5
g6 = math.sqrt(qb * (1 - q)) / A * (-ph.inv_cdf(b) - ph.inv_cdf(a) * math.sqrt((1 - q) / (1 - qb)))
d = a * math.log(a / (1 - b)) + (1 - a) * math.log((1 - a) / b)
B = 15000
g7 = math.sqrt(2 * d / B)
print("A =", A, " q barre =", qb)
print("borne (6) gamma <=", g6, " borne (7) gamma >=", g7, " rapport =", g6 / g7, " log10 =", math.log10(g6 / g7))
# minimum de (log psi)'' pour Student 2 dl echelle 0,01 et pour Cauchy unite, sur une grille
def d2(f, x, h=1e-5): return (math.log(f(x + h)) - 2 * math.log(f(x)) + math.log(f(x - h))) / h / h
print("min (log psi)'' Student 2 dl, echelle 0,01 :", min(d2(psi, k / 1e5, 1e-6) for k in range(-5000, 5001)))
cau = lambda x: 1 / (math.pi * (1 + x * x))
print("min (log psi)'' Cauchy unite :", min(d2(cau, k / 100) for k in range(-1000, 1001)))
# le compte des signes n'est pas invariant a la repartition : esperance sous deux repartitions de meme total (gaussienne)
tot = 2.0
for nom, ps in (("egale sur 100", [tot / 100] * 100), ("concentree sur 2", [1.0, 1.0] + [0.0] * 98)):
    print("esperance du compte des signes,", nom, ":", sum(1 - ph.cdf(-p) for p in ps))
