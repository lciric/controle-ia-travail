"""Dans le gabarit, garde les guillemets francais pour les seules citations du JSON ; les autres passent en guillemets anglais courbes.
Usage : python3 -I ce_script.py GABARIT JSON"""
import json, re, sys
gab, js = sys.argv[1:3]
cit = {c["citation"] for c in json.load(open(js, encoding="utf-8"))}
t = open(gab, encoding="utf-8").read()
n = [0]
def f(m):
    if m.group(1) in cit: return m.group(0)
    n[0] += 1
    return "“" + m.group(1) + "”"
t = re.sub(r"«\s*(.*?)\s*»", f, t, flags=re.S)
open(gab, "w", encoding="utf-8").write(t)
print("remplacements :", n[0])
