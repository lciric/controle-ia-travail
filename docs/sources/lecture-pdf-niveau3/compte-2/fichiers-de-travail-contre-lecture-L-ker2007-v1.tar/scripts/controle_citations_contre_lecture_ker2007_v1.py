"""Controle des citations de la contre-lecture L (lettre de Ker 2007), v1 -- ecrit par le contre-lecteur (modele B).
Usage : python3 -I controle_citations_contre_lecture_ker2007_v1.py DOSSIER_PDF citations.json
Verifie l'empreinte du PDF, extrait la page (pdftotext avec et sans -layout), normalise
(ligatures, apostrophes, guillemets, tirets, cesures, espaces) et cherche la citation exacte.
Code de sortie 0 seulement si zero echec."""
import hashlib, json, re, subprocess, sys, unicodedata

REMPL = {"’": "'", "‘": "'", "“": '"', "”": '"', "–": "-", "—": "-",
         "‐": "-", "‑": "-", "−": "-", "­": "", " ": " "}

def normaliser(s):
    s = unicodedata.normalize("NFKC", s)
    for a, b in REMPL.items():
        s = s.replace(a, b)
    return re.sub(r"\s+", " ", s).strip()

def decesurer(s):
    return re.sub(r"(?<=\w)- (?=\w)", "", s)

def texte_page(pdf, page, layout):
    cmd = ["pdftotext", "-f", str(page), "-l", str(page)]
    if layout:
        cmd.append("-layout")
    return subprocess.run(cmd + [pdf, "-"], capture_output=True, text=True, check=True).stdout

def main(dossier, chemin):
    with open(chemin, encoding="utf-8") as f:
        citations = json.load(f)
    echecs, vues = 0, {}
    for n, c in enumerate(citations, 1):
        pdf = dossier.rstrip("/") + "/" + c["pdf"]
        if pdf not in vues:
            with open(pdf, "rb") as f:
                vues[pdf] = hashlib.sha256(f.read()).hexdigest()
        if vues[pdf] != c["sha256"]:
            print(f"ECHEC {n:3d} empreinte differente pour {c['pdf']}"); echecs += 1; continue
        cible = normaliser(c["citation"])
        mode = None
        if len(cible) >= 8:
            for layout in (False, True):
                t = normaliser(texte_page(pdf, c["page"], layout))
                if cible in t:
                    mode = ("layout" if layout else "brut") + ", exact"; break
                if decesurer(cible) in decesurer(t):
                    mode = ("layout" if layout else "brut") + ", cesure"; break
        if mode:
            print(f"OK    {n:3d} p.{c['page']} [{mode}] {c['citation'][:80]}")
        else:
            print(f"ECHEC {n:3d} p.{c['page']} {c['citation'][:100]}"); echecs += 1
    print(f"TOTAL citations={len(citations)} echecs={echecs}")
    return 1 if echecs else 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1], sys.argv[2]))
