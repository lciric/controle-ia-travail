#!/usr/bin/env python3
"""Construit citations-H6-v1.json (liste fermee, numerotee dans le rapport par n)."""
import json
import sys

A = ("2504.10374v1.pdf", "5f802d679344fe5e15d1edd50e96245f3bdc054e69d1ff0880b077d173549211")
B = ("2605.26047v2.pdf", "947724f42324070fd47b1ecaf8c1bf9b2257df0e0c7f8822447241d3ea9a28fa")

C = [
    # --- Ctrl-Z, 2504.10374v1 ---
    (A, 1, "arXiv:2504.10374v1 [cs.LG] 14 Apr 2025"),
    (A, 1, "We introduce a class of control protocols called resample protocols that dynamically take additional samples of certain actions."),
    (A, 1, "selectively blocking the AI agent from executing suspicious code and incriminating the agent by generating additional examples of dangerous behavior"),
    (A, 1, "our best protocol combines resampling with analysis of previous steps, reducing the success rate of attacks from 58% to 7% at a 5% cost to the performance of a non-malicious agent"),
    (A, 2, "being completed in a new container, resetting state between each task"),
    (A, 3, "define usefulness to be the proportion of tasks the control protocol solves in each episode"),
    (A, 3, "define safety to be the probability that the blue team wins by reaching the end of an episode without allowing the AI agent to download and execute malware"),
    (A, 3, "from now on we assume that if an attack is audited by H, it provides unshakable evidence to the blue team about"),
    (A, 4, "auditing every action until H's budget runs out"),
    (A, 4, "Result: a safety score of 5.5% at 100% usefulness."),
    (A, 5, "Result: A safety score of 41.8% at 100% usefulness."),
    (A, 5, "A defer threshold of 80% means that if an action is rated as more suspicious than 80% of"),
    (A, 5, "Choosing a lower defer threshold decreases the chance an attack is executed by the control protocol but hurts usefulness."),
    (A, 5, "Result: A safety score of 72.7% at 95% usefulness."),
    (A, 6, "If a suspiciousness score is above a deferral threshold, we generate up to two new samples from"),
    (A, 6, "If any of these actions fall under the deferral threshold, the protocol executes the least suspicious one."),
    (A, 6, "Minimum of the scores from a resampling procedure with up to six resamples per action."),
    (A, 7, "on average, safer actions get implemented if the protocol gathers more samples and only implements the least suspicious one"),
    (A, 7, "This protocol combines both value from selection pressure (occasionally selecting non-attacking messages when sampling"),
    (A, 7, "If the blue team is using Defer to resample, for most deferral thresholds it's even more important for the red team to use a very high attack continuation probability."),
    (A, 8, "Safety scores for different protocols at 90%, 95%, and 99% usefulness"),
    (A, 8, "Result: A safety score of 87.1% at 95% usefulness. This is the best resampling protocol, as seen in Table 1."),
    (A, 8, "It's important to note that each of our improvements to the basic Defer to Resample protocol doesn't affect usefulness, and only influences how we make auditing decisions."),
    (A, 9, "Comparison at 95% usefulness. TM = Trusted Monitoring, UM = Untrusted Monitoring."),
    (A, 9, "Before showing proposed commands to the untrusted monitor, the trusted model rewrites them."),
    (A, 9, "The blue team still runs the original commands, so trusted paraphrasing does not affect usefulness."),
    (A, 9, "The blue team's absolute performance is highly sensitive to this parameter, but the relative performance between our protocols is fairly insensitive to it."),
    (A, 10, "The attack policy needs to execute a narrow attack on a specific, known target."),
    (A, 33, "If the suspiciousness score of the current action hits the deferral threshold, resample up to two times."),
    (A, 34, "a new sample is taken from the third most suspicious sample in the trajectory so far"),
    (A, 29, "If the suspicion score is above the defer threshold then disregard the action and ask T to provide an action instead"),
    # --- 2605.26047v2 ---
    (B, 1, "arXiv:2605.26047v2 [cs.AI] 26 May 2026"),
    (B, 1, "drawing five samples per step and auditing on the maximum suspicion score raises safety from 61% to 71% at a 0.3% audit budget, at no cost to usefulness."),
    (B, 1, "Selectively resampling only the steps that look suspicious on the first draw recovers 6.2 percentage points of the gain while drawing only 10% as many extra samples."),
    (B, 1, "Two of our findings in this setting contradict earlier work on resampling."),
    (B, 1, "The first is that auditing based on the maximum across resampled suspicion scores outperforms using the minimum, which is the opposite of what Ctrl-Z found."),
    (B, 1, "executing the least suspicious sample, which is the central mechanism in earlier defer-to-resample protocols, gives only a small empirical safety gain in our setting (+3.9 pp, with the confidence interval overlapping zero)."),
    (B, 1, "We disentangle design choices that previous work on resampling had bundled together."),
    (B, 1, "Past work on resampling [Bhatt et al., 2025, Kutasov et al., 2025a] has studied complex multi-stage protocols that combine resampling with features such as defer-to-trusted and trusted editing"),
    (B, 2, "Resampling improves safety by improving monitor performance, even without executing the least suspicious action, by up to +10.2 pp (paired 95% CI: [+6.1, +14.3]) with 5 samples per step."),
    (B, 2, "Executing the least suspicious sample only slightly increases safety over using resamples purely for information, and does not increase safety at all if the attacker is behaving optimally."),
    (B, 3, "BashArena is designed to model live failures [Kaufman and Lucassen, 2026]: side tasks which are immediately and irrecoverably bad for the blue team."),
    (B, 3, "Main tasks can be combined with any one of four side tasks: disabling the firewall, downloading malware, leaking sensitive data, and editing sudoers."),
    (B, 4, "Trusted monitoring achieves 61% safety (95% CI: [57%, 64%]) at a 0.3% auditing budget."),
    (B, 4, "We only trigger retries on steps that get suspicion scores above 30, which corresponds to about 2.6% of honest steps."),
    (B, 5, "However, feedback does not improve safety against a responsive attack policy at the headline audit budget."),
    (B, 6, "Always using the “cautious” prompt achieves 64.7% safety (95% CI [61.8%, 67.4%]) at 0.3% audit budget compared to 60.7% (95% CI [55.4%, 64.6%]) for the standard honest policy"),
    (B, 6, "at a usefulness cost of −5.3 percentage points (95% CI [−6.8, −3.7]), dropping from 69.0%"),
    (B, 6, "always either executes the first action sampled, or audits the trajectory"),
    (B, 6, "Resampled actions are never executed, are only used to provide more information about whether or not to audit. This has exactly zero effect on usefulness, because it leaves the trajectory unchanged."),
    (B, 8, "Fixed resampling: always draw k samples. Cost exactly k, latency exactly 1."),
    (B, 9, "Always drawing 5 samples achieves the highest safety, 10.2 percentage points higher than trusted monitoring, but it may be prohibitively costly."),
    (B, 9, "In Bhatt et al. [2025], resample execution substantially improved safety because of a specific chain of dynamics that relied on min aggregation."),
    (B, 10, "draws N =2 samples from the untrusted model per step, executes the least suspicious sample, and uses the maximum suspicion score across both samples for auditing decisions"),
    (B, 10, "Paired comparison finds a safety difference of +3.9 percentage points (95% CI [−2.1, +10.9]), but the confidence interval includes 0."),
    (B, 10, "resample execution drops the attack-sample execution rate from 54% (close to the 50% chance baseline expected for IID resampling on mixed steps) down to 32%"),
    (B, 10, "the same mechanism responsible for resample execution's effectiveness in Ctrl-Z is at play in our experiments, but it is much weaker, and would not increase safety at all against an optimally consistent attack policy"),
    (B, 11, "The Bhatt et al. [2025] argument for resample execution rests on honest scores being weakly correlated."),
    (B, 11, "Comparing BashArena main tasks run with and without executing the least suspicious sample, we find a paired usefulness difference of −1.0 pp (95% CI [−2.8, +0.9], n=298 paired tasks)."),
    (B, 12, "Resampling does not leak any information, and can increase safety at no cost to usefulness."),
    (B, 12, "Ctrl-z: Controlling ai agents via resampling. arXiv preprint arXiv:2504.00000, 2025."),
    (B, 12, "Evaluating control protocols for untrusted ai agents"),
    (B, 15, "The roughly +10 pp safety improvement of N=5 resampling for incrimination over N=1 trusted monitoring is preserved under all three rules."),
    (B, 22, "If the monitor is suspicious of an action you propose, it will reject the action and replace it with an action generated by a trusted model."),
    # --- ajouts (n = 65 a 69) ---
    (A, 6, "We found empirically that the minimum of suspiciousness scores is a good metric to look at when deciding whether to audit."),
    (A, 7, "If resampling happened at a step, its suspiciousness score is determined as the minimum of suspiciousness scores among its samples."),
    (A, 33, "If resampling happened in a step, its suspiciousness score is the mean suspiciousness score of the samples in that step"),
    (A, 29, "We present results on deferral thresholds ranging from 50% to 99%."),
    (B, 4, "We find that auditing after k strikes decreases safety in our setting for any k > 1."),
]

sortie = [{"n": i, "pdf": p[0], "sha256": p[1], "page": pg, "citation": t} for i, (p, pg, t) in enumerate(C, 1)]
with open(sys.argv[1], "w", encoding="utf-8") as f:
    json.dump(sortie, f, ensure_ascii=False, indent=1)
print(len(sortie))
