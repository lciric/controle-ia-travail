# Journal du lecteur — H6, compte 2, modèle A

Écrit le 2026-11-13 22:58:01 UTC (heure relevée par date -u dans la même commande). Début de session : 2026-11-13 22:51:46 UTC (date -u).

## Ordre des opérations
1. Consigne commune vérifiée (cb0623c4…f77ff5, conforme) et lue en entier ; interdits-communs-v2.md lu en entier (plus strict sur git, tenu).
2. Énoncé et état lus aux lignes du mandat seulement : programme v2 l. 85-125 et 185-200 ; N-013 l. 76-81 ; N-015 en entier ; anteriorite-v1 l. 152-165 ; niveau 3 l. 172-182 ; contre-lecture l. 408-441.
3. Empreintes des deux PDF vérifiées contre leurs compagnons .sha256 (sha256sum -c : OK, OK).
4. Texte extrait page par page (pdftotext, brut et -layout) dans texte/ (non archivé).
5. Lecture intégrale, puis figures par l'outil Read sur le PDF.
6. Script de contrôle des citations testé : cas juste (OK, code 0) ; cas altérés (chiffre changé, mauvaise page, mauvaise empreinte : 3 échecs, code 1).
7. Premier contrôle : 64 citations, 0 échec ; citation 8 remplacée par une phrase voisine sans nom de modèle (lecture stricte de la ligne 14 de la consigne) ; cinq citations ajoutées (n = 65 à 69). Contrôle final : 69 citations, 0 échec (controle-citations-H6-v1.txt), refait sur la copie au chemin de sortie : 69, 0 échec.
8. Rapport fermé le 2026-11-13 23:01:27 UTC ; journal corrigé (nombre de citations) le 2026-11-13 23:01:39 UTC (date -u), avant le scellement.

## Étendue réellement lue
### 2504.10374v1.pdf (38 pages)
- Pages 1 à 14, 18 à 38 : lues ligne à ligne (texte brut pdftotext).
- Pages 15 à 17 (gabarits de consignes et code de tests du jeu de données) : lues ligne à ligne, code parcouru.
- Figures vues sur le PDF (outil Read) : pages 4, 5, 6 (figures 2, 3, 4). Figures des pages 13, 14, 28 à 30, 35 à 37 : légendes lues, images non vues.
- Recherche par mots sur les 38 pages (brut) : random, uniform, every step, every action, always, ablat, baseline, regardless, temperature, paraphras, reset, best-of, fixed rate, unconditional, all actions.
### 2605.26047v2.pdf (46 pages)
- Pages 1 à 28 : lues ligne à ligne (texte brut).
- Pages 29 à 46 (annexe I, exemples de rééchantillons : code et consignes) : parcourues par mots, commentaires des auteurs lus ligne à ligne.
- Figures vues sur le PDF : pages 2, 7, 9, 10 (figures 1, 3, 6, 7). Autres figures (pages 5, 8, 16 à 20, 25 à 29) : légendes lues, images non vues.

## Points notés en lisant
- Ctrl-Z : tout rééchantillonnage est déclenché par un seuil du moniteur (report, enquête) ; aucun bras de rééchantillonnage systématique, à chaque pas ou à taux fixe, trouvé, ni en annexe. Paraphrase systématique présente mais sur l'entrée du moniteur non fiable (p. 9), sans mesure isolée. Aucun intervalle de confiance.
- 2605.26047 : rééchantillonnage systématique à k fixe à chaque pas (p. 8), N de 1 à 5 (fig. 3, p. 7), utilité inchangée par construction (p. 6) ; exécution du moins suspect à N = 2 à chaque pas, choix par le moniteur (p. 10) ; consigne « prudente » toujours appliquée (p. 6).
- Contradiction annoncée par 2605.26047 (p. 1, 9 à 11) : agrégation max contre min ; valeur de l'exécution du moins suspect.
- Incohérences : référence de Ctrl-Z donnée comme arXiv:2504.00000 (2605, p. 12) ; base surveillance de confiance 61 % [57, 64] (p. 4) contre 60,7 % [55,4 ; 64,6] (p. 6) contre 60,9 % (p. 15) ; consigne d'attaque qui annonce un report vers le modèle de confiance (p. 22) absent des protocoles de rééchantillonnage étudiés.
