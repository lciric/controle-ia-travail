"""Verifie le rapport H1-2609.19101 v2 : guillemets francais contre le JSON ; table A a L ; noms de modeles."""
import json, re, sys, unicodedata
t = open(sys.argv[1], encoding='utf-8').read()
def n(s):
    s = unicodedata.normalize('NFKC', s)
    for c in '‘’': s = s.replace(c, "'")
    return re.sub(r'\s+', ' ', s).strip()
cits = [n(c['citation']) for c in json.load(open(sys.argv[2], encoding='utf-8'))]
fr = re.findall(r'«\s*(.+?)\s*»', t, flags=re.S)
ok = [s for s in fr if n(s) in cits]
autres = sorted(set(n(s) for s in fr if n(s) not in cits))
print(f"guillemets francais : {len(fr)} ; identiques a une citation : {len(ok)} ; autres (francais attendu) : {len(autres)}")
for s in autres: print("  AUTRE :", s[:120])
print("guillemets droits :", re.findall(r'"([^"\n]+)"', t))
lettres = re.findall(r'^\| ([A-Z]) — ', t, flags=re.M)
print("lettres :", lettres, "OK" if lettres == list("ABCDEFGHIJKL") else "ECART")
for l in t.splitlines():
    if re.match(r'^\| [A-L] — ', l) and not re.match(r'^\| [A-L] — [^|]+\| (majeur|mineur) \| (corrigé|réserve maintenue) \| [^|]+\| [^|]+\|$', l):
        print("LIGNE MAL FORMEE :", l[:60])
print("noms de modeles :", sorted(set(re.findall(r'(?i)\b(kimi|glm|qwen|gpt|deepseek|claude|gemini|llama|gemma)\b', t))))
