# Journal du lecteur, H1 contre 2609.19101, modèle A, v2

Écrit à : 2026-11-14 01:31:33 UTC (date -u dans la commande d'écriture). Début de la v2 : 2026-11-14 01:28:40 UTC.

- ls du seul dossier compte-2/ : aucun fichier H1-2609.19101-v2 avant écriture.
- Contre-lecture vérifiée (724857f51ef78bc8d8a18e614c87e97c9f67d0e8e33cf8f7fb6fa82586ce7a21), lue lignes 1 à 147 ; archive vérifiée (0d8de92cccf7530a572662bd976b85967003ac03b85c7b8e64e9b47dbeb0ee8a), extraite dans contre-lecture-extraite/ (sous-dossier neuf), lue comme donnée ; aucun de ses scripts n'a été exécuté (dont lire_figure8_v1.py).
- Relu sur le texte intégral extrait en v1 : p. 2, 4, 5, 6, 9, 11, 13, 14, 15, 17, 18, 24, 28-31, 35-37 ; figure 2 (p. 4, valeurs F1 du moniteur au grain du déroulé : minimum 47,3, maximum 95,1) ; figure 13 (p. 13, minimum sonde 29,9).
- Décisions : A à L corrigé (aucune réserve maintenue). L : fourchettes couvrant ma lecture à l'œil et la mesure au pixel du contre-lecteur, sans exécuter son script.
- Citations : 64 (36 de v1 + 28 nouvelles), 0 échec.
- Vérification du rapport : extraits anglais entre guillemets français tous identiques au JSON ; aucun guillemet droit ; table A à L complète et bien formée ; aucun nom de modèle.
