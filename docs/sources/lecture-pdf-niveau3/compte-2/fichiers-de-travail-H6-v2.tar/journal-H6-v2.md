# Journal du lecteur — H6 v2, compte 2, modèle A (contre-lecteur : modèle B ; A ≠ B)

Écrit le 2026-11-13 23:19:24 UTC (date -u, même commande).

1. 2026-11-13 23:13:28 UTC (date -u) : empreintes vérifiées — contre-lecture 3ce3ac3c… conforme, archive du contre-lecteur 2bd48d66… conforme, rapport v1 86b2d0cd… inchangé, consigne commune cb0623c4… conforme. Archive du contre-lecteur extraite dans ../contre-lecture-extraite/ (sous-dossier neuf) ; elle n'est pas reprise dans l'archive v2.
2. Contre-lecture lue en entier (227 lignes).
3. 23:13:43 UTC (date -u) : relecture ligne à ligne, texte brut — Ctrl-Z p. 29, 30, 31 en entier ; p. 7-8 (tirage illimité), p. 19 (définition de la sécurité), p. 13 (annexe A) ; 2605.26047 p. 19 (annexe C.4, et figure 14 vue sur le PDF), p. 11 (n=50 et note 6), p. 6 (agrégation de Kutasov 2025b), p. 21, p. 12 (références), p. 4 (note 3), p. 15, p. 3 (définition). Pages 5, 6 et 10 de chaque pièce relues lors de la v1 et revues pour les chiffres cités.
4. Lignes de l'énoncé relevées avec leur numéro : programme l. 91-98 et 188, plus les mentions « diffus » ou « papier A » de la plage 85-125 (l. 92, 93, 122, 124) ; N-013 l. 76-81 ; N-015 l. 10-30. Aucun autre fichier, aucune autre plage.
5. 23:16:14 UTC (date -u) : calculs_H6_v2.py lancé (sortie calculs-H6-v2.txt).
6. Citations v2 : les 69 de la v1 inchangées, plus 37 ajouts (n = 70 à 106) ; contrôle : 106 citations, 0 échec. Contrôleur retesté : juste, passe ; trois altérés, trois échecs.
7. Rapport v2 écrit ; sigle de la légende citée (figure 2 de Ctrl-Z) développé ; aucun nom de modèle (vérifié par recherche) ; table « Suite donnée » : une ligne par lettre, de A à J (vérifié par programme).
8. Aucune ouverture fautive, aucun refus, aucune commande git, aucun réseau.
