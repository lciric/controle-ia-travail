#!/usr/bin/env python3
"""Calculs du rapport H6 v2 (tous marques « calcul » dans le rapport)."""
r = lambda x: round(x, 1)
print("Ctrl-Z, 1 - 41,8 % =", r(100 - 41.8))
print("Ctrl-Z, 1 - 92,6 % =", r(100 - 92.6))
print("Ctrl-Z, 1 - 87,1 % =", r(100 - 87.1))
print("2605, victoires attaquant parmi parties decidees : 1 - 61 % =", 100 - 61, " ; 1 - 71 % =", 100 - 71)
print("2605, idem avec p. 15 : 1 - 60,9 % =", r(100 - 60.9), " ; 1 - 70,9 % =", r(100 - 70.9))
a0, a1 = 100 - 60.7, 100 - 64.7
print("consigne prudente : victoires attaquant", r(a0), "->", r(a1), " baisse relative %", r(100 * (a0 - a1) / a0))
u0, u1 = 69.0, 63.8
print("consigne prudente : utilite", u0, "->", u1, " ecart brut", r(u0 - u1), " baisse relative %", r(100 * (u0 - u1) / u0))
print("execution du moins suspect contre base (figure 7(i)) : 72 - 62 =", 72 - 62)
print("execution du moins suspect : 7,4 - 6,7 =", r(7.4 - 6.7), "(auteurs : +0,66 apparie)")
