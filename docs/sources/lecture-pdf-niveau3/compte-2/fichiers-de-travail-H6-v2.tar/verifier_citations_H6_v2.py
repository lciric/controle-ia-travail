#!/usr/bin/env python3
"""Controle des citations du rapport H6 (compte 2, lecteur, modele A).

Usage : python3 -I verifier_citations_H6_v1.py CITATIONS.json DOSSIER_PDF
Pour chaque citation {pdf, sha256, page, citation} : verifie l'empreinte du PDF,
extrait la page par pdftotext (avec et sans -layout), normalise (espaces,
ligatures, cesures, apostrophes, guillemets, tirets) et cherche la citation.
Trois niveaux : 1 = espaces normalises ; 2 = cesures de fin de ligne recollees ;
3 = espaces et traits d'union retires des deux cotes. Sortie : un echec = code 1.
"""
import hashlib
import json
import re
import subprocess
import sys
import unicodedata

LIG = {"ﬀ": "ff", "ﬁ": "fi", "ﬂ": "fl", "ﬃ": "ffi", "ﬄ": "ffl",
       "ﬅ": "st", "ﬆ": "st"}
APOS = {"’": "'", "‘": "'", "ʼ": "'", "′": "'", "`": "'",
        "“": '"', "”": '"', "„": '"', "«": '"', "»": '"'}
DASH = {"‐": "-", "‑": "-", "‒": "-", "–": "-", "—": "-",
        "―": "-", "−": "-", "­": ""}


def base(t):
    t = unicodedata.normalize("NFKC", t)
    for table in (LIG, APOS, DASH):
        for k, v in table.items():
            t = t.replace(k, v)
    return t


def niv1(t):
    return re.sub(r"\s+", " ", base(t)).strip()


def niv2(t):
    t = base(t)
    t = re.sub(r"(\w)-\s*\n\s*(\w)", r"\1\2", t)
    return re.sub(r"\s+", " ", t).strip()


def niv3(t):
    return re.sub(r"[\s\-]+", "", base(t))


def page_texte(pdf, page, layout):
    cmd = ["pdftotext"] + (["-layout"] if layout else []) + ["-f", str(page), "-l", str(page), pdf, "-"]
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for bloc in iter(lambda: f.read(1 << 20), b""):
            h.update(bloc)
    return h.hexdigest()


def main():
    cits = json.load(open(sys.argv[1], encoding="utf-8"))
    dossier = sys.argv[2].rstrip("/")
    empreintes = {}
    echecs = 0
    for i, c in enumerate(cits, 1):
        chemin = f"{dossier}/{c['pdf']}"
        if chemin not in empreintes:
            empreintes[chemin] = sha(chemin)
        if empreintes[chemin] != c["sha256"]:
            print(f"[{i}] ECHEC empreinte {c['pdf']}")
            echecs += 1
            continue
        trouve = None
        for layout in (False, True):
            texte = page_texte(chemin, c["page"], layout)
            for nom, f in (("1", niv1), ("2", niv2), ("3", niv3)):
                if f(c["citation"]) and f(c["citation"]) in f(texte):
                    trouve = f"niveau {nom}, {'layout' if layout else 'brut'}"
                    break
            if trouve:
                break
        if trouve:
            print(f"[{i}] OK {c['pdf']} p.{c['page']} ({trouve})")
        else:
            print(f"[{i}] ECHEC {c['pdf']} p.{c['page']} : {c['citation'][:80]}")
            echecs += 1
    print(f"TOTAL {len(cits)} citations, {echecs} echec(s)")
    sys.exit(1 if echecs else 0)


if __name__ == "__main__":
    main()
