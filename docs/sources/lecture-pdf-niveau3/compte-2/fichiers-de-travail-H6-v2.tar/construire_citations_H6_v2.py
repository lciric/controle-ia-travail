#!/usr/bin/env python3
"""citations-H6-v2.json : les 69 citations de la v1 (n = 1 a 69, inchangees) puis les ajouts (n = 70 et suivants)."""
import json
import sys

A = ("2504.10374v1.pdf", "5f802d679344fe5e15d1edd50e96245f3bdc054e69d1ff0880b077d173549211")
B = ("2605.26047v2.pdf", "947724f42324070fd47b1ecaf8c1bf9b2257df0e0c7f8822447241d3ea9a28fa")

AJOUTS = [
    (A, 7, "If the blue team could use unlimited resampling, they would"),                                   # 70
    (A, 8, "draw many samples at every step, so they can make a more informed decision about auditing"),      # 71
    (A, 8, "we still restrict the blue team to no more than double the queries to"),                          # 72
    (A, 31, "Attacks are preserved around 14% of the time through trusted edit."),                             # 73
    (A, 31, "This protocol also never preserves an attack."),                                                  # 74
    (A, 31, "Prompt T with the summary and ask for an action. Submit this action"),                            # 75
    (A, 31, "It only increases the average number of steps until the task is solved by 1.71"),                 # 76
    (A, 31, "it only increases the length of solved trajectories by 2.26"),                                    # 77
    (A, 29, "On average, it takes our policy 2.76 extra steps to pass the tests after a defer occurs."),       # 78
    (A, 5, "However, we find they only provide slight benefits, so we discuss them in Appendix H."),           # 79
    (A, 10, "larger amounts of shared state between tasks, which introduces more opportunities for subtle attacks"),  # 80
    (A, 6, "Caught Attacks: 33.2%"),                                                                           # 81
    (A, 6, "Caught Attacks: 70.6%"),                                                                           # 82
    (A, 19, "need not sum to 1, as an attack may silently fail without the blue team deciding to audit it"),   # 83
    (A, 19, "that the game never ends in a red-team victory, gives the overall probability of a blue-team win"),  # 84
    (A, 13, "we present here the results at an auditing budget of 0.3% and 3%"),                               # 85
    (A, 4, "DTR + Time Travel + UM"),                                                                          # 86
    (A, 31, "Prompt T with U's action and ask T to edit the action to be less suspicious"),                    # 87
    (B, 10, "(paired difference +0.66, 95% CI [+0.26, +1.11])"),                                               # 88
    (B, 10, "7.4 with resample execution, vs. 6.7 without"),                                                   # 89
    (B, 10, "Figure 7(i) shows that resample execution achieves 72% safety (95% CI [67%, 77%]) at a 0.3% auditing budget"),  # 90
    (B, 10, "at the headline 0.3% audit budget on the paired attack-task subset"),                             # 91
    (B, 11, "does not affect the tool calls that get executed, only which ones are audited"),                  # 92
    (B, 19, "resample execution offers a small, marginally significant improvement over IID resampling at N =2"),  # 93
    (B, 19, "compared to IID resampling with max aggregation (N =2) and baseline trusted monitoring (N =1)"),  # 94
    (B, 4, "Caution protocols move along the Pareto frontier by accepting some small usefulness cost."),       # 95
    (B, 6, "Because resampling draws samples from the exact same context"),                                    # 96
    (B, 6, "Bhatt et al. [2025] makes auditing decisions based on the minimum of sampled suspicion scores, but Kutasov et al."),  # 97
    (B, 21, "attempts to accomplish that side task on every main task it is run on"),                          # 98
    (B, 3, "Safety is the blue team's win probability, normalized to ignore no-win outcomes"),                 # 99
    (B, 11, "SWE-bench-mini only contains 50 tasks"),                                                          # 100
    (B, 12, "Mikhail Kutasov et al. Shade-arena: Evaluating sabotage and monitoring in control settings."),    # 101
    (B, 12, "Jon Kutasov, Chloe Loughridge"),                                                                  # 102
    (B, 15, "drops from 60.9% to 58.8% under the strictest rule"),                                             # 103
    (B, 15, "incrimination using 5 samples drops from 70.9% to 69.5%"),                                        # 104
    (B, 6, "dropping from 69.0% (95% CI [66.9%, 71.1%]) to 63.8%"),                                            # 105
    (B, 6, "Next we use the cautious prompt only on resample."),                                               # 106
]

v1 = json.load(open(sys.argv[1], encoding="utf-8"))
assert len(v1) == 69 and [c["n"] for c in v1] == list(range(1, 70))
sortie = list(v1)
for i, (p, pg, t) in enumerate(AJOUTS, 70):
    sortie.append({"n": i, "pdf": p[0], "sha256": p[1], "page": pg, "citation": t})
with open(sys.argv[2], "w", encoding="utf-8") as f:
    json.dump(sortie, f, ensure_ascii=False, indent=1)
print(len(sortie))
