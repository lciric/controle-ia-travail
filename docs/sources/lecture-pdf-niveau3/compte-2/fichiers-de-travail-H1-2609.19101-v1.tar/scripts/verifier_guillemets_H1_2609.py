"""Verifie que tout extrait entre guillemets francais est soit une citation du JSON, soit du francais (liste a relire)."""
import json, re, sys, unicodedata
t = open(sys.argv[1], encoding='utf-8').read()
def n(s):
    s = unicodedata.normalize('NFKC', s)
    for c in '‘’': s = s.replace(c, "'")
    return re.sub(r'\s+', ' ', s).strip()
cits = [n(c['citation']) for c in json.load(open(sys.argv[2], encoding='utf-8'))]
fr = re.findall(r'«\s*(.+?)\s*»', t, flags=re.S)
ok = [s for s in fr if n(s) in cits]
autres = sorted(set(n(s) for s in fr if n(s) not in cits))
print(f"guillemets francais : {len(fr)} ; identiques a une citation : {len(ok)} ; autres (a relire, francais attendu) : {len(autres)}")
for s in autres: print("  AUTRE :", s[:120])
print("guillemets droits :", re.findall(r'"([^"\n]+)"', t))
print("noms de modeles :", sorted(set(re.findall(r'(?i)\b(kimi|glm|qwen|gpt|deepseek|claude|gemini|llama|gemma)\b', t))))
