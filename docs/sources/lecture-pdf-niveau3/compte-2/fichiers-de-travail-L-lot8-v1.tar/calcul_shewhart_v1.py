# Calcul : probabilite de discretion sous le test de Shewhart (formule lue p. 7 de 1906.08938v2,
# Q = (1 - (1/gamma)^(1/(1+q)))^L), a energie totale E = q*L fixee, gamma = 500.
import math
g = 500.0
for E in (1.5, 3.0):
    for L in (1, 2, 5, 10, 20, 50, 100):
        q = E / L
        Q = (1 - g ** (-1 / (1 + q))) ** L
        print(f"E={E} L={L:4d} q={q:.4f} Q={Q:.4f}")
