# Journal du lecteur — mandat H2 — modèle A

Début relevé par date -u : Fri Nov 13 23:37:38 UTC 2026 (première commande : 2026-11-13 23:36:46 UTC). Journal écrit le 2026-11-13 23:45:55 UTC (date -u).

## Fichiers du dépôt ouverts (et seulement eux)
- consigne-lecteur-compte-2-v1.md (empreinte vérifiée : cb0623c4…7ff5, conforme), en entier (41 lignes).
- docs/notes/g0-deux-semaines-v1/consignes-mere-2026-11-10-0500-v1/interdits-communs-v2.md, en entier (21 lignes), nommé par la consigne.
- docs/programme-controle-ia-v2.md, lignes 85-125 et 180-200.
- docs/decisions/decision-N-007-N-008-v1.md, lignes 1-56.
- docs/etat-de-l-art/niveau2-v1/anteriorite-v1.md, lignes 62-94.
- docs/etat-de-l-art/etat-de-l-art-verifie-niveau3-v1.md, lignes 100-136.
- docs/etat-de-l-art/etat-de-l-art-verifie-niveau3-v1-contre-lecture-v1.md, lignes 838-875 ; puis grep -n 'm6' sur ce seul fichier (sortie : lignes 139, 785, 897, affichées par le grep demandé) ; section m6 lue des lignes 785 à 821, arrêt automatique à la ligne 822 (début de la section suivante, non affichée).
- Aucune commande git, aucun réseau, aucun appel de modèle, aucune recherche récursive dans le dépôt.

## PDF (dossier de pièces hors dépôt), empreintes vérifiées contre les compagnons .sha256 : toutes conformes
- 2501.03982v5.pdf e40c11311e785508a78953d87c5004be05b42e44a8277545b51c29886a3e96f1 — 26 p. lues ligne à ligne (p. 1-26, annexes A et B comprises).
- 2103.08402v3.pdf 2e259a65ddca593a95dbe014297f4bdf3d9ceb25cbe6f551fc6230d62c8de886 — p. 1-22 lues ligne à ligne ; p. 23-26 (figures d'annexe) lues sur les 80 premières lignes par page, reste vérifié par motifs : seulement des étiquettes d'axes.
- 2110.00115v6.pdf fd87e23a30c6657fd8dd272f671d0bd8a3aa469f5aafbec85a00bb9501764286 — 61 p. lues ligne à ligne (annexes A à I comprises ; pages de figures parcourues).
- 2604.01151v1.pdf ca9a8623307849be9df9f905086ea4c499f09c1a20208bcc4ed969e420eb08b3 — 11 p. lues ligne à ligne.
- 2604.01151v2.pdf ba39580b0e05b948e5cc8102ba8fb9209b810aff1b07b4d42b86276413ea0f40 — 29 p. parcourues par mots (sequential, accumulat, anytime, always valid, optional stop, stopping, martingale, e-value, e-process, SAVI, Ville, cusum, over time, across turns/rounds, multi-turn, temporal, horizon, cumulative, Howard ; puis threshold, 1% FPR, recall at, rounds, final-round, average) ; lues en entier : p. 1 (en-tête et résumé), p. 8, p. 9 ; passages lus : p. 4 (extraction des activations), p. 11 (références), p. 23 (G.7 News Framing).
- 2604.01151v4.pdf 6d7c29a6b72c65ac53b018b9798b4f0f9eca2d8978ebb4faebec6276338cd650 — 47 p. parcourues par les mêmes mots ; lues en entier : p. 1, 2, 3, 6, 7, 10, 11, 12, 13, 18, 19, 26 ; passages : p. 4-5, 14-17 (statistiques de test, seuils), p. 20, 22, 24, 25 (références), p. 46-47 (preuves des tests).

## Contrôle des citations
- Script scripts/controle_citations.py, lancé par python3 -I ; essai sur un cas juste (OK, code 0) et sur deux cas altérés (mot changé ; page fausse) : 2 échecs attendus, code 1 (essai/juste.json, essai/altere.json).
- citations-H2-v1.json : 70 citations, 0 échec (controle-citations-sortie.txt). Une citation de v4 p. 18 a dû être coupée en deux fragments : la légende de la figure 3 s'intercale dans le texte extrait.

## Constats de lecture notés en cours
- Aucun des trois articles de statistique ne parle de moniteur, de sonde, d'agent ou de modèle de langue (recherche par mots sur toutes les pages : aucune occurrence pertinente).
- NARCBench : les mots anytime, e-process, e-value, martingale, Ville n'apparaissent dans aucune version hors d'un titre de référence (v4 p. 24).
- NARCBench v2 cite « Howard et al., 2022 » pour un article des Annals of Statistics daté 2021 dans v4 et dans 2110.00115 (incohérence mineure de référence).
- Audit des guillemets du rapport (scripts/guillemets_rapport.py, 2026-11-13 23:49:02 UTC par date -u) : 93 extraits entre guillemets ; 73 figurent dans le JSON ; les 20 autres sont du français (relus un à un). Sortie : guillemets-sortie.txt.
- Archive : scripts, JSON, journal, sorties de contrôle, cas d'essai ; sans les PDF, sans textes extraits (dossier textes/ et relevé mots-narcbench.txt exclus).
