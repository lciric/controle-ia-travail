# Journal du lecteur (modele A), lot 4-B partie 2, v2

Ecriture : Sat Nov 14 00:29:00 UTC 2026

## Reprise v2
- 00:25:08 UTC (date -u) : ls du seul dossier compte-2 : aucun rapport-4B-partie2-v2.md ni fichiers-de-travail-4B-partie2-v2.tar. Revu a 00:26:43 UTC : toujours absents.
- Empreintes verifiees : consigne cb0623c4... ; contre-lecture 66127a9c... ; archive de contre-lecture 3f2b6564... ; rapport v1 dbcdb09c... ; PDF conformes (verifies en v1, fichiers inchanges).
- Archive de contre-lecture extraite dans le sous-dossier neuf archive-contre-lecture-v1/ ; lu : journal ; autres fichiers conserves, non executes.
- Contre-lecture lue en entier (81 lignes).

## Pages relues
- 2608.08975 : p. 5-8 (texte brut, lignes longues), p. 12, 24, 30 (texte deja extrait) ; en image : p. 22 (tableaux 10, 11), 47 (tableau 30), 48 (tableaux 31, 32), 49 (tableaux 33-35), 50 (tableau 36), 54 (tableau 40).
- 2611.10791 : p. 3, 7, 9, 13, 19, 35, 37 relues sur les passages cites (texte extrait en v1).

## Recalculs (calcul)
- Tableau 35, reecrivain le plus efficace, consigne stricte, moyenne des cinq relecteurs : tour 1 = 2,313/5 = 0,4626 ; tour 2 = 3,118/5 = 0,6236 ; tour 3 = 3,160/5 = 0,632.
- Spearman sur six rangs avec une inversion de voisins : 1 - 6*2/(6*35) = 0,9429.
- Tableau 8 : la ligne Overall mean imprime -1.361 (contre-lecture J, second point, rejete ; citation controlee p. 14).

## Decisions
- A a J : corrige (B corrige pour (c) et (f), (d) ramene a voisin lointain ; J corrige pour les modes de moyenne, second point rejete).

## Controle des citations
- citations-4B-partie2-v2.json : 105 citations (64 de la v1 + 41 nouvelles), verifier_citations.py : 0 echec (controle-citations-sortie-v2.txt).
- verifier_guillemets.py sur le rapport v2 : chaque extrait anglais entre guillemets est une entree exacte du JSON v2 ; les absents sont francais (et un couple de guillemets vides dans l'en-tete).

## Ouvertures fautives, refus
- Aucune ; aucun appel reseau ni de modele ; aucune commande git ; aucune suppression.
