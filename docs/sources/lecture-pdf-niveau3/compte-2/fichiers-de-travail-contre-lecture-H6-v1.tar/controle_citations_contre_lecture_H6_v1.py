#!/usr/bin/env python3
"""Controle des citations de la contre-lecture H6 (compte 2, contre-lecteur, modele B).

Usage : python3 -I controle_citations_contre_lecture_H6_v1.py CITATIONS.json DOSSIER_PDF
Ecrit independamment du script du lecteur. Pour chaque objet {pdf, sha256, page, citation} :
empreinte du PDF recalculee ; page extraite par pdftotext, sans puis avec -layout ;
normalisation (NFKC, ligatures, apostrophes, guillemets, tirets, cesures, espaces) ;
la citation doit etre une sous-chaine de la page. Deux formes : A = espaces reduits a un seul,
cesures recollees ; B = tous les espaces et traits d'union retires. Code de sortie 1 au moindre echec.
"""
import hashlib, json, re, subprocess, sys, unicodedata

REMPL = {
    "ﬀ": "ff", "ﬁ": "fi", "ﬂ": "fl", "ﬃ": "ffi", "ﬄ": "ffl",
    "’": "'", "‘": "'", "ʼ": "'", "′": "'", "`": "'",
    "“": '"', "”": '"', "„": '"', "«": '"', "»": '"',
    "‐": "-", "‑": "-", "‒": "-", "–": "-", "—": "-", "―": "-",
    "−": "-", "­": "",
}

def commun(t):
    t = unicodedata.normalize("NFKC", t)
    for a, b in REMPL.items():
        t = t.replace(a, b)
    return t

def forme_a(t):
    t = commun(t)
    t = re.sub(r"(\w)-\s*\n\s*(\w)", r"\1\2", t)
    return re.sub(r"\s+", " ", t).strip()

def forme_b(t):
    return re.sub(r"[\s\-]+", "", commun(t))

def extraire(pdf, page, layout):
    cmd = ["pdftotext"]
    if layout:
        cmd.append("-layout")
    cmd += ["-f", str(page), "-l", str(page), pdf, "-"]
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout

def empreinte(chemin):
    h = hashlib.sha256()
    with open(chemin, "rb") as f:
        while True:
            b = f.read(1 << 20)
            if not b:
                break
            h.update(b)
    return h.hexdigest()

def main():
    with open(sys.argv[1], encoding="utf-8") as f:
        cits = json.load(f)
    dossier = sys.argv[2].rstrip("/")
    vues, echecs = {}, 0
    for i, c in enumerate(cits, 1):
        chemin = dossier + "/" + c["pdf"]
        if chemin not in vues:
            vues[chemin] = empreinte(chemin)
        if vues[chemin] != c["sha256"]:
            print("[%d] ECHEC empreinte %s" % (i, c["pdf"])); echecs += 1; continue
        if not isinstance(c["page"], int) or not c["citation"].strip():
            print("[%d] ECHEC objet mal forme" % i); echecs += 1; continue
        ou = None
        for layout in (False, True):
            texte = extraire(chemin, c["page"], layout)
            for nom, f in (("A", forme_a), ("B", forme_b)):
                cible = f(c["citation"])
                if len(cible) >= 8 and cible in f(texte):
                    ou = "forme %s, %s" % (nom, "layout" if layout else "brut"); break
            if ou:
                break
        if ou:
            print("[%d] OK %s p.%d (%s)" % (i, c["pdf"], c["page"], ou))
        else:
            print("[%d] ECHEC %s p.%d : %s" % (i, c["pdf"], c["page"], c["citation"][:90])); echecs += 1
    print("TOTAL %d citations, %d echec(s)" % (len(cits), echecs))
    sys.exit(1 if echecs else 0)

if __name__ == "__main__":
    main()
