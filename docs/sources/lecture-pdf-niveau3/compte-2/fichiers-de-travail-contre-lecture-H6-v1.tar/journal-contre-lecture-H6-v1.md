# Journal du contre-lecteur — H6, compte 2, modèle B

Écrit le 2026-11-13 23:11:29 UTC (heure relevée par date -u dans la même commande). Premier relevé de la session : 2026-11-13 23:03:42 UTC (date -u, à l'extraction de l'archive du lecteur).

## Ordre des opérations
1. Empreintes vérifiées : consigne commune (cb0623c4…f77ff5), rapport (86b2d0cd…f132), archive du lecteur (ce947965…0088). Consigne lue en entier. interdits-communs-v2.md non ouvert : non nommé par mon mandat, qui limite mes lectures aux fichiers nommés.
2. Rapport lu en entier ; archive du lecteur extraite dans archive-A/ (dossier à part) ; journal, script et 69 citations du lecteur lus.
3. Énoncé lu aux lignes du mandat : programme v2 l. 85-125 et 185-200 ; N-013 l. 76-81 ; N-015 en entier ; niveau 3 l. 172-182 ; contre-lecture du niveau 3 l. 408-441. Une seule autre lecture du programme : un filtre sur trois motifs (H1, H6, E1.6) pour relever leurs numéros de ligne (93, 97, 188), tous dans les plages du mandat.
4. Empreintes des deux PDF recalculées, égales aux compagnons .sha256. Texte extrait page par page (pdftotext, brut et -layout) dans textes/ (non archivé).
5. Lecture des PDF (étendue ci-dessous), puis figures par l'outil de lecture sur le PDF.
6. Script de contrôle écrit sans reprendre celui du lecteur. Premier passage sur 51 citations : 1 échec (texte d'un axe de figure, absent du texte extrait) ; citation retirée. Essais lancés ensuite, pas avant (écart à l'ordre de la consigne) : cas juste, 0 échec ; cas altérés (mot changé, mauvaise page, mauvaise empreinte, chiffre changé), 4 échecs. Une citation ajoutée (p. 19 de Ctrl-Z). Contrôle final : 51 citations, 0 échec. Les 69 citations du lecteur repassées par mon script : 0 échec. Sortie : controle-citations-contre-lecture-H6-v1.txt.
7. Calculs : calculs_contre_lecture_H6_v1.py, python3 -I ; sortie : calculs-contre-lecture-H6-v1.txt.
8. Erreur de lecture corrigée avant scellement : j'avais pris « n=506 » (p. 11 de 2605.26047) pour une incohérence ; c'est « n=50 » suivi de l'appel de la note 6. Numéros de ligne du programme corrigés (93, 97, 188).

## Étendue réellement lue
### 2605.26047v2.pdf (46 pages)
- Pages 1 à 28 : lues ligne à ligne (texte brut).
- Pages 29 et 30 : début lu ; pages 29 à 46 (annexe I, exemples de rééchantillons, code) parcourues par mots (paraphrase, reformulation, réécriture, résumé, remise à zéro, contexte, troncature, température, utilité).
- Figures vues sur le PDF : pages 7 (figure 3), 9 (figure 6), 10 (figure 7), 19 (figure 14). Autres figures : légendes lues, images non vues.
### 2504.10374v1.pdf (38 pages)
- Pages 1 à 11, 13, 14, 19, 20, 22 à 26, 28 à 38 : lues ligne à ligne (texte brut ; lignes de plus de 600 à 900 caractères coupées à l'affichage pour les pages 19 à 38 ; pages 26, 28, 36 à 38 limitées aux 60 premières lignes non vides).
- Pages 12 (références), 15 à 18, 21, 27 : parcourues par mots seulement (chaque pas, toujours, fixe, base, ablation, aléatoire, uniforme, coût, paraphrase, remise à zéro, contexte, sans état, résumé, nombre d'échantillons).
- Figures vues sur le PDF : pages 6 (figure 4) et 35 (figure 11). Autres figures : légendes lues, images non vues.

## Points notés en lisant
- 2605.26047, p. 10-11 et 19 : le bras « exécution du moins suspect » tire N = 2 à chaque pas (non déclenché) ; utilité mesurée ; base N = 1 à 62 % sur la figure 7(i). Le rapport ne le compte pas dans l'occupation.
- Ctrl-Z, p. 7-8 : tirage systématique nommé, écarté pour le coût. P. 31 : survie des attaques à l'édition de confiance (14 %) et à la mise en œuvre de confiance (jamais). P. 19 : sécurité calculée en écartant les attaques sans issue.
- Énoncé : « diffus » absent de N-015 et de la ligne 97 du programme ; N-013 l. 80 nomme « l'affaiblissement sélectif de l'attaquant ».
- Aucun refus de permission, aucune ouverture fautive, aucune commande git, aucun appel réseau, aucun appel de modèle.
- Une liste simple (non récursive) du dossier de sortie du compte 2 a été affichée avant la copie, pour vérifier que les chemins de sortie étaient libres ; aucun autre fichier n'y a été ouvert.
