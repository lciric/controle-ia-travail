#!/usr/bin/env python3
"""Calculs de la contre-lecture H6 (python3 -I). Entrees : chiffres imprimes par les auteurs, recopies ici."""
# Ctrl-Z, 2504.10374v1 : p. 5 (surveillance de confiance), tableau 1 p. 8, tableau 2 p. 9
tm, tt, tt_um, dtr, dtr_um, dtt, dtt_um = 41.8, 87.1, 92.6, 83.2, 91.1, 72.7, 77.6
print("Ctrl-Z  1 - 41,8 %% = %.1f %%  (resume : 58 %%)" % (100 - tm))
print("Ctrl-Z  1 - 92,6 %% = %.1f %%  (resume : 7 %% ; arrondi a l'unite : %d)" % (100 - tt_um, round(100 - tt_um)))
print("Ctrl-Z  1 - 87,1 %% = %.1f %%  (sans surveillance non fiable ; arrondi : %d)" % (100 - tt, round(100 - tt)))
print("Ctrl-Z  autres cellules a 95 %% d'utilite, 1 - securite :", [round(100 - x, 1) for x in (dtt, dtt_um, dtr, dtr_um, 84.0, 84.9)])
print("Ctrl-Z  seule cellule des tableaux 1 et 2 qui s'arrondit a 7 : 92,6 ->", [x for x in (58.3,65.2,68.3,68.0,72.2,72.7,83.2,84.0,84.9,87.1,83.4,89.0,90.4,77.6,91.1,92.6) if round(100-x)==7])
# 2605.26047v2 : resume p. 1, p. 2, p. 15
print("2605    61 + 10,2 = %.1f (resume : 71) ; p. 15 : 70,9 - 60,9 = %.1f" % (61 + 10.2, 70.9 - 60.9))
print("2605    1 - securite : %.0f %% -> %.0f %% ; baisse relative %.1f %%" % (100-61, 100-71, 100*(1-(100-71)/(100-61))))
# consigne prudente, p. 6
s0, s1, u0, u1 = 60.7, 64.7, 69.0, 63.8
r0, r1 = 100 - s0, 100 - s1
print("2605 prudente  1 - securite : %.1f -> %.1f ; baisse absolue %.1f point ; relative %.1f %%" % (r0, r1, r0 - r1, 100*(r0-r1)/r0))
print("2605 prudente  utilite : %.1f -> %.1f ; baisse absolue %.1f point ; relative %.1f %%" % (u0, u1, u0 - u1, 100*(u0-u1)/u0))
# execution du moins suspect, N = 2, p. 10 et 11 (62 % lu sur la figure 7(i), 72 % auteurs)
print("2605 execution N=2 contre N=1 : 72 - 62 = %d points (62 lu sur la legende de la figure 7(i)) ; utilite -1,0 point [-2,8 ; +0,9], soit %.1f %% de 70 %%" % (72-62, 100*1.0/70))
