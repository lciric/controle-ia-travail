# Journal du lecteur — lot 4-B, partie 1 sur 2 (v1)

Rôle : lecteur, modèle A. Heures relevées par `date -u`.

## Chronologie
- 2026-11-14 00:02:47 UTC (relevé `date -u`) : consigne commune du compte 2 vérifiée (`cb0623c4aff841a815dc628691f407308acbeeeceb274db96d1f2ba3c8c77ff5`, conforme), lue en entier (41 lignes) ; `interdits-communs-v2.md` lu (tenu le plus strict : aucune commande git, aucune recherche récursive).
- Énoncé et état, aux lignes du mandat seulement :
  - `docs/decisions/decision-N-065-v1.md`, l. 1-29 (en entier) ;
  - `docs/decisions/decision-N-067-v1.md` : titres seuls par `grep -n '^#'` sur ce fichier, puis l. 9-26 (section 0), l. 35-93 (sections 2 à 5 : O2, O4, nul formé des lois connues, O11, O12, ce qui reste à mesurer). Section 1 (l. 27-34) et sections 6 à 10 non lues ;
  - `docs/etat-de-l-art/etat-de-l-art-verifie-niveau3-v1.md`, l. 464-522 ;
  - `docs/etat-de-l-art/etat-de-l-art-verifie-niveau3-v1-contre-lecture-v1.md`, l. 607-634 (constat M12).
- Empreintes des quatre PDF contrôlées contre leurs compagnons `.sha256` (toutes conformes). Le listage du dossier `lot4/` (commande `ls -la`, non récursive) a affiché les noms des autres fichiers du dossier ; aucun autre fichier n'a été ouvert, ni 2608.08975, ni 2611.10791.
- Texte extrait page par page par `pdftotext -layout -f N -l N` dans `travail-4B-partie1-v1/textes/` (non archivé) ; lecture faite sur la sortie sans `-layout` pour les pages à deux colonnes, sur la sortie `-layout` pour les tableaux (2510.18003 p. 9 ; 2609.28614 p. 13, 28).
- Figures relues en image (outil Read) : 2609.28614 p. 7, 8, 10, 11.
- Script de contrôle `scripts/controle_citations_v1.py` testé sur un cas juste (1 citation, 0 échec, code 0) et un cas altéré (3 citations : chiffre changé, page fausse, empreinte fausse ; 3 échecs, code 1).
- 2026-11-14 00:10 UTC (relevé `date -u`) : 70 citations contrôlées, 0 échec (après correction de pages : 2510.18003 p. 1 au lieu de 3 ; « p-values » remplacée par un autre extrait de la p. 3 à cause d'une césure ; 2609.28614 p. 24 au lieu de 23).

## Étendue lue par PDF
| PDF | pages | lues ligne à ligne | parcourues par mots |
|---|---|---|---|
| 2510.18003v2 | 16 | 1-9, 12 (annexe A.1-A.2), 13-16 (preuves, figure 3, liste des graines) | 10-12 (références) |
| 2606.13044v1 | 35 | 1-10, 15-35 (annexes A à J, invites comprises) | 11-14 (références) |
| 2609.28614v1 | 33 | 1-16, 19-33 (annexes A à F) ; figures p. 7, 8, 10, 11 en image | 16-18 (références) |
| 2604.22080v2 | 11 | 1-5, 9-11 (annexe A) | 5-8 (références ; p. 6-7 : liste d'auteurs d'une seule référence) |

## Recalculs (nature « calcul »)
- 2606.13044, tableau 1 (p. 7) : (1,47 + 1,24 + 0,91) / 3 = 1,207 ; (87,0 + 79,8 + 58,4) / 3 = 75,07 % : conformes à +1,21 et 75,1 %.
- 2606.13044, tableau 8 (p. 23) : diagonale (2,27 + 1,20 + 0,80) / 3 = 1,423 ; hors diagonale 5,26 / 6 = 0,877 : conformes à +1,42 et +0,88.
- 2609.28614, tableau 7 (p. 28) : sommes 505 (Cheats), 33 (Evade), 38 (BeatX) conformes.
- 2609.28614, tableau 2 (p. 13) : familles 694 + 64 + 46 + 44 + 32 + 43 = 923 ; tailles du cadre 2 403 + 24 + 27 + 21 + 7 + 18 = 500 ; évasions du cadre 2 recomposées 10 + 5 + 5 + 0 + 4 + 9 = 33 : conformes.
- 2609.28614, p. 10-11 : 7/150 = 4,67 % ; 56/150 = 37,3 % ; survie 150 → 143 → 129 → 114 → 104 → 94, soit 95,3 ; 86,0 ; 76,0 ; 69,3 ; 62,7 % : conformes.
- 2609.28614, figure 3 (p. 7, lue sur image) : somme des effectifs imprimés en bout de ligne = 114 ; points bleu-vert (tâches spécifiques) comptés = 9 ; 9/306 = 2,94 % (conforme à 2,9 %) ; mais le texte (p. 6) dit 105 piratages spontanés ; 105/340 = 30,9 % et 114 − 9 = 105 : le « 105 » semble ne compter que les tâches de chaîne de recherche, et 30,5 % × 340 = 103,7. Incohérence mineure, non résolue.
- 2609.28614, figure 8c (p. 11, image) : 56 → 44 (jury indépendant) → 39 pris par l'audit, 5 passent les trois ; 39/44 = 88,6 %.
- 2510.18003, tableau 4 (p. 9) : pour o3 et la détection intégrée à la relecture, (81,6 + (100 − 44,9)) / 2 = 68,35 % contre 67,0 % imprimé (si les deux classes sont égales, 50 et 50) ; écart mineur.
- 2510.18003, p. 6 et 15 : 25 graines × 4 articles = 100 articles par stratégie, si « 4 papers » s'entend par stratégie (lecture ambiguë) ; des taux du tableau 1 comme 4,7 % ou 38,4 % suggèrent un dénominateur d'environ 85 pour le taux de soupçon, non expliqué.
- 2510.18003 : la ligne « Baseline » du tableau 3 (p. 8 ; corpus de 50 vrais et 50 fabriqués) porte un taux de soupçon de o3 de 50,6 %, identique à celui de la stratégie « All » du tableau 1 (p. 7, corpus tout fabriqué) ; coïncidence ou reprise, non expliquée.

## Reprise
- 2026-11-14 00:12:11 UTC (relevé `date -u`) : message de reprise de la coordination (redémarrage du conteneur, rien versé). Contrôlé : aucun `rapport-4B-partie1-v1.md` ni `fichiers-de-travail-4B-partie1-v1.tar` dans `docs/sources/lecture-pdf-niveau3/compte-2/` (`ls` de ce seul dossier) ; dossier de travail intact ; empreintes des quatre PDF recontrôlées (conformes). La lecture intégrale des quatre PDF était achevée avant l'interruption (étendue ci-dessus) ; rapport écrit ensuite, contrôle des citations relancé sur la version finale.
- Ajout d'une citation (2609.28614 p. 1, venue imprimée) ; contrôle relancé sur la version finale du JSON : 71 citations, 0 échec (sortie dans `sortie-controle-citations-v1.txt`). Contrôle programmatique : tout extrait entre « » du rapport absent du JSON est du français (liste relue).
- 2026-11-14 00:14:48 UTC (relevé `date -u`) : fin ; archive constituée (script, JSON, journal, sortie du contrôle, cas d'essai ; sans PDF ni textes extraits), puis scellement du rapport et de l'archive.
