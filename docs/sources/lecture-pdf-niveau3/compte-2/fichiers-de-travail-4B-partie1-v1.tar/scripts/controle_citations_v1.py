"""Controle des citations du lot 4-B, partie 1 (lecteur, modele A).

Usage : python3 -I controle_citations_v1.py DOSSIER_PDF FICHIER_JSON
Pour chaque citation {pdf, sha256, page, citation} : verifie l'empreinte du PDF,
extrait la page par pdftotext (avec et sans -layout), normalise (NFKC, ligatures,
apostrophes, guillemets, tirets, cesures, espaces) et cherche la citation.
Sortie : une ligne par citation, puis le compte des echecs ; code de retour 1 si echec.
"""
import hashlib
import json
import re
import subprocess
import sys
import unicodedata

TRAD = {
    "‘": "'", "’": "'", "‚": "'", "′": "'",
    "“": '"', "”": '"', "„": '"',
    "–": "-", "—": "-", "−": "-", "‐": "-", "‑": "-",
    "­": "", "ﬁ": "fi", "ﬂ": "fl", "ﬀ": "ff", "ﬃ": "ffi", "ﬄ": "ffl",
    " ": " ",
}


def normaliser(texte, cesure):
    texte = unicodedata.normalize("NFKC", texte)
    for a, b in TRAD.items():
        texte = texte.replace(a, b)
    if cesure:
        texte = re.sub(r"(\w)-\s*\n\s*(\w)", r"\1\2", texte)
    texte = re.sub(r"\s+", " ", texte)
    return texte.strip()


def page_textes(pdf, page):
    sorties = []
    for options in (["-layout"], []):
        r = subprocess.run(["pdftotext", *options, "-f", str(page), "-l", str(page), pdf, "-"],
                           capture_output=True, text=True, check=True)
        sorties.append(r.stdout)
    return sorties


def sha256(chemin):
    h = hashlib.sha256()
    with open(chemin, "rb") as f:
        for bloc in iter(lambda: f.read(1 << 20), b""):
            h.update(bloc)
    return h.hexdigest()


def main():
    dossier, fichier = sys.argv[1], sys.argv[2]
    with open(fichier, encoding="utf-8") as f:
        citations = json.load(f)
    empreintes = {}
    echecs = 0
    for i, c in enumerate(citations, 1):
        chemin = f"{dossier}/{c['pdf']}"
        if chemin not in empreintes:
            empreintes[chemin] = sha256(chemin)
        ok_sha = empreintes[chemin] == c["sha256"]
        cibles = [normaliser(c["citation"], False), normaliser(c["citation"], True)]
        trouve = False
        for t in page_textes(chemin, c["page"]):
            for cesure in (False, True):
                n = normaliser(t, cesure)
                if any(x in n for x in cibles):
                    trouve = True
        etat = "OK" if (trouve and ok_sha) else "ECHEC"
        if etat == "ECHEC":
            echecs += 1
        print(f"{i:03d} {etat} sha={'ok' if ok_sha else 'FAUX'} {c['pdf']} p.{c['page']} :: {c['citation'][:70]}")
    print(f"TOTAL {len(citations)} citations, {echecs} echec(s)")
    sys.exit(1 if echecs else 0)


if __name__ == "__main__":
    main()
