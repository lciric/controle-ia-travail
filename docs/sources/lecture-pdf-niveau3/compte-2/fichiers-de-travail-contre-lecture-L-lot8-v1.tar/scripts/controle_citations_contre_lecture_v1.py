"""Controle par programme des citations de la contre-lecture du rapport L (lot 8), v1.
Usage : python3 -I controle_citations_contre_lecture_v1.py DOSSIER_PDF FICHIER.json
Chaque entree : {"pdf","sha256","page","citation"}.
Pour chaque entree : empreinte du PDF recalculee et comparee ; texte de la page par pdftotext (brut puis -layout) ;
normalisation (NFKC : ligatures ; apostrophes, guillemets, tirets ; espaces) ; recherche de la citation,
puis seconde recherche apres suppression des cesures de fin de ligne. Sortie 0 seulement si aucun echec.
"""
import hashlib
import json
import re
import subprocess
import sys
import unicodedata

REMPL = {"’": "'", "‘": "'", "“": '"', "”": '"', "–": "-", "—": "-",
         "‐": "-", "‑": "-", "−": "-", "­": "", " ": " "}


def normaliser(s):
    s = unicodedata.normalize("NFKC", s)
    for a, b in REMPL.items():
        s = s.replace(a, b)
    return re.sub(r"\s+", " ", s).strip()


def decesurer(s):
    return re.sub(r"(?<=\w)- (?=\w)", "", s)


def texte_page(pdf, page, layout):
    cmd = ["pdftotext", "-f", str(page), "-l", str(page)]
    if layout:
        cmd.append("-layout")
    cmd += [pdf, "-"]
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout


def main(dossier, fichier):
    with open(fichier, encoding="utf-8") as f:
        entrees = json.load(f)
    empreintes, echecs = {}, 0
    for i, e in enumerate(entrees, 1):
        chemin = dossier.rstrip("/") + "/" + e["pdf"]
        if chemin not in empreintes:
            with open(chemin, "rb") as f:
                empreintes[chemin] = hashlib.sha256(f.read()).hexdigest()
        if empreintes[chemin] != e["sha256"]:
            print(f"ECHEC {i:3d} empreinte differente pour {e['pdf']}")
            echecs += 1
            continue
        cible = normaliser(e["citation"])
        if len(cible) < 12:
            print(f"ECHEC {i:3d} citation trop courte pour etre probante : {cible!r}")
            echecs += 1
            continue
        mode = None
        for layout in (False, True):
            t = normaliser(texte_page(chemin, e["page"], layout))
            if cible in t:
                mode = ("layout" if layout else "brut") + ", direct"
                break
            if decesurer(cible) in decesurer(t):
                mode = ("layout" if layout else "brut") + ", cesures retirees"
                break
        if mode:
            print(f"OK    {i:3d} {e['pdf']} p.{e['page']} [{mode}] {e['citation'][:80]}")
        else:
            print(f"ECHEC {i:3d} {e['pdf']} p.{e['page']} {e['citation'][:100]}")
            echecs += 1
    print(f"TOTAL citations={len(entrees)} echecs={echecs}")
    return 1 if echecs else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1], sys.argv[2]))
