"""Contre-calcul du calcul << Shewhart >> du rapport L (lot 8).
Formule lue sur 1906.08938v2.pdf, p. 7 (fin de la preuve du theoreme 1) :
    Q_L^SH(q) = (1 - (1/gamma)^(1/(1+q)))^L
(probabilite qu'aucune alarme ne sonne pendant les L pas d'emission, seuil regle par P_inf{alarme a un pas} = 1/gamma, p. 7, (12)-(13)).
Trois lectures :
 A. reproduction du rapport : energie totale E = q*L fixee, fenetre = L (varie avec L) ;
 B. part de fausse alarme : sans emission (q = 0) la meme fenetre de L pas donne deja (1 - 1/gamma)^L ;
 C. fenetre fixe n (cadre de L2 : n fixe, fragmentation m = L) :
    P(aucune alarme sur n pas) = (1 - 1/gamma)^(n-L) * Q_L(E/L) ; alarme = 1 - cela ; niveau nul = 1 - (1 - 1/gamma)^n.
Lancement : python3 -I calcul_shewhart_contre_lecture_v1.py
"""
import math

def Q(q, L, g):
    return (1.0 - g ** (-1.0 / (1.0 + q))) ** L

g = 500.0
print("A. reproduction (gamma = 500) : Q a energie E = q*L fixee ; B. base sans emission (1-1/gamma)^L ; ecart = base - Q")
for E in (1.5, 3.0):
    for L in (1, 2, 5, 10, 20, 50, 100):
        q = E / L
        base = (1 - 1 / g) ** L
        print(f"E={E} L={L:4d} q={q:.4f} Q={Q(q, L, g):.4f} base={base:.4f} ecart={base - Q(q, L, g):.4f}")

print()
print("A'. le maximum de Q en L (fenetre = L) est-il interieur ?")
for E in (1.5, 3.0):
    vals = [(Q(E / L, L, g), L) for L in range(1, 201)]
    best = max(vals)
    print(f"E={E} argmax L={best[1]} Q={best[0]:.4f} ; Q(L=1)={vals[0][0]:.4f} ; Q(L=200)={vals[-1][0]:.4f}")

print()
print("B'. l'ecart a la base (detection due a l'emission seule) est-il monotone en L ?")
for E in (1.5, 3.0):
    ec = [(1 - 1 / g) ** L - Q(E / L, L, g) for L in range(1, 201)]
    mono = all(ec[i + 1] <= ec[i] + 1e-15 for i in range(len(ec) - 1))
    print(f"E={E} ecart(L=1)={ec[0]:.4f} ecart(L=10)={ec[9]:.4f} ecart(L=100)={ec[99]:.4f} decroissant sur 1..200 : {mono}")

print()
print("C. fenetre fixe n = 100 : probabilite d'alarme sur la fenetre, emission fragmentee sur m = L pas, energie E fixee")
n = 100
nul = 1 - (1 - 1 / g) ** n
for E in (1.5, 3.0):
    al = [1 - (1 - 1 / g) ** (n - L) * Q(E / L, L, g) for L in range(1, n + 1)]
    mono = all(al[i + 1] <= al[i] + 1e-15 for i in range(len(al) - 1))
    print(f"E={E} niveau nul={nul:.4f} alarme(m=1)={al[0]:.4f} (m=2)={al[1]:.4f} (m=5)={al[4]:.4f} (m=10)={al[9]:.4f} "
          f"(m=50)={al[49]:.4f} (m=n)={al[-1]:.4f} ; decroissante en m : {mono} ; plancher - nul = {al[-1] - nul:.4f}")
