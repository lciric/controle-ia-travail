"""Ecrit citations-contre-lecture-L-v1.json, essai_juste.json et essai_altere.json.
Usage : python3 -I ecrire_citations_contre_lecture_v1.py DOSSIER_SORTIE"""
import json
import sys

A = ("1906.08938v2.pdf", "3fbaedd9705420fff23cbadb9c7d3de2240c2714c23440cbf133718534194ea9")
B = ("2605.16140v1.pdf", "1f70a3284a2eca0b62cded4dd43e6f88cc6930e3275349a17bee76850860a72a")
C = ("math-0410072v1.pdf", "cfcca06ea5e2b3852549dd896f381b2141c82fffa787787fc6fb6a5db560cbbf")

L = [
    # 1906.08938
    (A, 1, "Ke-Wen Huang, Hui-Ming Wang, Senior Member, IEEE,"),
    (A, 1, "Don Towsley, Life Fellow, IEEE, and H. Vincent Poor, Fellow, IEEE"),
    (A, 1, "bits covertly and reliably to Bob in n channel usages"),
    (A, 1, "when Willie does not exactly know when Alice starts to transmit (if she does) [9]–[11]"),
    (A, 2, "the beginning of which is random and unknown to Willie"),
    (A, 4, "only depends on the instantaneous sample observation and is"),
    (A, 5, "the detection procedure is equivalent to sequentially comparing the received signal power to a pre-designed threshold"),
    (A, 5, "We refer to such an event as timely detection."),
    (A, 6, "Willie’s detection process makes sense only when timely detection occurs"),
    (A, 6, "With the Shewhart test, the following theorem characterizes"),
    (A, 7, "(b) follows from the fact that {yν+k : 1 ≤ k ≤ L} are i.i.d."),
    (A, 10, "Corollary 3: Under the SR test, if ν < γ − 2 − µ for some positive real number µ, then for any pre-given θ (0 < θ < 1), there exists a θ-covert (q, L)-system."),
    (A, 10, "monotonically decreasing in both q and L."),
    (A, 12, "set the ARL2FA of Willie’s detector γ = 500"),
    (A, 13, "This is because the detector accumulates more noise samples before Alice starts to transmit to Bob as ν increases."),
    (A, 13, "is maximized in the middle of the feasible region of L."),
    (A, 14, "converges to a quasi-stationary distribution"),
    (A, 14, "SR test is not sensitive to a statistical change that occurs at the beginning of the detection procedure"),
    (A, 15, "B. A. Bash, D. Goeckel, and D. Towsley, “Covert communication gains from adversary’s ignorance of transmission time,”"),
    (A, 15, "B. A. Bash, D. Goeckel, and D. Towsley, “LPD communication when the warden does not know when,”"),
    # 2605.16140
    (B, 1, "from steganography [1]–[3] to covert communications [4]–[6]"),
    (B, 1, "ability to perform stealthy attacks in cyber-physical systems [15], [16]"),
    (B, 7, "we assume that Eve has full knowledge of Alice’s active policy"),
    (B, 14, "the probing sequence should both use low probing intensity and avoid inducing statistically detectable structure"),
    (B, 14, "where the instantaneous cost depends only on the current probing probability βi and channel state"),
    (B, 16, "the ECB constraint fundamentally limits the total probing effort that can be expended covertly."),
    (B, 17, "Under Q, we maintain Γ ∼ Geo(ρ), but the observations are drawn from the pre-change distribution for all t ≥ 1, regardless of Γ."),
    (B, 18, "Second, we claim that the relative entropy between P and Q is exactly the product of"),
    (B, 18, "representing the history of Alice’s causal information joined with oracle knowledge of the changepoint"),
    (B, 21, "dropping the pre-change part of ECB"),
    (B, 21, "On the other hand, from Cauchy-Schwarz inequality,"),
    (B, 22, "allocate a flat sequence between"),
    (B, 32, "intuitively the ECB is overwhelmingly dominated by the post-change detection period"),
    (B, 34, "A. Ker, “A capacity result for batch steganography,” IEEE Signal Processing Letters, vol. 14, no. 8, pp. 525–528, 2007."),
    (B, 35, "Security in stochastic control systems: Fundamental limitations and performance"),
    (B, 35, "K.-W. Huang, H.-M. Wang, D. Towsley, and H. V. Poor, “LPD communication: A sequential change-point detection perspective,”"),
    (B, 35, "K.-W. Huang, H.-M. Wang, and H. V. Poor, “On covert communication against sequential change-point detection,”"),
    # math/0410072
    (C, 2, "there are n independent tests of unrelated hypotheses"),
    (C, 4, "so that the fraction of nonzero means is small but not vanishingly small"),
    (C, 9, "Two detection boundaries are only different when"),
    (C, 10, "so that Mn is effective in the range of very sparse alternatives, while"),
    (C, 10, "so that Mn is inefficient if"),
    (C, 11, "Fn is unable to separate H1 and H0"),
    (C, 14, "Section 4 describes some simulation experiments."),
    (C, 22, "such as in watermarking and steganography, could reasonably use the model"),
]

def ecrire(nom, liste):
    with open(sys.argv[1].rstrip("/") + "/" + nom, "w", encoding="utf-8") as f:
        json.dump([{"pdf": p[0], "sha256": p[1], "page": pg, "citation": c} for (p, pg, c) in liste],
                  f, ensure_ascii=False, indent=1)

ecrire("citations-contre-lecture-L-v1.json", L)
ecrire("essai_juste.json", [L[2], L[25]])
ecrire("essai_altere.json", [
    (A, 1, "bits covertly and reliably to Bob in 2n channel usages"),           # mot change
    (A, 2, "bits covertly and reliably to Bob in n channel usages"),            # bonne citation, mauvaise page
    ((A[0], "0" * 64), 1, "bits covertly and reliably to Bob in n channel usages"),  # mauvaise empreinte
    (B, 16, "the ECB constraint fundamentally limits the total probing effort that can be expended overtly."),  # mot change
    (C, 9, "only when"),                                                        # trop courte
])
print(len(L), "citations ecrites")
