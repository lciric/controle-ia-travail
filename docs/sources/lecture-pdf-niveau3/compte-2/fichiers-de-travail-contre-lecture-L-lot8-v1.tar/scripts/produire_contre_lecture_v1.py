"""Produit la contre-lecture a partir du gabarit : heures (passees en arguments, relevees par date -u) et table des citations.
Usage : python3 -I produire_contre_lecture_v1.py GABARIT CITATIONS.json SORTIE DEBUT FIN"""
import json
import sys

gab, cit, sortie, debut, fin = sys.argv[1:6]
s = open(gab, encoding="utf-8").read()
c = json.load(open(cit, encoding="utf-8"))
lignes = [f"| K{i} | `{e['pdf']}` | {e['page']} | {e['citation'].replace('|', chr(92) + '|')} |" for i, e in enumerate(c, 1)]
for cle in ("@@DEBUT@@", "@@FIN@@", "@@TABLE@@"):
    assert s.count(cle) == 1, cle
s = s.replace("@@DEBUT@@", debut).replace("@@FIN@@", fin).replace("@@TABLE@@", "\n".join(lignes))
# controle : tout renvoi [Kn] du texte existe et sa citation entre guillemets est celle du fichier
import re
for m in re.finditer(r"« ([^»]+?) » \[K(\d+)\]", s):
    n = int(m.group(2))
    assert 1 <= n <= len(c), n
    assert m.group(1) == c[n - 1]["citation"], (n, m.group(1), c[n - 1]["citation"])
print("renvois K verifies :", len(re.findall(r"« [^»]+? » \[K\d+\]", s)), "; citations :", len(c))
open(sortie, "x", encoding="utf-8").write(s)
