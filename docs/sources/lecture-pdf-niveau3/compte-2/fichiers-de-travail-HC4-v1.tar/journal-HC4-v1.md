# Journal du lecteur — HC4, compte 2 (modèle A)

Écrit le 2026-11-13 23:27:56 UTC (relevé par date -u ; début de session 2026-11-13 23:21:26 UTC, relevé par date -u).

## Consignes et énoncé
- Consigne commune lue en entier ; empreinte vérifiée : cb0623c4aff841a815dc628691f407308acbeeeceb274db96d1f2ba3c8c77ff5 (conforme).
- interdits-communs-v2.md lu en entier ; la consigne du compte 2 est plus stricte (aucune commande git) : tenue.
- Énoncé lu aux lignes du mandat seulement : programme v2 l. 85-125 et 190-215 ; N-013 l. 46-55 ; N-068 l. 1-115 ; anteriorite-v1 l. 279-292 ; synthèse niveau 3 l. 412-431 ; contre-lecture l. 509-535 (M8) et 696-726 (M14).
- Aucun autre fichier du dépôt ouvert. Aucune commande git, aucun réseau, aucun appel de modèle. Aucune ouverture fautive.

## Empreintes (vérifiées contre les compagnons .sha256 avant lecture, toutes conformes)
- 2601.04603v1.pdf ba8ec6570a41c42554ac89b9869020a2356cead5bdcf2618fc9c6208a89afdb5 (17 p.)
- 2309.10253v4.pdf f2b76387acd042a27db07e8093dc4f4f4b876eb28d6a16fcf886432b31f1ffac (26 p.)
- 2310.08419v4.pdf 590bf40aa58061928f54d01b7d53f0d5141bb2ecf4f01483c6849423934f44e4 (34 p.)
- 2502.19537v5.pdf 4f991dbe01b2c853189b45e1b36906bf355a367550f96703cf320b6e9f291d3c (37 p.)

## Étendue lue
- 2601.04603v1 : p. 1-17 lues ligne à ligne (pdftotext -layout) ; figures des p. 7-8 lues sur l'image (outil de lecture du PDF).
- 2309.10253v4 : p. 1-23 et 25-26 lues ligne à ligne ; p. 24 (figure 9, histogramme par gabarit) parcourue ; figure 5 de la p. 13 lue sur l'image.
- 2310.08419v4 : p. 1-34 lues ligne à ligne (p. 27-33 : légendes seules, les figures sont des captures de conversations ; non lues sur l'image).
- 2502.19537v5 : p. 1-23 et 36-37 lues ligne à ligne ; p. 26-27 lues en partie ligne à ligne ; p. 24-35 (exemples de sorties nuisibles, annexes H et I) parcourues par mots : modèles, statuts « Success/Failure », aucune donnée chiffrée de coût (contrôle par recherche de motifs).

## Citations
- Script : scripts/verifier_citations_v1.py (python3 -I) ; constructeur : scripts/construire_citations_v1.py.
- Essai sur cas juste (1 citation, 0 échec, code 0) et cas altérés (texte changé, page fausse, empreinte fausse : 3 échecs, code 1) : essais/.
- Contrôle final : 79 citations, 0 échec.

## Points de calcul (nature « calcul »)
- 2601.04603 : 0,01871/0,00885 = 2,11 (l'article écrit « 2.2x », p. 2) ; 1/198K = 0,00505 ; 13/695K = 0,0187 ; 2/226K = 0,00885 ; 5/569K = 0,00879 ; 150/3,5 = 42,9 ; 27,8/3,5 = 7,9 ; 150/27,8 = 5,4 ; 2 x 46 x 4096 = 376 832 opérations ; 8e9/376 832 = 2,1e4.
- 2310.08419 : 256 000/10 = 25 600 ; 256 000/56 = 4 571 ; 5 120/11,9 = 430 ; 5 120/33,8 = 151 (aucun ne donne « 250-fold », p. 2).
- 2502.19537 : 0,57/0,086 = 6,6 ; 0,57/0,06 = 9,5 ; 0,57/0,043 = 13,3 ; 0,57/0,013 = 43,8 (« seven times higher than previous fine-tuning attacks », p. 2).

## Reprise après redémarrage du conteneur (relevé 2026-11-13 23:30:40 UTC, date -u)
- Message de la coordination reçu : rien versé ; vérifié par ls du seul dossier compte-2 : aucun rapport-HC4-v1.md ni fichiers-de-travail-HC4-v1.tar. Dossier de travail intact (citations, journal, scripts, essais, textes extraits).
- Empreintes des quatre PDF revérifiées contre leurs compagnons : toutes conformes.
- Lecture complétée : 2502.19537v5 p. 24-35 lues ligne à ligne (exemples de sorties sous attaque, annexes H et I ; aucun chiffre de coût ; les tableaux 11 à 15 se disent « with defenses » sans dire quelle défense s'applique à quelle ligne) ; 2310.08419v4 p. 27-33 lues sur l'image (captures de conversations : exemples d'attaques par autorité, appel logique, jeu de rôle ; aucun chiffre) ; 2309.10253v4 p. 23-24 lues sur l'image (figure 8 : captures ; figure 9 : axe « ASR (%) » gradué de 0 à 1,0, incohérence d'unité mineure).
- Étendue finale : les quatre PDF lus en entier (texte ligne à ligne, figures sur l'image là où le texte extrait était illisible).
- Contrôle final des citations relancé le 2026-11-13 23:33:13 UTC (date -u) sur la version finale : 79 citations, 0 échec (controle-citations-final-v1.txt).
