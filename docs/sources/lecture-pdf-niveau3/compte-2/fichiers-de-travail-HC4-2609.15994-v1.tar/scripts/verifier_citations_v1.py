"""Contrôle des citations : chaque citation doit figurer dans le texte pdftotext de sa page
(avec et sans -layout), après normalisation. Usage : python3 -I verifier_citations_v1.py PDF JSON"""
import json, re, subprocess, sys, unicodedata, hashlib

def extraire(pdf, page, layout):
    cmd = ["pdftotext"] + (["-layout"] if layout else []) + ["-f", str(page), "-l", str(page), pdf, "-"]
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout

TABLE = {"’": "'", "‘": "'", "“": '"', "”": '"', "–": "-", "—": "-",
         "−": "-", "‐": "-", "‑": "-", "∼": "~", " ": " "}

def norm(s):
    s = unicodedata.normalize("NFKC", s)
    for a, b in TABLE.items():
        s = s.replace(a, b)
    return re.sub(r"\s+", " ", s).strip()

def variantes(texte):
    t = unicodedata.normalize("NFKC", texte)
    for a, b in TABLE.items():
        t = t.replace(a, b)
    v1 = re.sub(r"-\s*\n\s*", "", t)      # césure retirée
    v2 = re.sub(r"-\s*\n\s*", "-", t)     # trait d'union gardé
    return [norm(t), norm(v1), norm(v2)]

def main(pdf, js):
    emp = hashlib.sha256(open(pdf, "rb").read()).hexdigest()
    cits = json.load(open(js, encoding="utf-8"))
    cache, echecs = {}, 0
    for i, c in enumerate(cits):
        if c["sha256"] != emp:
            print(f"ECHEC {i} empreinte"); echecs += 1; continue
        p = c["page"]
        if p not in cache:
            cache[p] = variantes(extraire(pdf, p, True)) + variantes(extraire(pdf, p, False))
        q = norm(c["citation"])
        if any(q in v for v in cache[p]):
            continue
        echecs += 1
        print(f"ECHEC {i} p.{p} : {c['citation'][:90]}")
    print(f"{len(cits)} citations, {echecs} echec(s)")
    return echecs

if __name__ == "__main__":
    sys.exit(1 if main(sys.argv[1], sys.argv[2]) else 0)
