"""Extrait chaque passage entre « » du rapport et le cherche (normalisé) dans les citations du JSON.
Usage : python3 -I controler_guillemets_rapport_v1.py RAPPORT JSON"""
import json, re, sys, unicodedata
T = {"’": "'", "‘": "'", "“": '"', "”": '"', "–": "-", "—": "-", "−": "-", "∼": "~", " ": " ", " ": " "}
def n(s):
    s = unicodedata.normalize("NFKC", s)
    for a, b in T.items(): s = s.replace(a, b)
    return re.sub(r"\s+", " ", s).strip()
r = open(sys.argv[1], encoding="utf-8").read()
cits = [n(c["citation"]) for c in json.load(open(sys.argv[2], encoding="utf-8"))]
passages = re.findall(r"«\s*(.*?)\s*»", r, flags=re.S)
trouves, absents = [], []
for p in passages:
    (trouves if any(n(p) in c for c in cits) else absents).append(p)
print(f"{len(passages)} passages ; {len(trouves)} trouvés dans le JSON ; {len(absents)} absents")
for p in absents: print("ABSENT :", n(p)[:160])
