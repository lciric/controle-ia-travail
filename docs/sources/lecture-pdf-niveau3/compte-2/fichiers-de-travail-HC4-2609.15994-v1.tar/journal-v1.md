Sat Nov 14 06:28:39 UTC 2026 début ; consigne cb0623c4… conforme ; rapport-HC4-v2 6c368ebb… conforme ; interdits-communs-v2 lu
Sat Nov 14 06:29:02 UTC 2026 PDF 2609.15994v1 1cbd4a41…9e25 conforme au compagnon ; textes extraits dans textes/ (hors archive)
Sat Nov 14 06:29:14 UTC 2026 p.1-4 lues ligne à ligne
Sat Nov 14 06:29:19 UTC 2026 p.5-6 lues ligne à ligne
Sat Nov 14 06:29:25 UTC 2026 p.7-8 lues ligne à ligne
Sat Nov 14 06:29:32 UTC 2026 p.9-10 lues ligne à ligne
Sat Nov 14 06:29:41 UTC 2026 p.11-12 lues ligne à ligne
Sat Nov 14 06:29:49 UTC 2026 p.13-14 lues ligne à ligne
Sat Nov 14 06:29:59 UTC 2026 p.15-16 lues ligne à ligne
Sat Nov 14 06:30:55 UTC 2026 p.17-18 lues ligne à ligne ; les 18 pages lues ligne à ligne (texte -layout). Reste : figures 1-9 sur l'image
Sat Nov 14 06:31:32 UTC 2026 figures lues sur l'image : p.4 (fig.1, 2, tableau 1), p.5 (fig.3, tableau 2), p.6 (tableau 3), p.7 (fig.4, 5), p.12 (fig.6, 7, 8, tableau 8), p.15 (fig.9, tableau 12).
Notes de lecture :
- sonde : linéaire, Llama-3.1-8B-Instruct couche 31, dernier jeton du tour utilisateur (lit le modèle qui RECOIT l'entrée) ; cible : intention de l'utilisateur malveillante (injection, jailbreak, demande nuisible, arnaque) contre bénigne ; 29 jeux, N=168440 (p.3, 13-14).
- perturbation : paquet de 5 composantes, 3,33 éditions de caractères en moyenne (1-5) (p.5) ; ESW ~50 % des jetons (p.2, 6). Aucune requête, aucun accès, aucune optimisation ; non adverse (p.2, 5, 8).
- chute : TPR@1%FPR 97,4 -> 85,4 (-12,0 pp), AUC -0,55 pp (tab.2 p.5) ; tab.3 p.6 multi-positions <=0,87 pp localisé ; ESW : linéaire -6,85, MLP moyenne -16,81, attention -3,78, maxi -3,91.
- parades : augmentation -3,70 résiduel (tab.4 p.7) ; KV-fork -0,60 (tab.5 p.8) ; MAIS hors distribution (LODO) KV-fork delta paquet -4,5 contre -3,5 sans (tab.17 p.16) : pire.
- juge génératif : Claude Sonnet 4.5 comme juge d'équivalence (A.2 p.10) et non comme moniteur ; intention préservée 94,6 %, équivalence 76,6 % ; refus basculés 27/294.
- aucune comparaison sonde contre juge-moniteur. Comparaison qualitative sonde contre comportement du modèle (p.8).
- incohérences : fig.1 Gemma ~38° < 43° ; p.8 « rotates the user-EOT activation by 43–56° » contre tab.1 4,7° à EOT ; couches Gemma 28/29/40/41 (p.3) contre 10/21/29/41 (fig.7 p.12) ; « order of magnitude » 3,7/0,6=6,2 ; LODO acc 0,77-0,81 (p.5) contre 0,775-0,821 (tab.13) ; tab.10 classes contre tab.14 (7 plis mixtes) ; ‡ fusion Gandalf/Scam contre plis séparés ; tab.18 même source pour Code Exercise et Python-Alpaca ; bascules vers conformité 15 contre 20/16/8 % ; « bypasses both probe and alignment (§3.3) » sans score de sonde sur l'exemple.
Sat Nov 14 06:32:19 UTC 2026 script verifier_citations_v1.py écrit
Sat Nov 14 06:32:58 UTC 2026 essais du script : cas juste 0 échec ; deux cas altérés (chiffre changé, page fausse) 2 échecs : conforme
Sat Nov 14 06:33:35 UTC 2026 JSON citations réécrit et contrôlé
Sat Nov 14 06:33:45 UTC 2026 JSON : 98 citations, 0 échec
Sat Nov 14 06:34:46 UTC 2026 JSON : 106 citations, 0 échec ; rédaction du rapport commencée
Sat Nov 14 06:34:56 UTC 2026 JSON : 106 citations, 0 échec ; rédaction du rapport commencée
Sat Nov 14 06:37:22 UTC 2026 rapport rédigé ; guillemets contrôlés ; absents tous en français
Sat Nov 14 06:37:41 UTC 2026 note : la ligne de 06:34:46 est mal étiquetée (1 échec restait, p.2) ; 0 échec à 06:34:56 (106), puis 107 citations, 0 échec après ajout de la citation p.1. En-tête et réserves du rapport complétés.
Sat Nov 14 06:38:01 UTC 2026 relecture finie ; copie du rapport et archive
