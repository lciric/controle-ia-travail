# Journal du contre-lecteur, H1, modèle B (v1)

Début : 2026-11-13 23:46:20 UTC (création du dossier de travail, date -u -r). Journal écrit à : 2026-11-13 23:53:42 UTC (date -u).

## Lu dans le dépôt (fichiers nommés, lignes indiquées seulement)
- consigne-lecteur-compte-2-v1.md, 1 à 41, empreinte cb0623c4aff841a815dc628691f407308acbeeeceb274db96d1f2ba3c8c77ff5 (concorde).
- rapport-H1-v1.md, 1 à 238, empreinte 46e77d0992a0744a34335beb5953bf24bdcbc1cf447d7bfc8b0adc6f40a5a4fe (concorde) ; archive du lecteur, empreinte 3472422771346addc8f8341563dbba206a10786673e341c270a00907682d7444 (concorde), extraite dans le dossier de travail.
- docs/programme-controle-ia-v2.md, 85 à 125 et 180 à 200 ; decision-N-055-v1.md, 32 à 37 ; decision-N-056-v1.md, 36 à 80.
- etat-de-l-art-verifie-niveau3-v1.md, 62 à 99 ; etat-de-l-art-verifie-niveau3-v1-contre-lecture-v1.md, 264 à 292.
- Non ouvert : interdits-communs-v2.md (nommé par la consigne commune, absent de mon mandat) ; anteriorite-v1.md (lu par le lecteur, absent de mon mandat).
- Aucune commande git, aucun réseau, aucun appel de modèle, aucune recherche récursive dans le dépôt. Rien sous registres/, diag/, runs/, donnees/ ; rien de T0.7, de 7a ni de 7b.

## Pièces (empreintes : compagnon et calcul concordants)
- lot8/2610.31593v1.pdf b127a5d0e34a118dc03f784d69028ffaf0d71381b43f165899b100168a5fbd5f, 22 pages.
- lot8/2604.15384v2.pdf d294bf631a15d89d48e5e9311b82cd6b31d578929bf7846f169ebd9c1ed3f12e, 51 pages.
- lot3/2610.39766v1.pdf e17604d3769d516cdc2c5a907f3531c47616acaaaa2fc9516a3d2c649f29b728, 22 pages.

## Étendue réellement lue (pdftotext sans -layout, page par page)
- 2610.39766 : p. 1 à 4, 6 à 8 ligne à ligne ; p. 9 à 22 en écartant les lignes de 14 caractères ou moins ; p. 5 par mots. Images : p. 3, 4, 17.
- 2610.31593 : p. 1 à 6 (lignes de 14 caractères ou moins écartées) ; p. 7 à 13 (40 ou moins écartées) ; p. 15 à 20 (60 ou moins écartées) ; p. 14, 21, 22 par mots. Images : p. 9, 11.
- 2604.15384 : p. 1, 2, 4 à 6, 8, 12 à 20, 28 à 32, 39 à 51 (30 ou moins écartées) ; p. 3, 7, 9 à 11, 25 à 27, 33 à 38 (50 ou moins écartées) ; p. 21 à 24 par mots. Images : p. 16, 19, 30, 51.
- Recherches sur le texte complet non filtré des 95 pages : prob(e|es|ing), activation, white-box, black-box, linear, internal, representation, residual, hidden state, interpretab, latent, logit, mechanis, embedding, classifier, logprob, fine-tun, trained monitor, untrusted monitor ; diffuse, low-stakes, high-stakes, distributed, spread, gradual, fragment, smother, individually, connect the dots, incremental, subtle, ambiguous, underspecified, sandbag, research sabotage ; threshold, honest, calibrat, held-out, action monitor, per-action.
  Résultat : aucune sonde d'activations ni boîte blanche dans 2610.31593 et 2604.15384 ; le mot anglais pour sonde, dans 2610.31593, est un nom de variable dans un exemple de code (p. 5), verbe (p. 15), discriminateur par modèle de langue (p. 20).

## Notes brutes
- LinuxArena p. 40 : fragmentation inscrite aux étapes 5 et 7 de la planification de la politique d'attaque par défaut ; p. 13 : le moniteur par étape voit toutes les actions passées ; p. 12 : moyenne de deux appels ; p. 28 : étapes d'avant le dommage seulement ; p. 30 (image) : n_attack=185, n_honest=400, 56 attaques à dommage immédiat ; à 1 % par étape, lecture par étape environ 0,90, combinée environ 0,84, trajectoire entière environ 0,43 ; p. 46 : trajectoires humaines itérées jusqu'à un score d'au plus 5.
- 2610.39766 p. 2 et 7 : filtrage des jeux aux exemples où le modèle répond juste ; p. 3 et 4 : facteur 2 (cinq meilleures sondes) et facteur 3 (treize architectures) ; p. 8 : facteurs 2 à 5 seulement, contre 10 et 20 p. 3, 4, 12 ; p. 17 (image) : meilleure sonde linéaire sur le dernier jeton, environ 0,07 à 1 positif, 0,18 vers 10, 0,28 au plus ; équilibré : 0,16 au plus.
- 2610.31593 p. 20 : le discriminateur sépare sorties simulées et sorties enregistrées, sessions sans attaque.
- « À une table près » : expression de S-2A, non lue ; le PDF v2 ne contient pas la comparaison ; sens de l'expression non vérifiable par les fichiers de mon mandat.
- Rapport du lecteur : neuf minutes entre début et écriture (23:36:03 à 23:45:05, d'après son en-tête).

## Contrôle des citations
- Script scripts/controle_citations_contre_lecture_H1_v1.py (python3 -I). Essai juste : 1 citation, 0 échec. Essai altéré : 3 citations, 3 échecs (mot changé, mauvaise page, mauvaise empreinte). Réel : 40 citations, 0 échec ; 40 extraits entre guillemets droits dans la contre-lecture, 0 hors JSON. Citations du lecteur repassées : 41, 0 échec.
