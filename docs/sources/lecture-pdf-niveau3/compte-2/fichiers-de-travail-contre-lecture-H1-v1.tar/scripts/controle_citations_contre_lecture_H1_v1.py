"""Controle des citations de la contre-lecture H1 (contre-lecteur, modele B), v1.

Usage : python3 -I controle_citations_contre_lecture_H1_v1.py CITATIONS.json DOSSIER_PDF [DOSSIER_PDF ...] [--rapport RAPPORT.md]

Ecrit independamment du script du lecteur. Pour chaque objet {pdf, sha256, page, citation} :
  1. le PDF est cherche par nom dans les dossiers ; son empreinte sha256 est recalculee et comparee ;
  2. la page est extraite par pdftotext, avec -layout puis sans ;
  3. texte et citation sont normalises (NFKC, ligatures, apostrophes, guillemets, tirets, cesures
     de fin de ligne recollees avec et sans tiret, espaces) ;
  4. la citation doit etre une sous-chaine du texte de la page dans au moins une variante.
Option --rapport : toute chaine entre guillemets droits du rapport doit figurer, a l'identique,
parmi les citations du JSON (exigence du mandat).
Code de retour : 0 si zero echec, 1 sinon.
"""
import hashlib
import json
import pathlib
import re
import subprocess
import sys
import unicodedata

REMPLACEMENTS = {
    "‐": "-", "‑": "-", "‒": "-", "–": "-", "—": "-", "―": "-", "−": "-",
    "‘": "'", "’": "'", "‚": "'", "‛": "'", "′": "'", "´": "'", "`": "'",
    "“": '"', "”": '"', "„": '"', "‟": '"', "″": '"',
    "­": "",
}


def norm(s, recoller_sans_tiret):
    s = unicodedata.normalize("NFKC", s)
    s = "".join(REMPLACEMENTS.get(c, c) for c in s)
    s = re.sub(r"-[ \t]*\n[ \t]*", "" if recoller_sans_tiret else "-", s)
    return re.sub(r"\s+", " ", s).strip()


def empreinte(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        while True:
            b = f.read(1 << 20)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def page_texte(pdf, page, layout):
    args = ["pdftotext"]
    if layout:
        args.append("-layout")
    args += ["-f", str(page), "-l", str(page), str(pdf), "-"]
    return subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, check=True).stdout.decode("utf-8", "replace")


def main(argv):
    rapport = None
    if "--rapport" in argv:
        i = argv.index("--rapport")
        rapport = argv[i + 1]
        argv = argv[:i] + argv[i + 2:]
    fichier, dossiers = argv[1], [pathlib.Path(d) for d in argv[2:]]
    cits = json.loads(pathlib.Path(fichier).read_text(encoding="utf-8"))
    echecs = 0
    shas, pages = {}, {}
    for n, c in enumerate(cits, 1):
        raison = None
        cand = [d / c["pdf"] for d in dossiers if (d / c["pdf"]).is_file()]
        if not cand:
            raison = "PDF introuvable"
        else:
            pdf = cand[0]
            shas.setdefault(pdf, empreinte(pdf))
            if shas[pdf] != c["sha256"]:
                raison = "empreinte differente"
            elif not c["citation"].strip():
                raison = "citation vide"
            else:
                trouve = False
                for layout in (False, True):
                    cle = (pdf, c["page"], layout)
                    if cle not in pages:
                        pages[cle] = page_texte(pdf, c["page"], layout)
                    for sans in (True, False):
                        if norm(c["citation"], sans) in norm(pages[cle], sans):
                            trouve = True
                if not trouve:
                    raison = "absente de la page"
        if raison:
            echecs += 1
        print("%3d %-28s %s p.%d : %s" % (n, "OK" if not raison else "ECHEC (" + raison + ")", c["pdf"], c["page"], c["citation"][:80]))
    print("TOTAL citations : %d ; echecs : %d" % (len(cits), echecs))
    if rapport:
        texte = pathlib.Path(rapport).read_text(encoding="utf-8")
        connues = {c["citation"] for c in cits}
        entre = re.findall(r'"([^"\n]+)"', texte)
        hors = [e for e in entre if e not in connues]
        for e in hors:
            print("HORS JSON : " + e)
        print("TOTAL extraits entre guillemets droits du rapport : %d ; hors JSON : %d" % (len(entre), len(hors)))
        echecs += len(hors)
    return 1 if echecs else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
