"""Controle des citations du rapport H1 (lecteur, modele A), v1.

Usage : python3 -I controle_citations_H1_v1.py CITATIONS.json DOSSIER_PDF [DOSSIER_PDF ...]

Pour chaque citation {pdf, sha256, page, citation} :
- retrouve le PDF par son nom dans les dossiers donnes, verifie son empreinte sha256 ;
- extrait la page par pdftotext (avec et sans -layout) ;
- normalise (NFKC pour les ligatures, apostrophes et guillemets, tirets, cesures, espaces) ;
- verifie que la citation normalisee figure dans le texte normalise de la page.
Sortie : une ligne par citation (OK / ECHEC) et un total ; code de retour 1 si un echec.
"""
import hashlib
import json
import os
import re
import subprocess
import sys
import unicodedata

TIRETS = "‐‑‒–—―−"
APOS = "‘’‚‛′´`"
GUILL = "“”„‟«»″"


def normaliser(texte, garder_tiret_cesure):
    t = unicodedata.normalize("NFKC", texte)
    t = t.replace("­", "")
    for c in TIRETS:
        t = t.replace(c, "-")
    for c in APOS:
        t = t.replace(c, "'")
    for c in GUILL:
        t = t.replace(c, '"')
    if garder_tiret_cesure:
        t = re.sub(r"-\s*\n\s*", "-", t)
    else:
        t = re.sub(r"-\s*\n\s*", "", t)
    t = re.sub(r"\s+", " ", t)
    return t.strip()


def extraire(pdf, page, layout):
    cmd = ["pdftotext"] + (["-layout"] if layout else []) + ["-f", str(page), "-l", str(page), pdf, "-"]
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout


def sha256(chemin):
    h = hashlib.sha256()
    with open(chemin, "rb") as f:
        for bloc in iter(lambda: f.read(1 << 20), b""):
            h.update(bloc)
    return h.hexdigest()


def trouver(nom, dossiers):
    for d in dossiers:
        c = os.path.join(d, nom)
        if os.path.isfile(c):
            return c
    return None


def main():
    chemin_json, dossiers = sys.argv[1], sys.argv[2:]
    with open(chemin_json, encoding="utf-8") as f:
        citations = json.load(f)
    cache_page, cache_sha = {}, {}
    echecs = 0
    for i, c in enumerate(citations, 1):
        pdf = trouver(c["pdf"], dossiers)
        motif = ""
        ok = False
        if pdf is None:
            motif = "PDF introuvable"
        else:
            if pdf not in cache_sha:
                cache_sha[pdf] = sha256(pdf)
            if cache_sha[pdf] != c["sha256"]:
                motif = "empreinte differente"
            else:
                for layout in (True, False):
                    cle = (pdf, c["page"], layout)
                    if cle not in cache_page:
                        cache_page[cle] = extraire(pdf, c["page"], layout)
                    for garder in (False, True):
                        page_n = normaliser(cache_page[cle], garder)
                        cit_n = normaliser(c["citation"], garder)
                        if cit_n and cit_n in page_n:
                            ok = True
                            break
                    if ok:
                        break
                if not ok:
                    motif = "citation absente de la page"
        if not ok:
            echecs += 1
        etat = "OK" if ok else "ECHEC (" + motif + ")"
        print(f"{i:3d} {etat:<40} {c['pdf']} p.{c['page']} : {c['citation'][:70]}")
    print(f"TOTAL {len(citations)} citations, {echecs} echec(s)")
    sys.exit(1 if echecs else 0)


if __name__ == "__main__":
    main()
