# Journal du lecteur, H1, modèle A (v1)

Écrit à : 2026-11-13 23:42:18 UTC (relevé par date -u dans la commande d'écriture). Début de session relevé : 2026-11-13 23:36:03 UTC (date -u).

## Consignes lues
- consigne-lecteur-compte-2-v1.md, lignes 1 à 41 (entier) ; empreinte vérifiée : cb0623c4aff841a815dc628691f407308acbeeeceb274db96d1f2ba3c8c77ff5 (concorde).
- docs/notes/g0-deux-semaines-v1/consignes-mere-2026-11-10-0500-v1/interdits-communs-v2.md, lignes 1 à 21 (entier) ; règle tenue : la plus stricte (aucune commande git du tout).

## Énoncé et état lus (fichiers nommés, lignes indiquées seulement)
- docs/programme-controle-ia-v2.md : lignes 85 à 125 et 180 à 200.
- docs/decisions/decision-N-055-v1.md : titres (grep -n '^#' sur ce seul fichier), puis lignes 32 à 37 (section « Nœud H1b »).
- docs/decisions/decision-N-056-v1.md : titres (grep -n '^#' sur ce seul fichier), puis lignes 36 à 80 (section « Ce que cela fixe », qui porte le nœud 1 de G1, le nœud 2 et la règle de H1 entre modes D-S29).
- docs/etat-de-l-art/niveau2-v1/anteriorite-v1.md : lignes 32 à 61.
- docs/etat-de-l-art/etat-de-l-art-verifie-niveau3-v1.md : lignes 62 à 99.
- docs/etat-de-l-art/etat-de-l-art-verifie-niveau3-v1-contre-lecture-v1.md : lignes 264 à 292.
- Aucun autre fichier du dépôt ouvert. Aucune commande git, aucun réseau, aucun appel de modèle. Rien sous registres/, diag/, runs/, donnees/ ; rien de T0.7, de 7a ni de 7b.

## Pièces : empreintes (compagnon .sha256 et calcul concordants)
- lot8/2610.31593v1.pdf : b127a5d0e34a118dc03f784d69028ffaf0d71381b43f165899b100168a5fbd5f (22 pages).
- lot8/2604.15384v2.pdf : d294bf631a15d89d48e5e9311b82cd6b31d578929bf7846f169ebd9c1ed3f12e (51 pages).
- lot3/2610.39766v1.pdf : e17604d3769d516cdc2c5a907f3531c47616acaaaa2fc9516a3d2c649f29b728 (22 pages).

## Étendue réellement lue
- 2610.31593v1 : pages 1 à 7 lues ligne à ligne (pdftotext -layout) ; pages 8 à 22 lues ligne à ligne sur le texte sans -layout, en écartant à l'affichage les lignes de 12 caractères ou moins (jetons d'axes et d'étiquettes de figures) ; page 8 lue en entier sans filtre. Recherche de termes (probe, activation, white-box, internal, diffuse, distributed, multi-step, spread, low-stakes, sabotage, fragment, per-action, action monitor, step, false-positive, FPR, calibrat, held-out, threshold) sur le texte non filtré des 22 pages. Figures parcourues par leurs légendes.
- 2604.15384v2 : pages 1 à 51 lues ligne à ligne (texte sans -layout, sans filtre). Figures vues sur le PDF (outil de lecture) : pages 15, 16, 19, 29, 30, 51 (toutes les figures qui listent des moniteurs : aucun moniteur à sondes). Autres figures (pages 25 à 28, 33 à 38, 47 à 50) parcourues par leurs légendes. Recherche de termes (probe, activation, white-box, internal, residual stream, hidden state, interpretab, diffuse, low-stakes, distributed, spread, fragment, smother, individually) sur les 51 pages : aucune occurrence de sonde, d'activation ni de boîte blanche.
- 2610.39766v1 : pages 1 à 22 lues ligne à ligne (pdftotext -layout). Figures vues sur le PDF : pages 3, 4, 12, 13, 17. Autres figures (pages 9 à 11, 14 à 16, 18 à 22) parcourues par leurs légendes.

## Contrôle des citations
- Script : scripts/controle_citations_H1_v1.py, lancé par python3 -I.
- Essai juste (essais/juste.json) : 1 citation, 0 échec. Essai altéré (essais/altere.json : mot changé, mauvaise page, mauvaise empreinte) : 3 citations, 3 échecs (attendu).
- Contrôle réel : citations-H1-v1.json, 41 citations, 0 échec (sortie-controle-citations-H1-v1.txt).

## Notes de lecture (brutes)
- 2610.31593 : cinq moniteurs de texte sur trajectoire entière ; seuils d'audit sur les trajectoires honnêtes exécutées qui servent aussi de références au simulateur ; sûreté à 5 % de budget d'audit ; aucune sonde ; le mot « probe » de la page 20 désigne un discriminateur par modèle de langue (lecture des sorties d'actions), pas une sonde d'activations. Aucune sous-tâche diffuse ; chaque sous-tâche a un correcteur ou un juge de succès.
- 2604.15384 : moniteurs de texte seulement (onze au groupe principal, davantage en annexe J), par action (avant exécution) et sur trajectoire ; seuil au 99e centile des scores par action des épisodes honnêtes du même modèle (dans l'échantillon) ; une trajectoire est signalée si une de ses actions l'est (maximum sur les étapes) ; règle combinée = maximum des rangs centiles ; sous-tâches concentrées avec correcteur caché ; fragmentation intra-trajectoire décrite (pages 6, 17, 40, 42) sans mesure séparée. Aucune table sondes contre texte.
- 2610.39766 : sondes seules (linéaire, attention, cosinus, sur autoencodeur creux), aucune base boîte noire ; spam (hors politique) et honnêteté MASK (sur politique) ; agrégation sur les jetons (moyenne, maximum, dernier jeton, softmax) ; rappel à 1 % de faux positifs sur un test équilibré 50/50, réglage du seuil non décrit ; incohérences : 2x (p. 3) contre 3x (p. 4) pour le meilleur facteur de suréchantillonnage ; 0,6 à 14 milliards (texte p. 4) contre une courbe 32 milliards (figure 4, p. 4) ; section A.6.3 vide (p. 12). Sur MASK, rappel à 1 % de faux positifs bas (figure 21, p. 17).
