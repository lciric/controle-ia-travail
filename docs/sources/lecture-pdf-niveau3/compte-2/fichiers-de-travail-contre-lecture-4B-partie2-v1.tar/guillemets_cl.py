import json, re, sys
rap = open(sys.argv[1], encoding="utf-8").read()
cits = {c["citation"] for c in json.load(open(sys.argv[2], encoding="utf-8"))}
ext = re.findall(r"«\s*(.*?)\s*»", rap, flags=re.S)
abs_ = [e for e in ext if e not in cits]
print(len(ext), "extraits entre guillemets ;", len(abs_), "absents du JSON :")
for e in abs_: print("  -", e[:120])
