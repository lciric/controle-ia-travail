"""Controle des citations - contre-lecture 4B partie 2 (modele B).
Usage : python3 -I controle_citations_cl.py DOSSIER_PDF FICHIER_JSON
Chaque citation doit figurer dans le texte de la page (pdftotext avec ou sans -layout),
apres normalisation (NFKC, ligatures, apostrophes, guillemets, tirets, cesures, espaces).
"""
import hashlib, json, re, subprocess, sys, unicodedata, os

def norm(t, cesure):
    t = unicodedata.normalize("NFKC", t)
    for a, b in (("ﬀ", "ff"), ("ﬁ", "fi"), ("ﬂ", "fl"), ("ﬃ", "ffi"), ("ﬄ", "ffl")):
        t = t.replace(a, b)
    t = re.sub("[‘’‚‛′´`]", "'", t)
    t = re.sub("[“”„‟«»]", '"', t)
    t = re.sub("[‐‑‒–—―−]", "-", t)
    t = t.replace(" ", " ").replace(" ", " ").replace("­", "")
    if cesure:
        t = re.sub(r"-\s*\n\s*", "", t)
    return re.sub(r"\s+", " ", t).strip()

def page(pdf, n, layout):
    cmd = ["pdftotext"] + (["-layout"] if layout else []) + ["-f", str(n), "-l", str(n), pdf, "-"]
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout

def main():
    dossier, fichier = sys.argv[1], sys.argv[2]
    cits = json.load(open(fichier, encoding="utf-8"))
    emp, echecs = {}, 0
    for i, c in enumerate(cits, 1):
        p = os.path.join(dossier, c["pdf"])
        if p not in emp:
            emp[p] = hashlib.sha256(open(p, "rb").read()).hexdigest()
        ok = emp[p] == c["sha256"] and bool(c["citation"].strip())
        if ok:
            ok = False
            for layout in (True, False):
                brut = page(p, c["page"], layout)
                for ces in (False, True):
                    if norm(c["citation"], ces) in norm(brut, ces):
                        ok = True
        echecs += 0 if ok else 1
        print(f"{i:03d} {'ok' if ok else 'ECHEC'} {c['pdf']} p.{c['page']} : {c['citation'][:80]}")
    print(f"TOTAL {len(cits)} citations, {echecs} echec(s)")
    sys.exit(1 if echecs else 0)

main()
