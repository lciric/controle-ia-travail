# Journal du contre-lecteur (modele B), lot 4-B partie 2, v1

Debut de session : Sat Nov 14 00:16:53 UTC 2026 (date -u sur la creation du dossier de travail, premiere commande).
Ecriture du journal : Sat Nov 14 00:23:21 UTC 2026

## Verifications
- Consigne commune compte 2 : sha256 cb0623c4aff841a815dc628691f407308acbeeeceb274db96d1f2ba3c8c77ff5 (conforme), lue en entier (41 lignes).
- Interdits communs v2 : NON ouverts (hors de la liste fermee du mandat) ; interdits de la consigne et du mandat tenus.
- Rapport : sha256 dbcdb09ce76583f4a8631fbdff1a7db9f0c012aecc0e1c27562bccf4d2f7b980 (conforme), lu en entier (128 lignes).
- Archive de l'auteur : sha256 b83be473244a930d970d3a208662e63be20b34c1aba35001e5af3c7a02dae886 (conforme), extraite dans archive-auteur/ ; lus : journal, verifier_citations.py ; JSON repasse par mon script.
- 2608.08975v1.pdf : sha256 cea31a07b3d124be3cb87c6193feaee8924f167a9ae3f8d2cb9ba29995924d01 = compagnon ; 63 pages.
- 2611.10791v1.pdf : sha256 5465764cf2de6501d7256d712d0bd9cd11fbf93a700dce02d5c900e3527ab4ac = compagnon ; 38 pages.
- Aucun autre PDF ouvert ; le dossier des pieces n'a pas ete liste.

## Fichiers du depot lus (aux lignes indiquees)
- docs/decisions/decision-N-065-v1.md : 1-29.
- docs/decisions/decision-N-067-v1.md : titres par grep -n '^#' ; l. 35-93 (sections 2 a 5, non decoupees par revendication).
- docs/etat-de-l-art/etat-de-l-art-verifie-niveau3-v1.md : l. 464-522.
- docs/etat-de-l-art/etat-de-l-art-verifie-niveau3-v1-contre-lecture-v1.md : l. 607-634.
- Dossier compte-2 : un ls filtre sur le motif de mes noms de sortie (recherche d'homonymes), rien d'autre.

## Etendue lue par PDF
- 2611.10791v1 : p. 1-16 et 33-38 ligne a ligne (pdftotext) ; p. 19-20, 23-25 par la prose (lignes de plus de 40 caracteres) ; p. 17-18, 21-22, 26-32 par titres, enonces (theoremes, propositions, tableaux) et mots.
- 2608.08975v1 : p. 1-15 et 19-24 prose ligne a ligne (lignes longues ; tableaux du corps par legendes et lignes de moyenne) ; p. 16-18 ligne a ligne ; p. 47-50 et 54 en image (outil Read) ; p. 4, 22, 26 relues avec -layout pour les tableaux 1, 11, 16 ; p. 25-46, 51-53, 55-63 par la prose filtree et par mots. Tableaux 27-29 (p. 37-46) non lus ligne a ligne.
- Recherche active page par page dans 2608.08975 : ground truth, oracle, statistical test, p-value, significan, human (rating, review, score...), official, neutral, placebo, paraphras, control, content-preserv, fidelity, semantic, numeric, metric, verif, manual, acceptance decision, automated research, research agent, AI scientist, tournament, pairwise, Elo, regression to the mean, repeated review, violation, repair, drift, discard. Resultat : aucun juge non generatif applique aux versions reecrites ; un controleur par programme des ancres de structure (p. 6) ; notes humaines sur les seuls originaux.
- Recherche dans 2611.10791 (p. 17-32) : statistic, adversar, attack, judge, score, hidden, oracle, ground, manipul, gaming, evasion.

## Recalculs (nature : calcul)
- Tableau 35, reecrivain Opus 4.8, consigne stricte : moyenne des cinq relecteurs 0,4626 (tour 1), 0,6236 (tour 2), 0,632 (tour 3) ; standard tour 3 : 0,447.
- Tableau 33, meme ligne : 5,388-4,921 = 0,467 ; 5,541-4,921 = 0,620 ; 5,552-4,921 = 0,631.
- Tableau 8 : (-1,367 + -1,356)/2 = -1,3615 ; texte p. 14 : 6,296 - 4,934 = 1,362.
- Spearman 0,943 sur six contrastes : 1 - 6*2/(6*35) = 0,9429, soit une inversion de deux rangs voisins.
- Tableaux 11 et 16 : chiffres de l'auteur retrouves (0,395 a 0,621 ; 13,0, 12,0, 9,0).

## Controle des citations
- controle_citations_cl.py teste sur test-juste.json (ok, code 0) et test-altere.json (mot change ; mauvaise page : 2 echecs attendus, code 1).
- Mon JSON : 36 citations, 0 echec (controle-citations-sortie-cl.txt).
- JSON de l'auteur par mon script : 64 citations, 0 echec (controle-citations-auteur-par-script-cl.txt).
- guillemets_cl.py : tout extrait anglais entre guillemets de la contre-lecture est une entree exacte du JSON ; les extraits absents sont en francais (termes de la table fermee, textes corriges, reprises du rapport).

## Ouvertures fautives, refus
- Aucune ouverture fautive ; aucun refus ; aucun appel reseau ni de modele ; aucune commande git.
