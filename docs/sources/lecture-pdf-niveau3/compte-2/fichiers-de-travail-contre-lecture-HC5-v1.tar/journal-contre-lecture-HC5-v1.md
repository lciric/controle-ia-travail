# Journal du contre-lecteur HC5 (modèle B) — v1

Début : 2026-11-13 à 23:01:15 UTC (relevé par date -u à la création du dossier de travail, fichier journal-debut.txt). Journal écrit le 2026-11-13 à 23:09:55 UTC (relevé par date -u dans la commande d'écriture).

## Déroulé
1. Consigne commune du compte 2 : empreinte vérifiée cb0623c4aff841a815dc628691f407308acbeeeceb274db96d1f2ba3c8c77ff5 ; lue en entier (41 lignes).
2. Rapport du lecteur : empreinte vérifiée 10b861094910ab7267276e424f0af78811a172157d167e45446baed67823d96b ; lu en entier (238 lignes). Archive du lecteur : empreinte vérifiée 81ca45569045a42de489ab360bb87350e282f79a6d02676b5db703007130b32a ; extraite dans archive-lecteur/ (journal, scripts, sorties, JSON lus).
3. Lignes nommées seulement : programme v2 l. 85-125 et 190-215 ; décision N-005/N-006 l. 76-90 ; décision N-013 l. 56-68 ; état de l'art vérifié du niveau 3 l. 432-448 ; sa contre-lecture l. 536-557. Les interdits communs v2 et l'antériorité du niveau 2, lus par le lecteur, ne sont pas dans mon mandat : non ouverts.
4. Empreintes des deux PDF vérifiées contre leurs compagnons .sha256 (identiques) ; 17 pages chacun (pdfinfo).
5. Extraction page à page par pdftotext dans textes/ (non archivé).
6. Lecture : voir l'étendue ci-dessous. Recherche par mots sur le texte aplati de 2601.04603 (liste des mots dans la contre-lecture, section 3).
7. Script de contrôle des citations écrit sans reprendre celui du lecteur ; testé sur un cas juste (1 citation, 0 échec, code 0) et sur trois cas altérés (mot changé, page fausse, empreinte fausse : 3 échecs, code 1).
8. Les 47 citations du lecteur repassées par mon script : 0 échec.
9. Mes citations : 56 écrites, 56 contrôlées, 0 échec au premier et au dernier passage. Empreinte du JSON : 3ffc365fbf91c39920e8059e0fe1e65a2f92d0762645a775d44be63c83ccc032.
10. Recalculs (nature « calcul ») par python3 -I : intervalles exacts de Poisson par la fonction gamma incomplète régularisée ; tests exacts conditionnels entre systèmes ; droite des moindres carrés et résidus sur le tableau 6 de 2608.11247 ; écarts du tableau 1.
11. Corrections de ma propre rédaction avant scellement : trois numéros de ligne (programme l. 103, N-013 l. 63, N-006 l. 83-85) et le décompte du mot « adaptive ».

## Étendue lue
- 2601.04603v1.pdf : pages 1 à 17 lues ligne à ligne (pdftotext -layout), bibliographie p. 11-13 comprise ; pages 7, 8, 14, 15, 16, 17 vues en image (figures 2, 3, 4, 5, 6).
- 2608.11247v1.pdf : pages 1 à 17 lues ligne à ligne (pdftotext en ordre de lecture pour les pages 1 à 12, -layout pour les pages 13 à 17) ; page 7 vue en image (figure 5, tableaux 2 et 3) ; figures 1 à 4 et 6 à 8 par légende et texte seulement.

## Tenue des interdits
- Aucune commande git, aucun réseau, aucun appel de modèle, aucune recherche récursive dans le dépôt, aucun fichier hors des fichiers nommés, aucun autre PDF.
- Aucun nom de modèle écrit dans les fichiers ; aucune citation contrôlée n'en contient.
- Aucun refus de permission, aucune ouverture fautive.
