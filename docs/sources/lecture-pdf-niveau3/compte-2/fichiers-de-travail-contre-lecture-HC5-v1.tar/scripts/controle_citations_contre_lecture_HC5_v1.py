"""Controle des citations de la contre-lecture HC5 (modele B), ecrit sans reprendre le script du lecteur.
Usage : python3 -I controle_citations_contre_lecture_HC5_v1.py CITATIONS.json PDF [PDF...]
Chaque PDF est donne par son chemin complet (aucun parcours de dossier).
Pour chaque citation : empreinte du PDF, texte de la page par pdftotext avec et sans -layout,
normalisation (NFKC, ligatures, apostrophes, guillemets, tirets, cesures de fin de ligne, espaces),
recherche de la citation. Deux formes du texte sont essayees : cesure recollee (mot coupe) et
cesure gardee (mot compose). Code de sortie 1 au moindre echec."""
import hashlib
import json
import os
import re
import subprocess
import sys
import unicodedata

APOS = "‘’‛′´`"
GUIL = "“”„″«»"
TIRETS = "‐‑‒–—―−"


def base(t):
    t = unicodedata.normalize("NFKC", t)
    t = t.replace("­", "")
    t = t.translate({ord(c): "'" for c in APOS})
    t = t.translate({ord(c): '"' for c in GUIL})
    t = t.translate({ord(c): "-" for c in TIRETS})
    return t


def formes(t):
    t = base(t)
    recolle = re.sub(r"(\w)-[ \t]*\n[ \t]*(\w)", r"\1\2", t)
    garde = re.sub(r"(\w)-[ \t]*\n[ \t]*(\w)", r"\1-\2", t)
    return [re.sub(r"\s+", " ", x).strip() for x in (recolle, garde)]


def texte_page(pdf, page, layout):
    cmd = ["pdftotext"] + (["-layout"] if layout else []) + ["-f", str(page), "-l", str(page), pdf, "-"]
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout


def main():
    citations = json.load(open(sys.argv[1], encoding="utf-8"))
    pdfs = {os.path.basename(p): p for p in sys.argv[2:]}
    empreintes = {n: hashlib.sha256(open(p, "rb").read()).hexdigest() for n, p in pdfs.items()}
    cache = {}
    echecs = 0
    for i, c in enumerate(citations, 1):
        nom = c["pdf"]
        if nom not in pdfs:
            print(f"{i:03d} ECHEC pdf non fourni : {nom}")
            echecs += 1
            continue
        if empreintes[nom] != c["sha256"]:
            print(f"{i:03d} ECHEC empreinte : {nom}")
            echecs += 1
            continue
        cle = (nom, c["page"])
        if cle not in cache:
            cache[cle] = [f for lay in (True, False) for f in formes(texte_page(pdfs[nom], c["page"], lay))]
        cherche = formes(c["citation"])[0]
        ok = any(cherche in f for f in cache[cle])
        if not ok:
            echecs += 1
        print(f"{i:03d} {'OK   ' if ok else 'ECHEC'} {nom} p.{c['page']} : {c['citation'][:80]}")
    print(f"TOTAL : {len(citations)} citations, {echecs} echec(s)")
    sys.exit(1 if echecs else 0)


if __name__ == "__main__":
    main()
