"""Recalculs du contre-lecteur (nature : calcul), bibliotheque standard seulement, lance par python3 -I.
A. 2601.04603v1 : intervalles exacts de Poisson (Garwood) a 95 % par la fonction gamma incomplete
   regularisee (autre voie que celle du lecteur, qui sommait la loi de Poisson), puis tests exacts
   conditionnels (binomiaux) entre systemes, a partir des effectifs imprimes p. 4, 5, 9 et du tableau 1 p. 10.
B. 2608.11247v1 : droite des moindres carres sur les six points << instantanes >> du tableau 6 (p. 13),
   residu de chaque methode, ecart du raisonnement ; ecarts << certain moins nu >> et << raisonne moins nu >>
   du tableau 1 (p. 4)."""
import math


def gamma_p(a, x):
    """Gamma incomplete regularisee inferieure P(a, x), serie puis fraction continue."""
    if x <= 0:
        return 0.0
    lg = math.lgamma(a)
    if x < a + 1:
        terme = 1.0 / a
        somme = terme
        n = a
        for _ in range(100000):
            n += 1
            terme *= x / n
            somme += terme
            if abs(terme) < abs(somme) * 1e-16:
                break
        return somme * math.exp(-x + a * math.log(x) - lg)
    b = x + 1 - a
    c = 1e300
    d = 1 / b
    h = d
    for i in range(1, 100000):
        an = -i * (i - a)
        b += 2
        d = an * d + b
        d = 1e-300 if abs(d) < 1e-300 else d
        c = b + an / c
        c = 1e-300 if abs(c) < 1e-300 else c
        d = 1 / d
        delta = d * c
        h *= delta
        if abs(delta - 1) < 1e-16:
            break
    return 1 - math.exp(-x + a * math.log(x) - lg) * h


def quantile_gamma(a, p):
    bas, haut = 0.0, 1000.0
    for _ in range(300):
        m = (bas + haut) / 2
        if gamma_p(a, m) < p:
            bas = m
        else:
            haut = m
    return (bas + haut) / 2


def garwood(k, niveau=0.95):
    alpha = 1 - niveau
    bas = 0.0 if k == 0 else quantile_gamma(k, alpha / 2)
    haut = quantile_gamma(k + 1, 1 - alpha / 2)
    return bas, haut


def binom_pmf(n, k, p):
    return math.comb(n, k) * p ** k * (1 - p) ** (n - k)


def test_conditionnel(k1, n1, k2, n2):
    """Sous l'egalite des taux, k1 | (k1+k2) suit une binomiale de parametre n1/(n1+n2).
    Rend la valeur p unilaterale (taux 1 plus bas) et bilaterale (somme des issues au plus aussi probables)."""
    n = k1 + k2
    p = n1 / (n1 + n2)
    uni = sum(binom_pmf(n, i, p) for i in range(0, k1 + 1))
    ref = binom_pmf(n, k1, p)
    bi = sum(binom_pmf(n, i, p) for i in range(0, n + 1) if binom_pmf(n, i, p) <= ref * (1 + 1e-12))
    return uni, bi


print("A. 2601.04603v1 - effectifs imprimes (requetes en milliers, arrondies par les auteurs)")
systemes = [("generation precedente (p. 4)", 13, 695), ("classifieur d'echange (p. 4)", 2, 226),
            ("cascade a deux etages (p. 5)", 5, 569), ("production (p. 9)", 1, 198)]
for nom, k, n in systemes:
    b, h = garwood(k)
    print(f"  {nom}: {k}/{n}k = {k / n:.5f} pour mille ; Poisson exact 95 % [{b / n:.5f} ; {h / n:.5f}]"
          f" ; bornes sur le compte [{b:.4f} ; {h:.4f}]")
print("  sensibilite a l'arrondi du denominateur (plus ou moins 0,5 millier), systeme de production :")
for n in (197.5, 198.5):
    b, h = garwood(1)
    print(f"    1/{n}k : taux {1 / n:.5f}, intervalle [{b / n:.5f} ; {h / n:.5f}]")
print("  tests exacts conditionnels (premier systeme suppose plus robuste) :")
paires = [("production contre generation precedente", 1, 198, 13, 695),
          ("production contre classifieur d'echange", 1, 198, 2, 226),
          ("production contre cascade", 1, 198, 5, 569),
          ("production contre les trois autres reunis", 1, 198, 20, 695 + 226 + 569),
          ("classifieur d'echange contre generation precedente", 2, 226, 13, 695),
          ("cascade contre generation precedente", 5, 569, 13, 695),
          ("cascade contre classifieur d'echange", 5, 569, 2, 226),
          ("trois nouveaux reunis contre generation precedente", 8, 226 + 569 + 198, 13, 695)]
for nom, k1, n1, k2, n2 in paires:
    uni, bi = test_conditionnel(k1, n1, k2, n2)
    print(f"    {nom}: {k1}/{n1}k contre {k2}/{n2}k ; rapport des taux {(k1 / n1) / (k2 / n2):.3f} ;"
          f" p unilaterale {uni:.4f} ; p bilaterale {bi:.4f}")
print("  taux imprime 0,00878 (p. 5, tableau 1) contre 5/569 =", f"{5 / 569:.6f}")
print("  taux imprime 0,005 (p. 9) et 0,00505 (tableau 1) contre 1/198 =", f"{1 / 198:.6f}")
print("  part des requetes renvoyees au second etage : 5,5 % (p. 9) ; donc environ 94,5 % jugees par la sonde seule")

print()
print("B. 2608.11247v1 - tableau 6 (p. 13), questions appariees : (resistance, receptivite)")
t6 = {
    "MMLU": {"sans intervention": (74.9, 59.6), "avocat du diable": (76.4, 55.9), "distillation de la question": (80.0, 53.8),
             "persona": (79.4, 50.1), "reflexion": (82.8, 44.3), "ancrage": (79.8, 48.9), "raisonnement": (77.5, 61.8)},
    "GPQA": {"sans intervention": (41.1, 70.0), "avocat du diable": (40.3, 66.3), "distillation de la question": (44.9, 64.6),
             "persona": (49.1, 59.2), "reflexion": (49.4, 54.0), "ancrage": (45.7, 58.8), "raisonnement": (45.8, 60.0)},
    "SimpleQA": {"sans intervention": (17.8, 94.3), "avocat du diable": (17.9, 93.3), "distillation de la question": (19.6, 93.7),
                 "persona": (23.2, 87.9), "reflexion": (27.8, 86.3), "ancrage": (22.9, 88.7), "raisonnement": (23.7, 86.9)},
}
for jeu, pts in t6.items():
    snap = [(rec, res) for nom, (res, rec) in pts.items() if nom != "raisonnement"]
    n = len(snap)
    mx = sum(x for x, _ in snap) / n
    my = sum(y for _, y in snap) / n
    sxx = sum((x - mx) ** 2 for x, _ in snap)
    sxy = sum((x - mx) * (y - my) for x, y in snap)
    syy = sum((y - my) ** 2 for _, y in snap)
    pente = sxy / sxx
    ord0 = my - pente * mx
    r2 = sxy ** 2 / (sxx * syy)
    print(f"  {jeu}: resistance = {ord0:.2f} + ({pente:.3f}) x receptivite ; R2 = {r2:.3f} (imprime p. 6 : 0,88 ; 0,80 ; 0,90)")
    for nom, (res, rec) in pts.items():
        print(f"      residu {nom}: {res - (ord0 + pente * rec):+.2f} point(s)")
print()
print("  tableau 1 (p. 4) : conformite, majorite unanime, selon la forme de l'affirmation")
t1 = {"MMLU": (22.8, 18.6, 24.9), "GPQA": (54.8, 48.2, 54.9), "SimpleQA": (71.0, 58.3, 74.2)}
for jeu, (nu, certain, raisonne) in t1.items():
    print(f"    {jeu}: nu {nu} ; certain {certain} (certain moins nu {certain - nu:+.1f}) ;"
          f" raisonne {raisonne} (raisonne moins nu {raisonne - nu:+.1f})")
print("  tableau 2 (p. 7), distillation de la question : rapport perte de receptivite / gain de resistance")
for jeu, (dres, drec) in {"MMLU": (5.1, -5.8), "GPQA": (3.9, -5.4), "SimpleQA": (1.8, -0.5)}.items():
    print(f"    {jeu}: {dres:+.1f} / {drec:+.1f} ; rapport {abs(drec) / dres:.2f}")
print("  tableau 2 (p. 7), reflexion :")
for jeu, (dres, drec) in {"MMLU": (7.9, -15.3), "GPQA": (8.3, -16.0), "SimpleQA": (10.0, -8.0)}.items():
    print(f"    {jeu}: {dres:+.1f} / {drec:+.1f} ; rapport {abs(drec) / dres:.2f}")
