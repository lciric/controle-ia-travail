#!/usr/bin/env python3
"""Contrôle des citations de la contre-lecture Tr (v1).

Usage : python3 -I verifier_citations_contre_lecture_Tr_v1.py CITATIONS.json DOSSIER_PDF [DOSSIER_PDF ...]
Pour chaque citation {pdf, sha256, page, citation} : vérifie l'empreinte du PDF, extrait la page par
pdftotext (avec et sans -layout) et cherche la citation après normalisation (espaces, ligatures,
césures de fin de ligne, apostrophes, guillemets, tirets). Code de sortie 0 si zéro échec, 1 sinon.
"""
import hashlib
import json
import os
import re
import subprocess
import sys
import unicodedata

LIGATURES = {"ﬀ": "ff", "ﬁ": "fi", "ﬂ": "fl", "ﬃ": "ffi", "ﬄ": "ffl"}
APOSTROPHES = "’‘ʼ`´"
GUILLEMETS = "“”«»„"
TIRETS = "‐‑‒–—−"


def normaliser(texte):
    for k, v in LIGATURES.items():
        texte = texte.replace(k, v)
    texte = unicodedata.normalize("NFKC", texte)
    for c in APOSTROPHES:
        texte = texte.replace(c, "'")
    for c in GUILLEMETS:
        texte = texte.replace(c, '"')
    for c in TIRETS:
        texte = texte.replace(c, "-")
    texte = texte.replace(" ", " ").replace("\f", " ")
    return re.sub(r"\s+", " ", texte).strip()


def variantes(brut):
    """Texte tel quel ; césure de fin de ligne supprimée ; césure gardée comme trait d'union."""
    brut = brut.replace("­", "")
    return {
        normaliser(brut),
        normaliser(re.sub(r"-\s*\n\s*", "", brut)),
        normaliser(re.sub(r"-\s*\n\s*", "-", brut)),
    }


def texte_page(chemin, page, layout):
    cmd = ["pdftotext"] + (["-layout"] if layout else []) + ["-f", str(page), "-l", str(page), chemin, "-"]
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout


def trouver(nom, dossiers):
    for d in dossiers:
        c = os.path.join(d, nom)
        if os.path.isfile(c):
            return c
    return None


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 2
    citations = json.load(open(sys.argv[1], encoding="utf-8"))
    dossiers = sys.argv[2:]
    echecs = 0
    empreintes = {}
    for i, c in enumerate(citations):
        chemin = trouver(c["pdf"], dossiers)
        if chemin is None:
            print(f"ECHEC {i} {c['pdf']} : fichier introuvable")
            echecs += 1
            continue
        if chemin not in empreintes:
            empreintes[chemin] = hashlib.sha256(open(chemin, "rb").read()).hexdigest()
        if empreintes[chemin] != c["sha256"]:
            print(f"ECHEC {i} {c['pdf']} p.{c['page']} : empreinte différente")
            echecs += 1
            continue
        cible = normaliser(c["citation"])
        ok = False
        for layout in (True, False):
            if any(cible in v for v in variantes(texte_page(chemin, c["page"], layout))):
                ok = True
                break
        print(f"{'OK   ' if ok else 'ECHEC'} {i} {c['pdf']} p.{c['page']} : {c['citation'][:70]}")
        echecs += 0 if ok else 1
    print(f"citations : {len(citations)} ; échecs : {echecs}")
    return 0 if echecs == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
