# Journal du lecteur — mandat Tr — modèle A

Journal écrit à 2026-11-13T23:10:46Z (heure relevée par date -u dans la commande d'écriture). Heures des étapes : relevées par date -u au fil des commandes.

- 2026-11-13T23:05:59Z : consigne commune lue en entier ; empreinte vérifiée (cb0623c4…7ff5, conforme). Interdits communs v2 lus (plus stricts sur la recherche récursive ; tenus). Aucune commande git, aucun réseau, aucun appel de modèle.
- Lecture des fichiers nommés, lignes indiquées seulement : programme v2 l. 85-125 et 180-200 ; anteriorite-v1 l. 130-151 ; état de l'art niveau 3 l. 183-191 ; contre-lecture l. 442-471.
- 2026-11-13T23:06:09Z : empreintes des trois PDF vérifiées contre leurs compagnons .sha256 : conformes.
- 2601.04603v1 (17 p.) : p. 1 à 17 lues ligne à ligne par pdftotext -layout ; pages de références (11-13) parcourues par mots ; figures p. 7 et p. 16 lues sur l'image (outil Read). Écart relevé entre l'échelle de la figure 2 (p. 7, environ 1,4 % pour la meilleure sonde) et celle de la figure 5 (p. 16, environ 0,01 à 0,06), pour « les mêmes données d'évaluation ».
- 2603.04069v1 (14 p.) : p. 1 à 14 lues ligne à ligne ; références (p. 9-10) parcourues par mots ; figures rendues en texte (p. 5, 6, 7, 12, 13, 14) lues par leurs légendes et axes ; figures 5 à 7 (p. 10-11) par légendes seulement.
- 2609.19101v2 (39 p.) : p. 1 à 18 lues ligne à ligne ; p. 19 à 24 (références) parcourues par mots ; p. 25 à 39 (annexes : définition, données synthétiques, grilles des juges, exemples) lues ligne à ligne ; figure 7 (p. 9) lue sur l'image. Recherche par mots sur les 39 pages (agrégation, mise en commun, maximum, pic, moyenne, fenêtre, adversaire, attaque, évasion, obfuscation, adaptatif, robuste, grain du passage) : aucun attaquant, aucune comparaison d'agrégations au grain du passage ; la seule « mise en commun » (p. 7, tableau 3 p. 26) porte sur les jeux de données synthétiques, pas sur les scores.
- 2026-11-13T23:09:47Z : script de contrôle testé : cas juste OK (code 0) ; trois cas altérés (texte changé, page fausse, empreinte fausse) en échec (code 1), comme attendu.
- 2026-11-13T23:10:07Z : 49 citations contrôlées, 0 échec.
- 2026-11-13T23:10:32Z : trois citations contenant des noms de modèles remplacées par des citations sans nom (consigne, ligne 14) ; nouveau contrôle : 49 citations, 0 échec.
- Aucun refus de permission, aucune ouverture fautive.
