# Journal du lecteur — HC1, pièce 2607.00415 v1 (modèle A)

Heures relevées par `date -u` : début 2026-11-13 22:52:33 UTC ; contrôle des citations terminé 22:57:16 UTC ; relevé 22:58:21 UTC avant rédaction. L'heure de fin figure en tête du rapport.

## Étapes
1. Consigne commune `consigne-lecteur-compte-2-v1.md` : empreinte vérifiée, `cb0623c4aff841a815dc628691f407308acbeeeceb274db96d1f2ba3c8c77ff5`, conforme ; lue en entier (41 lignes).
2. Interdits communs v2 (`docs/notes/g0-deux-semaines-v1/consignes-mere-2026-11-10-0500-v1/interdits-communs-v2.md`) lus en entier ; tenus avec la consigne (la plus stricte prime).
3. Fichiers du mandat lus aux lignes indiquées seulement (voir rapport, en-tête).
4. PDF : empreinte du compagnon `.sha256` = empreinte calculée = `dab3b21c3c3e62ac99854fa3a176b82d2d603ccf9244f1a81e03294516b17ec6` ; 15 pages (pdfinfo).
5. Extraction page par page, `pdftotext -layout` et sans `-layout` (dossier `textes/`, hors archive).
6. Lecture ligne à ligne du texte des pages 1 à 15 (toutes).
7. Figures vues en image (outil Read sur le PDF, pages 2-4, 8-11, 14) ; rendus à 220 ou 300 points par pouce et recadrés (pages 2, 3, 4, 11, 12, 13) pour les figures 2, 4, 5, 6, 13, 14, 15, 16, 17, 18 ; figure 19 vue sur la page 14.
8. Script de contrôle des citations écrit, testé sur un cas juste (réussite), un cas altéré (échec attendu, obtenu) et une page fausse (échec attendu, obtenu) : `test-cas.json`.
9. Premier passage : 57 citations, 1 échec (n° 32, phrase coupée par une formule sur la page 4 : `sortie-controle-v1.txt`). Citation raccourcie à la partie hors formule ; second passage : 57 citations, 0 échec (`sortie-controle-v2.txt`).
10. Calculs (`scripts/calculs.py`, `sortie-calculs-v1.txt`) : taux de bascule par persona et par modèle à partir des effectifs lus dans les titres des panneaux des figures 13 à 15 ; cohérence des figures 2 et 6.

## Étendue réellement lue
- Pages 1 à 15 : texte lu ligne à ligne (corps, annexes A.1 à A.5, bibliographie, légendes).
- Figures lues en image : 1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12 (basse résolution pour 10 à 12, effectifs lus avec réserve), 13, 14, 15 (haute résolution), 16, 17, 18, 19, 20, 21.
- Rien d'autre : aucun autre PDF ouvert ; aucun voisin ouvert.

## Lectures de figures (nature « figure », non contrôlées par programme)
- Fig. 4 (p. 3, Gemma, médecin, questions basculées n = 1287) : les sondes « indice » (régression logistique et perceptron multicouche) ne dépassent jamais environ 0,4 à aucune couche ; ce sont les sondes de base qui montent au-dessus de 0,9. Le texte « drop sharply from above 0.9 to near zero » décrit mal la figure.
- Fig. 13 (p. 11, Gemma) : après la couche 28, sondes « indice » sur les basculées ≈ 0,05 (médecin), ≈ 0,15-0,25 (chef résident), ≈ 0,3-0,4 (3e année), ≈ 0,4-0,5 (1re année) ; sondes de base sur les mêmes sous-ensembles ≈ 0,92 / 0,8 / 0,7 / 0,62.
- Fig. 14 (p. 12, Llama) : après la couche 17, basculées : ≈ 0,05 (médecin), ≈ 0,6-0,7 (chef résident), ≈ 0,6-0,65 (3e année), ≈ 0,8-0,85 (1re année, contre ≈ 0,8-0,85 pour la base du sous-ensemble) ; résistées sous le médecin : ≈ 0,7 (contre ≈ 0,98 pour la base), et non « near-perfect ».
- Fig. 15 (p. 13, Qwen) : basculées, toutes personas : pic ≈ 0,65-0,8 aux couches 24-25, puis chute sous le hasard après la couche 29 (≈ 0,07 médecin ; ≈ 0,15-0,25 pour les trois autres).
- Fig. 2 (p. 2) : exactitudes ≈ 15 / 29 / 34 % sous le médecin (Llama / Qwen / Gemma), ≈ 49 / 47 / 54 % chef résident, ≈ 49 / 54 / 58 % 3e année, ≈ 60 / 57 / 61 % 1re année ; lignes de base ≈ 63 / 60 / 58 %.
- Fig. 6 (p. 4) : ligne « Physician accuracy » ≈ 56 / 48 / 23 % (Gemma / Qwen / Llama).
- Fig. 18 (p. 13) : médecin – 1re année ≈ 0,54 à la couche 28 pour Gemma (le texte dit 0,57).
- Fig. 19 (p. 14) : analyse en composantes principales sur quatre points ; Gemma, ordre sur la première composante : médecin (≈ −32), chef résident (≈ 0), 3e année (≈ 12), 1re année (≈ 19) ; le chef résident n'est pas « à l'extrémité opposée » avec les étudiants.

## Incidents
- Aucun refus de permission. Aucune ouverture fautive. Aucune commande git, aucun réseau, aucun appel de modèle.
