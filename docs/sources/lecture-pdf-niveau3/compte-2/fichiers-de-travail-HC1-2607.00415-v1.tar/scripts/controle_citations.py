"""Controle des citations : chaque citation doit figurer dans le texte de sa page
extrait par pdftotext (avec et sans -layout), apres normalisation.
Usage : python3 -I controle_citations.py FICHIER_JSON DOSSIER_PDF
Sortie : une ligne par citation, puis le bilan ; code de retour 1 si un echec."""
import json, sys, subprocess, unicodedata, re, hashlib, os

TIRETS = "-‐‑‒–—―−­"
def norm_base(s):
    s = unicodedata.normalize("NFKC", s)  # ligatures (fi, fl), exposants
    for a in "‘’‚‛′`´":
        s = s.replace(a, "'")
    for a in "“”„‟″":
        s = s.replace(a, '"')
    return s
def norm_espaces(s):
    s = norm_base(s)
    s = re.sub(r"(\w)[" + re.escape(TIRETS) + r"]\s*\n\s*(\w)", r"\1\2", s)  # cesure
    return re.sub(r"\s+", " ", s).strip().lower()
def norm_dur(s):
    s = norm_base(s)
    s = re.sub(r"[\s" + re.escape(TIRETS) + r"]+", "", s)
    return s.lower()

def texte(pdf, page, layout):
    cmd = ["pdftotext"] + (["-layout"] if layout else []) + ["-f", str(page), "-l", str(page), pdf, "-"]
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout

def main():
    cits = json.load(open(sys.argv[1], encoding="utf-8"))
    dossier = sys.argv[2]
    cache, echecs, empr = {}, 0, {}
    for i, c in enumerate(cits, 1):
        pdf = os.path.join(dossier, c["pdf"])
        if pdf not in empr:
            empr[pdf] = hashlib.sha256(open(pdf, "rb").read()).hexdigest()
        ok_empr = empr[pdf] == c["sha256"]
        modes = []
        for layout in (False, True):
            k = (pdf, c["page"], layout)
            if k not in cache:
                cache[k] = texte(pdf, c["page"], layout)
            t = cache[k]
            nom = "layout" if layout else "brut"
            if norm_espaces(c["citation"]) in norm_espaces(t):
                modes.append(nom + ":espaces")
            elif norm_dur(c["citation"]) in norm_dur(t):
                modes.append(nom + ":sans-espaces-ni-tirets")
        ok = ok_empr and bool(modes)
        echecs += (not ok)
        print(f"{i:3d} p.{c['page']:>2} {'OK ' if ok else 'ECHEC'} {','.join(modes) or '-'} empreinte={'ok' if ok_empr else 'FAUSSE'} | {c['citation'][:70]}")
    print(f"BILAN : {len(cits)} citations, {echecs} echec(s)")
    sys.exit(1 if echecs else 0)

if __name__ == "__main__":
    main()
