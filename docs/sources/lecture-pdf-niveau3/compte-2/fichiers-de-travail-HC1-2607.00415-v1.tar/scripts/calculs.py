# Effectifs lus sur les figures 13 (Gemma), 14 (Llama), 15 (Qwen), titres des panneaux : (bascules, resistances)
F = {
 "Gemma-2-9B (fig. 13, p. 11)": {"Medecin": (1287, 1635), "Chef resident": (291, 2631), "Etudiant 3e annee": (117, 2805), "Etudiant 1re annee": (68, 2854)},
 "Llama-3.1-8B (fig. 14, p. 12)": {"Medecin": (2412, 730), "Chef resident": (744, 2398), "Etudiant 3e annee": (738, 2404), "Etudiant 1re annee": (270, 2872)},
 "Qwen3-8B (fig. 15, p. 13)": {"Medecin": (1577, 1431), "Chef resident": (728, 2280), "Etudiant 3e annee": (406, 2602), "Etudiant 1re annee": (265, 2743)},
}
for m, d in F.items():
    tot = {a + b for a, b in d.values()}
    print(m, "total des questions correctes sans indice, par persona :", sorted(tot))
    for p, (a, b) in d.items():
        print(f"   {p:20s} bascules {a:5d} / {a+b}  = {100*a/(a+b):5.1f} %   exactitude restante {100*b/(a+b):5.1f} %")
# Figure 2 (p. 2) lue : exactitude Gemma sous Medecin ~34 %, ligne de base ~58 % ; rapport
print("Gemma : 34/58 =", round(34/58, 3), "contre 1635/2922 =", round(1635/2922, 3))
print("Gemma : 34/0.56 -> base implicite =", round(34/(1635/2922), 1), "%")
