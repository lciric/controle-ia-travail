"""Verifie que chaque passage anglais entre guillemets du rapport figure dans le JSON des citations."""
import json, re, sys, unicodedata
def n(t):
    t = unicodedata.normalize("NFKC", t).replace("’", "'").replace(" ", " ")
    return re.sub(r"\s+", " ", t).strip()
rap = open(sys.argv[1], encoding="utf-8").read()
cits = [n(c["citation"]) for c in json.load(open(sys.argv[2], encoding="utf-8"))]
manque = 0
for q in re.findall(r"«\s*([^»]+?)\s*»", rap):
    q2 = n(q)
    if not re.search(r"\b(the|of|and|we|is|to|on|in|our|a)\b", q2):   # passage francais : ignore
        continue
    morceaux = [m.strip(" .") for m in re.split(r"\[…\]|…", q2) if m.strip(" .")]
    for m in morceaux:
        if not any(m in c for c in cits):
            manque += 1; print("NON COUVERT :", m)
print("passages non couverts :", manque)
