"""Controle des citations du mandat HC5 (lecteur, modele A).
Usage : python3 -I controle_citations_HC5_v1.py CITATIONS.json DOSSIER_PDF [DOSSIER_PDF...]
Pour chaque citation : verifie l'empreinte du PDF, extrait la page par pdftotext
(avec et sans -layout), normalise (ligatures, apostrophes, tirets, cesures, espaces)
et cherche la citation. Code de sortie 1 si un echec."""
import hashlib, json, os, re, subprocess, sys, unicodedata

def norm(t):
    t = unicodedata.normalize("NFKC", t)
    for a in "‘’‛′´`":
        t = t.replace(a, "'")
    for a in "“”„″":
        t = t.replace(a, '"')
    for a in "‐‑‒–—―−":
        t = t.replace(a, "-")
    t = t.replace("­", "")
    t = re.sub(r"-\s*\n\s*", "-", t)          # cesure en fin de ligne (tiret garde)
    t = re.sub(r"\s+", " ", t)
    return t.strip()

def lache(t):
    return re.sub(r"[\s\-]", "", norm(t))

def page_textes(pdf, page):
    out = []
    for opts in (["-layout"], []):
        r = subprocess.run(["pdftotext", *opts, "-f", str(page), "-l", str(page), pdf, "-"],
                           capture_output=True, text=True, check=True)
        out.append(r.stdout)
    return out

def trouver_pdf(nom, dossiers):
    for d in dossiers:                      # dossiers nommes, aucun parcours recursif
        chemin = os.path.join(d, nom)
        if os.path.isfile(chemin):
            return chemin
    return None

def main():
    cits = json.load(open(sys.argv[1], encoding="utf-8"))
    dossiers = sys.argv[2:]
    echecs = 0; empreintes = {}
    for i, c in enumerate(cits):
        pdf = trouver_pdf(c["pdf"], dossiers)
        if pdf is None:
            print(f"[{i}] ECHEC pdf introuvable {c['pdf']}"); echecs += 1; continue
        if pdf not in empreintes:
            empreintes[pdf] = hashlib.sha256(open(pdf, "rb").read()).hexdigest()
        if empreintes[pdf] != c["sha256"]:
            print(f"[{i}] ECHEC empreinte {c['pdf']}"); echecs += 1; continue
        textes = page_textes(pdf, c["page"])
        strict = any(norm(c["citation"]) in norm(t) for t in textes)
        souple = any(lache(c["citation"]) in lache(t) for t in textes)
        etat = "OK-strict" if strict else ("OK-souple" if souple else "ECHEC")
        if etat == "ECHEC":
            echecs += 1
        print(f"[{i}] {etat} {c['pdf']} p.{c['page']} : {c['citation'][:70]}")
    print(f"TOTAL {len(cits)} citations, {echecs} echec(s)")
    sys.exit(1 if echecs else 0)

if __name__ == "__main__":
    main()
