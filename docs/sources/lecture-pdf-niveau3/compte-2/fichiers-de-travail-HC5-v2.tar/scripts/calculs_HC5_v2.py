"""Recalculs de la version 2 (nature : calcul), bibliotheque standard seulement.
1) Tests exacts conditionnels entre systemes de 2601.04603v1 (effectifs imprimes p. 4, 5, 9, tableau 1 p. 10).
2) Droite des moindres carres sur les six points instantanes du tableau 6 (p. 13) de 2608.11247v1,
   R2, et ecart vertical de chaque methode a la droite (Resistance observee - predite).
3) Ecarts de deplacement selon la forme de l'affirmation (tableau 1, p. 4, 2608.11247v1)."""
import math

def binom_cdf(k, n, p):
    return sum(math.comb(n, i) * p**i * (1 - p)**(n - i) for i in range(k + 1))

def test_conditionnel(k1, t1, k2, t2):
    """H0 : meme taux. Sous H0, k1 | k1+k2 suit Binomiale(n, t1/(t1+t2)). p unilaterale : P(X <= k1)."""
    n, p = k1 + k2, t1 / (t1 + t2)
    uni = binom_cdf(k1, n, p)
    # bilaterale : somme des probabilites <= proba observee
    probs = [math.comb(n, i) * p**i * (1 - p)**(n - i) for i in range(n + 1)]
    bil = sum(q for q in probs if q <= probs[k1] * (1 + 1e-9))
    return uni, bil

S = {"gen_prec": (13, 695), "echange": (2, 226), "cascade": (5, 569), "production": (1, 198)}
print("== 1) tests exacts conditionnels (p unilaterale : premier systeme moins vulnerable)")
for a, b in [("production", "gen_prec"), ("production", "cascade"), ("production", "echange"),
             ("cascade", "gen_prec"), ("echange", "gen_prec")]:
    u, bl = test_conditionnel(*S[a], *S[b])
    print(f"{a} contre {b}: rapport des taux {(S[a][0]/S[a][1])/(S[b][0]/S[b][1]):.3f} ; p uni {u:.3f} ; p bil {bl:.3f}")
k3 = S["echange"][0] + S["cascade"][0] + S["production"][0]; t3 = S["echange"][1] + S["cascade"][1] + S["production"][1]
u, bl = test_conditionnel(k3, t3, *S["gen_prec"])
print(f"trois nouveaux reunis ({k3}/{t3}k) contre gen_prec: p uni {u:.3f} ; p bil {bl:.3f}")

print("== 2) frontiere (tableau 6, questions appariees) : (Res, Rec)")
T6 = {"MMLU": {"aucune": (74.9, 59.6), "avocat": (76.4, 55.9), "distillation": (80.0, 53.8), "persona": (79.4, 50.1),
               "reflexion": (82.8, 44.3), "ancree": (79.8, 48.9), "raisonnement": (77.5, 61.8)},
      "GPQA": {"aucune": (41.1, 70.0), "avocat": (40.3, 66.3), "distillation": (44.9, 64.6), "persona": (49.1, 59.2),
               "reflexion": (49.4, 54.0), "ancree": (45.7, 58.8), "raisonnement": (45.8, 60.0)},
      "SimpleQA": {"aucune": (17.8, 94.3), "avocat": (17.9, 93.3), "distillation": (19.6, 93.7), "persona": (23.2, 87.9),
                   "reflexion": (27.8, 86.3), "ancree": (22.9, 88.7), "raisonnement": (23.7, 86.9)}}
for jeu, d in T6.items():
    pts = [v for k, v in d.items() if k != "raisonnement"]
    xs = [r for _, r in pts]; ys = [s for s, _ in pts]
    mx, my = sum(xs)/6, sum(ys)/6
    b = sum((x-mx)*(y-my) for x, y in zip(xs, ys)) / sum((x-mx)**2 for x in xs); a = my - b*mx
    ssr = sum((y-(a+b*x))**2 for x, y in zip(xs, ys)); sst = sum((y-my)**2 for y in ys)
    ecarts = {k: round(s - (a + b*r), 2) for k, (s, r) in d.items()}
    print(f"{jeu}: pente {b:.3f} ; R2 {1-ssr/sst:.3f} ; ecarts {ecarts}")

print("== 3) tableau 1 : certaine - nue ; raisonnee - nue (points)")
T1 = {"MMLU": (22.8, 18.6, 24.9), "GPQA": (54.8, 48.2, 54.9), "SimpleQA": (71.0, 58.3, 74.2)}
for jeu, (nue, cert, rais) in T1.items():
    print(f"{jeu}: certaine-nue {cert-nue:+.1f} ; raisonnee-nue {rais-nue:+.1f}")
print("== 4) part du trafic non escaladee (p. 9 : 5,5 % escalade) :", f"{100-5.5:.1f} %")
