# Journal du lecteur HC5 (modèle A) — v2

Écrit le 2026-11-13 à 23:16:16 UTC (relevé par date -u dans la commande d'écriture). Les heures d'étape ci-dessous sont celles que date -u a imprimées à la fin de la commande de chaque étape.

## Étapes
- 23:11:25 UTC : empreintes vérifiées (contre-lecture `e241a0e0…`, archive de contre-lecture `e2fa704c…`, rapport v1 `10b86109…`) ; archive extraite dans `contre-lecture-v1-extrait/` (dossier neuf) ; contre-lecture lue en entier.
- Entre 23:11:25 et 23:12:48 UTC : figures vues en image par l'outil Read (pages) :
  - 2601.04603 : p. 14 (figure 4), p. 16 (figure 5), p. 17 (figure 6) ; les p. 7-8 (figures 2, 3) avaient été vues en version 1 ;
  - 2608.11247 : p. 2 (figure 1), p. 5 (figures 2, 3), p. 6 (figure 4), p. 7 (figure 5, tableaux 2 et 3), p. 15 (figure 7, tableaux 11 et 12), p. 16 (figure 8).
  - Toutes les figures des deux articles sont désormais vues en image.
- 23:12:48 UTC : `calculs_HC5_v2.py` (tests exacts conditionnels ; droite du tableau 6 et écarts par méthode ; écarts du tableau 1).
- Rédaction du rapport v2 (corps), puis citations : 77 citations, 0 échec ; deux citations inutiles retirées ; une citation composée ajoutée ; contrôle final à 23:15:46 UTC : 76 citations, 0 échec ; couverture des passages cités : 0 manquant.

## Décisions sur les constats (détail au rapport, section 9)
A à I : « corrigé ». Pour F, correction avec une nuance propre : l'effet de la certitude (moins de déplacement) a un pendant de sens opposé (une raison d'une ligne déplace un peu plus).

## Ouvertures
Aucun autre PDF ; aucun fichier hors des fichiers nommés ; aucune commande git ; aucun réseau ; aucun appel de modèle ; aucun refus rencontré.
