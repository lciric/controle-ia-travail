"""Liste les passages entre guillemets du rapport du lecteur, pour les confronter au JSON du lecteur."""
import json, re, sys, unicodedata
rapport = open(sys.argv[1], encoding="utf-8").read()
cits = json.load(open(sys.argv[2], encoding="utf-8"))
def n(t):
    t = unicodedata.normalize("NFKC", t)
    for a, b in (("’", "'"), ("‘", "'"), ("“", '"'), ("”", '"'), ("–", "-"), ("—", "-")):
        t = t.replace(a, b)
    return re.sub(r"\s+", " ", t).strip()
base = [n(c["citation"]) for c in cits]
for num, ligne in enumerate(rapport.split("\n"), 1):
    for m in re.finditer(r"«\s*([^»]+?)\s*»", ligne):
        q = n(m.group(1))
        dans = any(q in b for b in base)
        print("%s l.%d | %s" % ("JSON " if dans else "HORS ", num, q))
