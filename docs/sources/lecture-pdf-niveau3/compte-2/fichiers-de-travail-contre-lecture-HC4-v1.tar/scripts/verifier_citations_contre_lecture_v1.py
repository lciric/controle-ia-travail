"""Contrôle des citations de la contre-lecture HC4 (contre-lecteur, compte 2, modèle B).

Usage : python3 -I verifier_citations_contre_lecture_v1.py CITATIONS.json DOSSIER_PDF
Chaque citation {pdf, sha256, page, citation} : empreinte du PDF vérifiée, page extraite
par pdftotext avec et sans -layout, normalisation (NFKC, ligatures, apostrophes,
guillemets, tirets, césures de fin de ligne, espaces), recherche de la citation.
Code de sortie 0 si zéro échec, 1 sinon. Écrit de façon indépendante du script du lecteur.
"""
import hashlib
import json
import re
import subprocess
import sys
import unicodedata

REMPLACEMENTS = [
    ("’", "'"), ("‘", "'"), ("“", '"'), ("”", '"'),
    ("«", '"'), ("»", '"'), ("–", "-"), ("—", "-"),
    ("−", "-"), ("‐", "-"), ("‑", "-"), (" ", " "),
    ("ﬁ", "fi"), ("ﬂ", "fl"), ("ﬀ", "ff"), ("ﬃ", "ffi"), ("ﬄ", "ffl"),
]


def normaliser(texte):
    texte = unicodedata.normalize("NFKC", texte)
    for ancien, nouveau in REMPLACEMENTS:
        texte = texte.replace(ancien, nouveau)
    texte = re.sub(r"(\w)-\s*\n\s*(\w)", r"\1\2", texte)
    return re.sub(r"\s+", " ", texte).strip()


def texte_page(pdf, page, layout):
    commande = ["pdftotext"]
    if layout:
        commande.append("-layout")
    commande += ["-f", str(page), "-l", str(page), pdf, "-"]
    return subprocess.run(commande, capture_output=True, check=True).stdout.decode("utf-8", "replace")


def empreinte(chemin):
    h = hashlib.sha256()
    with open(chemin, "rb") as f:
        for bloc in iter(lambda: f.read(1 << 20), b""):
            h.update(bloc)
    return h.hexdigest()


def principal():
    citations = json.load(open(sys.argv[1], encoding="utf-8"))
    dossier = sys.argv[2].rstrip("/")
    empreintes, pages, echecs = {}, {}, 0
    for i, c in enumerate(citations):
        chemin = dossier + "/" + c["pdf"]
        if chemin not in empreintes:
            empreintes[chemin] = empreinte(chemin)
        cle = (chemin, c["page"])
        if cle not in pages:
            pages[cle] = [normaliser(texte_page(chemin, c["page"], lay)) for lay in (True, False)]
        cible = normaliser(c["citation"])
        ok_sha = empreintes[chemin] == c["sha256"]
        ok_txt = bool(cible) and any(cible in t for t in pages[cle])
        if not (ok_sha and ok_txt):
            echecs += 1
        print("%03d %s %s p.%d sha=%s :: %s" % (
            i, "OK" if (ok_sha and ok_txt) else "ECHEC", c["pdf"], c["page"],
            "ok" if ok_sha else "FAUX", c["citation"][:80]))
    print("TOTAL %d citations, %d echec(s)" % (len(citations), echecs))
    sys.exit(1 if echecs else 0)


if __name__ == "__main__":
    principal()
