"""Cherche, dans les textes extraits (dossier de travail), les pages où figure une chaîne normalisée."""
import glob, os, re, sys, unicodedata
def n(t):
    t = unicodedata.normalize("NFKC", t)
    for a, b in (("’", "'"), ("‘", "'"), ("“", '"'), ("”", '"'), ("–", "-"), ("—", "-"), ("−", "-"),
                 ("ﬁ", "fi"), ("ﬂ", "fl"), ("ﬀ", "ff"), ("ﬃ", "ffi")):
        t = t.replace(a, b)
    t = re.sub(r"(\w)-\s*\n\s*(\w)", r"\1\2", t)
    return re.sub(r"\s+", " ", t).strip()
dossier, prefixe = sys.argv[1], sys.argv[2]
for q in sys.argv[3:]:
    pages = set()
    for f in glob.glob(os.path.join(dossier, prefixe + "-p*-*.txt")):
        if n(q) in n(open(f, encoding="utf-8", errors="replace").read()):
            pages.add(int(re.search(r"-p(\d+)-", os.path.basename(f)).group(1)))
    print(sorted(pages), "|", q)
