# Journal du contre-lecteur — HC4, compte 2 (modèle B)

Début : 2026-11-13 23:36:11 UTC (relevé par date -u au début du travail). Journal écrit le 2026-11-13 23:45:47 UTC (date -u).

## Consigne, objet, interdits
- Consigne commune lue en entier, empreinte conforme (cb0623c4…77ff5). interdits-communs-v2.md non ouvert : il n'est pas nommé dans mon mandat.
- Rapport (dceefa6a…886c) et archive du lecteur (d5c79196…4c1b) : empreintes conformes. Archive extraite dans archive-lecteur/ (non reprise dans mon archive).
- Fichiers du dépôt lus aux lignes du mandat seulement (programme v2 l. 85-125 et 190-215 ; N-013 l. 46-55 ; N-068 l. 1-115 ; état de l'art de niveau 3 l. 412-431 ; sa contre-lecture l. 509-535 et 696-726). Lignes relues une seconde fois pour contrôle de numéros : programme l. 101-106 et 193-195, N-013 l. 48, état de l'art l. 419-422 (toutes dans les plages).
- Aucune commande git, aucun réseau, aucun appel de modèle, aucun refus. Un ls du dossier des pièces a affiché les noms des autres fichiers du lot 11 ; aucun ouvert.

## Empreintes des PDF (conformes aux compagnons .sha256)
- 2601.04603v1.pdf ba8ec6570a41c42554ac89b9869020a2356cead5bdcf2618fc9c6208a89afdb5 (17 p.)
- 2309.10253v4.pdf f2b76387acd042a27db07e8093dc4f4f4b876eb28d6a16fcf886432b31f1ffac (26 p.)
- 2310.08419v4.pdf 590bf40aa58061928f54d01b7d53f0d5141bb2ecf4f01483c6849423934f44e4 (34 p.)
- 2502.19537v5.pdf 4f991dbe01b2c853189b45e1b36906bf355a367550f96703cf320b6e9f291d3c (37 p.)

## Étendue relue
- 2601.04603v1 : p. 1-10 et 14-17 ligne à ligne (pdftotext -layout) ; p. 11-13 par mots ; p. 7, 8, 14, 15, 16 vues sur l'image (figures 2, 3, 4, 5).
- 2309.10253v4 : p. 9-14 ligne à ligne ; reste par mots ; figures non revues sur l'image.
- 2310.08419v4 : p. 1-9, 14, 15 ligne à ligne ; p. 4 vue sur l'image (tableau 1) ; reste par mots.
- 2502.19537v5 : p. 1, 2, 5-9, 21, 36, 37 ligne à ligne ; p. 4 en partie ; reste par mots.
- Balayage par mots des quatre PDF, toutes pages (texte sans -layout) : probe, activation, internal, gradient, white-box, adaptive, detector, moderation, obfuscat, monitor.

## Contrôles par programme
- scripts/verifier_citations_contre_lecture_v1.py (python3 -I) : essai juste (1 citation, 0 échec, code 0) ; essai altéré (texte du rapport « with substantial… », page 9 au lieu de 5, empreinte fausse : 3 échecs, code 1) ; fichiers dans essais/.
- Contrôle final : 49 citations, 0 échec (controle-citations-final-contre-lecture-v1.txt). Mêmes 49 citations passées au script du lecteur : 0 échec. Les 79 citations du lecteur passées à mon script : 0 échec.
- scripts/extraire_guillemets_rapport_v1.py : guillemets du rapport du lecteur confrontés à son JSON (une citation inexacte, ligne A3) ; guillemets de ma contre-lecture confrontés à mon JSON (guillemets-contre-lecture-v1.txt).
- scripts/chercher_pages_v1.py : localisation des extraits par page. La phrase « this required substantial effort and automated tools » est à la p. 5 (note 3), pas à la p. 9.

## Calculs (nature « calcul »)
- 2601.04603 : 0,01871/0,00885 = 2,11 ; (100 + 15)/2 = 57,5 ; 0,014 x 7 000 = 98 ; 0,011 x 7 000 = 77 (hypothèse : dénominateur = jeu entier, non imprimée).
- 2310.08419 : 5 120/20 = 256 ; 256 000/20 = 12 800 ; 256 000/5 120 = 50 ; requêtes attendues par succès, échecs comptés à 90 requêtes : ((1 - s) x 90 + s x q)/s = 22,3 (Vicuna) ; 2 216 (Llama-2) ; 119,5 (GPT-3.5) ; 121,2 (GPT-4) ; 2 923,7 (Claude-1) ; 56,8 (Gemini).
- 2502.19537, tableau 8, baisse relative sous le filtre de sortie : NOICE 16 %, 11 %, 44 % ; attaque implicite 66 %, 30 %, 6 % ; données nuisibles 15 %, 52 %, 41 %.

## Lectures sur figure (nature « figure »)
- 2601.04603, figure 2a : sonde ~1,4 ; petit classifieur ~1,05-1,1 ; très petit ~4,5. Figure 3a : ~1,1 ; ~1,4 ; ~0,45 ; ~0,8. Figure 4b : ~30, ~57, ~33, ~30 h. Figure 4c : ~5, ~15, ~12, 30 h. Figure 5 : axe gradué 0-0,1 et 0-0,05 sous une étiquette en pourcentage.
