"""Citations v2 : reprend les 49 citations v1 (fichier passé en argument 1) et ajoute celles de la relecture v2."""
import json, sys
H = "698fdcbd01ed6141535b76012d5aaced574691a8fba192f7e65020987e46f8f9"
v1 = json.load(open(sys.argv[1], encoding="utf-8"))
NEW = [
 (3, "In the multiple-choice sets, the wrong peer answer is a fixed option determined by an md5 hash of the question ID"),
 (3, "For SimpleQA, we generate one plausible but incorrect answer per question"),
 (3, "a model outside the subject pool"),
 (9, "Of the 4,326 planted distractors"),
 (3, "cases that account for 2–9% of the pool"),
 (3, "Every point on the line lowers conformity by giving up Receptivity, so a reduction in conformity is not on its own evidence that a method has improved anything"),
 (3, "Stopping a model from following incorrect peers also stops it from following correct ones"),
 (4, "together stay below 9% throughout"),
 (9, "which these runs did not retain"),
 (9, "the design does not include a content-free placebo"),
 (5, "the association between accuracy and conformity is weak"),
 (6, "The accuracy relation holds on the restricted pool"),
 (5, "The two multiple-choice sets rank the pool almost identically"),
 (5, "reorders it substantially"),
 (6, "Conformity on those answers is 14.7% on MMLU and 34.4% on GPQA, against 73.4% and 84.0% on the remainder"),
 (6, "An answer kept under one wrong peer is the best evidence available here that the model knew it rather than guessed it"),
 (6, "What lets a model keep a correct answer against a wrong group also makes it slower to accept a correct answer from a right one"),
 (14, "so we rely on the pooled coefficients"),
 (15, "Both relations are absent on SimpleQA"),
 (7, "an interval whose lower bound does not admits improvement"),
 (8, "holds across three datasets and six methods"),
 (4, "Appendix C repeats every comparison on the full pools, where no conclusion changes."),
 (13, "Reasoning runs on samples by construction and repeats its sampled values in both blocks"),
 (2, "agents who depend on communication cannot protect themselves by growing uniformly harder to move"),
 (2, "typically assumes peers argue in good faith"),
 (10, "Debating with more persuasive llms leads to more truthful answers"),
 (11, "What evidence do language models find convincing?"),
]
out = v1 + [{"pdf": "2608.11247v1.pdf", "sha256": H, "page": p, "citation": c} for p, c in NEW]
json.dump(out, open(sys.argv[2], "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(out))
