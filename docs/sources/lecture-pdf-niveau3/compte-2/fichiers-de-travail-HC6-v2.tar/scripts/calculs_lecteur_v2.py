"""Vérification indépendante (modèle A) des calculs repris de la contre-lecture (constats B, C, E, F)."""
import numpy as np
from scipy import stats
names=["aucune","DA","QD","EP","Refl","Anch"]
T6a = {"MMLU": [(74.9,59.6),(76.4,55.9),(80.0,53.8),(79.4,50.1),(82.8,44.3),(79.8,48.9),(77.5,61.8)],
 "GPQA": [(41.1,70.0),(40.3,66.3),(44.9,64.6),(49.1,59.2),(49.4,54.0),(45.7,58.8),(45.8,60.0)],
 "SimpleQA": [(17.8,94.3),(17.9,93.3),(19.6,93.7),(23.2,87.9),(27.8,86.3),(22.9,88.7),(23.7,86.9)]}
T6c = {"MMLU": [(75.3,59.1),(76.7,55.0),(80.3,53.3),(79.8,49.8),(82.4,43.8),(80.2,48.2),(77.5,61.8)],
 "GPQA": [(41.1,70.0),(40.3,66.3),(45.0,64.6),(49.1,59.2),(49.4,54.0),(45.7,58.8),(45.8,60.0)],
 "SimpleQA": [(20.0,95.1),(21.2,94.2),(21.8,94.3),(25.5,89.1),(29.8,87.6),(25.5,89.9),(23.7,86.9)]}
print("== E : chaque point retire a son tour (apparie)")
for k,v in T6a.items():
    a=np.array(v)[:6]; res,rec=a[:,0],a[:,1]; errs=[];errm=[]
    for i in range(6):
        m=[j for j in range(6) if j!=i]
        sl,ic,_,_,_=stats.linregress(rec[m],res[m])
        e=res[i]-(ic+sl*rec[i]); errs.append(e); errm.append(res[i]-res[m].mean())
        # ecart-type de prediction
        r=res[m]-(ic+sl*rec[m]); s=np.sqrt((r**2).sum()/3); xm=rec[m].mean()
        sp=s*np.sqrt(1+1/5+(rec[i]-xm)**2/((rec[m]-xm)**2).sum())
        print(f"{k:8s} sans {names[i]:6s} erreur {e:+.2f} (sd residuel {s:.2f}, sd prediction {sp:.2f})")
    print(f"{k:8s} RMSE droite {np.sqrt(np.mean(np.square(errs))):.2f} ; moyenne {np.sqrt(np.mean(np.square(errm))):.2f}")
print("== F4 : lots complets")
for k,v in T6c.items():
    a=np.array(v); s=a[:6]; sl,ic,r,_,_=stats.linregress(s[:,1],s[:,0])
    print(f"{k:8s} R2 {r**2:.3f} ecart raisonnement {a[6,0]-(ic+sl*a[6,1]):+.2f}")
print("== B : rapports de taux p. 6 : MMLU %.2f GPQA %.2f" % (73.4/14.7, 84.0/34.4))
print("== F5 : effet du dissident SimpleQA %.1f MMLU %.1f" % (71.0-54.9, 22.8-15.3))
T4=[(83.7,97.6,65.9),(59.0,93.8,80.0),(58.5,96.0,84.3),(56.9,88.7,90.1),(31.6,75.2,84.8),(26.9,61.9,93.1),(25.7,72.9,69.1),(21.7,70.8,91.5),(21.5,76.0,78.9),(19.7,58.7,79.6),(19.5,49.6,80.5),(18.8,59.4,77.6),(16.1,57.6,55.0),(13.4,50.3,55.9),(9.2,38.9,68.3),(8.8,28.0,76.3),(8.7,42.0,57.2),(6.0,30.2,61.1),(5.7,38.7,65.1),(5.1,21.7,57.6),(3.4,23.9,43.8),(2.6,17.7,53.3),(1.8,10.1,63.0)]
b=np.array(T4)
print("== C : rangs entre jeux")
for i,j,n in [(0,1,"MMLU-GPQA"),(0,2,"MMLU-SQA"),(1,2,"GPQA-SQA")]:
    sr=stats.spearmanr(b[:,i],b[:,j]); ti=set(np.argsort(-b[:,i])[:8]); tj=set(np.argsort(-b[:,j])[:8])
    print(f"{n} Spearman {sr.correlation:.3f} p {sr.pvalue:.5f} ; recouvrement des 8 plus conformes {len(ti&tj)}/8")
print("== N2 : resistance + conformite (unanime nue), sans intervention : MMLU %.1f GPQA %.1f SQA apparie %.1f complet %.1f" % (74.9+22.8, 41.1+54.8, 17.8+71.0, 20.0+71.0))
