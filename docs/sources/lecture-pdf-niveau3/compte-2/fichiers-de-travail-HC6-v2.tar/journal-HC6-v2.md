# Journal du lecteur — HC6 contre 2608.11247v1, version 2 (modèle A)

Écrit à 2026-11-13 23:32:53 UTC (date -u, même commande).

## Déroulement
- 23:22:44 UTC : reprise pour la version 2. Vérifié les empreintes de la contre-lecture (87e1699c…6f48c), de son archive (9d9cb08c…562a3) et du rapport v1 (0a35df01…9b079), toutes conformes. Constaté l'absence de tout fichier de version 2 dans le dossier de sortie.
- Archive de la contre-lecture extraite dans le sous-dossier neuf contre-lecture-extraite-v1/ (hors de l'archive v2).
- Lu la contre-lecture en entier et son fichier de recalculs.
- 23:24 UTC : affichage borné aux plages permises des lignes 102 et 195 du programme, et 28 à 40 de N-005 (filtre par numéro de ligne ; rien hors plage affiché).
- Relu ligne à ligne les pages 3 et 9 (ordre des colonnes, extraction sans -layout), puis la page 6 (mise en page, déjà affichée en v1, relue).
- Figure 2 (p. 5) rendue à 200 points par pouce (images/, hors archive) et relue : bande « autre réponse » d'environ 18 points sur SimpleQA sous un pair (constat N2).
- Calculs de B refaits par mon propre script (scripts/calculs_lecteur_v2.py, interpréteur du .venv avec -I) : tous retrouvés.
- Première rédaction de la v2 écrite au dépôt, puis redémarrage du conteneur avant scellement. Le coordinateur a retiré ce fichier partiel non scellé.
- 23:30:02 UTC : après la reprise, ls du seul dossier de sortie : aucun rapport-HC6-v2.md ni fichiers-de-travail-HC6-v2.tar. Empreintes des entrées revérifiées (23:30:11 UTC), toutes conformes. Dossier de travail intact.
- 23:30:11 UTC : rapport v2 réécrit en entier.
- 23:32:35 UTC : sur la version finale, contrôle des citations relancé (76 sur 76, 0 échec ; 3 au second niveau : n° 17, 40, 55), tests du script relancés (juste 2 sur 2 ; altéré 3 échecs sur 3), vérification des guillemets du rapport (69 passages anglais, 0 absent), table de suite : une entrée par lettre de A à J, aucun nom de modèle dans le rapport v2.

## Décisions sur les constats A à J
Toutes « corrigé » (motifs dans le rapport, section 8). D : verdict donné sous les deux sens de « bénin », sans trancher.

## Constats nouveaux
N1 (p. 3 : une baisse de conformité n'est pas à elle seule une preuve d'amélioration) ; N2 (figure 2 contre p. 3-4 sur les autres réponses) ; N3 (p. 9 : pas de placebo, pas de probabilités de jeton) ; N4 (nom de modèle dans la v1).

## Interdits
Aucune commande git, aucun réseau, aucun appel de modèle, aucune recherche récursive dans le dépôt, aucun fichier interdit ouvert, aucun refus.
