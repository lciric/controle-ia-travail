"""Vérifie que tout extrait entre guillemets français du Markdown figure tel quel dans le JSON des citations,
et que chaque ligne de constat commence par sa lettre seule."""
import json, re, sys
md = open(sys.argv[1], encoding="utf-8").read()
cits = {c["citation"] for c in json.load(open(sys.argv[2], encoding="utf-8"))}
ex = re.findall(r"«\s*(.*?)\s*»", md, flags=re.S)
ko = [e for e in ex if e not in cits]
fr = [e for e in ex if e not in cits]
print(len(ex), "extraits entre guillemets français ;", len(ko), "absents du JSON")
for e in fr: print("  HORS JSON:", e[:90])
utilises = {e for e in ex if e in cits}
print(len(cits - utilises), "citations du JSON non employées dans le texte")
for c in sorted(cits - utilises): print("  NON EMPLOYEE:", c[:90])
lettres = re.findall(r"^\| ([A-Z]) \| (bloquant|majeur|mineur) \|", md, flags=re.M)
print("constats:", "".join(l for l, _ in lettres), [g for _, g in lettres].count("majeur"), "majeurs")
sys.exit(1 if ko else 0)
