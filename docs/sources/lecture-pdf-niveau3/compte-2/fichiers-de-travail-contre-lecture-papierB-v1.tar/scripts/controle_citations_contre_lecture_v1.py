"""Contrôle des citations de la contre-lecture (écrit par le contre-lecteur, indépendant du script du lecteur).
Usage : python3 -I controle_citations_contre_lecture_v1.py CITATIONS.json PDF [PDF...]
Chaque citation doit figurer dans le texte de sa page (pdftotext avec puis sans -layout),
après normalisation des espaces, ligatures, césures, apostrophes et tirets."""
import hashlib, json, os, re, subprocess, sys, unicodedata

REMPL = {"’": "'", "‘": "'", "ʼ": "'", "“": '"', "”": '"', "«": '"', "»": '"',
         "–": "-", "—": "-", "−": "-", "‐": "-", "‑": "-", "­": "", " ": " "}

def norm(t):
    t = unicodedata.normalize("NFKC", t)
    for a, b in REMPL.items():
        t = t.replace(a, b)
    t = re.sub(r"(?<=\w)-[ \t]*\n[ \t]*(?=\w)", "", t)   # césure en fin de ligne
    return re.sub(r"\s+", " ", t).strip()

def serre(t):
    return re.sub(r"[\s-]+", "", norm(t))   # sans espaces ni tirets : tolère les césures de mots composés

def page(pdf, n, layout):
    cmd = ["pdftotext"] + (["-layout"] if layout else []) + ["-f", str(n), "-l", str(n), pdf, "-"]
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout

def main():
    cits = json.load(open(sys.argv[1], encoding="utf-8"))
    pdfs = {os.path.basename(p): p for p in sys.argv[2:]}
    emp = {n: hashlib.sha256(open(p, "rb").read()).hexdigest() for n, p in pdfs.items()}
    echecs = 0
    for i, c in enumerate(cits):
        raison = None
        if c["pdf"] not in pdfs:
            raison = "pdf inconnu"
        elif emp[c["pdf"]] != c["sha256"]:
            raison = "empreinte différente"
        elif len(norm(c["citation"])) < 12:
            raison = "citation trop courte"
        else:
            ok = False
            for layout in (True, False):
                txt = page(pdfs[c["pdf"]], int(c["page"]), layout)
                if norm(c["citation"]) in norm(txt) or serre(c["citation"]) in serre(txt):
                    ok = True
                    break
            if not ok:
                raison = "absente de la page"
        if raison:
            echecs += 1
            print(f"ECHEC {i} {c['pdf']} p.{c['page']} [{raison}] {c['citation'][:70]}")
    print(f"{len(cits)} citations, {echecs} echec(s)")
    return 1 if echecs else 0

if __name__ == "__main__":
    sys.exit(main())
