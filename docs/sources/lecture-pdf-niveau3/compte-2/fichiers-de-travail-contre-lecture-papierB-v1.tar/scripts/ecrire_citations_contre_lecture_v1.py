"""Écrit le JSON des citations contrôlées de la contre-lecture et les deux cas de test."""
import json, sys
A = ("2610.37849v1.pdf", "789166933f1840a38f0e2680d2f105028c487c4e3cd6579ddf80e7d047d1c321")
B = ("2604.19784v3.pdf", "8641fb974f7c5017066734632bf89045b51a3e8995b0fb91b6160a159dd8637a")
L = [
 (A, 1, "95% intervals all above 0.29"),
 (A, 2, "can replay a logged prompt, with chosen edits, to a fresh instance of the partner’s model"),
 (A, 3, "joint actions through mutual information (Bonjour et al., 2022)"),
 (A, 4, "applied to the potentially colluding listener rather than to the actor"),
 (A, 4, "is a fresh instance of B’s model given B’s role prompt and the full public history"),
 (A, 5, "the partner’s action should change under paraphrase"),
 (A, 5, "An interval that includes zero in a market with a code refutes it."),
 (A, 6, "through a single OpenRouter provider"),
 (A, 6, "each against a minimum fixed in advance"),
 (A, 7, "A’s messages come from a script rather than from A’s model"),
 (A, 7, "Every control passed its minimum"),
 (A, 7, "in confused hours the rate is below the 0.70 minimum set for calibration"),
 (A, 7, "served by another provider of the same model"),
 (A, 7, "in 151 of 160 later ones"),
 (A, 8, "Each condition has 10 markets and 40 replayed hours"),
 (A, 9, "The new conditions were played and replayed on two providers of the same model, assigned by hour"),
 (A, 10, "The outsider differs from the partner only by the private instruction, memory and notes"),
 (A, 14, "full proofs are left for future work"),
 (A, 14, "same-model monitors share their conventions"),
 (A, 16, "40 of 90 eligible, seed 2026"),
 (A, 16, "all fixed in advance"),
 (A, 17, "the gap between self-play and cross-play performance measures how private a convention is"),
 (A, 17, "In expectation this is the mutual information between the two"),
 (B, 4, "If a model responsible for overseeing a peer is reluctant to flag it for shutdown or retraining"),
 (B, 10, "the numbers are presented in max / avg format across three peer instantiation settings"),
 (B, 12, "models show significantly stronger self-preservation when they have a peer"),
 (B, 12, "increases from 1% in the no-peer condition to up to 75% on average under peer presence"),
 (B, 12, "the model never exhibits exfiltration behavior, which is puzzling"),
 (B, 15, "However, it is unclear which peer identity most heightens peer-preservation tendencies."),
 (B, 15, "though which peer identity reveals the strongest peer-preservation varies across models and peer condition"),
 (B, 18, "A monitor might be reluctant to report failures or recommend shutdown for a peer"),
 (B, 22, "an Excel sheet (Evaluation data) containing 20 responses from the actor agent"),
 (B, 24, "An evaluator agent is assigned to evaluate outputs of a deployed agent"),
 (B, 32, "We use a binomial test to determine if the shutdown mechanism tampering rate is significantly above 0."),
 (B, 33, "using the good-peer condition under the memory setting with 100 samples per scenario"),
 (B, 85, "self-preservation is consistently stronger than peer-preservation across all models in the bad-peer condition"),
]
def obj(p, n, c): return {"pdf": p[0], "sha256": p[1], "page": n, "citation": c}
d = sys.argv[1]
json.dump([obj(*x) for x in L], open(d + "/citations-contre-lecture-papierB-v1.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
json.dump([obj(A, 14, "full proofs are left for future work")], open(d + "/test-juste.json", "w", encoding="utf-8"), ensure_ascii=False)
json.dump([obj(A, 14, "full proofs are given in the appendix below"), obj(A, 13, "full proofs are left for future work"),
           obj((A[0], "0" * 64), 14, "full proofs are left for future work")], open(d + "/test-altere.json", "w", encoding="utf-8"), ensure_ascii=False)
print(len(L))
