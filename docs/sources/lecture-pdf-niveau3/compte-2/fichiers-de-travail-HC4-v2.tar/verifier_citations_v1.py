"""Contrôle des citations du rapport HC4 (lecteur, compte 2).

Usage : python3 -I verifier_citations_v1.py CITATIONS.json DOSSIER_PDF
Pour chaque citation {pdf, sha256, page, citation} : vérifie l'empreinte du PDF,
extrait la page par pdftotext (avec et sans -layout), normalise (NFKC, ligatures,
apostrophes, guillemets, tirets, césures en fin de ligne, espaces) et cherche la
citation normalisée. Code de sortie 0 si zéro échec, 1 sinon.
"""
import hashlib, json, re, subprocess, sys, unicodedata

TRAD = {"’": "'", "‘": "'", "“": '"', "”": '"', "«": '"', "»": '"',
        "–": "-", "—": "-", "−": "-", "‐": "-", "‑": "-", " ": " ",
        "ﬁ": "fi", "ﬂ": "fl", "ﬀ": "ff", "ﬃ": "ffi", "ﬄ": "ffl"}

def normaliser(t):
    t = unicodedata.normalize("NFKC", t)
    for a, b in TRAD.items():
        t = t.replace(a, b)
    t = re.sub(r"(\w)-[ \t]*\n[ \t]*(\w)", r"\1\2", t)   # césure en fin de ligne
    t = re.sub(r"\s+", " ", t)
    return t.strip()

def extraire(pdf, page, layout):
    cmd = ["pdftotext"] + (["-layout"] if layout else []) + ["-f", str(page), "-l", str(page), pdf, "-"]
    return subprocess.run(cmd, capture_output=True, check=True).stdout.decode("utf-8", "replace")

def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()

def main():
    cits = json.load(open(sys.argv[1], encoding="utf-8"))
    dossier = sys.argv[2].rstrip("/")
    cache_sha, echecs = {}, 0
    for i, c in enumerate(cits):
        pdf = f"{dossier}/{c['pdf']}"
        if pdf not in cache_sha:
            cache_sha[pdf] = sha(pdf)
        ok_sha = cache_sha[pdf] == c["sha256"]
        cible = normaliser(c["citation"])
        trouve = any(cible in normaliser(extraire(pdf, c["page"], lay)) for lay in (True, False))
        statut = "OK" if (ok_sha and trouve) else "ECHEC"
        if statut == "ECHEC":
            echecs += 1
        print(f"{i:03d} {statut} {c['pdf']} p.{c['page']} sha={'ok' if ok_sha else 'FAUX'} :: {c['citation'][:70]}")
    print(f"TOTAL {len(cits)} citations, {echecs} echec(s)")
    sys.exit(1 if echecs else 0)

if __name__ == "__main__":
    main()
