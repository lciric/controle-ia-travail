# Journal du lecteur — HC4, version 2 (modèle A ; contre-lecteur : modèle B ; A ≠ B)

Écrit le 2026-11-13 23:53:22 UTC (date -u). Reprise v2 à 2026-11-13 23:47:20 UTC (date -u).

- Message de la coordination : intégrer la contre-lecture sous un nom neuf, sans toucher la v1.
- Empreintes vérifiées : contre-lecture-rapport-HC4-v1.md 8fa4ab9baf757af42f44255b484c3b0ca865fc8b887c6c01bf4755473847e5b0 ; fichiers-de-travail-contre-lecture-HC4-v1.tar e7466a1f53ce016337caef2c2b6dfce0b037ae3f68586116925cdb9815ff75e2 (conformes). Archive extraite dans contre-lecture-B-v1/ (sous-dossier neuf ; non reprise dans mon archive ; aucun de ses scripts exécuté).
- Relectures ligne à ligne demandées, faites de 23:47:40 à 23:49 UTC : 2601.04603 p. 2-9 ; 2310.08419 p. 4-6 et 15 ; 2502.19537 p. 7-8. Figures 4 (p. 14) et 5 (p. 16) de 2601.04603 vues sur l'image.
- Lignes du dépôt relues dans les plages du mandat : programme l. 101-106, 193-195 ; N-013 l. 46-50 ; état de l'art niveau 3 l. 417-422.
- Constats A à M : tous « corrigé » (table du rapport, section 1). Ajouts propres : distillation de la sonde depuis un classifieur (2601.04603 p. 7) ; sensibilité de la sonde à la perte (figure 2b) ; mot « detection rate » p. 9.
- Calculs v2 : requêtes attendues par succès de PAIR, échecs à 90 : ((1-s)·90 + s·q)/s = 22,3 ; 2 216 ; 119,5 ; 121,2 ; 2 923,7 ; 56,8. Baisse relative sous le filtre (2502.19537, tableau 8), NOICE : 16 %, 11 %, 44 %. 5 120/20 = 256 ; 256 000/20 = 12 800. Hypothèse dénominateur 7 000 : 98 et 77.
- Citations v2 : 137 (79 v1 + 58 ajouts), 0 échec (controle-citations-final-v2.txt). Guillemets du rapport v2 : 98 dans le JSON, 46 hors JSON, tous en français, vérifiés un à un (guillemets-rapport-v2.txt).
- Aucune commande git, aucun réseau, aucun appel de modèle, aucun refus, aucune ouverture fautive.
