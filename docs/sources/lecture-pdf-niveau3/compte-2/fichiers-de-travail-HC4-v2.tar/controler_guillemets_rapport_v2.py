"""Extrait chaque passage entre guillemets français du rapport et le cherche (normalisé) dans le JSON des citations.
Usage : python3 -I controler_guillemets_rapport_v2.py RAPPORT.md CITATIONS.json
Imprime JSON/HORS par passage ; les HORS sont à vérifier à la main (français attendu)."""
import json, re, sys, unicodedata
TR = {"’": "'", "‘": "'", "“": '"', "”": '"', "–": "-", "—": "-", "−": "-", " ": " "}
def n(t):
    t = unicodedata.normalize("NFKC", t)
    for a, b in TR.items():
        t = t.replace(a, b)
    return re.sub(r"\s+", " ", t).strip()
rapport = open(sys.argv[1], encoding="utf-8").read()
base = [n(c["citation"]) for c in json.load(open(sys.argv[2], encoding="utf-8"))]
nj = nh = 0
for num, ligne in enumerate(rapport.split("\n"), 1):
    for m in re.finditer(r"«\s*([^»]+?)\s*»", ligne):
        q = n(m.group(1))
        dans = any(q in b for b in base)
        nj += dans; nh += (not dans)
        print("%s l.%d | %s" % ("JSON" if dans else "HORS", num, q))
print("TOTAL JSON=%d HORS=%d" % (nj, nh))
