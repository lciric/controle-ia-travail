"""Contrôle des citations de la contre-lecture du rapport T (lot 8), v1.

Usage : python3 -I verifier_citations_contre_lecture_v1.py DOSSIER_PDF citations.json
Chaque entrée {pdf, sha256, page, citation} : l'empreinte du PDF est vérifiée, la page
est extraite par pdftotext (avec et sans -layout), le texte et la citation sont
normalisés (Unicode NFKC, ligatures, apostrophes, guillemets, tirets, césures de fin
de ligne avec et sans trait d'union conservé, espaces), puis la citation est cherchée
dans la page. Code de sortie 0 si et seulement si aucun échec.
"""
import hashlib, json, re, subprocess, sys, unicodedata
from pathlib import Path

REMPL = {"ﬀ": "ff", "ﬁ": "fi", "ﬂ": "fl", "ﬃ": "ffi", "ﬄ": "ffl"}
for c in "‘’‚‛′´`":
    REMPL[c] = "'"
for c in "“”„‟«»":
    REMPL[c] = '"'
for c in "‐‑‒–—―−­":
    REMPL[c] = "-"


def norm(t, garder):
    t = unicodedata.normalize("NFKC", t)
    for k, v in REMPL.items():
        t = t.replace(k, v)
    t = t.replace("\f", " ")
    t = re.sub(r"(\w)-[ \t]*\n\s*(\w)", r"\1-\2" if garder else r"\1\2", t)
    t = re.sub(r"\s+", " ", t)
    t = re.sub(r"\s+([,.;:)\]])", r"\1", t)
    t = re.sub(r"([(\[])\s+", r"\1", t)
    return t.strip().lower()


def page(pdf, n, layout):
    cmd = ["pdftotext", "-q", "-f", str(n), "-l", str(n)] + (["-layout"] if layout else []) + [str(pdf), "-"]
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout


def trouve(pdf, n, cit):
    for layout in (True, False):
        brut = page(pdf, n, layout)
        for garder in (False, True):
            c, p = norm(cit, garder), norm(brut, garder)
            if len(c) >= 12 and c in p:
                return True
    return False


def main():
    dossier, fichier = Path(sys.argv[1]), Path(sys.argv[2])
    cits = json.loads(fichier.read_text(encoding="utf-8"))
    sha, echecs = {}, 0
    for i, e in enumerate(cits, 1):
        pdf = dossier / e["pdf"]
        if e["pdf"] not in sha:
            sha[e["pdf"]] = hashlib.sha256(pdf.read_bytes()).hexdigest()
        if sha[e["pdf"]] != e["sha256"]:
            statut = "ECHEC-EMPREINTE"
        elif trouve(pdf, int(e["page"]), e["citation"]):
            statut = "OK"
        else:
            statut = "ECHEC"
        echecs += statut != "OK"
        print(f"{i:3d} {statut:15s} {e['pdf']} p.{e['page']} : {e['citation'][:80]}")
    print(f"TOTAL {len(cits)} citations, {echecs} échec(s)")
    return 0 if echecs == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
