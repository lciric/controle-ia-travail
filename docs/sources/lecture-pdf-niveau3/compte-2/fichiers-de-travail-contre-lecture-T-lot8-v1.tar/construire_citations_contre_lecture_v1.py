"""Écrit citations-contre-lecture-T-v1.json et les deux fichiers d'essai (juste, altéré)."""
import json, sys
from pathlib import Path
K = ("2310.01153v5.pdf", "e8cd3532247d69817c47ecf7773c1da5318e87404b9e29d3d95f6fef69ab0544")
R = ("2102.00630v4.pdf", "2ada73f4abaf779b06baa558f49893678feec1d5b1451e083e842dd14117fd57")
V = ("1906.09256v3.pdf", "0a9a1f2c7e96107f4f573e9aa3dd8f1d79798b84cbbd9923bd3db2ecb81efbe3")
L = [
 (K, 8, "Y is an invariant random variable under a compact group G if one of the following equivalent conditions holds"),
 (K, 9, "which follows from Lemma 1 by considering the invariant random variable"),
 (K, 9, "the fact that the Haar measure on a compact group is both left- and right-invariant"),
 (K, 9, "We can also express this in terms of random variables"),
 (K, 11, "In particular, we may view the problem of testing group invariance as first observing the orbit"),
 (K, 39, "Moreover, recall that Gy ∼ Unif(Oy), for fixed y."),
 (K, 13, "One may also replace G in (3.2) with a random variable that is uniform on a compact subgroup [Chung and Fraser, 1958]."),
 (K, 17, "Permuting such a shot sequence exactly fixes the number of hits"),
 (K, 21, "Suppose we sequentially observe potentially unequally sized batches of data"),
 (K, 21, "where Pi is the group of permutations acting on the batch Yi"),
 (K, 22, "we exclude permutations that swap observations across batches"),
 (K, 22, "Specifically, the groups we consider here are subgroups of the permutations on the set of the individual observations."),
 (K, 23, "we are testing a larger hypothesis than"),
 (K, 23, "This shows where the test martingale loses power compared to an e-process."),
 (K, 23, "In each interval of time, we receive the outcomes of a number of treated and control units"),
 (K, 24, "As a batch of data, we consider the combined observations of both the treated and control units that arrived in the previous interval of time."),
 (K, 26, "the product of independent e-values is also an e-value"),
 (K, 26, "with 26 shooters taking up to 100 shots each"),
 (K, 26, "For simplicity, we say a player is ‘hot’ if they hit k shots in a row."),
 (K, 26, "long sequences are required to detect a hot hand"),
 (K, 35, "where Pi permutes the observations within the ith batch of data"),
 (K, 37, "Here, the resulting order of the numbers is not invariant under all permutations"),
 (K, 37, "only the 8 orders 1234, 1243, 2134, 2143, 3412, 3421, 4312 and 4321 can occur"),
 (K, 38, "which is not an exchangeable n-vector"),
 (K, 38, "the probability of rejection equals"),
 (K, 16, "This recovers the main result of Lehmann and Stein [1949]."),
 (R, 3, "All martingale statements in this paper will implicitly refer to this canonical filtration."),
 (R, 4, "safe and consistent e-processes do not exist and neither do valid, power-one tests."),
 (R, 11, "provided the chain does not have any absorbing states"),
 (R, 11, "that appear to be Bernoulli when summarized by only first order transition parameters"),
 (R, 17, "We now return to the main focus of this paper, which is binary sequences"),
 (R, 17, "Q-NSM must be nonincreasing, and hence these never exceed one and always have zero power for any"),
 (R, 21, "The right picture confirms that this is due to the Markovian aspect of the source, and not due to the changing probabilities."),
 (R, 22, "no test can possibly have power one"),
 (R, 26, "we prove that it has power one against any first-order Markovian alternative"),
 (V, 5, "Nonparametric statistics provides us with plenty of p-variables for testing exchangeability"),
 (V, 8, "It is easy to check that for the natural underlying filtration"),
 (V, 15, "which is futile, and so its value decreases exponentially quickly"),
 (V, 17, "we do not expect the first alarm to be raised too soon under the hypothesis of randomness"),
 (V, 25, "are IID and uniform on [0, 1] under any exchangeable probability measure"),
 (V, 33, "ω should be exchangeable, and the number of 1s in it should be binomial"),
]
d = Path(sys.argv[1])
def e(x): return {"pdf": x[0][0], "sha256": x[0][1], "page": x[1], "citation": x[2]}
(d / "citations-contre-lecture-T-v1.json").write_text(json.dumps([e(x) for x in L], ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
(d / "essai-juste-v1.json").write_text(json.dumps([e(L[13])], ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
alt = [e((K, 23, "This shows where the test martingale gains power compared to an e-process.")),
       e((K, 24, L[13][2])),
       {"pdf": K[0], "sha256": "0" * 64, "page": 23, "citation": L[13][2]}]
(d / "essai-altere-v1.json").write_text(json.dumps(alt, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
