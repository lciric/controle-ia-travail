"""Cohérence rapport / JSON : toute citation entre guillemets anglais doubles du rapport figure mot pour mot dans le JSON."""
import json, re, sys
from pathlib import Path
txt = Path(sys.argv[1]).read_text(encoding="utf-8")
cits = [e["citation"] for e in json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))]
dans = re.findall(r"“([^”]+)”", txt)
abs_ = [c for c in dans if c not in cits]
inut = [c for c in cits if c not in dans]
print(f"{len(dans)} citations entre guillemets anglais dans le rapport ({len(set(dans))} distinctes) ; {len(abs_)} absentes du JSON")
for c in abs_: print("  ABSENTE :", c)
print(f"{len(inut)} citations du JSON non reprises dans le rapport")
for c in inut: print("  NON REPRISE :", c)
sys.exit(1 if abs_ or inut else 0)
