# Lecture par pixels de la figure 8 (page 10 rendue a 300 points par pouce).
# Pour chaque panneau : repere l'etoile du moniteur (couleur ocre), puis la courbe noire de la sonde
# dans la meme colonne de pixels ; convertit en taux par les lignes de grille 0 % et 100 %.
import sys
from PIL import Image
im = Image.open(sys.argv[1]).convert('RGB')
Wd, Ht = im.size
px = im.load()
def ocre(c):
    r, g, b = c
    return 130 < r < 200 and 80 < g < 140 and b < 60 and r - b > 90
def noir(c):
    return max(c) < 70
# composantes ocre : regrouper par boites grossieres
pts = [(x, y) for y in range(0, Ht) for x in range(0, Wd) if ocre(px[x, y])]
groupes = []
for (x, y) in pts:
    for g in groupes:
        if abs(g[0] / g[2] - x) < 40 and abs(g[1] / g[2] - y) < 40:
            g[0] += x; g[1] += y; g[2] += 1
            break
    else:
        groupes.append([x, y, 1])
etoiles = [(g[0] / g[2], g[1] / g[2], g[2]) for g in groupes if g[2] > 150]
for e in sorted(etoiles, key=lambda e: (round(e[1] / 200), e[0])):
    print('etoile x=%.0f y=%.0f n=%d' % e)
    x = int(round(e[0]))
    ys = [y for y in range(int(e[1]) - 700, int(e[1]) + 700) if 0 <= y < Ht and all(noir(px[x + d, y]) for d in (0,))]
    # segments noirs dans la colonne
    seg = []
    for y in ys:
        if seg and y - seg[-1][1] <= 1:
            seg[-1][1] = y
        else:
            seg.append([y, y])
    print('   segments noirs colonne:', seg)
