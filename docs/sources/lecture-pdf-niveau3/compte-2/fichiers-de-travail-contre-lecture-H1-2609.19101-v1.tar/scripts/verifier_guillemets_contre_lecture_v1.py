"""Verifie que tout extrait entre guillemets francais du rapport est soit une citation du JSON controle,
soit une expression francaise de la liste fermee ci-dessous. Signale aussi tout guillemet droit double."""
import json, re, sys
txt = open(sys.argv[1], encoding="utf-8").read()
cits = {c["citation"] for c in json.load(open(sys.argv[2], encoding="utf-8"))}
FR = {"fichiers nommés seulement", "auteurs", "figure", "calcul", "tient avec corrections", "déclarable",
      "concentré", "des actes ou des pensées ponctuels", "ne touche pas", "voisin", "non déclarable pour l'instant",
      "oui", "Voisin", "Ne touche pas", "Non", "dans l'échantillon", "pas de vérité terrain", "répétée sur plusieurs pas",
      "moniteur binaire, un seul point de fonctionnement", "31 à 37 % pour la sonde", "30 à 37 % pour la sonde",
      "4 à 8 % pour le moniteur", "identification non vérifiable dans la pièce", "touche de près (d) et (e)",
      "d'après le seul titre, pourrait toucher (d) et (e)", "agrégation des jetons au passage non décrite, et aucune comparaison au grain du déroulé",
      "une phrase publique ne peut plus présenter le gain des sondes à taux égal dans un agent comme acquis"}
ko = 0
for m in re.findall(r"«\s*(.*?)\s*»", txt, flags=re.S):
    if m in cits:
        continue
    if m in FR:
        continue
    if re.search(r"[éèêàùçî]| (la|le|les|des|est|par) ", m):  # texte corrige propose, en francais
        print("FRANCAIS (texte propose, relu a l'oeil) :", m[:90].replace("\n", " "), "...")
        continue
    ko += 1
    print("HORS LISTE :", m)
print("guillemets droits doubles :", txt.count('"'))
print("extraits hors liste :", ko)
sys.exit(1 if ko else 0)
