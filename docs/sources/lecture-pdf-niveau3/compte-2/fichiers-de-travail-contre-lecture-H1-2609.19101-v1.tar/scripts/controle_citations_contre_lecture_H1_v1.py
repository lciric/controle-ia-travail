"""Controle des citations de la contre-lecture H1 / 2609.19101 (contre-lecteur, modele B), v1.
Usage : python3 -I controle_citations_contre_lecture_H1_v1.py CITATIONS.json DOSSIER_PDF
Chaque citation {pdf, sha256, page, citation} doit figurer dans le texte de la page du fichier,
extrait par pdftotext avec ou sans -layout, apres normalisation (espaces, ligatures, cesures,
apostrophes, guillemets, tirets). L'empreinte du PDF est verifiee. Code de retour 1 au moindre echec.
"""
import hashlib, json, pathlib, re, subprocess, sys, unicodedata

def norm(s, coller_cesure):
    s = unicodedata.normalize("NFKC", s).replace("­", "")
    s = re.sub("[‐‑‒–—―−]", "-", s)
    s = re.sub("[‘’‚‛′´`]", "'", s)
    s = re.sub("[“”„‟«»″]", '"', s)
    s = re.sub(r"-[ \t]*\n\s*", "" if coller_cesure else "-", s)
    return re.sub(r"\s+", " ", s).strip()

def page(pdf, n, layout):
    cmd = ["pdftotext"] + (["-layout"] if layout else []) + ["-f", str(n), "-l", str(n), str(pdf), "-"]
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout

def main():
    cits = json.loads(pathlib.Path(sys.argv[1]).read_text(encoding="utf-8"))
    dossier = pathlib.Path(sys.argv[2])
    empreintes, pages, echecs = {}, {}, 0
    for i, c in enumerate(cits, 1):
        pdf = dossier / c["pdf"]
        raison = None
        if not pdf.is_file():
            raison = "PDF introuvable"
        else:
            if pdf not in empreintes:
                empreintes[pdf] = hashlib.sha256(pdf.read_bytes()).hexdigest()
            if empreintes[pdf] != c["sha256"]:
                raison = "empreinte differente"
            elif not isinstance(c["page"], int) or not c["citation"].strip():
                raison = "page ou citation invalide"
            else:
                trouve = False
                for layout in (True, False):
                    cle = (pdf, c["page"], layout)
                    if cle not in pages:
                        pages[cle] = page(pdf, c["page"], layout)
                    for coller in (True, False):
                        if norm(c["citation"], coller) in norm(pages[cle], coller):
                            trouve = True
                if not trouve:
                    raison = "citation absente de la page"
        if raison:
            echecs += 1
        print("%3d %-34s p.%-3s %s" % (i, "OK" if not raison else "ECHEC (" + raison + ")", c["page"], c["citation"][:80]))
    print("TOTAL %d citations, %d echec(s)" % (len(cits), echecs))
    sys.exit(1 if echecs else 0)

main()
