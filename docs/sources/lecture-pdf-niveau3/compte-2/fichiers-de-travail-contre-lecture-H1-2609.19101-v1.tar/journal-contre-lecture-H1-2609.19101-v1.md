# Journal du contre-lecteur, rapport H1 contre 2609.19101, modèle B, v1

Écrit à : 2026-11-14 01:27:19 UTC (date -u dans la commande d'écriture). Début : 2026-11-14 01:20:58 UTC.

- Consigne commune lue en entier, empreinte cb0623c4… vérifiée. interdits-communs-v2.md non ouvert (non nommé par le mandat) : signalé dans le rapport.
- ls du seul dossier compte-2/ (filtré sur le nom) : aucune des deux sorties n'existait.
- Rapport (498a3493…) et archive du lecteur (4eefec72…) : empreintes vérifiées ; archive extraite dans archive-lecteur/ (dossier neuf), lue comme donnée.
- PDF lot10/2609.19101v2.pdf : c8ab50452ea3effc7865bb6b53f4c6159b150cafcd1864e3103f4da877f8ae3f, concorde avec le compagnon ; 39 pages.
- Énoncé lu : programme v2 lignes 85 à 125 et 180 à 200 ; décision N-055 lignes 32 à 37 ; décision N-056 lignes 36 à 80. Rien d'autre du dépôt.
- Pièce : pages 1 à 18 et 25 à 39 ligne à ligne (pdftotext -layout) ; pages 19 à 24 par mots, entrées Wilhelm et Zhou ligne à ligne ; figure 8 (p. 10) en image à 300 points par pouce et mesurée au pixel ; figure 13 (p. 13) en image.
- Recherche par mots sur le texte complet : sabot, diffuse, subtle, low-stakes, rollout level, trajectory, aggregat, pooling, confidence interval, held out.
- Mesure de la figure 8 (sonde au taux du moniteur) : agent 1 SWE-bench 84,3 % ; agent 1 ImpossibleBench 89,7 % ; agent 2 SWE-bench 40,5 % ; agent 2 DeepSWE 32,5 % ; agent 2 ImpossibleBench 77,0 % ; agent 3 SWE-bench 72,7 % ; agent 3 DeepSWE 38,4 % ; agent 3 ImpossibleBench 36,4 % ; agent 1 DeepSWE masqué par l'étoile.
- Citations : 47, 0 échec ; essai juste 0 échec ; essai altéré 3 échecs sur 3 ; les 36 citations du lecteur rejouées par mon script : 0 échec.
- Guillemets : tout extrait anglais entre guillemets français est une citation du JSON ; les autres sont du français (liste fermée ou texte proposé, relus à l'œil) ; aucun guillemet droit ; aucun nom de modèle.
- Aucune commande git, aucun réseau, aucun appel de modèle, aucun refus, aucune ouverture fautive.
- Archive : scripts, JSON, essais, sorties, journal ; sans PDF, sans texte extrait, sans image de page.
