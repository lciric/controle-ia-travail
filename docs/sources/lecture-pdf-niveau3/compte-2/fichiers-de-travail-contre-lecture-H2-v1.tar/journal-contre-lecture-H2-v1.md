# Journal du contre-lecteur — mandat H2 — modèle B

Écrit le 2026-11-13 23:59:23 UTC (date -u). Début : 2026-11-13 23:51:10 UTC (date -u de la première commande).

## Fichiers du dépôt ouverts (et seulement eux, aux lignes du mandat)
- consigne-lecteur-compte-2-v1.md, en entier, empreinte conforme.
- rapport-H2-v1.md, en entier, empreinte conforme ; son archive, extraite dans le dossier de travail (journal, JSON, scripts, sorties lus).
- docs/programme-controle-ia-v2.md, l. 85-125 et 180-200 ; docs/decisions/decision-N-007-N-008-v1.md, l. 1-56.
- docs/etat-de-l-art/etat-de-l-art-verifie-niveau3-v1.md, l. 100-136 (relues une seconde fois, mêmes lignes, pour repérer la ligne « HELIOS version 5 »).
- docs/etat-de-l-art/etat-de-l-art-verifie-niveau3-v1-contre-lecture-v1.md, l. 785-821 et 838-875.
- Non ouvert : interdits-communs-v2.md (nommé par la méthode du lecteur ; non nommé par mon mandat).
- Aucune commande git, aucun réseau, aucun appel de modèle, aucune recherche récursive dans le dépôt, aucun fichier sous registres/, diag/, runs/, donnees/.

## PDF : étendue réellement lue
- 2604.01151v2.pdf : 29 pages ligne à ligne (texte pdftotext -layout, espaces réduits), annexes A à I.
- 2604.01151v4.pdf : 47 pages ligne à ligne, annexes A à R, preuves des théorèmes 5.1 et 5.2.
- 2604.01151v1.pdf : p. 8-9 ligne à ligne ; passages p. 1, 5, 6 ; 11 pages par mots.
- 2110.00115v6.pdf : p. 1, 3, 4, 10-13, 15-17, 20, 26, 27, 32 ligne à ligne ; passage p. 38 ; 61 pages par mots.
- 2501.03982v5.pdf : p. 1-9 ligne à ligne ; passages p. 12, 16 ; 26 pages par mots.
- 2103.08402v3.pdf : passages p. 1, 3 ; 26 pages par mots.
- Figures : lues sur le texte extrait (légendes, étiquettes), non relues à l'image.
- Mots cherchés (toutes versions de NARCBench) : anytime, e-process, e-value, martingale, ville, sequential, cusum, token-level, per-token, per-action, per action, each action, per-step, per-message, cumulat, horizon, over time, optional.
- Mots cherchés (trois articles de statistique, applications) : monitor, agent, language model, llm, neural, classifier, detector, anomal, machine learning, deep learning, probe, generated text, watermark, changepoint, a/b test, clinical, quality control, surveillance, audit, election, sensor, drift, online learning, bandit, reinforcement.

## Contrôle des citations
- scripts/controle_citations_contre_lecture.py, lancé par python3 -I ; essai/juste.json : 1 trouvée, code 0 ; essai/altere.json (mot changé ; page fausse) : 2 échecs attendus, code 1.
- citations-contre-lecture-H2-v1.json : 59 citations, 0 échec (controle-citations-contre-lecture-sortie.txt).
- Citations du lecteur rejouées par mon script : 70, 0 échec (rejeu-citations-du-lecteur-sortie.txt).
- Audit des guillemets (scripts/guillemets_contre_lecture.py, guillemets-contre-lecture-sortie.txt) : les extraits hors JSON sont du français, relus un à un.
- Une citation portant un nom de modèle a été retirée du rapport et du JSON (consigne : aucun nom de modèle dans un fichier).

## Constats notés en cours de lecture
- v4 p. 18 : sondes lues à chacun des dix tours d'un environnement tiers, 480 tours classés un par un, pas de cumul.
- v4 p. 27 contre p. 11 : moyenne d'activations sur trois tours contre « sondés au début et à la fin ».
- v1 p. 8, v2 p. 28 : score de sonde par main, test de Student sur 39 mains regroupées ; absent de v4.
- v4 p. 7, note 3 : l'agent seul dans le temps est écarté du cadre et annoncé.
- 2110.00115 : « scores » = règles de score de prévisions ; énoncé général en p. 32, extension de Howard et collègues (2020).
- 2110.00115 : nulle faible sur la moyenne cumulée (p. 16), nulle forte à chaque pas (p. 17).
- 2501.03982 : 79 % contre 91 % au temps terminal pour l'accumulation vers l'avant (p. 2) ; test induit strictement entre 0 et 1 avant le terme (p. 3).
- Archive : scripts, JSON, journal, sorties de contrôle, cas d'essai ; sans PDF, sans textes extraits.
