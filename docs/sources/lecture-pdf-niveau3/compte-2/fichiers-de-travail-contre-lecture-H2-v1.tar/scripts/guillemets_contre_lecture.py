"""Audit des guillemets : tout extrait entre guillemets du rapport figure dans le JSON, ou est liste pour relecture.
Usage : python3 -I ce_script RAPPORT.md CITATIONS.json"""
import json, re, sys, unicodedata
def n(t):
    t = unicodedata.normalize("NFKC", t)
    for a, b in {"’": "'", "‘": "'", "–": "-", "—": "-", " ": " "}.items():
        t = t.replace(a, b)
    return re.sub(r"\s+", " ", t).strip()
texte = open(sys.argv[1], encoding="utf-8").read()
cit = {n(c["citation"]) for c in json.load(open(sys.argv[2], encoding="utf-8"))}
extraits = re.findall(r"«\s*(.+?)\s*»", texte, flags=re.S) + re.findall(r'"([^"\n]+)"', texte) + re.findall(r"“(.+?)”", texte, flags=re.S)
dans, hors = 0, []
for e in extraits:
    if n(e) in cit: dans += 1
    else: hors.append(n(e))
print(f"{len(extraits)} extraits entre guillemets ; {dans} dans le JSON ; {len(hors)} hors JSON (a relire : doivent etre du francais)")
for h in hors: print("HORS :", h[:160])
utilises = {n(e) for e in extraits}
print("citations du JSON non reprises dans le rapport :", sorted(cit - utilises))
