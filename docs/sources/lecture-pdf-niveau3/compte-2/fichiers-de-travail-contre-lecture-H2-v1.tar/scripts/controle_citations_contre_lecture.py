"""Controle des citations du contre-lecteur (modele B), ecrit independamment du script du lecteur.
Chaque citation (pdf, sha256, page, citation) doit figurer dans le texte de la page extrait par pdftotext,
avec ou sans -layout, apres normalisation (espaces, ligatures, cesures, apostrophes, tirets).
Usage : python3 -I controle_citations_contre_lecture.py DOSSIER_PIECES FICHIER_JSON"""
import hashlib
import json
import pathlib
import re
import subprocess
import sys
import unicodedata

REMPL = {"‘": "'", "’": "'", "‛": "'", "′": "'", "“": '"', "”": '"',
         "‐": "-", "‑": "-", "‒": "-", "–": "-", "—": "-", "―": "-",
         "−": "-", "­": ""}


def normaliser(t):
    t = unicodedata.normalize("NFKC", t)
    for a, b in REMPL.items():
        t = t.replace(a, b)
    return re.sub(r"\s+", " ", t).strip()


def formes(t):
    n = normaliser(t)
    return {n, re.sub(r"(?<=\w)- (?=\w)", "", n), re.sub(r"(?<=\w)- (?=\w)", "-", n)}


def texte_page(chemin, page, mise_en_page):
    args = ["pdftotext"] + (["-layout"] if mise_en_page else []) + ["-f", str(page), "-l", str(page), str(chemin), "-"]
    return subprocess.run(args, capture_output=True, text=True, check=True).stdout


def empreinte(chemin):
    return hashlib.sha256(pathlib.Path(chemin).read_bytes()).hexdigest()


def main(dossier, fichier):
    pdfs = {p.name: p for p in pathlib.Path(dossier).rglob("*.pdf")}
    citations = json.loads(pathlib.Path(fichier).read_text(encoding="utf-8"))
    echecs = 0
    for i, c in enumerate(citations, 1):
        p = pdfs.get(c["pdf"])
        if p is None or empreinte(p) != c["sha256"]:
            print(f"ECHEC {i:3d} piece absente ou empreinte differente : {c['pdf']}")
            echecs += 1
            continue
        cible = formes(c["citation"])
        trouve = any(any(x in f for x in cible for f in formes(texte_page(p, c["page"], m))) for m in (False, True))
        print(f"{'OK   ' if trouve else 'ECHEC'} {i:3d} {c['pdf']} p.{c['page']} : {normaliser(c['citation'])[:80]}")
        echecs += 0 if trouve else 1
    print(f"TOTAL {len(citations)} citations ; {echecs} echec(s)")
    return 1 if echecs else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1], sys.argv[2]))
