"""Controle des citations du rapport L (lot 8), v1.
Usage : python3 -I controle_citations_v1.py DOSSIER_PDF citations.json
Pour chaque citation : verifie l'empreinte du PDF, extrait la page par pdftotext (avec et sans -layout),
normalise (NFKC pour les ligatures, apostrophes, guillemets, tirets, cesures, espaces) et cherche la citation.
Code de sortie 0 seulement si zero echec."""
import hashlib, json, re, subprocess, sys, unicodedata

def norm(s):
    s = unicodedata.normalize("NFKC", s)
    for a, b in {"’": "'", "‘": "'", "“": '"', "”": '"', "–": "-", "—": "-",
                 "‐": "-", "‑": "-", "−": "-", "­": "", " ": " "}.items():
        s = s.replace(a, b)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def sans_cesure(s):
    return re.sub(r"(\w)- (\w)", r"\1\2", s)

def page_texte(pdf, p, layout):
    cmd = ["pdftotext", "-f", str(p), "-l", str(p)] + (["-layout"] if layout else []) + [pdf, "-"]
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout

def controle(dossier, chemin_json):
    cites = json.load(open(chemin_json, encoding="utf-8"))
    echecs, empreintes = 0, {}
    for i, c in enumerate(cites, 1):
        pdf = f"{dossier}/{c['pdf']}"
        if pdf not in empreintes:
            empreintes[pdf] = hashlib.sha256(open(pdf, "rb").read()).hexdigest()
        if empreintes[pdf] != c["sha256"]:
            print(f"ECHEC {i} empreinte {c['pdf']}"); echecs += 1; continue
        cn = norm(c["citation"])
        trouve = None
        for layout in (False, True):
            t = norm(page_texte(pdf, c["page"], layout))
            if cn in t:
                trouve = ("layout" if layout else "brut") + "/espaces"; break
            if sans_cesure(cn) in sans_cesure(t):
                trouve = ("layout" if layout else "brut") + "/cesure"; break
        if trouve:
            print(f"OK    {i:3d} {c['pdf']} p.{c['page']} [{trouve}] {c['citation'][:70]}")
        else:
            print(f"ECHEC {i:3d} {c['pdf']} p.{c['page']} {c['citation'][:90]}"); echecs += 1
    print(f"TOTAL citations={len(cites)} echecs={echecs}")
    return echecs

if __name__ == "__main__":
    sys.exit(1 if controle(sys.argv[1], sys.argv[2]) else 0)
