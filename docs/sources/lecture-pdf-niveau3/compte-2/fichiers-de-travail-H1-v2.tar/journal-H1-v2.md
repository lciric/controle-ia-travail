# Journal du lecteur, H1, modèle A, version 2

Écrit à : 2026-11-14 00:00:01 UTC (date -u dans la commande d'écriture). Reprise relevée à 2026-11-13 23:55:19 UTC.

- Contre-lecture vérifiée : contre-lecture-rapport-H1-v1.md (024f84a9440a0b273b5ec924a78c22ad43abcc87e2e010c5b203f8189675b0bf), lue lignes 1 à 213 ; archive fichiers-de-travail-contre-lecture-H1-v1.tar (03c761e0e41151536a4eace971b50cab0a867a589e805fd161b53679b22cefc7), extraite dans contre-lecture-extraite/ (sous-dossier neuf), lue comme donnée, rien exécuté.
- Relu ligne à ligne sans filtre : 2604.15384v2 p. 12, 13, 19, 28, 29, 30, 40, 46, 51 (et passages p. 7, 17) ; 2610.39766v1 p. 2, 3, 4, 6, 7, 8, 12 (p. 5 entière déjà en v1 ; pied de p. 1 sans mise en page) ; 2610.31593v1 passages p. 12 et 20.
- Programme, l. 92 (dans la plage 85 à 125) : énoncé de H1 vérifié ; le constat D citait l. 91 (titre de section), l'énoncé est l. 92.
- Décisions : A à L corrigé ; M réserve maintenue (constat de confirmation, rien à changer).
- Citations : citations-H1-v2.json, 76 citations (41 de v1 + 35 nouvelles), 0 échec (sortie-controle-citations-H1-v2.txt).
- Vérification du rapport (verifier_rapport_H1_v2.py) : tout extrait anglais entre guillemets français identique à une citation du JSON ; les autres extraits entre guillemets sont du français ; aucun guillemet droit ; table A à M complète, une entrée par lettre (sortie-verification-rapport-H1-v2.txt).
- Aucun nom de modèle écrit (correspondances fortuites : LaStraj, isolé).
