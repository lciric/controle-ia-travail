"""Verifie le rapport H1 v2 : extraits entre guillemets francais et droits contre le JSON ; table A a M."""
import json, re, sys, unicodedata
rap, js = sys.argv[1], sys.argv[2]
t = open(rap, encoding='utf-8').read()
def n(s):
    s = unicodedata.normalize('NFKC', s)
    for c in '‘’': s = s.replace(c, "'")
    return re.sub(r'\s+', ' ', s).strip()
cits = [n(c['citation']) for c in json.load(open(js, encoding='utf-8'))]
fr = re.findall(r'«\s*(.+?)\s*»', t, flags=re.S)
ok_ex = ok_sub = 0; autres = []
for s in fr:
    s2 = n(s)
    if s2 in cits: ok_ex += 1
    elif any(s2 in c for c in cits): ok_sub += 1
    else: autres.append(s2)
print(f"guillemets francais : {len(fr)} ; identiques a une citation : {ok_ex} ; sous-chaine : {ok_sub} ; hors JSON : {len(autres)}")
for s in sorted(set(autres)): print("  HORS JSON :", s[:110])
dr = re.findall(r'"([^"\n]+)"', t)
print("guillemets droits :", dr)
lettres = re.findall(r'^\| ([A-Z]) — ', t, flags=re.M)
print("lettres de la table :", lettres, "OK" if lettres == list("ABCDEFGHIJKLM") else "ECART")
for ligne in t.splitlines():
    m = re.match(r'^\| ([A-M]) — .*?\| (\w+) \| (corrigé|réserve maintenue) \|', ligne)
    if ligne.startswith('| ') and re.match(r'^\| [A-M] — ', ligne) and not m: print("LIGNE MAL FORMEE :", ligne[:80])
