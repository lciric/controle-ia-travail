# Journal du lecteur (modele A), lot 4-B partie 2, v1

Debut de session : Sat Nov 14 00:04:22 UTC 2026 (date -u, premiere commande).
Ecriture du journal : Sat Nov 14 00:09:55 UTC 2026

## Verifications
- Consigne commune compte 2 : sha256 cb0623c4aff841a815dc628691f407308acbeeeceb274db96d1f2ba3c8c77ff5 (conforme), lue en entier (41 lignes).
- Interdits communs v2 (docs/notes/g0-deux-semaines-v1/consignes-mere-2026-11-10-0500-v1/interdits-communs-v2.md) lus en entier (21 lignes) ; le plus strict tenu (aucune commande git).
- 2608.08975v1.pdf : sha256 cea31a07b3d124be3cb87c6193feaee8924f167a9ae3f8d2cb9ba29995924d01 = compagnon .sha256 ; 63 pages.
- 2611.10791v1.pdf : sha256 5465764cf2de6501d7256d712d0bd9cd11fbf93a700dce02d5c900e3527ab4ac = compagnon .sha256 ; 38 pages.
- Le dossier des pieces contient d'autres PDF (dont les quatre lus par l'autre session) : non ouverts ; seul un `ls` du dossier a montre leurs noms.

## Fichiers du depot lus (aux lignes indiquees)
- docs/decisions/decision-N-065-v1.md : 1-29 (entier).
- docs/decisions/decision-N-067-v1.md : titres par grep -n '^#' ; sections 0 (l. 9-26), 2 (l. 35-47), 3 (l. 48-71), 4 (l. 72-87), 5 (l. 88-93). Les sections ne sont pas decoupees par revendication : ces cinq sections portent O2, O4 et le nul des lois connues (avec O1, O3, O11, O12, O17 melees).
- docs/etat-de-l-art/etat-de-l-art-verifie-niveau3-v1.md : l. 464-522.
- docs/etat-de-l-art/etat-de-l-art-verifie-niveau3-v1-contre-lecture-v1.md : l. 607-634.

## Etendue lue par PDF
- 2611.10791v1 : p. 1-38 lues ligne a ligne (pdftotext -layout) ; p. 2 vue aussi en image (figure 1, bande dessinee) ; figures p. 6, 10, 11, 23, 30, 31, 32, 33 lues par leur texte extrait et legendes.
- 2608.08975v1 : p. 1-63 lues ligne a ligne (pdftotext -layout) ; p. 37-46 (tableaux 27, 28, 29 : decompositions numeriques par modele, plage et dimension) d'abord parcourues par en-tetes, puis lues ligne a ligne apres la reprise ; p. 2-3 vues aussi en image (figures 1 et 2) ; figure 5 (p. 24) lue par ses valeurs extraites, legende comprise.
- Recherche de termes page par page dans les deux textes extraits (statistic, oracle, ground truth, verif, executab, p-value, null, hypothes, dose, intensity, continuous, automated research, research agent, AI Scientist, hidden environment, replicat, test) : aucun juge statistique, oracle ou verite terrain soumis a l'attaque.

## Controle des citations
- Script verifier_citations.py teste d'abord sur un cas juste (ok, code 0) et sur deux cas alteres (mot change ; mauvaise page) : 2 echecs attendus, code 1.
- Premier passage du JSON : 60 citations, 2 echecs (cesure d'un mot compose p. 19 ; cesure d'un titre p. 15) ; citations corrigees sur le texte de la page, pas sur le script.
- Passage final : 62 citations, 0 echec (controle-citations-sortie.txt).

## Ouvertures fautives, refus
- Aucune ouverture fautive ; aucun refus de permission ; aucun appel reseau ni de modele ; aucune commande git.

## Reprise apres redemarrage du conteneur
- Message du coordinateur : lecture interrompue avant scellement ; rien de verse.
- Sat Nov 14 00:12:27 UTC 2026 : ls du seul dossier compte-2 : aucun rapport-4B-partie2-v1.md ni fichiers-de-travail-4B-partie2-v1.tar. Dossier de travail intact (scripts, JSON, journal, textes extraits) ; empreintes des deux PDF reverifiees, conformes.
- Lecture completee : p. 37-46 de 2608.08975 lues ligne a ligne. Controle des citations relance sur la version finale du JSON (voir controle-citations-sortie.txt).
- Sat Nov 14 00:14:32 UTC 2026 : JSON final de 64 citations (deux ajoutees pour des extraits du rapport), controle relance : 64 citations, 0 echec. verifier_guillemets.py : chaque extrait anglais entre guillemets du rapport est une entree exacte du JSON (les seuls extraits absents sont en francais).
