import json, re, sys
rapport, js = sys.argv[1], sys.argv[2]
cits = [c["citation"] for c in json.load(open(js, encoding="utf-8"))]
txt = open(rapport, encoding="utf-8").read()
n = bad = 0
for m in re.findall(r"«\s*(.*?)\s*»", txt, flags=re.S):
    m = re.sub(r"\s+", " ", m)
    n += 1
    if m in cits:
        st = "exact"
    elif any(m in c for c in cits):
        st = "SOUS-CHAINE"
    else:
        st = "ABSENT"; bad += 1
    if st != "exact":
        print(st, "|", m[:90])
print(f"{n} extraits entre guillemets ; {bad} absents")
