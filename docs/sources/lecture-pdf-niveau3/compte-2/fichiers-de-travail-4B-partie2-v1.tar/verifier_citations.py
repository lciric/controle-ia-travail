"""Controle des citations du lot 4-B, partie 2 (lecteur, modele A).

Usage : python3 -I verifier_citations.py DOSSIER_PDF FICHIER_JSON

Pour chaque citation {pdf, sha256, page, citation} :
- verifie l'empreinte du PDF ;
- extrait la page par pdftotext (avec et sans -layout) ;
- normalise (ligatures, apostrophes, guillemets, tirets, espaces insecables,
  cesures en fin de ligne, espaces) et cherche la citation dans le texte.
Sortie : une ligne par citation, puis le compte des echecs ; code 1 si echec.
"""
import hashlib
import json
import re
import subprocess
import sys
import unicodedata

LIGATURES = {"ﬀ": "ff", "ﬁ": "fi", "ﬂ": "fl", "ﬃ": "ffi", "ﬄ": "ffl"}
APOS = "‘’‚‛′´`"
QUOTES = "“”„‟«»"
DASHES = "‐‑‒–—―−"


def normaliser(texte, cesure):
    texte = unicodedata.normalize("NFKC", texte)
    for k, v in LIGATURES.items():
        texte = texte.replace(k, v)
    for c in APOS:
        texte = texte.replace(c, "'")
    for c in QUOTES:
        texte = texte.replace(c, '"')
    for c in DASHES:
        texte = texte.replace(c, "-")
    texte = texte.replace(" ", " ").replace(" ", " ")
    if cesure:
        texte = re.sub(r"-\s*\n\s*", "", texte)
    texte = re.sub(r"\s+", " ", texte)
    return texte.strip()


def extraire(pdf, page, layout):
    cmd = ["pdftotext"] + (["-layout"] if layout else []) + ["-f", str(page), "-l", str(page), pdf, "-"]
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout


def sha256(chemin):
    h = hashlib.sha256()
    with open(chemin, "rb") as f:
        for bloc in iter(lambda: f.read(1 << 20), b""):
            h.update(bloc)
    return h.hexdigest()


def main():
    dossier, fichier = sys.argv[1], sys.argv[2]
    with open(fichier, encoding="utf-8") as f:
        citations = json.load(f)
    empreintes = {}
    echecs = 0
    for i, c in enumerate(citations, 1):
        chemin = dossier.rstrip("/") + "/" + c["pdf"]
        if chemin not in empreintes:
            empreintes[chemin] = sha256(chemin)
        if empreintes[chemin] != c["sha256"]:
            print(f"{i:03d} ECHEC empreinte {c['pdf']}")
            echecs += 1
            continue
        trouve = False
        for layout in (True, False):
            brut = extraire(chemin, c["page"], layout)
            for cesure in (False, True):
                if normaliser(c["citation"], cesure) in normaliser(brut, cesure):
                    trouve = True
                    break
            if trouve:
                break
        statut = "ok" if trouve else "ECHEC"
        if not trouve:
            echecs += 1
        print(f"{i:03d} {statut} {c['pdf']} p.{c['page']} : {c['citation'][:70]}")
    print(f"TOTAL {len(citations)} citations, {echecs} echec(s)")
    sys.exit(1 if echecs else 0)


if __name__ == "__main__":
    main()
