"""Contrôle des citations : chaque citation doit figurer dans le texte de sa page,
extrait par pdftotext avec et sans -layout, après normalisation.
Usage : python3 -I controle_citations_v1.py CITATIONS.json DOSSIER_PDF
Sortie : une ligne par citation (OK / ECHEC), puis le total ; code de retour 1 si un échec."""
import json, sys, subprocess, unicodedata, re, hashlib, os

LIG = {"ﬀ":"ff","ﬁ":"fi","ﬂ":"fl","ﬃ":"ffi","ﬄ":"ffl","ﬅ":"st","ﬆ":"st"}
APOS = "‘’‚‛′´`"
QUOT = "“”„‟″«»"
DASH = "‐‑‒–—―−﹘﹣－"

def norm(t):
    t = unicodedata.normalize("NFKC", t)
    for k, v in LIG.items(): t = t.replace(k, v)
    for c in APOS: t = t.replace(c, "'")
    for c in QUOT: t = t.replace(c, '"')
    for c in DASH: t = t.replace(c, "-")
    t = t.replace("­", "")
    # césure en fin de ligne : « mot-\n suite » -> « motsuite »
    t = re.sub(r"(\w)-[ \t]*\n[ \t]*(\w)", r"\1\2", t)
    t = re.sub(r"\s+", " ", t)
    return t.strip().lower()

def norm_compact(t):
    # variante sans espaces ni tirets (colonnes entrelacées, césures ambiguës)
    return re.sub(r"[\s\-]", "", norm(t))

def page_texts(pdf, page):
    out = []
    for opts in (["-layout"], []):
        r = subprocess.run(["pdftotext", *opts, "-f", str(page), "-l", str(page), pdf, "-"],
                           capture_output=True, text=True, check=True)
        out.append(r.stdout)
    return out

def check(cit, pdfdir):
    pdf = os.path.join(pdfdir, cit["pdf"])
    h = hashlib.sha256(open(pdf, "rb").read()).hexdigest()
    if h != cit["sha256"]:
        return False, "empreinte differente"
    texts = page_texts(pdf, cit["page"])
    q = norm(cit["citation"]); qc = norm_compact(cit["citation"])
    for t in texts:
        if q in norm(t): return True, "exacte normalisee"
    # second niveau : sans espaces ni tirets (texte en deux colonnes, mise en page)
    for t in texts:
        if qc in norm_compact(t): return True, "compacte"
    return False, "absente"

def main():
    cits = json.load(open(sys.argv[1], encoding="utf-8")); pdfdir = sys.argv[2]
    n_ok = 0
    for i, c in enumerate(cits, 1):
        ok, why = check(c, pdfdir)
        n_ok += ok
        print(f"{i:02d} p.{c['page']:>2} {'OK   ' if ok else 'ECHEC'} [{why}] {c['citation'][:70]}")
    print(f"TOTAL {len(cits)} citations, {n_ok} OK, {len(cits)-n_ok} echec(s)")
    sys.exit(0 if n_ok == len(cits) else 1)

if __name__ == "__main__":
    main()
