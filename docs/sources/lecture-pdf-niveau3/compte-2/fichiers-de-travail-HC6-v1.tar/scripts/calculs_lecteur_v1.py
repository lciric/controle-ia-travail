"""Calculs du lecteur sur les valeurs imprimées (Tableau 6, apparié ; Tableau 4) de 2608.11247v1."""
import numpy as np
from scipy import stats
# Tableau 6, questions appariées : (Res, Rec) par jeu ; ordre : aucune, DA, QD, EP, Refl, Anch, Reasoning
T6 = {
 "MMLU": [(74.9,59.6),(76.4,55.9),(80.0,53.8),(79.4,50.1),(82.8,44.3),(79.8,48.9),(77.5,61.8)],
 "GPQA": [(41.1,70.0),(40.3,66.3),(44.9,64.6),(49.1,59.2),(49.4,54.0),(45.7,58.8),(45.8,60.0)],
 "SimpleQA": [(17.8,94.3),(17.9,93.3),(19.6,93.7),(23.2,87.9),(27.8,86.3),(22.9,88.7),(23.7,86.9)],
}
for k,v in T6.items():
    a=np.array(v); snap=a[:6]; res,rec=snap[:,0],snap[:,1]
    sl,ic,r,p,se=stats.linregress(rec,res)
    gap=a[6,0]-(ic+sl*a[6,1])
    # ajustement sans Anchored (indice 5), résidu de Anchored
    m=[0,1,2,3,4]; sl2,ic2,r2,_,_=stats.linregress(rec[m],res[m])
    resid_anch=res[5]-(ic2+sl2*rec[5])
    resid_sd=np.std(res[m]-(ic2+sl2*rec[m]),ddof=2)
    print(f"{k}: pente {sl:.3f} R2 {r**2:.3f} ; ecart raisonnement {gap:+.2f} ; sans Anchored : pente {sl2:.3f} R2 {r2**2:.3f}, residu Anchored {resid_anch:+.2f} (ecart-type residuel des 5 autres {resid_sd:.2f})")
# Tableau 4 : conformité unanime (MMLU, GPQA, SQA)
T4=[(83.7,97.6,65.9),(59.0,93.8,80.0),(58.5,96.0,84.3),(56.9,88.7,90.1),(31.6,75.2,84.8),(26.9,61.9,93.1),(25.7,72.9,69.1),(21.7,70.8,91.5),(21.5,76.0,78.9),(19.7,58.7,79.6),(19.5,49.6,80.5),(18.8,59.4,77.6),(16.1,57.6,55.0),(13.4,50.3,55.9),(9.2,38.9,68.3),(8.8,28.0,76.3),(8.7,42.0,57.2),(6.0,30.2,61.1),(5.7,38.7,65.1),(5.1,21.7,57.6),(3.4,23.9,43.8),(2.6,17.7,53.3),(1.8,10.1,63.0)]
b=np.array(T4); print("n modeles",len(b))
for (i,j,n) in [(0,1,"MMLU-GPQA"),(0,2,"MMLU-SQA"),(1,2,"GPQA-SQA")]:
    print(n,"Spearman %.3f"%stats.spearmanr(b[:,i],b[:,j]).correlation, "Pearson %.3f"%stats.pearsonr(b[:,i],b[:,j])[0])
# rapport Receptivité perdue / Résistance gagnée pour Reflection (Tableau 2)
print("Reflection MMLU %.2f GPQA %.2f"%(15.3/7.9,16.0/8.3))
