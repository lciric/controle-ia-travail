# Journal du lecteur — HC6 contre 2608.11247v1 (modèle A)

Entrée écrite à 2026-11-13 23:09:03 UTC (heure relevée par date -u dans la même commande). Début de session relevé à 2026-11-13 23:04:25 UTC (date -u).

## Fichiers ouverts (et seulement eux)
1. docs/sources/lecture-pdf-niveau3/compte-2/consignes-compte-2-v1/consigne-lecteur-compte-2-v1.md — en entier ; sha256 cb0623c4aff841a815dc628691f407308acbeeeceb274db96d1f2ba3c8c77ff5, conforme à l'attendu.
2. docs/notes/g0-deux-semaines-v1/consignes-mere-2026-11-10-0500-v1/interdits-communs-v2.md — en entier (exigé par la consigne commune) ; tenu le plus strict : aucune commande git du tout.
3. docs/programme-controle-ia-v2.md, lignes 85-125 et 190-215.
4. docs/decisions/decision-N-005-N-006-v1.md, lignes 22-56.
5. docs/decisions/decision-N-013-v1.md, lignes 86-95.
6. docs/etat-de-l-art/niveau2-v1/anteriorite-v1.md, lignes 313-325.
7. docs/etat-de-l-art/etat-de-l-art-verifie-niveau3-v1.md, lignes 449-463.
8. docs/etat-de-l-art/etat-de-l-art-verifie-niveau3-v1-contre-lecture-v1.md, lignes 558-575.
9. Pièce : scratchpad/pieces-10016a61/docs/sources/pdf/niveau3-v1/lot10/2608.11247v1.pdf et son compagnon .sha256.
Aucune recherche récursive dans le dépôt, aucune commande git, aucun réseau, aucun appel de modèle. Aucun fichier interdit ouvert.

## Empreinte de la pièce
- compagnon : 698fdcbd01ed6141535b76012d5aaced574691a8fba192f7e65020987e46f8f9
- recalculée : 698fdcbd01ed6141535b76012d5aaced574691a8fba192f7e65020987e46f8f9 — conforme.
- pdfinfo : 17 pages, A4 ; titre « Conformity Mitigations in Large Language Models Lie on a Single Resistance-Receptivity Frontier ».

## Étendue lue (2608.11247v1, 17 pages)
- Extraction page à page par pdftotext -layout et sans -layout (textes dans textes/, exclus de l'archive).
- Lues ligne à ligne : pages 1 à 9 (corps, discussion, conclusion, limites), 12 (tableau 4 et annexe B), 13 (tableaux 5, 6, 7), 14 (tableaux 8, 9, 10, annexes E et F), 15 (annexes F.1, F.2, G, tableaux 11, 12), 16 (annexe H), 17 (annexes I, J, tableau 13).
- Parcourues par mots : pages 9 (colonne droite), 10 et 11 (références ; colonne droite de la page 11 : début de l'annexe A lue ligne à ligne).
- Lues sur l'image (outil Read avec pages) : 2 (figure 1), 5 (figures 2, 3), 6 (figure 4), 7 (figure 5, tableaux 2, 3), 15 (figure 7, tableaux 11, 12), 16 (figure 8).
- Recherche de mots dans les textes extraits (adversar, optimi, attack, robust, monitor, judge, predict, jailbreak, adaptive, manipulat, benign, safety, oversight, correlat, Spearman, held-out) : « optimi » seulement page 2 (Khan et al.) ; « adaptive » seulement page 11 (titre d'une référence) ; « robust » pages 9 et 15 (robustesse à la paraphrase, robustesse de l'écart au groupe de modèles) ; aucune occurrence de adversar, attack, monitor, jailbreak, manipulat, benign, safety, oversight.

## Calculs du lecteur (scripts/calculs_lecteur_v1.py, valeurs imprimées des tableaux 4 et 6)
MMLU: pente -0.484 R2 0.876 ; ecart raisonnement +3.31 ; sans Anchored : pente -0.502 R2 0.886, residu Anchored -0.83 (ecart-type residuel des 5 autres 1.21)
GPQA: pente -0.588 R2 0.801 ; ecart raisonnement -0.55 ; sans Anchored : pente -0.623 R2 0.832, residu Anchored -1.76 (ecart-type residuel des 5 autres 2.03)
SimpleQA: pente -1.062 R2 0.904 ; ecart raisonnement -1.87 ; sans Anchored : pente -1.095 R2 0.912, residu Anchored -0.99 (ecart-type residuel des 5 autres 1.46)
n modeles 23
MMLU-GPQA Spearman 0.968 Pearson 0.890
MMLU-SQA Spearman 0.740 Pearson 0.485
GPQA-SQA Spearman 0.652 Pearson 0.626
Reflection MMLU 1.94 GPQA 1.93
- Lecture : les R2 imprimés (0,88 ; 0,80 ; 0,90), les écarts du raisonnement (+3,3 ; -0,6 ; -1,9) et les Spearman entre jeux (0,97 ; 0,74 ; 0,65) sont retrouvés. Anchored retiré de l'ajustement retombe à moins d'un écart-type résiduel de la droite des cinq autres points.

## Contrôle des citations
- Script scripts/controle_citations_v1.py, lancé par python3 -I.
- Cas juste (test-juste-v1.json) : 2 sur 2 OK, code 0. Cas altéré (test-altere-v1.json : mot changé, mauvaise page, empreinte fausse) : 3 échecs sur 3, code 1.
- citations-HC6-v1.json : 49 citations, 49 OK, 0 échec (47 au niveau « exacte normalisée », 2 au niveau « compacte » sans espaces ni tirets : n° 17 p. 4 et n° 40 p. 9, mots composés coupés en fin de ligne). Sortie : controle-citations-v1.txt.
- Note : calculs_lecteur_v1.py lancé par l'interpréteur du .venv du dépôt avec -I (scipy absent de python3 système) ; aucun fichier du dépôt importé.
- Fin de rédaction, avant archivage et scellement : 2026-11-13 23:11:00 UTC (date -u). Rapport : numéros de ligne cités vérifiés (programme l. 108 et 199 ; N-013 l. 90 ; N-005 l. 24-31, formule l. 28 ; niveau 3 l. 453) ; toutes les citations anglaises du rapport sont des sous-chaînes de citations contrôlées.
