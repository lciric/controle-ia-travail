#' @title The Pearson chi-squared test for association in 2x2 tables
#' @description The Pearson chi-squared test for association in 2x2 tables
#' @description with continuity correction
#' @description Described in Chapter 4 "The 2x2 Table"
#' @param n the observed counts (a 2x2 matrix)
#' @examples
#' # Example: A lady tasting a cup of tea
#' Pearson_chi_squared_test_CC_2x2(tea)
#'
#' # Example: Perondi et al. (2004)
#' Pearson_chi_squared_test_CC_2x2(perondi_2004)
#'
#' # Example: Lampasona et al. (2013)
#' Pearson_chi_squared_test_CC_2x2(lampasona_2013)
#'
#' # Example: Ritland et al. (2007)
#' Pearson_chi_squared_test_CC_2x2(ritland_2007)
#'
#' @export
#' @inheritSection chap4 Table orientation
#' @return An object of the [contingencytables_result] class,
#' basically a subclass of [base::list()]. Use the [utils::str()] function
#' to see the specific elements returned.
Pearson_chi_squared_test_CC_2x2 <- function(n) {
  validateArguments(mget(ls()))

  n1p <- n[1, 1] + n[1, 2]
  n2p <- n[2, 1] + n[2, 2]
  np1 <- n[1, 1] + n[2, 1]
  np2 <- n[1, 2] + n[2, 2]
  N <- sum(n)

  # The Pearson chi-squared statistic
  T0 <- (N * max(0, (abs(n[1, 1] * n[2, 2] - n[1, 2] * n[2, 1]) - (N / 2)))^2) / (n1p * n2p * np1 * np2)

  # The two-sided P-value (reference distribution: chi-squared with 1 degree of freedom)
  df <- 1
  P <- pchisq(T0, df, lower.tail = FALSE)

  # Handle cases where the P-value is not computable
  if (is.na(P) || (n[1, 1] == 0 && n[2, 1] == 0) || (n[1, 2] == 0 && n[2, 2] == 0)) {
    P <- 1.0
  }

  return(
    contingencytables_result(
      list("Pvalue" = P, "T" = T0, "df" = df),
      sprintf("The Pearson chi-squared test: P = %7.5f, T = %5.3f (df = %i)", P, T0, df)
    )
  )
}
