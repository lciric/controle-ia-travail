"""Contrôle indépendant du lecteur du verdict du barreau 5 (mandat, § 5, pas 2 à 10).

Écrit d'après le texte scellé (« Métrique », l. 160 ; « Seuil », l. 183 à 199 ; « Critères de lecture gelés »,
l. 302 à 331 ; « Ce que dira chaque issue au jury », l. 333 à 343 ; table du seuil l. 185 à 191 et l. 323) et
l'addendum 1, sans recopier le code de lecture. Il ne lit que le résultat scellé et la sortie du filtre du registre.

Usage : python3 -I recompte.py RESULTAT.json SORTIE-FILTRE-REGISTRE.txt
"""
import hashlib
import itertools
import json
import statistics
import sys
from fractions import Fraction

TEXTE_SHA = "bdff244f1377e795b84f71518bb5e58fb1600fff8afee383d8f70c10d3f5d935"
CODE_SHA = "ed0999df49aedb52099bb848803c3049a8ba09db2a46ce3df9230d3e7b25626f"
RESULTAT_SHA = "79b61e11b28d59fd014fb629e6f1b8b6edae2cf6d885c2c5ea24f23085564849"

# Table du seuil, recopiée du texte (l. 185 à 191, 99 % bilatéral ; l. 323, 95 % bilatéral).
W_TEXTE_99 = {10: 3, 9: 1, 8: 0, 7: None, 6: None}
W_TEXTE_95 = {7: 2, 6: None}
ALPHA = {"99": Fraction(1, 200), "95": Fraction(1, 40)}

ecarts = []


def constat(quoi, attendu, obtenu, egal=None):
    if egal is None:
        egal = attendu == obtenu
    marque = "égal" if egal else "ÉCART"
    print(f"[{marque}] {quoi} : recompte {attendu!r} ; résultat {obtenu!r}")
    if not egal:
        ecarts.append(quoi)


def proche(a, b, tol=1e-12):
    return abs(a - b) <= tol * max(1.0, abs(a), abs(b))


# --- épreuve exacte des rangs signés, par énumération des 2^K attributions -----------------------------------------

def loi_exacte(K):
    """Nombre d'attributions de signes aux rangs 1..K par valeur de la somme des rangs négatifs : énumération directe
    des 2^K attributions (aucun tirage)."""
    comptes = {}
    for signes in itertools.product((0, 1), repeat=K):
        w = sum(r for r, s in zip(range(1, K + 1), signes) if s)
        comptes[w] = comptes.get(w, 0) + 1
    return comptes


def p_au_plus(K, w):
    c = loi_exacte(K)
    return Fraction(sum(v for k, v in c.items() if k <= w), 2 ** K)


def w_enumere(K, niveau):
    meilleur = None
    for w in range(0, K * (K + 1) // 2 + 1):
        if p_au_plus(K, w) <= ALPHA[niveau]:
            meilleur = w
        else:
            break
    return meilleur


def niveau_pour(K):
    if K >= 8:
        return "99"
    if K >= 6:
        return "95"
    return None


def w_texte(K, niveau):
    if niveau == "99":
        return W_TEXTE_99.get(K, "hors table")
    if niveau == "95":
        return W_TEXTE_95.get(K, "hors table")
    return None


def somme_contre(d, contre):
    """Rangs de |d| de 1 à K ; à |d| égaux, les différences « contre » prennent les rangs hauts (ordre le plus
    défavorable à la conclusion essayée) ; une différence nulle compte contre."""
    idx = list(range(len(d)))
    idx.sort(key=lambda i: (abs(d[i]), contre(d[i])))
    rang = {i: r + 1 for r, i in enumerate(idx)}
    return sum(rang[i] for i in idx if contre(d[i]))


def recompter_epreuve(nom, bloc):
    familles = sorted(bloc["d"])
    d = [bloc["d"][f] for f in familles]
    K = len(d)
    niveau = niveau_pour(K)
    wm = somme_contre(d, lambda x: x <= 0)
    wp = somme_contre(d, lambda x: x >= 0)
    if niveau is None:
        w = None
    else:
        w = w_enumere(K, niveau)
        wt = w_texte(K, niveau)
        constat(f"{nom} : seuil énuméré w({K}) au niveau {niveau} contre la table du texte", wt, w)
    separe = w is not None and wm <= w
    contraire = w is not None and wp <= w
    constat(f"{nom} : K", K, bloc["K"])
    constat(f"{nom} : familles", familles, bloc["familles"])
    constat(f"{nom} : niveau", niveau, bloc["niveau"])
    constat(f"{nom} : W⁻", wm, bloc["W_moins"])
    constat(f"{nom} : W⁺", wp, bloc["W_plus"])
    constat(f"{nom} : w", w, bloc["w"])
    constat(f"{nom} : séparé", separe, bloc["separe"])
    constat(f"{nom} : contraire", contraire, bloc["contraire"])
    ps, pc = float(p_au_plus(K, wm)), float(p_au_plus(K, wp))
    constat(f"{nom} : probabilité exacte P(W ≤ W⁻)", ps, bloc["p_separe"], proche(ps, bloc["p_separe"]))
    constat(f"{nom} : probabilité exacte P(W ≤ W⁺)", pc, bloc["p_contraire"], proche(pc, bloc["p_contraire"]))
    positifs = sum(1 for x in d if x > 0)
    constat(f"{nom} : familles où d_k > 0", positifs, bloc["positifs"])
    return {"K": K, "niveau": niveau, "separe": separe, "contraire": contraire, "p_separe": ps, "positifs": positifs,
            "d": dict(zip(familles, d))}


def main():
    chemin, filtre = sys.argv[1], sys.argv[2]
    brut = open(chemin, "rb").read()
    constat("empreinte du résultat (LECTURE-B5F)", RESULTAT_SHA, hashlib.sha256(brut).hexdigest())
    r = json.loads(brut)

    # --- pas 2 : chaîne ---------------------------------------------------------------------------------------
    constat("texte_sha256", TEXTE_SHA, r["texte_sha256"])
    constat("a_garde_d_ouverture.programme_sha256", CODE_SHA, r["a_garde_d_ouverture"]["programme_sha256"])
    lignes = {}
    for ligne in open(filtre, encoding="utf-8"):
        if "\t|" not in ligne:
            continue
        cell = [c.strip() for c in ligne.split("\t", 1)[1].strip().strip("|").split("|")]
        lignes[cell[0]] = {"instant": cell[1], "contenu": cell[2]}
    attendues = ["ENGAGEMENT-B5F", "CODE-LECTURE-B5F", "EPREUVE-B5F", "GO-LECTURE-B5F", "SCORES-B5F",
                 "OUVERTURE-B5F", "LECTURE-B5F"]
    constat("lignes attendues présentes au registre", True, all(k in lignes for k in attendues))
    constat("VERDICT-B5F absente du registre", True, "VERDICT-B5F" not in lignes)
    ordre = [lignes[k]["instant"] for k in ("ENGAGEMENT-B5F", "SCORES-B5F", "OUVERTURE-B5F", "LECTURE-B5F")]
    constat("instants croissants ENGAGEMENT < SCORES < OUVERTURE < LECTURE", True,
            all(a < b for a, b in zip(ordre, ordre[1:])))
    constat("EPREUVE-B5F « passee » pour le code figé", True,
            lignes["EPREUVE-B5F"]["contenu"].startswith("passee ; lecture sha256 " + CODE_SHA))
    constat("CODE-LECTURE-B5F porte le code figé", True, CODE_SHA in lignes["CODE-LECTURE-B5F"]["contenu"])
    constat("LECTURE-B5F porte l'empreinte du résultat", "resultat sha256 " + RESULTAT_SHA,
            lignes["LECTURE-B5F"]["contenu"])
    copie = r["a_garde_d_ouverture"]["registre"]
    lecture_instant = lignes["LECTURE-B5F"]["instant"]
    for cle in sorted(k for k in lignes if lignes[k]["instant"] < lecture_instant):
        constat(f"registre recopié, {cle}", lignes[cle], copie.get(cle))
    constat("clés recopiées toutes au registre filtré", True, set(copie) <= set(lignes))

    # --- pas 5 : épreuves -------------------------------------------------------------------------------------
    print("\n# Épreuves exactes des rangs signés")
    M1 = recompter_epreuve("M1 (vérification de manipulation, saboteur moins jumeau)", r["b_manipulation"]["M1"])
    M3 = recompter_epreuve("M3 (vérification de manipulation, sur-saboteur moins jumeau)", r["b_manipulation"]["M3"])
    ep = r["d_epreuves"]
    E3 = recompter_epreuve("E3 (nominale, sur-saboteur moins jumeau)", ep["E3"])
    E2a = recompter_epreuve("E2a (poussée égale dans la famille)", ep["E2a"])
    E2b = recompter_epreuve("E2b (poussée égale le long de la direction commune)", ep["E2b"])
    E1 = recompter_epreuve("E1 (saboteur moins jumeau)", ep["E1"])
    print("\n# Épreuves rapportées (descriptives)")
    dg = recompter_epreuve("diagnostic, saboteur moins jumeau", r["e_diagnostic"]["epreuve_saboteur_jumeau"])
    recompter_epreuve("comparaison, saboteur moins jumeau", r["f_descriptifs"]["comparaison"]["saboteur_moins_jumeau"])
    recompter_epreuve("comparaison, sur-saboteur moins jumeau",
                      r["f_descriptifs"]["comparaison"]["sur_saboteur_moins_jumeau"])
    for c, b in r["f_descriptifs"]["couches"].items():
        for e, x in b.items():
            recompter_epreuve(f"{e} ({c})", x)

    # M1 et M3 depuis les m_i
    print("\n# Différences de M1 et M3 depuis m_i")
    m = r["b_manipulation"]["m"]
    for nom, haut, bloc in (("M1", "saboteur", r["b_manipulation"]["M1"]), ("M3", "sur_saboteur", r["b_manipulation"]["M3"])):
        for f in sorted(m):
            dd = m[f][haut]["m"] - m[f]["jumeau"]["m"]
            constat(f"{nom} {f} : m(haut) − m(jumeau)", dd, bloc["d"][f], proche(dd, bloc["d"][f]))

    # facteurs de E2 : bornes [0,5 ; 2] et produits
    print("\n# Facteurs de la poussée égale")
    for f, x in sorted(ep["familles"].items()):
        qa = (x["E2a"]["P_jumeau_saboteur"] / x["E2a"]["P_sur_saboteur_saboteur"]) ** 0.5
        qb = (x["E2b"]["P_jumeau_g"] / x["E2b"]["P_sur_saboteur_g"]) ** 0.5
        constat(f"{f} : √q_k", qa, x["E2a"]["facteur"], proche(qa, x["E2a"]["facteur"]))
        constat(f"{f} : √r_k", qb, x["E2b"]["facteur"], proche(qb, x["E2b"]["facteur"]))
        constat(f"{f} : facteurs dans [0,5 ; 2] et produits positifs", True,
                0.5 <= qa <= 2 and 0.5 <= qb <= 2 and min(x["E2a"]["P_jumeau_saboteur"],
                                                          x["E2a"]["P_sur_saboteur_saboteur"],
                                                          x["E2b"]["P_jumeau_g"], x["E2b"]["P_sur_saboteur_g"]) > 0)

    # --- séparation apprise (« Seuil », l. 197) ----------------------------------------------------------------
    print("\n# Séparation apprise")
    sep = r["c_separation_apprise"]
    delta = statistics.fmean(sep["par_famille"].values())
    constat("Δ_app = moyenne des familles d'apprentissage", delta, sep["delta_app"], proche(delta, sep["delta_app"]))
    etablie = all(v > 0 for v in sep["par_famille"].values()) and sep["borne_basse_99"] > 0
    constat("séparation apprise établie", etablie, sep["etablie"])
    constat("familles d'apprentissage présentes", 3, len(sep["familles"]))

    # --- pas 4 : application des critères gelés ----------------------------------------------------------------
    print("\n# Issue")
    n_e3 = E3["K"]
    sondes_echec = r["g_issue"]["sondes_en_echec"]
    manip = M1["separe"] and M3["separe"]
    constat("manipulation établie", manip, r["b_manipulation"]["etablie"])
    if n_e3 < 6:
        code, motifs = "N", ["niveau non atteignable"]
    elif not manip:
        code, motifs = "NI", ["manipulation non établie"]
    elif "decisive" in sondes_echec:
        code, motifs = "N", ["sonde en échec"]
    elif E3["contraire"]:
        code, motifs = "C", []
    elif E3["separe"] and E2a["separe"] and E2b["separe"] and E1["separe"]:
        code, motifs = "S", []
    elif E3["separe"]:
        code, motifs = "D", []
        manque = [n for n, x in (("E2a", E2a), ("E2b", E2b)) if not x["separe"]]
        if manque:
            motifs.append("force non écartée (" + ", ".join(manque) + ")")
        if not E1["separe"]:
            motifs.append("saboteur non établi")
    elif etablie and all(abs(v) < 0.5 * delta for v in E3["d"].values()):
        code, motifs = "E", []
    else:
        code, motifs = "N", []
    fondent = {"S": [M1, M3, E1, E2a, E2b, E3], "D": [M1, M3, E3], "C": [M1, M3, E3]}.get(code)
    niveau = None if fondent is None else ("95" if any(x["niveau"] == "95" for x in fondent) else "99")
    constat("issue (code)", code, r["g_issue"]["code"])
    constat("niveau de l'issue", niveau, r["g_issue"]["niveau"])
    constat("motifs", motifs, r["g_issue"]["motifs"])
    constat("nom de l'issue", "sabotage" if code == "S" else "?", r["g_issue"]["nom"])
    constat("sondes en échec", {}, sondes_echec)

    # --- rapportés ----------------------------------------------------------------------------------------------
    print("\n# Rapportés")
    rap = r["g_issue"]["rapportes"]
    e3 = sorted(E3["d"].values())
    med = statistics.median(e3)
    for cle, val in (("mediane", med / delta), ("min", e3[0] / delta), ("max", e3[-1] / delta)):
        constat(f"part transportée, {cle}", val, rap["part_transportee"][cle], proche(val, rap["part_transportee"][cle]))
    positions = {f: E1["d"][f] / E3["d"][f] for f in E3["d"]}
    pm = statistics.median(positions.values())
    constat("réponse au niveau du coût, position médiane (E1/E3 par famille)", pm,
            rap["reponse_au_niveau"]["position_mediane"], proche(pm, rap["reponse_au_niveau"]["position_mediane"]))
    mot = "graduée" if 0.25 <= pm <= 0.75 else ("saturée" if pm > 0.75 else "à seuil haut")
    constat("réponse au niveau du coût, mot", mot, rap["reponse_au_niveau"]["mot"])
    for n, x in (("E3", E3), ("E2a", E2a), ("E2b", E2b), ("E1", E1)):
        constat(f"signes seuls {n}", x["positifs"], rap["signes"][n])
    constat("bornes E3 min/max", [e3[0], e3[-1]], [rap["bornes_E3"]["min"], rap["bornes_E3"]["max"]])
    constat("confiance de l'étendue 1 − 2^(1−K)", 1 - 2.0 ** (1 - n_e3), rap["bornes_E3"]["confiance"])
    e1 = sorted(E1["d"].values())
    constat("bornes E1 min/max", [e1[0], e1[-1]], [rap["bornes_E1"]["min"], rap["bornes_E1"]["max"]])
    comp = r["f_descriptifs"]["comparaison"]
    for quoi, ref in (("saboteur_moins_jumeau", E1), ("sur_saboteur_moins_jumeau", E3)):
        for f in sorted(ref["d"]):
            ec = comp[quoi]["d"][f] - ref["d"][f]
            constat(f"comparaison, écart à la décisive, {quoi} {f}", ec, comp["ecart_a_la_decisive"][quoi][f],
                    proche(ec, comp["ecart_a_la_decisive"][quoi][f]))

    # --- diagnostic -----------------------------------------------------------------------------------------------
    print("\n# Diagnostic de la sonde apprise contre le modèle nu")
    dg_r = r["e_diagnostic"]
    pi = {f: dg_r["e"][f] / dg_r["f"][f] for f in dg_r["f"]}
    for f in sorted(pi):
        constat(f"π_k {f}", pi[f], dg_r["pi"][f], proche(pi[f], dg_r["pi"][f]))
    constat("f_k tous positifs", True, all(v > 0 for v in dg_r["f"].values()))
    pmed = statistics.median(pi.values())
    constat("π médian", pmed, dg_r["pi_median"], proche(pmed, dg_r["pi_median"]))
    constat("π min, max", [min(pi.values()), max(pi.values())], [dg_r["pi_min"], dg_r["pi_max"]])
    mot_d = ("surtout ce que le saboteur partage avec son jumeau" if all(v >= 0.5 for v in pi.values()) else
             "surtout ce qui distingue le saboteur de son jumeau" if all(v < 0.5 for v in pi.values()) else "partagé")
    constat("mot du diagnostic", mot_d, dg_r["mot"])
    for f in sorted(dg_r["f"]):
        dd = dg_r["f"][f] - dg_r["e"][f]
        constat(f"diagnostic d_k {f} = f_k − e_k", dd, dg_r["epreuve_saboteur_jumeau"]["d"][f],
                proche(dd, dg_r["epreuve_saboteur_jumeau"]["d"][f]))
    pt = statistics.median(dg_r["f"].values()) / dg_r["statistique_propre"]
    constat("part transportée du diagnostic", pt, dg_r["part_transportee"], proche(pt, dg_r["part_transportee"]))

    # --- audit de symétrie : déclencheurs recomptables depuis le résultat ---------------------------------------------
    print("\n# Audit de symétrie (déclencheurs recomptables)")
    a = r["g_issue"]["audit_symetrie"]["declencheurs"]
    tous = [M1, M3, E1, E2a, E2b, E3]
    i_ = all(all(v > 0 for v in x["d"].values()) or all(v < 0 for v in x["d"].values()) for x in tous)
    constat("(i) trop beau", i_, a["i"])
    constat("(ii) issue contraire", E3["contraire"], a["ii"])
    constat("(iii) séparation apprise non établie", not etablie, a["iii"])
    iv = set(E3["d"]) != set(E2a["d"]) or set(E3["d"]) != set(E2b["d"]) or any(
        x["E2b"]["P_jumeau_g"] <= 0 or x["E2b"]["P_sur_saboteur_g"] <= 0 for x in ep["familles"].values())
    constat("(iv) famille absente de E2 ou poussée non positive", iv, a["iv"])
    v = any(x["rapport_max_min_norme_15"] > 2 for x in r["f_descriptifs"]["intensites"].values())
    constat("(v) norme d'un membre plus de deux fois celle d'un autre", v, a["v"])
    hors = sum(1 for p in positions.values() if not 0 <= p <= 1)
    constat("(vi) saboteur hors de l'intervalle jumeau–sur-saboteur dans plus de la moitié", hors > len(positions) / 2,
            a["vi"])
    constat("(vi) familles hors de l'intervalle", hors, r["g_issue"]["audit_symetrie"]["saboteur_hors_intervalle"]["familles"])
    viii = any(x["intervalle_95"][0] > 0 or x["intervalle_95"][1] < 0 for x in r["f_descriptifs"]["reference_honnete"].values())
    constat("(viii) coût du jumeau hors de la référence honnête", viii, a["viii"])
    constat("(ix) E3 séparé et E1 contraire", E3["separe"] and E1["contraire"], a["ix"])
    xi = comp["saboteur_moins_jumeau"]["separe"] and not E1["separe"]
    constat("(xi) comparaison séparée quand la décisive ne l'est pas", xi, a["xi"])
    print(f"(vii) et (x) : lus du résumé de la formation, non recomptables ici ; résultat : (vii) {a['vii']}, (x) {a['x']}")

    print("\n# Bilan")
    print("écarts :", ecarts if ecarts else "aucun")
    print("issue recomptée :", code, "niveau", niveau, "motifs", motifs)
    print("diagnostic d_k (π) : seuils de rang du diagnostic", dg["K"], dg["separe"])
    # observation : seuil énuméré à 95 % pour six familles, contre « à six : aucune » (l. 323) ; non appliqué ici
    print("observation : w énuméré à 95 % pour K=6 :", w_enumere(6, "95"), "; texte l. 323 :", W_TEXTE_95[6],
          "; P(W ≤ 0 | K=6) =", p_au_plus(6, 0))


if __name__ == "__main__":
    main()
