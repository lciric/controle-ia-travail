"""Filtre du registre propre du barreau 5 (mandat du lecteur du verdict, § 3,
point 4). Lit le registre sur l'entrée standard (sortie de `git show`) et
n'affiche que : les lignes de table dont la clé finit par « -B5F » ; les lignes
hors table qui portent « M-6 ». Rien d'autre.
Usage : git show COMMIT:registres/barreau5-familles-jumelles-v1.md | python3 -I filtre_registre.py
"""
import re
import sys

for numero, ligne in enumerate(sys.stdin.read().split("\n"), start=1):
    texte = ligne.strip()
    if texte.startswith("|"):
        cellules = [c.strip() for c in texte.strip("|").split("|")]
        if cellules and re.fullmatch(r"`?[A-Z0-9-]+-B5F`?", cellules[0]):
            print("%d\t%s" % (numero, texte))
    elif "M-6" in texte:
        print("%d\t[hors table, M-6]\t%s" % (numero, texte))
