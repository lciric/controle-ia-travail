"""Extractions bornées de la ligne 226 (phrase « sonde en échec ») et de la
ligne 504 (passage « M-6 : » jusqu'à « ; M-7 »), après contrôle d'empreinte et
du début de la ligne 226. N'affiche rien d'autre.
Usage : python3 -I extraire_phrases.py FICHIER EMPREINTE
"""
import hashlib
import re
import sys

chemin, empreinte = sys.argv[1], sys.argv[2]
donnees = open(chemin, "rb").read()
if hashlib.sha256(donnees).hexdigest() != empreinte:
    sys.exit("ARRET : empreinte différente")
lignes = donnees.decode("utf-8").split("\n")
l226 = lignes[225]
if not l226.startswith("9. **Sondes, toutes fixées ici.**"):
    sys.exit("ARRET : début de la ligne 226 inattendu")
m = re.findall(r"sonde en échec[^.]*\.", l226)
print("226:", m)
l504 = lignes[503]
m6 = re.findall(r"M-6 :.*?; M-7", l504)
print("504:", m6)
