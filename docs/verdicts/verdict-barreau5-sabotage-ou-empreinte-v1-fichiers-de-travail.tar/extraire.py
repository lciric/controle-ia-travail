"""Extraction bornée du texte scellé : vérifie l'empreinte, puis que la première
ligne de la plage commence par le titre attendu, avant d'afficher la plage.
Usage : python3 -I extraire.py FICHIER EMPREINTE DEBUT FIN "TITRE ATTENDU"
"""
import hashlib
import sys

chemin, empreinte, debut, fin, titre = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4]), sys.argv[5]
donnees = open(chemin, "rb").read()
if hashlib.sha256(donnees).hexdigest() != empreinte:
    sys.exit("ARRET : empreinte différente")
lignes = donnees.decode("utf-8").split("\n")
premiere = lignes[debut - 1]
if not premiere.startswith(titre):
    sys.exit("ARRET : première ligne inattendue (début : %r)" % premiere[:40])
for n in range(debut, fin + 1):
    print("%d\t%s" % (n, lignes[n - 1]))
