"""Pas 7 du mandat : prend à la lettre la phrase de l'issue S (l. 335) et celle du diagnostic (l. 341) dans le texte
scellé (empreinte vérifiée, début de ligne contrôlé), remplit les crochets par les valeurs du résultat, fait les trois
substitutions de nombres attendues, et compare au champ `g_issue.phrases` du résultat.

Usage : python3 -I phrase_gelee.py TEXTE EMPREINTE RESULTAT.json
"""
import hashlib
import json
import re
import statistics
import sys

NOMBRES = {1: "une", 2: "deux", 3: "trois", 4: "quatre", 5: "cinq", 6: "six", 7: "sept", 8: "huit", 9: "neuf", 10: "dix"}

texte, empreinte, chemin = sys.argv[1], sys.argv[2], sys.argv[3]
brut = open(texte, "rb").read()
if hashlib.sha256(brut).hexdigest() != empreinte:
    sys.exit("ARRET : empreinte")
lignes = brut.decode("utf-8").split("\n")
l335, l341 = lignes[334], lignes[340]
if not l335.startswith("- **S.** « ") or not l341.startswith("- **Diagnostic, dit avec toute issue.** « "):
    sys.exit("ARRET : début de ligne inattendu")
r = json.load(open(chemin, encoding="utf-8"))
ep, dg, ph = r["d_epreuves"], r["e_diagnostic"], r["g_issue"]["phrases"]


def p4(v):
    return f"{v:.4f}".replace(".", ",")


def s3(v):
    return f"{v:.3g}".replace(".", ",")


# --- issue S ---
s = l335[len("- **S.** « "):]
s = s[: s.rindex(" »")]
K = ep["E3"]["K"]
n_app = len(r["c_separation_apprise"]["familles"])
# substitutions attendues (mandat, pas 7) : « dix » familles jamais vues = K de E3 ; « trois autres familles »
s = s.replace("Sur dix familles d'adaptateurs", f"Sur {NOMBRES[K]} familles d'adaptateurs", 1)
s = s.replace("sur trois autres familles", f"sur {NOMBRES[n_app]} autres familles", 1)
s = s.replace("[n] familles sur dix", f"[n] familles sur {NOMBRES[K]}", 1)
s = s.replace("[n]", str(ep["E3"]["positifs"]), 1)
for cle in ("E3", "E2a", "E2b", "E1"):     # ordre des [p] dans la phrase : E3, E2a, E2b, E1
    s = s.replace("[p]", p4(ep[cle]["p_separe"]), 1)
print("crochets restants (issue) :", re.findall(r"\[[^\]]*\]", s))
print("ISSUE remplie :", s)
print("issue égale au résultat, à la lettre :", s == ph["issue"])

# --- diagnostic ---
d = l341[len("- **Diagnostic, dit avec toute issue.** « "):]
d = d[: d.rindex(" »")]
pi = dg["pi"]
d = d.replace("sur dix familles jamais vues", f"sur {NOMBRES[len(pi)]} familles jamais vues", 1)
d = d.replace("[π médian]", s3(statistics.median(pi.values())), 1)
d = d.replace("[min]", s3(min(pi.values())), 1).replace("[max]", s3(max(pi.values())), 1)
branche = {"surtout ce que le saboteur partage avec son jumeau": "surtout ce que le saboteur partage avec son jumeau",
           "surtout ce qui distingue le saboteur de son jumeau": "surtout ce qui distingue le saboteur de son jumeau",
           "partagé": "les deux"}[dg["mot"]]
d = re.sub(r"\[surtout ce que le saboteur partage avec son jumeau \| surtout ce qui distingue le saboteur de son jumeau \| les deux\]",
           branche, d, count=1)
print("crochets restants (diagnostic) :", re.findall(r"\[[^\]]*\]", d))
print("DIAGNOSTIC rempli :", d)
print("diagnostic égal au résultat, à la lettre :", d == ph["diagnostic"])
