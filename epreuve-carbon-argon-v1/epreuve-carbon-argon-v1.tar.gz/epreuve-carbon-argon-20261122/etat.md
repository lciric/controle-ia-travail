| Cellule | Statut | Essais | Modèle servi | Caractères | Marqueur | Coût USD |
|---|---|---|---|---|---|---|
| E3-T1-conception-A | OK | 1 | gemini-4-argon | 53336 | oui | 0.48 |
| E3-T1-conception-B | OK | 1 | gemini-4-carbon | 37732 | oui | 0.79 |
| E3-T2-critique-croisee-A | OK | 1 | gemini-4-argon | 54059 | oui | 0.53 |

Absences acceptées par l'arbitre : aucune.
Refus avant l'envoi : 1 (PLAFOND, détail au journal).
Ligne : 4.00 USD, ouverte à 0.00 USD de dépense ; dépensé sur la ligne : 1.79 USD.
Dépense totale : 1.79 USD. Mis à jour 2026-11-22T17:02:31Z.
