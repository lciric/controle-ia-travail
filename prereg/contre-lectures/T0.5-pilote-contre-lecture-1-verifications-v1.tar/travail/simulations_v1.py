"""Simulations de contre-lecture (non décisives, aucune donnée du programme) :
1. kappa de Cohen sur un sous-échantillon de n paires : distribution de la borne basse de l'intervalle par
   rééchantillonnage (percentiles à 95 %), probabilité de satisfaire « kappa >= 0,6 et borne basse >= 0,4 » ;
2. décomposition de variance de l'annexe C.1 (un générateur) sur n tâches : dispersion de la part du bruit de juge,
   probabilité de franchir 0,8, composantes négatives.
Graines : SeedSequence(20261006) dérivée par simulation (esprit de R9). Lancer : python -I simulations_v1.py
"""
import numpy as np

RACINE = np.random.SeedSequence(20261006)


def kappa(x, y):
    po = np.mean(x == y)
    px, py = x.mean(), y.mean()
    pe = px * py + (1 - px) * (1 - py)
    if pe >= 1.0:
        return np.nan
    return (po - pe) / (1 - pe)


def table(p, k):
    q = p * (1 - p)
    return np.array([p * p + k * q, q * (1 - k), q * (1 - k), (1 - p) ** 2 + k * q])  # (1,1),(1,0),(0,1),(0,0)


def sim_kappa(n, p, k, reps, boots, rng):
    probs = table(p, k)
    bas, points, indefinis, crit = [], [], 0, 0
    for _ in range(reps):
        c = rng.choice(4, size=n, p=probs)
        x = np.isin(c, (0, 1)).astype(int)
        y = np.isin(c, (0, 2)).astype(int)
        kp = kappa(x, y)
        if np.isnan(kp):
            indefinis += 1
            continue
        tirs = []
        for _ in range(boots):
            i = rng.integers(0, n, n)
            v = kappa(x[i], y[i])
            if not np.isnan(v):
                tirs.append(v)
        lb = np.quantile(tirs, 0.025)
        bas.append(lb)
        points.append(kp)
        crit += (kp >= 0.6) and (lb >= 0.4)
    return {"n": n, "p": p, "k": k, "indefini": indefinis / reps,
            "borne_basse_mediane": float(np.median(bas)) if bas else np.nan,
            "P(critere)": crit / reps}


def decomposition(a, b, c):
    eps = np.var(a - b, ddof=1) / 2
    beta = np.cov(a, c, ddof=1)[0, 1]
    delta = np.cov(a, b, ddof=1)[0, 1] - beta
    tot = beta + delta + eps
    return beta, delta, eps, tot


def sim_variance(n, parts, reps, boots, rng):
    sb, sd, se = (np.sqrt(v) for v in parts)
    est, larg, neg_d, neg_b, tot_neg, au_dessus = [], [], 0, 0, 0, 0
    for _ in range(reps):
        beta = rng.normal(0, sb, n)
        d1, d2 = rng.normal(0, sd, n), rng.normal(0, sd, n)
        e1, e2, e3 = rng.normal(0, se, n), rng.normal(0, se, n), rng.normal(0, se, n)
        a, b, c = beta + d1 + e1, beta + d1 + e2, beta + d2 + e3
        bt, dl, ep, tot = decomposition(a, b, c)
        neg_d += dl < 0
        neg_b += bt < 0
        if tot <= 0:
            tot_neg += 1
            continue
        part = ep / tot
        est.append(part)
        au_dessus += part > 0.8
        tirs = []
        for _ in range(boots):
            i = rng.integers(0, n, n)
            bt2, dl2, ep2, tot2 = decomposition(a[i], b[i], c[i])
            if tot2 > 0:
                tirs.append(ep2 / tot2)
        larg.append(np.quantile(tirs, 0.975) - np.quantile(tirs, 0.025))
    return {"n": n, "parts_vraies(beta,delta,eps)": parts, "ecart_type_part_eps": float(np.std(est)),
            "largeur_IC95_mediane": float(np.median(larg)), "P(part>0,8)": au_dessus / reps,
            "P(delta<0)": neg_d / reps, "P(beta<0)": neg_b / reps, "P(total<=0)": tot_neg / reps}


if __name__ == "__main__":
    enfants = RACINE.spawn(2)
    rk = np.random.default_rng(enfants[0])
    print("== kappa (500 répétitions, 500 tirages)")
    for n in (67, 100, 200):
        for p in (0.05, 0.10, 0.20, 0.30):
            for k in (0.6, 0.7, 0.8):
                print(sim_kappa(n, p, k, 500, 500, rk))
    rv = np.random.default_rng(enfants[1])
    print("== décomposition (400 répétitions, 400 tirages)")
    for n in (64, 40):
        for parts in ((0.3, 0.2, 0.5), (0.15, 0.15, 0.7), (0.1, 0.1, 0.8), (0.05, 0.1, 0.85), (0.4, 0.3, 0.3)):
            print(sim_variance(n, parts, 400, 400, rv))
