"""Simulation de contre-lecture (non décisive) : précision de la part du bruit de juge selon le plan de notation.
Plan du brouillon : A noté deux fois (A, B), C une fois ; estimateurs de l'annexe C.1 adaptée.
Plan enrichi : A, C et D notés deux fois ; σ²_ε moyenne des trois demi-variances de différences ; σ²_β moyenne des
trois covariances entre épisodes (premières notations) ; σ²_δ moyenne des covariances entre passes d'un même épisode
moins σ²_β. Graine : SeedSequence(20261006, spawn_key=(2,)). Lancer : python -I simulations_v2.py
"""
import numpy as np

rng = np.random.default_rng(np.random.SeedSequence(20261006, spawn_key=(2,)))


def cov(x, y):
    return np.cov(x, y, ddof=1)[0, 1]


def un_tirage(n, sb, sd, se):
    beta = rng.normal(0, sb, n)
    ep = [rng.normal(0, sd, n) for _ in range(3)]
    notes = [[beta + ep[k] + rng.normal(0, se, n) for _ in range(2)] for k in range(3)]  # [épisode][passe]
    a, b, c = notes[0][0], notes[0][1], notes[1][0]
    eps = np.var(a - b, ddof=1) / 2
    bet = cov(a, c)
    dl = cov(a, b) - bet
    brouillon = eps / (eps + bet + dl)
    eps2 = np.mean([np.var(notes[k][0] - notes[k][1], ddof=1) / 2 for k in range(3)])
    bet2 = np.mean([cov(notes[i][0], notes[j][0]) for i, j in ((0, 1), (0, 2), (1, 2))])
    dl2 = np.mean([cov(notes[k][0], notes[k][1]) for k in range(3)]) - bet2
    enrichi = eps2 / (eps2 + bet2 + dl2)
    return brouillon, enrichi, dl < 0, dl2 < 0


for parts in ((0.3, 0.2, 0.5), (0.15, 0.15, 0.7), (0.1, 0.1, 0.8)):
    s = [np.sqrt(p) for p in parts]
    r = np.array([un_tirage(64, *s) for _ in range(4000)], dtype=float)
    print({"parts_vraies": parts,
           "ecart_type_brouillon": round(float(np.std(r[:, 0])), 3),
           "ecart_type_enrichi": round(float(np.std(r[:, 1])), 3),
           "P(part>0,8) brouillon": round(float(np.mean(r[:, 0] > 0.8)), 3),
           "P(part>0,8) enrichi": round(float(np.mean(r[:, 1] > 0.8)), 3),
           "P(delta<0) brouillon": round(float(np.mean(r[:, 2])), 3),
           "P(delta<0) enrichi": round(float(np.mean(r[:, 3])), 3)})
