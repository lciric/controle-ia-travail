# Journal de l'audit des fuites de T0.7 — v1

Toutes les heures sont relevées par `date -u` (UTC, 14 novembre 2026). Auditeur : modèle C. Commande type (le même habillage à
chaque appel, depuis la racine du dépôt) : voir `lancer.sh` du bac à sable (`/root/bac-audit-fuites-t07-v1/auditeur/lancer.sh`),
qui n'ajoute à la commande du § 2 de la consigne de lancement que les arguments du script (chemins, empreintes attendues).

| heure (UTC) | acte |
|---|---|
| 12:41:20 | début ; `sha256sum -c` de la consigne de lancement v2 : OK ; empreinte de la consigne scellée relue : `43102e80…3a5d` ; lecture en entier des deux consignes |
| 12:41:27 | les quatre commandes de lecture du registre (§ 2 de la consigne de lancement) : une ligne `CONSIGNE-AUDIT-FUITES-T07`, une ligne `RUN-CONFIRMATION-T06`, une ligne `CODE-T07`, zéro ligne `AUDIT-FUITES-T07` ; création de `/root/bac-audit-fuites-t07-v1/auditeur/{tmp,hf,decoupeur,jouets}` |
| 12:41 – 12:52 (heures non relevées une à une) | lectures permises (§ 3) : `CODE-T07-v3.json` (commit, entrée `criteres_v1.py`), champs du manifeste de 7b, champs d'`episodes-t06.json`, empreintes des entrées (comparées à leurs compagnons), sources de construction au commit du manifeste par `git show` (`propositions.py`, `conditions.py`, `test_croise.py`, `cout.py`, `lanceur.py`, `lanceur_v6.py`, `episode.py`, `modeles.py`, `P3-consignes-v1.md` seulement par programme et ses deux premiers blocs cités, index des invites, guide `H1-classification`), `statistiques.py` et `criteres_v1.py` (`valider_audit_fuites`), `evaluation.py` ; comparaison des onze sources du § 5.1 point 5 aux mêmes chemins au commit `1609a4bf…` : empreintes égales, aucun écart ; aucun texte d'action, aucune mesure de 7b, aucun score ouvert |
| avant 12:52 | écriture du script `audit_fuites_t07_v1.py` ; aucune exécution avant 12:52:11 |
| 12:52:11 | `lancer.sh prealables` : 8 préalables OK (sortie dans le bac à sable, `tmp/`), code 0 ; les textes et mesures de 7b ne sont que hachés |
| 12:52:18 – 12:52:22 | `lancer.sh candidats` : code 0 ; `candidats-v1.jsonl` écrit et scellé, `903d6440…1da1a` (1609 lignes ; 258 suites de mots venues de P3 dont 243 pour la consigne privée et 15 pour l'indication, 69 et 14 retirées : repères du § 6.2 retrouvés) ; **aucun texte ni aucune mesure de 7b ouverts avant ce scellement** |
| 12:52:29 | `lancer.sh essais` (premier lancement) : arrêt à l'essai 15, exception du jouet (argument `registre_extra` non transmis par la fabrique de jouets, défaut du code d'essai, non du script d'audit) ; sortie jetée ; correction du code d'essai |
| 12:53 – 12:55 | trois relances d'essais pour corriger le code d'essai : (a) l'essai 2 plantait la suite en fin de texte, ce qui changeait aussi le dernier jeton noté du jouet (fuite `empan` légitimement nommée, défaut du jouet) ; les suites plantées sont désormais insérées au milieu du texte ; (b) mêmes corrections sur les essais 1, 6, 7, 9 et 23 ; (c) 39 cas sur 39 OK. Le seul code modifié après le scellement de `candidats-v1.jsonl` est le code des essais (sous-commande `essais` et fabrique de jouets) ; la liste des candidats est rejouée par `auditer` et comparée à l'octet au fichier scellé |
| 12:55:42 – 12:56:22 | `lancer.sh essais` final, sortie brute dans `essais-r5-v1.txt` : 39 cas OK sur 39 (les 23 essais du § 8, avec leurs sous-cas) ; scellé |
| 12:56:25 – 12:56:43 | `lancer.sh auditer` : code 0 ; 3 840 lignes des six conditions lues ; bijection, `jetons`, `jetons_notes`, décodage des jetons notés, formes du coût et `valide` contrôlés sans écart ; `table-candidats-v1.jsonl` `872efc1e…c59` ; `audit-fuites-t07.json` `5c76b7ff…e094` validé par `valider_audit_fuites` avant scellement, puis scellé |
| 12:56:56 – 12:57:20 | rejeu complet (`candidats` puis `auditer`) vers un dossier de sortie et un dossier de découpeur neufs du bac à sable (`rejeu/`, `rejeu-dec/`) : `cmp` octet pour octet égal pour `candidats-v1.jsonl`, `table-candidats-v1.jsonl` et `audit-fuites-t07.json` |
| 12:57:41 | rapport, journal, scellements ; fin |

Aucun arrêt de la liste du § 10. Aucun refus d'un contrôle de permissions ou d'un classifieur. Aucune écriture hors du dossier de
sortie et du bac à sable ; `git status` ne montre, pour cet audit, que des fichiers non suivis de ce dossier.
