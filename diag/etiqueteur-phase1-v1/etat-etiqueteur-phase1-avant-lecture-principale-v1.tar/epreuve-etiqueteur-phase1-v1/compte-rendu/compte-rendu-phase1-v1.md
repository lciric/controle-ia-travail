# Compte rendu de la phase 1 de l'épreuve de l'étiqueteur — exécutante : la session mère (R-1756)

Ordre : docs/procedures/ordre-execution-phase1-epreuve-etiqueteur-v1.md (30f265a9a1c49a6af734c71a69cdc444989f9ec1c6e294525f43035a28705f18).

## Sections 1 et 2 (8 novembre 2026, 05:50:18Z à 05:52:34Z, date -u)
- 1.1 : variables-v1.sh 90b6bee859044fd9edbb7351c4efa61a3c11eae0898576525c4023136b7bb976.
- 1.2 : « commit du code conforme », « arbre propre ».
- 1.3 : douze « OK », code sha256sum=0 ; GO-2026-11-07-07 : 1 ligne ; entropie 17812956677980471985 ; python 3.13.18, numpy 2.4.6.
- 1.4 : 24, 6, 79, 12 passés, codes 0.
- 1.5 : GEMINI_API_KEY_2 présente, KIMI_API_KEY présente (par le nom seulement).
- 1.6 : port 8789 libre.
- 2.1 à 2.3 : codes 0 ; 2.4 : 396, 396, 20, 20, 80, 60 lignes ; « comptes conformes » ; entropie, commit 64e67cbd…, empreinte du script ceeef529… conformes ; empreintes-generation-v1.txt 73f5f61abeb29d5b62ed73a4abcada2ced3b948e7d00f7e9e6b8a9038cb8b914.
- CO-10 : 1.3 et 1.4 refaits (conformes) ; empreintes de 2.4 recalculées dans empreintes-generation-verification-v1.txt (fichier neuf, R12) : identiques.

## 2.5 — Feu vert de dépôt (session mère, 2026-11-08T05:55:04Z)
- Dépôt chez le tiers : projet privé dr57c de l'Open Science Framework, fichier depot-epreuve-etiqueteur-phase1-v1.json, date de dépôt rendue par l'interface **2026-11-08T05:54:40.935302Z**, empreinte relue ab240b401de2f9a6edb69dfc14ac9dfdc828f50542dc8a543f5473d13ce8707a (conforme), identifiant 6af00ea0066c9d972ba9da79. Copie scellée : livrables/osf-depot-epreuve-etiqueteur-phase1-v1/ (commit 3b39d1e75).
- Empreintes déposées : texte scellé f73455b8… ; extrait des seuils et critères des deux phases 2f146f94… ; ordre 30f265a9… ; items 8efc13d3…, clé 191e5001…, items de formation 14d887a2…, clé de formation cf528ffa…, manifeste de génération e39ea53b…, relectures 5ed697c8…, tirage de la phase 2 07e359ba… — égales à empreintes-generation-v1.txt (vérifié par programme à la construction du dépôt).
- CO-07 (a) : prix public d'Argon relevé à 05:46:11Z (copie docs/sources/prix/page-prix-gemini-api-20261108T054611Z.html, ad2140dd…) : 2,00 USD par million d'entrée, 10,00 USD par million de sortie pensée comprise, jusqu'au 30 novembre 2026 ; sous 10 et 50 : pas d'arrêt.
- CO-07 (b) : GEMINI_API_KEY_2 ne sert à rien d'autre (mot du directeur, R-1754) ; KIMI_API_KEY : aucun autre appel engagé par la session mère ni par ses filles pendant la fenêtre de l'essai de format (aucun ordre en cours qui l'emploie).
- Feu vert de dépôt donné : l'essai de format (section 3) peut partir.

## Section 3 — essai de format (05:55:13Z à 06:05:34Z)
- 3.1 : relais 4488 ; état avant conforme (relais-kimi-v4, Kimi seul, plafond 300, réserve 0,4, 100 appels, 0 appel, prix 2 / 10 / 2, recherche inactive, variable de clé absente de son environnement, numéro conforme).
- 3.2 : lecture 4539, lancée détachée 05:55:23Z ; deux guets ; code de fin **0**.
- 3.4 : état du relais après : 20 appels, depense_usd 0,379924, 0 refus, 0 écart de modèle servi, 0 usage absent, 0 délai dépassé, réponses 200 : 20 ; relais 4488 arrêté (vérifié). Manifeste : code 0, aucun arrêt ; comptes A ok 20, B ok 20 (0 illisible, 0 arrêt) ; **feu_vert True**, motifs [] ; extrapolation 34,8598 USD ; plafond restant 298,8351 ; **depense_estimee_dollars 1.164904** ; tentatives interrompues 0 ; empreinte des réglages 303edae8… ; commit 64e67cbd… ; manifeste 3a3d868ebc15e995040c9c70807e801589bd02dda4bf7725865c1e22580222a2 ; empreintes au fichier empreintes-lecture-format-v1.txt.

## 3 bis — facture attendue (journal, nombres seulement)
- A, gemini-4-argon, appel direct, GEMINI_API_KEY_2 : 20 tentatives ; jetons d'entrée 60 883 ; jetons de sortie 3 523 (pensée comprise, dont pensée 1 723) ; coût estimé au barème scellé 0,78498 USD ; modèle servi différent : 0 ; fenêtre 05:55:23Z → 06:03:13Z.
- B, kimi-k3.1-pro, par le relais, KIMI_API_KEY : 20 tentatives ; jetons d'entrée 62 132 ; jetons de sortie 25 566 (raisonnement compris, dont 23 455) ; coût estimé 0,379924 USD (relais : 20 appels, 0,379924 USD) ; modèle servi différent : 0 ; fenêtre 05:55:23Z → 06:05:07Z.
- Comparaison par le directeur sur les consoles de facturation (Google, Moonshot), écrite ici par la session mère. (2026-11-08T06:05:55Z)

## 4.1 — Feu vert de la lecture principale (session mère, 2026-11-08T06:09:35Z)
- « feu vert de la lecture principale ».
- Empreinte de lecture-format/manifeste-lecture-phase1-v4.json : 3a3d868ebc15e995040c9c70807e801589bd02dda4bf7725865c1e22580222a2 (égale à celle de empreintes-lecture-format-v1.txt).
- depense_estimee_dollars de ce manifeste : 1.164904.
- Contrôle de la facture : **non fait, levé par le directeur** (GO-2026-11-08-03, verbatim « pas la peine on avance ») ; écart au texte scellé (point 6) consigné ; feu vert du script : True, motifs aucun.

## Passation (2026-11-08T06:10:57Z)
- 4.2 joué une fois (relais 7210, plafond 298,83, 2 280 appels, état avant conforme), puis **arrêté par son numéro sans aucun appel** (0 appel, 0 USD) : passation demandée par le directeur vers une nouvelle instance ; la lecture principale (4.3) n'a **jamais** été lancée ici. États du relais annulé copiés : relais-principale-annule-etat-avant-v1.json, relais-principale-annule-etat-apres-v1.json. Le dossier relais-principale n'est pas transmis : la nouvelle instance refait 4.2 dans un dossier neuf.
