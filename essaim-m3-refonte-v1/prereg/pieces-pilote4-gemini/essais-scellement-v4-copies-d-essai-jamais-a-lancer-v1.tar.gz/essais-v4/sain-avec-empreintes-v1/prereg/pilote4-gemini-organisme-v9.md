# texte d essai
entropie E = 256226539220396978895046163908794646008 tirée au scellement
   graine de la course v5-3 = 15766279427063595319
   graine de la course v6-2 = 7738969930906883375
empreintes : `21945edc6ae30f6476afbc2021ff7c1dcbb3a5e768571b46e12ef90b92b08b8a`
