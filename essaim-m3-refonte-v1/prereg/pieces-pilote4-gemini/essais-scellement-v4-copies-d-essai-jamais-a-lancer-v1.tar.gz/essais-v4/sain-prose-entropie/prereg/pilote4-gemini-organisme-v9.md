# texte d essai
entropie E = 154257433381486574139568419166846745463 tirée au scellement
   graine de la course v5-3 = 2567368324448608055
   graine de la course v6-2 = 2320338127090223189
empreintes : `0c333b524f6632d0292df2a0e0378b0018bc6fb0298aed16f9e37972451844dc`
la graine dérive de l entropie E du texte (sans égalité)
