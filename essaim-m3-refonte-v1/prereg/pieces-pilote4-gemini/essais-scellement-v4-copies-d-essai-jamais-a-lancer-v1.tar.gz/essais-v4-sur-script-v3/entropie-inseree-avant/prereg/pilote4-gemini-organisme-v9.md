# texte d essai
résumé de contre-lecture : entropie E = 12345 lue dans un essai
entropie E = <<ENTROPIE>> tirée au scellement
   graine de la course v5-3 = <<GRAINE_V53>>
   graine de la course v6-2 = <<GRAINE_V6X>>
empreintes : <<EMPREINTE_PIECES>>
