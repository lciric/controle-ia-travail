# texte d essai
entropie E = <<ENTROPIE>> tirée au scellement
   graine de la course v5-3 = <<GRAINE_V53>>
   graine de la course v6-2 = <<GRAINE_V6X>>
empreintes : <<EMPREINTE_PIECES>>
