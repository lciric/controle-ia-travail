# texte d essai
entropie E = 311033804275266510120788571313543199925 tirée au scellement
   graine de la course v5-3 = 6856167203344393970
   graine de la course v6-2 = 8067994496145915864
empreintes : `0c333b524f6632d0292df2a0e0378b0018bc6fb0298aed16f9e37972451844dc`
la graine dérive de l entropie E du texte (sans égalité)
