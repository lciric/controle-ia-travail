"""La boucle externe du noyau : amorcer, exécuter une génération, juger, archiver, relancer le successeur.

Le noyau n'impose aucune organisation ni aucune règle de sélection ; il tient ce que l'essaim ne peut pas tenir
lui-même : les clés et le journal (couche d'appel), le juge (tâches cachées), le bac à sable, l'archive, les bornes
de l'humain (générations, budget, temps), et l'arrêt sur ordre (fichier `STOP` dans le dossier du run).

Reprise par segments (décision de Lazar, 25 octobre 2026, 20:23 Paris) : une course arrêtée par `STOP` entre deux unités
(rondes de conception ou générations) écrit son état dans `reprise/etat-vN.json`, scellé ; `reprendre()` la continue dans
une autre commande, à la première unité qui n'a pas tourné, avec les mêmes graines, la même archive et la même dépense.
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import os
import pathlib
import platform
import secrets
import shutil
import sys

import numpy as np

from . import archive as _archive, bac_a_sable, contrat, fichiers as _fichiers, entrainement as _entrainement, moisson as _moisson, question as _question, recherche as _recherche, taches as _taches
from .appels import EMPREINTE_COLLISIONNEUR_V25, Appelant, Arret, cv
from .serveur import PARALLELE_MAX_DEFAUT, ServeurAppels

FAMILLES_CONNUES = sorted(set(contrat.FAMILLES.values()))


def _heure() -> str:
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def commit_git(dossier: pathlib.Path) -> str | None:
    """Commit du code (lecture seule, aucune autre commande git) ; None hors dépôt."""
    import subprocess
    try:
        r = subprocess.run(["git", "-C", str(dossier), "rev-parse", "HEAD"], capture_output=True, text=True, timeout=10)
        return r.stdout.strip() if r.returncode == 0 else None
    except (OSError, subprocess.SubprocessError):
        return None


USAGES_GRAINE = {"ordre_train": 1, "ordre_test": 2, "recherche": 3, "defense": 4, "organisme": 5, "ordre_lignees": 6, "ordre_vivier": 7}
DECALAGE_CONCEPTION = 100_000  # CE3-17 : la ronde de conception k ne tire pas les graines de la génération notée k
INDICE_RONDE = 1_000_000  # indice de lignée réservé aux tirages de ronde (ordre des lignées), hors de toute lignée réelle
MARGE_TEMPS_S = 300  # CE-07 : temps de génération laissé aux appels et à l'écriture, au-delà des entraînements permis
ETAT_REPRISE_VERSION = 1  # reprise par segments : format de `reprise/etat-vN.json`
# Reprise par segments : champs du manifeste qu'un lancement de reprise doit retrouver à l'identique (même course, mêmes
# bornes, mêmes conditions extérieures, même code) ; les organismes imposés sont comparés par famille et empreinte d'arbre
CHAMPS_REPRISE = ("reel", "go_id", "entropie_seed_sequence", "python", "numpy", "collisionneur_v25_empreinte",
                  "collisionneur_conforme", "budget_generation", "plafond_total_usd", "generations_max", "isolation_reseau", "gel",
                  "n_taches_entrainement", "n_taches_test_dev", "n_taches_test_final", "mission_sha256", "parallele_max",
                  "especes_amorcage", "relances_max", "memoire_partagee", "rondes_conception_max", "decalage_uid",
                  "question_ouverte", "budget_conception", "vivier", "sources_moisson", "cle_brave_presente",
                  "cle_openalex_presente", "cle_s2_presente", "entrainements_max", "pas_max", "traits", "lignees_base_graines",
                  "isolation", "espace_organismes", "commit", "sha256_code_noyau", "sha256_banque")


def _projection_reprise(manifeste: dict) -> dict:
    """Ce qu'un lancement de reprise doit retrouver d'un manifeste, après un aller-retour JSON (le manifeste de la course
    est relu d'un fichier) : les champs de `CHAMPS_REPRISE`, sans les chemins des fichiers servis (question ouverte,
    vivier : leurs empreintes restent comparées), et les organismes imposés par famille et empreinte d'arbre."""
    m = json.loads(json.dumps(manifeste, ensure_ascii=False))
    p = {k: m.get(k) for k in CHAMPS_REPRISE}
    if isinstance(p.get("question_ouverte"), dict):
        p["question_ouverte"] = {k: v for k, v in p["question_ouverte"].items() if k != "source"}
    if isinstance(p.get("vivier"), dict):
        p["vivier"] = {k: v for k, v in p["vivier"].items() if k != "chemin"}
    p["organismes_imposes"] = {nom: [v.get("famille"), v.get("empreinte_arbre")] for nom, v in (m.get("organismes_imposes") or {}).items()}
    return p


def anomalie_journal_absent(n_appels: int, journal: pathlib.Path) -> str | None:
    """CE3-07 : le journal des appels vit hors du dossier de l'organisme (à root) ; s'il manque alors que des appels ont
    été servis, c'est une anomalie du noyau, jamais un silence — la génération est invalidée. Rend la raison, ou None."""
    if int(n_appels) > 0 and not pathlib.Path(journal).exists():
        return "journal des appels absent alors que des appels ont été servis (CE3-07)"
    return None


def temps_pire_cas(budget: dict) -> tuple[int, str]:
    """CE-07 / CE3-11 : durée au pire cas du travail permis par un budget — entraînements × délai, recherches × délai
    réseau, téléchargements × (délai réseau + extraction), plus la marge. Rend (secondes, détail lisible)."""
    n_ent = int(budget.get("entrainements_max", 0))
    delai = int(budget.get("delai_entrainement_s", _entrainement.DELAI_S_DEFAUT))
    n_rech = int(budget.get("recherches_max", 0))
    n_tel = int(budget.get("telechargements_max", 0))
    t_rech = n_rech * float(_recherche.DELAI_S)
    t_tel = n_tel * (float(_moisson.DELAI_S) + float(_moisson.EXTRACTION_MAX_S))
    total = int(round(n_ent * delai + t_rech + t_tel + MARGE_TEMPS_S))
    return total, (f"{n_ent} entraînements × {delai} s + {n_rech} recherches × {_recherche.DELAI_S:.0f} s + {n_tel} téléchargements × "
                   f"({_moisson.DELAI_S:.0f} + {_moisson.EXTRACTION_MAX_S}) s + {MARGE_TEMPS_S} s")


def empreinte_arbre(dossier: pathlib.Path) -> str:
    """Empreinte d'un dossier : chemins relatifs triés et contenu de chaque fichier (indépendante des dates). Le bytecode
    (`__pycache__/`, `*.pyc`) est écarté : il dépend de l'exécution, pas du code (constat de « conv-audit », n° 30 § 5)."""
    h = hashlib.sha256()
    for f in sorted(p for p in pathlib.Path(dossier).rglob("*")
                    if p.is_file() and p.suffix != ".pyc" and "__pycache__" not in p.relative_to(dossier).parts):
        h.update(str(f.relative_to(dossier)).encode("utf-8") + b"\0")
        h.update(hashlib.sha256(f.read_bytes()).hexdigest().encode("ascii") + b"\n")
    return h.hexdigest()


def organismes_g000(course: str | pathlib.Path, destination: str | pathlib.Path) -> dict[str, dict]:
    """Les organismes de génération 0 archivés d'une course (mêmes empreintes), extraits sous `destination/<lignée>/`,
    pour le bras gelé apparié (CR-08) : {lignée: {"organisme": dossier, "famille": …, "empreinte_organisme": …}}."""
    import tarfile
    course, destination = pathlib.Path(course), pathlib.Path(destination)
    index = course / "archive" / "index.jsonl"
    if not index.exists():
        raise Arret(f"course sans archive : {index}")
    lignes = [json.loads(l) for l in index.read_text(encoding="utf-8").splitlines() if l.strip()]
    manifeste = json.loads((course / "manifeste-run.json").read_text(encoding="utf-8")) if (course / "manifeste-run.json").exists() else {}
    # CE4-05 : lignées de la course d'origine (index et dernier rapport), pour que l'indice de lignée qui entre dans les
    # graines soit le même dans le bras relancé, même si une lignée d'origine n'a pas de génération 0 à relancer
    origine = {l["lignee"] for l in lignes}
    rapports = sorted(course.glob("rapport-v*.json"), key=lambda r: int("".join(ch for ch in r.stem if ch.isdigit()) or 0))
    if rapports:
        origine |= set((json.loads(rapports[-1].read_text(encoding="utf-8")).get("lignees") or {}))
    sortie = {}
    for l in lignes:
        if l["generation"] != 0 or l.get("phase") or l["lignee"] in sortie:
            continue
        tar = course / "archive" / l["chemin"] / "organisme.tar.gz"
        cible = destination / l["lignee"]
        if cible.exists():
            shutil.rmtree(cible)
        cible.mkdir(parents=True)
        with tarfile.open(tar, "r:gz") as t:
            membres = [m for m in t.getmembers() if m.isfile() and m.name.startswith("organisme/") and ".." not in m.name]
            t.extractall(cible, members=membres, filter="data")
        famille = l.get("famille")
        if not famille:  # courses antérieures : famille de l'espèce d'amorçage, par le nom de la lignée
            for e in manifeste.get("especes_amorcage", []):
                if e.lower().replace("_", "-") == l["lignee"]:
                    famille = contrat.FAMILLES[e]
        sortie[l["lignee"]] = {"organisme": str(cible / "organisme"), "famille": famille or "gemini",
                               "empreinte_organisme": l.get("empreinte_organisme"), "course_origine": str(course),
                               "impose": bool(l.get("impose")), "rondes_conception_max_origine": int(manifeste.get("rondes_conception_max") or 0),
                               "lignees_origine": sorted(origine)}
    if not sortie:
        raise Arret(f"aucune génération 0 archivée dans {course}")
    return sortie


class Noyau:
    @classmethod
    def recharger(cls, course: str | pathlib.Path, appelants: dict | None = None, reel: bool = False, go_id: str | None = None,
                  registre_go: str | pathlib.Path | None = None, isoler_reseau: bool | None = None):
        """Recharge une course finie (manifeste, banque, mission, lignées de l'archive) pour une confrontation séparée
        (CR-04) : rien de la course n'est réécrit ; les dépenses nouvelles s'ajoutent au plafond restant."""
        course = pathlib.Path(course)
        m = json.loads((course / "manifeste-run.json").read_text(encoding="utf-8"))
        banque = json.loads((course / "banque.json").read_text(encoding="utf-8"))
        mission = (course / "mission.txt").read_text(encoding="utf-8") if (course / "mission.txt").exists() else ""
        n = cls(course, mission, banque, m["budget_generation"], m["plafond_total_usd"], m["generations_max"], appelants=appelants,
                reel=reel, go_id=go_id or m.get("go_id"), isoler_reseau=(m.get("isolation_reseau", False) if isoler_reseau is None else isoler_reseau),
                entropie=m["entropie_seed_sequence"], especes_amorcage=m.get("especes_amorcage"), etiquette_run=m.get("run", ""),
                gel=m.get("gel", False), parallele_max=m.get("parallele_max", PARALLELE_MAX_DEFAUT), registre_go=registre_go,
                memoire_partagee=m.get("memoire_partagee", False), rondes_conception_max=0, decalage_uid=int(m.get("decalage_uid", 0)))
        n.lignees_base = set(m.get("lignees_base_graines") or [])  # CE4-05 : mêmes graines qu'à la course
        lignes = n.archive.lignes()
        depense = 0.0
        for l in lignes:
            if l.get("importee"):  # rondes importées d'une course d'origine : dépensées là-bas, jamais ici
                continue
            depense += float(l.get("cout_usd") or 0.0)
            if l.get("phase"):
                continue
            nom = l["lignee"]
            espece = next((e for e in m.get("especes_amorcage", []) if e.lower().replace("_", "-") == nom), None)
            n.lignees[nom] = {"espece_amorcage": espece, "famille": l.get("famille") or (contrat.FAMILLES[espece] if espece else None),
                              "generation": l["generation"], "organisme": None, "active": False, "impose": bool(l.get("impose")),
                              "uid": (bac_a_sable.uid_lignee(len(n.lignees), n.decalage_uid) if n.isolation["utilisateur"] and nom not in n.lignees else n.lignees.get(nom, {}).get("uid"))}
        n.depense_totale = depense
        n._evenement(etape="rechargement", lignees=sorted(n.lignees), depense_relue_usd=round(depense, 4))
        return n

    def __init__(self, racine: str | pathlib.Path, mission: str, banque: dict, budget_generation: dict,
                 plafond_total_usd: float, generations_max: int, appelants: dict | None = None, reel: bool = False,
                 go_id: str | None = None, isoler_reseau: bool = False, entropie: int | None = None,
                 especes_amorcage: list[str] | None = None, etiquette_run: str = "", gel: bool = False,
                 organismes_imposes: dict[str, dict] | None = None, parallele_max: int = PARALLELE_MAX_DEFAUT,
                 recherche=None, relances_max: int = 1, traits: dict | None = None, description_traits: str = "",
                 registre_go: str | pathlib.Path | None = None,
                 memoire_partagee: bool = False, rondes_conception_max: int = 0, budget_conception: dict | None = None,
                 decalage_uid: int = 0, vivier: dict | None = None,
                 question_ouverte: "_question.QuestionOuverte | None" = None):
        """`organismes_imposes` : {nom de lignée: {"organisme": dossier `organisme/` déjà écrit, "famille": "anthropic"|"gemini"}}
        — lignées dont la génération 0 n'est pas écrite par une espèce mais fournie (par exemple l'essaim de Gemini
        corrigé, mis sous contrat), pour les comparer sous le même noyau, les mêmes tâches et les mêmes bornes que les
        lignées auto-écrites. La famille déclarée sert à la confrontation entre familles."""
        self.racine = pathlib.Path(racine)
        if not isinstance(decalage_uid, int) or decalage_uid < 0 or decalage_uid > 900 or decalage_uid % 100:
            raise Arret(f"decalage_uid {decalage_uid!r} : multiple de 100 entre 0 et 900 attendu (CE3-06)")
        self.decalage_uid = decalage_uid  # CE3-06 : utilisateurs distincts entre courses qui tournent ensemble
        self.racine.mkdir(parents=True, exist_ok=True)
        # CR-01 : isolation d'utilisateur quand le noyau est root ; la racine est traversable (0711) mais ses dossiers
        # sensibles (banque, archive, lignées, journaux) restent à root en 0700 ; chaque lignée a son propre utilisateur
        self.isolation = bac_a_sable.capacites_isolation()
        bac_a_sable.proteger(self.racine, 0o711)
        for sous in ("lignees", "confrontation"):
            (self.racine / sous).mkdir(exist_ok=True)
            bac_a_sable.proteger(self.racine / sous, 0o700)
        # les dossiers de travail des organismes et la vue de l'archive doivent être atteignables par leurs utilisateurs
        course_nouvelle = not (self.racine / "manifeste-run.json").exists()
        self.espace = bac_a_sable.espace_organismes(self.racine, course_nouvelle) if self.isolation["utilisateur"] else self.racine
        (self.espace / "travail").mkdir(exist_ok=True)
        bac_a_sable.proteger(self.espace / "travail", 0o711)
        self.mission = mission
        self.banque = banque
        self.budget = dict(budget_generation)
        self.plafond_total = float(plafond_total_usd)
        self.generations_max = int(generations_max)
        self.appelants = appelants
        self.reel, self.go_id, self.isoler_reseau = bool(reel), go_id, bool(isoler_reseau)
        self.especes_amorcage = list(contrat.ESPECES_DISPONIBLES if especes_amorcage is None else especes_amorcage)  # [] : aucune lignée auto-écrite (bras gelé apparié)
        self.gel = bool(gel)  # bras témoin : la génération 0 est relancée, le successeur est ignoré
        self.organismes_imposes = dict(organismes_imposes or {})
        self.parallele_max = max(1, int(parallele_max))
        # recherche documentaire servie par le noyau (nœud 1, option (b)) : `recherche` est la fabrique du moteur
        # (double en simulation ; None en réel = arXiv) ; `budget['recherches_max']` = 0 la coupe
        self.recherche = recherche
        self.budget.setdefault("recherches_max", 0)
        # successeur invalide : relance de la dernière génération valide, `relances_max` fois de suite (nœud 2, (b))
        self.relances_max = max(0, int(relances_max))
        # CR-15 (c) : par défaut chaque lignée ne lit que sa propre archive (lignées indépendantes) ; avec
        # `memoire_partagee`, la vue de toutes les lignées est lisible, figée au début de chaque ronde (CR-15 b)
        self.memoire_partagee = bool(memoire_partagee)
        # question ouverte (contrat § 7 ; Lazar, 24 et 25 octobre, 23:58, 00:05, 00:55 Paris) : texte figé et empreinté, posé
        # aux seules générations ou rondes ciblées ; la réponse est une pièce archivée, jamais un score
        self.question = question_ouverte
        # phase de conception (Lazar, 24 octobre, 20:37 et 20:42 Paris) : avant la génération 0 notée, l'organisme moissonne,
        # teste ses modules, se réécrit, ronde après ronde ; **il conçoit lui-même son critère d'arrêt** et le déclare en
        # écrivant `fin_conception.json` ; le noyau ne tient qu'une borne dure (rondes, budget : devis et GO) ; rondes
        # archivées (cNNN), jamais notées ; l'organisme de la dernière ronde devient la génération 0
        self.rondes_conception = max(0, int(rondes_conception_max))
        self.budget_conception = dict(budget_conception) if budget_conception else dict(budget_generation)
        self.budget_conception.setdefault("recherches_max", self.budget.get("recherches_max", 0))
        self.ronde = 0
        self.vue_ronde: pathlib.Path | None = None
        # reprise par segments : numéro du segment (1 au départ, n + 1 à la n-ième reprise), première ronde de conception
        # qui n'a pas tourné, ronde en cours (lignées faites ; None une fois toutes faites)
        self.segment = 1
        self._prochaine_ronde_conception = 1
        self._ronde_en_cours: dict | None = None
        # vivier de conception (Lazar, 25 octobre, 00:05 Paris, « GO now ») : tâches à vérité connue d'un fichier distinct de
        # la banque (`vivier.charger_vivier`), servies pendant la conception seulement, jamais en génération notée
        self.vivier = vivier if (vivier and vivier.get("taches")) else None
        if vivier is not None and not self.rondes_conception:
            raise Arret("vivier de conception sans phase de conception (rondes_conception_max = 0) : refusé")
        # apprentissage par gradient (contrat v3) : traits par tâche (activations en réel, hachage en simulation) ;
        # `budget['entrainements_max']` = 0 le coupe ; en simulation sans traits fournis, ils sont calculés ici
        self.budget.setdefault("entrainements_max", 0)
        self.budget.setdefault("pas_max", _entrainement.PAS_MAX_DEFAUT)
        # vues servies (une vue = une couche × une agrégation des activations ; {id: vecteur} seul = la vue « defaut »)
        try:
            self.vues = _entrainement.normaliser_vues(traits)
        except ValueError as e:
            raise Arret(f"traits : {e}")
        self.description_traits = description_traits
        self.budget.setdefault("delai_entrainement_s", _entrainement.DELAI_S_DEFAUT)
        # plafond de jetons de sortie par appel d'organisme (None : aucun) ; la ronde de conception hérite de la génération
        self.budget.setdefault("max_tokens_appel", None)
        self.budget_conception.setdefault("max_tokens_appel", self.budget["max_tokens_appel"])
        for b in (self.budget, self.budget_conception):
            if b["max_tokens_appel"] is not None and int(b["max_tokens_appel"]) <= 0:
                raise Arret("max_tokens_appel doit être strictement positif ou absent")
        # CE-07 (étendue par CE3-11) : en réel, le temps d'une génération — et d'une ronde de conception, qui sert les mêmes
        # primitives — doit contenir au pire cas tous les entraînements permis, toutes les recherches et tous les
        # téléchargements permis (délai réseau, extraction d'un PDF), plus le reste du travail
        if self.reel:
            budgets = [("génération", self.budget)] + ([("ronde de conception", self.budget_conception)] if self.rondes_conception else [])
            for nom_b, b in budgets:
                besoin, detail = temps_pire_cas(b)
                if besoin > MARGE_TEMPS_S and int(b["temps_max_s"]) < besoin:
                    raise Arret(f"budget incohérent (CE-07, {nom_b}) : temps_max_s {b['temps_max_s']} < {besoin} s au pire cas ({detail})")
        if int(self.budget["entrainements_max"]) > 0 and not self.vues:
            if self.reel:
                raise Arret("apprentissage par gradient demandé en réel sans fichier de traits (activations) : refusé")
            textes = {t["id"]: t["texte"] for n in ("train", "test", "test_final") for t in self.banque.get(n, [])}
            self.vues = {"simulation": _entrainement.traits_simules(textes)}
            self.description_traits = f"traits de hachage simulés ({_entrainement.DIM_SIMULATION} dimensions), vue « simulation »"
        for nom, spec in self.organismes_imposes.items():
            if not isinstance(spec, dict) or "organisme" not in spec or spec.get("famille") not in FAMILLES_CONNUES:
                raise Arret(f"organisme imposé {nom!r} : il faut {{'organisme': dossier, 'famille': {FAMILLES_CONNUES}}}")
            if nom in {e.lower().replace("_", "-") for e in self.especes_amorcage}:
                raise Arret(f"organisme imposé {nom!r} : nom déjà pris par une lignée auto-écrite")
        self.banque.setdefault("test_final", [])
        self.archive = _archive.Archive(self.racine / "archive", vue=self.espace / "archive_vue")
        self.depense_totale = 0.0
        self.n_appels_total = 0
        self.lignees: dict[str, dict] = {}
        # CE4-05 : base de l'indice de lignée des graines ; dans un bras relancé, les lignées de la course d'origine
        self.lignees_base: set[str] = {n for s in self.organismes_imposes.values() for n in (s.get("lignees_origine") or [])}
        self.evenements: list[dict] = []
        self.graines = np.random.SeedSequence(entropie)
        self.manifeste = {
            "run": etiquette_run or self.racine.name, "debut_utc": _heure(), "reel": self.reel, "go_id": go_id,
            "entropie_seed_sequence": int(self.graines.entropy), "python": sys.version.split()[0], "numpy": np.__version__,
            "plateforme": platform.platform(), "collisionneur_v25_empreinte": getattr(cv, "__empreinte_fichier__", None),
            "budget_generation": self.budget, "plafond_total_usd": self.plafond_total, "generations_max": self.generations_max,
            "isolation_reseau": self.isoler_reseau, "gel": self.gel, "n_taches_entrainement": len(banque["train"]),
            "n_taches_test_dev": len(banque["test"]), "n_taches_test_final": len(banque.get("test_final", [])),
            "mission_sha256": hashlib.sha256(mission.encode("utf-8")).hexdigest(),
            "parallele_max": self.parallele_max, "especes_amorcage": self.especes_amorcage, "relances_max": self.relances_max,
            "memoire_partagee": self.memoire_partagee, "rondes_conception_max": self.rondes_conception, "decalage_uid": self.decalage_uid,
            "question_ouverte": (self.question.manifeste() if self.question is not None else None),
            "budget_conception": (self.budget_conception if self.rondes_conception else None),
            "vivier": ((vivier or {}).get("manifeste") if vivier is not None else None),
            "coeurs": os.cpu_count(),  # RV-15, CE3-11 : contention du processeur rapportée
            "sources_moisson": self._sources_moisson(), "cle_brave_presente": bool(os.environ.get("BRAVE_API_KEY")),
            "cle_openalex_presente": bool(os.environ.get("OPENALEX_API_KEY")), "cle_s2_presente": bool(os.environ.get("SEMANTIC_SCHOLAR_API_KEY")),
            "entrainements_max": int(self.budget["entrainements_max"]), "pas_max": int(self.budget["pas_max"]),
            "traits": ({"description": self.description_traits, "n": len(next(iter(self.vues.values()))),
                        "vues": _entrainement.dimensions_vues(self.vues)} if self.vues else None),
            "lignees_base_graines": sorted(self.lignees_base),  # CE4-05 : base de l'indice de lignée des graines
            "organismes_imposes": {nom: {"source": str(spec["organisme"]), "famille": spec["famille"],
                                         "empreinte_arbre": (empreinte_arbre(pathlib.Path(spec["organisme"])) if pathlib.Path(spec["organisme"]).is_dir() else None)}
                                   for nom, spec in self.organismes_imposes.items()},
        }
        self.manifeste["isolation"] = dict(self.isolation)
        self.manifeste["espace_organismes"] = str(self.espace)
        code = pathlib.Path(__file__).resolve().parent.parent  # essaim_m3/
        self.manifeste["commit"] = commit_git(code)
        self.manifeste["sha256_code_noyau"] = empreinte_arbre(code / "noyau")
        self.manifeste["sha256_banque"] = hashlib.sha256(json.dumps(self.banque, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()
        self.manifeste["collisionneur_conforme"] = (getattr(cv, "__empreinte_fichier__", None) == EMPREINTE_COLLISIONNEUR_V25)
        if self.reel:
            if not self.go_id:
                raise Arret("mode réel sans GO : refusé")
            if not self.manifeste["collisionneur_conforme"]:  # CR-13 (d) : table des prix et appelants vérifiés
                raise Arret(f"mode réel : collisionneur v2.5 d'empreinte inattendue ({getattr(cv, '__empreinte_fichier__', None)}) ; refusé")
            if registre_go is None:
                raise Arret("mode réel : extrait de registres/go.md (--registre-go) exigé pour vérifier l'identifiant de GO (CR-13 g)")
            texte_go = pathlib.Path(registre_go).read_text(encoding="utf-8", errors="replace")
            lignes_go = [l for l in texte_go.splitlines() if self.go_id in l]
            if not lignes_go or not any("calcul" in l.lower() for l in lignes_go):
                raise Arret(f"mode réel : {self.go_id} absent de l'extrait du registre des GO, ou sans le type « calcul » ; refusé")
            self.manifeste["registre_go"] = {"chemin": str(registre_go), "sha256": hashlib.sha256(texte_go.encode("utf-8")).hexdigest(), "ligne": lignes_go[0][:300]}
            if not self.isolation["utilisateur"]:
                raise Arret("mode réel : isolation d'utilisateur impossible (le noyau n'est pas root) ; refusé (CR-01)")
            if not self.isoler_reseau:
                raise Arret("mode réel : --isoler-reseau est obligatoire (CR-02)")
            if not bac_a_sable.isolation_reseau_disponible():
                raise Arret("mode réel : isolation réseau demandée mais indisponible (unshare -n)")
            if not self.isolation.get("espaces_noms"):  # RV-06 : sans espace de processus, un descendant détaché survivrait
                raise Arret("mode réel : espaces de noms de montage, de processus et de communication indisponibles ; refusé (RV-06)")
        if not (self.racine / "manifeste-run.json").exists():  # une course existante n'est jamais réécrite (rechargement)
            (self.racine / "manifeste-run.json").write_text(json.dumps(self.manifeste, ensure_ascii=False, indent=1), encoding="utf-8")
            (self.racine / "banque.json").write_text(json.dumps(self.banque, ensure_ascii=False), encoding="utf-8")
            (self.racine / "mission.txt").write_text(self.mission, encoding="utf-8")
        for f in ("manifeste-run.json", "banque.json", "mission.txt"):
            bac_a_sable.proteger(self.racine / f, 0o600)

    # ---- journal du noyau ----
    def _evenement(self, **d):
        d["quand_utc"] = _heure()
        self.evenements.append(d)
        with (self.racine / "evenements.jsonl").open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(d, ensure_ascii=False) + "\n")
        bac_a_sable.proteger(self.racine / "evenements.jsonl", 0o600)

    def _plafond_restant(self) -> float:
        return max(0.0, self.plafond_total - self.depense_totale)

    def graine(self, lignee: str, generation: int, usage: str, phase: str | None = None) -> int:
        """Graine déterministe et consignée : SeedSequence(entropie, spawn_key=(indice de lignée, génération [+ DECALAGE_CONCEPTION
        pour une ronde de conception, CE3-17], usage)) (CR-19)."""
        idx = sorted(set(self.lignees) | {lignee} | self.lignees_base).index(lignee)
        cle = int(generation) + (DECALAGE_CONCEPTION if phase == "conception" else 0)
        ss = np.random.SeedSequence(int(self.graines.entropy), spawn_key=(idx, cle, USAGES_GRAINE[usage]))
        g = int(ss.generate_state(1, dtype=np.uint64)[0])
        self._evenement(etape="graine", lignee=lignee, generation=generation, usage=usage, graine=g, **({"phase": phase} if phase else {}))
        return g

    def graine_ronde(self, ronde: int, conception: bool = False) -> int:
        """Graine de l'ordre des lignées d'une ronde : spawn_key=(INDICE_RONDE [+ 1 en conception], ronde, usage
        « ordre_lignees ») ; consignée."""
        ss = np.random.SeedSequence(int(self.graines.entropy), spawn_key=(INDICE_RONDE + (1 if conception else 0), int(ronde), USAGES_GRAINE["ordre_lignees"]))
        g = int(ss.generate_state(1, dtype=np.uint64)[0])
        self._evenement(etape="graine", ronde=ronde, usage=("ordre_lignees_conception" if conception else "ordre_lignees"), graine=g)
        return g

    def _vue_pour(self, lignee: str) -> pathlib.Path:
        """Dossier d'archive lisible par la lignée : sa propre vue (défaut) ; la vue figée de la ronde (mémoire partagée) ;
        une vue vide (bras gelé)."""
        if self.gel:
            vue = self.espace / "archive_vue_gel"
        elif self.memoire_partagee:
            vue = self.vue_ronde if self.vue_ronde is not None else self.archive.vue
        else:
            vue = self.archive.vue / lignee
        vue.mkdir(parents=True, exist_ok=True)
        if not self.gel and not self.memoire_partagee and self.isolation["utilisateur"]:
            # CE3-06 : en mémoire privée, `archive_vue/` se traverse sans se lister (0711) et la vue d'une lignée n'est
            # lisible que par elle (à root, groupe de la lignée, 0750)
            bac_a_sable.proteger(self.archive.vue, 0o711)
            self._proteger_lecture_lignee(vue, self._uid(lignee), recursif=False)
        else:
            bac_a_sable.proteger(vue, 0o755)
        return vue

    def _verrouiller_vivants(self, dossiers: list) -> None:
        """RV-02 : après le dépôt d'une génération ou d'une ronde, ses dossiers vivants (travail de l'organisme, journaux du
        noyau, corpus moissonné) passent à root en 0700 : les générations suivantes n'en lisent plus rien, et la mémoire ne
        passe que par la vue de l'archive, la même dans les deux bras d'une paire (le bras B n'a que la vue importée).
        Sans isolation d'utilisateur (simulation hors root), rien n'est changé : l'organisme tourne alors sous le même
        utilisateur que le noyau."""
        if not self.isolation["utilisateur"]:
            return
        for d in dossiers:
            if d is not None and _fichiers.vrai_dossier(d):
                try:
                    os.chown(d, 0, 0, follow_symlinks=False)
                    os.chmod(d, 0o700)
                except OSError as e:
                    raise Arret(f"dossier vivant {d} : verrouillage impossible ({type(e).__name__}) : la génération suivante pourrait le lire (RV-02)")

    def _proteger_lecture_lignee(self, dossier: pathlib.Path, uid: int | None, recursif: bool = True) -> None:
        """CE3-06 : un dossier du noyau que la lignée lit (son corpus moissonné, sa vue) appartient à root et au groupe de la
        lignée (son gid est son uid), lisible par elle seule (dossiers 0750, fichiers 0640) ; sans isolation d'utilisateur
        (simulation hors root) ou en mémoire partagée, lisible par tous (0755, 0644). Aucun lien n'est suivi."""
        prive = uid is not None and not self.memoire_partagee
        for f in [dossier] + (sorted(dossier.rglob("*")) if recursif else []):
            if f.is_symlink():
                continue
            try:
                if prive:
                    os.chown(f, 0, uid, follow_symlinks=False)
                    os.chmod(f, 0o750 if f.is_dir() else 0o640)
                else:
                    os.chmod(f, 0o755 if f.is_dir() else 0o644)
            except OSError:
                pass

    def _figer_vue(self, ronde: int) -> pathlib.Path:
        """Copie en lecture seule de la vue de toutes les lignées, prise au début de la ronde (CR-15 b)."""
        cible = self.espace / f"archive_vue_r{ronde:03d}"
        if cible.exists():
            shutil.rmtree(cible)
        shutil.copytree(self.archive.vue, cible, symlinks=False)
        for f in [cible] + list(cible.rglob("*")):
            bac_a_sable.proteger(f, 0o555 if f.is_dir() else 0o444)
        return cible

    def _uid(self, lignee: str) -> int | None:
        """Utilisateur non privilégié de la lignée (None sans isolation d'utilisateur : simulation hors root)."""
        if not self.isolation["utilisateur"]:
            return None
        etat = self.lignees.get(lignee)
        if etat is not None and etat.get("uid") is not None:
            return etat["uid"]
        return bac_a_sable.uid_lignee(sorted(self.lignees).index(lignee) if lignee in self.lignees else len(self.lignees), self.decalage_uid)

    def _empreintes_fuite(self) -> set:
        """CE3-04 : empreintes des fenêtres de mots des tâches de test (développement et final) de la banque, calculées une
        fois. La recherche et le téléchargement refusent de servir une requête ou un document qui en recoupe une : la
        recherche de provenance d'un texte de test n'est pas servie (le texte final vient d'un jeu public)."""
        if getattr(self, "_cache_empreintes_fuite", None) is None:
            from .garde_fuite import MOTS, MOTS_COURTS, empreintes_de_fuite
            textes = [t["texte"] for t in (self.banque.get("test") or [])] + [t["texte"] for t in (self.banque.get("test_final") or [])]
            train = [t["texte"] for t in (self.banque.get("train") or [])]
            # RV-12 : une fenêtre présente aussi dans l'entraînement (que l'organisme a) est un gabarit commun, pas une fuite
            self._cache_empreintes_fuite = empreintes_de_fuite(textes, MOTS, exclure=train)
            self._cache_empreintes_courtes = empreintes_de_fuite(textes, MOTS_COURTS, exclure=train)
        return self._cache_empreintes_fuite

    def _empreintes_courtes(self) -> set:
        """RV-07 (ii) : fenêtres courtes des textes de test (moins celles de l'entraînement), pour la mesure sans refus."""
        self._empreintes_fuite()
        return self._cache_empreintes_courtes

    def _rechercheur(self, dossier: pathlib.Path, budget: dict | None = None, telechargeur=None):
        """Un rechercheur par génération ; None si `recherches_max` vaut 0 (recherche non servie)."""
        budget = budget or self.budget
        if int(budget["recherches_max"]) <= 0:
            return None
        backend = self.recherche(None) if self.recherche is not None else None
        return _recherche.Rechercheur(dossier, int(budget["recherches_max"]), backend, telechargeur=telechargeur,
                                      empreintes_fuite=self._empreintes_fuite(), empreintes_courtes=self._empreintes_courtes())

    def _telechargeur(self, dossier_corpus: pathlib.Path, budget: dict | None = None, dossier_noyau: pathlib.Path | None = None):
        """Un téléchargeur par génération ; None si `telechargements_max` vaut 0. Le corpus vit dans `dossier_corpus`,
        frère du dossier de travail, à root (CE3-07) ; recopié dans l'archive et la vue sous `travail/corpus` au dépôt ;
        double sans réseau en simulation."""
        budget = budget or self.budget
        if int(budget.get("telechargements_max", 0)) <= 0:
            return None
        backend = _moisson.telechargement_simule if self.recherche is not None else None
        return _moisson.Telechargeur(dossier_corpus, int(budget["telechargements_max"]),
                                     octets_max_total=int(budget.get("octets_max", _moisson.OCTETS_MAX_GENERATION)), backend=backend,
                                     empreintes_fuite=self._empreintes_fuite(), empreintes_courtes=self._empreintes_courtes(),
                                     journal_noyau=(pathlib.Path(dossier_noyau) / "journal-fuite.jsonl" if dossier_noyau is not None else None))

    def _entraineur(self, dossier: pathlib.Path, lignee: str, g: int, traits_sup: dict | None = None, budget: dict | None = None):
        """Un entraîneur par génération ; None si `entrainements_max` vaut 0. Les vérités servies sont celles de
        l'entraînement seulement ; `traits_sup` ajoute des traits (tâches d'attaque en confrontation, simulation)."""
        budget = budget or self.budget
        if int(budget.get("entrainements_max", 0)) <= 0 or not self.vues:
            return None
        verites = {t["id"]: (1.0 if t["verite"] == _taches.ETIQUETTES[t["famille"]][0] else 0.0) for t in self.banque["train"]}
        vues = {nom: dict(t) for nom, t in self.vues.items()}
        for nom, t in _entrainement.normaliser_vues(traits_sup).items() if traits_sup else ():
            if nom not in vues:
                raise Arret(f"traits supplémentaires pour une vue non servie : {nom!r}")
            vues[nom].update(t)
        # CE-02 : l'objectif écrit par l'organisme tourne sous un utilisateur non privilégié propre à l'entraîneur de la
        # lignée, dans des espaces de noms neufs, réseau coupé ; en réel, sans cette isolation, aucun entraînement
        uid_ent, isole = None, False
        if self.isolation["utilisateur"]:
            idx = sorted(self.lignees).index(lignee) if lignee in self.lignees else len(self.lignees)
            uid_ent, isole = bac_a_sable.uid_entraineur(idx, self.decalage_uid), bool(self.isolation["reseau"])
        elif self.reel:
            raise Arret("entraîneur sans isolation d'utilisateur en réel : refusé (CE-02)")
        return _entrainement.Entraineur(dossier, vues, verites, int(budget["entrainements_max"]), pas_max=int(budget.get("pas_max", _entrainement.PAS_MAX_DEFAUT)),
                                        delai_s=int(budget.get("delai_entrainement_s", self.budget.get("delai_entrainement_s", _entrainement.DELAI_S_DEFAUT))),
                                        uid=uid_ent, isoler_reseau=isole, espace=(self.espace if uid_ent is not None else None),
                                        prefixe=f"{lignee[:12]}-g{g:03d}")

    def _contexte_traits(self, disponibles: bool) -> dict:
        """`contexte["traits"]` : vues servies et leur dimension ; `dimension` (celle de la première vue) reste pour les
        organismes écrits avant les vues ; `spec["vue"]` désigne la vue d'un entraînement."""
        dims = _entrainement.dimensions_vues(self.vues) if self.vues else {}
        return {"disponibles": bool(disponibles), "vues": dims, "dimension": (next(iter(dims.values())) if dims else 0),
                "description": self.description_traits}

    def _appelant(self, dossier: pathlib.Path, budget: dict | None = None) -> Appelant:
        budget = budget or self.budget
        plafond = min(float(budget["usd_max"]), self._plafond_restant())
        return Appelant(dossier, plafond, self.appelants, self.reel, self.go_id)

    # ---- amorçage ----
    def amorcer(self) -> dict:
        exemples = self.banque["train"][:6]
        prompt = contrat.prompt_amorcage(self.mission, _taches.ETIQUETTES, self.budget, exemples)
        (self.racine / "amorcage-consigne.txt").write_text(prompt, encoding="utf-8")
        bac_a_sable.proteger(self.racine / "amorcage-consigne.txt", 0o600)
        resultats = {}
        for espece in self.especes_amorcage:
            lignee = espece.lower().replace("_", "-")
            dossier = self.racine / "lignees" / lignee / "g000"
            dossier.mkdir(parents=True, exist_ok=True)
            appelant = self._appelant(dossier / "noyau-amorcage")
            bac_a_sable.proteger(dossier / "noyau-amorcage", 0o700)
            try:
                res = appelant.appeler(espece, "amorcage", prompt, role="amorcage")
            except Arret as e:  # CR-02 (6) : un plafond à l'amorçage est un statut archivé, pas une sortie sans rapport
                self.depense_totale += appelant.depense_usd
                resultats[lignee] = {"espece": espece, "statut": "AMORCAGE_PLAFOND", "problemes": [str(e)[:200]], "n_fichiers": 0,
                                     "id_appel": None, "cout_usd": appelant.depense_usd}
                self._evenement(etape="amorcage", lignee=lignee, **resultats[lignee])
                continue
            self.depense_totale += appelant.depense_usd
            self.n_appels_total += 1
            self._noter_credit(appelant, lignee, 0, "amorcage")  # CE3-05
            if appelant.journal.exists():
                _archive.sceller(appelant.journal)  # CR-02 (8) : le journal d'amorçage est scellé comme les autres
            fichiers = contrat.extraire_fichiers(res.texte) if res.ok else {}
            problemes = contrat.ecrire_organisme(fichiers, dossier) if fichiers else ["aucun fichier dans la réponse"]
            if not res.ok:
                problemes = [f"appel d'amorçage en statut {res.statut}"] + problemes
            statut = "ORGANISME_VALIDE" if not problemes else "AMORCAGE_INVALIDE"
            if res.statut == "MODELE_NON_CONFORME":
                statut = "AMORCAGE_INVALIDE_MODELE"
            resultats[lignee] = {"espece": espece, "statut": statut, "problemes": problemes, "n_fichiers": len(fichiers),
                                 "id_appel": res.identifiant, "cout_usd": appelant.depense_usd,
                                 "journal": str(appelant.journal), "sha256_journal": (_archive.empreinte_fichier(appelant.journal) if appelant.journal.exists() else None)}
            if statut == "ORGANISME_VALIDE":
                self.lignees[lignee] = {"espece_amorcage": espece, "famille": contrat.FAMILLES[espece], "generation": 0,
                                        "organisme": dossier / "organisme", "active": True, "impose": False,
                                        "uid": (bac_a_sable.uid_lignee(len(self.lignees), self.decalage_uid) if self.isolation["utilisateur"] else None)}
            self._evenement(etape="amorcage", lignee=lignee, **resultats[lignee])
        # lignées imposées : génération 0 fournie (aucun appel), validée par le même contrat que les auto-écrites
        for nom, spec in self.organismes_imposes.items():
            source = pathlib.Path(spec["organisme"])
            problemes = contrat.valider_organisme(source)
            dossier = self.racine / "lignees" / nom / "g000"
            if not problemes:
                dossier.mkdir(parents=True, exist_ok=True)
                if (dossier / "organisme").exists():
                    shutil.rmtree(dossier / "organisme")
                shutil.copytree(source, dossier / "organisme", symlinks=False, ignore=shutil.ignore_patterns("__pycache__"))
                problemes = contrat.valider_organisme(dossier / "organisme")
            statut = "ORGANISME_IMPOSE_VALIDE" if not problemes else "ORGANISME_IMPOSE_INVALIDE"
            resultats[nom] = {"espece": None, "famille": spec["famille"], "statut": statut, "problemes": problemes,
                              "source": str(source), "empreinte_arbre": (empreinte_arbre(source) if source.is_dir() else None),
                              "id_appel": None, "cout_usd": 0.0}
            if statut == "ORGANISME_IMPOSE_VALIDE":
                self.lignees[nom] = {"espece_amorcage": None, "famille": spec["famille"], "generation": 0,
                                     "organisme": dossier / "organisme", "active": True,
                                     # CE4-05 : une lignée auto-écrite relancée par `--depuis` garde sa marque d'origine
                                     "impose": bool(spec.get("impose", True)),
                                     "uid": (bac_a_sable.uid_lignee(len(self.lignees), self.decalage_uid) if self.isolation["utilisateur"] else None)}
                # bras apparié adaptatif (`--depuis` sans `--gel`, CE-06) : la génération 0 relancée doit voir ce que la
                # génération 0 d'origine voyait — ses rondes de conception (historique et vue) ; le bras gelé reste sans archive
                if spec.get("course_origine") and not self.gel:
                    uid_l = self.lignees[nom]["uid"]
                    importees = self.archive.importer_conception(pathlib.Path(spec["course_origine"]), nom,
                                                                 gid=(uid_l if (uid_l is not None and not self.memoire_partagee) else None))
                    # CE4-05 / RV-09 : le contexte de B dit la même borne de conception que celui de A (sans nouvelle ronde)
                    self.rondes_conception_contexte = max(int(getattr(self, "rondes_conception_contexte", 0)),
                                                          int(spec.get("rondes_conception_max_origine") or 0))
                    resultats[nom]["rondes_conception_importees"] = [int(l["generation"]) for l in importees]
                    if importees:
                        self._evenement(etape="conception_importee", lignee=nom, course_origine=spec["course_origine"],
                                        rondes=[int(l["generation"]) for l in importees])
            self._evenement(etape="amorcage", lignee=nom, **resultats[nom])
        return resultats

    # ---- une génération ----
    def executer_generation(self, lignee: str, conception: int | None = None) -> dict:
        """Une génération notée (défaut) ou, avec `conception=k`, la k-ième ronde de la phase de conception : même bac à
        sable, budget de conception, aucune tâche de test, aucun score ; le successeur valide devient l'organisme de la
        ronde suivante, ou la génération 0 après la dernière ronde ; sans successeur valide, l'organisme reste."""
        etat = self.lignees[lignee]
        g = etat["generation"] if conception is None else int(conception)
        phase = None if conception is None else "conception"
        budget = self.budget if conception is None else self.budget_conception
        organisme = etat["organisme"]
        travail = self.espace / "travail" / lignee / _archive.Archive.nom_generation(g, phase)
        # CE3-07 : les dossiers du noyau (journaux, bac de l'entraîneur ; corpus moissonné) sont des frères de `travail`, sous
        # un parent à root (0711) : l'organisme, propriétaire de `travail`, ne peut ni les renommer ni les remplacer
        dossier_noyau = travail.parent / f"{travail.name}.noyau"
        dossier_corpus = travail.parent / f"{travail.name}.corpus"
        for dd in (travail, dossier_noyau, dossier_corpus):
            if dd.exists():
                shutil.rmtree(dd)
        travail.mkdir(parents=True)
        bac_a_sable.proteger(travail.parent, 0o711)
        dossier_noyau.mkdir()
        bac_a_sable.proteger(dossier_noyau, 0o700)
        ordre_train = np.random.default_rng(self.graine(lignee, g, "ordre_train", phase)).permutation(len(self.banque["train"]))
        # test de développement (score rendu) et test final (jamais rendu), mêlés sans distinction pour l'organisme
        tous_tests = [] if phase else list(self.banque["test"]) + list(self.banque["test_final"])
        ordre_test = np.random.default_rng(self.graine(lignee, g, "ordre_test", phase)).permutation(len(tous_tests))
        graine_organisme = self.graine(lignee, g, "organisme", phase)
        # vivier de conception : à la suite des tâches d'entraînement de la banque, dans un ordre tiré par la graine de la
        # ronde ; jamais en génération notée ; sans traits (ni `entrainer` ni `predire` sur elles)
        vivier = list(self.vivier["taches"]) if (phase and self.vivier) else []
        ordre_vivier = (np.random.default_rng(self.graine(lignee, g, "ordre_vivier", phase)).permutation(len(vivier)) if vivier else [])
        # bras gelé : témoin sans aucune transmission entre générations — archive vide et historique vide, sinon
        # l'organisme relit sa propre mémoire archivée (Gemini le fait : `charger_connaissances_archive`)
        archive_vue = self._vue_pour(lignee)
        contexte = {
            "generation": (0 if phase else g), "lignee": lignee, "mission": contrat.mission_texte(self.mission, _taches.ETIQUETTES),
            "phase": (phase or "generation"), "ronde_conception": (g if phase else None), "rondes_conception_max": max(self.rondes_conception, int(getattr(self, "rondes_conception_contexte", 0))),
            "dossier_travail": str(travail), "dossier_archive": str(archive_vue),
            "taches_entrainement": ([dict(_taches.masquer(self.banque["train"][i]), verite=self.banque["train"][i]["verite"]) for i in ordre_train]
                                    + [dict(_taches.masquer(vivier[i]), verite=vivier[i]["verite"]) for i in ordre_vivier]),
            "taches_test": [_taches.masquer(tous_tests[i]) for i in ordre_test],
            "budget": {"appels_max": int(budget["appels_max"]), "usd_max": round(min(float(budget["usd_max"]), self._plafond_restant()), 4),
                       "temps_max_s": int(budget["temps_max_s"]), "recherches_max": int(budget["recherches_max"]),
                       "telechargements_max": int(budget.get("telechargements_max", 0)), "octets_max": int(budget.get("octets_max", _moisson.OCTETS_MAX_GENERATION)),
                       "entrainements_max": int(budget.get("entrainements_max", 0)), "pas_max": int(budget.get("pas_max", _entrainement.PAS_MAX_DEFAUT)),
                       "max_tokens_appel": (int(budget["max_tokens_appel"]) if budget.get("max_tokens_appel") else None)},
            "traits": self._contexte_traits(bool(self.vues) and int(budget.get("entrainements_max", 0)) > 0),
            "historique": ([] if self.gel else self.archive.historique(lignee)), "relance": bool(etat.get("relance_en_cours")),
            "graine": graine_organisme,
            "question_ouverte": (self.question.pour(g, phase) if self.question is not None else None),
        }
        if vivier:
            familles_v: dict[str, int] = {}
            for t in vivier:
                familles_v[t["famille"]] = familles_v.get(t["famille"], 0) + 1
            contexte["vivier"] = {"n": len(vivier), "familles": familles_v, "ids": sorted(t["id"] for t in vivier)}
        question_posee = contexte["question_ouverte"] is not None
        appelant = self._appelant(dossier_noyau, budget)
        chemin_socket = str(travail / "noyau.sock")
        if len(chemin_socket) > 100:  # limite des sockets Unix ; nom unique par course (CR-12), hors de /tmp et imprévisible (RV-04)
            chemin_socket = str(bac_a_sable.dossier_sockets() / f"essaim-{hashlib.sha256(str(self.racine).encode()).hexdigest()[:10]}-{lignee[:10]}-g{g}-{secrets.token_hex(8)}.sock")
        uid = self._uid(lignee)
        bac_a_sable.preparer(travail, organisme, contexte, uid=uid)
        telechargeur = self._telechargeur(dossier_corpus, budget, dossier_noyau)
        if telechargeur is not None:
            self._proteger_lecture_lignee(dossier_corpus, uid)
        rechercheur = self._rechercheur(dossier_noyau, budget, telechargeur)
        bac_a_sable.proteger(dossier_noyau, 0o700)
        entraineur = self._entraineur(dossier_noyau, lignee, g, budget=budget)
        with ServeurAppels(appelant, chemin_socket, int(budget["appels_max"]), self.parallele_max, rechercheur, entraineur, telechargeur,
                           max_tokens_appel=budget.get("max_tokens_appel")) as serveur:
            execution = bac_a_sable.executer(travail, chemin_socket, int(budget["temps_max_s"]), isoler_reseau=self.isoler_reseau, uid=uid)
        # RV-08 : lus après la sortie du serveur, qui attend les appels encore en vol (journal et dépense complets)
        n_appels = serveur.n_appels
        refus = list(serveur.refus)
        en_vol_max = serveur.en_vol_max
        non_conformes = serveur.non_conformes
        indisponibles = dict(serveur.indisponibles)
        if serveur.fils_non_finis:
            execution = dict(execution, appels_en_vol_non_finis=serveur.fils_non_finis)
        if non_conformes:  # CR-02 (1) : génération invalidée, exclue des hypothèses, lignée arrêtée
            execution = dict(execution, code="INVALIDE_MODELE", code_origine=execution.get("code"), non_conformes=non_conformes)
        # CE3-07 : le journal des appels vit hors d'atteinte de l'organisme ; son absence alors que des appels ont été servis
        # est une anomalie du noyau, jamais un silence : génération invalidée, consignée
        anomalie_noyau = anomalie_journal_absent(n_appels, appelant.journal)
        if anomalie_noyau:
            execution = dict(execution, code="ANOMALIE_NOYAU", code_origine=execution.get("code"), anomalie=anomalie_noyau)
        # CE3-05 : un crédit de fournisseur épuisé (HTTP 402, ou 400 « credit balance is too low », R-395) invalide la génération où il survient et arrête la course
        self._noter_credit(appelant, lignee, g, phase)
        if getattr(appelant, "credit_epuise", None) and not anomalie_noyau:
            anomalie_noyau = (f"crédit d'un fournisseur épuisé en cours de génération (HTTP 402 ou 400 de crédit, {appelant.credit_epuise.get('espece')}) : "
                              "génération invalidée, course arrêtée (CE3-05)")
            execution = dict(execution, code="CREDIT_EPUISE", code_origine=execution.get("code"), anomalie=anomalie_noyau)
        n_recherches = rechercheur.compteur if rechercheur is not None else 0
        n_entrainements = entraineur.compteur if entraineur is not None else 0
        n_telechargements = telechargeur.compteur if telechargeur is not None else 0
        if telechargeur is not None:
            self._proteger_lecture_lignee(dossier_corpus, uid)
            if telechargeur.index.exists():
                _archive.sceller(telechargeur.index)  # corpus moissonné scellé en fin de génération
        self.depense_totale += appelant.depense_usd
        self.n_appels_total += n_appels
        # jugement externe
        reponses = {}
        chemin_rep = travail / "reponses_test.json"
        probleme_reponses = None
        # R-372 : jamais de lecture qui suit un lien ou attend sur un tube (fichier ordinaire, taille bornée, sinon refus consigné)
        donnees_rep, raison_rep = _fichiers.lire_fichier_organisme(chemin_rep, _fichiers.OCTETS_MAX_REPONSES)
        if donnees_rep is not None:
            try:
                brut = json.loads(donnees_rep.decode("utf-8-sig"))
                if isinstance(brut, dict):
                    for t in tous_tests:
                        r = brut.get(t["id"])
                        if isinstance(r, dict) and str(r.get("etiquette", "")).strip().lower() in _taches.ETIQUETTES[t["famille"]]:
                            reponses[t["id"]] = {"etiquette": str(r["etiquette"]).strip().lower(), "confiance": _taches.confiance_de(r)}
                else:
                    probleme_reponses = "reponses_test.json n'est pas un objet"
            except (json.JSONDecodeError, UnicodeDecodeError) as e:
                probleme_reponses = f"reponses_test.json illisible : {str(e)[:100]}"
        elif raison_rep == "absent":
            probleme_reponses = "reponses_test.json absent"
        else:
            probleme_reponses = f"reponses_test.json {raison_rep}"
        if phase:
            score = {"score": None, "phase": phase, "probleme_reponses": None}  # jamais notée
            score_final = None
        else:
            score = _taches.evaluer({k: v for k, v in reponses.items() if k in {t["id"] for t in self.banque["test"]}}, self.banque["test"])
            score["probleme_reponses"] = probleme_reponses
            score_final = None
            if self.banque["test_final"]:
                score_final = _taches.evaluer({k: v for k, v in reponses.items() if k in {t["id"] for t in self.banque["test_final"]}}, self.banque["test_final"])
        # métrique proposée par l'organisme (archivée, jamais utilisée par le noyau)
        metrique = None
        chemin_metrique = travail / "metrique_proposee.json"
        donnees_m, raison_m = _fichiers.lire_fichier_organisme(chemin_metrique, _fichiers.OCTETS_MAX_METRIQUE)
        if donnees_m is not None:
            try:
                m = json.loads(donnees_m.decode("utf-8-sig"))
                metrique = m if isinstance(m, dict) else {"illisible": True}
            except (json.JSONDecodeError, UnicodeDecodeError):
                metrique = {"illisible": True}
        elif raison_m != "absent":
            metrique = {"refuse": raison_m}  # R-372 : un lien (vers la banque, par exemple) n'est jamais lu
        # successeur
        successeur = travail / "successeur" / "organisme"
        if _fichiers.vrai_dossier(travail / "successeur") and _fichiers.vrai_dossier(successeur):
            speciaux = _fichiers.elements_non_ordinaires(successeur)  # R-372 : liens, tubes, liens durs multiples refusés
            problemes_succ = [f"successeur : {x}" for x in speciaux[:10]] or contrat.valider_organisme(successeur)
        elif os.path.lexists(travail / "successeur") or os.path.lexists(successeur):
            problemes_succ = ["successeur refusé : lien symbolique ou fichier spécial à la place d'un dossier (R-372)"]
        else:
            problemes_succ = ["successeur absent"]
        a_successeur = not problemes_succ
        resume = {"statut": execution["code"], "execution": execution, "n_appels": n_appels, "cout_usd": round(appelant.depense_usd, 4),
                  "refus_noyau": refus, "indisponibles": indisponibles, "appels_simultanes_max": en_vol_max, "successeur": a_successeur, "problemes_successeur": problemes_succ,
                  "n_reponses_test": len(reponses), "score": score["score"], "metrique_proposee": metrique, "gel": self.gel,
                  "impose": bool(etat.get("impose")), "famille": etat.get("famille"), "relance": bool(etat.get("relance_en_cours")),
                  "n_recherches": n_recherches, "n_entrainements": n_entrainements, "n_telechargements": n_telechargements, "invalide": bool(non_conformes) or bool(anomalie_noyau), "non_conformes": non_conformes,
                  "anomalie_noyau": anomalie_noyau, "phase": phase}
        # question ouverte (contrat § 7) : la réponse est lue sans lien et bornée avant le dépôt, résumée sans son contenu ;
        # un organisme qui n'a rien écrit n'a rien de noté contre lui ; aucun score n'en dépend
        lecture_question = _question.lire_reponse(travail) if question_posee else None
        if question_posee:
            resume["question_ouverte"] = _question.resume_lecture(lecture_question, True)
        self.archive.deposer(lignee, g, organisme, travail, appelant.journal, score, resume, score_final, phase=phase,
                             dossier_noyau=dossier_noyau, dossier_corpus=dossier_corpus,
                             gid=(uid if (uid is not None and not self.memoire_partagee) else None),
                             reponses_lues=(None if phase else {"reponses": {k: v["etiquette"] for k, v in reponses.items()},
                                                                "probleme_reponses": probleme_reponses}))
        # RV-02 : la mémoire d'une génération ne passe que par sa vue (dans les deux bras) : les dossiers vivants (travail,
        # journaux du noyau, corpus) sont rendus au seul root après le dépôt et la lecture du successeur (ci-dessous)
        vivants = [travail, dossier_noyau, dossier_corpus]
        if question_posee:  # pièce à la racine de la génération archivée (scellée) et dans la vue de la seule lignée
            dossier_gen = self.archive.racine / lignee / _archive.Archive.nom_generation(g, phase)
            vue_gen = self.archive.vue / lignee / _archive.Archive.nom_generation(g, phase)
            _question.archiver_reponse(lecture_question, dossier_gen, vue_gen, gid=(uid if (uid is not None and not self.memoire_partagee) else None))
            self._evenement(etape="question_ouverte", lignee=lignee, generation=g, phase=phase, **resume["question_ouverte"])
        self._evenement(etape=("conception" if phase else "generation"), lignee=lignee, generation=g, statut=execution["code"], score=score["score"],
                        n_appels=n_appels, cout_usd=resume["cout_usd"], successeur=a_successeur, cumul_usd=round(self.depense_totale, 4))
        etat["relance_en_cours"] = False
        if non_conformes or anomalie_noyau:
            etat["active"] = False
            etat["fin"] = ("appel à modèle non conforme : génération invalidée (CR-02)" if non_conformes
                           else f"anomalie du noyau : génération invalidée ({anomalie_noyau})")
            self._verrouiller_vivants(vivants)
            return resume
        if phase:  # phase de conception : le successeur valide devient l'organisme de la ronde suivante ou de la génération 0
            fin = travail / "fin_conception.json"  # l'organisme déclare lui-même la fin de sa conception (son critère, ses valeurs)
            donnees_f, raison_f = _fichiers.lire_fichier_organisme(fin, _fichiers.OCTETS_MAX_FIN_CONCEPTION)
            if donnees_f is not None or raison_f != "absent":  # présent : déclaration lue, ou refusée et consignée (R-372)
                if donnees_f is None:
                    declaration = {"refuse": raison_f}
                else:
                    try:
                        declaration = json.loads(donnees_f.decode("utf-8-sig"))
                    except (json.JSONDecodeError, UnicodeDecodeError):
                        declaration = {"illisible": True}
                etat["conception_finie"] = True
                self._evenement(etape="fin_conception", lignee=lignee, ronde=g, declaration=(declaration if isinstance(declaration, dict) else {"brut": str(declaration)[:500]}))
            derniere = etat.get("conception_finie") or g >= self.rondes_conception
            if a_successeur:
                cible = self.racine / "lignees" / lignee / ("g000-concu" if derniere else f"c{g + 1:03d}") / "organisme"
                cible.parent.mkdir(parents=True, exist_ok=True)
                if cible.exists():
                    shutil.rmtree(cible)
                _fichiers.copier_sans_liens(successeur, cible)  # validé sans élément non ordinaire : rien n'est écarté
                etat["organisme"] = cible
            else:
                self._evenement(etape="conception_sans_successeur", lignee=lignee, ronde=g, problemes_successeur=problemes_succ[:10])
            self._verrouiller_vivants(vivants)
            return resume
        if self.gel and g + 1 < self.generations_max:
            etat.update(generation=g + 1)  # même organisme (génération 0), relancé : bras témoin
        elif a_successeur and g + 1 < self.generations_max:
            prochain = self.racine / "lignees" / lignee / f"g{g + 1:03d}" / "organisme"
            prochain.parent.mkdir(parents=True, exist_ok=True)
            _fichiers.copier_sans_liens(successeur, prochain)  # validé sans élément non ordinaire : rien n'est écarté
            etat.update(generation=g + 1, organisme=prochain, relances_consecutives=0)
        elif not a_successeur and g + 1 < self.generations_max and etat.get("relances_consecutives", 0) < self.relances_max:
            # nœud 2, option (b) : la dernière génération valide (celle qui vient de tourner) est relancée telle quelle ;
            # l'organisme voit le refus de son successeur dans `historique` et `contexte["relance"]`
            etat.update(generation=g + 1, relances_consecutives=etat.get("relances_consecutives", 0) + 1, relance_en_cours=True)
            self._evenement(etape="relance", lignee=lignee, generation=g + 1, problemes_successeur=problemes_succ[:10])
        else:
            etat["active"] = False
            if a_successeur:
                etat["fin"] = "générations maximales"
            elif etat.get("relances_consecutives", 0) >= self.relances_max and self.relances_max > 0:
                etat["fin"] = "sans successeur valide après relance"
            else:
                etat["fin"] = "sans successeur valide"
        self._verrouiller_vivants(vivants)
        return resume

    # ---- boucle ----
    def _sources_moisson(self) -> list[str]:
        """CE3-05 / CE3-18 : sources de moisson réellement servies à cette course, consignées au manifeste (la source « web »
        n'existe que si la clé Brave est dans l'environnement du noyau ; sa valeur n'est jamais écrite)."""
        if int(self.budget.get("recherches_max", 0)) <= 0:
            return []
        if self.recherche is not None:
            return ["simulation"]
        return sorted(n for n in _moisson.sources_disponibles() if n != "web" or os.environ.get("BRAVE_API_KEY"))

    def _doit_arreter(self) -> str | None:
        """Raison d'arrêter la course avant la prochaine génération ou ronde, ou None : fichier STOP ; crédit d'un fournisseur
        épuisé en cours de course (HTTP 402 ou 400 de crédit, CE3-05 et R-395 : course arrêtée, consignée, lue telle quelle, aucune relance) ;
        plafond total atteint."""
        if (self.racine / "STOP").exists():
            return "fichier STOP"
        if getattr(self, "arret_credit", None):
            return f"crédit d'un fournisseur épuisé (HTTP 402 ou 400 de crédit) : {self.arret_credit.get('espece')} (CE3-05)"
        if self._plafond_restant() <= 0:
            return "plafond total atteint"
        return None

    def _noter_credit(self, appelant, lignee: str, generation: int, phase: str | None) -> None:
        """CE3-05 : un appelant qui a reçu un crédit épuisé (HTTP 402, ou 400 de crédit, R-395) arrête la course (premier constat consigné)."""
        if getattr(appelant, "credit_epuise", None) and not getattr(self, "arret_credit", None):
            self.arret_credit = dict(appelant.credit_epuise, lignee=lignee, generation=generation, phase=phase)
            self._evenement(etape="credit_epuise", **self.arret_credit)

    def _tourner_ronde(self, conception: int | None = None) -> str | None:
        """Fait tourner les lignées de la ronde en cours qui n'ont pas encore tourné, dans l'ordre tiré, la garde d'arrêt lue
        avant chacune ; rend la raison qui l'interrompt (la ronde reste alors en cours, ses lignées faites consignées), ou
        None quand toutes ont tourné. Reprise par segments : une ronde interrompue par `STOP` est continuée là, jamais tirée
        de nouveau (aucune lignée rejouée, aucune sautée)."""
        r = self._ronde_en_cours
        for lignee in r["ordre"][len(r["faites"]):]:
            raison = self._doit_arreter()
            if raison:
                return raison
            self.executer_generation(lignee, conception=conception)
            r["faites"].append(lignee)
        self._ronde_en_cours = None
        return None

    def concevoir(self) -> str | None:
        """Phase de conception : rondes jusqu'à la borne dure, ordre tiré, aucune note ; une lignée sort de la phase quand elle
        déclare `fin_conception.json` (son critère) ; aucun arrêt de lignée hors modèle non conforme ou STOP. Rend la raison
        qui arrête la phase avant la borne (None : borne atteinte). Reprise par segments : elle repart de la première ronde
        qui n'est pas achevée (`_prochaine_ronde_conception`), en continuant la ronde en cours s'il y en a une."""
        while self._prochaine_ronde_conception <= self.rondes_conception:
            k = self._prochaine_ronde_conception
            raison = self._doit_arreter()
            if raison:
                self._evenement(etape="arret_conception", ronde=k, raison=raison)
                return raison
            if self._ronde_en_cours is None:
                if not any(e["active"] for e in self.lignees.values()):  # CE3-12 : raison juste quand aucune lignée n'existe
                    self._evenement(etape="arret_conception", ronde=k, raison="aucune lignée active")
                    return "aucune lignée active"
                actives = [l for l, e in self.lignees.items() if e["active"] and not e.get("conception_finie")]
                if not actives:
                    self._evenement(etape="arret_conception", ronde=k, raison="toutes les lignées ont déclaré la fin de leur conception")
                    return "toutes les lignées ont déclaré la fin de leur conception"
                rng = np.random.default_rng(self.graine_ronde(k, conception=True))
                ordre = [actives[i] for i in rng.permutation(len(actives))]
                self._evenement(etape="ronde_conception", ronde=k, ordre=ordre)
                self._ronde_en_cours = {"phase": "conception", "ronde": k, "ordre": list(ordre), "faites": []}
            if self._tourner_ronde(conception=k) is None:
                self._prochaine_ronde_conception = k + 1
        return None

    def boucler(self) -> dict:
        if self.rondes_conception and not self.gel and not getattr(self, "_conception_faite", False):
            raison_conception = self.concevoir()
            # reprise par segments : une conception arrêtée par STOP n'est pas faite ; la course s'arrête là (aucune génération
            # notée ne part avant la fin de la conception) et la reprise la continue
            self._conception_faite = raison_conception != "fichier STOP"
            if not self._conception_faite and any(e["active"] for e in self.lignees.values()):
                self._evenement(etape="arret", raison="fichier STOP")
                self._ecrire_etat_reprise("fichier STOP")
                return self.rapport()
        while True:
            raison = self._doit_arreter()
            if (raison == "fichier STOP" and not (self._ronde_en_cours and self._ronde_en_cours.get("phase") == "generation")
                    and not any(e["active"] for e in self.lignees.values())):
                # plus aucune unité à faire : la course finit ci-dessous (« aucune lignée active ») ; un STOP posé pendant la
                # dernière unité n'appelle pas de segment de plus
                raison = None
            if raison and raison != "plafond total atteint":
                self._evenement(etape="arret", raison=raison)
                if raison == "fichier STOP":  # reprise par segments : l'état qu'il faut pour continuer est écrit et scellé
                    self._ecrire_etat_reprise(raison)
                break
            if self._ronde_en_cours is None or self._ronde_en_cours.get("phase") != "generation":
                # base triée par nom (CE2-03) : deux courses aux mêmes lignées et à la même graine ont le même ordre de ronde,
                # quel que soit l'ordre d'insertion (bras apparié `--depuis` : toutes les lignées y entrent comme imposées)
                actives = sorted(l for l, e in self.lignees.items() if e["active"])
                if not actives:
                    self._evenement(etape="arret", raison="aucune lignée active")
                    break
                if self._plafond_restant() <= 0:
                    self._evenement(etape="arret", raison="plafond total atteint")
                    break
                # CR-15 (b) : ordre des lignées tiré par SeedSequence à chaque ronde et consigné ; vue figée au début de la ronde
                self.ronde += 1
                rng = np.random.default_rng(self.graine_ronde(self.ronde))
                ordre = [actives[i] for i in rng.permutation(len(actives))]
                self.vue_ronde = self._figer_vue(self.ronde) if (self.memoire_partagee and not self.gel) else None
                self._evenement(etape="ronde", ronde=self.ronde, ordre=ordre, vue_figee=(str(self.vue_ronde) if self.vue_ronde else None))
                self._ronde_en_cours = {"phase": "generation", "ronde": self.ronde, "ordre": list(ordre), "faites": [],
                                        "vue_figee": (str(self.vue_ronde) if self.vue_ronde else None)}
            elif self._plafond_restant() <= 0:  # ronde en cours (reprise ou interruption) et plafond atteint
                self._evenement(etape="arret", raison="plafond total atteint")
                break
            self._tourner_ronde()
        return self.rapport()

    # ---- reprise par segments (décision de Lazar, 25 octobre 2026, 20:23 Paris) ----
    def _ecrire_etat_reprise(self, raison: str) -> pathlib.Path:
        """À un arrêt sur `STOP` (lu entre deux unités, jamais pendant), écrit dans `reprise/etat-vN.json` l'état du noyau
        qu'il faut pour continuer la course dans une autre commande, et le scelle (compagnon `.sha256`) ; jamais réécrit
        (R12). Aucun événement n'est ajouté : l'état compte les événements de la course, dont l'arrêt."""
        dossier = self.racine / "reprise"
        dossier.mkdir(exist_ok=True)
        bac_a_sable.proteger(dossier, 0o700)
        n = 1
        while (dossier / f"etat-v{n}.json").exists():
            n += 1
        index = self.archive.index
        journal = self.racine / "evenements.jsonl"
        etat = {
            "version": ETAT_REPRISE_VERSION, "segment": int(self.segment), "quand_utc": _heure(), "raison_arret": raison,
            "manifeste_sha256": _archive.empreinte_fichier(self.racine / "manifeste-run.json"),
            "sha256_code_noyau": self.manifeste.get("sha256_code_noyau"),
            "conception_faite": bool(getattr(self, "_conception_faite", False)) or not self.rondes_conception or self.gel,
            "prochaine_ronde_conception": int(self._prochaine_ronde_conception),
            "ronde": int(self.ronde), "ronde_inachevee": self._ronde_en_cours,
            "lignees": {l: {k: (str(v) if isinstance(v, pathlib.Path) else v) for k, v in e.items()} for l, e in self.lignees.items()},
            "depense_totale_usd": self.depense_totale, "n_appels_total": int(self.n_appels_total),
            "rondes_conception_contexte": int(getattr(self, "rondes_conception_contexte", 0)),
            "arret_credit": getattr(self, "arret_credit", None),
            "archive_index_sha256": (_archive.empreinte_fichier(index) if index.exists() else None),
            "n_lignes_archive": len(self.archive.lignes()),
            "n_evenements": (sum(1 for l in journal.read_text(encoding="utf-8").splitlines() if l.strip()) if journal.exists() else 0),
        }
        chemin = dossier / f"etat-v{n}.json"
        chemin.write_text(json.dumps(etat, ensure_ascii=False, indent=1), encoding="utf-8")
        _archive.sceller(chemin)
        for f in (chemin, chemin.with_name(chemin.name + ".sha256")):
            bac_a_sable.proteger(f, 0o600)
        return chemin

    def reprendre(self) -> dict:
        """Continue, dans une nouvelle commande, une course arrêtée par `STOP` entre deux unités : à appeler à la place
        d'`amorcer()`, sur un noyau neuf construit avec les mêmes paramètres que la course, puis `boucler()`. Refusée
        (`Arret`, rien d'écrit) sur un noyau déjà amorcé ; sans état de reprise ; si l'état ne correspond pas à son
        compagnon, n'est pas d'un arrêt sur STOP ou d'une autre version ; si `STOP` est encore là ; si la course a bougé
        depuis l'état (événements, archive, manifeste) — donc jamais deux reprises du même état ; si un paramètre de ce
        lancement diffère de la course (`_projection_reprise`) ; si la ronde en cours est illisible ou incohérente, ou
        l'organisme d'une lignée active introuvable ; après un crédit épuisé ou au plafond total. Rien n'est rejoué ni
        sauté : la reprise part de la première unité qui n'a pas tourné (la ronde en cours est continuée dans son ordre
        tiré, avec sa vue figée), avec les graines de la course (même entropie, mêmes lignées), sa dépense et son archive.
        Le manifeste du rapport reste celui de la course ; ce qui est propre à ce lancement (heure, machine, extrait du
        registre des GO, chemins des pièces) est consigné dans l'événement `reprise`. Rend l'état relu."""
        if self.lignees or self.evenements:
            raise Arret("reprise : à appeler à la place d'amorcer(), sur un noyau neuf")
        dossier = self.racine / "reprise"
        etats = (sorted(dossier.glob("etat-v*.json"), key=lambda p: int("".join(ch for ch in p.stem if ch.isdigit()) or 0))
                 if dossier.is_dir() else [])
        if not etats:
            raise Arret("reprise : aucun état de reprise (reprise/etat-vN.json) dans la course")
        chemin = etats[-1]
        compagnon = chemin.with_name(chemin.name + ".sha256")
        if not compagnon.is_file() or compagnon.read_text(encoding="utf-8").split()[0] != _archive.empreinte_fichier(chemin):
            raise Arret(f"reprise : {chemin.name} ne correspond pas à son compagnon .sha256")
        etat = json.loads(chemin.read_text(encoding="utf-8"))
        if etat.get("version") != ETAT_REPRISE_VERSION:
            raise Arret(f"reprise : état de version {etat.get('version')!r}, attendue {ETAT_REPRISE_VERSION}")
        if etat.get("raison_arret") != "fichier STOP":
            raise Arret(f"reprise : l'état n'est pas celui d'un arrêt sur STOP ({etat.get('raison_arret')!r})")
        if (self.racine / "STOP").exists():
            raise Arret("reprise : le fichier STOP est encore dans la course (le lanceur le retire avant la reprise)")
        journal = self.racine / "evenements.jsonl"
        lignes_ev = [l for l in journal.read_text(encoding="utf-8").splitlines() if l.strip()] if journal.exists() else []
        if len(lignes_ev) != int(etat.get("n_evenements", -1)):
            raise Arret("reprise : la course a bougé depuis l'état (journal des événements) : une seule reprise par état")
        dernier = json.loads(lignes_ev[-1]) if lignes_ev else {}
        if dernier.get("etape") != "arret" or dernier.get("raison") != "fichier STOP":
            raise Arret("reprise : le dernier événement de la course n'est pas l'arrêt sur STOP de l'état")
        if _archive.empreinte_fichier(self.racine / "manifeste-run.json") != etat.get("manifeste_sha256"):
            raise Arret("reprise : le manifeste de la course n'est pas celui de l'état")
        index = self.archive.index
        if (_archive.empreinte_fichier(index) if index.exists() else None) != etat.get("archive_index_sha256"):
            raise Arret("reprise : l'archive de la course a changé depuis l'état")
        manifeste_course = json.loads((self.racine / "manifeste-run.json").read_text(encoding="utf-8"))
        a, b = _projection_reprise(manifeste_course), _projection_reprise(self.manifeste)
        ecarts = sorted(k for k in a if a[k] != b.get(k))
        if ecarts:
            raise Arret(f"reprise : ce lancement diffère de la course sur {ecarts}")
        if etat.get("arret_credit"):
            raise Arret("reprise : crédit d'un fournisseur épuisé pendant la course (CE3-05) : aucune reprise")
        if float(self.plafond_total) - float(etat["depense_totale_usd"]) <= 0:
            raise Arret("reprise : plafond total atteint")
        lignees = etat.get("lignees") or {}
        r = etat.get("ronde_inachevee")
        if r is not None:
            ordre, faites = list(r.get("ordre") or []), list(r.get("faites") or [])
            if (r.get("phase") not in ("conception", "generation") or not isinstance(r.get("ronde"), int) or not ordre
                    or len(faites) >= len(ordre) or faites != ordre[:len(faites)] or any(l not in lignees for l in ordre)):
                raise Arret(f"reprise : ronde en cours illisible dans {chemin.name}")
            if r["phase"] == "conception" and (etat.get("conception_faite") or r["ronde"] != int(etat.get("prochaine_ronde_conception", -1))):
                raise Arret("reprise : ronde de conception en cours incohérente avec l'état")
            if r["phase"] == "generation" and (not etat.get("conception_faite") or r["ronde"] != int(etat.get("ronde", -1))):
                raise Arret("reprise : ronde de génération en cours incohérente avec l'état")
            if r["phase"] == "generation" and self.memoire_partagee and not self.gel:
                vue = pathlib.Path(r.get("vue_figee") or "")
                if not (r.get("vue_figee") and vue.is_dir() and vue.resolve().is_relative_to(self.espace.resolve())):
                    raise Arret("reprise : vue figée de la ronde en cours introuvable dans l'espace de la course (mémoire partagée)")
        # les organismes d'une course vivent sous sa racine (`lignees/`) : un chemin dehors dit une course déplacée ou un état altéré
        racine_r = self.racine.resolve()
        hors = sorted(l for l, e in lignees.items() if e.get("organisme") and not pathlib.Path(e["organisme"]).resolve().is_relative_to(racine_r))
        if hors:
            raise Arret(f"reprise : organisme hors de la course pour les lignées {hors} (course déplacée ou état altéré)")
        absents = sorted(l for l, e in lignees.items() if e.get("active") and not (e.get("organisme") and pathlib.Path(e["organisme"]).is_dir()))
        if absents:
            raise Arret(f"reprise : organisme introuvable pour les lignées actives {absents}")
        nouveau = self.manifeste
        self.lignees = {}
        for l, e in lignees.items():
            e = dict(e)
            if e.get("organisme") is not None:
                e["organisme"] = pathlib.Path(e["organisme"])
            self.lignees[l] = e
        self.depense_totale = float(etat["depense_totale_usd"])
        self.n_appels_total = int(etat["n_appels_total"])
        self.ronde = int(etat["ronde"])
        self._conception_faite = bool(etat["conception_faite"])
        self._prochaine_ronde_conception = int(etat["prochaine_ronde_conception"])
        if r is not None:
            self._ronde_en_cours = {"phase": r["phase"], "ronde": int(r["ronde"]), "ordre": list(r["ordre"]), "faites": list(r["faites"])}
            if r["phase"] == "generation":
                self._ronde_en_cours["vue_figee"] = r.get("vue_figee")
                self.vue_ronde = pathlib.Path(r["vue_figee"]) if r.get("vue_figee") else None
        if int(etat.get("rondes_conception_contexte", 0)):
            self.rondes_conception_contexte = int(etat["rondes_conception_contexte"])
        self.segment = int(etat["segment"]) + 1
        self.manifeste = manifeste_course  # le rapport garde le manifeste de la course
        self._evenement(etape="reprise", segment=self.segment, etat=chemin.name, sha256_etat=_archive.empreinte_fichier(chemin),
                        conception_faite=self._conception_faite, prochaine_ronde_conception=self._prochaine_ronde_conception,
                        ronde=self.ronde, ronde_en_cours=({k: r[k] for k in ("phase", "ronde", "ordre", "faites")} if r is not None else None),
                        depense_relue_usd=round(self.depense_totale, 4), n_appels_relus=self.n_appels_total,
                        lancement={k: nouveau.get(k) for k in ("debut_utc", "plateforme", "coeurs", "registre_go")},
                        sources={"organismes_imposes": {nom: v.get("source") for nom, v in (nouveau.get("organismes_imposes") or {}).items()},
                                 "question_ouverte": (nouveau.get("question_ouverte") or {}).get("source"),
                                 "vivier": (nouveau.get("vivier") or {}).get("chemin")})
        return etat

    def _reprises(self) -> list[dict]:
        """Événements `reprise` de la course (un par segment au-delà du premier), relus du journal."""
        journal = self.racine / "evenements.jsonl"
        if not journal.exists():
            return []
        sortie = []
        for ligne in journal.read_text(encoding="utf-8").splitlines():
            if '"reprise"' in ligne:
                e = json.loads(ligne)
                if e.get("etape") == "reprise":
                    sortie.append(e)
        return sortie

    def _scores_finaux(self, lignes: list[dict]) -> dict:
        """Score sur le test final, lu une seule fois, à la fin, jamais rendu aux organismes. Générations notées et valides
        seulement (CR3-02 : ni rondes de conception, ni générations invalidées, ni rondes importées)."""
        sortie = {}
        for l in lignes:
            if l.get("phase") or l.get("invalide") or l.get("importee"):
                continue
            f = self.archive.racine / l["chemin"] / "juge" / "score-final.json"
            if f.exists():
                sortie.setdefault(l["lignee"], []).append(json.loads(f.read_text(encoding="utf-8"))["score"])
        return sortie

    def rapport(self) -> dict:
        lignes = self.archive.lignes()
        rapport = {
            "avertissement": "NON OPPOSABLE (R7) : résultats d'un essaim de modèles, juge externe en simulation ou préenregistré ; aucun chiffre n'est une preuve",
            "manifeste": self.manifeste, "fin_utc": _heure(), "depense_totale_usd": round(self.depense_totale, 4),
            "n_appels_total": self.n_appels_total, "lignees": {l: {k: (str(v) if isinstance(v, pathlib.Path) else v) for k, v in e.items()} for l, e in self.lignees.items()},
            "generations": lignes,
            "courbes": {l: [x["score"] for x in lignes if x["lignee"] == l and not x.get("invalide") and not x.get("phase")] for l in {x["lignee"] for x in lignes}},
            "rondes_conception": [{"lignee": x["lignee"], "ronde": x["generation"], "statut": x["statut"], "successeur": x.get("successeur"), "cout_usd": x.get("cout_usd")} for x in lignes if x.get("phase") == "conception" and not x.get("importee")],
            "rondes_conception_importees": [{"lignee": x["lignee"], "ronde": x["generation"], "course_origine": x.get("course_origine")} for x in lignes if x.get("importee")],
            "generations_invalidees": [{"lignee": x["lignee"], "generation": x["generation"], "statut": x["statut"]} for x in lignes if x.get("invalide")],
            "scores_finaux": self._scores_finaux(lignes),
            # reprise par segments : numéro de ce segment, et les reprises de la course (vide sans reprise)
            "segments": int(self.segment), "reprises": self._reprises(),
        }
        n = 1
        while (self.racine / f"rapport-v{n}.json").exists():
            n += 1
        chemin = self.racine / f"rapport-v{n}.json"
        chemin.write_text(json.dumps(rapport, ensure_ascii=False, indent=1), encoding="utf-8")
        _archive.sceller(chemin)
        return rapport
