contre-lecture d essai (fichier d une ligne, pas un rapport)
