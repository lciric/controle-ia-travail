# texte d essai
entropie E = 31679548110020923965693927519450262581 tirée au scellement
   graine de la course v5-3 = 17629878560148353776
   graine de la course v6-1 = 4068166376944131946
empreintes : `0c333b524f6632d0292df2a0e0378b0018bc6fb0298aed16f9e37972451844dc`
   graine de la course v5-3 = 99
