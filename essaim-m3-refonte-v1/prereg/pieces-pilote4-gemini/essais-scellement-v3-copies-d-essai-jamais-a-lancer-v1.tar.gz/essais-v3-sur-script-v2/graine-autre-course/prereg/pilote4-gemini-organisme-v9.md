# texte d essai
entropie E = 67212473130941924933861816083099326082 tirée au scellement
   graine de la course v5-3 = 12418400779614300029
   graine de la course v6-1 = 3050883683209539859
empreintes : `0c333b524f6632d0292df2a0e0378b0018bc6fb0298aed16f9e37972451844dc`
   graine de la course v6-2 = 7
