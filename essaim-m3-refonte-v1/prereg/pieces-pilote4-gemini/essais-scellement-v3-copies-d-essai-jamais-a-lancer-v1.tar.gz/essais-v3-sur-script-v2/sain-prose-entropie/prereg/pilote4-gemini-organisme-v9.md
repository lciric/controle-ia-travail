# texte d essai
entropie E = 53340478282593405055466700646043083975 tirée au scellement
   graine de la course v5-3 = 16419895097773519028
   graine de la course v6-1 = 14093731591405607550
empreintes : `0c333b524f6632d0292df2a0e0378b0018bc6fb0298aed16f9e37972451844dc`
la graine dérive de l entropie E du texte (sans égalité)
