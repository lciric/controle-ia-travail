# texte d essai
résumé de contre-lecture : entropie E = 12345 lue dans un essai
entropie E = 172478258882036320453769295467659450442 tirée au scellement
   graine de la course v5-3 = 9225168837353074206
   graine de la course v6-1 = 10166034498177593287
empreintes : `0c333b524f6632d0292df2a0e0378b0018bc6fb0298aed16f9e37972451844dc`
