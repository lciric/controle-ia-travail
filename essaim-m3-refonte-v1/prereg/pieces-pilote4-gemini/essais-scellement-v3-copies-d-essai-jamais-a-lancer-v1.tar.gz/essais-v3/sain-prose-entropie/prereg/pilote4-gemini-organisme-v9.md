# texte d essai
entropie E = 164498220979700979443246389683379883931 tirée au scellement
   graine de la course v5-3 = 15165271408389233062
   graine de la course v6-1 = 5024383972053450403
empreintes : `0c333b524f6632d0292df2a0e0378b0018bc6fb0298aed16f9e37972451844dc`
la graine dérive de l entropie E du texte (sans égalité)
