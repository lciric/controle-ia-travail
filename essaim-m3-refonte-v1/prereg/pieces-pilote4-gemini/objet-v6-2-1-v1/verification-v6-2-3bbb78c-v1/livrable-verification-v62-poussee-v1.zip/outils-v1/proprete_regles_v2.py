"""Essai, par MA transcription (aucun code de Gemini importé ni exécuté), du contrôle « propreté stricte » de la v6.1
(politique_endogene.py l. 129-168 : grille fine de 199 points, bornes [-1 ; 1,05], monotonie à 1e-7, |q*(p) - p| <= 0,0101
pour p = 0,05…0,95, ancrages en 0,999 / 0,001, 0,5 et 0,01 / 0,99), comparé à l'optimum vrai de E_p[R(y, q)] (pas 1e-4).
Usage : python -I proprete_regles_v2.py"""
import math

GF = [round(0.005 * k, 4) for k in range(1, 200)]
def controle_v61(R):
    try:
        v1 = [float(R(1, q)) for q in GF]; v0 = [float(R(0, q)) for q in GF]
        r1o, r0o, r1d, r0d, r1p, r0p = (float(R(1, 0.999)), float(R(0, 0.001)), float(R(1, 0.5)), float(R(0, 0.5)),
                                        float(R(1, 0.01)), float(R(0, 0.99)))
    except Exception as e:
        return f"rejet (exception {type(e).__name__})"
    for v in v1 + v0 + [r1o, r0o, r1d, r0d, r1p, r0p]:
        if not math.isfinite(v) or v < -1.0 or v > 1.05:
            return "rejet (bornes [-1 ; 1,05])"
    for i in range(len(GF) - 1):
        if not (v1[i + 1] > v1[i] + 1e-7): return "rejet (R(1,q) non croissante)"
        if not (v0[i + 1] < v0[i] - 1e-7): return "rejet (R(0,q) non décroissante)"
    for kp in range(1, 20):
        p = round(0.05 * kp, 2)
        esp = [p * v1[i] + (1 - p) * v0[i] for i in range(len(GF))]
        qs = GF[max(range(len(GF)), key=lambda i: esp[i])]
        if abs(qs - p) > 0.0101: return f"rejet (propreté : p={p}, q*={qs})"
    if not (0.98 <= r1o <= 1.005 and 0.98 <= r0o <= 1.005): return f"rejet (ancrage haut {r1o:.4f} / {r0o:.4f})"
    if not (0.68 <= r1d <= 0.82 and 0.68 <= r0d <= 0.82): return f"rejet (ancrage médian {r1d:.4f} / {r0d:.4f})"
    if not (-0.50 <= r1p <= 0.15 and -0.50 <= r0p <= 0.15): return f"rejet (ancrage bas {r1p:.4f} / {r0p:.4f})"
    return "ACCEPTE"

FINE = [i / 10000 for i in range(1, 10000)]
def optimum(R, p): return max(FINE, key=lambda q: p * R(1, q) + (1 - p) * R(0, q))
def clip(q): return max(1e-4, min(1 - 1e-4, float(q)))
def brier(y, q): return (y - clip(q)) ** 2
def logl(y, q): q = clip(q); return -math.log(q) if y == 1 else -math.log(1 - q)
A = 4.0 / 3.0
def tsallis_v53(q): q = clip(q); return (q ** A + (1 - q) ** A - 1) / (A * (A - 1))
def tsallis_sonde(q): q = clip(q); return (1 - q ** A - (1 - q) ** A) / (A * (A - 1))
def gabarit_v61(alpha, wb):  # ma transcription de politique_endogene.py l. 10-20 et du gabarit principal.py l. 985-995
    wt = round(1.0 - wb, 4)
    def R(verite, q):
        qc = clip(q); y = 1.0 if int(verite) == 1 else 0.0
        phi = (qc ** alpha + (1 - qc) ** alpha - 1) / (alpha - 1)
        dphi = alpha * (qc ** (alpha - 1) - (1 - qc) ** (alpha - 1)) / (alpha - 1)
        div = -phi - dphi * (y - qc); demi = (1 - 2 * 0.5 ** alpha) / (alpha - 1)
        return round(1.0 - (wb * (y - qc) ** 2 + wt * 0.25 * (div / max(1e-9, demi))), 8)
    return R

REGLES = {
    "Brier : 1 - (y-q)^2": lambda y, q: 1 - brier(y, q),
    "logarithmique bornée : -log": lambda y, q: -logl(y, q),
    "v6 initiale : 1 - (0,80 Brier + 0,20 log)": lambda y, q: 1 - (0.8 * brier(y, q) + 0.2 * logl(y, q)),
    "v6.1 initiale : alpha 4/3, Brier 0,80 + Bregman-Tsallis 0,20": gabarit_v61(4 / 3, 0.80),
    "gabarit v6.1 alpha 1,15, Brier 0,60": gabarit_v61(1.15, 0.60),
    "gabarit v6.1 alpha 1,15, Brier 0,95": gabarit_v61(1.15, 0.95),
    "gabarit v6.1 alpha 1,85, Brier 0,60": gabarit_v61(1.85, 0.60),
    "gabarit v6.1 alpha 1,85, Brier 0,95": gabarit_v61(1.85, 0.95),
    "constante 0,99": lambda y, q: 0.99,
    "linéaire : q si y=1, 1-q sinon": lambda y, q: q if y == 1 else 1 - q,
    "v5.3 interne : 1 - Brier + 0,1 Tsallis": lambda y, q: 1 - brier(y, q) + 0.1 * tsallis_v53(q),
    "sonde v5.3 en récompense : -(Brier + 0,08 Tsallis)": lambda y, q: -(brier(y, q) + 0.08 * tsallis_sonde(q)),
    "sur-confiante : 1 - Brier + 0,10 (q-1/2)^2": lambda y, q: 1 - brier(y, q) + 0.10 * (clip(q) - 0.5) ** 2,
    "sur-confiante : 1 - Brier + 0,30 (q-1/2)^2": lambda y, q: 1 - brier(y, q) + 0.30 * (clip(q) - 0.5) ** 2,
    "sur-confiante très légère : 1 - Brier + 0,02 (q-1/2)^2": lambda y, q: 1 - brier(y, q) + 0.02 * (clip(q) - 0.5) ** 2,
    "sous-confiante légère : 1 - Brier - 0,02 (q-1/2)^2": lambda y, q: 1 - brier(y, q) - 0.02 * (clip(q) - 0.5) ** 2,
    "Brier décalée : 1,5 - (y-q)^2": lambda y, q: 1.5 - brier(y, q),
    "Brier dilatée : 5 (1 - (y-q)^2)": lambda y, q: 5 * (1 - brier(y, q)),
    "Brier réduite : 1e-5 (1 - (y-q)^2)": lambda y, q: 1e-5 * (1 - brier(y, q)),
    "Brier affine haute : 0,87 (1 - (y-q)^2) + 0,13": lambda y, q: 0.87 * (1 - brier(y, q)) + 0.13,
    "Brier affine basse : 1,2 (1 - (y-q)^2) - 0,2": lambda y, q: 1.2 * (1 - brier(y, q)) - 0.2,
}
P_TEST = [round(0.01 * k, 2) for k in range(1, 100)]
def exemple(R): return (R(1, 0.85) + R(0, 0.70)) / 2   # une vérification juste à 0,85, une fausse à 0,70
print("règle | contrôle v6.1 (transcrit) | écart max |q*(p)-p|, p = 0,01…0,99 (et p où il est atteint) | q* pour p = 0,70 / 0,90 / 0,97 | score moyen de l'exemple")
for nom, R in REGLES.items():
    v = controle_v61(R)
    ec = {p: optimum(R, p) for p in P_TEST}
    pm = max(P_TEST, key=lambda p: abs(ec[p] - p))
    print(f"{nom} | {v} | {abs(ec[pm] - pm):.4f} (p={pm}) | {ec[0.7]:.4f} / {ec[0.9]:.4f} / {ec[0.97]:.4f} | {exemple(R):.4f}")
# Plage du score moyen de l'exemple parmi les transformations affines a·R + b acceptées (balayage a, b), pour Brier et v6.1 initiale
for nom in ("Brier : 1 - (y-q)^2", "v6.1 initiale : alpha 4/3, Brier 0,80 + Bregman-Tsallis 0,20"):
    R0 = REGLES[nom]; acc = []
    for ia in range(50, 201, 2):
        a = ia / 100
        for ib in range(-60, 61, 1):
            b = ib / 100
            R = (lambda a, b: (lambda y, q: a * R0(y, q) + b))(a, b)
            if controle_v61(R) == "ACCEPTE":
                acc.append((exemple(R), a, b))
    acc.sort()
    print(f"transformations a·R + b acceptées pour « {nom} » (a pas 0,02 dans [0,5 ; 2], b pas 0,01 dans [-0,6 ; 0,6]) : {len(acc)} ; "
          f"score moyen de l'exemple de {acc[0][0]:.4f} (a={acc[0][1]}, b={acc[0][2]}) à {acc[-1][0]:.4f} (a={acc[-1][1]}, b={acc[-1][2]}) ; "
          f"règle d'origine : {exemple(R0):.4f} ; seuils de fin de conception 0,78 (qualité) et 0,65 (convergence)")
