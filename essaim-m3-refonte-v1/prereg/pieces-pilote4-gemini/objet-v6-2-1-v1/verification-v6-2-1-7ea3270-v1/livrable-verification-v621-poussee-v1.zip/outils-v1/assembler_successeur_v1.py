"""Construit, SANS exécuter de code de Gemini, le politique_endogene.py qu'écrirait _propager_successeur de la v6.2 si une
mutation par gabarit était acceptée : gabarit de principal.py (_synthetiser_mutation_politique_endogene, chaîne formatée
l. 1020-1069) rempli par MES valeurs (les expressions de la chaîne sont reconnues par leur texte, jamais évaluées), puis
assemblage transcrit de principal.py l. 1531-1537 (coupe à la première occurrence de "\\nimport ast\\nimport math\\n").
Vérifie ensuite, par l'arbre syntaxique seul, le contrôle de l. 1539-1550 (imports ast et math, cinq fonctions).
Usage : python -I assembler_successeur_v1.py PRINCIPAL POLITIQUE SORTIE"""
import ast, sys

principal, politique, sortie = sys.argv[1:4]
nom_pol, alpha_val, poids_b, seuil_c1 = "bregman_mutee_gen2", 1.45, 0.82, 0.75   # valeurs de l'essai V6-01 (l. 120)
poids_t = round(1.0 - poids_b, 4)
valeurs = {"nom_pol": nom_pol, "round(alpha_val, 6)": round(alpha_val, 6), "round(poids_b, 4)": round(poids_b, 4),
           "poids_t": poids_t, "round(seuil_c1, 4)": round(seuil_c1, 4)}
arbre = ast.parse(open(principal, encoding="utf-8").read())
fn = next(n for n in ast.walk(arbre) if isinstance(n, ast.FunctionDef) and n.name == "_synthetiser_mutation_politique_endogene")
gabarit = next(n.value for n in ast.walk(fn) if isinstance(n, ast.Assign) and isinstance(n.value, ast.JoinedStr)
               and any(isinstance(t, ast.Name) and t.id == "code_candidat" for t in n.targets))
morceaux = []
for part in gabarit.values:
    if isinstance(part, ast.Constant):
        morceaux.append(part.value)
    else:
        src = ast.unparse(part.value)
        if src not in valeurs or part.format_spec is not None or part.conversion != -1:
            raise SystemExit(f"expression inattendue dans le gabarit : {src}")
        morceaux.append(str(valeurs[src]))
code_politique_mute = "".join(morceaux)
src_actuel = open(politique, encoding="utf-8").read()
cible_split = "\nimport ast\nimport math\n"
if cible_split in src_actuel:
    bloc_verif = "# " + ("=" * 117) + cible_split + src_actuel.split(cible_split, 1)[1]
    code_complet = code_politique_mute.rstrip() + "\n\n\n" + bloc_verif
else:
    code_complet = code_politique_mute
a = ast.parse(code_complet)
imports_racine = {al.name for n in a.body if isinstance(n, ast.Import) for al in n.names}
fns = {n.name for n in a.body if isinstance(n, ast.FunctionDef)}
requis = {"recompense_interne", "code_objectif_sonde", "ponderer_trace_memoire", "seuils_routage", "verifier_et_valider_code_politique"}
print(f"coupe trouvée : {cible_split in src_actuel} ; imports racine : {sorted(imports_racine)} ; fonctions requises présentes : {requis <= fns}")
print(f"contrôle de _propager_successeur (transcrit) : {'passe' if {'ast', 'math'} <= imports_racine and requis <= fns else 'ÉCHOUE'}")
open(sortie, "w", encoding="utf-8").write(code_complet)
print(f"écrit : {sortie} ({len(code_complet)} caractères)")
