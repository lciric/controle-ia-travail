#!/bin/bash
# Lance une commande de l'organisme en isolation, sur une copie à part passée à nobody (méthode de la vérification v6.2).
# Usage : lancer_isole_v1.sh NOM ARBRE_ORGANISME JOURNAL [GRAINE|-] ARGUMENTS_PYTHON…
#   NOM : dossier de la copie sous /var/tmp/verification-v621-poussee-v1/essais-v1/ (doit être neuf)
#   ARBRE_ORGANISME : dossier « organisme » à copier (cp -a), placé en <copie>/organisme
#   GRAINE : valeur de PYTHONHASHSEED, ou « - » pour ne pas la fixer
# La commande tourne dans <copie> (répertoire courant), sous unshare -n sudo -u nobody env -i …, python -P -s -B, jamais -I.
set -u
BASE=/var/tmp/verification-v621-poussee-v1/essais-v1
NOM=$1; ARBRE=$2; JOURNAL=$3; GRAINE=$4; shift 4
C=$BASE/$NOM
if [ -e "$C" ]; then echo "copie déjà présente : $C" >&2; exit 2; fi
mkdir -p "$C/tmp"
cp -a "$ARBRE" "$C/organisme"
chown -R nobody "$C"
ENVS=(PATH=/usr/bin:/bin HOME=$C LANG=C.UTF-8 TMPDIR=$C/tmp PYTHONDONTWRITEBYTECODE=1)
if [ "$GRAINE" != "-" ]; then ENVS+=(PYTHONHASHSEED=$GRAINE); fi
CMD=(unshare -n sudo -u nobody env -i "${ENVS[@]}" /opt/venv-essaim-sim-v1/bin/python -P -s -B "$@")
{
  echo "# commande : ${CMD[*]}  (dossier : $C) ; début $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
} >> "$JOURNAL"
T0=$(date +%s.%N)
( cd "$C" && "${CMD[@]}" ) >> "$JOURNAL" 2>&1
CODE=$?
T1=$(date +%s.%N)
{
  echo "CODE_SORTIE=$CODE"
  echo "# temps mur : $(echo "$T1 - $T0" | bc) s ; fin $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
} >> "$JOURNAL"
exit $CODE
