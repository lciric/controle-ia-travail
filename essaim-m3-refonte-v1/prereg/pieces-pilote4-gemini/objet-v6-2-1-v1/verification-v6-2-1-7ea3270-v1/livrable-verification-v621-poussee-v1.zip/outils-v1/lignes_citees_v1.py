"""Lecture seule : pour des plages de lignes d'un fichier A, donne leurs numéros dans le fichier B (correspondance ligne à
ligne par difflib, blocs égaux seulement) et dit si leur texte change.
Usage : python -I lignes_citees_v1.py A B DEBUT-FIN [DEBUT-FIN…]"""
import difflib, sys

a = open(sys.argv[1], encoding="utf-8").read().splitlines()
b = open(sys.argv[2], encoding="utf-8").read().splitlines()
corr = {}
for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
    if tag == "equal":
        for k in range(i2 - i1):
            corr[i1 + k + 1] = j1 + k + 1
for plage in sys.argv[3:]:
    d, f = (int(x) for x in plage.split("-")) if "-" in plage else (int(plage), int(plage))
    cibles = [corr.get(n) for n in range(d, f + 1)]
    if None in cibles:
        manq = [n for n, c in zip(range(d, f + 1), cibles) if c is None]
        print(f"A l. {plage} -> lignes changées ou retirées dans B : {manq}")
        continue
    contigu = all(cibles[k + 1] == cibles[k] + 1 for k in range(len(cibles) - 1))
    meme = all(a[n - 1] == b[c - 1] for n, c in zip(range(d, f + 1), cibles))
    print(f"A l. {plage} -> B l. {cibles[0]}-{cibles[-1]} ; contiguës : {contigu} ; texte identique : {meme} ; "
          f"première ligne : {a[d - 1].strip()[:90]!r}")
