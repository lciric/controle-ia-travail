"""Lecture seule : compte, fichier par fichier (code de l'organisme hors essais), les motifs interdits par le contrat du
noyau et les lignes d'entrée-sortie, pour deux arbres. Usage : python -I motifs_contrat_v1.py ARBRE_A ARBRE_B"""
import re, sys
from pathlib import Path

MOTIFS = [r"subprocess", r"socket", r"urllib", r"requests", r"http\.client", r"os\.environ", r"getenv", r"importlib",
          r"ctypes", r"multiprocessing", r"__import__", r"\bexec\(", r"\bcompile\(", r"\beval\(", r"\bopen\(", r"threading",
          r"\bos\.system", r"\bpopen", r"https?://"]
IO = re.compile(r"read_text|write_text|read_bytes|write_bytes|\bopen\(|shutil\.(copy|rmtree|move)|\.unlink\(|\.replace\(dossier|mkdir")
a, b = Path(sys.argv[1]), Path(sys.argv[2])
fichiers = sorted({p.relative_to(a).as_posix() for p in a.rglob("*.py")} | {p.relative_to(b).as_posix() for p in b.rglob("*.py")})
fichiers = [f for f in fichiers if not f.startswith("tests/")]
for f in fichiers:
    ta = (a / f).read_text(encoding="utf-8") if (a / f).exists() else ""
    tb = (b / f).read_text(encoding="utf-8") if (b / f).exists() else ""
    for m in MOTIFS:
        na, nb = len(re.findall(m, ta)), len(re.findall(m, tb))
        if na or nb:
            print(f"motif {m} | {f} | A {na} | B {nb}{'' if na == nb else '  <-- DIFFÈRE'}")
for f in fichiers:
    for nom, racine in (("B", b),):
        if not (racine / f).exists():
            continue
        for i, l in enumerate((racine / f).read_text(encoding="utf-8").splitlines(), 1):
            if IO.search(l):
                print(f"E/S {nom} {f}:{i}: {l.strip()[:150]}")
