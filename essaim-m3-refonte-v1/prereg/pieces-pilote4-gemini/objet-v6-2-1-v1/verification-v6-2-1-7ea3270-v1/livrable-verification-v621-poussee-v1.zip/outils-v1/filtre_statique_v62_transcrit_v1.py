"""MA transcription de la seule partie STATIQUE du filtre de la v6.2 (politique_endogene.py l. 152-207 : longueur,
ast.parse, 800 nœuds, liste blanche, constantes <= 10 000 et chaînes <= 450, exposant CONSTANT <= 4, imports, noms,
attributs, appels). Aucun candidat n'est compilé ni exécuté : on dit seulement si le filtre statique le laisse passer.
Usage : python -I filtre_statique_v62_transcrit_v1.py"""
import ast, math

BLANCS = (ast.Module, ast.Import, ast.alias, ast.FunctionDef, ast.arguments, ast.arg, ast.Assign, ast.AugAssign, ast.Return,
          ast.If, ast.Expr, ast.BoolOp, ast.BinOp, ast.UnaryOp, ast.IfExp, ast.Dict, ast.Set, ast.Compare, ast.Call,
          ast.Constant, ast.Attribute, ast.Subscript, ast.Name, ast.Load, ast.Store, ast.Tuple, ast.List, ast.And, ast.Or,
          ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod, ast.Pow, ast.USub, ast.UAdd, ast.Not, ast.Eq,
          ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE, ast.In, ast.NotIn, ast.Is, ast.IsNot)
INTERDITS = {"eval", "exec", "compile", "open", "__import__", "getattr", "setattr", "delattr", "globals", "locals", "vars",
             "input", "breakpoint", "exit", "quit", "os", "sys", "subprocess", "socket", "shutil", "pathlib", "threading",
             "multiprocessing", "ctypes"}
BUILTINS = {"abs", "min", "max", "round", "float", "int", "str", "bool", "dict", "list", "tuple", "set", "len", "sum"}
MATH = {"log", "exp", "sqrt", "sin", "cos", "tan", "atan", "asin", "acos", "tanh", "cosh", "sinh", "fabs", "floor", "ceil",
        "isfinite", "isnan", "isinf", "copysign", "pi", "e"}


def filtre(src):
    if len(src.strip()) < 50 or len(src) > 12_000: return "rejet (longueur)"
    try: arbre = ast.parse(src)
    except Exception as e: return f"rejet ({type(e).__name__})"
    defs = {n.name for n in arbre.body if isinstance(n, ast.FunctionDef)}
    k = 0
    for n in ast.walk(arbre):
        k += 1
        if k > 800: return "rejet (> 800 nœuds)"
        if not isinstance(n, BLANCS): return f"rejet (nœud {type(n).__name__})"
        if isinstance(n, ast.Constant):
            if isinstance(n.value, (int, float)) and not isinstance(n.value, bool):
                if not math.isfinite(float(n.value)) or abs(float(n.value)) > 10_000.0: return "rejet (constante)"
            elif isinstance(n.value, str) and len(n.value) > 450: return "rejet (chaîne)"
        if isinstance(n, ast.BinOp) and isinstance(n.op, ast.Pow):
            if isinstance(n.right, ast.Constant) and isinstance(n.right.value, (int, float)) and abs(float(n.right.value)) > 4.0:
                return "rejet (exposant constant > 4)"
        if isinstance(n, ast.Import):
            for al in n.names:
                if al.name != "math" or al.asname is not None: return "rejet (import)"
        if isinstance(n, ast.Name) and (n.id in INTERDITS or n.id.startswith("__")): return "rejet (nom)"
        if isinstance(n, ast.Attribute):
            if isinstance(n.ctx, ast.Store) or n.attr.startswith("__"): return "rejet (attribut)"
            if isinstance(n.value, ast.Name) and n.value.id == "math":
                if n.attr not in MATH: return "rejet (attribut math)"
            elif n.attr not in ("lower", "strip"): return "rejet (attribut)"
        if isinstance(n, ast.Call):
            if isinstance(n.func, ast.Name):
                if n.func.id in defs or n.func.id not in BUILTINS: return "rejet (appel)"
            elif isinstance(n.func, ast.Attribute):
                if isinstance(n.func.value, ast.Name) and n.func.value.id == "math":
                    if n.func.attr not in MATH: return "rejet (appel math)"
                elif n.func.attr not in ("lower", "strip"): return "rejet (méthode)"
            else: return "rejet (appel dynamique)"
    return f"PASSE le filtre statique ({k} nœuds)"


RESTE = ("def code_objectif_sonde(): return 'def perte(p, y): return 0.0'\n"
         "def ponderer_trace_memoire(t, p): return 0.5\n"
         "def seuils_routage(): return {'seuil_confiance_caste1': 0.78}\n")
CANDIDATS = {
    "essai de Gemini (l. 333) : x = 9999 ** 99": "    x = 9999 ** 99\n",
    "exposant non constant : n = 9999 ; x = n ** n ** n": "    n = 9999\n    x = n ** n ** n\n",
    "exposant constant composé : x = 9999 ** (4 ** 4 ** 4)": "    x = 9999 ** (4 ** 4 ** 4)\n",
    "puissances constantes imbriquées (14 fois ** 4)": "    x = " + "(" * 14 + "9999" + " ** 4)" * 14 + "\n",
    "répétition de séquence : s = 'a' * 10000 * 10000 * 10000": "    s = 'a' * 10000 * 10000 * 10000\n",
}
for nom, corps in CANDIDATS.items():
    src = "import math\ndef recompense_interne(verite, q):\n" + corps + "    return 1.0 - (verite - q) ** 2\n" + RESTE
    print(f"{nom} : {filtre(src)}")
print("(au niveau module, la même expression serait évaluée dès l'exec de la validation, l. 227, dans le fil principal)")
