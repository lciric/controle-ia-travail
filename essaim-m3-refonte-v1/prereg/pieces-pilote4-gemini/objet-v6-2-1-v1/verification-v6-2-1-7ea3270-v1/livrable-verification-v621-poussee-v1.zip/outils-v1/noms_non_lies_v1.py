"""Analyse statique (aucune exécution) : parcourt, dans l'ordre, les instructions de niveau module d'un fichier Python
et signale le premier usage, au niveau module, d'un nom ni lié avant ni intégré (builtins). Les corps de fonctions ne
sont pas évalués à l'import ; seuls comptent les décorateurs, valeurs par défaut et expressions de niveau module.
Usage : python -I noms_non_lies_v1.py FICHIER"""
import ast, builtins, sys

src = open(sys.argv[1], encoding="utf-8").read()
arbre = ast.parse(src)
lies = set(dir(builtins)) | {"__name__", "__file__", "__doc__"}
trouve = []

def noms_lus(expr_nodes):
    for e in expr_nodes:
        if e is None:
            continue
        for n in ast.walk(e):
            if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load):
                yield n

for st in arbre.body:
    a_lire = []
    if isinstance(st, (ast.FunctionDef, ast.AsyncFunctionDef)):
        a_lire = list(st.decorator_list) + list(st.args.defaults) + [d for d in st.args.kw_defaults if d]
    elif isinstance(st, ast.ClassDef):
        a_lire = list(st.decorator_list) + list(st.bases)
    elif isinstance(st, (ast.Import, ast.ImportFrom)):
        a_lire = []
    else:
        a_lire = [st]
    for n in noms_lus(a_lire):
        if n.id not in lies:
            trouve.append((n.lineno, n.id))
    if isinstance(st, ast.Import):
        for al in st.names:
            lies.add((al.asname or al.name).split(".")[0])
    elif isinstance(st, ast.ImportFrom):
        for al in st.names:
            lies.add(al.asname or al.name)
    elif isinstance(st, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
        lies.add(st.name)
    else:
        for n in ast.walk(st):
            if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store):
                lies.add(n.id)
imports = [(st.lineno, al.name) for st in arbre.body if isinstance(st, ast.Import) for al in st.names]
print(f"imports de niveau module : {imports}")
if trouve:
    for l, nom in trouve:
        print(f"NOM NON LIE au niveau module : '{nom}' ligne {l} -> NameError à l'import")
else:
    print("aucun nom non lié au niveau module")
