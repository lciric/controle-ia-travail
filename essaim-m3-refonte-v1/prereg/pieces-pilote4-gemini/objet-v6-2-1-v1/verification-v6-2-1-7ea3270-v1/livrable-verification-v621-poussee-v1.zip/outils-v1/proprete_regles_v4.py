"""Essai, par MA transcription (aucun code de Gemini importé ni exécuté), du contrôle « propreté stricte » de la v6.2 telle que poussée en 3bbb78c
(politique_endogene.py l. 95-148 : grille fine de 199 points, bornes [-10 ; 10] (3bbb78c, l. 110-111), monotonie à 1e-7, condition du premier
ordre de Savage par différences finies (h = 1e-5, p = 0,01…0,99 : |g'| <= 1,5e-4 et g'' <= -0,05), |q*(p) - p| <= 0,0051
pour p = 0,05…0,95 sur la grille, ancrages R(1 ; 0,9999) = R(0 ; 0,0001) = 1 ± 5e-4, R(y ; 0,5) = 0,75 ± 5e-4,
R(1 ; 0,01) et R(0 ; 0,99) dans [-0,50 ; 0,15]).
Règles transcrites : la règle initiale de la v6.2 (l. 13-23 ; en 3bbb78c, sans arrondi) et le gabarit de mutation
(principal.py l. 1029-1039, même formule, arrondie à 8 décimales), avec et sans l'arrondi, plus les cas de la v6.1.
Usage : python -I proprete_regles_v4.py (copie de la v3, bornes portées à [-10 ; 10] comme en 3bbb78c, plus une règle à bonus caché entre les points contrôlés)"""
import math

GF = [round(0.005 * k, 4) for k in range(1, 200)]


def controle_v62(R):
    try:
        v1 = [float(R(1, q)) for q in GF]; v0 = [float(R(0, q)) for q in GF]
        r1o, r0o, r1d, r0d, r1p, r0p = (float(R(1, 0.9999)), float(R(0, 0.0001)), float(R(1, 0.5)), float(R(0, 0.5)),
                                        float(R(1, 0.01)), float(R(0, 0.99)))
    except Exception as e:
        return f"rejet (exception {type(e).__name__})"
    for v in v1 + v0 + [r1o, r0o, r1d, r0d, r1p, r0p]:
        if not math.isfinite(v) or v < -10.0 or v > 10.0:
            return f"rejet (bornes [-10 ; 10] (3bbb78c, l. 110-111) : {v})"
    for i in range(len(GF) - 1):
        if not (v1[i + 1] > v1[i] + 1e-7): return "rejet (R(1,q) non strictement croissante)"
        if not (v0[i + 1] < v0[i] - 1e-7): return "rejet (R(0,q) non strictement décroissante)"
    h = 1e-5
    for kp in range(1, 100):
        p = round(0.01 * kp, 2)
        try:
            g = p * float(R(1, p)) + (1 - p) * float(R(0, p))
            gp = p * float(R(1, p + h)) + (1 - p) * float(R(0, p + h))
            gm = p * float(R(1, p - h)) + (1 - p) * float(R(0, p - h))
        except Exception as e:
            return f"rejet (exception locale {type(e).__name__})"
        d1 = (gp - gm) / (2 * h); d2 = (gp - 2 * g + gm) / (h * h)
        if abs(d1) > 1.5e-4 or d2 > -0.05:
            return f"rejet (Savage en p={p} : g'={round(d1, 6)}, g''={round(d2, 4)})"
    for kp in range(1, 20):
        p = round(0.05 * kp, 2)
        esp = [p * v1[i] + (1 - p) * v0[i] for i in range(len(GF))]
        qs = GF[max(range(len(GF)), key=lambda i: esp[i])]
        if abs(qs - p) > 0.0051: return f"rejet (optimum sur grille : p={p}, q*={qs})"
    if not (abs(r1o - 1) <= 5e-4 and abs(r0o - 1) <= 5e-4): return f"rejet (ancrage haut {r1o:.6f} / {r0o:.6f})"
    if not (abs(r1d - 0.75) <= 5e-4 and abs(r0d - 0.75) <= 5e-4): return f"rejet (ancrage médian {r1d:.6f} / {r0d:.6f})"
    if not (-0.50 <= r1p <= 0.15 and -0.50 <= r0p <= 0.15): return f"rejet (ancrage bas {r1p:.4f} / {r0p:.4f})"
    return "ACCEPTE"


def clip(q): return max(1e-4, min(1 - 1e-4, float(q)))
def brier(y, q): return (y - clip(q)) ** 2


def gabarit(alpha, wb, arrondi=True):  # transcription de politique_endogene.py l. 13-23 = principal.py l. 1029-1039
    wt = round(1.0 - wb, 4)
    def R(verite, q):
        qc = clip(q); y = 1.0 if int(verite) == 1 else 0.0
        phi = (qc ** alpha + (1 - qc) ** alpha - 1) / (alpha - 1)
        dphi = alpha * (qc ** (alpha - 1) - (1 - qc) ** (alpha - 1)) / (alpha - 1)
        div = -phi - dphi * (y - qc); demi = (1 - 2 * 0.5 ** alpha) / (alpha - 1)
        v = 1.0 - (wb * (y - qc) ** 2 + wt * 0.25 * (div / max(1e-9, demi)))
        return round(v, 8) if arrondi else v
    return R


INIT = gabarit(4 / 3, 0.80)
INIT_BRUT = gabarit(4 / 3, 0.80, arrondi=False)
REGLES = {
    "v6.2 initiale (alpha 4/3, Brier 0,80), arrondie à 8 décimales comme dans le code": INIT,
    "v6.2 initiale, SANS l'arrondi à 8 décimales": INIT_BRUT,
    "gabarit alpha 1,50, Brier 0,78 (essai test_v6_auto_reecriture…), arrondi": gabarit(1.50, 0.78),
    "gabarit alpha 1,45, Brier 0,82 (essai test_v6_1_successeur_mute…), arrondi": gabarit(1.45, 0.82),
    "gabarit alpha 1,45, Brier 0,82, SANS arrondi": gabarit(1.45, 0.82, arrondi=False),
    "Brier 1 - (y-q)^2, arrondie à 8 décimales": lambda y, q: round(1 - brier(y, q), 8),
    "Brier 1 - (y-q)^2, sans arrondi (ancrage médian 0,75 et haut 1 tenus)": lambda y, q: 1 - brier(y, q),
    "Brier arrondie à 4 décimales": lambda y, q: round(1 - brier(y, q), 4),
    "sur-confiante très légère 1 - Brier + 0,02 (q-1/2)^2 (sans arrondi)": lambda y, q: 1 - brier(y, q) + 0.02 * (clip(q) - 0.5) ** 2,
    "sur-confiante 1 - Brier + 0,10 (q-1/2)^2 (sans arrondi)": lambda y, q: 1 - brier(y, q) + 0.10 * (clip(q) - 0.5) ** 2,
    "affine 0,87 R + 0,13 sur l'initiale arrondie": lambda y, q: 0.87 * INIT(y, q) + 0.13,
    "affine 0,82 R + 0,18 sur l'initiale arrondie": lambda y, q: 0.82 * INIT(y, q) + 0.18,
    "affine 0,82 R + 0,18 sur l'initiale SANS arrondi": lambda y, q: 0.82 * INIT_BRUT(y, q) + 0.18,
    "affine 1,2 R - 0,2 sur l'initiale SANS arrondi": lambda y, q: 1.2 * INIT_BRUT(y, q) - 0.2,
}
def exemple(R): return (R(1, 0.85) + R(0, 0.70)) / 2   # une vérification juste à 0,85, une fausse à 0,70 (v6.1 § 9.3)

print("règle | contrôle v6.2 (transcrit) | score de l'exemple")
for nom, R in REGLES.items():
    print(f"{nom} | {controle_v62(R)} | {exemple(R):.4f}")

# Gabarit sur toute sa plage (alpha 1,15…1,85 pas 0,05 ; Brier 0,60…0,95 pas 0,05), avec l'arrondi du code puis sans
for arr in (True, False):
    acc, tot, raisons = 0, 0, {}
    ex = []
    for ia in range(0, 15):
        a = round(1.15 + 0.05 * ia, 2)
        for ib in range(0, 8):
            b = round(0.60 + 0.05 * ib, 2)
            v = controle_v62(gabarit(a, b, arrondi=arr)); tot += 1
            if v == "ACCEPTE":
                acc += 1; ex.append(exemple(gabarit(a, b, arrondi=arr)))
            else:
                cle = v.split(" en p=")[0] if "Savage" in v else v
                raisons[cle] = raisons.get(cle, 0) + 1
    plage = f" ; score de l'exemple des acceptées de {min(ex):.4f} à {max(ex):.4f}" if ex else ""
    print(f"gabarit {'AVEC' if arr else 'SANS'} l'arrondi à 8 décimales : {acc} acceptés sur {tot}{plage} ; rejets : {raisons}")

# Transformations affines a·R + b de l'initiale sans arrondi (a pas 0,02 dans [0,5 ; 2], b pas 0,01 dans [-0,6 ; 0,6])
acc = []
for ia in range(50, 201, 2):
    a = ia / 100
    for ib in range(-60, 61):
        b = ib / 100
        R = (lambda a, b: (lambda y, q: a * INIT_BRUT(y, q) + b))(a, b)
        if controle_v62(R) == "ACCEPTE": acc.append((round(exemple(R), 4), a, b))
print(f"transformations affines acceptées de l'initiale sans arrondi : {len(acc)} : {sorted(acc)[:5]}")

# Règle à bonus caché : Brier sans arrondi, plus 0,01 pour y = 1 quand q est dans ]0,0151 ; 0,0199[, intervalle qui ne
# contient aucun point lu par le contrôle (grille de 0,005, p ± 1e-5 pour p = 0,01 et 0,02, ancrages). Elle s'écrit avec les
# seuls nœuds de la liste blanche (If, Compare, BoolOp). Optimum vrai pour p = 0,012 calculé au pas de 1e-5.
def cachee(y, q):
    v = 1 - brier(y, q)
    if int(y) == 1 and q > 0.0151 and q < 0.0199:
        v = v + 0.01
    return v
fin = [i / 100000 for i in range(1, 5000)]
qs = max(fin, key=lambda q: 0.012 * cachee(1, q) + 0.988 * cachee(0, q))
print(f"bonus caché entre les points contrôlés : {controle_v62(cachee)} ; optimum vrai pour p = 0,012 : q* = {qs:.5f}")
