"""Sonde d'isolation (mon code ; aucune pièce de l'organisme) : graine de hachage, réseau, utilisateur, interpréteur.
Usage (en isolation) : python -P -s -B sonde_isolation_v1.py"""
import os, socket, sys
print(f"PYTHONHASHSEED={os.environ.get('PYTHONHASHSEED')} : hash('a')={hash('a')} randomisation={sys.flags.hash_randomization}")
try:
    s = socket.create_connection(("1.1.1.1", 443), timeout=3)
    print("réseau : CONNEXION ÉTABLIE (isolation rompue)")
    s.close()
except OSError as e:
    print(f"réseau dans l'espace de noms : refusé : OSError {e.errno}")
print(f"utilisateur : uid={os.getuid()} euid={os.geteuid()}")
try:
    import pytest
    v = pytest.__version__
except Exception as e:
    v = f"absent ({type(e).__name__})"
print(f"interpréteur : {sys.version.split()[0]} ; pytest {v} ; sys.path[0]={sys.path[0]!r}")
