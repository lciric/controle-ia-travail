"""Différences feuille à feuille entre deux fichiers JSON (lecture seule). Usage : python -I diff_json_v1.py A B [MAX]"""
import json, sys
def feuilles(x, p=""):
    if isinstance(x, dict):
        for k in sorted(x): yield from feuilles(x[k], f"{p}/{k}")
    elif isinstance(x, list):
        for i, v in enumerate(x): yield from feuilles(v, f"{p}[{i}]")
    else:
        yield p, x
a = dict(feuilles(json.load(open(sys.argv[1], encoding="utf-8")))); b = dict(feuilles(json.load(open(sys.argv[2], encoding="utf-8"))))
mx = int(sys.argv[3]) if len(sys.argv) > 3 else 40
d = [k for k in sorted(set(a) | set(b)) if a.get(k, "<absent>") != b.get(k, "<absent>")]
print(f"{len(d)} feuilles différentes sur {len(set(a) | set(b))}")
for k in d[:mx]:
    print(f"  {k} : {a.get(k, '<absent>')!r} -> {b.get(k, '<absent>')!r}")
