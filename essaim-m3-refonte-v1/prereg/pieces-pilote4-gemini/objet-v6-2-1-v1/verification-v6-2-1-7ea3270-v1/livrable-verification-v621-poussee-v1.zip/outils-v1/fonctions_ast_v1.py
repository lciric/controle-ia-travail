"""Compare fonction par fonction (niveau module et fonctions internes, docstrings retirées) deux fichiers Python, et
liste les constantes de niveau module ajoutées, retirées ou changées. Lecture seule, aucune exécution.
Usage : python -I fonctions_ast_v1.py FICHIER_A FICHIER_B"""
import ast, sys

def nettoyer(n):
    for m in ast.walk(n):
        if isinstance(m, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Module)) and m.body \
                and isinstance(m.body[0], ast.Expr) and isinstance(getattr(m.body[0], "value", None), ast.Constant) \
                and isinstance(m.body[0].value.value, str):
            m.body = m.body[1:] or [ast.Pass()]
    return n

def index(p):
    t = nettoyer(ast.parse(open(p, encoding="utf-8").read()))
    fonctions, consts = {}, {}
    def visite(noeud, prefixe=""):
        for enfant in ast.iter_child_nodes(noeud):
            if isinstance(enfant, (ast.FunctionDef, ast.AsyncFunctionDef)):
                nom = prefixe + enfant.name
                fonctions[nom] = (ast.dump(enfant), enfant.lineno)
                visite(enfant, nom + ".")
            else:
                visite(enfant, prefixe)
    visite(t)
    for st in t.body:
        if isinstance(st, ast.Assign):
            for cible in st.targets:
                if isinstance(cible, ast.Name):
                    consts[cible.id] = (ast.dump(st.value), st.lineno)
    return fonctions, consts

fa, ca = index(sys.argv[1]); fb, cb = index(sys.argv[2])
for titre, a, b in (("fonction", fa, fb), ("constante", ca, cb)):
    inch = [n for n in a if n in b and a[n][0] == b[n][0]]
    chg = [n for n in a if n in b and a[n][0] != b[n][0]]
    ajt = [n for n in b if n not in a]
    ret = [n for n in a if n not in b]
    print(f"{titre}s : {len(inch)} inchangées, {len(chg)} changées, {len(ajt)} ajoutées, {len(ret)} retirées")
    for n in chg: print(f"  CHANGEE  {n} (l. {a[n][1]} -> l. {b[n][1]})")
    for n in ajt: print(f"  AJOUTEE  {n} (l. {b[n][1]})")
    for n in ret: print(f"  RETIREE  {n} (l. {a[n][1]})")
    if titre == "fonction":
        print("  inchangées : " + ", ".join(sorted(inch)))
