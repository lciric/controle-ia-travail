"""Analyse statique (aucune exécution) : fonctions qui prennent _VERROU directement ou par une chaîne d'appels internes
au module, puis tout appel fait en tenant _VERROU vers l'une d'elles. Signale aussi _VERROU.acquire / release.
Usage : python -I verrous_transitifs_v1.py FICHIER"""
import ast, sys
arbre = ast.parse(open(sys.argv[1], encoding="utf-8").read())
fonctions = {f.name: f for f in ast.walk(arbre) if isinstance(f, (ast.FunctionDef, ast.AsyncFunctionDef))}
def blocs(f):
    return [n for n in ast.walk(f) if isinstance(n, (ast.With, ast.AsyncWith))
            and any(isinstance(i.context_expr, ast.Name) and i.context_expr.id == "_VERROU" for i in n.items)]
def appels(n):
    return {c.func.id for c in ast.walk(n) if isinstance(c, ast.Call) and isinstance(c.func, ast.Name) and c.func.id in fonctions}
directs = {nom for nom, f in fonctions.items() if blocs(f)}
graphe = {nom: appels(f) - {nom} for nom, f in fonctions.items()}
ferme = set(directs)
change = True
while change:
    change = False
    for nom, cibles in graphe.items():
        if nom not in ferme and cibles & ferme:
            ferme.add(nom); change = True
trouves = 0
for nom, f in fonctions.items():
    for b in blocs(f):
        for c in ast.walk(b):
            if isinstance(c, ast.Call) and isinstance(c.func, ast.Name) and c.func.id in ferme:
                trouves += 1
                print(f"BLOCAGE POSSIBLE : {nom} (with l. {b.lineno}) appelle {c.func.id} (l. {c.lineno}), qui prend _VERROU (directement ou non)")
acq = [(n.lineno, n.attr) for n in ast.walk(arbre) if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name)
       and n.value.id == "_VERROU" and n.attr in ("acquire", "release")]
print(f"prennent _VERROU directement : {sorted(directs)}")
print(f"prennent _VERROU par chaîne d'appels : {sorted(ferme - directs)}")
print(f"{trouves} appel(s) imbriqué(s), chaînes comprises ; acquire/release explicites : {acq or 'aucun'}")
