"""Transcription exacte de essaim_m3/noyau/boucle.py::empreinte_arbre (l. 70-78, noyau 218052dd…), lecture seule.
Usage : python -I empreinte_arbre_v1.py DOSSIER [DOSSIER…]"""
import hashlib, pathlib, sys

def empreinte_arbre(dossier):
    h = hashlib.sha256()
    for f in sorted(p for p in pathlib.Path(dossier).rglob("*")
                    if p.is_file() and p.suffix != ".pyc" and "__pycache__" not in p.relative_to(dossier).parts):
        h.update(str(f.relative_to(dossier)).encode("utf-8") + b"\0")
        h.update(hashlib.sha256(f.read_bytes()).hexdigest().encode("ascii") + b"\n")
    return h.hexdigest()

for d in sys.argv[1:]:
    n = sum(1 for p in pathlib.Path(d).rglob("*") if p.is_file() and p.suffix != ".pyc" and "__pycache__" not in p.relative_to(d).parts)
    print(f"{empreinte_arbre(d)}  {n} fichiers  {d}")
