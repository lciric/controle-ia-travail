"""Compare deux relevés d'invariance_v1.py (lecture de JSON seulement, aucune exécution d'organisme).
Usage : python -I comparer_releves_v1.py RELEVE_A RELEVE_B"""
import json, sys
a = json.load(open(sys.argv[1], encoding="utf-8")); b = json.load(open(sys.argv[2], encoding="utf-8"))
ja, jb = a["journal"], b["journal"]
print(f"versions : {a['version']} -> {b['version']} ; cas {a['cas']} / {b['cas']}")
print(f"appels : {len(ja['appeler'])} -> {len(jb['appeler'])} ; budget() {ja['budget']} -> {jb['budget']} ; especes() {ja['especes']} -> {jb['especes']} ; "
      f"rechercher {len(ja['rechercher'])} -> {len(jb['rechercher'])} ; telecharger {len(ja['telecharger'])} -> {len(jb['telecharger'])}")
print(f"suite des rôles identique : {[x['role'] for x in ja['appeler']] == [x['role'] for x in jb['appeler']]}")
print(f"suite (espèce, rôle, jetons) identique : {[(x['espece'], x['role'], x['max_tokens']) for x in ja['appeler']] == [(x['espece'], x['role'], x['max_tokens']) for x in jb['appeler']]}")
for i, (x, y) in enumerate(zip(ja["appeler"], jb["appeler"])):
    if x != y:
        champs = [k for k in x if x.get(k) != y.get(k)]
        print(f"  appel n° {i} ({x['role']} / {y['role']}) : diffère par {champs}")
print(f"requêtes de recherche identiques : {ja['rechercher'] == jb['rechercher']} ; téléchargements identiques : {ja['telecharger'] == jb['telecharger']}")
fa, fb = a["fichiers"], b["fichiers"]
for f in sorted(set(fa) | set(fb)):
    print(f"  {'IDENTIQUE' if fa.get(f) == fb.get(f) else 'DIFFERENT'} {f}")
print(f"clés du bilan : en plus {sorted(set(b['cles_bilan'] or []) - set(a['cles_bilan'] or []))}, en moins {sorted(set(a['cles_bilan'] or []) - set(b['cles_bilan'] or []))}")
