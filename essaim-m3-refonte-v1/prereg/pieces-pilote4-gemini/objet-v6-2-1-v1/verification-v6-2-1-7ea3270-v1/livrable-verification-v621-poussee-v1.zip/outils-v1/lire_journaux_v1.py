"""Lecture seule (aucune exécution d'organisme) : résume des journal_generation.json et le NOM_POLITIQUE (lu par l'arbre
syntaxique) du politique_endogene.py du successeur voisin.
Usage : python -I lire_journaux_v1.py JOURNAL [JOURNAL…]"""
import ast, json, sys
from collections import Counter
from pathlib import Path

for p in map(Path, sys.argv[1:]):
    j = json.loads(p.read_text(encoding="utf-8"))
    roles = Counter(a.get("role") for a in j.get("journal_appels", []))
    print(f"== {p}")
    print(f"   version={j.get('version')} generation={j.get('generation')} phase={j.get('phase')} castes={j.get('n_castes_recrutees')}"
          f" appels={j.get('compteurs_appels', {}).get('tentatives')} roles={dict(roles)}")
    print(f"   taches test {j.get('n_taches_test_repondues')}/{j.get('n_taches_test')} ; mutation={j.get('mutation_politique_endogene')}"
          f" ; erreurs={len(j.get('erreurs', []))} {j.get('erreurs', [])[:3]}")
    succ = p.parent / "successeur" / "organisme" / "politique_endogene.py"
    if succ.exists():
        arbre = ast.parse(succ.read_text(encoding="utf-8"))
        noms = [n.value.value for n in arbre.body if isinstance(n, ast.Assign) and isinstance(n.value, ast.Constant)
                and any(isinstance(t, ast.Name) and t.id == "NOM_POLITIQUE" for t in n.targets)]
        print(f"   successeur : NOM_POLITIQUE={noms}")
