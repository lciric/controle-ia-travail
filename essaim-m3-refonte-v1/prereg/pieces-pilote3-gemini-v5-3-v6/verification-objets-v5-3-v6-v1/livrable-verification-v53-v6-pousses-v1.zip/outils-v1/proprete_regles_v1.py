"""Essai, par MA transcription (aucun code de Gemini importé ni exécuté), du contrôle « propreté stricte » de
politique_endogene.py l. 66-93 (grille de 7 points, monotonie à 1e-5, comparaison q = p contre les 6 autres points de
la grille pour p intérieur), comparé à l'optimum vrai de E_p[R(y, q)] sur une grille fine.
Usage : python -I proprete_regles_v1.py"""
import math

GRILLE = [0.05, 0.15, 0.30, 0.50, 0.70, 0.85, 0.95]

def controle_grille(R):  # transcription de verifier_proprete_stricte_recompense
    v1 = [float(R(1, q)) for q in GRILLE]; v0 = [float(R(0, q)) for q in GRILLE]
    for v in v1 + v0:
        if not math.isfinite(v) or v < -10.0 or v > 10.0:
            return "rejet (bornes)"
    for i in range(len(GRILLE) - 1):
        if not (v1[i + 1] > v1[i] + 1e-5):
            return "rejet (R(1,q) non strictement croissante)"
        if not (v0[i + 1] < v0[i] - 1e-5):
            return "rejet (R(0,q) non strictement décroissante)"
    for ip, p in enumerate(GRILLE[1:-1], 1):
        ep = p * v1[ip] + (1 - p) * v0[ip]
        for iq, q in enumerate(GRILLE):
            if iq != ip and ep <= p * v1[iq] + (1 - p) * v0[iq] + 1e-5:
                return f"rejet (propreté : p={p}, q={q})"
    return "ACCEPTE"

FINE = [i / 10000 for i in range(1, 10000)]
def optimum(R, p):
    return max(FINE, key=lambda q: p * R(1, q) + (1 - p) * R(0, q))

def clip(q): return max(1e-4, min(1 - 1e-4, float(q)))
def brier(y, q): return (y - clip(q)) ** 2
def logl(y, q): q = clip(q); return -math.log(q) if y == 1 else -math.log(1 - q)
A = 4.0 / 3.0
def tsallis_v53(q): q = clip(q); return (q ** A + (1 - q) ** A - 1) / (A * (A - 1))   # principal.py v5.3 l. 891 (≤ 0, max aux bords)
def tsallis_sonde(q): q = clip(q); return (1 - q ** A - (1 - q) ** A) / (A * (A - 1))  # objectif de sonde, principal.py l. 48

REGLES = {
    "Brier : 1 - (y-q)^2": lambda y, q: 1 - brier(y, q),
    "logarithmique bornée : -log": lambda y, q: -logl(y, q),
    "v6 initiale : 1 - (0,80 Brier + 0,20 log)": lambda y, q: 1 - (0.8 * brier(y, q) + 0.2 * logl(y, q)),
    "v6 gabarit, poids Brier 0,55": lambda y, q: 1 - (0.55 * brier(y, q) + 0.45 * logl(y, q)),
    "v6 gabarit, poids Brier 0,95": lambda y, q: 1 - (0.95 * brier(y, q) + 0.05 * logl(y, q)),
    "constante 0,99": lambda y, q: 0.99,
    "linéaire : q si y=1, 1-q sinon": lambda y, q: q if y == 1 else 1 - q,
    "v5.3 interne : 1 - Brier + 0,1 Tsallis (sur-confiante)": lambda y, q: 1 - brier(y, q) + 0.1 * tsallis_v53(q),
    "sonde v5.3 en récompense : -(Brier + 0,08 Tsallis)": lambda y, q: -(brier(y, q) + 0.08 * tsallis_sonde(q)),
    "sur-confiante : 1 - Brier + 0,10 (q-1/2)^2": lambda y, q: 1 - brier(y, q) + 0.10 * (clip(q) - 0.5) ** 2,
    "sur-confiante : 1 - Brier + 0,30 (q-1/2)^2": lambda y, q: 1 - brier(y, q) + 0.30 * (clip(q) - 0.5) ** 2,
    "Brier décalée : 1,5 - (y-q)^2 (même optimum, niveau +0,5)": lambda y, q: 1.5 - brier(y, q),
    "Brier dilatée : 5 (1 - (y-q)^2) (même optimum, échelle x5)": lambda y, q: 5 * (1 - brier(y, q)),
    "Brier réduite : 1e-5 (1 - (y-q)^2) (propre)": lambda y, q: 1e-5 * (1 - brier(y, q)),
}
P_TEST = [0.05, 0.15, 0.30, 0.50, 0.60, 0.70, 0.80, 0.90, 0.95]
print("règle | contrôle de grille (transcrit) | écart max |q*(p) - p| sur p ∈ {0,05…0,95} | q* pour p = 0,60 / 0,70 / 0,80 / 0,90")
for nom, R in REGLES.items():
    verdict = controle_grille(R)
    ecarts = {p: optimum(R, p) for p in P_TEST}
    emax = max(abs(ecarts[p] - p) for p in P_TEST)
    print(f"{nom} | {verdict} | {emax:.4f} | {ecarts[0.60]:.4f} / {ecarts[0.70]:.4f} / {ecarts[0.80]:.4f} / {ecarts[0.90]:.4f}")
# niveau moyen sur un exemple de calibration : 2 vérifications, une juste à 0,85, une fausse à 0,70
for nom in ("Brier : 1 - (y-q)^2", "Brier décalée : 1,5 - (y-q)^2 (même optimum, niveau +0,5)", "v6 gabarit, poids Brier 0,55", "v6 gabarit, poids Brier 0,95", "v6 initiale : 1 - (0,80 Brier + 0,20 log)", "v5.3 interne : 1 - Brier + 0,1 Tsallis (sur-confiante)"):
    R = REGLES[nom]; m = (R(1, 0.85) + R(0, 0.70)) / 2
    print(f"score interne moyen (juste à 0,85 ; fausse à 0,70) avec « {nom} » : {m:.4f}  (seuil fin de conception 0,78 : {'atteint' if m >= 0.78 else 'non atteint'})")
