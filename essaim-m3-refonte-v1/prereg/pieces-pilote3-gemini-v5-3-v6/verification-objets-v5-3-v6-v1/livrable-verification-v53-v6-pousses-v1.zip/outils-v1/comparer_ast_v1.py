"""Compare deux fichiers Python par leur arbre syntaxique, docstrings retirées (lecture seule, aucune exécution).
Usage : python -I comparer_ast_v1.py FICHIER_A FICHIER_B"""
import ast, sys

def sans_docstrings(arbre):
    for n in ast.walk(arbre):
        if isinstance(n, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            corps = n.body
            if corps and isinstance(corps[0], ast.Expr) and isinstance(getattr(corps[0], "value", None), ast.Constant) \
                    and isinstance(corps[0].value.value, str):
                n.body = corps[1:] or [ast.Pass()]
    return arbre

def lire(p):
    with open(p, encoding="utf-8") as f:
        return f.read()

a, b = sys.argv[1], sys.argv[2]
ta, tb = ast.parse(lire(a)), ast.parse(lire(b))
brut = ast.dump(ta) == ast.dump(tb)
da, db = ast.dump(sans_docstrings(ta)), ast.dump(sans_docstrings(tb))
print(f"arbre identique (docstrings comprises) : {brut}")
print(f"arbre identique (docstrings retirées) : {da == db}")
if da != db:
    fa = {n.name: ast.dump(n) for n in ast.walk(ast.parse(lire(a))) if isinstance(n, ast.FunctionDef)}
    fb = {n.name: ast.dump(n) for n in ast.walk(ast.parse(lire(b))) if isinstance(n, ast.FunctionDef)}
    ta2, tb2 = sans_docstrings(ast.parse(lire(a))), sans_docstrings(ast.parse(lire(b)))
    ga = {n.name: ast.dump(n) for n in ast.walk(ta2) if isinstance(n, ast.FunctionDef)}
    gb = {n.name: ast.dump(n) for n in ast.walk(tb2) if isinstance(n, ast.FunctionDef)}
    for nom in sorted(set(ga) | set(gb)):
        if ga.get(nom) != gb.get(nom):
            print(f"  fonction différente : {nom}")
