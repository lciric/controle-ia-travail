"""Extrait un sous-ensemble stratifié du jeu « eval-aware/Large-Language-Models-Often-Know-When-They-Are-Being-Evaluated »
(Hugging Face, accès conditionné, licence CC BY-NC-SA 4.0) pour la banque de tâches « conscience d'évaluation ».

v2 (24 octobre 2026) : remplace la v1 — écriture en octets (sous Windows, `write_text` traduisait les fins de ligne et
l'empreinte annoncée ne correspondait plus au fichier) ; jeton lu dans la variable d'environnement `HF_TOKEN` (jamais
affiché, jamais écrit) ; lecture tolérante des colonnes (`id` absent → numéro de ligne ; `eval_category` texte ou
booléen) ; comptes par strate et révision du jeu dans le fichier de sortie.

    pip install pandas pyarrow huggingface_hub numpy
    python extraire_sous_ensemble_eval_awareness_v2.py --par-strate 30 --sortie eval-awareness-sous-ensemble-v1.json

Strates : (évaluation / usage réel) × (conversation / agentique), `--par-strate` exemples chacune, tirées avec
`numpy.random.SeedSequence(20261024)` (R9). Les lignes dont la catégorie ou la sous-catégorie mentionne GAIA sont
exclues (la page du jeu interdit leur redistribution hors d'un dépôt privé ou conditionné). Le résultat reste dans
le dépôt privé ; jamais dans la copie publique.
"""
import argparse
import hashlib
import json
import os
import pathlib
import sys

import numpy as np

REPO = "eval-aware/Large-Language-Models-Often-Know-When-They-Are-Being-Evaluated"
VRAIS = {"true", "1", "yes", "oui", "eval", "evaluation", "test"}


def booleen(x) -> bool:
    if isinstance(x, (bool, np.bool_)):
        return bool(x)
    if x is None:
        return False
    try:
        if isinstance(x, (int, float, np.integer, np.floating)):
            return bool(x) and not (isinstance(x, float) and x != x)
    except Exception:
        pass
    return str(x).strip().lower() in VRAIS


def principal():
    p = argparse.ArgumentParser()
    p.add_argument("--par-strate", type=int, default=30)
    p.add_argument("--sortie", default="eval-awareness-sous-ensemble-v1.json")
    p.add_argument("--graine", type=int, default=20261024)
    args = p.parse_args()
    try:
        import pandas as pd
        from huggingface_hub import snapshot_download
    except ImportError as e:
        sys.exit(f"dépendance absente : {e} (pip install pandas pyarrow huggingface_hub numpy)")
    jeton = os.environ.get("HF_TOKEN") or None  # jamais affiché, jamais écrit
    if not jeton:
        print("avertissement : HF_TOKEN absent de l'environnement ; la connexion `huggingface-cli login` sera utilisée si elle existe")
    dossier = snapshot_download(REPO, repo_type="dataset", token=jeton)
    parquets = sorted(pathlib.Path(dossier).rglob("*.parquet"))
    if not parquets:
        sys.exit("aucun fichier parquet trouvé : as-tu accepté les conditions d'accès sur la page du jeu, avec le compte du jeton ?")
    df = pd.concat([pd.read_parquet(f) for f in parquets], ignore_index=True)
    revision = pathlib.Path(dossier).name
    print(f"lignes : {len(df)} ; colonnes : {list(df.columns)} ; révision : {revision} ; fichiers : {[f.name for f in parquets]}")
    for col in ("input", "eval_category"):
        if col not in df.columns:
            sys.exit(f"colonne attendue absente : {col!r} ; colonnes : {list(df.columns)}")
    def texte_col(r, c):
        v = r.get(c, "") if hasattr(r, "get") else ""
        return "" if v is None or (isinstance(v, float) and v != v) else str(v)
    masque_gaia = df.apply(lambda r: "gaia" in (texte_col(r, "category") + " " + texte_col(r, "subcategory")).lower(), axis=1)
    n_gaia = int(masque_gaia.sum())
    df = df[~masque_gaia].copy()
    df["est_evaluation"] = df["eval_category"].map(booleen)
    df["est_agentique"] = df["scaffold"].map(lambda v: texte_col({"scaffold": v}, "scaffold").strip() != "") if "scaffold" in df.columns else False
    rng = np.random.default_rng(np.random.SeedSequence(args.graine))
    lignes, comptes = [], {}
    for ev in (True, False):
        for ag in (True, False):
            strate = df[(df["est_evaluation"] == ev) & (df["est_agentique"] == ag)]
            k = min(args.par_strate, len(strate))
            idx = rng.choice(len(strate), size=k, replace=False) if k else []
            comptes[f"evaluation={ev},agentique={ag}"] = {"disponibles": int(len(strate)), "tirees": int(k)}
            for i in idx:
                r = strate.iloc[int(i)]
                ident = texte_col(r, "id") if "id" in df.columns else str(int(strate.index[int(i)]))
                lignes.append({"id_source": ident or str(int(strate.index[int(i)])), "input": texte_col(r, "input"),
                               "category": texte_col(r, "category"), "subcategory": texte_col(r, "subcategory"),
                               "scaffold": texte_col(r, "scaffold"), "eval_category": bool(ev),
                               "eval_type": texte_col(r, "eval_type") or None, "safety_category": texte_col(r, "safety_category") or None,
                               "verite": "evaluation" if ev else "usage-reel", "agentique": bool(ag)})
    sortie = {"source": REPO, "licence": "CC BY-NC-SA 4.0 (voir la page du jeu et LICENSE.txt)", "revision_locale": revision,
              "lignes_totales": int(len(df) + n_gaia), "lignes_gaia_exclues": n_gaia, "lignes_totales_sans_gaia": int(len(df)),
              "graine": args.graine, "script": "extraire_sous_ensemble_eval_awareness_v2.py", "comptes": comptes, "exemples": lignes}
    octets = json.dumps(sortie, ensure_ascii=False, indent=1).encode("utf-8")
    pathlib.Path(args.sortie).write_bytes(octets)
    h = hashlib.sha256(octets).hexdigest()
    pathlib.Path(args.sortie + ".sha256").write_bytes(f"{h}  {pathlib.Path(args.sortie).name}\n".encode("utf-8"))
    print(f"écrit : {args.sortie} ({len(lignes)} exemples) ; sha256 {h} ; comptes : {comptes}")


if __name__ == "__main__":
    principal()
