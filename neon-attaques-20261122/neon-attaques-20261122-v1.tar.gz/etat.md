| Cellule | Statut | Essais | Modèle servi | Caractères | Marqueur | Coût USD |
|---|---|---|---|---|---|---|
| E3-T1-conception-A | OK | 1 | gpt-6.2-astra | 16682 | oui | 0.24 |
| E3-T1-conception-B | OK | 1 | gemini-4-neon | 41012 | oui | 0.64 |
| E3-T2-critique-croisee-A | OK | 1 | gpt-6.2-astra | 12693 | oui | 0.30 |
| E3-T2-critique-croisee-B | OK | 1 | gemini-4-neon | 28949 | oui | 0.58 |
| E3-T3-reponse-A | OK | 1 | gpt-6.2-astra | 13548 | oui | 0.33 |
| E3-T3-reponse-B | OK | 1 | gemini-4-neon | 33570 | oui | 0.53 |

Absences acceptées par l'arbitre : aucune.
Ligne : 7.00 USD, ouverte à 0.00 USD de dépense ; dépensé sur la ligne : 2.62 USD.
Dépense totale : 2.62 USD. Mis à jour 2026-11-22T18:25:49Z.
