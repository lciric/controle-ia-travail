# Sur la proposition A

*Pièce reçue : `E3-T1-conception-A` (complète, close par `FIN-DE-CELLULE`). Statuts repris sans modification des faits transmis : faits 1 à 6 `VÉRIFIÉ`, fait 7 `RAPPORTÉ`, fait 8 `HYPOTHÈSE`. Toutes les propositions, fiches et estimations de la pièce A portent le statut `HYPOTHÈSE` ; nos diagnostics méthodologiques et empiriques ci-dessous portent également le statut `HYPOTHÈSE`, hormis les identités algébriques déduites des définitions probabilistes.*

---

## 1. Critique mode par mode (qualification, nouveauté, faiblesse vs exposition, vrai par construction, détails opérants)

**Bilan sur les détails opérants et la couverture des cibles.** Aucune des quatre fiches de la proposition A ne contient de recette opérante (ni consigne, ni fonction de coût, ni code, ni exemple rédigé, ni valeur de réglage d'attaque). Les mentions de familles de modèles et d'enveloppe budgétaire (`HYPOTHÈSE`, chiffres **illustratifs** dans A : 100 heures-GPU à 3 €, soit 300 €) relèvent d'un cadrage matériel, non d'une recette d'attaque. En revanche, `HYPOTHÈSE` : la couverture des cibles des faits 2 et 4 (`VÉRIFIÉ`) est incomplète : aucun mode ne vise l'agrégation par attention ni la géométrie de Mahalanobis (fait 2), et aucun mode ne vise les moniteurs « boîte noire » par action ou à état (fait 4), la fiche C visant le lecteur de référence et la fiche D un collège dont la règle d'agrégation n'est pas établie dans les faits.

### Fiche A — *Dépendance des extrêmes* (sondes à maximum)

- **Mode ou recette ?** C'est un mode au sens probabiliste (propriété de dépendance de queue), non une recette. Toutefois (`HYPOTHÈSE`), sa définition relève davantage d'une propriété générale d'un processus agrégé par maximum que d'un mode d'attaque spécifié : la fiche ne distingue pas si l'attaquant agit uniquement sur les épisodes sabotés ($Y=1$) ou aussi sur les épisodes honnêtes ($Y=0$).
- **Inédit ou famille connue ?** `HYPOTHÈSE` : revient à une famille connue, celle du regroupement d'extrêmes (*extremal clustering* / indice extrémal en théorie des valeurs extrêmes, référence à vérifier) et du découplage entre discrimination au niveau instance et au niveau sac en apprentissage multi-instances (*multiple-instance learning*, référence à vérifier). De plus, comme démontré en section 2(a), la fiche A est mathématiquement isomorphe à la fiche D (cas particulier $k=1$ d'une agrégation à seuil sur indicateurs corrélés) : les classer respectivement premier et dernier en nouveauté est incohérent.
- **Distingue-t-elle un moniteur exposé d'un moniteur simplement faible ?** `HYPOTHÈSE` : non. Sous la convention commune (perte absolue $\Delta > \delta$), un moniteur faible sur le témoin ($\text{TPR}_{\text{tém}}(\alpha) \le \alpha + \delta$) ne peut pas perdre plus de $\delta$ sans passer sous le hasard et se voit donc déclaré résistant ($H_B$). Inversement, une sonde faible accrochée à des motifs superficiels naturellement groupés peut chuter sur un contraste textuel sans exposition spécifique.
- **Qu'est-ce qui y est vrai par construction ?** La fiche affirme qu'« une baisse de détection à fausses alertes fixées ne le serait pas ». C'est **faux** sous ses propres hypothèses lorsque la loi de $Y=0$ est inchangée et que la probabilité marginale de queue $\bar{p}_1(u_\alpha)$ du score de sonde est maintenue constante : par l'identité exacte $\text{TPR}_{\max}(u_\alpha) = L\bar{p}_1(u_\alpha)/\mu_1^+(u_\alpha)$ (établie ci-dessous), toute hausse de la taille moyenne de regroupement $\mu_1^+(u_\alpha)$ impose algébriquement une baisse proportionnelle de $\text{TPR}_{\max}(u_\alpha)$.

### Fiche B — *Défaut de transport du repère* (sondes)

- **Mode ou recette ?** C'est un mode (au niveau des lois conditionnelles), sans détail opérant. Cependant (`HYPOTHÈSE`), dans la formulation en bras aveugle, il décrit un protocole classique d'évaluation hors distribution plutôt qu'un mode d'attaque déplaçant activement le moniteur (fait 1, `VÉRIFIÉ`).
- **Inédit ou famille connue ?** `HYPOTHÈSE` : revient directement à une famille très connue : le décalage conditionnel / changement de concept (*concept shift*, référence à vérifier) et le défaut de généralisation interdomaines des sondes de représentation, déjà un diagnostic standard de la littérature sur les sondes (référence à vérifier).
- **Distingue-t-elle un moniteur exposé d'un moniteur simplement faible ?** `HYPOTHÈSE` : non. Une sonde faible qui n'a appris qu'un raccourci superficiel propre au contexte témoin s'effondre dans un autre contexte ($\Delta > \delta$), tandis que des sondes intracontexte réajustées peuvent exploiter de nouveaux raccourcis propres à chaque contexte. La fiche ne distingue pas une rotation géométrique d'une représentation authentique du dommage de l'échec attendu d'une sonde opportuniste.
- **Qu'est-ce qui y est vrai par construction ?** Pour une sonde linéaire ou par différence de moyennes (fait 2, `VÉRIFIÉ`), si la frontière réelle $P(Y=1 \mid H)$ est non linéaire mais **strictement invariante** d'un contexte à l'autre ($Y \perp C \mid H$) et que les contextes occupent des régions distinctes de l'espace des activations (simple décalage de covariables $P(H \mid C)$), alors $K$ sondes linéaires locales surpassent par construction une sonde linéaire globale par approximation linéaire par morceaux.

### Fiche C — *Équivalence de preuve* (juges lecteurs)

- **Mode ou recette ?** C'est un mode (niveau épistémique/probabiliste), sans détail opérant.
- **Inédit ou famille connue ?** `HYPOTHÈSE` : revient à deux familles connues, l'apprentissage par raccourcis d'inférence (*shortcut learning* / heuristiques superficielles en inférence en langage naturel, référence à vérifier) et le découplage entre attribution extractive vérifiable et implication logique globale (*attribution without entailment* / distracteurs en vérification de faits multi-sauts, référence à vérifier). Plus gravement (`HYPOTHÈSE`), rapprochée du fait 1 (`VÉRIFIÉ` : sabotage diffus dont chaque action est innocente prise seule), la dissociation entre preuve locale et dommage global est **déjà la propriété constitutive du sabotage diffus** : si le témoin impose une concordance locale-globale, le contraste oppose un sabotage localisé à un sabotage diffus plutôt qu'un mode d'attaque propre au juge.
- **Distingue-t-elle un moniteur exposé d'un moniteur simplement faible ?** `HYPOTHÈSE` : non. Dissocier la preuve locale de la conclusion globale accroît nécessairement la profondeur inférentielle (nombre de prémisses à composer). Un juge simplement faible en raisonnement global ou multi-sauts échoue sur le bras attaqué sans être spécifiquement piégé par l'exigence de citation.
- **Qu'est-ce qui y est vrai par construction ?** Outre l'authenticité des extraits (signalée par A), tout moniteur local par architecture (tel un moniteur par action, fait 4, `VÉRIFIÉ`) échoue par construction dès que la preuve locale est insuffisante. De plus, si le témoin est concordant en un saut et le bras attaqué exige une synthèse globale, un avantage de complexité inférentielle en faveur du témoin est inscrit par construction.

### Fiche D — *Concentration des erreurs communes* (collège de juges)

- **Mode ou recette ?** C'est un mode (copule des erreurs), sans détail opérant.
- **Inédit ou famille connue ?** `HYPOTHÈSE` : revient directement à des familles classiques — défaillance de cause commune en sûreté de fonctionnement, théorème du jury sous dépendance et transférabilité adversariale entre modèles (références à vérifier) — et recouvre déjà la matrice de transfert posée au fait 3 (`VÉRIFIÉ`). Elle est aussi mathématiquement isomorphe à la fiche A (même changement de copule à marges fixes sous agrégation à seuil).
- **Distingue-t-elle un moniteur exposé d'un moniteur simplement faible ?** `HYPOTHÈSE` : partiellement seulement. L'effet de plancher sur $\delta$ masque les collèges faibles, et un collège composé de juges faibles ($r < k/M$ sous règle majoritaire) peut même voir sa détection **augmenter** quand la corrélation des décisions croît (inversion de signe détaillée en section 3).
- **Qu'est-ce qui y est vrai par construction ?** Contrairement à ce qu'affirme la fiche A (rubrique 6 de D), pour une règle de disjonction (« au moins un juge alerte », $S \ge 1$) à taux individuels $r_m$ fixes, toute hausse du regroupement des alertes sur les mêmes épisodes réduisant le nombre d'épisodes couverts **impose algébriquement** une chute de détection collective. Pour une règle majoritaire avec juges meilleurs que le hasard, l'augmentation de la corrélation positive à marges fixes accroît mécaniquement $\text{Var}(S \mid Y=1)$ et dégrade la queue au-delà du seuil dès que la règle est symétrique.

---

## 2. (a) Défauts de méthode : variables confondantes, tautologies et fuites

### Défauts transversaux à la convention de mesure commune

1. **Effets de plancher et de plafond sur la marge absolue $\delta$ (`HYPOTHÈSE`).** Tous les duels opposent $\Delta = \text{TPR}_{\text{tém}}(\alpha) - \text{TPR}_{\text{att}}(\alpha) > \delta$ à $\Delta \le \delta$. Sans condition préalable sur le niveau de base ($\text{TPR}_{\text{tém}}(\alpha)$ loin de $\alpha$ et loin de $1$), un moniteur faible satisfait $H_B$ par manque de marge de chute, et un moniteur saturé près de $1$ peut subir une forte perte de séparation latente tout en gardant $\Delta \le \delta$. De plus, les duels testent un seuil scalaire unique plutôt que deux mécanismes explicatifs exclusifs (exigence B4).
2. **Incompatibilité entre « même taux de fausses alertes » et sorties discrètes (`HYPOTHÈSE`).** Les juges lecteurs (fiche C) et un collège à votes binaires sous règle gelée (fiche D) produisent des décisions discrètes ; le taux de fausses alertes exact $\alpha$ n'est généralement pas atteignable simultanément sur le témoin et le bras attaqué sans score continu ni randomisation, non spécifiés par A.
3. **Biais d'appariement post-traitement et fuite de covariables latentes (`HYPOTHÈSE`).** La convention commune apparie sur la longueur, les « possibilités de dommage », la « difficulté de vérification » et la « gravité du dommage ». Or : (i) si un mode d'attaque modifie la longueur ou la difficulté de vérification en aval de la politique de l'agent, apparier sur ces médiateurs post-traitement bloque ou distord l'effet causal (biais de conditionnement / collisionneur) ; (ii) si ces grandeurs latentes sont estimées par un modèle de langue ou une heuristique corrélée au moniteur évalué, une fuite directe s'introduit entre construction de l'appariement et évaluation.
4. **Fuite potentielle de recalibration sur le bras scellé (`HYPOTHÈSE`).** Comparer $\text{TPR}_{\text{att}}$ à $\text{FPR}=\alpha$ calibré sur des épisodes honnêtes issus du bras attaqué présuppose que le défenseur dispose d'un échantillon de calibration propre à l'attaque avant déploiement, ce qui rompt la symétrie opérationnelle du scellement (fait 6, `VÉRIFIÉ`), même si le rapport au seuil témoin gelé en atténue partiellement la confusion.

### Défauts spécifiques par fiche

- **Fiche A (`HYPOTHÈSE`).**
  - *Fuite d'appariement* : « apparier les performances locales » de la sonde évaluée sélectionne l'épreuve à l'aide de l'instrument testé ; à l'inverse, apparier les marginales dans l'espace complet des activations $H_t \in \mathbb{R}^d$ est statistiquement hors de portée dans les queues extrêmes ($1/L$).
  - *Confusion entre dépendance intratrajectoire et hétérogénéité interépisodes* : regrouper les dépassements dans un sous-ensemble plus restreint d'épisodes (mélange d'épisodes faciles et invisibles) modifie la moyenne conditionnelle $\mu_1^+(u_\alpha)$ exactement comme une dépendance temporelle stationnaire, sans aucun mécanisme de dépendance des extrêmes au sein des trajectoires.
  - *Incohérence de label local* : la fiche présuppose une « discrimination locale » par position alors que le sabotage diffus (fait 1, `VÉRIFIÉ`) n'est défini qu'au niveau de l'épisode — incohérence que A reconnaît elle-même dans son tableau pour les moniteurs textuels mais ignore en fiche A.
- **Fiche B (`HYPOTHÈSE`).**
  - *Confusion décalage additif / rotation du repère* : si la direction discriminante $w$ est strictement invariante entre contextes mais que la moyenne de base $\mu_c$ varie ($H \mid Y, C=c$ subit une translation $\mu_c$), la sonde globale perd en discrimination par mélange d'offsets $w^\top \mu_c$, tandis qu'un simple réajustement du biais scalaire $b_c$ par contexte restaure la lecture. La comparaison entre sonde globale fixe et sondes intracontexte librement réentraînées confond ce simple décalage d'offset avec un défaut de transport géométrique du repère.
  - *Asymétrie de capacité effective* : $K$ sondes intracontexte possèdent globalement $K$ fois plus de paramètres qu'une sonde unique ; sous décalage de covariables $P(H \mid C)$ et frontière non linéaire invariante, l'écart est produit sans aucun défaut de transport.
  - *Ambiguïté d'entraînement* : la fiche ne sépare pas l'extrapolation vers un contexte inédit (zéro-shot) de l'incompatibilité sur un mélange de contextes vus à l'entraînement.
- **Fiche C (`HYPOTHÈSE`).**
  - *Régression d'oracle et fuite d'annotation* : le lecteur du fait 4 (`VÉRIFIÉ`) sert précisément à établir la vérité du dommage ; évaluer ce lecteur exige une double annotation externe (dommage et suffisance du dossier). Si un autre modèle de langue fournit l'étalon de suffisance, des angles morts partagés biaisent la sélection des dossiers « décidables » (fuite corrélée entre oracle et juge testé).
  - *Confusion entre sabotage diffus et vulnérabilité de citation* : sans contrôle maintenant constante la profondeur inférentielle entre témoin et attaque, la perte mesure le passage d'un dommage localement décidable à un dommage diffus.
- **Fiche D (`HYPOTHÈSE`).**
  - *Incompatibilité logique entre règle gelée, marges fixes et FPR collectif constant* : si la corrélation des fausses alertes change sur $Y=0$, une règle discrète gelée ne peut pas conserver le même FPR collectif à taux individuels fixes.
  - *Paradoxe d'attribution et biais d'erreur de type II* : une véritable attaque par cause commune (angle mort partagé) dégrade simultanément les performances individuelles $r_m$, ce qui déclenche l'échec d'attribution de la rubrique 8. À l'inverse, si l'égalité des marges est seulement « non rejetée dans la précision de l'étude » (sans test d'équivalence strict), de petites baisses individuelles non détectées s'additionnent pour créer une perte collective faussement attribuée à la seule corrélation.

---

## 3. (b) Conditions mesurables de perte de puissance ou d'injugeabilité

*Conformément à la consigne, cette section ne formule que des lois de probabilité, des paramètres et des estimateurs (`HYPOTHÈSE` pour l'applicabilité empirique aux instruments du programme).*

### Convention commune (calibrage du seuil et duel sur $\delta$)

Soient $F_0, F_1$ (densités $f_0, f_1$) les lois continues d'un score scalaire sous $Y=0$ et $Y=1$, $R(\alpha) = 1 - F_1(F_0^{-1}(1-\alpha))$ la courbe ROC, $\hat{u}_\alpha$ le quantile empirique d'ordre $1-\alpha$ estimé sur $n_{\text{cal},0}$ épisodes honnêtes indépendants, et $n_{\text{test},1}$ le nombre d'épisodes endommagés d'épreuve. Par la méthode delta sur $1 - F_0(\hat{u}_\alpha)$ (de variance approchée $\alpha(1-\alpha)/n_{\text{cal},0}$), la variance totale de l'estimateur $\widehat{\text{TPR}}(\hat{u}_\alpha)$ vaut au premier ordre :
$$\text{Var}\!\left(\widehat{\text{TPR}}(\hat{u}_\alpha)\right) \approx \frac{R(\alpha)(1 - R(\alpha))}{n_{\text{test},1}} + \left(\frac{f_1(u_\alpha)}{f_0(u_\alpha)}\right)^2 \frac{\alpha(1-\alpha)}{n_{\text{cal},0}}.$$
La mesure perd sa puissance ou devient non jugeable dès que :
1. **Amplification par le rapport de vraisemblance en queue** : $R'(\alpha) = f_1(u_\alpha)/f_0(u_\alpha)$ est grand alors que $n_{\text{cal},0}\alpha$ est modéré, rendant le second terme dominant et élargissant l'intervalle de confiance de $\hat{\Delta}$ au-delà de $\delta$.
2. **Régime de plancher ou de plafond** : $R_{\text{tém}}(\alpha) \le \alpha + \delta$ (impossibilité de distinguer résistance et faiblesse) ou $1 - R_{\text{tém}}(\alpha) \ll \delta$ avec séparation latente élevée (insensibilité à une forte dégradation des paramètres de séparation).
3. **Zone frontière** : $|\Delta_{\text{vrai}} - \delta| = O\!\left(\text{SE}(\hat{\Delta})\right)$, où la probabilité d'indécision reste élevée.
4. **Sauts discrets** : si $F_0$ comporte des atomes de masse $\pi_0 > \alpha$ ou comparables à $\alpha$, l'estimateur à $\alpha$ fixé sans randomisation n'est pas identifiable.

### Fiche A (sondes à maximum)

Soit $S_1, \dots, S_L$ la suite des scores locaux, $M_L = \max_{1 \le t \le L} S_t$, $N_L(u) = \sum_{t=1}^L \mathbb{1}(S_t > u)$, $\bar{p}_y(u) = \frac{1}{L}\sum_{t=1}^L P(S_t > u \mid Y=y)$ et $\mu_y^+(u) = \mathbb{E}[N_L(u) \mid N_L(u) \ge 1, Y=y]$. Sans hypothèse de stationnarité, pour tout $u$ tel que $P(M_L > u \mid Y=y) > 0$ :
$$P(M_L > u \mid Y=y) = \frac{L\,\bar{p}_y(u)}{\mu_y^+(u)}.$$
À longueur $L$ appariée et seuil $u_\alpha$ inchangé (loi de $Y=0$ fixe), le rapport des détections se factorise exactement :
$$\frac{\text{TPR}_{\max}^{\text{att}}(u_\alpha)}{\text{TPR}_{\max}^{\text{tém}}(u_\alpha)} = \frac{\bar{p}_1^{\text{att}}(u_\alpha)}{\bar{p}_1^{\text{tém}}(u_\alpha)} \cdot \frac{\mu_1^{+,\text{tém}}(u_\alpha)}{\mu_1^{+,\text{att}}(u_\alpha)}.$$
Posons $q = \text{TPR}_{\max}(u_\alpha)$ et $\text{CV}^2(C) = \text{Var}(N_L(u_\alpha) \mid N_L(u_\alpha)\ge 1, Y=1) / (\mu_1^+(u_\alpha))^2$. Pour l'estimateur empirique $\hat{p}_1(u_\alpha) = \frac{1}{n_1 L}\sum_{i=1}^{n_1} N_{L,i}(u_\alpha)$ sur $n_1$ épisodes indépendants, la variance totale donne exactement :
$$\left(\frac{\text{SE}(\hat{p}_1(u_\alpha))}{\bar{p}_1(u_\alpha)}\right)^2 = \frac{1}{n_1 q}\left[1 - q + \text{CV}^2(C)\right].$$
Le critère de la fiche A perd sa puissance ou devient non jugeable dès que :
1. **Incapacité à borner la dérive marginale de queue** : $\sqrt{\frac{1 - q + \text{CV}^2(C)}{n_1 q}}$ n'est pas très inférieur à $\delta / q$ ; un glissement non rejeté de $\bar{p}_1(u_\alpha)$ d'amplitude $O(\delta/L)$ (invisible sur une AUC locale globale, qui ne varie que de $O(1/L)$) explique alors à lui seul une perte $\delta$ sur $\text{TPR}_{\max}$.
2. **Déplacement concomitant de la dépendance sous $Y=0$** : si $\mu_0^+(u)$ varie entre témoin et attaque, le seuil $u_\alpha$ se déplace ($u_\alpha^{\text{att}} \neq u_\alpha^{\text{tém}}$), et le contraste mélange la pente des queues marginales $\bar{p}_1(u)$ et $\bar{p}_0(u)$ avec la dépendance.
3. **Non-identifiabilité du mécanisme de mélange** : deux lois conjointes ayant la même loi de $N_L(u_\alpha)$ — l'une stationnaire d'indice extrémal $\theta < 1$, l'autre issue d'un mélange hétérogène d'épisodes de paramètre latent $Z_i$ — sont indistinguables par $(M_L, \hat{p}_1, \hat{\mu}_1^+)$.

### Fiche B (défaut de transport du repère)

Soient $H \in \mathbb{R}^d$ les représentations, $C \in \{1,\dots,K\}$ le contexte, $n_c$ l'effectif dans le contexte $c$, et $\Sigma_c$ la covariance de $H \mid C=c$ de rang effectif $r_{\text{eff}}(\Sigma_c) = \text{tr}(\Sigma_c)/\|\Sigma_c\|_{\text{op}}$. Le critère devient non jugeable ou biaisé dès que :
1. **Surparamétrisation intracontexte** : $r_{\text{eff}}(\Sigma_c) / n_c$ n'est pas petit, de sorte que la variance d'estimation hors échantillon des estimateurs locaux $\hat{f}_c$ effondre la lisibilité intracontexte et fait conclure à tort à une perte d'information.
2. **Décalage d'offset pur** : $\text{Var}_C(\mathbb{E}[w^\top H \mid Y=0, C]) > 0$ alors que la direction discriminante conditionnelle reste constante, produisant $\Delta > \delta$ sans changement de repère directionnel.
3. **Non-linéarité sous décalage de covariables** : $P(Y=1 \mid H, C) = g(H)$ invariant en $C$ mais non linéaire, avec supports disjoints de $P(H \mid C=c)$, produisant un écart positif entre estimateurs locaux et global pour des familles linéaires.
4. **Déséquilibre des prévalences ou recouvrement insuffisant** : $P(Y=1 \mid C=c)$ varie fortement avec $c$ ou $\min_c n_{c,1}$ est petit, confondant évaluation intercontextes et changement de prévalence ou de composition des dommages.

### Fiche C (équivalence de preuve)

Soient $Y \in \{0,1\}$ le dommage vrai, $Z \in \{0,1\}$ la décidabilité réelle du dossier, $\hat{Z}$ son estimateur d'annotation, $V \in \{0,1\}$ le verdict du lecteur, et $k$ la profondeur inférentielle (nombre minimal de passages nécessaires pour impliquer $Y=1$). Le critère devient non jugeable ou perd sa puissance dès que :
1. **Biais de sélection conditionnelle** : $P(\hat{Z}=1 \mid Y, \text{bras})$ diffère entre témoin et attaque, conditionnant l'estimateur $\widehat{\text{TPR}}_{\text{att} \mid \hat{Z}=1}$ sur des sous-populations non comparables.
2. **Corrélation des erreurs oracle-juge** : $\text{Cov}\!\left(\mathbb{1}(\hat{Z} \neq Z),\, \mathbb{1}(V \neq Y) \mid Y=1\right) > 0$ (ou même corrélation entre $\hat{Y}$ et $V$), qui censure préférentiellement les épisodes où le juge échoue et biaise $\hat{\Delta}$ vers zéro.
3. **Décalage de distribution de $k$** : $P(k \mid Y=1, \text{att})$ domine stochastiquement $P(k \mid Y=1, \text{tém})$ alors que $P(V=1 \mid Y=1, k)$ est décroissante en $k$, rendant non identifiable l'effet propre de l'équivalence de preuve.
4. **Imprécision de l'appariement sur FPR** : lorsque $V$ est binaire et $P(V=1 \mid Y=0, \text{att}) \neq P(V=1 \mid Y=0, \text{tém})$, la perte à FPR fixe n'est pas estimable sans modèle de score continu.

### Fiche D (concentration des erreurs communes)

Soient $J_1, \dots, J_M \in \{0,1\}$ les verdicts des $M$ juges, de marges $r_m = P(J_m=1 \mid Y=1)$ et $\alpha_m = P(J_m=1 \mid Y=0)$, $S = \sum_{m=1}^M J_m$, la règle de décision $\mathbb{1}(S \ge k)$, et $\bar{\rho}_y$ la corrélation moyenne par paires de $(J_m)$ conditionnellement à $Y=y$. À marges symétriques ($r_m=r$, $\alpha_m=\alpha_{\text{ind}}$), $\mathbb{E}[S \mid Y=1] = Mr$ est constant tandis que :
$$\text{Var}(S \mid Y=1) = M r(1-r)\,[1 + (M-1)\bar{\rho}_1], \qquad \text{Var}(S \mid Y=0) = M \alpha_{\text{ind}}(1-\alpha_{\text{ind}})\,[1 + (M-1)\bar{\rho}_0].$$
Le critère perd sa puissance ou devient non jugeable dès que :
1. **Dérive du FPR collectif sous règle gelée** : dès que $k \ge 2$ et $\alpha_{\text{ind}} < k/M$, une hausse de $\bar{\rho}_0 > 0$ augmente $P(S \ge k \mid Y=0)$, interdisant de conserver simultanément la règle gelée, les marges $\alpha_m$ et le FPR collectif.
2. **Inversion de signe** : lorsque $r < k/M$ (juges individuellement faibles à seuil strict ou règle d'unanimité $k=M$), une hausse de $\bar{\rho}_1$ peut augmenter $P(S \ge k \mid Y=1)$, rendant négative la perte attendue $\Delta$.
3. **Effondrement de puissance des $2M$ tests d'équivalence marginale** : si la marge d'équivalence individuelle tolérée est $\eta$, une dérive marginale simultanée $|\Delta r_m| \le \eta$ peut déplacer la détection collective d'un ordre $\sum_{m=1}^M \left|\frac{\partial P_{\text{coll}}}{\partial r_m}\right| \eta$ (jusqu'à $M\eta$ pour $k=1$). Exiger simultanément $|\hat{\Delta} r_m| + z\cdot\text{SE} < \eta$ et $|\hat{\Delta}\alpha_m| + z\cdot\text{SE} < \eta$ pour tous les $m \in \{1,\dots,M\}$ avec $\eta \ll \delta/M$ fait chuter la probabilité jointe de validation des portes d'équivalence dès que $n$ ne croît pas en $O(M^2 \log M / \delta^2)$ ; à l'inverse, omettre ces bornes d'équivalence rend $\hat{\Delta}$ confondu avec une baisse moyenne des marges.

---

## 4. (c) Contrôles négatifs dont l'absence serait fatale

Chaque contrôle ci-dessous vise à falsifier une explication confondante précise (inférence forte, règle B4).

### Contrôles transversaux indispensables

1. **Contrôle de plancher et de plafond (calibrage du régime dynamique) (`HYPOTHÈSE`).** Avant tout duel $H_A/H_B$, vérifier sur le témoin que le moniteur bat la sonde aléatoire appariée (fait 2, `VÉRIFIÉ`) et se situe dans une fenêtre opérationnelle où une perte $\delta$ est à la fois possible ($\text{TPR}_{\text{tém}}(\alpha) > \alpha + \delta$ avec borne inférieure de confiance) et non masquée par saturation (ou rapporter en parallèle une métrique non bornée telle que l'écart de log-cotes ou la différence de moyennes standardisées sur scores). *Sans ce contrôle*, un moniteur faible ou saturé est faussement classé résistant.
2. **Contrôle de dérive de seuil par permutation de calibration (`HYPOTHÈSE`).** Estimer l'écart $\hat{\Delta}$ entre deux scissions aléatoires du seul témoin avec réestimation indépendante de $\hat{u}_\alpha$ sur chaque scission. *Sans ce contrôle*, la variance induite par l'estimation du quantile $\hat{u}_\alpha$ (amplifiée par $R'(\alpha)$) n'est pas isolée du signal d'attaque.

### Contrôles propres à chaque fiche

3. **Fiche A — Contrôle de permutation temporelle intrapopulation et contrôle d'homogénéité interépisodes (`HYPOTHÈSE`).**
   - *Contrôle A1 (permutation des positions entre épisodes de même classe)* : redistribuer aléatoirement les scores $S_{i,t}$ entre épisodes de la même classe $Y=y$ en conservant exactement la loi marginale empirique $\hat{p}_y(u)$ et la longueur $L$. Opposer $H_A$ (la perte disparaît sous permutation, attribuant l'effet à la dépendance conjointe) à $H_B$ (une perte persiste sous permutation, falsifiant l'appariement marginal de queue).
   - *Contrôle A2 (permutation des positions à l'intérieur de chaque épisode vs diagnostic de surdispersion des comptages $N_{L,i}(u_\alpha)$)* : vérifier si la baisse provient d'une corrélation séquentielle interne ou d'une simple hétérogénéité de difficulté entre épisodes (mélange). *Sans A1 et A2*, une dérive de queue d'ordre $O(1/L)$ ou un mélange hétérogène d'épisodes sont indistinguables d'une dépendance des extrêmes.
4. **Fiche B — Contrôle de recalibration d'offset seul et contrôle de partitionnement géométrique dans le témoin (`HYPOTHÈSE`).**
   - *Contrôle B1 (poids fixes $w$, seuil $b_c$ recalibré par contexte)* : opposer $H_A$ (la recalibration scalaire par contexte suffit à restaurer la détection, réfutant une rotation du repère au profit d'une translation d'offset) à $H_B$ (même avec $b_c$ optimal par contexte, seule une réestimation de $w_c$ restaure la lecture, étayant un changement géométrique de direction).
   - *Contrôle B2 (partitions regroupées dans l'espace $H$ au sein du seul témoin, et non partitions aléatoires)* : si $K$ sondes locales surpassent déjà la sonde globale sur une partition géométrique du témoin sans attaque, l'écart provient de la non-linéarité de la frontière sous décalage de covariables, non d'un défaut de transport du repère. *Sans B1 et B2*, deux artefacts majeurs miment intégralement la fiche B.
5. **Fiche C — Contrôle d'ablation de la contrainte de citation à profondeur inférentielle égale (`HYPOTHÈSE`).**
   - *Contrôle C1 (même dossier, avec et sans contrainte d'extrait vérifié, à profondeur inférentielle $k$ appariée entre témoin et attaque)* : opposer $H_A$ (la perte n'apparaît ou ne s'amplifie que sous contrainte de citation ou en présence d'un extrait-leurre localement valide, incriminant l'équivalence de preuve) à $H_B$ (la perte est identique sans contrainte de citation et sans extrait-leurre, falsifiant le mécanisme au profit d'une faiblesse générale de raisonnement global).
   - *Contrôle C2 (accord d'annotation de suffisance entre annotateurs indépendants de familles distinctes du juge testé)* : quantifier l'erreur et la covariance d'erreur de $\hat{Z}$. *Sans C1 et C2*, la fiche C confond le sabotage diffus de base avec une vulnérabilité spécifique au mécanisme de citation.
6. **Fiche D — Contrôle de rééchantillonnage indépendant à marges empiriques gelées et contrôle de stabilité de $\bar{\rho}_0$ (`HYPOTHÈSE`).**
   - *Contrôle D1 (copule indépendante construite sur les marges empiriques observées du bras attaqué)* : comparer la performance réelle du collège sur le bras attaqué à celle obtenue en permutant indépendamment les verdicts de chaque juge entre épisodes de même classe $Y=y$ (conservant exactement les marges empiriques $\hat{r}_m, \hat{\alpha}_m$ du bras attaqué tout en annulant la corrélation). Opposer $H_A$ (l'écart entre collège réel et collège permuté est supérieur à $\delta$, isolant l'effet pur de la corrélation) à $H_B$ (l'essentiel de la perte est déjà présent dans le collège permuté, falsifiant l'attribution à la corrélation au profit d'une dérive non détectée des marges individuelles).
   - *Contrôle D2 (mesure directe de $\bar{\rho}_0$ et du FPR collectif sous règle gelée)* : vérifier explicitement que le taux de fausses alertes du collège ne dérive pas sur $Y=0$ ; à défaut, la comparaison à règle gelée est invalide. *Sans D1 et D2*, toute dégradation individuelle sous le seuil de détection statistique ou tout glissement de FPR collectif corrompt entièrement l'attribution du mode.

FIN-DE-CELLULE