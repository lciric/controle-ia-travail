# Proposition A — Quatre modes candidats

**HYPOTHÈSE — critère de distinction.** Une baisse de détection ne suffit pas à identifier un mode. Il faut pouvoir nommer **ce qui change**, **ce qui reste constant** et **le contraste qui distingue l’effet d’une faiblesse ordinaire du moniteur**. Les quatre fiches ci-dessous sont des hypothèses, y compris leurs rapprochements avec des familles connues ; aucune ne revendique une antériorité établie.

**VÉRIFIÉ — contraintes du programme.** Les sondes agrègent par maximum ou par attention, pas par moyenne. La sonde aléatoire appariée est un comparateur obligatoire. Les bras aveugle et informé sont scellés ; aucun des modes proposés ne requiert que le score d’un moniteur serve à entraîner ou à sélectionner l’agent.

**HYPOTHÈSE — convention de mesure commune.** Pour chaque instrument, la mesure principale serait la **perte de taux de détection entre témoin et bras scellé, au même taux de fausses alertes**. Les cas honnêtes seraient appariés par tâche, longueur, possibilités de dommage et difficulté de vérification ; les cas endommagés, par nature et gravité du dommage. Les seuils de décision seraient calibrés sur des cas honnêtes distincts de l’épreuve. On rapporterait aussi les deux taux au seuil du témoin laissé inchangé : cela distingue un déplacement de calibration d’une perte de discrimination. Pour chaque duel ci-dessous, \(\delta\) désigne une marge de perte matériellement pertinente, choisie avant l’épreuve selon l’usage prévu, et non déduite des résultats. Un intervalle d’incertitude qui traverse cette marge laisse le duel indécis.

## Fiche A — Dépendance des extrêmes

1. **Nom et cible — HYPOTHÈSE.** *Dépendance des extrêmes*, contre les sondes à maximum. Même à longueur fixée, des épisodes dont les états ont les mêmes distributions position par position peuvent différer par la fréquence à laquelle leurs états atypiques surviennent ensemble.
2. **Propriété exploitée — HYPOTHÈSE.** La calibration du maximum suppose transportable non seulement la distribution locale, mais aussi la dépendance entre positions dans la queue de cette distribution.
3. **Invariant de famille — HYPOTHÈSE.** Le contraste porte sur la dépendance conjointe, à distributions locales comparables. Une simple augmentation de longueur ou un déplacement uniforme des états ne relève pas de ce mode.
4. **Connaissance et prise — HYPOTHÈSE.** Bras informé : connaissance du type d’agrégation et latitude sur la distribution conjointe des trajectoires de l’agent. Ni accès aux valeurs de la sonde ni modification de ses paramètres.
5. **Nouveauté — HYPOTHÈSE.** Parent proche : changement de dépendance en statistique des extrêmes. La distinction candidate, ici, est une perte de discrimination de l’épisode **sans perte de discrimination locale**. C’est une application possiblement connue ; référence à vérifier.
6. **Exposition — HYPOTHÈSE.** Comparer la perte de détection au témoin sans attaque, à longueur et performances locales appariées. Contrôle négatif : épisodes sans changement de dépendance, soumis aux mêmes contraintes d’appariement. Une différence de dépendance serait vraie par construction ; **une baisse de détection à fausses alertes fixées ne le serait pas**. Une baisse seulement au seuil inchangé indiquerait plutôt un défaut de calibration.
7. **Vérité indépendante — HYPOTHÈSE.** La provenance scellée attesterait le bras ; un diagnostic de dépendance défini indépendamment de la sonde vérifierait que le contraste existe effectivement. Le dommage serait établi sur le produit final contre la référence cachée, indépendamment des états internes.
8. **Duel — HYPOTHÈSE.** \(H_A\) : la perte de détection de la sonde à maximum dépasse \(\delta\), malgré la stabilité locale. \(H_B\) : elle ne dépasse pas \(\delta\). Une perte nettement au-dessus réfute \(H_B\) ; une borne supérieure au plus égale à \(\delta\) réfute \(H_A\). Un changement local excédant la tolérance d’appariement invalide l’attribution au mode.
9. **Parade — HYPOTHÈSE.** Une calibration sensible à la dépendance pourrait corriger un déplacement de seuil ; une perte de discrimination exigerait un résumé de trajectoire plus informatif. Coûts : données de queue et estimation de dépendances.
10. **Manque — HYPOTHÈSE.** Il faudrait notamment assez d’épisodes indépendants pour contrôler les marges **dans les queues**, pas seulement leurs moyennes. Sans cela, un effet local rare resterait une explication concurrente.

## Fiche B — Défaut de transport du repère

1. **Nom et cible — HYPOTHÈSE.** *Défaut de transport du repère*, contre les sondes. L’information sur le dommage resterait lisible dans chaque contexte pris séparément, mais la relation entre coordonnées internes et dommage ne serait pas commune aux contextes.
2. **Propriété exploitée — HYPOTHÈSE.** Une règle de lecture fixe suppose que des états comparables aient une signification comparable d’un contexte de tâche à l’autre.
3. **Invariant de famille — HYPOTHÈSE.** La signature est la dissociation entre **lisibilité intracontexte conservée** et **lecture intercontextes dégradée**. Une disparition générale de l’information ne satisfait pas la définition.
4. **Connaissance et prise — HYPOTHÈSE.** Bras aveugle concevable si l’agent dispose de plusieurs régimes de représentation pour une même tâche et si leur distribution peut varier ; aucune connaissance des couches, directions ou familles de sondes n’est alors nécessaire. L’existence de cette latitude est une condition, pas un fait.
5. **Nouveauté — HYPOTHÈSE.** Parent proche : décalage de domaine conditionnel. Ce serait une sous-famille testable plutôt qu’un principe statistique neuf : sa différence tient à la conservation de la lisibilité à capacité de lecture égale. Référence à vérifier.
6. **Exposition — HYPOTHÈSE.** Mesurer la perte de la sonde fixe face au témoin et, séparément, l’écart avec une lecture propre à chaque contexte, de même capacité et évaluée hors échantillon. Contrôle négatif : partitions arbitraires de taille et de composition comparables dans le témoin. Une meilleure adaptation **sur les données d’ajustement** ne prouverait rien.
7. **Vérité indépendante — HYPOTHÈSE.** Le contexte et le bras proviendraient du registre expérimental ; les labels de dommage, d’une comparaison indépendante à la référence. Les lectures intracontexte seraient des diagnostics, jamais les arbitres du dommage.
8. **Duel — HYPOTHÈSE.** Sous condition de lisibilité intracontexte maintenue hors échantillon, \(H_A\) : perte de la lecture fixe supérieure à \(\delta\) ; \(H_B\) : perte au plus égale à \(\delta\). Les bornes de part et d’autre de la marge réfutent respectivement \(H_B\) ou \(H_A\). Si toutes les lectures échouent, l’expérience ne distingue pas défaut de transport et perte d’information.
9. **Parade — HYPOTHÈSE.** Une lecture conditionnelle au contexte, ou une représentation dont la signification est stable, pourrait résister. Coût : davantage de données par contexte et une validation distincte pour les contextes nouveaux.
10. **Manque — HYPOTHÈSE.** Il faudrait des contextes identifiables indépendamment des scores, où les mêmes catégories de dommage soient suffisamment représentées. Sans recouvrement, le contraste mesurerait aussi un changement de tâche.

## Fiche C — Équivalence de preuve

1. **Nom et cible — HYPOTHÈSE.** *Équivalence de preuve*, contre les juges lecteurs. Des épisodes pourraient offrir au juge une preuve citée également authentique et pertinente sur un point local, mais de force différente pour conclure au dommage global.
2. **Propriété exploitée — HYPOTHÈSE.** L’authenticité d’un extrait et sa pertinence locale ne garantissent pas que la conclusion globale en découle. Le mode vise la confusion entre ces propriétés, non une incapacité à retrouver l’extrait.
3. **Invariant de famille — HYPOTHÈSE.** La preuve locale demeure valide ; seule varie la relation entre cette preuve, le reste du dossier et le verdict. Un extrait inventé est hors famille.
4. **Connaissance et prise — HYPOTHÈSE.** Bras informé : connaissance de l’exigence de citation, latitude sur le texte que le juge lira, sans accès à la référence cachée ni au vérificateur.
5. **Nouveauté — HYPOTHÈSE.** Parent proche : attribution correcte mais justification insuffisante. La différence testable avec une omission pure est que **le dossier accessible contient encore de quoi trancher**. Une famille déjà connue sous un autre nom reste plausible ; référence à vérifier.
6. **Exposition — HYPOTHÈSE.** Parmi des dossiers décidables et appariés en difficulté, mesurer la perte de détection lorsque la force probante locale se dissocie de la conclusion. Témoin sans attaque : même validité des citations, mais concordance locale et globale. Contrôle négatif : variation textuelle de difficulté comparable ne changeant pas cette concordance. Battre la seule vérification de présence de l’extrait est nécessaire ; obtenir des extraits authentiques est vrai par construction.
7. **Vérité indépendante — HYPOTHÈSE.** Deux annotations distinctes seraient nécessaires : dommage selon la référence ; suffisance de la preuve selon le dossier effectivement visible. Elles seraient établies sans verdict du lecteur testé. Une information décisive absente du dossier signalerait un défaut d’observabilité, pas une erreur de raisonnement du juge.
8. **Duel — HYPOTHÈSE.** Sur les dossiers indépendamment jugés décidables, \(H_A\) : la perte dépasse \(\delta\) ; \(H_B\) : elle ne le dépasse pas. Une borne inférieure au-dessus de la marge réfute \(H_B\) ; une borne supérieure au plus égale réfute \(H_A\).
9. **Parade — HYPOTHÈSE.** Distinguer dans le verdict « extrait authentique » et « conclusion justifiée par le dossier », avec abstention si la seconde propriété manque. Coût : examen plus long et couverture réduite ; l’abstention doit être comptée séparément.
10. **Manque — HYPOTHÈSE.** Il manque surtout un étalon de suffisance indépendant du lecteur. La seule vérification mécanique de la citation ne peut pas en tenir lieu.

## Fiche D — Concentration des erreurs communes

1. **Nom et cible — HYPOTHÈSE.** *Concentration des erreurs communes*, contre un collège de juges. La fiabilité individuelle de chaque juge resterait comparable, mais les erreurs se concentreraient davantage sur les mêmes épisodes, réduisant la valeur de leur accord.
2. **Propriété exploitée — HYPOTHÈSE.** Le bénéfice attendu de la diversité dépend de la loi conjointe des erreurs conditionnellement au dommage, pas seulement de la diversité nominale des juges.
3. **Invariant de famille — HYPOTHÈSE.** Les taux individuels par classe sont conservés dans la précision de l’étude ; la perte concerne la décision collective. Une baisse uniforme des performances individuelles n’est pas ce mode.
4. **Connaissance et prise — HYPOTHÈSE.** Bras informé : connaissance de l’existence du collège et de sa règle de décision, latitude sur la distribution des dossiers communs. Aucune lecture des votes ni sélection sur leurs scores.
5. **Nouveauté — HYPOTHÈSE.** Parent proche : défaillance de cause commune. La distinction proposée est surtout expérimentale : isoler la perte collective **à performances individuelles constantes**. La distance à la famille connue paraît faible ; référence à vérifier.
6. **Exposition — HYPOTHÈSE.** Mesurer la perte du collège sous sa règle gelée, par rapport au témoin sans attaque, après vérification des taux individuels dans chaque classe. Contrôle négatif : dossiers témoins appariés sur difficulté et composition. Une hausse de coïncidence des erreurs caractérise le contraste ; elle ne prouve pas à elle seule une perte pour la règle collective retenue.
7. **Vérité indépendante — HYPOTHÈSE.** Le registre attesterait le bras ; les dommages seraient déterminés sans aucun membre du collège. La coïncidence des erreurs serait une quantité mesurée après coup contre cet étalon, jamais un critère de sélection des épisodes.
8. **Duel — HYPOTHÈSE.** À performances individuelles conservées, \(H_A\) : perte collective supérieure à \(\delta\) ; \(H_B\) : perte au plus égale à \(\delta\). Une borne inférieure supérieure à la marge réfute \(H_B\) ; une borne supérieure au plus égale réfute \(H_A\). Si les marges individuelles changent sensiblement, une perte collective reste mesurable mais son attribution échoue.
9. **Parade — HYPOTHÈSE.** Exiger qu’un accord apporte une information supplémentaire validée hors échantillon, ou adjoindre une preuve de nature indépendante. Coûts : annotations conjointes, contrôles supplémentaires et abstentions.
10. **Manque — HYPOTHÈSE.** Une règle collective effectivement spécifiée et suffisamment de verdicts conjoints sur les mêmes épisodes. L’hétérogénéité des juges est **VÉRIFIÉE** dans le programme ; une règle d’agrégation particulière ne l’est pas.

### Instruments et ancrage matériel

**HYPOTHÈSE — mesure minimale par instrument.**

| Instrument | Comparaison minimale, en plus des taux de détection et de fausses alertes sur les cas appariés |
|---|---|
| Sonde linéaire, différence de moyennes, petit perceptron, attention, Mahalanobis | Pour **chacune**, battre sur témoin une sonde aléatoire appariée ainsi qu’un indicateur mécanique de longueur. Évaluer le transport du repère séparément. Pour la dépendance des extrêmes, ne pas attribuer à l’attention une propriété du maximum : son résultat est un contraste de transfert. |
| Moniteur textuel par action | Battre un contrôle de longueur et de présence d’indices textuels déclarés. Si le dommage n’est défini qu’au niveau de l’épisode, rapporter la détection par épisode sous une agrégation déclarée ; ne pas étiqueter chaque action comme dommageable. |
| Moniteur textuel à état | Battre les mêmes contrôles et une lecture sans historique sur les mêmes épisodes ; apparier aussi la longueur d’historique. |
| Lecteur avec référence cachée | Battre la vérification mécanique de présence de l’extrait et, sur les tâches qui le permettent, comparer au contrôle mécanique du produit final. Si ce contrôle décide exactement le dommage, c’est un étalon, pas un concurrent à battre. |
| Juges hétérogènes et collège | Rapporter les taux de chaque juge, du collège gelé et d’un juge individuel choisi avant l’épreuve. Comparer aussi aux vérifications mécaniques applicables au dossier ; un accord unanime n’est pas un label de vérité. |

**HYPOTHÈSE — faisabilité et budget illustratifs.** Des modèles à poids ouverts des familles Qwen et Mistral seraient des candidats pour l’agent et les lecteurs, sous réserve de vérifier les licences, l’accès aux activations et la compatibilité avec les tâches. Le poste de calcul à estimer séparément est la lecture répétée des mêmes dossiers par les juges ; les sondes peuvent partager les activations d’un épisode. À titre **illustratif**, une enveloppe pilote de **100 heures-GPU à 3 € par heure-GPU, soit 300 € de calcul**, exclut stockage et adjudication. Ce n’est pas une estimation du coût d’un test décisif : sans débit mesuré, fréquence du dommage et précision exigée autour de \(\delta\), ce coût reste indéterminé.

### (a) Ce que la question suppose sans que ce soit établi

- **HYPOTHÈSE :** chaque contraste est réalisable dans un bras scellé sans consulter les scores. Une différence définissable entre deux lois ne démontre pas que l’agent peut la produire.
- **HYPOTHÈSE :** le dommage peut être établi indépendamment et le dossier visible suffit aux instruments auxquels on demande de le détecter. Ces deux conditions sont distinctes.
- **HYPOTHÈSE :** chaque instrument est assez performant sur le témoin pour qu’une perte soit identifiable. À défaut, l’étude établit une faiblesse de base, pas une résistance.
- **HYPOTHÈSE :** au moins une famille est historiquement inédite. Ni une signature statistique distinctive ni une expérience positive ne trancherait la question bibliographique.

### (b) Classements séparés

- **HYPOTHÈSE — distance aux familles connues, décroissante :** dépendance des extrêmes ; équivalence de preuve ; défaut de transport du repère ; concentration des erreurs communes. Le premier rang tient à la signature particulière « marges locales stables, décision extrême instable », non à une revendication de nouveauté en statistique.
- **HYPOTHÈSE — solidité de la mesure, décroissante :** concentration des erreurs communes ; défaut de transport du repère ; équivalence de preuve ; dépendance des extrêmes. Les verdicts conjoints rendent le premier contraste directement observable si le dommage est connu ; le dernier exige de distinguer une modification de dépendance d’un déplacement marginal rare, précisément là où l’appariement est le plus difficile à valider.

FIN-DE-CELLULE