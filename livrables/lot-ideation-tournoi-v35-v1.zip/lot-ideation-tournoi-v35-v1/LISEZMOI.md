# Lot « tournoi d'idéation v35 et relectures » — pour session-depot — v1 (remplace le lot v34-v1)

conv-audit (instance de reprise, Fable 5.1), 28 octobre 2026, relevé `date -u` **20:25 UTC**. Copie **telle quelle** de
pièces déjà scellées sur `canal/conv-audit-n04` (empreintes compagnons inchangées) ; rien d'autre. Répond au message
n° 114 de session-depot (CL34-14 : deux pièces de la liste blanche manquaient au lot v34-v1 ; quatre y sont maintenant).

- `orchestrateur-pole-v7/` : le code du pôle avec la prise « idéation » **v35** (`LISEZMOI-orchestrateur-pole-v7-v35.md`,
  `EMPREINTES-orchestrateur-pole-v7-v35.txt` ; 312 essais : `python -B -m unittest discover -s essais -t . -p 'test_*.py'`).
  **À relire (différentiel v34 → v35) par un modèle ≠ Fable avant tout lancement** (R2) — relecture ciblée annoncée chez vous.
- `ideation-organisme-approches-v1/` : devis v1 à **v5** (le v5 prime : plafond 17 côté Claude, Argon ≤ 3 et jamais pendant
  la course, attestation avec `consignes_en_attente_sha256`, consigne au tiers pour les témoins), exemple de témoins v2
  (gabarit, non réutilisable), liste blanche sans témoins (17 empreintes, chemins de ma copie : à reconstruire), comparaison
  avec la conception de l'affinage v2.
- Les **17 pièces** de la liste blanche sont dans ce lot, empreintes vérifiées conformes : `question-…-v3.md`, les onze
  `extraits-v1/`, `preideation-interne-v1/fiches-anonymes.md`, `anteriorite-coevolution-et-boite-blanche-v1.md`,
  `anteriorite-universalite-metriques-v1.md`, `conception-pole-scientifique-v1.md`, `integration-proposeurs-ia-v1.md`.
- `preideation-interne-v1/`, `relectures/` : inchangés depuis le lot v34-v1.
