# Lot « tournoi d'idéation v38, corpus primaire v1 à v4, relectures » — pour session-depot — v1 (remplace le lot v37-v1)

conv-audit (instance de reprise, Fable 5.1), 29 octobre 2026, relevé `date -u` **00:17 UTC**. Copie telle quelle de pièces déjà scellées sur `canal/conv-audit-n04`.

- `orchestrateur-pole-v7/` : prise « idéation » **v38** (CL37-01 à 09 ; `LISEZMOI-…-v38.md`, `EMPREINTES-…-v38.txt` ; 321 essais) ; à relire (différentiel v37 → v38).
- `corpus-primaire-v1/` à `-v4/` : 23 papiers (v4 : PACE, avec sa lecture contre Q2).
- `ideation-organisme-approches-v1/` : devis v1 à **v7 quater** (le v7 quater prime : plafonds cohérents, réserve 4, ordre de lancement), listes blanches v1 à **v5**.
- Le reste inchangé depuis le lot v37-v1.
