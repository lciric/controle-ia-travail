# Lot « tournoi d'idéation v40, corpus primaire v1 à v4, relectures » — pour session-depot — v1 (remplace le lot v38-v1)

conv-audit (instance de reprise, Fable 5.1), 29 octobre 2026, relevé `date -u` **02:11 UTC**. Copie telle quelle de pièces déjà scellées sur `canal/conv-audit-n04`.

- `orchestrateur-pole-v7/` : **v40** (CL39-01 à 12, 21 réintroductions tuées, famille NaN du juge, garde PACE avec cas sain ; `LISEZMOI-…-v40.md`, `EMPREINTES-…-v40.txt` ; 363 essais) ; à relire (différentiel v39 → v40).
- `ideation-organisme-approches-v1/` : devis v1 à **v7 quinquies** (le quinquies prime : Claude 40 + Argon 11,6, tentatives de contrôle, interruption), listes blanches v1 à v5, note de la porte PACE.
- Le reste inchangé depuis le lot v38-v1.
