"""Essais de la version 35 (depuis la 32) : la course d'idéation (prise « idéation » : proposer et classer seulement).

Cas sains : fiche au gabarit validée et empreintée ; liste blanche par empreinte acceptée ; anonymisation par juge
(permutations différentes, clé hors des fiches servies, aucune empreinte servie) ; notes complètes agrégées (moyenne
nommée à deux juges, porte fixée d'avance, porte « unanimité », départage par empreinte) ; course entière avec faux
adaptateur : manifeste de départ scellé avant le premier appel, témoins lus à part, classement lisible, lectures par juge ;
seconde passe qui ajoute (ne remplace pas) et sert le matériau après ; appel de contrôle conforme.
Artefacts (R5) : champ hors gabarit, énumération hors valeurs, bloc JSON absent, liste vide, fiches en trop, note hors
borne, note manquante, pièce hors liste blanche ou à empreinte différente, lien symbolique, variantes de chemin (accents,
`_`, « données »), paraphrases devant la garde, secret caviardé, session en erreur (arrêt dur, code d'erreur), juge
invalide (arrêt), plafond total, appel de contrôle refusé (statut, texte, coût, relais muet), url du relais en https ou
avec chemin, étiquettes invalides, absence de témoins, max_tours trop grand — tous refusés avec un motif.
v35 (CL34) : attestation donnée à la course refusée ; bras différé seul chemin (attestation sans l'empreinte de la consigne
refusée, sceau faux refusé, rejeu refusé, plafond total tenu, témoins lus chez le juge externe, manifeste sur tous les
chemins) ; coût manquant du juge externe → erreur ; environnement minimal de la commande ; `tools=[]` dans les options et
`--tools ''` sur la ligne de commande du kit ; borne de temps par session ; `nombre` borné ; contrôles comptés ; manifeste de
fin sur toute exception ; pluriels devant la garde.
"""

import json
import os
import re
import sys
import unittest

from essais.aides import CasAvecDossier
from pole import ideation as idn
from pole.adaptateurs import Resultat, construire_options
from pole.relais import RelaisInvalide


def fiche_brute(**modifs):
    f = {"nom": "Essai", "type": "question",
         "enonce": "Le transfert d'un moniteur vers le diffus suit-il une courbe prédite avant le test ?",
         "loi_predictive": {"espace_instances": "familles × dilution, dix familles", "prediction": "rappel décroît",
                            "signe": "-", "metrique": "rappel à 1 % de fausses alertes"},
         "perte_traduction": "la forme est résumée par une pente",
         "questions_servies": ["Q4", "Q3"],
         "avantage": {"source": "programme", "texte": "théorie explicite", "incopiable_parce_que": "exige la carte"},
         "originalite": {"niveau": "transposition", "texte": "détection de rupture"},
         "demande_organisme": {"nature": "ajout", "texte": "générateur de dilution"},
         "cout": {"nature": "processeur", "ordre_de_grandeur": "jours"},
         "piege": "artefact de découpe", "cosmetique_si": "courbes plates",
         "anteriorite": [{"reference": "Ramtin, Nain, Towsley 2601.20022", "statut": "RAPPORTE"}]}
    for cle, valeur in modifs.items():
        if isinstance(valeur, dict) and isinstance(f.get(cle), dict):
            f[cle] = dict(f[cle], **valeur)
        else:
            f[cle] = valeur
    return f


def notes_pour(identifiants, base=2, **sur):
    notes = []
    for i in identifiants:
        c = {k: base for k in idn.CRITERES}
        c.update(sur.get(i, {}))
        notes.append({"identifiant": i, "criteres": c, "justifications": {k: "ligne" for k in idn.CRITERES}})
    return {"notes": notes, "doublons": []}


class FauxAdaptateur:
    """Rend des fiches pour un proposeur, des notes pour un juge, « OK » pour l'appel de contrôle ; coût fixe ; peut
    simuler une erreur ou des notes données par une fonction (identifiants → objet)."""
    nom = "faux-ideation"

    def __init__(self, fiches_par_etiquette, notes_par_juge=None, cout=0.5, notes_base=2, erreur_pour=(),
                 texte_controle="OK", cout_controle=0.01, statut_controle="ok"):
        self.fiches = fiches_par_etiquette
        self.notes = notes_par_juge or {}
        self.cout, self.notes_base = cout, notes_base
        self.erreur_pour = set(erreur_pour)
        self.texte_controle, self.cout_controle, self.statut_controle = texte_controle, cout_controle, statut_controle
        self.appels = []

    def lancer(self, role, consigne, dossier, budget_usd, max_tours, modele=None):
        self.appels.append({"role": role, "consigne": consigne, "dossier": dossier, "modele": modele,
                            "budget": budget_usd, "max_tours": max_tours})
        if consigne == idn.APPEL_DE_CONTROLE_CONSIGNE:
            return Resultat(self.texte_controle, [], self.cout_controle, self.statut_controle)
        etiquette = os.path.basename(os.path.dirname(dossier)) if role == "proposeur_ideation" else os.path.basename(dossier)
        passe = os.path.basename(dossier)
        if (etiquette, passe) in self.erreur_pour or etiquette in self.erreur_pour:
            return Resultat("API Error: 400 Bad request version", [], 0.0, "erreur", "APIError")
        if role == "proposeur_ideation":
            fiches = self.fiches[etiquette]
            if callable(fiches):
                fiches = fiches(passe, consigne)
            elif passe == "passe-2":
                fiches = [dict(f, nom=f["nom"] + " (revue)") for f in fiches]
            texte = "Voici.\n```json\n" + json.dumps({"fiches": fiches}, ensure_ascii=False) + "\n```"
            return Resultat(texte, [], self.cout, "ok")
        if role == "juge_ideation":
            idents = sorted(set(re.findall(r'"identifiant": "(T\d\d)"', consigne)))
            objet = self.notes.get(etiquette)
            if callable(objet):
                objet = objet(idents, consigne)
            if objet is None:
                objet = notes_pour(idents, base=self.notes_base)
            return Resultat("```json\n" + json.dumps(objet) + "\n```", [], self.cout, "ok")
        raise AssertionError(role)


class TestFiche(unittest.TestCase):
    def test_fiche_valide_et_empreinte_stable(self):
        a = idn.valider_fiche_ideation(fiche_brute(), "a", 1)
        b = idn.valider_fiche_ideation(fiche_brute(), "b", 7, passe=2)
        self.assertEqual(a["empreinte"], b["empreinte"])
        self.assertEqual(a["identifiant_auteur"], "a-p1-01")
        self.assertEqual(b["identifiant_auteur"], "b-p2-07")
        self.assertNotIn("empreinte", idn.vue_servie(a))
        self.assertNotIn("auteur", idn.vue_servie(a))

    def test_artefacts_refuses_avec_motif(self):
        cas = {"champ hors gabarit": fiche_brute(extra="x"), "type hors valeurs": fiche_brute(type="idee"),
               "signe hors valeurs": fiche_brute(loi_predictive={"signe": "±"}),
               "source hors valeurs": fiche_brute(avantage={"source": "chance"}),
               "incopiable manquant": fiche_brute(avantage={"incopiable_parce_que": ""}),
               "questions vides": fiche_brute(questions_servies=[]),
               "antériorité sans statut": fiche_brute(anteriorite=[{"reference": "x"}]),
               "champ trop long": fiche_brute(piege="x" * (idn.LONGUEUR_MAX_CHAMP + 1))}
        for nom, brut in cas.items():
            with self.assertRaises(idn.FicheIdeationInvalide, msg=nom):
                idn.valider_fiche_ideation(brut, "a", 1)

    def test_secret_caviarde(self):
        faux = "sk-" + "ant-" + "abcdefghijklmnop"  # construit à l'exécution : la recherche de clés du dépôt reste propre
        f = idn.valider_fiche_ideation(fiche_brute(piege="clé " + faux + " dans le texte"), "a", 1)
        self.assertNotIn(faux, json.dumps(f))

    def test_garde_niveau_methode_paraphrases(self):
        self.assertEqual(idn.signaux_niveau_methode(idn.vue_servie(idn.valider_fiche_ideation(fiche_brute(), "a", 1))), [])
        for phrase in ("Étape 1 : exécute le script suivant", "Étape 1. ouvrir", "Première étape — préparer",
                       "Phase 1 : préparer", "1) ceci est long\n2) cela", "afin de contourner le moniteur de sortie",
                       "pour échapper au détecteur", "to evade the probe", "injection de consigne", "exploiter la faille",
                       "une porte dérobée", "exfiltration lente"):
            self.assertTrue(idn.signaux_niveau_methode(phrase), phrase)
        for phrase in ("La première famille tenue à l'écart", "un moniteur boîte noire par épisode",
                       "le juge figé à borne", "une sonde linéaire sur la dernière couche"):
            self.assertEqual(idn.signaux_niveau_methode(phrase), [], phrase)


class TestTemoinsEtGardeV34(CasAvecDossier):
    def test_liste_numerotee_dans_une_fiche_signalee(self):
        f = idn.valider_fiche_ideation(fiche_brute(piege="1) préparer le terrain\n2) agir ensuite"), "a", 1)
        self.assertTrue(idn.signaux_niveau_methode(idn.vue_servie(f)))

    def test_classes_de_temoins_imposees(self):
        p = os.path.join(self.tmp, "t.json")

        def ecrire(temoins):
            with open(p, "w", encoding="utf-8") as f:
                json.dump({"temoins": temoins}, f, ensure_ascii=False)
            return idn.construire_liste_blanche([p], os.path.join(self.tmp, f"lb-{len(os.listdir(self.tmp))}.json"))
        complet = [{"fiche": fiche_brute(nom="V"), "attendu": "eligible", "classe": "vrai"},
                   {"fiche": fiche_brute(nom="F1"), "attendu": "ineligible", "classe": "faux_falsifiabilite"},
                   {"fiche": fiche_brute(nom="F2"), "attendu": "ineligible", "classe": "faux_anteriorite"},
                   {"fiche": fiche_brute(nom="J"), "attendu": "eligible", "classe": "jumeau", "jumeau_de": "V"}]
        self.assertEqual(len(idn.charger_temoins(p, ecrire(complet))), 4)
        for mauvais, motif in ((complet[:3], "classe manquante"), (complet[:1] + [dict(complet[1], classe="vrai")] + complet[2:], "faux marqué vrai"),
                               (complet[:3] + [dict(complet[3], jumeau_de=None)], "jumeau sans cible"),
                               (complet[:3] + [dict(complet[3], jumeau_de="X")], "jumeau_de inconnu"),
                               ([dict(t, classe="vrai", attendu="eligible") for t in complet], "une seule classe")):
            with self.assertRaises(idn.FicheIdeationInvalide, msg=motif):
                idn.charger_temoins(p, ecrire(mauvais))


class TestPieces(CasAvecDossier):
    def ecrire(self, nom, contenu="x"):
        chemin = os.path.join(self.tmp, nom)
        os.makedirs(os.path.dirname(chemin), exist_ok=True)
        with open(chemin, "w", encoding="utf-8") as f:
            f.write(contenu)
        return chemin

    def test_liste_blanche_acceptee_et_variantes_refusees(self):
        p = self.ecrire("piece-a.md", "# A")
        liste = idn.construire_liste_blanche([p], os.path.join(self.tmp, "lb.json"))
        self.assertEqual(idn.verifier_pieces([p], liste), [os.path.realpath(p)])
        for nom in ("donnees/banque.json", "x/mode-tenu-a-l-ecart-v1.md", "x/bras_attaque/a.md", "x/bras-d-attaque/a.md",
                    "données/a.md", "x/mode_tenu_à_l_écart/a.md", "docs/carte-hypotheses-v1.md", "x/banques/a.md",
                    "x/banque_v3.json", "prereg/P3-consignes-v1.md"):
            c = self.ecrire(nom)
            liste2 = dict(liste, **{os.path.realpath(c): idn.sha256_fichier(c)})
            with self.assertRaises(idn.PieceInterdite, msg=nom):
                idn.verifier_pieces([c], liste2)

    def test_hors_liste_empreinte_differente_lien(self):
        p = self.ecrire("piece-b.md", "# B")
        with self.assertRaises(idn.PieceInterdite):
            idn.verifier_pieces([p], {})
        with self.assertRaises(idn.PieceInterdite):
            idn.verifier_pieces([p], {os.path.realpath(p): "0" * 64})
        liste = idn.construire_liste_blanche([p], os.path.join(self.tmp, "lb2.json"))
        with open(p, "a") as f:
            f.write("modifié")
        with self.assertRaises(idn.PieceInterdite):
            idn.verifier_pieces([p], liste)
        lien = os.path.join(self.tmp, "lien.md")
        os.symlink(p, lien)
        liste3 = idn.construire_liste_blanche([p], os.path.join(self.tmp, "lb3.json"))
        with self.assertRaises(idn.PieceInterdite):
            idn.verifier_pieces([lien], dict(liste3, **{os.path.realpath(lien): liste3[os.path.realpath(p)]}))

    def test_url_relais_ideation(self):
        self.assertEqual(idn.valider_url_relais_ideation("http://127.0.0.1:8787"), "http://127.0.0.1:8787")
        for url in ("https://127.0.0.1:8787", "http://127.0.0.1:8787/v1", "http://relais.exemple.org", "http://127.0.0.1:1?x=1"):
            with self.assertRaises(RelaisInvalide, msg=url):
                idn.valider_url_relais_ideation(url)


class TestAnonymisationEtNotes(unittest.TestCase):
    def setUp(self):
        self.fiches = [idn.valider_fiche_ideation(fiche_brute(nom=f"F{i}"), "a" if i < 3 else "b", i) for i in range(1, 7)]

    def test_anonymisation_par_juge(self):
        a1, cle1 = idn.anonymiser(self.fiches, 1, "juge-1")
        a2, cle2 = idn.anonymiser(self.fiches, 1, "juge-2")
        self.assertEqual(sorted(cle1.values()), sorted(f["identifiant_auteur"] for f in self.fiches))
        self.assertNotEqual([a["nom"] for a in a1], [a["nom"] for a in a2])
        for a in a1:
            for champ in idn.CHAMPS_INTERNES:
                self.assertNotIn(champ, a)
        encore, _ = idn.anonymiser(self.fiches, 1, "juge-1")
        self.assertEqual([a["nom"] for a in a1], [a["nom"] for a in encore])

    def test_notes_valides_et_artefacts(self):
        idents = ["T01", "T02"]
        notes, doubles = idn.valider_notes(notes_pour(idents), idents)
        self.assertEqual(set(notes), set(idents))
        with self.assertRaises(idn.NotesInvalides):
            idn.valider_notes(notes_pour(["T01"]), idents)
        trop = notes_pour(idents)
        trop["notes"][0]["criteres"]["avantage"] = 4
        with self.assertRaises(idn.NotesInvalides):
            idn.valider_notes(trop, idents)
        with self.assertRaises(idn.NotesInvalides):
            idn.valider_notes(notes_pour(idents + ["T99"]), idents)
        booleen = notes_pour(idents)
        booleen["notes"][1]["criteres"]["robustesse"] = True
        with self.assertRaises(idn.NotesInvalides):
            idn.valider_notes(booleen, idents)
        demi = notes_pour(idents)
        demi["notes"][0]["criteres"]["avantage"] = 2.5
        with self.assertRaises(idn.NotesInvalides):
            idn.valider_notes(demi, idents)

    def test_agregation_nommee_porte_unanimite_departage(self):
        par = {f["identifiant_auteur"]: f for f in self.fiches}
        ids = list(par)
        j1 = {i: {"criteres": {k: 1 for k in idn.CRITERES}} for i in ids}
        j2 = {i: {"criteres": {k: 1 for k in idn.CRITERES}} for i in ids}
        j1[ids[0]]["criteres"]["avantage"] = 3  # un seul juge élève : moyenne 2 → éligible, unanimité fausse
        j1[ids[1]]["criteres"]["originalite"] = 3
        j2[ids[1]]["criteres"]["originalite"] = 3  # unanimité vraie
        cl = idn.agreger({"j1": j1, "j2": j2}, par)
        parl = {l["identifiant_auteur"]: l for l in cl}
        self.assertEqual(parl[ids[0]]["nom_agregat"], "moyenne")
        self.assertTrue(parl[ids[0]]["eligible"])
        self.assertFalse(parl[ids[0]]["eligible_unanimite"])
        self.assertTrue(parl[ids[1]]["eligible_unanimite"])
        self.assertEqual([l["identifiant_auteur"] for l in cl][:2], [ids[1], ids[0]])  # totaux 7 puis 6
        # les quatre autres fiches sont à égalité stricte (1 partout, inéligibles) : départage par empreinte, déterministe
        reste = [l["identifiant_auteur"] for l in cl][2:]
        self.assertEqual(reste, sorted(reste, key=lambda i: par[i]["empreinte"]))
        trois = idn.agreger({"j1": j1, "j2": j2, "j3": j2}, par)
        self.assertEqual(trois[0]["nom_agregat"], "mediane")


class TestCourse(CasAvecDossier):
    def preparer(self, temoins_json=None):
        p = os.path.join(self.tmp, "piece-a.md")
        with open(p, "w", encoding="utf-8") as f:
            f.write("# Pièce A\nTexte de contexte.")
        q = os.path.join(self.tmp, "question.md")
        with open(q, "w", encoding="utf-8") as f:
            f.write("Quelles questions ?")
        m = os.path.join(self.tmp, "materiau.md")
        with open(m, "w", encoding="utf-8") as f:
            f.write("# Matériau\nTour interne.")
        t = os.path.join(self.tmp, "temoins.json")
        with open(t, "w", encoding="utf-8") as f:
            json.dump(temoins_json or {"temoins": [
                {"fiche": fiche_brute(nom="Sobre fort"), "attendu": "eligible", "classe": "vrai"},
                {"fiche": fiche_brute(nom="Verbeux vide", enonce="Long " * 50), "attendu": "ineligible",
                 "note_max": {"falsifiabilite": 1}, "classe": "faux_falsifiabilite"},
                {"fiche": fiche_brute(nom="Assuré occupé", originalite={"niveau": "inedite", "texte": "jamais vu"}),
                 "attendu": "ineligible", "note_max": {"originalite": 1}, "classe": "faux_anteriorite"},
                {"fiche": fiche_brute(nom="Jumeau"), "attendu": "eligible", "jumeau_de": "Sobre fort", "classe": "jumeau"}]},
                f, ensure_ascii=False)
        lb = os.path.join(self.tmp, "liste-blanche.json")
        idn.construire_liste_blanche([p, q, m, t], lb)
        return dict(liste_blanche=lb, question=q, pieces=[p], materiau=[m], temoins=t)

    def budgets(self):
        return {("proposeur_ideation", "claude-opus-5-5"): 1.0, ("proposeur_ideation", "claude-fable-5-1"): 1.0,
                ("juge_ideation", "claude-opus-5-5"): 1.0, ("juge_ideation", "claude-fable-5-1"): 1.0}

    def lancer(self, ad, sortie, **modifs):
        if not hasattr(self, "_prep"):
            self._prep = self.preparer()  # la liste blanche est scellée une fois par essai (jamais écrasée)
        args = dict(self._prep, proposeurs=[("opus", "claude-opus-5-5"), ("fable", "claude-fable-5-1")],
                    juges=[("juge-fable", "claude-fable-5-1"), ("juge-opus", "claude-opus-5-5")], graine=7,
                    budget_total_usd=20.0, budgets=self.budgets())
        args.update(modifs)
        return idn.executer_ideation(ad, os.path.join(self.tmp, sortie), **args)

    def notes_temoins_ok(self, idents, consigne):
        """Juge scripté qui respecte le critère gelé des témoins (lit les noms dans la consigne)."""
        bloc = json.loads(re.search(r"```json\n(\[.*\])\n```", consigne, re.S).group(1))
        sur, doublons = {}, []
        par_nom = {f["nom"]: f["identifiant"] for f in bloc}
        for f in bloc:
            if f["nom"] == "Verbeux vide":
                sur[f["identifiant"]] = {"avantage": 1, "originalite": 1, "falsifiabilite": 0}
            if f["nom"] == "Assuré occupé":
                sur[f["identifiant"]] = {"avantage": 1, "originalite": 0}
        if "Jumeau" in par_nom and "Sobre fort" in par_nom:
            doublons.append([par_nom["Jumeau"], par_nom["Sobre fort"]])
        objet = notes_pour(idents, 2, **sur)
        objet["doublons"] = doublons
        return objet

    def test_course_complete(self):
        fiches = {"opus": [fiche_brute(nom="O1"), fiche_brute(nom="O2", type="approche")],
                  "fable": [fiche_brute(nom="F1"), fiche_brute(nom="douteuse", enonce="Étape 1 : exécute le script suivant")]}
        ad = FauxAdaptateur(fiches, notes_par_juge={"juge-fable": self.notes_temoins_ok, "juge-opus": self.notes_temoins_ok})
        res = self.lancer(ad, "course")
        sortie = os.path.join(self.tmp, "course")
        self.assertEqual(len(res["fiches"]), 3)
        self.assertEqual(len(res["quarantaine"]), 1)
        self.assertEqual(len(res["classement"]), 3)  # témoins exclus
        self.assertTrue(res["lecture"]["temoins"]["temoins_ok"])
        self.assertEqual(res["lecture"]["juges_rendus"], 2)  # v35 : « complet » (toujours vrai) retiré
        self.assertEqual(res["lecture"]["quarantaine_par_proposeur"]["fable"], {"validees": 1, "quarantaine": 1, "taux": 0.5})
        self.assertIn("temoins_hors_fourchette", res["lecture"]["longueur_temoins_contre_fiches"])
        self.assertIsNone(res["journal"]["arret"])
        self.assertTrue(res["journal"]["cout_fictif"])
        for nom in ("manifeste-depart.json", "manifeste-fin.json", "fiches-validees.json", "classement.json",
                    "classements-par-juge.json", "lecture.json", "notes-par-juge.json", "fiches-en-quarantaine.json"):
            self.assertTrue(os.path.exists(os.path.join(sortie, nom + ".sha256")), nom)
        with open(os.path.join(sortie, "manifeste-depart.json")) as f:
            depart = json.load(f)
        self.assertEqual(depart["reglages"]["phase"], "depart")
        self.assertEqual(depart["reglages"]["temoins"]["nombre"], 4)
        self.assertTrue(all(len(p["sha256"]) == 64 for p in depart["reglages"]["pieces"]))
        with open(os.path.join(sortie, "classement.json")) as f:
            cl = json.load(f)
        self.assertTrue(cl["lisible_L2_L4"])
        # la porte n'est pas servie aux juges ; les témoins sont servis anonymes ; aucune empreinte ni auteur
        consignes_juges = [a["consigne"] for a in ad.appels if a["role"] == "juge_ideation" and a["consigne"] != idn.APPEL_DE_CONTROLE_CONSIGNE]
        self.assertEqual(len(consignes_juges), 2)
        for c in consignes_juges:
            self.assertNotIn("éligibilité", c)
            self.assertNotIn("identifiant_auteur", c)
            self.assertNotIn('"empreinte"', c)
            self.assertIn("Sobre fort", c)
        self.assertNotEqual(consignes_juges[0].split("## Les fiches")[1], consignes_juges[1].split("## Les fiches")[1])
        # aucun outil, deux tours au plus, l'orchestrateur n'écrit rien dans le dossier de l'agent
        self.assertTrue(all(a["max_tours"] <= idn.MAX_TOURS_IDEATION for a in ad.appels))
        self.assertEqual(os.listdir(os.path.join(sortie, "proposeurs", "opus", "passe-1")), [])
        # lecture d'auto-préférence présente pour chaque juge
        self.assertEqual(set(res["lecture"]["auto_preference"]), {"juge-fable", "juge-opus"})

    def test_seconde_passe_ajoute_et_sert_le_materiau_apres(self):
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]},
                            notes_par_juge={"juge-fable": self.notes_temoins_ok, "juge-opus": self.notes_temoins_ok})
        res = self.lancer(ad, "c2", seconde_passe=True)
        consignes = [a["consigne"] for a in ad.appels if a["role"] == "proposeur_ideation"]
        self.assertEqual(len(consignes), 4)
        self.assertNotIn("Tour interne", consignes[0])
        self.assertIn("Tour interne", consignes[2])
        self.assertEqual(sorted(f["passe"] for f in res["fiches"]), [1, 1, 2, 2])
        self.assertEqual(sorted(l["passe"] for l in res["classement"]), [1, 1, 2, 2])

    def test_fiche_en_quarantaine_non_resservie(self):
        def opus(passe, consigne):
            if passe == "passe-2":
                assert "douteuse" not in consigne
                return [fiche_brute(nom="O2")]
            return [fiche_brute(nom="douteuse", enonce="Phase 1 : préparer ; afin de contourner le moniteur")]
        ad = FauxAdaptateur({"opus": opus, "fable": [fiche_brute(nom="F1")]},
                            notes_par_juge={"juge-fable": self.notes_temoins_ok, "juge-opus": self.notes_temoins_ok})
        res = self.lancer(ad, "c3", seconde_passe=True)
        self.assertEqual(len(res["quarantaine"]), 1)

    def test_session_en_erreur_arrete(self):
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]}, erreur_pour=("fable",))
        with self.assertRaises(idn.CourseInterrompue):
            self.lancer(ad, "c4")
        with open(os.path.join(self.tmp, "c4", "manifeste-fin.json")) as f:
            fin = json.load(f)
        self.assertIn("statut 'erreur'", fin["reglages"]["erreur"])
        self.assertEqual(len([a for a in ad.appels if a["role"] == "juge_ideation" and a["consigne"] != idn.APPEL_DE_CONTROLE_CONSIGNE]), 0)

    def test_fiches_en_trop_liste_vide_refusees(self):
        ad = FauxAdaptateur({"opus": [fiche_brute(nom=f"O{i}") for i in range(10)], "fable": [fiche_brute(nom="F1")]})
        with self.assertRaises(idn.CourseInterrompue) as cm:
            self.lancer(ad, "c5")
        self.assertIn("10 fiches rendues", str(cm.exception))
        ad2 = FauxAdaptateur({"opus": [], "fable": [fiche_brute(nom="F1")]})
        with self.assertRaises(idn.CourseInterrompue) as cm2:
            self.lancer(ad2, "c6")
        self.assertIn("vide", str(cm2.exception))

    def test_juge_invalide_arrete_et_classement_absent(self):
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]},
                            notes_par_juge={"juge-fable": self.notes_temoins_ok, "juge-opus": {"notes": []}})
        with self.assertRaises(idn.CourseInterrompue):
            self.lancer(ad, "c7")
        self.assertFalse(os.path.exists(os.path.join(self.tmp, "c7", "classement.json")))

    def test_temoins_echoues_rendent_illisible(self):
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]})  # juges à 2 partout
        res = self.lancer(ad, "c8")
        self.assertFalse(res["lecture"]["temoins"]["temoins_ok"])
        with open(os.path.join(self.tmp, "c8", "classement.json")) as f:
            self.assertFalse(json.load(f)["lisible_L2_L4"])

    def test_plafond_total_arrete_avant_depense(self):
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]}, cout=1.0)
        with self.assertRaises(idn.CourseInterrompue):  # v38 (CL37-03) : somme des plafonds 4 > 1,5 → refus avant tout appel
            self.lancer(ad, "c9a", budget_total_usd=1.5)
        self.assertEqual(ad.appels, [])
        with self.assertRaises(idn.CourseInterrompue):  # tolérée : arrêt au premier dépassement, avant la dépense
            self.lancer(ad, "c9", budget_total_usd=1.5, tolerer_somme_plafonds=True)
        self.assertLessEqual(ad.appels[-1]["budget"], 1.0)

    def test_reglages_refuses(self):
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1")]})
        with self.assertRaises(idn.CourseInterrompue):
            self.lancer(ad, "c10", temoins=None)
        with self.assertRaises(idn.CourseInterrompue):
            self.lancer(ad, "c11", juges=[("Juge Opus", "claude-opus-5-5")])
        with self.assertRaises(idn.CourseInterrompue):
            self.lancer(ad, "c12", max_tours=6)
        with self.assertRaises(idn.CourseInterrompue):
            self.lancer(ad, "c13", budgets={})

    def test_appel_de_controle(self):
        sortie = os.path.join(self.tmp, "ctrl")
        etat = {"appels": 0, "depense_usd": 0.0}

        def relais():
            return dict(etat)
        ad = FauxAdaptateur({})
        orig = ad.lancer

        def lancer_compte(*a, **k):
            r = orig(*a, **k)
            etat["appels"] += 1
            etat["depense_usd"] += 0.01
            return r
        ad.lancer = lancer_compte
        lecture = idn.appel_de_controle(ad, ["claude-opus-5-5"], sortie, 0.1, relais)
        self.assertEqual(lecture["claude-opus-5-5"]["problemes"], [])
        for mauvais in (dict(texte_controle="Bonjour"), dict(statut_controle="erreur"), dict(cout_controle=0.0)):
            with self.assertRaises(idn.CourseInterrompue):
                idn.appel_de_controle(FauxAdaptateur({}, **mauvais), ["claude-opus-5-5"], sortie, 0.1, None)
        with self.assertRaises(idn.CourseInterrompue):  # relais muet
            idn.appel_de_controle(FauxAdaptateur({}), ["claude-fable-5-1"], sortie, 0.1, lambda: {"appels": 0, "depense_usd": 0.0})

    def test_options_sans_outil_pour_les_roles_ideation(self):
        dossier = os.path.join(self.tmp, "course", "proposeurs", "opus", "passe-1")
        os.makedirs(dossier)
        for role in ("proposeur_ideation", "juge_ideation"):
            o = construire_options(dossier, 1.0, 2, url_relais="http://127.0.0.1:8787", modele="claude-opus-5-5",
                                   role=role, interdire_lecture=[os.path.join(self.tmp, "course")])
            self.assertEqual(o["allowed_tools"], [])
            self.assertEqual(o["max_turns"], 2)


class TestCommandeExterne(CasAvecDossier):
    """v33 → v36 : juge d'une autre lignée (Argon) par commande externe ; v36 : à poids égal et proposeur à égalité."""

    def commande(self, script, nom="juge.py"):
        chemin = os.path.join(self.tmp, nom)
        with open(chemin, "w", encoding="utf-8") as f:
            f.write(script)
        return [sys.executable, "-I", chemin]

    FICHE = json.dumps(fiche_brute(nom="Argon A"), ensure_ascii=False)
    SCRIPT_OK = (
        "import sys, json, re\n"
        "consigne = sys.stdin.read()\n"
        "if 'exactement OK' in consigne:\n"
        "    print(json.dumps({'texte': 'OK', 'cout_usd': 0.001})); sys.exit(0)\n"
        "if 'passe de proposition' in consigne:\n"
        "    f1 = json.loads(%r); f2 = dict(f1, nom='Argon B')\n"
        "    if 'première passe' in consigne: f1['nom'] = 'Argon A (revue)'\n"
        "    print(json.dumps({'texte': '```json\\n' + json.dumps({'fiches': [f1, f2]}, ensure_ascii=False) + '\\n```', 'cout_usd': 0.25})); sys.exit(0)\n"
        "bloc = json.loads(re.search(r'```json\\n(\\[.*\\])\\n```', consigne, re.S).group(1))\n"
        "par_nom = {f['nom']: f['identifiant'] for f in bloc}\n"
        "notes = []\n"
        "for f in bloc:\n"
        "    c = {k: 2 for k in ('avantage','originalite','falsifiabilite','traitabilite','robustesse')}\n"
        "    if f['nom'] == 'Verbeux vide': c.update({'avantage': 1, 'originalite': 1, 'falsifiabilite': 0})\n"
        "    if f['nom'] == 'Assuré occupé': c.update({'avantage': 1, 'originalite': 0})\n"
        "    if f['nom'].startswith('Argon'): c.update({'avantage': 3})\n"
        "    if f['nom'] == 'O1': c.update({'avantage': 0})\n"
        "    notes.append({'identifiant': f['identifiant'], 'criteres': c, 'justifications': {}})\n"
        "doublons = [[par_nom['Jumeau'], par_nom['Sobre fort']]] if 'Jumeau' in par_nom and 'Sobre fort' in par_nom else []\n"
        "print(json.dumps({'texte': '```json\\n' + json.dumps({'notes': notes, 'doublons': doublons}) + '\\n```', 'cout_usd': 0.3}))\n") % FICHE

    def test_commande_factice_notes_et_controle(self):
        from pole.adaptateurs import AdaptateurCommandeExterne, AdaptateurJugeExterne
        self.assertIs(AdaptateurJugeExterne, AdaptateurCommandeExterne)
        ad = AdaptateurCommandeExterne(self.commande(self.SCRIPT_OK), environnement={})
        r = ad.lancer("juge_ideation", idn.APPEL_DE_CONTROLE_CONSIGNE, self.tmp, 0.1, 1, modele="autre-lignee-x")
        self.assertEqual((r.statut, r.texte_final, r.cout_declare_usd, r.cout_inconnu), ("ok", "OK", 0.001, False))
        with self.assertRaises(ValueError):
            ad.lancer("experimentateur", "x", self.tmp, 1.0, 1)
        self.assertEqual(sorted(ad.description()), ["commande", "delai_s", "empreintes", "variables_transmises"])
        self.assertIn(ad.commande[-1], ad.description()["empreintes"])
        with self.assertRaises(ValueError):
            AdaptateurCommandeExterne(self.commande("x"), delai_s=0)

    def test_artefacts_de_la_commande(self):
        """R5 : coût absent, NaN, infini, nul, négatif, sortie non JSON, code ≠ 0 → erreur ; coût imprimé avant un échec
        compté (CL35-02) ; coût illisible → plafond de session compté et marqué inconnu."""
        from pole.adaptateurs import AdaptateurCommandeExterne
        cas = (("import sys; sys.exit(3)", "erreur", 1.0, True),
               ("print('pas du json')", "erreur", 1.0, True),
               ("import json; print(json.dumps({'texte': 'x', 'cout_usd': 9.0}))", "budget_depasse", 9.0, False),
               ("import json; print(json.dumps({'texte': 'x'}))", "erreur", 1.0, True),
               ("import json; print(json.dumps({'cout_usd': 1}))", "erreur", 1.0, True),
               ("print('{\"texte\": \"x\", \"cout_usd\": NaN}')", "erreur", 1.0, True),
               ("print('{\"texte\": \"x\", \"cout_usd\": Infinity}')", "erreur", 1.0, True),
               ("import json; print(json.dumps({'texte': 'x', 'cout_usd': 0}))", "erreur", 1.0, True),
               ("import json; print(json.dumps({'texte': 'x', 'cout_usd': -1}))", "erreur", 1.0, True),
               ("import json, sys; print(json.dumps({'texte': 'x', 'cout_usd': 0.4})); sys.exit(3)", "erreur", 0.4, False),
               ("import json; print(json.dumps({'texte': 'x', 'cout_usd': 0.5}))", "ok", 0.5, False))
        for script, attendu, cout, inconnu in cas:
            ad = AdaptateurCommandeExterne(self.commande(script), environnement={})
            r = ad.lancer("juge_ideation", "consigne", self.tmp, 1.0, 1)
            self.assertEqual((r.statut, r.cout_declare_usd, r.cout_inconnu), (attendu, cout, inconnu), script)
        from pole.relais import CleDansEnvironnement
        ad = AdaptateurCommandeExterne(self.commande("print(1)"), environnement={"ANTHROPIC_API_KEY": "x"})
        with self.assertRaises(CleDansEnvironnement):
            ad.lancer("juge_ideation", "consigne", self.tmp, 1.0, 1)

    def test_delai_arrete_tout_le_groupe(self):
        """CL35-13 : au délai, le petit-enfant de la commande est arrêté aussi ; coût inconnu → plafond compté."""
        import time
        from pole.adaptateurs import AdaptateurCommandeExterne
        pid_f = os.path.join(self.tmp, "petit-enfant.pid")
        script = ("import subprocess, sys, time\n"
                  f"p = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(60)'])\n"
                  f"open({pid_f!r}, 'w').write(str(p.pid))\n"
                  "time.sleep(60)\n")
        ad = AdaptateurCommandeExterne(self.commande(script), environnement={}, delai_s=1.5)
        debut = time.monotonic()
        r = ad.lancer("juge_ideation", "consigne", self.tmp, 0.7, 1)
        self.assertLess(time.monotonic() - debut, 10.0)  # M26 : avec `kill` au lieu de `killpg`, le tube tenu par le petit-enfant bloque 60 s
        self.assertEqual((r.statut, r.cout_declare_usd, r.cout_inconnu), ("erreur", 0.7, True))
        self.assertIn("délai", r.erreur)
        pid = int(open(pid_f).read())

        def vivant():
            try:
                with open(f"/proc/{pid}/status") as f:
                    return not any(l.startswith("State:") and "Z" in l for l in f)
            except OSError:
                return False
        for _ in range(30):
            if not vivant():
                break
            time.sleep(0.1)
        else:
            try:
                os.kill(pid, 9)
            except ProcessLookupError:
                pass
            self.fail("le petit-enfant a survécu au délai")

    def test_environnement_minimal_de_la_commande(self):
        """CL34-09 / CL35-05 : environnement explicite et minimal, plus plafond de session et rôle."""
        from pole.adaptateurs import AdaptateurCommandeExterne
        from pole.relais import CleDansEnvironnement
        script = "import os, json; print(json.dumps({'texte': ','.join(sorted(os.environ)), 'cout_usd': 0.01}))"
        env = {"PATH": os.environ.get("PATH", "/usr/bin"), "HOME": "/tmp", "LANG": "C.UTF-8", "HTTPS_PROXY": "http://x",
               "CHEMIN_CLE_JUGE": "/dev/null", "AUTRE": "1"}
        ad = AdaptateurCommandeExterne(self.commande(script), environnement=env, variables_transmises=("CHEMIN_CLE_JUGE",))
        self.assertEqual(sorted(ad.environnement_commande()), ["CHEMIN_CLE_JUGE", "HOME", "LANG", "PATH"])
        r = ad.lancer("juge_ideation", "consigne", self.tmp, 1.0, 1)
        self.assertEqual(r.statut, "ok")
        self.assertEqual(r.texte_final, "CHEMIN_CLE_JUGE,HOME,LANG,PATH,PLAFOND_SESSION_USD,ROLE_POLE")
        with self.assertRaises(CleDansEnvironnement):
            AdaptateurCommandeExterne(self.commande(script), environnement=env, variables_transmises=("ANTHROPIC_API_KEY",))

    def cours(self):
        c = TestCourse("test_course_complete")
        c.tmp = self.tmp
        return c

    def test_adaptateur_principal_externe_refuse(self):
        """CL35-06 : une commande externe ne peut pas être l'adaptateur principal (ni le rôle réel d'un mixte)."""
        from pole.adaptateurs import AdaptateurCommandeExterne
        c = self.cours()
        ad = AdaptateurCommandeExterne(self.commande(self.SCRIPT_OK), environnement={})
        with self.assertRaises(idn.CourseInterrompue):
            c.lancer(ad, "cx-principal")
        self.assertFalse(os.path.exists(os.path.join(self.tmp, "cx-principal")))

        class Mixte:
            nom = "mixte"
            reel = ad
        with self.assertRaises(idn.CourseInterrompue):
            c.lancer(Mixte(), "cx-mixte")
        # moteur réel déclaré avec un adaptateur qui n'est pas celui du kit
        faux = FauxAdaptateur({"opus": [fiche_brute()], "fable": [fiche_brute()]})
        with self.assertRaises(idn.CourseInterrompue):
            c.lancer(faux, "cx-moteur", moteur="claude-sdk")
        self.assertEqual(faux.appels, [])

    def test_proposeur_externe_dans_la_course(self):
        """n° 119 : Argon propose à égalité dans la course (question et pièces) ; sa seconde passe exige l'attestation du
        matériau ; il ne voit jamais les fiches des autres ; plafond externe séparé."""
        from pole.adaptateurs import AdaptateurCommandeExterne
        c = self.cours()
        fiches = {"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]}
        ad = FauxAdaptateur(fiches, notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        ext = AdaptateurCommandeExterne(self.commande(self.SCRIPT_OK), environnement={})
        budgets = dict(c.budgets())
        budgets[("proposeur_ideation", "gemini-argon")] = 1.0
        prop_ext = [("argon", "gemini-argon", ext)]
        with self.assertRaises(idn.CourseInterrompue):  # plafond externe nul
            c.lancer(ad, "cx-0", budgets=budgets, proposeurs_externes=prop_ext, budget_externe_usd=0.0)
        with self.assertRaises(idn.CourseInterrompue):  # seconde passe avec matériau sans attestation : refus avant tout appel
            c.lancer(ad, "cx-1", budgets=budgets, proposeurs_externes=prop_ext, budget_externe_usd=3.0, seconde_passe=True)
        self.assertEqual(ad.appels, [])
        res = c.lancer(ad, "cx-2", budgets=budgets, proposeurs_externes=prop_ext, budget_externe_usd=3.0)
        auteurs = {f["auteur"] for f in res["fiches"]}
        self.assertEqual(auteurs, {"opus", "fable", "argon"})
        self.assertAlmostEqual(res["journal"]["cout_externe_usd"], 0.25)
        self.assertAlmostEqual(res["journal"]["cout_total_usd"], 4 * 0.5)
        self.assertEqual(res["lecture"]["quarantaine_par_proposeur"]["argon"]["validees"], 2)
        # attestation du matériau scellée → seconde passe ; Argon reçoit le matériau et SES fiches seulement
        att = os.path.join(self.tmp, "attestation-materiau.json")
        prep = c._prep
        idn.ecrire_json_scelle(att, {"lecteur": "Lazar", "lu_le": "2026-10-28",
                                     "materiau_sha256": {os.path.basename(prep["materiau"][0]):
                                                         idn.sha256_fichier(prep["materiau"][0])}})
        res = c.lancer(ad, "cx-3", budgets=budgets, proposeurs_externes=prop_ext, budget_externe_usd=3.0,
                       seconde_passe=True, attestation_materiau=att)
        consigne2 = open(os.path.join(self.tmp, "cx-3", "proposeurs", "traces-argon", "passe-2", "consigne.md")
                         if os.path.exists(os.path.join(self.tmp, "cx-3", "proposeurs", "traces-argon", "passe-2", "consigne.md"))
                         else os.path.join(self.tmp, "cx-3", "proposeurs", "argon", "traces-passe-2", "consigne.md"),
                         encoding="utf-8").read()
        self.assertIn("Matériau servi", consigne2)
        self.assertIn("Argon A", consigne2)
        self.assertNotIn('"O1"', consigne2)
        self.assertNotIn('"F1"', consigne2)
        self.assertEqual(sum(1 for f in res["fiches"] if f["auteur"] == "argon" and f["passe"] == 2), 2)
        # attestation à l'empreinte fausse → refus avant tout appel
        att2 = os.path.join(self.tmp, "attestation-materiau-fausse.json")
        idn.ecrire_json_scelle(att2, {"lecteur": "Lazar", "lu_le": "2026-10-28",
                                      "materiau_sha256": {os.path.basename(prep["materiau"][0]): "0" * 64}})
        n = len(ad.appels)
        with self.assertRaises(idn.CourseInterrompue):
            c.lancer(ad, "cx-4", budgets=budgets, proposeurs_externes=prop_ext, budget_externe_usd=3.0,
                     seconde_passe=True, attestation_materiau=att2)
        self.assertEqual(len(ad.appels), n)

    def attester(self, chemin, sortie, etiquette="argon"):
        consigne = os.path.join(sortie, "juges-bras-rapporte", f"traces-{etiquette}", "consigne-en-attente.md")
        idn.ecrire_json_scelle(chemin, {"lecteur": "Lazar", "lu_le": "2026-10-28",
                                        "fiches_validees_sha256": idn.sha256_fichier(os.path.join(sortie, "fiches-validees.json")),
                                        "consignes_en_attente_sha256": {etiquette: idn.sha256_fichier(consigne)}})
        return chemin

    def test_bras_differe_a_poids_egal(self):
        """CL34-01, CL34-04, n° 118 : la course n'appelle jamais le juge externe et n'écrit aucun classement ; le bras,
        après attestation scellée, note à poids égal : classement à trois juges (médiane), accords par paire ; jamais rejoué."""
        from pole.adaptateurs import AdaptateurCommandeExterne
        c = self.cours()
        fiches = {"opus": [fiche_brute(nom="O1"), fiche_brute(nom="O2")], "fable": [fiche_brute(nom="F1")]}
        ad = FauxAdaptateur(fiches, notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        externe = AdaptateurCommandeExterne(self.commande(self.SCRIPT_OK), environnement={})
        budgets = dict(c.budgets())
        budgets[("juge_ideation", "autre-lignee-x")] = 1.0
        # R5 : attestation donnée à la course → refus avant tout appel
        with self.assertRaises(idn.CourseInterrompue):
            c.lancer(ad, "cx-refus", budgets=budgets, juges_externes=[("argon", "autre-lignee-x")],
                     attestation_lecture_humaine=os.path.join(self.tmp, "x.json"))
        self.assertEqual(ad.appels, [])
        res = c.lancer(ad, "cx", budgets=budgets, juges_externes=[("argon", "autre-lignee-x")], budget_externe_usd=2.0)
        sortie = os.path.join(self.tmp, "cx")
        self.assertTrue(res["en_attente_bras"])
        self.assertIsNone(res["classement"])
        for nom in ("classement.json", "classements-par-juge.json", "lecture.json"):
            self.assertFalse(os.path.exists(os.path.join(sortie, nom)), nom)
        for nom in ("lecture-course.json", "notes-par-juge.json", "noyau/temoins-servis.json", "noyau/modeles.json",
                    "juges-bras-rapporte/traces-argon/consigne-en-attente.md"):
            self.assertTrue(os.path.exists(os.path.join(sortie, nom + ".sha256")), nom)
        self.assertTrue(all("argon" not in os.path.relpath(a["dossier"], sortie) for a in ad.appels))
        externes = [("argon", "autre-lignee-x", externe)]
        # attestation non scellée → refus
        att_nue = os.path.join(self.tmp, "att-nue.json")
        with open(att_nue, "w") as f:
            json.dump({"lecteur": "Lazar"}, f)
        with self.assertRaises(idn.CourseInterrompue):
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att_nue, budgets=budgets, juges_externes=externes)
        # attestation scellée mais consigne fausse → refus ; aucun manifeste du bras
        att_f = os.path.join(self.tmp, "att-fausse.json")
        idn.ecrire_json_scelle(att_f, {"lecteur": "Lazar", "lu_le": "2026-10-28",
                                       "fiches_validees_sha256": idn.sha256_fichier(os.path.join(sortie, "fiches-validees.json")),
                                       "consignes_en_attente_sha256": {"argon": "0" * 64}})
        with self.assertRaises(idn.CourseInterrompue):
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att_f, budgets=budgets, juges_externes=externes)
        att = self.attester(os.path.join(self.tmp, "att.json"), sortie)
        # juges donnés ≠ course → refus ; plafond externe insuffisant → refus AVANT le contrôle (CL35-05), sans manifeste
        with self.assertRaises(idn.CourseInterrompue):
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                      juges_externes=[("argon", "autre-modele", externe)])
        with self.assertRaises(idn.CourseInterrompue):
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets, juges_externes=externes,
                                      budget_externe_usd=0.5)
        self.assertFalse(os.path.exists(os.path.join(sortie, "manifeste-bras-rapporte.json")))
        self.assertFalse(os.path.exists(os.path.join(sortie, "bras-rapporte-controle")))
        # cas sain : trois juges
        apres = idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets, juges_externes=externes)
        self.assertFalse(apres["sans_bras"])
        self.assertTrue(all(l["nombre_juges"] == 3 and l["nom_agregat"] == "mediane" for l in apres["classement"]))
        o1 = next(l for l in apres["classement"] if l["identifiant_auteur"] == "opus-p1-01")
        self.assertEqual(o1["agregat"]["avantage"], 2)  # notes (2, 2, 0) : médiane 2, pas la moyenne 1,33
        self.assertEqual(o1["par_juge"]["argon"]["avantage"], 0)
        self.assertEqual(sorted(apres["lecture"]["juges_agreges"]), ["argon", "juge-fable", "juge-opus"])
        self.assertEqual(len(apres["lecture"]["accords_de_rang_par_paire"]), 3)
        self.assertTrue(apres["lecture"]["temoins"]["temoins_ok"])
        self.assertTrue(apres["lecture"]["temoins_juge_externe"]["temoins_ok"])
        self.assertTrue(apres["lecture"]["lisible_L2_L4"])
        self.assertIn("argon", apres["lecture"]["auto_preference"])
        self.assertEqual(apres["journal"]["controle"]["argon"]["texte"], "OK")
        self.assertFalse(apres["journal"]["cout_fictif"])
        for nom in ("classement.json", "classements-par-juge.json", "lecture.json", "manifeste-bras-rapporte.json",
                    "notes-bras-rapporte.json"):
            self.assertTrue(os.path.exists(os.path.join(sortie, nom + ".sha256")), nom)
        with open(os.path.join(sortie, "manifeste-bras-rapporte.json")) as f:
            m = json.load(f)["reglages"]
        self.assertEqual(m["commande_externe"][0]["commande"], externe.commande)  # CL35-03
        # rejeu → refus
        with self.assertRaises(idn.CourseInterrompue):
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets, juges_externes=externes)

    def test_bras_en_panne_classement_sans_bras(self):
        """n° 118 point 3 : Argon en panne → classement à deux juges marqué illisible, manifeste avec l'erreur, code distinct ;
        témoins échoués chez Argon → classement à trois juges illisible."""
        from pole.adaptateurs import AdaptateurCommandeExterne
        c = self.cours()
        fiches = {"opus": [fiche_brute(nom="O1"), fiche_brute(nom="O2")], "fable": [fiche_brute(nom="F1")]}
        ad = FauxAdaptateur(fiches, notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        budgets = dict(c.budgets())
        budgets[("juge_ideation", "autre-lignee-x")] = 1.0
        panne = AdaptateurCommandeExterne(self.commande(
            "import sys, json\nc = sys.stdin.read()\n"
            "if 'exactement OK' in c: print(json.dumps({'texte': 'OK', 'cout_usd': 0.001})); sys.exit(0)\n"
            "print(json.dumps({'texte': 'x', 'cout_usd': 0.2})); sys.exit(3)\n", "panne.py"), environnement={})
        c.lancer(ad, "cp", budgets=budgets, juges_externes=[("argon", "autre-lignee-x")], budget_externe_usd=2.0)
        sortie = os.path.join(self.tmp, "cp")
        att = self.attester(os.path.join(self.tmp, "att-p.json"), sortie)
        with self.assertRaises(idn.SansJugeExterne) as cm:
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                      juges_externes=[("argon", "autre-lignee-x", panne)])
        res = cm.exception.resultat
        self.assertTrue(res["sans_bras"])
        self.assertTrue(all(l["nombre_juges"] == 2 for l in res["classement"]))
        self.assertFalse(res["lecture"]["lisible_L2_L4"])
        self.assertAlmostEqual(res["journal"]["cout_total_usd"], 0.201)  # le coût imprimé avant l'échec est compté
        self.assertTrue(os.path.exists(os.path.join(sortie, "classement-sans-bras.json.sha256")))
        self.assertFalse(os.path.exists(os.path.join(sortie, "classement.json")))
        with open(os.path.join(sortie, "manifeste-bras-rapporte.json")) as f:
            self.assertIn("code 3", json.load(f)["reglages"]["erreur"])
        # témoins échoués chez Argon : trois juges, illisible
        mauvais = AdaptateurCommandeExterne(self.commande(self.SCRIPT_OK.replace("'avantage': 1, 'originalite': 0", "'avantage': 3, 'originalite': 3"), "mauvais.py"), environnement={})
        c.lancer(ad, "ct", budgets=budgets, juges_externes=[("argon", "autre-lignee-x")], budget_externe_usd=2.0)
        sortie = os.path.join(self.tmp, "ct")
        att = self.attester(os.path.join(self.tmp, "att-t.json"), sortie)
        apres = idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                          juges_externes=[("argon", "autre-lignee-x", mauvais)])
        self.assertFalse(apres["lecture"]["lisible_L2_L4"])
        self.assertFalse(apres["lecture"]["temoins_juge_externe"]["temoins_ok"])
        self.assertTrue(all(l["nombre_juges"] == 3 for l in apres["classement"]))

    def test_bras_simule_sur_course_reelle_refuse(self):
        """CL35-04 : course marquée réelle (adaptateur du kit, modèles permis) → un adaptateur qui n'est pas une commande
        externe est refusé avant tout écrit ; CL35-03 : la commande est consignée ; CL36-03 : Argon obligatoire."""
        from pole.adaptateurs import AdaptateurCommandeExterne
        c = self.cours()
        fiches = {"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]}
        ad = FauxAdaptateur(fiches, notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        ad.nom = "claude-sdk"
        budgets = dict(c.budgets())
        budgets[("juge_ideation", "autre-lignee-x")] = 1.0
        budgets[("proposeur_ideation", "gemini-argon")] = 1.0
        ext = AdaptateurCommandeExterne(self.commande(self.SCRIPT_OK), environnement={})
        with self.assertRaises(idn.CourseInterrompue):  # CL36-03 : course réelle sans Argon proposeur ET juge → refus
            c.lancer(ad, "cr0", budgets=budgets, juges_externes=[("argon", "autre-lignee-x")], budget_externe_usd=2.0,
                     moteur="claude-sdk")
        self.assertEqual(ad.appels, [])
        c.lancer(ad, "cr", budgets=budgets, juges_externes=[("argon", "autre-lignee-x")], budget_externe_usd=4.0,
                 proposeurs_externes=[("argon-p", "gemini-argon", ext)], moteur="claude-sdk")
        sortie = os.path.join(self.tmp, "cr")
        att = self.attester(os.path.join(self.tmp, "att-r.json"), sortie)
        simule = FauxAdaptateur({}, notes_par_juge={"argon": c.notes_temoins_ok})
        with self.assertRaises(idn.CourseInterrompue):
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                      juges_externes=[("argon", "autre-lignee-x", simule)])
        self.assertEqual(simule.appels, [])
        self.assertFalse(os.path.exists(os.path.join(sortie, "manifeste-bras-rapporte.json")))
        # proposeur externe sans juge externe sur une course réelle : refusé (CL36-03, « juge oublié », n° 118)
        with self.assertRaises(idn.CourseInterrompue) as cm:
            c.lancer(ad, "cr1", budgets=budgets, proposeurs_externes=[("argon-p", "gemini-argon", ext)],
                     budget_externe_usd=4.0, moteur="claude-sdk")
        self.assertIn("obligatoires", str(cm.exception))
        # et un proposeur externe simulé sur une course réelle est refusé aussi (CL35-04), juge externe présent
        with self.assertRaises(idn.CourseInterrompue) as cm:
            c.lancer(ad, "cr2", budgets=budgets, juges_externes=[("argon", "autre-lignee-x")],
                     proposeurs_externes=[("argon-p", "gemini-argon", simule)], budget_externe_usd=4.0, moteur="claude-sdk")
        self.assertIn("CL35-04", str(cm.exception))


    def test_bras_non_joue_relancable(self):
        """CL36-01 : commande introuvable ou clé dans l'environnement → rien envoyé, rien dépensé : manifeste « non joué »
        numéroté, bras relançable ; puis le bras se joue."""
        from pole.adaptateurs import AdaptateurCommandeExterne
        c = self.cours()
        fiches = {"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]}
        ad = FauxAdaptateur(fiches, notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        budgets = dict(c.budgets())
        budgets[("juge_ideation", "autre-lignee-x")] = 1.0
        c.lancer(ad, "cn", budgets=budgets, juges_externes=[("argon", "autre-lignee-x")], budget_externe_usd=2.0)
        sortie = os.path.join(self.tmp, "cn")
        att = self.attester(os.path.join(self.tmp, "att-n.json"), sortie)
        introuvable = AdaptateurCommandeExterne(["/chemin/qui/n/existe/pas"], environnement={})
        with self.assertRaises(idn.CourseInterrompue) as cm:
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                      juges_externes=[("argon", "autre-lignee-x", introuvable)])
        self.assertIn("non joué", str(cm.exception))
        self.assertTrue(os.path.exists(os.path.join(sortie, "manifeste-bras-non-joue-1.json.sha256")))
        self.assertFalse(os.path.exists(os.path.join(sortie, "manifeste-bras-rapporte.json")))
        cle_env = AdaptateurCommandeExterne(self.commande(self.SCRIPT_OK), environnement={"ANTHROPIC_API_KEY": "x"})
        with self.assertRaises(idn.CourseInterrompue):
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                      juges_externes=[("argon", "autre-lignee-x", cle_env)])
        self.assertTrue(os.path.exists(os.path.join(sortie, "manifeste-bras-non-joue-2.json")))
        # attestation complète mais au sceau faux (modifiée après scellement) → refus
        att_f = os.path.join(self.tmp, "att-n-fausse.json")
        self.attester(att_f, sortie)
        with open(att_f, "a") as f:
            f.write("\n")
        with self.assertRaises(idn.CourseInterrompue) as cm:
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att_f, budgets=budgets,
                                      juges_externes=[("argon", "autre-lignee-x", introuvable)])
        self.assertIn("sceau", str(cm.exception))  # CL39-12 : le motif est bien le sceau
        self.assertFalse(os.path.exists(os.path.join(sortie, "juges-bras-rapporte", "traces-argon", "reponse.md")))  # M28
        # CL37-02 : contrôle « KO » qui a coûté 0,15 → tentative payée, coût scellé, imputé au plafond externe
        ko = AdaptateurCommandeExterne(self.commande(
            "import sys, json\nc = sys.stdin.read()\nprint(json.dumps({'texte': 'KO', 'cout_usd': 0.15}))\n", "ko.py"),
            environnement={})
        with self.assertRaises(idn.CourseInterrompue) as cm:
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                      juges_externes=[("argon", "autre-lignee-x", ko)])
        self.assertIn("0.1500 USD comptés", str(cm.exception))
        self.assertTrue(os.path.exists(os.path.join(sortie, "bras-tentative-3.json.sha256")))
        with open(os.path.join(sortie, "bras-tentative-3.json")) as f:
            self.assertAlmostEqual(json.load(f)["reglages"]["journal"]["cout_total_usd"], 0.15)
        # trois tentatives faites : plus de relance
        bon = AdaptateurCommandeExterne(self.commande(self.SCRIPT_OK), environnement={})
        with self.assertRaises(idn.CourseInterrompue) as cm:
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                      juges_externes=[("argon", "autre-lignee-x", bon)])
        self.assertIn("tentatives", str(cm.exception))
        self.assertFalse(os.path.exists(os.path.join(sortie, "manifeste-bras-rapporte.json")))
        # course neuve : une tentative payée, puis le bras joué avec le coût précédent imputé
        c.lancer(ad, "cn2", budgets=budgets, juges_externes=[("argon", "autre-lignee-x")], budget_externe_usd=2.0)
        sortie2 = os.path.join(self.tmp, "cn2")
        att2 = self.attester(os.path.join(self.tmp, "att-n2.json"), sortie2)
        with self.assertRaises(idn.CourseInterrompue):
            idn.executer_bras_differe(sortie2, attestation_lecture_humaine=att2, budgets=budgets,
                                      juges_externes=[("argon", "autre-lignee-x", ko)])
        apres = idn.executer_bras_differe(sortie2, attestation_lecture_humaine=att2, budgets=budgets,
                                          juges_externes=[("argon", "autre-lignee-x", bon)])
        self.assertFalse(apres["sans_bras"])
        self.assertAlmostEqual(apres["journal"]["cout_tentatives_precedentes_usd"], 0.15)
        self.assertEqual(apres["journal"]["tentative"], 2)
        self.assertTrue(os.path.exists(os.path.join(sortie2, "manifeste-bras-rapporte.json")))


class TestLanceurV37(CasAvecDossier):
    """CL35-07, 08, 09, CL36-03 : le lanceur refuse avec un code, jamais une trace."""

    def lanceur(self):
        import importlib.util
        chemin = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "demonstrations", "ideation_v1.py")
        spec = importlib.util.spec_from_file_location("ideation_v1_lanceur", chemin)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def test_options_refusees(self):
        import contextlib
        import io
        lanceur = self.lanceur()
        base = [os.path.join(self.tmp, "s"), "--liste-blanche", "l", "--question", "q", "--temoins", "t"]
        for options in (["--commande-externe", "x"], ["--delai-session-s", "0"], ["--attestation-lecture-humaine", "a"],
                        ["--nombre", "13"], ["--delai-commande-s", "-1"]):
            with contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit) as cm:
                    lanceur.principal(base + options)
            self.assertEqual(cm.exception.code, 2, options)
        err = io.StringIO()
        with contextlib.redirect_stderr(err):
            code = lanceur.principal(base + ["--moteur", "claude-sdk"])  # M29 : course réelle sans Argon → refus d'abord
        self.assertEqual(code, 2)
        self.assertIn("obligatoires", err.getvalue())
        err = io.StringIO()
        with contextlib.redirect_stderr(err):  # CL35-08 : non armé → 2, pas une trace
            code = lanceur.principal(base + ["--moteur", "claude-sdk", "--proposeur-externe", "a=x", "--juge-externe", "b=x",
                                             "--commande-externe", "x"])
        self.assertEqual(code, 2)
        self.assertIn("MoteurNonArme", err.getvalue())
        # M31 : --commande-externe avec --juge-externe seul, hors bras → refusé
        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                lanceur.principal(base + ["--juge-externe", "b=x", "--commande-externe", "x"])
        # M18, M21, M22, M30 : défauts du devis en vigueur
        a = lanceur.construire_analyseur()
        self.assertEqual(a.get_default("taille_max_pieces"), 750_000)
        self.assertEqual(a.get_default("delai_commande_s"), 1800.0)
        self.assertEqual(a.get_default("budget_externe_usd"), 11.6)
        self.assertEqual(lanceur.BUDGETS_PAR_DEFAUT[("juge_ideation", "claude-opus-5-5")], 4.0)
        from pole.adaptateurs import DELAI_SESSION_S, AdaptateurCommandeExterne
        self.assertEqual(DELAI_SESSION_S, 3600)
        self.assertEqual(AdaptateurCommandeExterne.DELAI_COMMANDE_S, 1800)
        self.assertEqual(lanceur.BUDGETS_PAR_DEFAUT[("proposeur_ideation", "claude-fable-5-1")], 9.3)  # CL36-04, CL37-03

    def test_controle_argon_avant_toute_passe(self):
        """CL36-02 / CL37-01 : avec une commande factice, le proposeur externe est contrôlé avant toute passe, sous son
        rôle, à la taille réelle des pièces, son coût compté ; Argon joue en tête de chaque passe. Une commande qui casse
        sur une grosse consigne arrête avant tout appel Claude de proposition."""
        import contextlib
        import io
        lanceur = self.lanceur()
        cours = TestCourse("test_course_complete")
        cours.tmp = self.tmp
        prep = cours.preparer()
        cmd = TestCommandeExterne("test_commande_factice_notes_et_controle")
        cmd.tmp = self.tmp
        commande = " ".join(cmd.commande(cmd.SCRIPT_OK))
        sortie = os.path.join(self.tmp, "lanceur-ok")
        base = [sortie, "--liste-blanche", prep["liste_blanche"], "--question", prep["question"], "--piece", prep["pieces"][0],
                "--temoins", prep["temoins"], "--proposeur-externe", "argon=gemini-argon", "--juge-externe",
                "argon-j=gemini-argon", "--commande-externe", commande, "--budget-externe-usd", "9"]
        import unittest.mock
        env_propre = {k: v for k, v in os.environ.items() if k in ("PATH", "HOME", "LANG", "LC_ALL", "TMPDIR")}
        out = io.StringIO()
        with unittest.mock.patch.dict(os.environ, env_propre, clear=True), contextlib.redirect_stdout(out):
            code = lanceur.principal(base)
        self.assertEqual(code, 0, out.getvalue())
        with open(os.path.join(sortie, "manifeste-depart.json")) as f:
            depart = json.load(f)["reglages"]
        ctrl = depart["versions"]["appel_de_controle"]["externe:argon"]
        self.assertEqual(ctrl["role"], "proposeur_ideation")
        self.assertGreater(ctrl["taille_consigne"], depart["taille_pieces_servies"]["proposeurs"])
        self.assertAlmostEqual(depart["cout_externe_deja_engage_usd"], 0.001)
        with open(os.path.join(sortie, "manifeste-fin.json")) as f:
            journal = json.load(f)["reglages"]["journal"]
        self.assertEqual(journal["appels"][0]["etiquette"], "argon")  # CL37-01 : Argon en tête
        self.assertAlmostEqual(journal["cout_externe_usd"], 0.001 + 0.25)
        # commande qui casse au-delà de 100 caractères : refus au contrôle, aucun proposeur Claude appelé
        casse = " ".join(cmd.commande("import sys, json\nc = sys.stdin.read()\n"
                                      "if len(c) > 100: sys.exit(3)\nprint(json.dumps({'texte': 'OK', 'cout_usd': 0.001}))\n",
                                      "casse.py"))
        sortie2 = os.path.join(self.tmp, "lanceur-casse")
        err = io.StringIO()
        with unittest.mock.patch.dict(os.environ, env_propre, clear=True), contextlib.redirect_stdout(io.StringIO()), \
                contextlib.redirect_stderr(err):
            code = lanceur.principal([sortie2 if x == sortie else x for x in base[:-4]] + ["--commande-externe", casse,
                                                                                            "--budget-externe-usd", "9"])
        self.assertEqual(code, 2)
        self.assertIn("appel de contrôle refusé", err.getvalue())
        self.assertFalse(os.path.exists(os.path.join(sortie2, "manifeste-depart.json")))


class TestV40(CasAvecDossier):
    """v40 (relecture CL6) : sommes externes avec le contrôle du bras, plafonds finis, tentatives de contrôle scellées,
    garde du relais avec la dépense, bras interrompu après envoi verrouillé, interruption qui arrête Argon, refus avant
    les contrôles, contrôle simulé par préfixe."""

    def cours(self):
        c = TestCourse("test_course_complete")
        c.tmp = self.tmp
        return c

    def cmd(self):
        c = TestCommandeExterne("test_commande_factice_notes_et_controle")
        c.tmp = self.tmp
        return c

    def lanceur(self):
        return TestLanceurV37("test_options_refusees").lanceur()

    def test_sommes_et_plafonds_non_finis(self):
        """M12 à M14, M17, M19 : somme externe (contrôle du bras compris) refusée au cœur et par verifier_reglages ;
        totaux et plafonds non finis refusés."""
        from pole.adaptateurs import AdaptateurCommandeExterne
        c = self.cours()
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]})
        ext = AdaptateurCommandeExterne(self.cmd().commande(self.cmd().SCRIPT_OK), environnement={})
        budgets = dict(c.budgets())
        budgets[("proposeur_ideation", "gemini-argon")] = 1.0
        budgets[("juge_ideation", "autre-lignee-x")] = 1.0
        ext_args = dict(budgets=budgets, proposeurs_externes=[("argon", "gemini-argon", ext)],
                        juges_externes=[("argon-j", "autre-lignee-x")], seconde_passe=False)
        # cœur : 1,0 + 1,0 + 0,2 (contrôle du bras) = 2,2 > 2,1 refusé ; 2,2 accepté
        with self.assertRaises(idn.CourseInterrompue) as cm:
            c.lancer(ad, "s-ext-refus", budget_externe_usd=2.1, **ext_args)
        self.assertIn("externes", str(cm.exception))
        self.assertEqual(ad.appels, [])
        c.lancer(ad, "s-ext-ok", budget_externe_usd=2.2, **ext_args)
        # verifier_reglages : mêmes sommes (M13, M14), plafonds non finis (M19)
        prep = c._prep
        base = dict(liste_blanche=prep["liste_blanche"], question=prep["question"], pieces=prep["pieces"], temoins=prep["temoins"],
                    budgets=budgets, proposeurs=[("opus", "claude-opus-5-5"), ("fable", "claude-fable-5-1")],
                    juges=[("juge-fable", "claude-fable-5-1"), ("juge-opus", "claude-opus-5-5")],
                    proposeurs_externes=[("argon", "gemini-argon")], juges_externes=[("argon-j", "autre-lignee-x")])
        idn.verifier_reglages(budget_total_usd=4.0, budget_externe_usd=2.2, **base)
        with self.assertRaises(idn.CourseInterrompue):
            idn.verifier_reglages(budget_total_usd=3.9, budget_externe_usd=2.2, **base)
        with self.assertRaises(idn.CourseInterrompue):
            idn.verifier_reglages(budget_total_usd=4.0, budget_externe_usd=2.1, **base)
        mauvais = dict(budgets); mauvais[("juge_ideation", "claude-opus-5-5")] = float("nan")
        with self.assertRaises(idn.CourseInterrompue):
            idn.verifier_reglages(budget_total_usd=4.0, budget_externe_usd=2.2, **dict(base, budgets=mauvais))
        with self.assertRaises(idn.CourseInterrompue):
            idn.verifier_reglages(budget_total_usd=4.0, budget_externe_usd=2.2, max_tours=3, **base)  # CL39-07
        # cœur : totaux non finis (M17)
        for champ in ("budget_total_usd", "budget_externe_usd", "cout_deja_engage_usd"):
            with self.assertRaises(idn.CourseInterrompue):
                c.lancer(ad, f"nan-{champ}", **{champ: float("nan")})
        with self.assertRaises(idn.CourseInterrompue):
            c.lancer(ad, "nan-session", budgets=mauvais)

    def test_garde_du_relais(self):
        """CL39-03, M15 : plafond − réserve − dépense ≥ total − plus petit juge."""
        lanceur = self.lanceur()
        budgets = {("juge_ideation", "claude-opus-5-5"): 4.0, ("juge_ideation", "claude-fable-5-1"): 7.0}
        juges = [("a", "claude-opus-5-5"), ("b", "claude-fable-5-1")]
        lu = lanceur.verifier_relais({"plafond_usd": 40, "reserve_par_appel_usd": 4, "depense_usd": 0.0}, 40.0, budgets, juges)
        self.assertEqual(lu["depense_usd"], 0.0)
        with self.assertRaises(idn.CourseInterrompue):  # réserve 10 : 30 < 36
            lanceur.verifier_relais({"plafond_usd": 40, "reserve_par_appel_usd": 10}, 40.0, budgets, juges)
        with self.assertRaises(idn.CourseInterrompue):  # relance après 0,4 dépensés : 35,6 < 36
            lanceur.verifier_relais({"plafond_usd": 40, "reserve_par_appel_usd": 4, "depense_usd": 0.4}, 40.0, budgets, juges)
        lanceur.verifier_relais({}, 40.0, budgets, juges)  # relais muet sur ses plafonds : rien à vérifier

    def test_tentatives_de_controle_scellees(self):
        """CL39-02, CL39-07, CL39-08, M16 : un contrôle refusé est scellé avec son coût dans SORTIE-controle, imputé à la
        relance, borné à trois ; un refus de réglage ou une SORTIE existante tombent avant tout contrôle ; la répétition
        simulée avec un proposeur externe sans commande passe."""
        import contextlib
        import io
        import unittest.mock
        lanceur = self.lanceur()
        c = self.cours()
        prep = c.preparer()
        cmd = self.cmd()
        casse = " ".join(cmd.commande("import sys, json\nc = sys.stdin.read()\nprint(json.dumps({'texte': 'KO', 'cout_usd': 0.15}))\n",
                                      "casse.py"))
        sortie = os.path.join(self.tmp, "l-tent")
        env_propre = {k: v for k, v in os.environ.items() if k in ("PATH", "HOME", "LANG", "LC_ALL", "TMPDIR")}
        base = [sortie, "--liste-blanche", prep["liste_blanche"], "--question", prep["question"], "--piece", prep["pieces"][0],
                "--temoins", prep["temoins"], "--proposeur-externe", "argon=gemini-argon", "--juge-externe",
                "argon-j=gemini-argon", "--budget-externe-usd", "11.2"]
        with unittest.mock.patch.dict(os.environ, env_propre, clear=True), contextlib.redirect_stderr(io.StringIO()):
            for n in (1, 2, 3):
                code = lanceur.principal(base + ["--commande-externe", casse])
                self.assertEqual(code, 2)
                chemin = os.path.join(sortie + "-controle", f"tentative-{n}.json")
                self.assertTrue(os.path.exists(chemin + ".sha256"), n)
                with open(chemin) as f:
                    r = json.load(f)["reglages"]
                self.assertAlmostEqual(r["cout_externe_usd"], 0.15)
                self.assertEqual(r["relancable"], n < 3)
            self.assertFalse(os.path.exists(sortie))
            err = io.StringIO()
            with contextlib.redirect_stderr(err):
                self.assertEqual(lanceur.principal(base + ["--commande-externe", casse]), 2)
            self.assertIn("tentatives", err.getvalue())
            self.assertFalse(os.path.exists(os.path.join(sortie + "-controle", "tentative-4.json")))
        # M16 / CL39-07 : réglage refusé AVANT tout contrôle (aucun dossier de contrôle, commande jamais appelée)
        sortie2 = os.path.join(self.tmp, "l-regl")
        with unittest.mock.patch.dict(os.environ, env_propre, clear=True), contextlib.redirect_stderr(io.StringIO()):
            code = lanceur.principal([sortie2 if x == sortie else x for x in base] + ["--commande-externe", casse,
                                                                                         "--taille-max-pieces", "5"])
        self.assertEqual(code, 2)
        self.assertFalse(os.path.exists(sortie2 + "-controle"))
        os.makedirs(sortie2)
        with unittest.mock.patch.dict(os.environ, env_propre, clear=True), contextlib.redirect_stderr(io.StringIO()):
            code = lanceur.principal([sortie2 if x == sortie else x for x in base] + ["--commande-externe", casse])
        self.assertEqual(code, 2)
        self.assertFalse(os.path.exists(sortie2 + "-controle"))
        # CL39-08 : répétition simulée avec proposeur externe, sans commande
        sortie3 = os.path.join(self.tmp, "l-sim")
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            code = lanceur.principal([sortie3 if x == sortie else x for x in base])
        self.assertEqual(code, 0, out.getvalue())

    def test_bras_interrompu_apres_envoi_verrouille(self):
        """CL39-04 : une exception pendant la session du juge du bras, après envoi, compte le plafond et verrouille."""
        c = self.cours()
        fiches = {"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]}
        ad = FauxAdaptateur(fiches, notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        budgets = dict(c.budgets())
        budgets[("juge_ideation", "autre-lignee-x")] = 1.0
        c.lancer(ad, "ci", budgets=budgets, juges_externes=[("argon", "autre-lignee-x")], budget_externe_usd=2.0)
        sortie = os.path.join(self.tmp, "ci")
        cmd = self.cmd()
        att = cmd.attester(os.path.join(self.tmp, "att-ci.json"), sortie)

        class Coupe:
            nom = "commande-externe"

            def lancer(self, role, consigne, dossier, budget_usd, max_tours, modele=None):
                if consigne.startswith(idn.APPEL_DE_CONTROLE_CONSIGNE):
                    return Resultat("OK", [], 0.001, "ok")
                raise RuntimeError("coupé pendant la session")

            def description(self):
                return {"commande": ["coupe"]}
        with self.assertRaises(RuntimeError):
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                      juges_externes=[("argon", "autre-lignee-x", Coupe())])
        chemin = os.path.join(sortie, "manifeste-bras-rapporte.json")
        self.assertTrue(os.path.exists(chemin))
        with open(chemin) as f:
            j = json.load(f)["reglages"]["journal"]
        self.assertAlmostEqual(j["cout_total_usd"], 1.001)  # contrôle 0,001 + plafond 1,0 de la session interrompue
        self.assertEqual(j["consigne_envoyee"], "argon")
        self.assertFalse(any(f.startswith("bras-tentative") or f.startswith("manifeste-bras-non-joue") for f in os.listdir(sortie)))
        bon = self.cmd()
        from pole.adaptateurs import AdaptateurCommandeExterne
        with self.assertRaises(idn.CourseInterrompue):  # verrouillé
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                      juges_externes=[("argon", "autre-lignee-x",
                                                       AdaptateurCommandeExterne(bon.commande(bon.SCRIPT_OK), environnement={}))])

    def test_tentative_payee_imputee_et_non_lance(self):
        """M07, M09 : « rien envoyé » exige « aucun processus parti » ; le coût d'une tentative payée réduit le plafond."""
        from pole.adaptateurs import AdaptateurCommandeExterne
        c = self.cours()
        fiches = {"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]}
        ad = FauxAdaptateur(fiches, notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        budgets = dict(c.budgets())
        budgets[("juge_ideation", "autre-lignee-x")] = 1.0
        c.lancer(ad, "cp9", budgets=budgets, juges_externes=[("argon", "autre-lignee-x")], budget_externe_usd=1.3)
        sortie = os.path.join(self.tmp, "cp9")
        cmd = self.cmd()
        att = cmd.attester(os.path.join(self.tmp, "att-cp9.json"), sortie)
        ko = AdaptateurCommandeExterne(cmd.commande("import sys, json\nsys.stdin.read()\nprint(json.dumps({'texte': 'KO', 'cout_usd': 0.15}))\n", "ko9.py"),
                                       environnement={})
        with self.assertRaises(idn.CourseInterrompue) as cm:
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                      juges_externes=[("argon", "autre-lignee-x", ko)])
        self.assertNotIn("non joué", str(cm.exception))  # M07 : un processus est parti → tentative payée, pas « non joué »
        self.assertTrue(os.path.exists(os.path.join(sortie, "bras-tentative-1.json")))
        bon = AdaptateurCommandeExterne(cmd.commande(cmd.SCRIPT_OK), environnement={})
        with self.assertRaises(idn.CourseInterrompue) as cm:  # M09 : 0,15 + 0,2 + 1,0 > 1,3 → plafond externe insuffisant
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                      juges_externes=[("argon", "autre-lignee-x", bon)])
        self.assertIn("plafond externe", str(cm.exception))

    def test_interruption_arrete_le_groupe_et_compte(self):
        """CL37-07, CL39-05, M20 : une interruption pendant la commande arrête tout son groupe ; la session interrompue
        est comptée au plafond par la course et le manifeste de fin est écrit."""
        import subprocess
        import unittest.mock
        from pole.adaptateurs import AdaptateurCommandeExterne
        cmd = self.cmd()
        ad = AdaptateurCommandeExterne(cmd.commande("import sys, time\nsys.stdin.read()\ntime.sleep(30)\n", "lent.py"), environnement={})
        tues = []
        vrai_communicate = subprocess.Popen.communicate

        lances = []

        def communicate_coupe(self_p, *a, **k):
            if not getattr(self_p, "_deja", False):
                self_p._deja = True
                lances.append(self_p)
                raise KeyboardInterrupt()
            return vrai_communicate(self_p, *a, **k)
        with unittest.mock.patch.object(subprocess.Popen, "communicate", communicate_coupe), \
                unittest.mock.patch("os.killpg", side_effect=lambda pid, sig: tues.append((pid, sig))):
            with self.assertRaises(KeyboardInterrupt):
                ad.lancer("juge_ideation", "consigne", self.tmp, 1.0, 1)
        self.assertEqual(len(tues), 1)  # M20 : le groupe est visé
        for p in lances:  # v41 : `os.killpg` était simulé — la commande lente est arrêtée ici (aucun processus survivant)
            p.kill()
            p.communicate()
        # la course compte la session interrompue au plafond et écrit le manifeste de fin
        c = self.cours()

        class Interrompt(FauxAdaptateur):
            def lancer(self, role, consigne, dossier, budget_usd, max_tours, modele=None):
                raise KeyboardInterrupt()
        ad2 = Interrompt({"opus": [fiche_brute()], "fable": [fiche_brute()]})
        with self.assertRaises(KeyboardInterrupt):
            c.lancer(ad2, "c-int")
        with open(os.path.join(self.tmp, "c-int", "manifeste-fin.json")) as f:
            j = json.load(f)["reglages"]["journal"]
        self.assertEqual(j["appels"][0]["statut"], "interrompue")
        self.assertAlmostEqual(j["cout_total_usd"], 1.0)  # plafond de la session compté
        self.assertIn("taille_consigne", j["appels"][0])


    def test_sigterm_sur_le_lanceur(self):
        """CL39-05 : SIGTERM à l'orchestrateur pendant la session d'Argon → code 2, manifeste de fin écrit avec la session
        comptée au plafond, commande et petit-enfant arrêtés."""
        import signal
        import subprocess
        import time
        c = self.cours()
        prep = c.preparer()
        cmd = self.cmd()
        pid_f = os.path.join(self.tmp, "pe.pid")
        lent = " ".join(cmd.commande(
            "import sys, json, subprocess, time\nc = sys.stdin.read()\n"
            "if 'exactement OK' in c: print(json.dumps({'texte': 'OK', 'cout_usd': 0.001})); sys.exit(0)\n"
            f"p = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(60)']); open({pid_f!r}, 'w').write(str(p.pid))\n"
            "time.sleep(60)\n", "lent2.py"))
        sortie = os.path.join(self.tmp, "l-term")
        lanceur = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "demonstrations", "ideation_v1.py")
        env = {k: v for k, v in os.environ.items() if k in ("PATH", "HOME", "LANG", "LC_ALL", "TMPDIR")}
        p = subprocess.Popen([sys.executable, "-I", "-B", lanceur, sortie, "--liste-blanche", prep["liste_blanche"], "--question",
                              prep["question"], "--piece", prep["pieces"][0], "--temoins", prep["temoins"], "--proposeur-externe",
                              "argon=gemini-argon", "--juge-externe", "argon-j=gemini-argon", "--commande-externe", lent,
                              "--budget-externe-usd", "11.2"], env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        for _ in range(100):
            if os.path.exists(pid_f):
                break
            time.sleep(0.1)
        else:
            p.kill()
            self.fail("la commande lente n'a pas démarré")
        p.send_signal(signal.SIGTERM)
        out, err = p.communicate(timeout=30)
        self.assertEqual(p.returncode, 2, err.decode("utf-8", "replace"))
        self.assertIn("interruption", err.decode("utf-8", "replace"))
        with open(os.path.join(sortie, "manifeste-fin.json")) as f:
            j = json.load(f)["reglages"]["journal"]
        self.assertEqual(j["appels"][-1]["statut"], "interrompue")
        pe = int(open(pid_f).read())
        for _ in range(30):
            try:
                with open(f"/proc/{pe}/status") as f:
                    if any(l.startswith("State:") and "Z" in l for l in f):
                        break
            except OSError:
                break
            time.sleep(0.1)
        else:
            os.kill(pe, 9)
            self.fail("le petit-enfant d'Argon a survécu au SIGTERM")


def _lire(chemin):
    with open(chemin, encoding="utf-8") as f:
        return f.read()


class TestV41(CasAvecDossier):
    """v41 (relecture CL7 de la v40) : contrôle interrompu compté au plafond (CL40-02), même contrôle du bras au lanceur
    et au cœur et refus du cœur scellé (CL40-03), contrôle à la taille réelle et passe 2 d'Argon juste après sa passe 1
    (CL40-04), `relancable` calculé et contrôle Claude payé (CL40-01, code), deux tolérances, valeurs non finies du
    chemin de l'argent (CL40-05), classement sans bras après envoi (CL40-08), M07 (CL40-07), écrits (CL40-09)."""

    ENV = ("PATH", "HOME", "LANG", "LC_ALL", "TMPDIR")

    def cours(self):
        c = TestCourse("test_course_complete")
        c.tmp = self.tmp
        return c

    def cmd(self):
        c = TestCommandeExterne("test_commande_factice_notes_et_controle")
        c.tmp = self.tmp
        return c

    def lanceur(self, cout_controle_claude=None, ko_claude=None):
        """Lanceur chargé à neuf ; avec `cout_controle_claude`, le contrôle Claude simulé rend ce coût (moteur simulé payé) ;
        v42 : `ko_claude` (un modèle) rend « KO » au contrôle, à ce même coût."""
        lanceur = TestLanceurV37("test_options_refusees").lanceur()
        if cout_controle_claude is not None:
            original = lanceur.AdaptateurIdeationSimule.lancer

            def lancer(s, role, consigne, dossier, budget_usd, max_tours, modele=None):
                if consigne.startswith(idn.APPEL_DE_CONTROLE_CONSIGNE):
                    return Resultat("KO" if modele == ko_claude else "OK", [], cout_controle_claude, "ok")
                return original(s, role, consigne, dossier, budget_usd, max_tours, modele)
            lanceur.AdaptateurIdeationSimule.lancer = lancer
        return lanceur

    def env_propre(self):
        return {k: v for k, v in os.environ.items() if k in self.ENV}

    def principal(self, lanceur, argv):
        """Appelle le lanceur dans un environnement sans variable de clé ; rend (code, sortie, erreur)."""
        import contextlib
        import io
        import unittest.mock
        out, err = io.StringIO(), io.StringIO()
        with unittest.mock.patch.dict(os.environ, self.env_propre(), clear=True), contextlib.redirect_stdout(out), \
                contextlib.redirect_stderr(err):
            code = lanceur.principal(argv)
        return code, out.getvalue(), err.getvalue()

    def prep_devis(self):
        """Pièces des essais, matériau attesté : réglages du devis v7 quinquies (seconde passe, Argon proposeur et juge)."""
        prep = self.cours().preparer()
        att = os.path.join(self.tmp, "att-materiau.json")
        idn.ecrire_json_scelle(att, {"lecteur": "Lazar", "lu_le": "2026-10-29", "materiau_sha256": {
            os.path.basename(prep["materiau"][0]): idn.sha256_fichier(prep["materiau"][0])}})
        return prep, att

    def base(self, sortie, prep, att=None, *options):
        b = [sortie, "--liste-blanche", prep["liste_blanche"], "--question", prep["question"], "--piece", prep["pieces"][0],
             "--temoins", prep["temoins"], "--proposeur-externe", "argon=gemini-argon", "--juge-externe", "argon-j=gemini-argon"]
        if att:
            b += ["--materiau", prep["materiau"][0], "--seconde-passe", "--attestation-materiau", att]
        return b + list(options)

    def script(self, corps, nom):
        return " ".join(self.cmd().commande(corps, nom))

    SCRIPT_PLAFOND = (  # Argon au pire cas : chaque appel rend son plafond de session
        "import sys, json, os\nc = sys.stdin.read()\ncout = float(os.environ['PLAFOND_SESSION_USD'])\n"
        "if c.startswith('Réponds exactement OK'): print(json.dumps({'texte': 'OK', 'cout_usd': cout})); sys.exit(0)\n"
        "if os.environ['ROLE_POLE'] == 'juge_ideation':\n"
        "    import re\n"
        "    bloc = json.loads(re.search(r'```json\\n(\\[.*\\])\\n```', c, re.S).group(1)); par_nom = {f['nom']: f['identifiant'] for f in bloc}\n"
        "    notes = []\n"
        "    for f in bloc:\n"
        "        k = {x: 2 for x in ('avantage', 'originalite', 'falsifiabilite', 'traitabilite', 'robustesse')}\n"
        "        if f['nom'] in ('Verbeux vide', 'Assuré occupé'): k.update({'avantage': 1, 'originalite': 0, 'falsifiabilite': 0})\n"
        "        notes.append({'identifiant': f['identifiant'], 'criteres': k, 'justifications': {}})\n"
        "    d = [[par_nom['Jumeau'], par_nom['Sobre fort']]]\n"
        "    print(json.dumps({'texte': '```json\\n' + json.dumps({'notes': notes, 'doublons': d}) + '\\n```', 'cout_usd': cout})); sys.exit(0)\n"
        "f1 = json.loads(%r); f2 = dict(f1, nom='Argon B')\n"
        "if 'première passe' in c: f1['nom'] = 'Argon A revue'; f2['nom'] = 'Argon B revue'\n"
        "print(json.dumps({'texte': '```json\\n' + json.dumps({'fiches': [f1, f2]}, ensure_ascii=False) + '\\n```', "
        "'cout_usd': cout}))\n") % json.dumps(fiche_brute(nom="Argon A"), ensure_ascii=False)

    # --- CL40-02 ---------------------------------------------------------------------------------------------------------

    def test_controle_interrompu_compte_le_plafond_et_garde_les_lectures(self):
        """CL40-02 : une exception au contrôle du second modèle compte son plafond et garde la lecture (et le coût) du
        premier ; une interruption remonte telle quelle, lectures jointes ; une clé dans l'environnement (rien lancé) compte 0."""
        from pole.relais import CleDansEnvironnement

        class Panne:
            nom = "panne"

            def __init__(self, exc):
                self.exc = exc

            def lancer(self, role, consigne, dossier, budget_usd, max_tours, modele=None):
                if modele == "claude-opus-5-5":
                    raise self.exc
                return Resultat("OK", [], 0.01, "ok")
        sortie = os.path.join(self.tmp, "ctrl-int")
        modeles = ["claude-fable-5-1", "claude-opus-5-5"]
        with self.assertRaises(idn.ControleRefuse) as cm:
            idn.appel_de_controle(Panne(RuntimeError("panne de l'adaptateur")), modeles, sortie, 0.2)
        lec = cm.exception.lecture
        self.assertAlmostEqual(lec["claude-fable-5-1"]["cout_compte_usd"], 0.01)  # premier modèle : payé, gardé
        self.assertEqual(lec["claude-opus-5-5"]["statut"], "interrompue")
        self.assertAlmostEqual(idn.cout_compte_controle(lec["claude-opus-5-5"]), 0.2)  # plafond, jamais 0
        self.assertTrue(lec["claude-opus-5-5"]["cout_inconnu"])
        self.assertAlmostEqual(sum(idn.cout_compte_controle(c) for c in lec.values()), 0.21)
        with self.assertRaises(KeyboardInterrupt) as cm2:
            idn.appel_de_controle(Panne(KeyboardInterrupt("signal 15")), modeles, sortie, 0.2)
        self.assertAlmostEqual(sum(idn.cout_compte_controle(c) for c in cm2.exception.lecture.values()), 0.21)
        with self.assertRaises(CleDansEnvironnement) as cm3:  # levée avant tout lancement : rien compté
            idn.appel_de_controle(Panne(CleDansEnvironnement("clé")), modeles, sortie, 0.2)
        self.assertEqual(idn.cout_compte_controle(cm3.exception.lecture["claude-opus-5-5"]), 0.0)
        self.assertTrue(cm3.exception.lecture["claude-opus-5-5"]["non_lance"])
        # cas sain inchangé
        self.assertEqual(idn.appel_de_controle(Panne(None), ["claude-fable-5-1"], sortie, 0.2)["claude-fable-5-1"]["problemes"], [])

    def _attendre_pids(self, pid_f, p):
        import time
        for _ in range(150):
            if os.path.exists(pid_f) and _lire(pid_f).strip():
                return
            time.sleep(0.1)
        p.kill()
        p.communicate()
        self.fail("la commande lente n'a pas démarré")

    def _morts(self, pids):
        import time
        for pe in pids:
            for _ in range(50):
                try:
                    with open(f"/proc/{pe}/status") as f:
                        if any(l.startswith("State:") and "Z" in l for l in f):
                            break
                except OSError:
                    break
                time.sleep(0.1)
            else:
                os.kill(pe, 9)
                self.fail(f"processus {pe} survivant au SIGTERM")

    SCRIPT_LENT_CONTROLE = (
        "import sys, json, os, subprocess, time\nc = sys.stdin.read()\n"
        "if c.startswith('Réponds exactement OK'):\n"
        "    p = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(60)'])\n"
        "    open(%r, 'w').write(str(os.getpid()) + ' ' + str(p.pid)); time.sleep(60)\n"
        "print(json.dumps({'texte': 'x', 'cout_usd': 0.1}))\n")

    def test_sigterm_pendant_le_controle_de_la_course(self):
        """CL40-02 (S3) : SIGTERM pendant le contrôle d'Argon dans la course → code 2, tentative scellée au plafond de la
        session de contrôle (2,5 chez Argon), message vrai, commande et petit-enfant arrêtés."""
        import signal
        import subprocess
        prep = self.cours().preparer()
        pid_f = os.path.join(self.tmp, "ctrl.pid")
        lent = self.script(self.SCRIPT_LENT_CONTROLE % pid_f, "lent-ctrl.py")
        sortie = os.path.join(self.tmp, "l-sig-ctrl")
        chemin = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "demonstrations", "ideation_v1.py")
        p = subprocess.Popen([sys.executable, "-I", "-B", chemin] + self.base(sortie, prep) + ["--commande-externe", lent],
                             env=self.env_propre(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self._attendre_pids(pid_f, p)
        p.send_signal(signal.SIGTERM)
        _, err = p.communicate(timeout=30)
        err = err.decode("utf-8", "replace")
        self.assertEqual(p.returncode, 2, err)
        self.assertIn("contrôle compris", err)
        with open(os.path.join(sortie + "-controle", "tentative-1.json")) as f:
            r = json.load(f)["reglages"]
        self.assertTrue(idn.verifier_scelle(os.path.join(sortie + "-controle", "tentative-1.json")))
        self.assertAlmostEqual(r["cout_externe_usd"], 2.5)  # v40 : 0,0
        self.assertEqual(r["lectures"]["externe:argon"]["statut"], "interrompue")
        self.assertIn("tentative_scellee", err)
        self._morts([int(x) for x in _lire(pid_f).split()])

    def test_sigterm_pendant_le_controle_du_bras(self):
        """CL40-02 (S3b) : SIGTERM pendant le contrôle du bras → code 2, bras-tentative scellée au plafond du contrôle
        (0,2), `relancable` calculé, commande et petit-enfant arrêtés."""
        import signal
        import subprocess
        prep = self.cours().preparer()
        sortie = os.path.join(self.tmp, "l-bras-sig")
        code, out, err = self.principal(self.lanceur(), self.base(sortie, prep) + ["--commande-externe",
                                                                                   " ".join(self.cmd().commande(self.cmd().SCRIPT_OK))])
        self.assertEqual(code, 0, out + err)
        att = self.cmd().attester(os.path.join(self.tmp, "att-bras-sig.json"), sortie, "argon-j")
        pid_f = os.path.join(self.tmp, "bras.pid")
        lent = self.script(self.SCRIPT_LENT_CONTROLE % pid_f, "lent-bras.py")
        chemin = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "demonstrations", "ideation_v1.py")
        p = subprocess.Popen([sys.executable, "-I", "-B", chemin, sortie, "--bras-rapporte-differe", "--attestation-lecture-humaine",
                              att, "--juge-externe", "argon-j=gemini-argon", "--commande-externe", lent],
                             env=self.env_propre(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self._attendre_pids(pid_f, p)
        p.send_signal(signal.SIGTERM)
        _, err = p.communicate(timeout=30)
        err = err.decode("utf-8", "replace")
        self.assertEqual(p.returncode, 2, err)
        self.assertIn("interruption", err)
        chemin_t = os.path.join(sortie, "bras-tentative-1.json")
        self.assertTrue(idn.verifier_scelle(chemin_t))
        with open(chemin_t) as f:
            r = json.load(f)["reglages"]
        self.assertAlmostEqual(r["journal"]["cout_total_usd"], 0.2)  # v40 : 0,0
        self.assertTrue(r["relancable"])  # 11,6 ≥ course + 0,2 + 3,5 + 0,2 : relance calculée possible
        self.assertFalse(os.path.exists(os.path.join(sortie, "manifeste-bras-rapporte.json")))
        self._morts([int(x) for x in _lire(pid_f).split()])

    # --- CL40-03 ---------------------------------------------------------------------------------------------------------

    def test_s9_meme_controle_du_bras_et_refus_du_coeur_scelle(self):
        """CL40-03 (S9) : `--budget-controle-usd 0.1 --budget-externe-usd 11.1`, Argon au pire cas, seconde passe : le
        lanceur et le cœur comptent le même contrôle du bras (0,1) → la course part. Un refus du cœur après des contrôles
        payés (contrôle Claude rendu « ok » au-dessus de son plafond) écrit une tentative scellée avec les coûts, relance
        calculée impossible et refusée avant tout contrôle."""
        prep, att = self.prep_devis()
        argon = self.script(self.SCRIPT_PLAFOND, "argon-plafond.py")
        sortie = os.path.join(self.tmp, "l-s9")
        code, out, err = self.principal(self.lanceur(), self.base(sortie, prep, att, "--commande-externe", argon,
                                                                   "--budget-controle-usd", "0.1", "--budget-externe-usd", "11.1"))
        self.assertIn(code, (0, 4), err)  # v40 : 2, « somme des plafonds externes 11.20 > total externe 11.1 »
        with open(os.path.join(sortie, "manifeste-depart.json")) as f:
            sommes = json.load(f)["reglages"]["somme_des_plafonds"]
        self.assertAlmostEqual(sommes["budget_controle_bras_usd"], 0.1)
        self.assertAlmostEqual(sommes["externe_avec_controle_du_bras"], 11.1)  # 2,5 + 2 × 2,5 + 3,5 + 0,1
        self.assertFalse(os.path.exists(os.path.join(sortie + "-controle", "tentative-1.json")))
        # le bras, lancé sans répéter l'option, joue le contrôle que la course a compté (0,1) : Argon 7,5 + 0,1 + 3,5 = 11,1
        att_b = self.cmd().attester(os.path.join(self.tmp, "att-s9.json"), sortie, "argon-j")
        code, out, err = self.principal(self.lanceur(), [sortie, "--bras-rapporte-differe", "--attestation-lecture-humaine", att_b,
                                                         "--juge-externe", "argon-j=gemini-argon", "--commande-externe", argon])
        self.assertIn(code, (0, 4), err)  # avant : refus « 7,5 + 3,7 > 11,1 » (contrôle du bras repris à 0,2)
        with open(os.path.join(sortie, "manifeste-bras-rapporte.json")) as f:
            jb = json.load(f)["reglages"]["journal"]
        self.assertAlmostEqual(jb["controle"]["argon-j"]["cout_compte_usd"], 0.1)
        self.assertAlmostEqual(jb["cout_externe_deja_compte_course_usd"] + jb["cout_total_usd"], 11.1)
        # refus du cœur après les contrôles payés (SUPPOSÉ : un contrôle « ok » au-dessus de son plafond, 0,5 > 0,2)
        sortie2 = os.path.join(self.tmp, "l-coeur")
        args2 = self.base(sortie2, prep, att, "--commande-externe", argon)
        code, out, err = self.principal(self.lanceur(cout_controle_claude=0.5), args2)
        self.assertEqual(code, 2)
        self.assertIn("somme des plafonds Claude", err)
        self.assertFalse(os.path.exists(sortie2))
        chemin_t = os.path.join(sortie2 + "-controle", "tentative-1.json")
        self.assertTrue(idn.verifier_scelle(chemin_t))  # v40 : aucune trace
        with open(chemin_t) as f:
            r = json.load(f)["reglages"]
        self.assertAlmostEqual(r["cout_claude_usd"], 1.0)
        self.assertAlmostEqual(r["cout_externe_usd"], 2.5)
        self.assertFalse(r["relancable"])
        code, out, err = self.principal(self.lanceur(cout_controle_claude=0.5), args2)  # relance : refus avant tout contrôle
        self.assertEqual(code, 2)
        self.assertFalse(os.path.exists(os.path.join(sortie2 + "-controle", "tentative-2.json")))
        self.assertFalse(os.path.exists(os.path.join(sortie2 + "-controle", "tentative-2")))

    # --- CL40-04 ---------------------------------------------------------------------------------------------------------

    def test_controle_a_la_taille_reelle_de_la_passe_2_et_ordre_d_argon(self):
        """CL40-04 (S5) : le contrôle d'Argon porte sa consigne de passe 2 au maximum (fiches à la taille maximale champ par
        champ × nombre, matériau) ; une passe 2 réelle à champs de 3 000 caractères n'est pas plus grosse que le contrôle ;
        sans matériau la seconde passe compte aussi ses fiches ; Argon joue sa passe 2 juste après sa passe 1, avant toute
        passe Claude. **Changé en v43** (CL42-04, décision de Lazar : « retirer » la borne de fiche) : retour aux assertions de
        la v41 — fiche maximale de plus de 13 × 3 000 caractères, grosse fiche d'Argon à quatre champs de 3 000 (v42 : 12 000
        et trois champs)."""
        c = self.cours()
        prep = c.preparer()
        c._prep = prep
        att = os.path.join(self.tmp, "att-m.json")
        idn.ecrire_json_scelle(att, {"lecteur": "Lazar", "lu_le": "2026-10-29", "materiau_sha256": {
            os.path.basename(prep["materiau"][0]): idn.sha256_fichier(prep["materiau"][0])}})
        budgets = dict(c.budgets())
        budgets[("proposeur_ideation", "gemini-argon")] = 1.0
        args = dict(liste_blanche=prep["liste_blanche"], question=prep["question"], pieces=prep["pieces"], temoins=prep["temoins"],
                    budgets=budgets, proposeurs=[("opus", "claude-opus-5-5"), ("fable", "claude-fable-5-1")],
                    juges=[("juge-fable", "claude-fable-5-1"), ("juge-opus", "claude-opus-5-5")],
                    proposeurs_externes=[("argon", "gemini-argon")], budget_total_usd=20.0, budget_externe_usd=5.0,
                    nombre_par_proposeur=8)
        taille_fiche = len(json.dumps([idn.fiche_maximale()], ensure_ascii=False, indent=1))
        self.assertGreater(taille_fiche, 13 * idn.LONGUEUR_MAX_CHAMP)  # v43 (CL42-04) : comme la v41 (v42 : 12 000)
        v2 = idn.verifier_reglages(materiau=prep["materiau"], seconde_passe=True, attestation_materiau=att, **args)
        self.assertGreater(len(v2["texte_controle_externe"]), 8 * taille_fiche)  # v40 : 8 × 4 000
        self.assertIn("Tour interne", v2["texte_controle_externe"])
        v2b = idn.verifier_reglages(seconde_passe=True, **args)  # sans matériau : les fiches de passe 1 comptent
        self.assertGreater(len(v2b["texte_controle_externe"]), 8 * taille_fiche)
        v1 = idn.verifier_reglages(**args)
        self.assertLess(len(v1["texte_controle_externe"]), taille_fiche)
        # une passe 2 réelle aux champs de 3 000 caractères (8 fiches) n'est pas plus grosse que la consigne de contrôle
        # (v43 : quatre champs de 3 000, comme la v41 ; v42 : trois, sous la borne de 12 000 retirée)
        controle = idn.consigne_de_controle(v2["texte_controle_externe"])
        grosse = fiche_brute(nom="Argon gros")
        for k in ("enonce", "perte_traduction", "piege", "cosmetique_si"):
            grosse[k] = "y" * idn.LONGUEUR_MAX_CHAMP
        ordre = []

        class Argon:
            nom = "argon-simule"

            def lancer(self, role, consigne, dossier, budget_usd, max_tours, modele=None):
                ordre.append(("argon", os.path.basename(dossier), len(consigne)))
                fiches = [dict(grosse, nom=f"Argon {i}") for i in range(8)]
                return Resultat("```json\n" + json.dumps({"fiches": fiches}, ensure_ascii=False) + "\n```", [], 0.1, "ok")
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]},
                            notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        orig = ad.lancer

        def lancer_note(role, consigne, dossier, budget_usd, max_tours, modele=None):
            if role == "proposeur_ideation":
                ordre.append(("claude", os.path.basename(dossier), len(consigne)))
            return orig(role, consigne, dossier, budget_usd, max_tours, modele)
        ad.lancer = lancer_note
        res = c.lancer(ad, "c-ordre", budgets=budgets, proposeurs_externes=[("argon", "gemini-argon", Argon())],
                       budget_externe_usd=5.0, seconde_passe=True, attestation_materiau=att)
        self.assertEqual([(q, d) for q, d, _ in ordre][:2], [("argon", "passe-1"), ("argon", "passe-2")])  # v40 : Claude avant
        self.assertEqual([(q, d) for q, d, _ in ordre][2:], [("claude", "passe-1")] * 2 + [("claude", "passe-2")] * 2)
        self.assertLessEqual(ordre[1][2], len(controle))  # la passe 2 réelle tient dans la taille éprouvée
        # ordre des fiches écrites inchangé : passe 1 (Argon, opus, fable) puis passe 2
        self.assertEqual([f["passe"] for f in res["fiches"]], [1] * 10 + [2] * 10)
        self.assertEqual(res["fiches"][0]["auteur"], "argon")

    def test_controle_du_bras_porte_la_consigne_du_juge(self):
        """CL40-04 (S6), **inversé en v42** (CL41-01, option B de session-depot) : le contrôle du bras redevient court (41
        caractères, aucune fiche) ; la consigne du juge n'est envoyée qu'à la session du juge, telle quelle."""
        c = self.cours()
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]},
                            notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        budgets = dict(c.budgets())
        budgets[("juge_ideation", "autre-lignee-x")] = 1.0
        c.lancer(ad, "cb", budgets=budgets, juges_externes=[("argon", "autre-lignee-x")], budget_externe_usd=2.0)
        sortie = os.path.join(self.tmp, "cb")
        att = self.cmd().attester(os.path.join(self.tmp, "att-cb.json"), sortie)
        with open(os.path.join(sortie, "juges-bras-rapporte", "traces-argon", "consigne-en-attente.md"), encoding="utf-8") as f:
            consigne_juge = f.read()
        recu = []

        class Enregistre:
            nom = "commande-externe"

            def lancer(self, role, consigne, dossier, budget_usd, max_tours, modele=None):
                recu.append(consigne)
                if consigne.startswith(idn.APPEL_DE_CONTROLE_CONSIGNE):
                    return Resultat("OK", [], 0.01, "ok")
                return Resultat("```json\n" + json.dumps(c.notes_temoins_ok(
                    sorted(set(re.findall(r'"identifiant": "(T\d\d)"', consigne))), consigne)) + "\n```", [], 0.3, "ok")

            def description(self):
                return {"commande": ["enregistre"]}
        apres = idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                          juges_externes=[("argon", "autre-lignee-x", Enregistre())])
        self.assertEqual(recu[0], idn.APPEL_DE_CONTROLE_CONSIGNE)  # v41 : la consigne du juge entière
        self.assertNotIn(consigne_juge, recu[0])
        self.assertEqual(apres["journal"]["controle"]["argon"]["taille_consigne"], len(idn.APPEL_DE_CONTROLE_CONSIGNE))
        self.assertEqual(recu[1], consigne_juge)
        self.assertFalse(apres["sans_bras"])

    # --- CL40-01 (code) : relance calculée, contrôle Claude payé ; tolérances ------------------------------------------

    SCRIPT_KO = "import sys, json\nc = sys.stdin.read()\nopen(%r, 'a').write('appel\\n')\nprint(json.dumps({'texte': 'KO', 'cout_usd': 0.15}))\n"
    SCRIPT_CTRL_OK = "import sys, json\nc = sys.stdin.read()\nopen(%r, 'a').write('appel\\n')\nprint(json.dumps({'texte': 'OK', 'cout_usd': 0.15}))\n"

    def test_relancable_calcule_avec_un_controle_claude_paye(self):
        """CL40-01 (code), point 6 : contrôle Claude payé (0,01 puis 0,2 par modèle), réglages du devis v7 quinquies (somme
        Claude 40,0 exactement), Argon « OK » à 0,15, le second contrôle Claude « KO » (payé). **Changé en v43** (CL40-01,
        option c, décision de Lazar : les contrôles réussis ne sont pas rejoués) : la somme de la relance compte les coûts
        imputés et le seul contrôle à refaire — 0,02 + 0,2 + 39,6 = 39,82 ≤ 40, relançable, et la relance ne rejoue que le
        contrôle « KO » (Argon et le premier contrôle Claude repris) ; à 0,2 : 0,4 + 0,2 + 39,6 = 40,2 > 40, non relançable,
        relance refusée avant tout contrôle. Total relevé à 41 : trois tentatives au plus, Argon appelé une seule fois.
        (v42 : relance 40,02 et 40,4, non relançable ; la relance à 41 rejouait tous les contrôles, Argon trois fois.)"""
        prep, att = self.prep_devis()
        for cout, somme, relancable in ((0.01, "39.8200", True), (0.2, "40.2000", False)):
            journal = os.path.join(self.tmp, f"ko-{cout}.log")
            ko = self.script(self.SCRIPT_CTRL_OK % journal, f"ko-{cout}.py")
            sortie = os.path.join(self.tmp, f"l-paye-{cout}")
            argv = self.base(sortie, prep, att, "--commande-externe", ko)
            code, out, err = self.principal(self.lanceur(cout_controle_claude=cout, ko_claude="claude-opus-5-5"), argv)
            self.assertEqual(code, 2)
            chemin = os.path.join(sortie + "-controle", "tentative-1.json")
            self.assertTrue(idn.verifier_scelle(chemin))
            with open(chemin) as f:
                r = json.load(f)["reglages"]
            self.assertAlmostEqual(r["cout_claude_usd"], 2 * cout)
            self.assertAlmostEqual(r["cout_externe_usd"], 0.15)
            self.assertEqual(r["relancable"], relancable, r["motifs_relance"])
            self.assertEqual(r["controles_a_refaire"], ["claude-opus-5-5"])
            self.assertAlmostEqual(r["sommes_de_la_relance_hors_cette_tentative"]["claude"], 39.8)
            if not relancable:
                self.assertTrue(any(somme in m for m in r["motifs_relance"]), r["motifs_relance"])
                self.assertIn('"relancable": false', err)
            self.assertNotIn("trois tentatives", err)
            n = len(_lire(journal).splitlines())
            code, out, err = self.principal(self.lanceur(cout_controle_claude=cout, ko_claude="claude-opus-5-5"), argv)
            self.assertEqual(code, 2)
            self.assertEqual(len(_lire(journal).splitlines()), n)  # Argon jamais rappelé (refus, ou contrôle repris)
            if relancable:  # la relance ne rejoue que le contrôle « KO »
                with open(os.path.join(sortie + "-controle", "tentative-2.json")) as f:
                    r2 = json.load(f)["reglages"]
                self.assertEqual(sorted(r2["lectures"]), ["claude-opus-5-5"])
                self.assertEqual(sorted(r2["controles_repris"]), ["claude-fable-5-1", "externe:argon"])
                self.assertEqual({v["repris_de_tentative"] for v in r2["controles_repris"].values()}, {1})
                self.assertAlmostEqual(r2["cout_claude_usd"], cout)
                self.assertEqual(r2["cout_externe_usd"], 0.0)
            else:
                self.assertIn("somme des plafonds Claude", err)
                self.assertFalse(os.path.exists(os.path.join(sortie + "-controle", "tentative-2.json")))
        # total relevé à 41 : relance calculée possible, seul le contrôle « KO » rejoué (bornée à trois)
        journal = os.path.join(self.tmp, "ko-41.log")
        ko = self.script(self.SCRIPT_CTRL_OK % journal, "ko-41.py")
        sortie = os.path.join(self.tmp, "l-paye-41")
        argv = self.base(sortie, prep, att, "--commande-externe", ko, "--budget-total-usd", "41", "--budget-externe-usd", "12")
        for n in (1, 2, 3):  # sommes de la relance : 40,2 ; 40,4 ; 40,6 (≤ 41) ; la troisième atteint la borne
            code, _, err = self.principal(self.lanceur(cout_controle_claude=0.2, ko_claude="claude-opus-5-5"), argv)
            self.assertEqual(code, 2)
            with open(os.path.join(sortie + "-controle", f"tentative-{n}.json")) as f:
                r = json.load(f)["reglages"]
            self.assertEqual(r["relancable"], n < 3, r["motifs_relance"])
        self.assertIn("3 tentatives faites", r["motifs_relance"][0])
        code, _, err = self.principal(self.lanceur(cout_controle_claude=0.2, ko_claude="claude-opus-5-5"), argv)
        self.assertEqual(code, 2)
        self.assertIn("tentatives", err)
        self.assertEqual(len(_lire(journal).splitlines()), 1)  # v42 : 3

    def test_tolerances_separees(self):
        """CL40-01 (code), point 5 : la tolérance Claude ne désarme pas la somme externe, et inversement ; l'ancienne option
        vaut les deux et est consignée au manifeste."""
        c = self.cours()
        prep = c.preparer()
        c._prep = prep
        budgets = dict(c.budgets())
        budgets[("proposeur_ideation", "gemini-argon")] = 1.0
        budgets[("juge_ideation", "autre-lignee-x")] = 1.0
        base = dict(liste_blanche=prep["liste_blanche"], question=prep["question"], pieces=prep["pieces"], temoins=prep["temoins"],
                    budgets=budgets, proposeurs=[("opus", "claude-opus-5-5"), ("fable", "claude-fable-5-1")],
                    juges=[("juge-fable", "claude-fable-5-1"), ("juge-opus", "claude-opus-5-5")],
                    proposeurs_externes=[("argon", "gemini-argon")], juges_externes=[("argon-j", "autre-lignee-x")])
        # Claude au-dessus (4 > 3), externe au-dessus (2,2 > 2,0)
        idn.verifier_reglages(budget_total_usd=3.0, budget_externe_usd=2.2, tolerer_somme_claude=True, **base)
        with self.assertRaises(idn.CourseInterrompue) as cm:
            idn.verifier_reglages(budget_total_usd=4.0, budget_externe_usd=2.0, tolerer_somme_claude=True, **base)
        self.assertIn("externes", str(cm.exception))
        idn.verifier_reglages(budget_total_usd=4.0, budget_externe_usd=2.0, tolerer_somme_externe=True, **base)
        with self.assertRaises(idn.CourseInterrompue) as cm:
            idn.verifier_reglages(budget_total_usd=3.0, budget_externe_usd=2.2, tolerer_somme_externe=True, **base)
        self.assertIn("Claude", str(cm.exception))
        idn.verifier_reglages(budget_total_usd=3.0, budget_externe_usd=2.0, tolerer_somme_plafonds=True, **base)
        # au cœur
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]})
        ext = dict(budgets=budgets, juges_externes=[("argon-j", "autre-lignee-x")])
        with self.assertRaises(idn.CourseInterrompue) as cm:
            c.lancer(ad, "t-c", budget_total_usd=3.0, budget_externe_usd=1.0, tolerer_somme_claude=True, **ext)
        self.assertIn("externes", str(cm.exception))
        self.assertEqual(ad.appels, [])
        # lanceur : options séparées, ancienne option consignée
        lanceur = self.lanceur()
        sortie = os.path.join(self.tmp, "l-tol")
        argv = self.base(sortie, prep, None, "--budget-externe-usd", "11.6", "--tolerer-somme-plafonds")
        code, out, err = self.principal(lanceur, argv)
        self.assertEqual(code, 0, err)
        with open(os.path.join(sortie, "manifeste-depart.json")) as f:
            d = json.load(f)["reglages"]
        self.assertEqual(d["versions"]["tolerances"], {"claude": True, "externe": True, "option_ancienne_les_deux": True})
        self.assertTrue(d["somme_des_plafonds"]["toleree_claude"] and d["somme_des_plafonds"]["toleree_externe"])
        a = lanceur.construire_analyseur()
        ns = a.parse_args(["s", "--tolerer-somme-plafonds-externe"])
        self.assertEqual(idn.tolerances(ns.tolerer_somme_plafonds, ns.tolerer_somme_plafonds_claude,
                                        ns.tolerer_somme_plafonds_externe), (False, True))

    # --- CL40-05 ---------------------------------------------------------------------------------------------------------

    def test_chemin_de_l_argent_valeurs_non_finies(self):
        """CL40-05 : `budget_controle_bras_usd` (réglages, cœur, bras), champs du relais, coûts et sceaux des tentatives :
        NaN, ±∞, négatif, booléen refusés ; cas sains acceptés."""
        c = self.cours()
        prep = c.preparer()
        c._prep = prep
        budgets = dict(c.budgets())
        budgets[("juge_ideation", "autre-lignee-x")] = 1.0
        base = dict(liste_blanche=prep["liste_blanche"], question=prep["question"], pieces=prep["pieces"], temoins=prep["temoins"],
                    budgets=budgets, proposeurs=[("opus", "claude-opus-5-5"), ("fable", "claude-fable-5-1")],
                    juges=[("juge-fable", "claude-fable-5-1"), ("juge-opus", "claude-opus-5-5")],
                    juges_externes=[("argon-j", "autre-lignee-x")], budget_total_usd=4.0, budget_externe_usd=1.2)
        for x in (float("nan"), -float("inf"), -5.0, True):  # v40 : −5,0 faisait passer 1,2 de plafonds sous un total de 6,0
            with self.subTest(budget_controle_bras_usd=x), self.assertRaises(idn.CourseInterrompue):
                idn.verifier_reglages(budget_controle_bras_usd=x, **base)
            with self.subTest(coeur=x), self.assertRaises(idn.CourseInterrompue):
                c.lancer(FauxAdaptateur({}), f"nf-{x}", budgets=budgets, juges_externes=[("argon-j", "autre-lignee-x")],
                         budget_externe_usd=1.2, budget_controle_bras_usd=x)
        idn.verifier_reglages(budget_controle_bras_usd=0.2, **base)  # sain
        idn.verifier_reglages(budget_controle_bras_usd=0, **dict(base, budget_externe_usd=1.0))  # sain : nul permis
        # relais
        lanceur = self.lanceur()
        juges = [("a", "claude-opus-5-5"), ("b", "claude-fable-5-1")]
        bj = {("juge_ideation", "claude-opus-5-5"): 4.0, ("juge_ideation", "claude-fable-5-1"): 7.0}
        sain = {"plafond_usd": 44, "reserve_par_appel_usd": 4, "depense_usd": 0.0}
        lanceur.verifier_relais(sain, 40.0, bj, juges)
        for champ, mauvais in (("depense_usd", (float("nan"), -float("inf"), True, -1.0)),
                               ("plafond_usd", (float("nan"), float("inf"), True)),
                               ("reserve_par_appel_usd", (float("nan"), -float("inf"), True))):
            for x in mauvais:
                with self.subTest(champ=champ, valeur=x), self.assertRaises(idn.CourseInterrompue):
                    lanceur.verifier_relais(dict(sain, **{champ: x}), 40.0, bj, juges)
        lanceur.verifier_relais({}, 40.0, bj, juges)  # relais muet : inchangé
        # tentatives de contrôle : sceau, coûts, numérotation, dossier sans tentative
        d = os.path.join(self.tmp, "s-controle")
        os.makedirs(d)
        r = {"reglages": {"cout_claude_usd": 0.4, "cout_externe_usd": 0.15}}
        idn.ecrire_json_scelle(os.path.join(d, "tentative-1.json"), r)
        self.assertEqual(len(lanceur.lire_tentatives_controle(d)), 1)  # sain
        with open(os.path.join(d, "tentative-2.json"), "w") as f:  # sans sceau
            json.dump(r, f)
        with self.assertRaises(idn.CourseInterrompue):
            lanceur.lire_tentatives_controle(d)
        os.remove(os.path.join(d, "tentative-2.json"))
        idn.ecrire_scelle(os.path.join(d, "tentative-2.json"), '{"reglages": {"cout_claude_usd": NaN, "cout_externe_usd": 0}}')
        with self.assertRaises(idn.CourseInterrompue):
            lanceur.lire_tentatives_controle(d)
        for nom in ("tentative-2.json", "tentative-2.json.sha256"):
            os.remove(os.path.join(d, nom))
        idn.ecrire_json_scelle(os.path.join(d, "tentative-2.json"), {"reglages": {"cout_claude_usd": -2.5, "cout_externe_usd": 0}})
        with self.assertRaises(idn.CourseInterrompue):
            lanceur.lire_tentatives_controle(d)
        for nom in ("tentative-2.json", "tentative-2.json.sha256"):
            os.remove(os.path.join(d, nom))
        with open(os.path.join(d, "tentative-1.json"), "a") as f:  # sceau faux
            f.write(" ")
        with self.assertRaises(idn.CourseInterrompue):
            lanceur.lire_tentatives_controle(d)
        d2 = os.path.join(self.tmp, "s2-controle")
        os.makedirs(os.path.join(d2, "tentative-1"))  # dossier de contrôle sans tentative scellée (arrêt brutal, ou retrait)
        with self.assertRaises(idn.CourseInterrompue):
            lanceur.lire_tentatives_controle(d2)
        idn.ecrire_json_scelle(os.path.join(d2, "tentative-2.json"), r)  # numérotation trouée
        with self.assertRaises(idn.CourseInterrompue):
            lanceur.lire_tentatives_controle(d2)
        # bras : tentative payée au sceau absent → refus ; budget du contrôle non fini → refus
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]},
                            notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        c.lancer(ad, "nf-bras", budgets=budgets, juges_externes=[("argon", "autre-lignee-x")], budget_externe_usd=2.0)
        sortie = os.path.join(self.tmp, "nf-bras")
        att = self.cmd().attester(os.path.join(self.tmp, "att-nf.json"), sortie)
        bon = Enregistreur(c)
        with self.assertRaises(idn.CourseInterrompue):
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets, budget_controle_usd=float("nan"),
                                      juges_externes=[("argon", "autre-lignee-x", bon)])
        with open(os.path.join(sortie, "bras-tentative-1.json"), "w") as f:
            json.dump({"reglages": {"journal": {"cout_total_usd": 0.15}}}, f)
        with self.assertRaises(idn.CourseInterrompue) as cm:
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                      juges_externes=[("argon", "autre-lignee-x", bon)])
        self.assertIn("sceau", str(cm.exception))
        self.assertEqual(bon.recu, [])

    # --- CL40-08, CL40-07 (M07) ------------------------------------------------------------------------------------------

    def test_bras_interrompu_apres_envoi_ecrit_le_classement_sans_bras(self):
        """CL40-08 (S8) : interruption pendant la session du juge d'Argon (consigne envoyée) → manifeste, plafond compté,
        `classement-sans-bras.json` à deux juges marqué « sans juge externe », l'interruption remonte, bras verrouillé."""
        c = self.cours()
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]},
                            notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        budgets = dict(c.budgets())
        budgets[("juge_ideation", "autre-lignee-x")] = 1.0
        c.lancer(ad, "ck", budgets=budgets, juges_externes=[("argon", "autre-lignee-x")], budget_externe_usd=2.0)
        sortie = os.path.join(self.tmp, "ck")
        att = self.cmd().attester(os.path.join(self.tmp, "att-ck.json"), sortie)
        coupe = Enregistreur(c, interrompre_juge=True)
        with self.assertRaises(KeyboardInterrupt):
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                      juges_externes=[("argon", "autre-lignee-x", coupe)])
        chemin = os.path.join(sortie, "classement-sans-bras.json")
        self.assertTrue(idn.verifier_scelle(chemin))  # v40 : absent
        with open(chemin) as f:
            cl = json.load(f)
        self.assertFalse(cl["lisible_L2_L4"])
        self.assertIn("interrompu après envoi", cl["sans_juge_externe"])
        self.assertTrue(all(l["nombre_juges"] == 2 for l in cl["lignes"]))
        with open(os.path.join(sortie, "manifeste-bras-rapporte.json")) as f:
            j = json.load(f)["reglages"]["journal"]
        self.assertAlmostEqual(j["cout_total_usd"], 0.01 + 1.0)
        with self.assertRaises(idn.CourseInterrompue):  # verrouillé
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                      juges_externes=[("argon", "autre-lignee-x", Enregistreur(c))])

    def test_m07_controle_du_bras_a_cout_nul_processus_parti(self):
        """CL40-07 (M07) : un contrôle du bras où un processus est parti mais rien n'est compté (exception avec un plafond
        de contrôle nul ; ou « KO » à coût 0 d'un adaptateur fictif) est une **tentative payée** (bornée), jamais « non
        joué » ; seule une commande non lancée ou une clé dans l'environnement donnent « non joué »."""
        c = self.cours()
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]},
                            notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        budgets = dict(c.budgets())
        budgets[("juge_ideation", "autre-lignee-x")] = 1.0
        for nom, adapt, plafond in (("m7a", Enregistreur(c, panne_controle=True), 0.0),
                                    ("m7b", Enregistreur(c, ko_gratuit=True), 0.2)):
            c.lancer(ad, nom, budgets=budgets, juges_externes=[("argon", "autre-lignee-x")], budget_externe_usd=2.0)
            sortie = os.path.join(self.tmp, nom)
            att = self.cmd().attester(os.path.join(self.tmp, f"att-{nom}.json"), sortie)
            with self.assertRaises(idn.CourseInterrompue) as cm:
                idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets, budget_controle_usd=plafond,
                                          exiger_cout_controle=False, juges_externes=[("argon", "autre-lignee-x", adapt)])
            self.assertNotIn("non joué", str(cm.exception), nom)
            self.assertTrue(os.path.exists(os.path.join(sortie, "bras-tentative-1.json")), nom)
            self.assertFalse(os.path.exists(os.path.join(sortie, "manifeste-bras-non-joue-1.json")), nom)

    def test_bras_tentative_relancable_calcule(self):
        """Point 4 (bras) : `relancable` d'une tentative payée du bras est calculé sur le plafond externe de la relance
        (coût de la tentative imputé), pas promis par le seul compte : 0,15 + 0,2 + 1,0 > 1,3 → faux dès la première."""
        c = self.cours()
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]},
                            notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        budgets = dict(c.budgets())
        budgets[("juge_ideation", "autre-lignee-x")] = 1.0
        for nom, total, attendu in (("rb1", 1.3, False), ("rb2", 2.0, True)):
            c.lancer(ad, nom, budgets=budgets, juges_externes=[("argon", "autre-lignee-x")], budget_externe_usd=total)
            sortie = os.path.join(self.tmp, nom)
            att = self.cmd().attester(os.path.join(self.tmp, f"att-{nom}.json"), sortie)
            from pole.adaptateurs import AdaptateurCommandeExterne
            ko = AdaptateurCommandeExterne(self.cmd().commande(
                "import sys, json\nsys.stdin.read()\nprint(json.dumps({'texte': 'KO', 'cout_usd': 0.15}))\n", f"ko-{nom}.py"),
                environnement={})
            with self.assertRaises(idn.CourseInterrompue) as cm:
                idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                          juges_externes=[("argon", "autre-lignee-x", ko)])
            with open(os.path.join(sortie, "bras-tentative-1.json")) as f:
                r = json.load(f)["reglages"]
            self.assertEqual(r["relancable"], attendu, nom)  # v40 : vrai dans les deux cas
            self.assertIn("relance permise" if attendu else "plus de relance", str(cm.exception))

    # --- CL40-09 ---------------------------------------------------------------------------------------------------------

    def test_ecrits_du_lanceur(self):
        """CL40-09 : le devis en vigueur (v7 quinquies) nommé partout ; message d'interruption vrai pour les contrôles ;
        plus de promesse « trois tentatives » sans calcul."""
        chemin = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "demonstrations", "ideation_v1.py")
        with open(chemin, encoding="utf-8") as f:
            texte = f.read()
        for ancien in ("v7 bis", "v7 ter", "v7 quater", "relance permise\", qui", "bornée à trois)"):
            self.assertNotIn(ancien, texte)
        self.assertIn("devis v7 quinquies", texte)
        self.assertIn("contrôle compris", texte)


class Enregistreur:
    """Juge externe d'essai (v41) : enregistre ce qu'il reçoit ; contrôle « OK » à 0,01 ; options : panne au contrôle,
    « KO » gratuit au contrôle, interruption pendant la session du juge."""
    nom = "commande-externe"

    def __init__(self, cours, panne_controle=False, ko_gratuit=False, interrompre_juge=False):
        self.cours, self.recu = cours, []
        self.panne_controle, self.ko_gratuit, self.interrompre_juge = panne_controle, ko_gratuit, interrompre_juge

    def lancer(self, role, consigne, dossier, budget_usd, max_tours, modele=None):
        self.recu.append(consigne)
        if consigne.startswith(idn.APPEL_DE_CONTROLE_CONSIGNE):
            if self.panne_controle:
                raise RuntimeError("panne pendant le contrôle")
            return Resultat("KO" if self.ko_gratuit else "OK", [], 0.0 if self.ko_gratuit else 0.01, "ok")
        if self.interrompre_juge:
            raise KeyboardInterrupt("signal 15")
        idents = sorted(set(re.findall(r'"identifiant": "(T\d\d)"', consigne)))
        return Resultat("```json\n" + json.dumps(self.cours.notes_temoins_ok(idents, consigne)) + "\n```", [], 0.3, "ok")

    def description(self):
        return {"commande": ["enregistreur"]}


class TestReglagesV35(CasAvecDossier):
    def test_options_tools_vides_et_effort(self):
        """CL34-02 / CL34-08 : `tools=[]` (jeu disponible) pour les rôles de l'idéation, effort fixé ; les autres rôles
        gardent le jeu par défaut du kit (None)."""
        dossier = os.path.join(self.tmp, "course", "juges", "j")
        os.makedirs(dossier)
        o = construire_options(dossier, 1.0, 2, url_relais="http://127.0.0.1:8787", modele="claude-opus-5-5",
                               role="juge_ideation", interdire_lecture=[os.path.join(self.tmp, "course")])
        self.assertEqual((o["tools"], o["allowed_tools"], o["effort"]), ([], [], "medium"))
        o = construire_options(dossier, 1.0, 2, url_relais="http://127.0.0.1:8787", modele="claude-opus-5-5",
                               role="experimentateur", interdire_lecture=[os.path.join(self.tmp, "course")])
        self.assertIsNone(o["tools"])
        self.assertIsNone(o["effort"])

    def test_ligne_de_commande_du_kit_sans_outil(self):
        """CL34-02 : la ligne de commande construite par le kit porte `--tools ''` (jamais exécutée)."""
        try:
            import claude_agent_sdk as sdk
            from claude_agent_sdk._internal.transport.subprocess_cli import SubprocessCLITransport
        except ImportError:
            self.skipTest("kit d'agent absent")
        from pole.adaptateurs import AdaptateurClaudeSDK
        dossier = os.path.join(self.tmp, "course", "juges", "j")
        os.makedirs(dossier)
        o = construire_options(dossier, 1.0, 2, url_relais="http://127.0.0.1:8787", modele="claude-opus-5-5",
                               role="juge_ideation", interdire_lecture=[os.path.join(self.tmp, "course")])
        options = AdaptateurClaudeSDK.options_sdk(sdk, o)
        options.cli_path = "/bin/true"
        cmd = SubprocessCLITransport("x", options)._build_command()
        self.assertIn("--tools", cmd)
        self.assertEqual(cmd[cmd.index("--tools") + 1], "")
        self.assertNotIn("--allowedTools", cmd)
        self.assertEqual(cmd[cmd.index("--effort") + 1], "medium")
        for nom in [n for n in sys.modules if n.startswith("claude_agent_sdk")]:  # CL39-12 : ne pas laisser le kit chargé
            del sys.modules[nom]

    def test_borne_de_temps_par_session(self):
        """CL34-05 : une session qui pend au-delà du délai rend « erreur » avec un motif, sans lever."""
        import asyncio
        from pole.adaptateurs import AdaptateurClaudeSDK

        class FauxSDK:
            class ClaudeSDKError(Exception):
                pass

            class AssistantMessage:
                pass

            class ResultMessage:
                pass

            class TextBlock:
                pass

            @staticmethod
            async def query(prompt, options):
                await asyncio.sleep(5)
                yield None
        texte, cout, statut, erreur = asyncio.run(AdaptateurClaudeSDK._executer(FauxSDK, "x", None, delai_s=0.2))
        self.assertEqual((texte, cout, statut), ("", 0.0, "erreur"))
        self.assertIn("délai de session dépassé", erreur)
        with self.assertRaises(ValueError):
            AdaptateurClaudeSDK("http://127.0.0.1:8787", delai_s=0)

    def test_garde_pluriels(self):
        """CL34-10 : pluriels signalés."""
        for texte in ("Étapes 1 : préparer", "les injections de consignes", "des portes dérobées", "exécuter les scripts fournis"):
            self.assertTrue(idn.signaux_niveau_methode(texte), texte)
        self.assertFalse(idn.signaux_niveau_methode("classe exfiltration, nommée par protocole") == [], "signal assumé")


class TestCourseV35(CasAvecDossier):
    def cours(self):
        c = TestCourse("test_course_complete")
        c.tmp = self.tmp
        return c

    def test_nombre_borne_et_controles_comptes(self):
        """CL34-11 : nombre ∉ [1, 12] refusé ; CL34-07 : le coût déjà engagé (contrôles) entre au journal et au plafond."""
        c = self.cours()
        fiches = {"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]}
        ad = FauxAdaptateur(fiches, notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        for n in (0, 13, True):
            with self.assertRaises(idn.CourseInterrompue):
                c.lancer(ad, f"c-{n}", nombre_par_proposeur=n)
        with self.assertRaises(idn.CourseInterrompue):
            c.lancer(ad, "c-neg", cout_deja_engage_usd=-1)
        self.assertEqual(ad.appels, [])
        res = c.lancer(ad, "c-ok", cout_deja_engage_usd=0.07)
        self.assertAlmostEqual(res["journal"]["cout_appels_de_controle_usd"], 0.07)
        self.assertAlmostEqual(res["journal"]["cout_total_usd"], 0.07 + 4 * 0.5)
        c.lancer(ad, "c-juste", budget_total_usd=2.5, tolerer_somme_plafonds=True)  # sans contrôle : 1,5 + 1 = 2,5, passe
        with self.assertRaises(idn.CourseInterrompue):  # 0,07 + 1,5 + 1 > 2,5 : le contrôle compté arrête avant le dernier juge
            c.lancer(ad, "c-plafond", cout_deja_engage_usd=0.07, budget_total_usd=2.5, tolerer_somme_plafonds=True)
        with self.assertRaises(idn.CourseInterrompue):  # CL37-03 : sans tolérance, 4,07 > 4 refusé avant tout appel
            n = len(ad.appels)
            c.lancer(ad, "c-somme", cout_deja_engage_usd=0.07, budget_total_usd=4.0)
        self.assertEqual(len(ad.appels), n)

    def test_taille_max_pieces_bornee(self):
        """v37 : taille des pièces réglable, plafond dur, consignée au manifeste ; hors borne → refus avant tout appel."""
        c = self.cours()
        ad = FauxAdaptateur({"opus": [fiche_brute()], "fable": [fiche_brute()]})
        for t in (0, idn.TAILLE_MAX_PIECES_ABSOLUE + 1, True, 10.0):
            with self.assertRaises(idn.CourseInterrompue):
                c.lancer(ad, f"t-{t}", taille_max_pieces=t)
        self.assertEqual(ad.appels, [])
        with self.assertRaises(idn.PieceInterdite):  # pièces plus longues que le réglage
            c.lancer(ad, "t-court", taille_max_pieces=5)
        res = c.lancer(ad, "t-ok", taille_max_pieces=650_000)
        with open(os.path.join(self.tmp, "t-ok", "manifeste-depart.json")) as f:
            m = json.load(f)["reglages"]
        self.assertEqual(m["taille_max_pieces"], 650_000)
        self.assertGreater(m["taille_pieces_servies"]["proposeurs"], 0)
        self.assertIsNotNone(res["classement"])

    def test_manifeste_de_fin_sur_toute_exception(self):
        """CL34-09 : une exception qui n'est pas CourseInterrompue écrit quand même le manifeste de fin, puis remonte."""
        class AdaptateurQuiCasse(FauxAdaptateur):
            def lancer(self, role, consigne, dossier, budget_usd, max_tours, modele=None):
                raise OSError("relais injoignable")
        c = self.cours()
        ad = AdaptateurQuiCasse({"opus": [fiche_brute()], "fable": [fiche_brute()]})
        with self.assertRaises(OSError):
            c.lancer(ad, "c-casse")
        chemin = os.path.join(self.tmp, "c-casse", "manifeste-fin.json")
        self.assertTrue(os.path.exists(chemin + ".sha256"))
        with open(chemin) as f:
            self.assertIn("OSError", json.load(f)["reglages"]["erreur"])


class TestV42(CasAvecDossier):
    """v42 (contre-lecture CL8 de la v41 ; choix de session-depot, message n° 151) : contrôle du bras court, garde de taille
    sans dépense, plafond externe donné au bras, classement sans juge externe dès qu'une tentative du bras est non
    relançable (CL41-01) ; fiche bornée et marge réaliste (CL41-02) ; consigne de contrôle qui finit par « OK » (CL41-03) ;
    contrôle non court refusé = envoi (CL41-04) ; relais gardé et relancé à neuf (CL41-05) ; fenêtre SORTIE sans manifeste
    (CL41-06) ; Argon contrôlé d'abord (CL41-07) ; un essai par trou de CL41-08 (N03, N04, N07, N08, N13, V12, V20, V34, V36)."""

    def v41(self):
        t = TestV41("test_ecrits_du_lanceur")
        t.tmp = self.tmp
        return t

    def cours(self):
        c = TestCourse("test_course_complete")
        c.tmp = self.tmp
        return c

    def cmd(self):
        c = TestCommandeExterne("test_commande_factice_notes_et_controle")
        c.tmp = self.tmp
        return c

    def journal_de(self, chemin):
        if not os.path.exists(chemin):
            return []
        return [json.loads(l) for l in _lire(chemin).splitlines() if l.strip()]

    # Argon factice au barème haut du code (10 dollars par million de jetons d'entrée à 3 caractères par jeton, plus 2 000
    # jetons de sortie à 50 dollars par million), coût jamais borné par la commande ; chaque appel consigné
    SCRIPT_BAREME = (
        "import sys, json, os, re\nc = sys.stdin.read()\n"
        "ctrl = c.startswith('Réponds exactement OK')\n"
        "open(%r, 'a').write(json.dumps({'taille': len(c), 'controle': ctrl, 'role': os.environ['ROLE_POLE']}) + '\\n')\n"
        "cout = len(c) / 3 * 10e-6 + 2000 * 50e-6\n"
        "if ctrl: print(json.dumps({'texte': 'OK', 'cout_usd': cout})); sys.exit(0)\n"
        "bloc = json.loads(re.search(r'```json\\n(\\[.*\\])\\n```', c, re.S).group(1)); par_nom = {f['nom']: f['identifiant'] for f in bloc}\n"
        "notes = []\n"
        "for f in bloc:\n"
        "    k = {x: 2 for x in ('avantage', 'originalite', 'falsifiabilite', 'traitabilite', 'robustesse')}\n"
        "    if f['nom'] == 'Verbeux vide': k.update({'avantage': 1, 'originalite': 1, 'falsifiabilite': 0})\n"
        "    if f['nom'] == 'Assuré occupé': k.update({'avantage': 1, 'originalite': 0})\n"
        "    notes.append({'identifiant': f['identifiant'], 'criteres': k, 'justifications': {}})\n"
        "d = [[par_nom['Jumeau'], par_nom['Sobre fort']]]\n"
        "print(json.dumps({'texte': '```json\\n' + json.dumps({'notes': notes, 'doublons': d}) + '\\n```', 'cout_usd': cout}))\n")

    def course_avec_piece_juge(self, nom, taille_piece_juge=240_000, versions=None):
        """Course (cœur, faux adaptateur Claude) avec une pièce d'antériorité servie aux juges : consigne du juge externe
        en attente d'environ 243 000 caractères (S6 et S10-grand de CL7 et CL8)."""
        c = self.cours()
        if not hasattr(self, "_prep_pj"):
            self._prep_pj = c.preparer()  # liste blanche scellée une fois par essai (jamais écrasée)
        prep = self._prep_pj
        pj = os.path.join(self.tmp, "piece-juge.md")
        if not os.path.exists(pj):
            with open(pj, "w", encoding="utf-8") as f:
                f.write("# Antériorité\n" + ("Résumé d'article. " * 20000)[:taille_piece_juge])
        lb = os.path.join(self.tmp, "liste-blanche-pj.json")
        if not os.path.exists(lb):
            idn.construire_liste_blanche([prep["pieces"][0], prep["question"], prep["materiau"][0], prep["temoins"], pj], lb)
        c._prep = dict(prep, liste_blanche=lb)
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]},
                            notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        budgets = dict(c.budgets())
        budgets[("juge_ideation", "gemini-argon")] = 3.5
        c.lancer(ad, nom, budgets=budgets, juges_externes=[("argon", "gemini-argon")], budget_externe_usd=3.7,
                 pieces_juge=[pj], versions=versions)
        sortie = os.path.join(self.tmp, nom)
        att = self.cmd().attester(os.path.join(self.tmp, f"att-{nom}.json"), sortie)
        return sortie, att, budgets

    # --- CL41-01 ---------------------------------------------------------------------------------------------------------

    def test_cl41_01_consigne_du_juge_de_243000_au_bareme_haut(self):
        """CL41-01 (S10-grand) : consigne du juge de 243 000 caractères, Argon au barème haut du code, sans borne à son
        plafond : le contrôle du bras est court (≈ 0,10 < 0,2), le juge joue (≈ 0,91 < 3,5), classement à trois juges
        (v41 : contrôle de 243 000 caractères facturé 0,91 > 0,2, refusé après toute la dépense, aucun classement).
        Variante : garde de taille (donnée, puis par défaut sur un plafond de juge de 0,5) → refus scellé avant tout
        appel, rien payé ; puis le bras se joue.
        **Changé en v43** (CL42-05, choix de session-depot n° 156) : la garde par défaut déduit la provision de sortie du
        juge (6 fiches servies × 2 000 × 5 : 1 400 000 − 60 000) ; chaque refus de taille **compte une tentative non
        relançable** et le premier écrit le classement sans bras (le second ne le réécrit pas) ; le bras se joue donc en
        tentative 3 (v42 : en tentative 1, refus non comptés) ; la taille donnée à la course **ne vaut plus** pour le bras
        (v42 : refus « donnée à la course »)."""
        from pole.adaptateurs import AdaptateurCommandeExterne
        sortie, att, budgets = self.course_avec_piece_juge("c-243k")
        with open(os.path.join(sortie, "juges-bras-rapporte", "traces-argon", "consigne-en-attente.md"), encoding="utf-8") as f:
            taille_juge = len(f.read())
        self.assertGreaterEqual(taille_juge, 243_000)
        journal = os.path.join(self.tmp, "argon-bareme.jsonl")
        argon = AdaptateurCommandeExterne(self.cmd().commande(self.SCRIPT_BAREME % journal, "argon-bareme.py"), environnement={})
        externes = [("argon", "gemini-argon", argon)]
        res = idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets, juges_externes=externes)
        self.assertFalse(res["sans_bras"])
        self.assertTrue(all(l["nombre_juges"] == 3 and l["nom_agregat"] == "mediane" for l in res["classement"]))
        self.assertTrue(idn.verifier_scelle(os.path.join(sortie, "classement.json")))
        appels = self.journal_de(journal)
        self.assertEqual([(a["controle"], a["taille"] if a["controle"] else None) for a in appels],
                         [(True, len(idn.APPEL_DE_CONTROLE_CONSIGNE)), (False, None)])  # contrôle court, puis le juge
        self.assertEqual(appels[1]["taille"], taille_juge)
        ctrl = res["journal"]["controle"]["argon"]
        self.assertLess(ctrl["cout_compte_usd"], 0.2)
        self.assertTrue(ctrl["consigne_courte"])
        self.assertAlmostEqual(res["journal"]["cout_total_usd"], ctrl["cout_compte_usd"] + taille_juge / 3 * 10e-6 + 0.1, places=4)
        self.assertEqual(res["journal"]["garde_taille"]["argon"]["taille_caracteres"], taille_juge)
        # v43 (CL42-05) : 3,5 / 2,5e-6 − provision de sortie (6 fiches servies × 2 000 caractères au rapport 5)
        self.assertEqual(res["journal"]["garde_taille"]["argon"]["taille_max_caracteres"], 1_400_000 - 6 * 10_000)
        self.assertEqual(res["journal"]["garde_taille"]["argon"]["provision_sortie_caracteres"], 60_000)
        # variante : la garde refuse avant toute dépense (taille donnée) ; v43 : tentative 1 non relançable, classement
        # sans bras écrit
        sortie2, att2, _ = self.course_avec_piece_juge("c-243k-garde")
        avant = len(self.journal_de(journal))
        with self.assertRaises(idn.SansJugeExterne) as cm:
            idn.executer_bras_differe(sortie2, attestation_lecture_humaine=att2, budgets=budgets, juges_externes=externes,
                                      taille_max_consigne_externe=100_000)
        self.assertIn("rien payé", str(cm.exception))
        self.assertIsInstance(cm.exception.__cause__, idn.TailleConsigneRefusee)
        self.assertEqual(len(self.journal_de(journal)), avant)  # Argon jamais appelé, pas même au contrôle
        r1 = os.path.join(sortie2, "manifeste-bras-refus-taille-1.json")
        self.assertTrue(idn.verifier_scelle(r1))
        with open(r1) as f:
            g = json.load(f)["reglages"]
        self.assertEqual((g["garde_taille"]["taille_max_caracteres"], g["cout_usd"], g["tentative_comptee"], g["relancable"]),
                         (100_000, 0.0, True, False))
        cl = os.path.join(sortie2, "classement-sans-bras.json")
        empreinte_cl = idn.sha256_fichier(cl)
        # garde par défaut : plafond de juge de 0,5 → 200 000 − 60 000 caractères au plus ; tentative 2, classement gardé
        petit = dict(budgets)
        petit[("juge_ideation", "gemini-argon")] = 0.5
        with self.assertRaises(idn.SansJugeExterne) as cm:
            idn.executer_bras_differe(sortie2, attestation_lecture_humaine=att2, budgets=petit, juges_externes=externes)
        self.assertIn("non réécrit", str(cm.exception))
        r2 = os.path.join(sortie2, "manifeste-bras-refus-taille-2.json")
        self.assertTrue(idn.verifier_scelle(r2))
        with open(r2) as f:
            self.assertEqual(json.load(f)["reglages"]["garde_taille"]["taille_max_caracteres"], 140_000)
        self.assertEqual(idn.sha256_fichier(cl), empreinte_cl)
        self.assertEqual(len(self.journal_de(journal)), avant)
        for nom in os.listdir(sortie2):
            self.assertFalse(nom.startswith(("bras-tentative", "manifeste-bras-non-joue", "manifeste-bras-rapporte",
                                             "bras-rapporte-controle", "classement.json")), nom)
        res2 = idn.executer_bras_differe(sortie2, attestation_lecture_humaine=att2, budgets=budgets, juges_externes=externes)
        self.assertEqual(res2["journal"]["tentative"], 3)  # v43 : les deux refus de taille comptent (v42 : 1)
        self.assertFalse(res2["sans_bras"])
        # v43 : la taille donnée à la course (consignée au manifeste de départ) ne vaut plus pour le bras
        sortie3, att3, _ = self.course_avec_piece_juge("c-243k-option", versions={"taille_max_consigne_externe": {
            "valeur": 200_000, "origine": "option"}})
        res3 = idn.executer_bras_differe(sortie3, attestation_lecture_humaine=att3, budgets=budgets, juges_externes=externes)
        self.assertFalse(res3["sans_bras"])
        self.assertTrue(res3["journal"]["garde_taille"]["argon"]["origine_taille_max"].startswith("défaut"))
        self.assertEqual(len(self.journal_de(journal)), avant + 4)

    def test_cl41_01_plafond_externe_donne_au_bras_et_classement_si_non_relancable(self):
        """CL41-01 : une tentative du bras scellée non relançable écrit tout de suite le classement à deux juges (« sans
        juge externe », code 5), sans verrouiller ; le bras lancé sans `--budget-externe-usd` garde le plafond de la course
        (relance refusée) ; avec `--budget-externe-usd 12` (mot de Lazar), le lanceur le transmet et le bras se joue (v41 :
        code 2 sans classement, `budget_externe_usd=None` toujours passé)."""
        v41 = self.v41()
        prep = self.cours().preparer()
        sortie = os.path.join(self.tmp, "l-nr")
        ok = " ".join(self.cmd().commande(self.cmd().SCRIPT_OK))
        code, out, err = v41.principal(v41.lanceur(), v41.base(sortie, prep, None, "--commande-externe", ok,
                                                                "--budget-externe-usd", "9"))
        self.assertEqual(code, 0, err)
        att = self.cmd().attester(os.path.join(self.tmp, "att-nr.json"), sortie, "argon-j")
        ko = v41.script("import sys, json\nsys.stdin.read()\nprint(json.dumps({'texte': 'KO', 'cout_usd': 5.2}))\n", "ko52.py")
        bras = [sortie, "--bras-rapporte-differe", "--attestation-lecture-humaine", att, "--juge-externe", "argon-j=gemini-argon"]
        code, out, err = v41.principal(v41.lanceur(), bras + ["--commande-externe", ko])
        self.assertEqual(code, 5, err)  # 0,251 + 5,2 + 3,7 > 9 : non relançable
        self.assertIn("classement-sans-bras.json", err)
        cl = os.path.join(sortie, "classement-sans-bras.json")
        self.assertTrue(idn.verifier_scelle(cl))  # v41 : absent
        with open(cl) as f:
            c = json.load(f)
        self.assertFalse(c["lisible_L2_L4"])
        self.assertIn("non relançable", c["sans_juge_externe"])
        self.assertTrue(all(l["nombre_juges"] == 2 for l in c["lignes"]))
        self.assertFalse(os.path.exists(os.path.join(sortie, "manifeste-bras-rapporte.json")))  # pas de verrou
        with open(os.path.join(sortie, "bras-tentative-1.json")) as f:
            self.assertFalse(json.load(f)["reglages"]["relancable"])
        code, out, err = v41.principal(v41.lanceur(), bras + ["--commande-externe", ok])
        self.assertEqual(code, 2)
        self.assertIn("plafond externe 9.0 insuffisant", err)  # plafond relu au manifeste de départ, pas le défaut 11,6
        code, out, err = v41.principal(v41.lanceur(), bras + ["--commande-externe", ok, "--budget-externe-usd", "12"])
        self.assertIn(code, (0, 4), err)
        with open(os.path.join(sortie, "manifeste-bras-rapporte.json")) as f:
            jb = json.load(f)["reglages"]["journal"]
        self.assertEqual(jb["plafond_externe_usd"], 12.0)
        self.assertAlmostEqual(jb["cout_tentatives_precedentes_usd"], 5.2)
        with open(os.path.join(sortie, "classement.json")) as f:
            self.assertTrue(all(l["nombre_juges"] == 3 for l in json.load(f)["lignes"]))
        # une valeur non finie donnée au bras est refusée avant tout appel
        with self.assertRaises(idn.CourseInterrompue):
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets={}, juges_externes=[],
                                      budget_externe_usd=float("nan"))

    def test_cl41_01_classement_apres_le_dernier_bras_non_joue(self):
        """CL41-01 : trois tentatives « non jouées » (commande introuvable : rien envoyé, rien payé) — la troisième est
        scellée non relançable et écrit le classement à deux juges « sans juge externe », sans verrou (v41 : aucun)."""
        from pole.adaptateurs import AdaptateurCommandeExterne
        c = self.cours()
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]},
                            notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        budgets = dict(c.budgets())
        budgets[("juge_ideation", "autre-lignee-x")] = 1.0
        c.lancer(ad, "nj", budgets=budgets, juges_externes=[("argon", "autre-lignee-x")], budget_externe_usd=2.0)
        sortie = os.path.join(self.tmp, "nj")
        att = self.cmd().attester(os.path.join(self.tmp, "att-nj.json"), sortie)
        introuvable = [("argon", "autre-lignee-x", AdaptateurCommandeExterne(["/chemin/qui/n/existe/pas"], environnement={}))]
        for n in (1, 2, 3):
            with self.assertRaises(idn.CourseInterrompue) as cm:
                idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets, juges_externes=introuvable)
            self.assertEqual(isinstance(cm.exception, idn.SansJugeExterne), n == 3, n)
            self.assertEqual(os.path.exists(os.path.join(sortie, "classement-sans-bras.json")), n == 3, n)
        with open(os.path.join(sortie, "classement-sans-bras.json")) as f:
            cl = json.load(f)
        self.assertIn("tentative 3 du bras non relançable", cl["sans_juge_externe"])
        self.assertTrue(all(l["nombre_juges"] == 2 for l in cl["lignes"]))
        self.assertFalse(os.path.exists(os.path.join(sortie, "manifeste-bras-rapporte.json")))

    def test_cl41_01_garde_de_taille_de_la_course_avant_tout_controle(self):
        """CL41-01 (course) : consigne de contrôle d'Argon plus grosse que `--taille-max-consigne-externe` (donnée, puis par
        défaut : `--budget-controle-externe-usd` / prix prudent) → code 2, refus scellé dans SORTIE-controle, aucun
        contrôle (ni Argon ni Claude), aucune tentative ; la relance sans l'option passe et consigne la valeur par défaut.
        **Changé en v43** (CL42-01) : défaut 520 000 caractères (contrôle 2,5 → 1 000 000 ; passe 2,5 → 1 000 000 moins la
        provision de sortie de 480 000 ; le plus petit) ; v42 : 1 000 000. Le second cas (contrôle à 0,001 → 400) est
        inchangé : le contrôle, entrée seule, y est la session la plus petite."""
        v41 = self.v41()
        prep = self.cours().preparer()
        journal = os.path.join(self.tmp, "argon-garde.jsonl")
        argon = v41.script(self.cmd().SCRIPT_OK.replace("consigne = sys.stdin.read()\n", "consigne = sys.stdin.read()\n"
                                                        "open(%r, 'a').write('{}\\n')\n" % journal, 1), "argon-garde.py")
        sortie = os.path.join(self.tmp, "l-garde")
        argv = v41.base(sortie, prep, None, "--commande-externe", argon)
        for n, options, tmax in ((1, ["--taille-max-consigne-externe", "1000"], 1000),
                                 (2, ["--budget-controle-externe-usd", "0.001"], 400)):
            code, out, err = v41.principal(v41.lanceur(cout_controle_claude=0.2), argv + options)
            self.assertEqual(code, 2, err)
            self.assertIn("garde de taille", err)
            r = os.path.join(sortie + "-controle", f"refus-taille-{n}.json")
            self.assertTrue(idn.verifier_scelle(r))
            with open(r) as f:
                g = json.load(f)["reglages"]
            self.assertEqual((g["garde_taille"]["taille_max_caracteres"], g["cout_usd"]), (tmax, 0.0))
            self.assertEqual(self.journal_de(journal), [])  # Argon jamais appelé
            self.assertEqual(sorted(os.listdir(sortie + "-controle")),
                             sorted(x for k in range(1, n + 1) for x in (f"refus-taille-{k}.json", f"refus-taille-{k}.json.sha256")))
            self.assertFalse(os.path.exists(sortie))
        code, out, err = v41.principal(v41.lanceur(), argv)
        self.assertEqual(code, 0, err)
        with open(os.path.join(sortie, "manifeste-depart.json")) as f:
            v = json.load(f)["reglages"]["versions"]
        self.assertEqual(v["tentatives_precedentes"], [])  # les refus de taille ne sont pas des tentatives
        self.assertEqual((v["taille_max_consigne_externe"]["valeur"], v["taille_max_consigne_externe"]["origine"]),
                         (520_000, "defaut"))  # v43 (CL42-01) ; v42 : 1 000 000
        self.assertEqual(v["marge_controle_externe"]["garde_taille"]["taille_max_caracteres"], 520_000)

    # --- CL41-02 ---------------------------------------------------------------------------------------------------------

    def test_cl41_02_fiche_bornee_et_marge_realiste(self):
        """CL41-02 : listes bornées (9 questions, 12 antériorités) ; `fiche_maximale` = le maximum du gabarit ; la passe 2
        réelle à fiches maximales ne dépasse pas la consigne éprouvée ; tailles écrites au manifeste de départ et au journal.
        **Changé en v43** (CL42-04, décision de Lazar : « retirer ») : plus de borne de 12 000 caractères sur la fiche — les
        deux fiches que la v42 refusait (guillemets échappés, quatre champs de 3 000) sont admises ; `fiche_maximale` revient
        au pire cas aux bornes par champ (44 259 caractères servis, v42 : 12 000) ; les listes restent bornées."""
        ok9 = idn.valider_fiche_ideation(fiche_brute(questions_servies=["Q1"] * 9), "a", 1)
        self.assertEqual(len(ok9["questions_servies"]), 9)
        for modif, motif in ((dict(questions_servies=["Q1"] * 10), "questions_servies"),
                             (dict(anteriorite=[{"reference": "r", "statut": "SUPPOSE"}] * 13), "anteriorite")):
            with self.subTest(motif=motif), self.assertRaises(idn.FicheIdeationInvalide) as cm:
                idn.valider_fiche_ideation(fiche_brute(**modif), "a", 1)
            self.assertIn(motif, str(cm.exception))
        for modif in (dict(enonce='"' * 2900, perte_traduction='"' * 2900, piege='"' * 2900),
                      dict(enonce="y" * 3000, perte_traduction="y" * 3000, piege="y" * 3000, cosmetique_si="y" * 3000)):
            self.assertGreater(idn.taille_servie(idn.valider_fiche_ideation(fiche_brute(**modif), "a", 1)), 12_000)  # v42 : refusées
        idn.valider_fiche_ideation(fiche_brute(anteriorite=[{"reference": "r", "statut": "SUPPOSE"}] * 12), "a", 1)
        fm = idn.fiche_maximale()
        taille_fm = idn.taille_servie(fm)
        self.assertGreater(taille_fm, 44_000)  # 44 259 : douze textes de 3 000, listes à leur borne
        self.assertEqual(idn.taille_servie(idn.valider_fiche_ideation(fm, "a", 1)), taille_fm)
        # la passe 2 réelle d'Argon (8 fiches à la taille maximale) tient dans la consigne éprouvée
        c = self.cours()
        prep = c.preparer()
        c._prep = prep
        att = os.path.join(self.tmp, "att-m42.json")
        idn.ecrire_json_scelle(att, {"lecteur": "Lazar", "lu_le": "2026-10-29", "materiau_sha256": {
            os.path.basename(prep["materiau"][0]): idn.sha256_fichier(prep["materiau"][0])}})
        budgets = dict(c.budgets())
        budgets[("proposeur_ideation", "gemini-argon")] = 1.0
        v2 = idn.verifier_reglages(liste_blanche=prep["liste_blanche"], question=prep["question"], pieces=prep["pieces"],
                                   temoins=prep["temoins"], budgets=budgets, materiau=prep["materiau"], seconde_passe=True,
                                   attestation_materiau=att, proposeurs=[("opus", "claude-opus-5-5"), ("fable", "claude-fable-5-1")],
                                   juges=[("juge-fable", "claude-fable-5-1"), ("juge-opus", "claude-opus-5-5")],
                                   proposeurs_externes=[("argon", "gemini-argon")], budget_total_usd=20.0, budget_externe_usd=5.0)
        self.assertEqual(v2["taille_fiche_maximale"], taille_fm)
        self.assertGreater(v2["taille_consigne_controle_externe"], 8 * taille_fm)  # v43 : comme la v41 (v42 : < 8 × 13 000)
        tailles = []

        class Argon:
            nom = "argon-simule"

            def lancer(self, role, consigne, dossier, budget_usd, max_tours, modele=None):
                tailles.append((os.path.basename(dossier), len(consigne)))
                fiches = [dict(fm, nom=f"Argon {i}".ljust(200, "x")) for i in range(8)]
                return Resultat("```json\n" + json.dumps({"fiches": fiches}, ensure_ascii=False) + "\n```", [], 0.1, "ok")
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]},
                            notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        res = c.lancer(ad, "c-borne", budgets=budgets, proposeurs_externes=[("argon", "gemini-argon", Argon())],
                       budget_externe_usd=5.0, seconde_passe=True, attestation_materiau=att)
        self.assertEqual([d for d, _ in tailles], ["passe-1", "passe-2"])
        self.assertLessEqual(tailles[1][1], len(v2["texte_controle_externe"]))
        self.assertEqual(sum(1 for f in res["fiches"] if f["auteur"] == "argon"), 16)
        self.assertEqual(res["journal"]["marge_seconde_passe"]["taille_fiche_maximale_servie"], taille_fm)
        with open(os.path.join(self.tmp, "c-borne", "manifeste-depart.json")) as f:
            self.assertEqual(json.load(f)["reglages"]["taille_fiche_maximale_servie"], taille_fm)
        # la consigne des proposeurs dit les bornes
        self.assertIn("au plus 9 questions servies, au plus 12 antériorités", v2["texte_controle_externe"])
        # au lanceur : taille de la marge et du contrôle au manifeste de départ
        v41 = self.v41()
        sortie = os.path.join(self.tmp, "l-marge")
        code, out, err = v41.principal(v41.lanceur(), v41.base(sortie, prep, att, "--commande-externe",
                                                                " ".join(self.cmd().commande(self.cmd().SCRIPT_OK))))
        self.assertEqual(code, 0, err)
        with open(os.path.join(sortie, "manifeste-depart.json")) as f:
            v = json.load(f)["reglages"]["versions"]
        m = v["marge_controle_externe"]
        self.assertEqual(m["taille_fiche_maximale_servie"], taille_fm)
        self.assertEqual(m["taille_consigne_de_controle"], v["appel_de_controle"]["externe:argon"]["taille_consigne"])

    def test_v36_listes_comptees_dans_fiche_maximale(self):
        """CL41-08 (V36) : `fiche_maximale` compte les deux listes à leur borne (9 questions, 12 antériorités)."""
        fm = idn.fiche_maximale()
        self.assertEqual((len(fm["questions_servies"]), len(fm["anteriorite"])), (idn.MAX_QUESTIONS_SERVIES, idn.MAX_ANTERIORITES))
        self.assertEqual((idn.MAX_QUESTIONS_SERVIES, idn.MAX_ANTERIORITES), (9, 12))
        self.assertTrue(all(len(q) == 80 for q in fm["questions_servies"]))

    # --- CL41-03 et N13 --------------------------------------------------------------------------------------------------

    def test_cl41_03_et_n13_consigne_de_controle_recue_par_la_commande(self):
        """CL41-03 : la consigne de contrôle d'Argon que **reçoit la commande** encadre le matériau entre délimiteurs et finit
        par « Fin du matériau. Réponds exactement OK, sans rien d'autre. » ; N13 : ce matériau est sa consigne de passe 2
        (fiches de première passe, matériau, instructions), pas les pièces seules ; au bras, le contrôle reçu est la
        consigne courte, qui finit par « Réponds exactement OK, sans rien d'autre. » (v41 : finit par « un seul bloc json »)."""
        v41 = self.v41()
        prep, att = v41.prep_devis()
        recu = os.path.join(self.tmp, "controles-recus.txt")
        script = self.cmd().SCRIPT_OK.replace(
            "if 'exactement OK' in consigne:\n",
            "if 'exactement OK' in consigne:\n    open(%r, 'a', encoding='utf-8').write(consigne + '\\x00')\n" % recu, 1)
        argon = v41.script(script, "argon-recoit.py")
        sortie = os.path.join(self.tmp, "l-recu")
        code, out, err = v41.principal(v41.lanceur(), v41.base(sortie, prep, att, "--commande-externe", argon))
        self.assertEqual(code, 0, err)
        course = _lire(recu).split("\x00")[0]
        self.assertTrue(course.startswith(idn.APPEL_DE_CONTROLE_CONSIGNE))
        self.assertTrue(course.endswith("Fin du matériau. Réponds exactement OK, sans rien d'autre."))
        self.assertEqual(idn.APPEL_DE_CONTROLE_FIN, "Fin du matériau. Réponds exactement OK, sans rien d'autre.")
        materiau = course.split(idn.DEBUT_MATERIAU_CONTROLE + "\n", 1)[1].rsplit("\n" + idn.FIN_MATERIAU_CONTROLE, 1)[0]
        for attendu in ("## Tes fiches de la première passe", "Tour interne", "## Ce que tu rends", "## Pièce : piece-a.md"):
            self.assertIn(attendu, materiau)  # N13 : la consigne de passe 2, pas les pièces seules
        self.assertNotIn("## Ce que tu rends", course.rsplit(idn.FIN_MATERIAU_CONTROLE, 1)[1])
        with open(os.path.join(sortie, "manifeste-depart.json")) as f:
            v = json.load(f)["reglages"]["versions"]
        self.assertEqual(len(course), v["appel_de_controle"]["externe:argon"]["taille_consigne"])
        # bras : contrôle court
        att_b = self.cmd().attester(os.path.join(self.tmp, "att-recu.json"), sortie, "argon-j")
        code, out, err = v41.principal(v41.lanceur(), [sortie, "--bras-rapporte-differe", "--attestation-lecture-humaine", att_b,
                                                       "--juge-externe", "argon-j=gemini-argon", "--commande-externe", argon])
        self.assertIn(code, (0, 4), err)
        bras = _lire(recu).split("\x00")[1]
        self.assertEqual(bras, idn.APPEL_DE_CONTROLE_CONSIGNE)
        self.assertTrue(bras.endswith("Réponds exactement OK, sans rien d'autre."))

    # --- CL41-04 ---------------------------------------------------------------------------------------------------------

    def test_cl41_04_controle_non_court_refuse_verrouille_le_bras(self):
        """CL41-04 : contrôle court refusé → tentative payée, message « avant tout envoi des fiches » vrai (la commande n'a
        reçu que 41 caractères) ; un contrôle qui n'était pas court (il a pu recevoir les fiches — ne doit plus arriver,
        simulé ici) et n'a pas rendu « OK » verrouille le bras comme un envoi : manifeste du bras, classement sans bras,
        aucune tentative relançable (v41 : tentative « relance permise », le tirage du juge rejoué)."""
        import unittest.mock
        c = self.cours()
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]},
                            notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        budgets = dict(c.budgets())
        budgets[("juge_ideation", "autre-lignee-x")] = 1.0

        class NotesAuControle(Enregistreur):
            def lancer(self, role, consigne, dossier, budget_usd, max_tours, modele=None):
                if consigne.startswith(idn.APPEL_DE_CONTROLE_CONSIGNE):
                    self.recu.append(consigne)
                    return Resultat("```json\n{\"notes\": []}\n```", [], 0.05, "ok")
                return Enregistreur.lancer(self, role, consigne, dossier, budget_usd, max_tours, modele)
        # contrôle court refusé : message vrai, tentative payée
        c.lancer(ad, "nc1", budgets=budgets, juges_externes=[("argon", "autre-lignee-x")], budget_externe_usd=2.0)
        s1 = os.path.join(self.tmp, "nc1")
        att1 = self.cmd().attester(os.path.join(self.tmp, "att-nc1.json"), s1)
        a1 = NotesAuControle(c)
        with self.assertRaises(idn.CourseInterrompue) as cm:
            idn.executer_bras_differe(s1, attestation_lecture_humaine=att1, budgets=budgets,
                                      juges_externes=[("argon", "autre-lignee-x", a1)])
        self.assertIn("avant tout envoi des fiches", str(cm.exception))
        self.assertEqual(a1.recu, [idn.APPEL_DE_CONTROLE_CONSIGNE])  # aucune fiche reçue : le message est vrai
        self.assertTrue(os.path.exists(os.path.join(s1, "bras-tentative-1.json")))
        self.assertFalse(os.path.exists(os.path.join(s1, "manifeste-bras-rapporte.json")))
        # contrôle non court (simulé) refusé : verrouillé comme un envoi
        c.lancer(ad, "nc2", budgets=budgets, juges_externes=[("argon", "autre-lignee-x")], budget_externe_usd=2.0)
        s2 = os.path.join(self.tmp, "nc2")
        att2 = self.cmd().attester(os.path.join(self.tmp, "att-nc2.json"), s2)
        with open(os.path.join(s2, "juges-bras-rapporte", "traces-argon", "consigne-en-attente.md"), encoding="utf-8") as f:
            consigne_juge = f.read()
        a2 = NotesAuControle(c)
        long_controle = lambda supplement=None: idn.APPEL_DE_CONTROLE_CONSIGNE + "\n\n" + consigne_juge  # noqa: E731
        with unittest.mock.patch.object(idn, "consigne_de_controle", long_controle):
            with self.assertRaises(idn.SansJugeExterne) as cm:
                idn.executer_bras_differe(s2, attestation_lecture_humaine=att2, budgets=budgets,
                                          juges_externes=[("argon", "autre-lignee-x", a2)])
        self.assertIn("CL41-04", str(cm.exception))
        self.assertFalse(os.path.exists(os.path.join(s2, "bras-tentative-1.json")))
        with open(os.path.join(s2, "manifeste-bras-rapporte.json")) as f:
            j = json.load(f)["reglages"]["journal"]
        self.assertEqual(j["consigne_envoyee"], "argon")
        self.assertAlmostEqual(j["cout_total_usd"], 0.05)
        self.assertTrue(idn.verifier_scelle(os.path.join(s2, "classement-sans-bras.json")))
        with self.assertRaises(idn.CourseInterrompue) as cm:  # verrouillé
            idn.executer_bras_differe(s2, attestation_lecture_humaine=att2, budgets=budgets,
                                      juges_externes=[("argon", "autre-lignee-x", Enregistreur(c))])
        self.assertIn("déjà été joué", str(cm.exception))

    # --- CL41-05 ---------------------------------------------------------------------------------------------------------

    def test_cl41_05_relancable_relais_garde_et_relance_a_neuf(self):
        """CL41-05 (sonde de CL8) : total 41, relais 41 (réserve 4), contrôles Claude 0,4 : `relancable` faux dans
        l'hypothèse « relais gardé » (écrite au motif) ; le second calcul « relais relancé à neuf » dit la relance possible.
        Relais trop petit même à neuf : les deux faux."""
        lanceur = self.v41().lanceur()
        budgets = dict(lanceur.BUDGETS_PAR_DEFAUT)
        juges = [("juge-opus", "claude-opus-5-5"), ("juge-fable", "claude-fable-5-1")]
        verif = {"somme_claude": 40.0, "somme_externe": 11.2}
        relais = {"plafond_usd": 41.0, "reserve_par_appel_usd": 4.0, "depense_usd": 0.0}
        ok, motifs, neuf = lanceur.relance_possible(1, verif, 0.4, 0.15, 41.0, 11.6, False, False, True, relais, budgets, juges,
                                                    details=True)
        self.assertFalse(ok)
        self.assertEqual(len(motifs), 1)
        self.assertIn("relais gardé (hypothèse) : 36.6000", motifs[0])
        self.assertIn("relais relancé à neuf (devis, point 4) : 37.0000 ≥ 37.0000", motifs[0])
        self.assertTrue(neuf["relancable"], neuf)
        self.assertEqual(lanceur.relance_possible(1, verif, 0.4, 0.15, 41.0, 11.6, False, False, True, relais, budgets, juges),
                         (ok, motifs))  # forme de la v41 gardée sans `details`
        petit = dict(relais, plafond_usd=39.0)
        ok2, motifs2, neuf2 = lanceur.relance_possible(1, verif, 0.4, 0.15, 41.0, 11.6, False, False, True, petit, budgets,
                                                       juges, details=True)
        self.assertFalse(ok2 or neuf2["relancable"])
        self.assertNotIn("la garde du relais accepterait", motifs2[0])

    def test_v34_relais_lu_avec_le_cout_claude_de_la_tentative(self):
        """CL41-08 (V34) : le calcul du relais retire le coût Claude de la tentative (plafond 40,2, réserve 4 : 36,2 − 0,4 =
        35,8 < 36 → faux ; sans ce coût, 36,2 ≥ 36 l'aurait dit vrai)."""
        lanceur = self.v41().lanceur()
        budgets = dict(lanceur.BUDGETS_PAR_DEFAUT)
        juges = [("juge-opus", "claude-opus-5-5"), ("juge-fable", "claude-fable-5-1")]
        verif = {"somme_claude": 30.0, "somme_externe": 11.2}
        relais = {"plafond_usd": 40.2, "reserve_par_appel_usd": 4.0, "depense_usd": 0.0}
        ok, motifs = lanceur.relance_possible(1, verif, 0.4, 0.0, 40.0, 11.6, False, False, True, relais, budgets, juges)
        self.assertFalse(ok)
        self.assertIn("35.8000", motifs[0])
        self.assertTrue(lanceur.relance_possible(1, verif, 0.0, 0.0, 40.0, 11.6, False, False, True, relais, budgets, juges)[0])

    # --- CL41-06 ---------------------------------------------------------------------------------------------------------

    def test_cl41_06_interruption_avant_le_manifeste_de_depart(self):
        """CL41-06 (S12, `lanceur_fenetre.py` de CL8) : interruption au moment d'écrire le manifeste de départ → aucune SORTIE
        (dossier provisoire retiré), tentative scellée relançable, et la relance passe (v41 : SORTIE vide laissée,
        « relançable » puis relance refusée « SORTIE existe déjà »). Au lanceur, une SORTIE créée sans manifeste de départ
        rend `relancable` faux, motif nommé."""
        import glob
        import unittest.mock
        v41 = self.v41()
        prep = self.cours().preparer()
        ok = " ".join(self.cmd().commande(self.cmd().SCRIPT_OK))
        sortie = os.path.join(self.tmp, "l-fenetre")
        argv = v41.base(sortie, prep, None, "--commande-externe", ok)
        vrai = idn.manifeste

        def manifeste_coupe(**k):
            if k.get("phase") == "depart":
                raise KeyboardInterrupt("signal 15 (simulé entre la création de SORTIE et le manifeste de départ)")
            return vrai(**k)
        with unittest.mock.patch.object(idn, "manifeste", manifeste_coupe):
            code, out, err = v41.principal(v41.lanceur(), argv)
        self.assertEqual(code, 2, err)
        self.assertFalse(os.path.exists(sortie))  # v41 : SORTIE vide
        self.assertEqual(glob.glob(sortie + ".depart-en-cours-*"), [])
        with open(os.path.join(sortie + "-controle", "tentative-1.json")) as f:
            r = json.load(f)["reglages"]
        self.assertTrue(r["relancable"], r["motifs_relance"])
        code, out, err = v41.principal(v41.lanceur(), argv)
        self.assertEqual(code, 0, err)  # v41 : 2, « SORTIE existe déjà »
        # au lanceur : SORTIE sans manifeste de départ → relancable faux
        lanceur = v41.lanceur()
        sortie2 = os.path.join(self.tmp, "l-fenetre-2")

        def coeur_coupe(adaptateur, s, **k):
            os.makedirs(s)
            raise KeyboardInterrupt("signal 15")
        with unittest.mock.patch.object(lanceur.idn, "executer_ideation", coeur_coupe):
            code, out, err = v41.principal(lanceur, v41.base(sortie2, prep, None, "--commande-externe", ok))
        self.assertEqual(code, 2)
        with open(os.path.join(sortie2 + "-controle", "tentative-1.json")) as f:
            r = json.load(f)["reglages"]
        self.assertFalse(r["relancable"])
        self.assertTrue(any("sans manifeste de départ" in m for m in r["motifs_relance"]), r["motifs_relance"])
        self.assertFalse(r["relance_relais_relance_a_neuf"]["relancable"])

    # --- CL41-07 ---------------------------------------------------------------------------------------------------------

    def test_cl41_07_panne_d_argon_au_controle_ne_coute_rien_chez_claude(self):
        """CL41-07 : réglages du devis, contrôles Claude payés (0,2 chacun) ; Argon rend « KO » à 0,15 au contrôle, joué en
        premier : aucun contrôle Claude, tentative à 0 côté Claude, relançable (11,2 + 0,15 ≤ 11,6) ; la relance part
        (v41 : 0,4 Claude dépensés, plus de relance)."""
        v41 = self.v41()
        prep, att = v41.prep_devis()
        journal = os.path.join(self.tmp, "ko-07.log")
        ko = v41.script(v41.SCRIPT_KO % journal, "ko-07.py")
        sortie = os.path.join(self.tmp, "l-07")
        code, out, err = v41.principal(v41.lanceur(cout_controle_claude=0.2), v41.base(sortie, prep, att, "--commande-externe", ko))
        self.assertEqual(code, 2)
        with open(os.path.join(sortie + "-controle", "tentative-1.json")) as f:
            r = json.load(f)["reglages"]
        self.assertEqual(r["cout_claude_usd"], 0.0)  # v41 : 0,4
        self.assertAlmostEqual(r["cout_externe_usd"], 0.15)
        self.assertEqual(sorted(r["lectures"]), ["externe:argon"])
        self.assertFalse(os.path.exists(os.path.join(sortie + "-controle", "tentative-1")))  # aucun dossier de contrôle Claude
        self.assertTrue(r["relancable"], r["motifs_relance"])
        argon = v41.script(v41.SCRIPT_PLAFOND, "argon-plafond-07.py")
        code, out, err = v41.principal(v41.lanceur(cout_controle_claude=0.2), v41.base(sortie, prep, att, "--commande-externe", argon))
        self.assertIn(code, (0, 4), err)
        with open(os.path.join(sortie, "manifeste-depart.json")) as f:
            d = json.load(f)["reglages"]
        self.assertAlmostEqual(d["cout_externe_deja_engage_usd"], 0.15 + 2.5)
        self.assertAlmostEqual(d["cout_deja_engage_usd"], 0.4)

    # --- CL41-08 ---------------------------------------------------------------------------------------------------------

    def test_n03_meme_controle_du_bras_au_lanceur_et_au_coeur(self):
        """CL41-08 (N03) : `verifier_reglages` reçoit le même contrôle du bras que le cœur (0,2 par défaut, 0,1 donné) ; une
        somme externe qui ne tient qu'avec un contrôle du bras à 0 (11,1 < 11,2) est refusée avant tout contrôle."""
        import unittest.mock
        v41 = self.v41()
        prep, att = v41.prep_devis()
        argon = v41.script(v41.SCRIPT_PLAFOND, "argon-n03.py")
        vus = {"reglages": [], "coeur": []}
        vrai_v, vrai_c = idn.verifier_reglages, idn.executer_ideation

        def espion_v(**k):
            vus["reglages"].append(k["budget_controle_bras_usd"])
            return vrai_v(**k)

        def espion_c(*a, **k):
            vus["coeur"].append(k["budget_controle_bras_usd"])
            return vrai_c(*a, **k)
        for n, options, attendu in ((1, [], 0.2), (2, ["--budget-controle-usd", "0.1", "--budget-externe-usd", "11.1"], 0.1)):
            with unittest.mock.patch.object(idn, "verifier_reglages", espion_v), \
                    unittest.mock.patch.object(idn, "executer_ideation", espion_c):
                code, out, err = v41.principal(v41.lanceur(), v41.base(os.path.join(self.tmp, f"l-n03-{n}"), prep, att,
                                                                        "--commande-externe", argon, *options))
            self.assertIn(code, (0, 4), err)
            self.assertEqual((vus["reglages"][-1], vus["coeur"][-1]), (attendu, attendu))
        sortie = os.path.join(self.tmp, "l-n03-refus")
        journal = os.path.join(self.tmp, "n03.log")
        code, out, err = v41.principal(v41.lanceur(), v41.base(sortie, prep, att, "--commande-externe",
                                                                v41.script(v41.SCRIPT_KO % journal, "ko-n03.py"),
                                                                "--budget-externe-usd", "11.1"))
        self.assertEqual(code, 2)
        self.assertIn("somme des plafonds externes 11.20 > total externe 11.1", err)
        self.assertFalse(os.path.exists(sortie + "-controle"))
        self.assertFalse(os.path.exists(journal))

    SCRIPT_CTRL = ("import sys, json, os\nc = sys.stdin.read()\nopen(%r, 'a').write('appel\\n')\n"
                   "if c.startswith('Réponds exactement OK'): print(json.dumps({'texte': %r, 'cout_usd': %s})); sys.exit(0)\n")

    def test_n04_n07_n08_couts_des_tentatives_precedentes(self):
        """CL41-08 (N04, N07, N08) : deux tentatives payées (Claude 0,02 et Argon 0,3 ; puis Argon 2,5) ; la relance sous un
        total externe juste est refusée avant tout contrôle ; ensuite la course part et son manifeste de départ porte les
        coûts imputés, comme le journal du cœur. **Changé en v43** (CL40-01, option c, décision de Lazar) : la troisième
        tentative reprend le contrôle d'Argon réussi en tentative 1 (même commande, même consigne) et le premier contrôle
        Claude ; elle ne rejoue que le contrôle Claude « KO » — somme externe de la relance 0,3 + 2,5 + 0 + 6,2 = 9,0 (refusée
        sous 8,9 ; v42 : 11,5, refusée sous 11,4) ; `cout_deja_engage_usd` = 0,02 + 0,01 (v42 : 0,04) et
        `cout_externe_deja_engage_usd` = 0,3 + 2,5 (v42 : 3,1) ; contrôles repris écrits au manifeste et au journal."""
        v41 = self.v41()
        prep = self.cours().preparer()
        journal = os.path.join(self.tmp, "n04.log")
        suite_ok = self.cmd().SCRIPT_OK.split("\n", 2)[2]  # passes et juge du script commun (la consigne est déjà lue)
        argon_ok = v41.script((self.SCRIPT_CTRL % (journal, "OK", "0.3")).replace("c = sys.stdin.read()", "consigne = c = sys.stdin.read()")
                              .replace("import sys, json, os", "import sys, json, os, re") + suite_ok, "argon-n04-ok.py")
        argon_ko = v41.script(self.SCRIPT_CTRL % (journal, "KO", "float(os.environ['PLAFOND_SESSION_USD'])"), "argon-n04-ko.py")
        sortie = os.path.join(self.tmp, "l-n04")

        def argv(commande, total):
            return v41.base(sortie, prep, None, "--commande-externe", commande, "--budget-externe-usd", total)
        code, _, err = v41.principal(v41.lanceur(cout_controle_claude=0.01, ko_claude="claude-opus-5-5"), argv(argon_ok, "11.5"))
        self.assertEqual(code, 2, err)
        code, _, err = v41.principal(v41.lanceur(cout_controle_claude=0.01), argv(argon_ko, "11.5"))
        self.assertEqual(code, 2, err)
        t = [json.loads(_lire(os.path.join(sortie + "-controle", f"tentative-{n}.json")))["reglages"] for n in (1, 2)]
        self.assertEqual([(round(x["cout_claude_usd"], 6), round(x["cout_externe_usd"], 6)) for x in t], [(0.02, 0.3), (0.0, 2.5)])
        n = len(_lire(journal).splitlines())
        code, _, err = v41.principal(v41.lanceur(cout_controle_claude=0.01), argv(argon_ok, "8.9"))
        self.assertEqual(code, 2)
        self.assertIn("somme des plafonds externes 9.00 > total externe 8.9", err)  # N04 (v42 : 11.50 > 11.4)
        self.assertEqual(len(_lire(journal).splitlines()), n)
        self.assertFalse(os.path.exists(os.path.join(sortie + "-controle", "tentative-3.json")))
        code, _, err = v41.principal(v41.lanceur(cout_controle_claude=0.01), argv(argon_ok, "11.5"))
        self.assertEqual(code, 0, err)
        with open(os.path.join(sortie, "manifeste-depart.json")) as f:
            d = json.load(f)["reglages"]
        self.assertAlmostEqual(d["cout_deja_engage_usd"], 0.03)  # N08 (v42 : 0,04, le contrôle réussi rejoué)
        self.assertAlmostEqual(d["cout_externe_deja_engage_usd"], 2.8)  # N07 (v42 : 3,1)
        self.assertAlmostEqual(d["somme_des_plafonds"]["externe_avec_controle_du_bras"], 2.8 + 2.5 + 3.5 + 0.2)
        repris = d["versions"]["controles_repris"]
        self.assertEqual(sorted(repris), ["claude-fable-5-1", "externe:argon"])
        self.assertEqual({v["repris_de_tentative"] for v in repris.values()}, {1})
        self.assertEqual(repris["externe:argon"]["sha256_tentative"],
                         idn.sha256_fichier(os.path.join(sortie + "-controle", "tentative-1.json")))
        self.assertEqual(sorted(d["versions"]["appel_de_controle"]), ["claude-opus-5-5"])
        with open(os.path.join(sortie, "manifeste-fin.json")) as f:
            j = json.load(f)["reglages"]["journal"]
        self.assertAlmostEqual(j["cout_appels_de_controle_usd"], 0.03)
        self.assertAlmostEqual(j["cout_appels_de_controle_externes_usd"], 2.8)
        self.assertAlmostEqual(j["cout_externe_usd"], 2.8 + 0.25)
        self.assertEqual(j["controles_repris"], repris)

    def test_v12_relancable_avec_le_cout_externe_de_la_tentative(self):
        """CL41-08 (V12) : réglages du devis, seul le coût externe de la tentative fait dépasser — Argon « KO » à 0,5 :
        somme externe de la relance 11,7 > 11,6, `relancable` faux ; à 0,15 : vrai."""
        v41 = self.v41()
        prep, att = v41.prep_devis()
        for cout, attendu in ((0.5, False), (0.15, True)):
            journal = os.path.join(self.tmp, f"v12-{cout}.log")
            ko = v41.script(self.SCRIPT_CTRL % (journal, "KO", repr(cout)), f"ko-v12-{cout}.py")
            sortie = os.path.join(self.tmp, f"l-v12-{cout}")
            code, _, err = v41.principal(v41.lanceur(), v41.base(sortie, prep, att, "--commande-externe", ko))
            self.assertEqual(code, 2)
            with open(os.path.join(sortie + "-controle", "tentative-1.json")) as f:
                r = json.load(f)["reglages"]
            self.assertEqual(r["cout_claude_usd"], 0.0)
            self.assertEqual(r["relancable"], attendu, r["motifs_relance"])
            if not attendu:
                self.assertEqual(r["motifs_relance"], ["somme des plafonds externes de la relance 11.7000 > total externe 11.6"])

    def test_v20_tentative_du_bras_scellee_au_cout_non_fini(self):
        """CL41-08 (V20, S13 de CL8) : une `bras-tentative` **scellée** au coût NaN, −2,5 ou `true` est refusée avant tout
        appel."""
        c = self.cours()
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]},
                            notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        budgets = dict(c.budgets())
        budgets[("juge_ideation", "autre-lignee-x")] = 1.0
        for i, valeur in enumerate(("NaN", "-2.5", "true")):
            nom = f"v20-{i}"
            c.lancer(ad, nom, budgets=budgets, juges_externes=[("argon", "autre-lignee-x")], budget_externe_usd=2.0)
            sortie = os.path.join(self.tmp, nom)
            att = self.cmd().attester(os.path.join(self.tmp, f"att-{nom}.json"), sortie)
            idn.ecrire_scelle(os.path.join(sortie, "bras-tentative-1.json"),
                              '{"reglages": {"journal": {"cout_total_usd": %s}}}' % valeur)
            bon = Enregistreur(c)
            with self.subTest(cout=valeur), self.assertRaises(idn.CourseInterrompue) as cm:
                idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                          juges_externes=[("argon", "autre-lignee-x", bon)])
            self.assertIn("coût illisible", str(cm.exception))
            self.assertEqual(bon.recu, [])


class TestV43(CasAvecDossier):
    """v43 (contre-lecture CL9 de la v42 ; choix de session-depot, message n° 156) : garde de la course sur le plus petit
    plafond des sessions d'Argon, provision de sortie, passe gardée avant son envoi (CL42-01) ; garde propre au bras, refus
    de taille compté et classé, chaîne lanceur → manifeste → bras (CL42-05, W07) ; échec du classement de repli dit et
    scellé, second repli sans écrasement (CL42-06, S14, W36) ; NaN au bras sur une SORTIE fraîche, phrase de la borne,
    refus pour taille par proposeur (CL42-07, W30, W35b) ; mesure des consignes sans appel (CL42-03)."""

    def v41(self):
        t = TestV41("test_ecrits_du_lanceur")
        t.tmp = self.tmp
        return t

    def cours(self):
        c = TestCourse("test_course_complete")
        c.tmp = self.tmp
        return c

    def cmd(self):
        c = TestCommandeExterne("test_commande_factice_notes_et_controle")
        c.tmp = self.tmp
        return c

    def journal_de(self, chemin):
        if not os.path.exists(chemin):
            return []
        return [json.loads(l) for l in _lire(chemin).splitlines() if l.strip()]

    def prep(self):
        """Pièces, question, matériau et témoins des essais, préparés une fois par essai (liste blanche jamais écrasée)."""
        if not hasattr(self, "_prep_base"):
            self._prep_base = self.cours().preparer()
        return self._prep_base

    def argon_journal(self, journal, nom):
        """Le script commun (`SCRIPT_OK`) qui consigne chaque appel : taille, contrôle, passe 2."""
        script = self.cmd().SCRIPT_OK.replace(
            "consigne = sys.stdin.read()\n",
            "consigne = sys.stdin.read()\nopen(%r, 'a').write(json.dumps({'taille': len(consigne), 'controle': "
            "'exactement OK' in consigne, 'passe2': 'première passe' in consigne}) + '\\n')\n" % journal, 1)
        return self.v41().script(script, nom)

    # Argon factice au tarif donné (dollars par caractère d'entrée et de sortie), coût jamais borné à son plafond ;
    # chaque appel consigné (CL9 : « tarif_tout »)
    SCRIPT_TARIF = (
        "import sys, json, os, re\nc = sys.stdin.read()\nctrl = c.startswith('Réponds exactement OK')\n"
        "def sortir(t):\n"
        "    cout = len(c) * %r + len(t) * %r\n"
        "    open(%r, 'a').write(json.dumps({'taille': len(c), 'controle': ctrl, 'role': os.environ['ROLE_POLE'], "
        "'cout': cout}) + '\\n')\n"
        "    print(json.dumps({'texte': t, 'cout_usd': cout})); sys.exit(0)\n"
        "if ctrl: sortir('OK')\n"
        "if os.environ['ROLE_POLE'] == 'proposeur_ideation':\n"
        "    f1 = json.loads(%r); f2 = dict(f1, nom='Argon B')\n"
        "    sortir('```json\\n' + json.dumps({'fiches': [f1, f2]}, ensure_ascii=False) + '\\n```')\n"
        "bloc = json.loads(re.search(r'```json\\n(\\[.*\\])\\n```', c, re.S).group(1))\n"
        "notes = [{'identifiant': f['identifiant'], 'criteres': {x: 2 for x in ('avantage', 'originalite', 'falsifiabilite', "
        "'traitabilite', 'robustesse')}, 'justifications': {}} for f in bloc]\n"
        "sortir('```json\\n' + json.dumps({'notes': notes, 'doublons': []}) + '\\n```')\n")

    def prep_grand(self):
        """Réglages du devis (CL9, § 4) : pièce de 750 000 caractères, matériau de 350 000, question de 19 caractères,
        témoins des essais, matériau attesté."""
        prep = self.prep()
        p = os.path.join(self.tmp, "piece-grande.md")
        with open(p, "w", encoding="utf-8") as f:
            f.write(("# Pièce A\n" + "Texte de contexte. " * 40_000)[:750_000])
        m = os.path.join(self.tmp, "materiau-grand.md")
        with open(m, "w", encoding="utf-8") as f:
            f.write(("# Matériau\n" + "Tour interne. " * 26_000)[:350_000])
        lb = os.path.join(self.tmp, "liste-blanche-grande.json")
        idn.construire_liste_blanche([p, m, prep["question"], prep["temoins"]], lb)
        att = os.path.join(self.tmp, "att-materiau-grand.json")
        idn.ecrire_json_scelle(att, {"lecteur": "Lazar", "lu_le": "2026-10-29",
                                     "materiau_sha256": {"materiau-grand.md": idn.sha256_fichier(m)}})
        return dict(prep, liste_blanche=lb, pieces=[p], materiau=[m]), att

    def prep_piece_juge(self, taille=200_000):
        prep = self.prep()
        pj = os.path.join(self.tmp, "piece-juge.md")
        with open(pj, "w", encoding="utf-8") as f:
            f.write("# Antériorité\n" + ("Résumé d'article. " * 20000)[:taille])
        lb = os.path.join(self.tmp, "liste-blanche-pj.json")
        idn.construire_liste_blanche([prep["pieces"][0], prep["question"], prep["materiau"][0], prep["temoins"], pj], lb)
        return dict(prep, liste_blanche=lb), pj

    def course_bras(self, nom, juge_budget=1.0, budget_externe=2.0):
        """Course (cœur, faux adaptateur Claude) avec un juge externe différé ; rend (cours, sortie, attestation, budgets)."""
        c = self.cours()
        c._prep = self.prep()
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]},
                            notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        budgets = dict(c.budgets())
        budgets[("juge_ideation", "autre-lignee-x")] = juge_budget
        c.lancer(ad, nom, budgets=budgets, juges_externes=[("argon", "autre-lignee-x")], budget_externe_usd=budget_externe)
        sortie = os.path.join(self.tmp, nom)
        att = self.cmd().attester(os.path.join(self.tmp, f"att-{nom}.json"), sortie)
        return c, sortie, att, budgets

    # --- CL42-01 ---------------------------------------------------------------------------------------------------------

    def test_cl42_01_controle_releve_seul_refuse_sans_depense_et_garde_donnee_passe(self):
        """CL42-01 (D-a-devis de CL9) : réglages du devis (pièce 750 000, matériau 350 000, huit fiches, seconde passe),
        `--budget-controle-externe-usd 3.0 --budget-externe-usd 12.1` seuls → **refus sans dépense** : la garde reste à
        1 000 000 − 480 000 = 520 000 (la passe d'Argon reste à 2,5, provision de huit fiches de 12 000 au rapport 5),
        refus scellé, ni Argon (au tarif du devis) ni Claude appelés (v42 : garde 1 200 000, contrôle payé 2,73, course
        perdue après la passe 2 d'Argon à 2,51 > 2,5). Au prix de 8,3 dollars par million de jetons
        (`--prix-entree-usd-par-million-jetons`, CL42-04 b) : garde 1 204 819 − 480 000 = 724 819, refus aussi ; prix nul ou
        non fini refusé. Cas sain : `--taille-max-consigne-externe 1500000` donné (le contrôle fait ≈ 1 457 000 caractères
        depuis que la borne de fiche est retirée, CL42-04), Argon au pire cas (chaque session à son plafond) → course et bras
        passent, classement à trois juges ; les deux passes d'Argon gardées par le cœur avant leur envoi contre la taille
        donnée.
        v44 (CL43-02, changé) : la taille donnée ne désarme plus la garde propre de chaque passe (plafond moins la provision
        de huit fiches de 8 000) ; au prix 10 et passes à 2,5, la passe 1 (752 445) serait refusée avant tout contrôle
        (680 000) : le cas sain passe aux réglages (β) (prix 8,3, contrôle 3,1, passe 2 à 3,1, externe 12,8), gardes
        884 819 et 1 173 975 (v43 : 1 500 000 et 1 500 000)."""
        self.assertEqual(idn.provision_sortie_caracteres(8), 480_000)
        self.assertEqual(idn.taille_max_consigne_course_par_defaut(3.0, [2.5], 8)[0], 520_000)
        self.assertEqual(idn.taille_max_consigne_course_par_defaut(2.5, [2.5], 8)[0], 520_000)
        self.assertEqual(idn.taille_max_consigne_course_par_defaut(2.5, [3.7], 8)[0], 1_000_000)  # contrôle, entrée seule
        self.assertEqual(idn.taille_max_consigne_course_par_defaut(2.5, [1.0], 8)[0], 0)  # jamais négatif
        v41 = self.v41()
        prep, att = self.prep_grand()
        journal = os.path.join(self.tmp, "argon-devis.jsonl")
        devis = v41.script(self.SCRIPT_TARIF % (2.5 / 1.1e6, 0.0, journal, TestCommandeExterne.FICHE), "argon-devis.py")
        sortie = os.path.join(self.tmp, "l-devis-a")
        code, out, err = v41.principal(v41.lanceur(cout_controle_claude=0.2), v41.base(
            sortie, prep, att, "--commande-externe", devis, "--budget-controle-externe-usd", "3.0", "--budget-externe-usd", "12.1"))
        self.assertEqual(code, 2, err)
        self.assertIn("garde de taille", err)
        self.assertEqual(self.journal_de(journal), [])  # Argon jamais appelé (v42 : contrôle 2,73, passes 1,71 et 2,51)
        r = os.path.join(sortie + "-controle", "refus-taille-1.json")
        self.assertTrue(idn.verifier_scelle(r))
        with open(r) as f:
            g = json.load(f)["reglages"]
        self.assertEqual((g["garde_taille"]["taille_max_caracteres"], g["cout_usd"], g["tentative_comptee"]), (520_000, 0.0, False))
        self.assertEqual(g["garde_taille"]["provision_sortie_caracteres"], 480_000)
        self.assertGreater(g["garde_taille"]["taille_caracteres"], 1_199_000)
        self.assertIn("passe du proposeur externe 2.5", g["garde_taille"]["origine_taille_max"])
        self.assertEqual(sorted(os.listdir(sortie + "-controle")), ["refus-taille-1.json", "refus-taille-1.json.sha256"])
        self.assertFalse(os.path.exists(sortie))  # aucun contrôle Claude, aucune SORTIE
        # CL42-04 b : prix d'entrée du devis (8,3 dollars par million de jetons) — garde plus haute, refus quand même
        code, out, err = v41.principal(v41.lanceur(cout_controle_claude=0.2), v41.base(
            sortie, prep, att, "--commande-externe", devis, "--prix-entree-usd-par-million-jetons", "8.3"))
        self.assertEqual(code, 2, err)
        with open(os.path.join(sortie + "-controle", "refus-taille-2.json")) as f:
            g2 = json.load(f)["reglages"]["garde_taille"]
        self.assertEqual((g2["taille_max_caracteres"], g2["prix_entree_usd_par_million_jetons"]), (724_819, 8.3))
        self.assertAlmostEqual(g2["cout_prudent_entree_usd"], round(g2["taille_caracteres"] * 8.3e-6 / 4, 4))
        self.assertEqual(self.journal_de(journal), [])
        import contextlib
        import io
        for prix in ("0", "nan", "-1"):
            with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                v41.lanceur().principal(v41.base(sortie, prep, att, "--prix-entree-usd-par-million-jetons", prix))
        # cas sain : garde donnée explicitement, Argon au pire cas → course puis bras, classement à trois juges
        argon = v41.script(v41.SCRIPT_PLAFOND, "argon-plafond-43.py")
        sortie2 = os.path.join(self.tmp, "l-devis-c")
        code, out, err = v41.principal(v41.lanceur(), v41.base(
            sortie2, prep, att, "--commande-externe", argon, "--taille-max-consigne-externe", "1500000",
            "--prix-entree-usd-par-million-jetons", "8.3", "--budget-controle-externe-usd", "3.1",
            "--budget-passe-2-externe-usd", "3.1", "--budget-externe-usd", "12.8"))
        self.assertEqual(code, 0, err)
        with open(os.path.join(sortie2, "manifeste-depart.json")) as f:
            v = json.load(f)["reglages"]["versions"]
        self.assertEqual((v["taille_max_consigne_externe"]["valeur"], v["taille_max_consigne_externe"]["origine"]),
                         (1_500_000, "option"))
        self.assertGreater(v["marge_controle_externe"]["taille_consigne_de_controle"], 1_450_000)  # CL42-04 : borne retirée
        with open(os.path.join(sortie2, "manifeste-fin.json")) as f:
            j = json.load(f)["reglages"]["journal"]
        self.assertEqual([(x["passe"], x["taille_max_caracteres"], x["refusee"]) for x in j["gardes_taille_sessions"]],
                         [(1, 884_819, False), (2, 1_173_975, False)])  # v43 : 1 500 000 deux fois
        self.assertGreater(j["gardes_taille_sessions"][1]["taille_caracteres"], 1_100_000)
        att_b = self.cmd().attester(os.path.join(self.tmp, "att-devis-c.json"), sortie2, "argon-j")
        code, out, err = v41.principal(v41.lanceur(), [sortie2, "--bras-rapporte-differe", "--attestation-lecture-humaine", att_b,
                                                       "--juge-externe", "argon-j=gemini-argon", "--commande-externe", argon])
        self.assertIn(code, (0, 4), err)
        with open(os.path.join(sortie2, "classement.json")) as f:
            self.assertTrue(all(l["nombre_juges"] == 3 for l in json.load(f)["lignes"]))

    def test_cl42_01_passe_gardee_contre_son_propre_plafond_avant_envoi(self):
        """CL42-01 : `garder_sessions_externes` (donné par le lanceur) — chaque passe d'un proposeur externe est gardée
        avant son envoi contre son propre plafond / prix prudent moins la provision de sortie ; un plafond qui tient la
        passe 1 et pas la passe 2 → passe 2 **non envoyée**, rien payé pour elle, aucune passe Claude, manifeste de fin
        en erreur, gardes au journal (v42 : aucune garde dans le cœur, la passe 2 part). Cas sain : plafond 2,5 → les deux
        passes gardées et jouées.
        v44 (CL43-02, changé) : provision de huit fiches de 8 000 (`TAILLE_FICHE_PROVISIONNEE_PASSE`) au lieu de 12 000 :
        320 000 au lieu de 480 000 ; cas sain 680 000 au lieu de 520 000."""
        c = self.cours()
        prep = self.prep()
        c._prep = prep
        att = os.path.join(self.tmp, "att-p2.json")
        idn.ecrire_json_scelle(att, {"lecteur": "Lazar", "lu_le": "2026-10-29", "materiau_sha256": {
            os.path.basename(prep["materiau"][0]): idn.sha256_fichier(prep["materiau"][0])}})
        liste = idn.charger_liste_blanche(prep["liste_blanche"])
        passe1 = len(idn.consigne_proposeur(idn.lire_pieces(prep["pieces"], liste), 8,
                                            idn.lire_pieces([prep["question"]], liste)[0][1]))
        recu = []

        class Argon:
            nom = "argon-simule"

            def lancer(self, role, consigne, dossier, budget_usd, max_tours, modele=None):
                recu.append((os.path.basename(dossier), len(consigne)))
                fiches = [fiche_brute(nom="Argon A"), fiche_brute(nom="Argon B")]
                return Resultat("```json\n" + json.dumps({"fiches": fiches}, ensure_ascii=False) + "\n```", [], 0.1, "ok")
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]},
                            notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        budgets = dict(c.budgets())
        budgets[("proposeur_ideation", "gemini-argon")] = (320_000 + passe1 + 50) * idn.PRIX_CARACTERE_PRUDENT_USD
        args = dict(budgets=budgets, proposeurs_externes=[("argon", "gemini-argon", Argon())], budget_externe_usd=5.0,
                    seconde_passe=True, attestation_materiau=att, garder_sessions_externes=True)
        with self.assertRaises(idn.TailleConsigneRefusee) as cm:
            c.lancer(ad, "c-p2", **args)
        self.assertIn("rien payé", str(cm.exception))
        self.assertEqual([d for d, _ in recu], ["passe-1"])  # la passe 2 n'est jamais partie
        self.assertEqual(ad.appels, [])  # aucune passe Claude
        sortie = os.path.join(self.tmp, "c-p2")
        self.assertFalse(os.path.exists(os.path.join(sortie, "proposeurs", "argon", "passe-2")))
        with open(os.path.join(sortie, "manifeste-fin.json")) as f:
            fin = json.load(f)["reglages"]
        self.assertIn("garde de taille", fin["erreur"])
        g = fin["journal"]["gardes_taille_sessions"]
        self.assertEqual([(x["passe"], x["refusee"]) for x in g], [(1, False), (2, True)])
        self.assertEqual((g[1]["taille_max_caracteres"], g[1]["provision_sortie_caracteres"]), (passe1 + 50, 320_000))
        self.assertGreater(g[1]["taille_caracteres"], passe1 + 50)
        self.assertAlmostEqual(fin["journal"]["cout_externe_usd"], 0.1)  # la passe 1 seule
        # cas sain
        budgets[("proposeur_ideation", "gemini-argon")] = 2.5
        res = c.lancer(ad, "c-p2-ok", **args)
        self.assertEqual([(x["passe"], x["taille_max_caracteres"], x["refusee"]) for x in res["journal"]["gardes_taille_sessions"]],
                         [(1, 680_000, False), (2, 680_000, False)])  # v43 : 520 000

    # --- CL42-05 et W07 --------------------------------------------------------------------------------------------------

    def test_cl42_05_garde_du_bras_de_bout_en_bout_par_le_lanceur(self):
        """CL42-05, W07 : `--taille-max-consigne-externe 150000` donné au lanceur (consigné « option » au manifeste de
        départ, et appliqué aux passes d'Argon), puis bras **sans option** : la consigne du juge (≈ 210 000 caractères,
        pièce de juge de 200 000) passe sous la garde propre du bras (plafond du juge 3,5 / prix prudent moins la
        provision de sortie des fiches servies) → classement à trois juges (v42 : refus « donnée à la course »). Avec
        `--taille-max-consigne-externe-bras 1000` : code 5, refus scellé compté comme tentative non relançable, classement
        sans bras écrit, Argon jamais appelé ; la relance sans option se joue en tentative 2. Options croisées refusées."""
        import contextlib
        import io
        v41 = self.v41()
        prep, pj = self.prep_piece_juge()
        journal = os.path.join(self.tmp, "argon-w07.jsonl")
        argon = self.argon_journal(journal, "argon-w07.py")
        sortie = os.path.join(self.tmp, "l-w07")
        course = v41.base(sortie, prep, None, "--commande-externe", argon, "--piece-juge", pj,
                          "--taille-max-consigne-externe", "150000")
        code, out, err = v41.principal(v41.lanceur(), course)
        self.assertEqual(code, 0, err)
        with open(os.path.join(sortie, "manifeste-depart.json")) as f:
            v = json.load(f)["reglages"]["versions"]
        self.assertEqual((v["taille_max_consigne_externe"]["valeur"], v["taille_max_consigne_externe"]["origine"]),
                         (150_000, "option"))  # W07 : origine écrite par le lanceur
        with open(os.path.join(sortie, "manifeste-fin.json")) as f:
            j = json.load(f)["reglages"]["journal"]
        self.assertEqual([(x["passe"], x["taille_max_caracteres"]) for x in j["gardes_taille_sessions"]], [(1, 150_000)])
        att = self.cmd().attester(os.path.join(self.tmp, "att-w07.json"), sortie, "argon-j")
        bras = [sortie, "--bras-rapporte-differe", "--attestation-lecture-humaine", att, "--juge-externe", "argon-j=gemini-argon",
                "--commande-externe", argon]
        code, out, err = v41.principal(v41.lanceur(), bras)
        self.assertEqual(code, 0, err)  # v42 : 2, « donnée à la course »
        with open(os.path.join(sortie, "manifeste-bras-rapporte.json")) as f:
            gb = json.load(f)["reglages"]["journal"]["garde_taille"]["argon-j"]
        with open(os.path.join(sortie, "noyau", "cles-anonymisation-par-juge.json")) as f:
            servies = len(json.load(f)["argon-j"])
        self.assertEqual(gb["taille_max_caracteres"], 1_400_000 - servies * 10_000)
        self.assertTrue(gb["origine_taille_max"].startswith("défaut : plafond de la session du juge 3.5"))
        self.assertGreater(gb["taille_caracteres"], 200_000)
        with open(os.path.join(sortie, "classement.json")) as f:
            self.assertTrue(all(l["nombre_juges"] == 3 for l in json.load(f)["lignes"]))
        # option propre au bras : refus compté, classement sans bras, Argon jamais appelé
        sortie_b = os.path.join(self.tmp, "l-w07-b")
        code, out, err = v41.principal(v41.lanceur(), [sortie_b] + course[1:])
        self.assertEqual(code, 0, err)
        att_b = self.cmd().attester(os.path.join(self.tmp, "att-w07-b.json"), sortie_b, "argon-j")
        bras_b = [sortie_b] + bras[1:3] + [att_b] + bras[4:]
        n = len(self.journal_de(journal))
        code, out, err = v41.principal(v41.lanceur(), bras_b + ["--taille-max-consigne-externe-bras", "1000"])
        self.assertEqual(code, 5, err)
        self.assertIn("classement-sans-bras.json", err)
        self.assertEqual(len(self.journal_de(journal)), n)
        r = os.path.join(sortie_b, "manifeste-bras-refus-taille-1.json")
        self.assertTrue(idn.verifier_scelle(r))
        with open(r) as f:
            g = json.load(f)["reglages"]
        self.assertEqual((g["garde_taille"]["taille_max_caracteres"], g["tentative_comptee"], g["relancable"], g["cout_usd"]),
                         (1000, True, False, 0.0))
        cl = os.path.join(sortie_b, "classement-sans-bras.json")
        self.assertTrue(idn.verifier_scelle(cl))
        with open(cl) as f:
            self.assertTrue(all(l["nombre_juges"] == 2 for l in json.load(f)["lignes"]))
        self.assertFalse(os.path.exists(os.path.join(sortie_b, "manifeste-bras-rapporte.json")))
        for options in (bras_b + ["--taille-max-consigne-externe", "1000"],  # la valeur de la course ne vaut plus au bras
                        [os.path.join(self.tmp, "l-w07-c")] + course[1:] + ["--taille-max-consigne-externe-bras", "5"],
                        bras_b + ["--taille-max-consigne-externe-bras", "0"]):
            with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as cm:
                v41.lanceur().principal(options)
            self.assertEqual(cm.exception.code, 2)
        code, out, err = v41.principal(v41.lanceur(), bras_b)  # relance sans option : tentative 2, jouée
        self.assertEqual(code, 0, err)
        with open(os.path.join(sortie_b, "manifeste-bras-rapporte.json")) as f:
            self.assertEqual(json.load(f)["reglages"]["journal"]["tentative"], 2)

    # --- CL42-06 (S14, W36) ---------------------------------------------------------------------------------------------

    def test_cl42_06_echec_du_classement_de_repli_dit_et_scelle(self):
        """CL42-06 (S14 de CL9) : trois bras « non joués » (commande introuvable) ; à la troisième, non relançable, le
        classement de repli échoue (`_classer` qui lève) → code 2, le motif est dans l'exception levée et sur la sortie
        d'erreur, et `classement-sans-bras-impossible-3.json` est scellé (v42 : rien, ni fichier ni message). Après envoi
        (juge en erreur), même échec : fichier scellé, manifeste du bras et exception le disent."""
        import unittest.mock
        v41 = self.v41()
        prep = self.prep()
        sortie = os.path.join(self.tmp, "l-s14")
        code, out, err = v41.principal(v41.lanceur(), v41.base(sortie, prep, None, "--commande-externe",
                                                                " ".join(self.cmd().commande(self.cmd().SCRIPT_OK))))
        self.assertEqual(code, 0, err)
        att = self.cmd().attester(os.path.join(self.tmp, "att-s14.json"), sortie, "argon-j")
        bras = [sortie, "--bras-rapporte-differe", "--attestation-lecture-humaine", att, "--juge-externe", "argon-j=gemini-argon",
                "--commande-externe", "/chemin/qui/n/existe/pas"]

        def panne(*a, **k):
            raise RuntimeError("panne simulée du classement de repli (disque plein)")
        for n in (1, 2):
            code, out, err = v41.principal(v41.lanceur(), bras)
            self.assertEqual(code, 2, err)
        with unittest.mock.patch.object(idn, "_classer", panne):
            code, out, err = v41.principal(v41.lanceur(), bras)
        self.assertEqual(code, 2, err)
        self.assertIn("classement sans bras impossible : RuntimeError : panne simulée", err)
        self.assertIn("classement_sans_bras_impossible", err)
        chemin = os.path.join(sortie, "classement-sans-bras-impossible-3.json")
        self.assertTrue(idn.verifier_scelle(chemin))  # v42 : absent
        with open(chemin) as f:
            r = json.load(f)["reglages"]
        self.assertIn("panne simulée", r["classement_sans_bras_impossible"])
        self.assertIn("tentative 3 du bras non relançable", r["motif_du_repli"])
        self.assertFalse(os.path.exists(os.path.join(sortie, "classement-sans-bras.json")))
        # après envoi : juge en erreur, repli en panne → verrouillé, scellé, dit
        c, s2, att2, budgets = self.course_bras("rp-envoi")

        class JugeEnErreur(Enregistreur):
            def lancer(self, role, consigne, dossier, budget_usd, max_tours, modele=None):
                if consigne.startswith(idn.APPEL_DE_CONTROLE_CONSIGNE):
                    return Resultat("OK", [], 0.01, "ok")
                return Resultat("", [], 0.3, "erreur", "panne du juge")
        with unittest.mock.patch.object(idn, "_classer", panne), self.assertRaises(idn.CourseInterrompue) as cm:
            idn.executer_bras_differe(s2, attestation_lecture_humaine=att2, budgets=budgets,
                                      juges_externes=[("argon", "autre-lignee-x", JugeEnErreur(c))])
        self.assertNotIsInstance(cm.exception, idn.SansJugeExterne)
        self.assertIn("classement sans bras impossible", str(cm.exception))
        self.assertTrue(idn.verifier_scelle(os.path.join(s2, "classement-sans-bras-impossible-1.json")))
        with open(os.path.join(s2, "manifeste-bras-rapporte.json")) as f:
            self.assertIn("classement sans bras impossible", json.load(f)["reglages"]["erreur"])

    def test_cl42_06_w36_deux_tentatives_non_relancables_sans_ecrasement(self):
        """CL42-06, W36 : deux tentatives non relançables de suite — refus de taille (tentative 1 : classement sans bras
        écrit), puis contrôle « KO » payé 0,9 qui épuise le plafond externe (tentative 2) : le second repli est joué, ne
        réécrit pas le classement (même empreinte, motif de la tentative 1) et l'exception le dit ; aucun échec de repli
        (v42 : le refus de taille n'écrivait aucun classement). Un troisième refus de taille est la tentative 3 ; la quatrième
        est refusée avant tout appel (« 3 tentatives du bras déjà faites ») : les refus de taille comptent."""
        c, sortie, att, budgets = self.course_bras("w36")
        with self.assertRaises(idn.SansJugeExterne) as cm:
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                      juges_externes=[("argon", "autre-lignee-x", Enregistreur(c))], taille_max_consigne_externe=100)
        self.assertIn("tentative 1 du bras non relançable (refus de taille", str(cm.exception))
        cl = os.path.join(sortie, "classement-sans-bras.json")
        empreinte = idn.sha256_fichier(cl)

        class KoPaye(Enregistreur):
            def lancer(self, role, consigne, dossier, budget_usd, max_tours, modele=None):
                self.recu.append(consigne)
                return Resultat("KO", [], 0.9, "ok")
        ko = KoPaye(c)
        with self.assertRaises(idn.SansJugeExterne) as cm:
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                      juges_externes=[("argon", "autre-lignee-x", ko)])
        self.assertEqual(ko.recu, [idn.APPEL_DE_CONTROLE_CONSIGNE])  # le second a bien été joué (contrôle payé)
        self.assertIn("tentative 2 du bras échouée avant tout envoi des fiches", str(cm.exception))
        self.assertIn("classement-sans-bras.json déjà écrit par une tentative précédente : non réécrit", str(cm.exception))
        self.assertNotIn("impossible", str(cm.exception))
        with open(os.path.join(sortie, "bras-tentative-2.json")) as f:
            self.assertFalse(json.load(f)["reglages"]["relancable"])
        self.assertEqual(idn.sha256_fichier(cl), empreinte)
        with open(cl) as f:
            self.assertIn("tentative 1", json.load(f)["sans_juge_externe"])
        self.assertFalse(any(n.startswith("classement-sans-bras-impossible") for n in os.listdir(sortie)))
        # CL42-05 : les refus de taille comptent parmi les trois tentatives — un troisième (tentative 3), puis plus rien
        with self.assertRaises(idn.SansJugeExterne):
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                      juges_externes=[("argon", "autre-lignee-x", Enregistreur(c))], taille_max_consigne_externe=100)
        self.assertTrue(idn.verifier_scelle(os.path.join(sortie, "manifeste-bras-refus-taille-3.json")))
        juge = Enregistreur(c)
        with self.assertRaises(idn.CourseInterrompue) as cm:
            idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                      juges_externes=[("argon", "autre-lignee-x", juge)], taille_max_consigne_externe=100)
        self.assertNotIsInstance(cm.exception, idn.SansJugeExterne)
        self.assertIn("3 tentatives du bras déjà faites", str(cm.exception))
        self.assertEqual(juge.recu, [])

    # --- CL42-07 (W30, W35b) --------------------------------------------------------------------------------------------

    def test_cl42_07_w30_plafond_externe_non_fini_au_bras_sur_sortie_fraiche(self):
        """CL42-07, W30 : sur une SORTIE fraîche (bras jamais joué), `budget_externe_usd` NaN, +∞, négatif ou booléen →
        refus avant tout appel, juge jamais appelé, aucune `bras-tentative` ni aucun fichier du bras scellé ; même chose
        par le lanceur (`--budget-externe-usd nan`). L'essai de la v42 était vide (il échouait d'abord sur « déjà été
        joué ») ; le code de la v42 était juste : cet essai passe sur la v42 et tue W30."""
        c, sortie, att, budgets = self.course_bras("w30")
        avant = sorted(os.listdir(sortie))
        for valeur in (float("nan"), float("inf"), -1.0, True):
            juge = Enregistreur(c)
            with self.subTest(valeur=valeur), self.assertRaises(idn.CourseInterrompue) as cm:
                idn.executer_bras_differe(sortie, attestation_lecture_humaine=att, budgets=budgets,
                                          juges_externes=[("argon", "autre-lignee-x", juge)], budget_externe_usd=valeur)
            self.assertIn("budget_externe_usd", str(cm.exception))
            self.assertEqual(juge.recu, [])
            self.assertEqual(sorted(os.listdir(sortie)), avant)
        v41 = self.v41()
        prep = self.prep()
        journal = os.path.join(self.tmp, "argon-w30.jsonl")
        argon = self.argon_journal(journal, "argon-w30.py")
        s2 = os.path.join(self.tmp, "l-w30")
        code, out, err = v41.principal(v41.lanceur(), v41.base(s2, prep, None, "--commande-externe", argon))
        self.assertEqual(code, 0, err)
        att2 = self.cmd().attester(os.path.join(self.tmp, "att-l-w30.json"), s2, "argon-j")
        n = len(self.journal_de(journal))
        code, out, err = v41.principal(v41.lanceur(), [s2, "--bras-rapporte-differe", "--attestation-lecture-humaine", att2,
                                                       "--juge-externe", "argon-j=gemini-argon", "--commande-externe", argon,
                                                       "--budget-externe-usd", "nan"])
        self.assertEqual(code, 2)
        self.assertIn("budget_externe_usd", err)
        self.assertEqual(len(self.journal_de(journal)), n)
        self.assertFalse(any(x.startswith(("bras-", "manifeste-bras", "classement")) for x in os.listdir(s2)))

    def test_cl42_04_borne_de_fiche_retiree_et_refus_pour_taille_par_proposeur(self):
        """CL42-04 (décision de Lazar : « retirer ») et CL42-07 : la consigne des proposeurs ne dit plus « 12000 caractères au
        plus par fiche » (consigne construite et consigne reçue par Argon) ; une fiche de plus de 40 000 caractères servis,
        champs dans leurs bornes (`fiche_maximale`), est admise ; les bornes par champ et de listes restent, et leurs refus
        sont comptés **par proposeur et par passe**, au journal et au manifeste de fin (Argon 2 : un champ de 3 001
        caractères, dix questions servies ; Opus 1 : treize antériorités ; Fable 0 — son refus pour un signe hors valeurs
        n'est pas un refus pour taille). Remplace l'essai W35b (la phrase n'existe plus). v42 : phrase présente, fiche de
        44 259 caractères refusée, aucun compte."""
        c = self.cours()
        prep = self.prep()
        c._prep = prep
        liste = idn.charger_liste_blanche(prep["liste_blanche"])
        consigne = idn.consigne_proposeur(idn.lire_pieces(prep["pieces"], liste), 8, "Quelles questions ?")
        self.assertNotIn("caractères au plus par fiche", consigne)
        self.assertIn("au plus 9 questions servies, au plus 12 antériorités, 3000 caractères au plus par texte.", consigne)
        fm = idn.valider_fiche_ideation(idn.fiche_maximale(), "a", 1)
        self.assertGreater(idn.taille_servie(fm), 40_000)
        trop_long = fiche_brute(nom="Champ trop long", enonce="y" * (idn.LONGUEUR_MAX_CHAMP + 1))
        with self.assertRaises(idn.FicheTropLongue):
            idn.valider_fiche_ideation(trop_long, "a", 1)
        recu = []

        class Argon:
            nom = "argon-simule"

            def lancer(self, role, consigne, dossier, budget_usd, max_tours, modele=None):
                recu.append(consigne)
                fiches = [dict(idn.fiche_maximale(), nom="Argon maximal"), dict(trop_long, nom="Argon trop long"),
                          fiche_brute(nom="Argon dix questions", questions_servies=["Q1"] * 10)]
                return Resultat("```json\n" + json.dumps({"fiches": fiches}, ensure_ascii=False) + "\n```", [], 0.1, "ok")
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1"), fiche_brute(nom="O treize", anteriorite=[
                                 {"reference": "r", "statut": "SUPPOSE"}] * 13)],
                             "fable": [fiche_brute(nom="F1"), fiche_brute(nom="F signe", loi_predictive={"signe": "?"})]},
                            notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        budgets = dict(c.budgets())
        budgets[("proposeur_ideation", "gemini-argon")] = 1.0
        res = c.lancer(ad, "c-refus-taille", budgets=budgets, proposeurs_externes=[("argon", "gemini-argon", Argon())],
                       budget_externe_usd=3.0)
        self.assertNotIn("caractères au plus par fiche", recu[0])
        self.assertIn("Argon maximal", [f["nom"] for f in res["fiches"]])  # 44 259 caractères servis, admise
        attendu = {"argon": {"passe-1": 2, "total": 2}, "opus": {"passe-1": 1, "total": 1}, "fable": {"passe-1": 0, "total": 0}}
        self.assertEqual(res["journal"]["refus_pour_taille_par_proposeur"], attendu)
        self.assertEqual(len(res["refus"]), 4)
        with open(os.path.join(self.tmp, "c-refus-taille", "manifeste-fin.json")) as f:
            fin = json.load(f)["reglages"]
        self.assertEqual(fin["refus_pour_taille_par_proposeur"], attendu)
        self.assertEqual(fin["journal"]["refus_pour_taille_par_proposeur"], attendu)

    # --- CL40-01, option (c) -----------------------------------------------------------------------------------------

    def test_cl40_01_c_relance_sans_rejouer_les_controles_reussis(self):
        """CL40-01, option (c) (décision de Lazar) : réglages du devis, contrôles Claude payés 0,2 et réussis, Argon « OK » à
        0,15 (commande A), puis panne du cœur avant son départ → tentative 1 relançable (0,4 + 0 + 39,6 = 40,0 ≤ 40 ; v42 :
        40,4 > 40, non relançable). Tentative 2 avec une autre commande d'Argon, qui rend « KO » : Argon rejoué (commande
        changée), échoue ; Claude **jamais rappelé**, ses contrôles repris. Tentative 3 avec une commande d'Argon qui marche :
        **seul le contrôle d'Argon est repayé**, Claude n'est pas rappelé pour ses contrôles, la course part ; manifeste de
        départ et journal : contrôles Claude repris de la tentative 1 (empreinte du fichier, de la consigne), coûts imputés
        Claude 0,4 (et non 0,8) et Argon 0,15 + 0,15 + 2,5."""
        import unittest.mock
        v41 = self.v41()
        prep, att = v41.prep_devis()
        lanceur = v41.lanceur(cout_controle_claude=0.2)
        appels_claude = []
        original = lanceur.AdaptateurIdeationSimule.lancer

        def lancer(s, role, consigne, dossier, budget_usd, max_tours, modele=None):
            appels_claude.append((modele, consigne.startswith(idn.APPEL_DE_CONTROLE_CONSIGNE)))
            return original(s, role, consigne, dossier, budget_usd, max_tours, modele)
        lanceur.AdaptateurIdeationSimule.lancer = lancer
        journal = os.path.join(self.tmp, "argon-c.log")
        argon_a = v41.script(v41.SCRIPT_CTRL_OK % journal, "argon-a.py")
        argon_ko = v41.script(v41.SCRIPT_KO % journal, "argon-ko.py")
        argon_b = v41.script(v41.SCRIPT_PLAFOND, "argon-b.py")
        sortie = os.path.join(self.tmp, "l-c")

        def panne(*a, **k):
            raise idn.CourseInterrompue("panne simulée du cœur avant son départ")
        with unittest.mock.patch.object(idn, "executer_ideation", panne):
            code, _, err = v41.principal(lanceur, v41.base(sortie, prep, att, "--commande-externe", argon_a))
        self.assertEqual(code, 2, err)
        t1 = os.path.join(sortie + "-controle", "tentative-1.json")
        with open(t1) as f:
            r1 = json.load(f)["reglages"]
        self.assertEqual((round(r1["cout_claude_usd"], 6), round(r1["cout_externe_usd"], 6)), (0.4, 0.15))
        self.assertEqual(r1["controles_a_refaire"], [])
        self.assertTrue(r1["relancable"], r1["motifs_relance"])  # v42 : 40,4 > 40
        self.assertEqual(sum(1 for _, ctrl in appels_claude if ctrl), 2)
        # tentative 2 : Argon (autre commande) rejoué, « KO » ; Claude jamais rappelé
        appels_claude.clear()
        code, _, err = v41.principal(lanceur, v41.base(sortie, prep, att, "--commande-externe", argon_ko))
        self.assertEqual(code, 2, err)
        self.assertEqual(appels_claude, [])
        with open(os.path.join(sortie + "-controle", "tentative-2.json")) as f:
            r2 = json.load(f)["reglages"]
        self.assertEqual(sorted(r2["lectures"]), ["externe:argon"])
        self.assertEqual(sorted(r2["controles_repris"]), ["claude-fable-5-1", "claude-opus-5-5"])
        self.assertEqual((r2["cout_claude_usd"], round(r2["cout_externe_usd"], 6)), (0.0, 0.15))
        self.assertEqual(r2["controles_a_refaire"], ["externe:argon"])
        self.assertTrue(r2["relancable"], r2["motifs_relance"])
        # tentative 3 : seul le contrôle d'Argon est repayé ; la course part
        appels_claude.clear()
        code, _, err = v41.principal(lanceur, v41.base(sortie, prep, att, "--commande-externe", argon_b))
        self.assertIn(code, (0, 4), err)
        self.assertFalse(any(ctrl for _, ctrl in appels_claude))  # aucun contrôle Claude rejoué
        self.assertTrue(appels_claude)  # les sessions Claude de la course, elles, ont eu lieu
        with open(os.path.join(sortie, "manifeste-depart.json")) as f:
            d = json.load(f)["reglages"]
        self.assertAlmostEqual(d["cout_deja_engage_usd"], 0.4)  # imputé une fois (v42 : contrôles rejoués, 0,8)
        self.assertAlmostEqual(d["cout_externe_deja_engage_usd"], 0.15 + 0.15 + 2.5)
        repris = d["versions"]["controles_repris"]
        self.assertEqual(sorted(repris), ["claude-fable-5-1", "claude-opus-5-5"])
        for v in repris.values():
            self.assertEqual((v["repris_de_tentative"], v["sha256_tentative"]), (1, idn.sha256_fichier(t1)))
            self.assertEqual(v["consigne_sha256"], r1["lectures"][v["controle"]]["consigne_sha256"])
        self.assertEqual(sorted(d["versions"]["appel_de_controle"]), ["externe:argon"])
        with open(os.path.join(sortie, "manifeste-fin.json")) as f:
            self.assertEqual(json.load(f)["reglages"]["journal"]["controles_repris"], repris)

    # --- CL42-03 ---------------------------------------------------------------------------------------------------------

    def test_cl42_03_mesurer_consignes_sans_appel(self):
        """CL42-03 : `--mesurer-consignes` écrit les tailles réelles (contrôle d'Argon, passe 2 maximale, juge au
        maximum : 3 proposeurs × 2 passes × 8 fiches maximales + 4 témoins + pièce de juge) et les gardes (course 520 000 ;
        bras 1 400 000 − 52 × 10 000), code 0, sans aucun appel (adaptateurs piégés, commande jamais lancée), sans fichier
        ni SORTIE, même avec `--moteur claude-sdk` non armé. La course réelle lancée ensuite envoie à Argon un contrôle de
        la taille mesurée, et une consigne de juge plus petite que le maximum mesuré (v42 : option inconnue). v43 (CL42-04 b) :
        coûts et gardes au prix donné (`--prix-entree-usd-par-million-jetons 8.3` : garde 724 819) et figures de la provision
        demandée (huit fiches à `fiche_maximale()`, 1 770 360 caractères équivalents), rapportées, non appliquées (garde 0).
        Course lancée sans option : chaque passe d'Argon gardée par le cœur à 520 000 (provision 480 000).
        v44 (CL43-02, changé) : passes gardées à 680 000 (provision de huit fiches de 8 000, 320 000)."""
        import unittest.mock
        from pole.adaptateurs import AdaptateurCommandeExterne
        v41 = self.v41()
        prep, att = v41.prep_devis()
        lb2 = os.path.join(self.tmp, "liste-blanche-mesure.json")
        pj = os.path.join(self.tmp, "piece-juge-mesure.md")
        with open(pj, "w", encoding="utf-8") as f:
            f.write("# Antériorité\n" + "Résumé. " * 3000)
        idn.construire_liste_blanche([prep["pieces"][0], prep["question"], prep["materiau"][0], prep["temoins"], pj], lb2)
        prep = dict(prep, liste_blanche=lb2)
        journal = os.path.join(self.tmp, "argon-mesure.jsonl")
        argon = self.argon_journal(journal, "argon-mesure.py")
        sortie = os.path.join(self.tmp, "l-mesure")
        argv = v41.base(sortie, prep, att, "--commande-externe", argon, "--piece-juge", pj)

        def piege(*a, **k):
            raise AssertionError("aucun appel ne doit partir")
        lanceur = v41.lanceur()
        with unittest.mock.patch.object(lanceur.AdaptateurIdeationSimule, "lancer", piege), \
                unittest.mock.patch.object(AdaptateurCommandeExterne, "lancer", piege):
            code, out, err = v41.principal(lanceur, argv + ["--mesurer-consignes"])
            code_r, out_r, err_r = v41.principal(lanceur, argv + ["--mesurer-consignes", "--moteur", "claude-sdk"])
            code_p, out_p, err_p = v41.principal(lanceur, argv + ["--mesurer-consignes", "--prix-entree-usd-par-million-jetons",
                                                                  "8.3"])
        self.assertEqual((code, code_r, code_p), (0, 0, 0), err + err_r + err_p)
        m = json.loads(out)
        self.assertEqual(json.loads(out_r)["consignes"], m["consignes"])
        mp = json.loads(out_p)
        ctrl = m["consignes"]["consigne_de_controle_externe"]
        self.assertEqual((m["prix_entree_usd_par_million_jetons"], mp["prix_entree_usd_par_million_jetons"]), (10.0, 8.3))
        self.assertAlmostEqual(m["garde_course"]["cout_entree_controle_usd"], round(ctrl * 2.5e-6, 4))
        self.assertAlmostEqual(mp["garde_course"]["cout_entree_controle_usd"], round(ctrl * 8.3e-6 / 4, 4))
        self.assertEqual(mp["garde_course"]["taille_max_caracteres"], 724_819)
        for x in (m, mp):
            nd = x["garde_course"]["provision_huit_fiches_maximales_non_appliquee"]
            self.assertEqual((nd["provision_sortie_caracteres"], nd["taille_max_caracteres"]), (8 * idn.taille_servie(idn.fiche_maximale()) * 5, 0))
        self.assertFalse(os.path.exists(sortie) or os.path.exists(sortie + "-controle") or os.path.exists(journal))
        budgets = dict(self.cours().budgets())
        budgets[("proposeur_ideation", "gemini-argon")] = 2.5
        budgets[("juge_ideation", "gemini-argon")] = 3.5
        verif = idn.verifier_reglages(liste_blanche=lb2, question=prep["question"], pieces=prep["pieces"],
                                      materiau=prep["materiau"], temoins=prep["temoins"], seconde_passe=True,
                                      attestation_materiau=att, budgets=budgets, budget_total_usd=40.0, budget_externe_usd=12.0,
                                      proposeurs=[("opus", "claude-opus-5-5"), ("fable", "claude-fable-5-1")],
                                      juges=[("juge-fable", "claude-fable-5-1"), ("juge-opus", "claude-opus-5-5")],
                                      proposeurs_externes=[("argon", "gemini-argon")])
        cs = m["consignes"]
        self.assertEqual(cs["consigne_de_controle_externe"], verif["taille_consigne_controle_externe"])
        self.assertEqual(len(idn.consigne_de_controle(verif["texte_controle_externe"])), cs["consigne_de_controle_externe"])
        self.assertEqual(cs["consigne_passe_2_maximale"], len(verif["texte_controle_externe"]))
        self.assertEqual((cs["fiches_au_juge_au_maximum"], cs["controle_du_bras"]), (52, 41))
        self.assertGreater(cs["consigne_du_juge_maximale"], 48 * 12_000)
        self.assertEqual((m["garde_course"]["taille_max_caracteres"], m["garde_course"]["passerait"]), (520_000, True))
        self.assertEqual(m["garde_bras"]["argon-j"]["taille_max_caracteres"], 1_400_000 - 52 * 10_000)
        # la course réelle : contrôle d'Argon de la taille mesurée ; consigne du juge sous le maximum mesuré
        code, out, err = v41.principal(v41.lanceur(), argv)
        self.assertEqual(code, 0, err)
        appels = self.journal_de(journal)
        self.assertEqual(appels[0]["controle"], True)
        self.assertEqual(appels[0]["taille"], cs["consigne_de_controle_externe"])
        self.assertLessEqual(max(a["taille"] for a in appels if a["passe2"] and not a["controle"]), cs["consigne_passe_2_maximale"])
        with open(os.path.join(sortie, "juges-bras-rapporte", "traces-argon-j", "consigne-en-attente.md"), encoding="utf-8") as f:
            self.assertLess(len(f.read()), cs["consigne_du_juge_maximale"])
        # CL42-01 : sans option, le lanceur fait garder chaque passe d'Argon par le cœur contre son propre plafond
        with open(os.path.join(sortie, "manifeste-fin.json")) as f:
            g = json.load(f)["reglages"]["journal"]["gardes_taille_sessions"]
        self.assertEqual([(x["passe"], x["taille_max_caracteres"], x["provision_sortie_caracteres"], x["refusee"]) for x in g],
                         [(1, 680_000, 320_000, False), (2, 680_000, 320_000, False)])  # v43 : 520 000, 480 000



class TestV44(CasAvecDossier):
    """v44 (contre-lecture CL10 de la v43 ; périmètre minimal de session-depot pour lancer) : plafond propre à la passe 2
    d'Argon et somme externe de (β) (CL43-01) ; chaque passe gardée contre son propre plafond moins la provision de sortie,
    même sous une taille donnée (CL43-02) ; contrôles Claude repris seulement si le relais n'a pas été relancé (CL43-03) ;
    fichier d'entrée changé entre deux tentatives (X01) ; borne de trois tentatives dite (CL43-05) ; mesures de
    convergence au manifeste de fin (ajout de Lazar)."""

    BETA = ["--budget-controle-externe-usd", "3.1", "--budget-passe-2-externe-usd", "3.1", "--budget-externe-usd", "12.8",
            "--prix-entree-usd-par-million-jetons", "8.3", "--taille-max-consigne-externe", "1490000"]
    BRAS_BETA = ["--prix-entree-usd-par-million-jetons", "8.3", "--budget-externe-usd", "12.8"]

    def v43(self):
        t = TestV43("test_cl42_03_mesurer_consignes_sans_appel")
        t.tmp = self.tmp
        return t

    # Argon factice au barème donné (dollars par caractère d'entrée et de sortie ; jamais borné à son plafond), huit fiches
    # copiées d'une fiche donnée, juge qui respecte le critère des témoins ; chaque appel consigné
    SCRIPT_TARIF_8 = (
        "import sys, json, os, re\nc = sys.stdin.read()\nctrl = c.startswith('Réponds exactement OK')\n"
        "def sortir(t):\n"
        "    cout = len(c) * %r + len(t) * %r\n"
        "    open(%r, 'a').write(json.dumps({'taille': len(c), 'controle': ctrl, 'role': os.environ['ROLE_POLE'], "
        "'passe2': 'première passe' in c, 'cout': cout, 'plafond': float(os.environ['PLAFOND_SESSION_USD'])}) + '\\n')\n"
        "    print(json.dumps({'texte': t, 'cout_usd': cout})); sys.exit(0)\n"
        "if ctrl: sortir('OK')\n"
        "if os.environ['ROLE_POLE'] == 'proposeur_ideation':\n"
        "    f = json.loads(%r)\n"
        "    fiches = [dict(f, nom=('Argon %%d' %% i) + (' revue' if 'première passe' in c else '')) for i in range(8)]\n"
        "    sortir('```json\\n' + json.dumps({'fiches': fiches}, ensure_ascii=False) + '\\n```')\n"
        "bloc = json.loads(re.search(r'```json\\n(\\[.*\\])\\n```', c, re.S).group(1)); par_nom = {f['nom']: f['identifiant'] for f in bloc}\n"
        "notes = []\n"
        "for f in bloc:\n"
        "    k = {x: 2 for x in ('avantage', 'originalite', 'falsifiabilite', 'traitabilite', 'robustesse')}\n"
        "    if f['nom'] in ('Verbeux vide', 'Assuré occupé'): k.update({'avantage': 1, 'originalite': 0, 'falsifiabilite': 0})\n"
        "    notes.append({'identifiant': f['identifiant'], 'criteres': k, 'justifications': {}})\n"
        "sortir('```json\\n' + json.dumps({'notes': notes, 'doublons': [[par_nom['Jumeau'], par_nom['Sobre fort']]]}) + '\\n```')\n")

    def argon_tarif(self, fiche, journal, nom):
        return self.v43().v41().script(self.SCRIPT_TARIF_8 % (8.3e-6 / 4, 41.5e-6 / 4, journal, json.dumps(fiche, ensure_ascii=False)),
                                       nom)

    @staticmethod
    def fiche_de_taille(cible):
        """Une fiche au gabarit dont la taille servie est la plus petite ≥ `cible` (douze textes de même longueur)."""
        for n in range(1, 3000):
            t = ("texte de méthode sans signal " * (n // 29 + 1))[:n]
            f = fiche_brute(nom="Argon", enonce=t, perte_traduction=t, piege=t, cosmetique_si=t,
                            loi_predictive={"espace_instances": t, "prediction": t, "metrique": t},
                            avantage={"texte": t, "incopiable_parce_que": t}, originalite={"texte": t},
                            demande_organisme={"texte": t}, cout={"ordre_de_grandeur": t})
            if idn.taille_servie(idn.valider_fiche_ideation(f, "a", 1)) >= cible:
                return f
        raise AssertionError(cible)

    def journal(self, chemin):
        return self.v43().journal_de(chemin)

    # --- CL43-01 ---------------------------------------------------------------------------------------------------------

    def test_cl43_01_plafond_de_passe_2_et_somme_externe_de_beta(self):
        """CL43-01 : `--budget-passe-2-externe-usd` (plafond de la seule passe 2 d'Argon ; v43 : option inconnue). Ligne (β)
        aux réglages du devis (pièce 750 000, matériau 350 000) : somme externe 3,1 + 2,5 + 3,1 + 3,5 + 0,2 = 12,4 ≤ 12,8,
        `verifier_reglages` l'accepte (passe 1 gardée à 884 819 avant tout contrôle) ; `--budget
        "proposeur_ideation|gemini-argon=3.1"` à la place (les deux passes à 3,1) : 13,0 > 12,8, refus avant tout appel,
        Argon jamais appelé, aucun fichier. Sans l'option : la passe 2 prend le plafond de la passe 1 (comme en v43). Option
        non finie, nulle, ou sans `--seconde-passe` : refusée par l'analyseur."""
        import contextlib
        import io
        v43 = self.v43()
        v41 = v43.v41()
        prep, att = v43.prep_grand()
        budgets = dict(self.v43().cours().budgets())
        budgets.update({("proposeur_ideation", "gemini-argon"): 2.5, ("juge_ideation", "gemini-argon"): 3.5})
        commun = dict(liste_blanche=prep["liste_blanche"], question=prep["question"], pieces=prep["pieces"],
                      materiau=prep["materiau"], temoins=prep["temoins"], seconde_passe=True, attestation_materiau=att,
                      budgets=budgets, budget_total_usd=40.0, budget_externe_usd=12.8, cout_controles_externes_prevu_usd=3.1,
                      proposeurs=[("opus", "claude-opus-5-5")], juges=[("juge-opus", "claude-opus-5-5")],
                      proposeurs_externes=[("argon", "gemini-argon")], juges_externes=[("argon-j", "gemini-argon")],
                      taille_max_consigne_externe=1_490_000, prix_caractere_usd=idn.prix_caractere(8.3), taille_max_pieces=750_000)
        v = idn.verifier_reglages(budget_passe_2_externe_usd=3.1, garder_passes_externes=True, **commun)
        self.assertAlmostEqual(v["somme_externe"], 12.4)
        self.assertEqual(v["garde_passe_1"]["argon"]["taille_max_caracteres"], 884_819)
        self.assertAlmostEqual(idn.verifier_reglages(**commun)["somme_externe"], 11.8)  # passe 2 = passe 1 (v43)
        with self.assertRaises(idn.CourseInterrompue):
            idn.verifier_reglages(budget_passe_2_externe_usd=float("nan"), **commun)
        journal = os.path.join(self.tmp, "argon-cl43-01.jsonl")
        argon = self.argon_tarif(fiche_brute(nom="Argon"), journal, "argon-cl43-01.py")
        sortie = os.path.join(self.tmp, "l-cl43-01")
        treize = ["--budget-controle-externe-usd", "3.1", "--budget-externe-usd", "12.8", "--prix-entree-usd-par-million-jetons",
                  "8.3", "--taille-max-consigne-externe", "1490000", "--budget", "proposeur_ideation|gemini-argon=3.1"]
        code, out, err = v41.principal(v41.lanceur(), v41.base(sortie, prep, att, "--commande-externe", argon, *treize))
        self.assertEqual(code, 2, err)
        self.assertIn("somme des plafonds externes 13.00 > total externe 12.8", err)
        self.assertEqual(self.journal(journal), [])
        self.assertFalse(os.path.exists(sortie) or os.path.exists(sortie + "-controle"))
        for options in (["--budget-passe-2-externe-usd", "nan"], ["--budget-passe-2-externe-usd", "0"]):
            with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as cm:
                v41.lanceur().principal(v41.base(sortie, prep, att, "--commande-externe", argon, *options))
            self.assertEqual(cm.exception.code, 2)
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            v41.lanceur().principal(v41.base(sortie, prep, None, "--commande-externe", argon, "--budget-passe-2-externe-usd", "3.1"))

    # --- CL43-02 ---------------------------------------------------------------------------------------------------------

    def test_cl43_02_passe_2_refusee_avant_envoi_fiches_de_8950(self):
        """CL43-02 (B-p31-b83-g700 de CL10, sous (β)) : fiches d'Argon de ≈ 8 950 caractères servis, Argon au barème 8,3
        (sortie au rapport 5), garde donnée 1 490 000 : contrôle 3,02 et passe 1 ≈ 2,31 payés ; la passe 2 (≈ 1 175 000
        caractères) est **refusée avant envoi** contre son plafond 3,1 moins la provision de huit fiches de la plus grande
        fiche admise de passe 1 (1 493 975 − 40 × 8 950 ≈ 1 135 975), au lieu d'être payée 3,18 > 3,1 ; aucune passe
        Claude ; manifeste de fin scellé en erreur, gardes au journal (v43 : option de passe 2 inconnue ; sous la garde
        donnée, passe 2 gardée à 1 490 000 seulement, partie)."""
        v43 = self.v43()
        v41 = v43.v41()
        prep, att = v43.prep_grand()
        fiche = self.fiche_de_taille(8_950)
        journal = os.path.join(self.tmp, "argon-8950.jsonl")
        argon = self.argon_tarif(fiche, journal, "argon-8950.py")
        sortie = os.path.join(self.tmp, "l-8950")
        code, out, err = v41.principal(v41.lanceur(), v41.base(sortie, prep, att, "--commande-externe", argon, *self.BETA))
        self.assertEqual(code, 2, err)
        self.assertIn("garde de taille : consigne de la passe 2", err)
        appels = self.journal(journal)
        self.assertEqual([(a["controle"], a["passe2"]) for a in appels], [(True, True), (False, False)])  # contrôle, passe 1
        self.assertLessEqual(appels[0]["cout"], 3.1)
        self.assertLessEqual(appels[1]["cout"], 2.5)
        with open(os.path.join(sortie, "manifeste-fin.json")) as f:
            fin = json.load(f)["reglages"]
        g = fin["journal"]["gardes_taille_sessions"]
        self.assertEqual([(x["passe"], x["refusee"], x["plafond_usd"]) for x in g], [(1, False, 2.5), (2, True, 3.1)])
        self.assertEqual(g[0]["taille_max_caracteres"], 884_819)
        tf = g[1]["taille_fiche_provisionnee"]
        self.assertGreaterEqual(tf, 8_950)
        self.assertEqual((g[1]["provision_sortie_caracteres"], g[1]["taille_max_caracteres"]), (40 * tf, 1_493_975 - 40 * tf))
        self.assertGreater(g[1]["taille_caracteres"], g[1]["taille_max_caracteres"])
        self.assertLess(g[1]["taille_caracteres"], 1_490_000)  # la garde donnée seule l'aurait laissée partir (v43)
        self.assertAlmostEqual(fin["journal"]["cout_externe_usd"], appels[0]["cout"] + appels[1]["cout"], places=6)
        self.assertFalse(any(a["role"] == "proposeur_ideation" and not a["externe"] for a in fin["journal"]["appels"]))

    def test_cl43_02_fiches_maximales_et_fiches_courtes(self):
        """CL43-02 : (1) passe 1 trop grosse pour son plafond moins la provision (passe 1 à 1,0) → **refusée avant tout
        contrôle**, refus scellé (`refus-taille-1.json`), Argon et Claude jamais appelés ; (2) fiches d'Argon au maximum par
        champ (44 259) sous (β) : la passe 1 ne peut pas être gardée sur des fiches qu'elle n'a pas encore rendues (sa
        garde, 884 819, la laisse partir ; réserve dite au LISEZMOI) ; sa réponse dépasse son plafond (`budget_depasse`),
        la course s'arrête et la passe 2 n'est **jamais envoyée** ; au cœur, passe 1 tenue (plafond 6,0) : passe 2 refusée
        avant envoi (provision de huit fiches de 44 259, garde 0) ; (3) fiches courtes sous (β) : tout passe, gardes
        884 819 et 1 173 975, puis bras au barème 8,3 → classement à trois juges ; `--mesurer-consignes` aux mêmes réglages
        rapporte les gardes des passes (v43 : option inconnue)."""
        v43 = self.v43()
        v41 = v43.v41()
        prep, att = v43.prep_grand()
        # (1) passe 1 refusée avant tout contrôle
        journal = os.path.join(self.tmp, "argon-p1.jsonl")
        argon = self.argon_tarif(fiche_brute(nom="Argon"), journal, "argon-p1.py")
        s1 = os.path.join(self.tmp, "l-p1")
        code, out, err = v41.principal(v41.lanceur(), v41.base(s1, prep, att, "--commande-externe", argon, *self.BETA,
                                                               "--budget", "proposeur_ideation|gemini-argon=1.0"))
        self.assertEqual(code, 2, err)
        self.assertEqual(self.journal(journal), [])
        with open(os.path.join(s1 + "-controle", "refus-taille-1.json")) as f:
            g = json.load(f)["reglages"]
        self.assertIn("passe 1", g["garde_taille"]["quoi"])
        self.assertEqual((g["cout_usd"], g["tentative_comptee"]), (0.0, False))
        self.assertFalse(os.path.exists(s1))
        # (2) fiches maximales sous (β)
        jmax = os.path.join(self.tmp, "argon-max.jsonl")
        amax = self.argon_tarif(idn.fiche_maximale(), jmax, "argon-max.py")
        s2 = os.path.join(self.tmp, "l-max")
        code, out, err = v41.principal(v41.lanceur(), v41.base(s2, prep, att, "--commande-externe", amax, *self.BETA))
        self.assertEqual(code, 2, err)
        self.assertEqual([(a["controle"], a["passe2"]) for a in self.journal(jmax)], [(True, True), (False, False)])
        with open(os.path.join(s2, "manifeste-fin.json")) as f:
            fin = json.load(f)["reglages"]
        self.assertIn("budget_depasse", fin["erreur"])
        self.assertEqual([x["passe"] for x in fin["journal"]["gardes_taille_sessions"]], [1])
        c = v43.cours()
        c._prep = v43.prep()
        recu = []

        class ArgonMax:
            nom = "argon-simule"

            def lancer(self, role, consigne, dossier, budget_usd, max_tours, modele=None):
                recu.append(os.path.basename(dossier))
                fiches = [dict(idn.fiche_maximale(), nom=f"Argon {i}") for i in range(8)]
                return Resultat("```json\n" + json.dumps({"fiches": fiches}, ensure_ascii=False) + "\n```", [], 5.0, "ok")
        ad = FauxAdaptateur({"opus": [fiche_brute(nom="O1")], "fable": [fiche_brute(nom="F1")]},
                            notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        budgets = dict(c.budgets())
        budgets[("proposeur_ideation", "gemini-argon")] = 6.0
        att_p = os.path.join(self.tmp, "att-max.json")
        idn.ecrire_json_scelle(att_p, {"lecteur": "Lazar", "lu_le": "2026-10-29", "materiau_sha256": {
            os.path.basename(c._prep["materiau"][0]): idn.sha256_fichier(c._prep["materiau"][0])}})
        with self.assertRaises(idn.TailleConsigneRefusee):
            c.lancer(ad, "c-max", budgets=budgets, proposeurs_externes=[("argon", "gemini-argon", ArgonMax())],
                     budget_externe_usd=10.0, seconde_passe=True, attestation_materiau=att_p, garder_sessions_externes=True,
                     budget_passe_2_externe_usd=3.1, prix_caractere_usd=idn.prix_caractere(8.3))
        self.assertEqual(recu, ["passe-1"])
        self.assertEqual(ad.appels, [])
        # (3) fiches courtes sous (β) : tout passe, trois juges
        jc = os.path.join(self.tmp, "argon-court.jsonl")
        ac = self.argon_tarif(fiche_brute(nom="Argon"), jc, "argon-court.py")
        s3 = os.path.join(self.tmp, "l-court")
        lanceur = v41.lanceur()
        code, out, err = v41.principal(lanceur, v41.base(s3, prep, att, "--commande-externe", ac, *self.BETA, "--mesurer-consignes"))
        self.assertEqual(code, 0, err)
        gp = json.loads(out)["gardes_passes_externes"]["argon"]
        self.assertEqual((gp["passe_1"]["taille_max_caracteres"], gp["passe_1"]["passerait"]), (884_819, True))
        self.assertEqual(gp["passe_2_fiches_de_passe_1_au_plus_provisionnees"]["taille_max_caracteres"], 1_173_975)
        self.assertFalse(gp["passe_2_maximale"]["passerait"])
        self.assertFalse(os.path.exists(s3))
        code, out, err = v41.principal(lanceur, v41.base(s3, prep, att, "--commande-externe", ac, *self.BETA))
        self.assertEqual(code, 0, err)
        with open(os.path.join(s3, "manifeste-fin.json")) as f:
            g = json.load(f)["reglages"]["journal"]["gardes_taille_sessions"]
        self.assertEqual([(x["passe"], x["taille_max_caracteres"], x["refusee"]) for x in g],
                         [(1, 884_819, False), (2, 1_173_975, False)])
        self.assertTrue(all(a["cout"] <= a["plafond"] for a in self.journal(jc)))
        att_b = v43.cmd().attester(os.path.join(self.tmp, "att-court.json"), s3, "argon-j")
        code, out, err = v41.principal(lanceur, [s3, "--bras-rapporte-differe", "--attestation-lecture-humaine", att_b,
                                                 "--juge-externe", "argon-j=gemini-argon", "--commande-externe", ac,
                                                 *self.BRAS_BETA])
        self.assertEqual(code, 0, err)
        with open(os.path.join(s3, "classement.json")) as f:
            self.assertTrue(all(l["nombre_juges"] == 3 for l in json.load(f)["lignes"]))

    # --- CL43-03 ---------------------------------------------------------------------------------------------------------

    def test_cl43_03_controles_claude_rejoues_si_le_relais_a_ete_relance(self):
        """CL43-03 : chemin du moteur réel (kit, bac à sable et relais remplacés par des faux locaux ; aucun réseau, aucune
        clé) ; tentative 1 : contrôles Claude payés 0,2 chacun et réussis (dépense lue au relais 0,2 puis 0,4), panne du
        cœur ; tentative 2, relais gardé (dépense 0,4) : contrôles Claude **repris**, motif « relais non relancé » ;
        tentative 3, relais relancé (dépense remise à 0) : contrôles Claude **rejoués** (v43 : repris), motif « relais
        relancé » au manifeste de départ, au journal du cœur et sur la sortie d'erreur ; la course part."""
        import types
        import unittest.mock
        import pole.adaptateurs as pa
        v41 = self.v43().v41()
        prep, att = v41.prep_devis()
        lanceur = v41.lanceur()
        relais = {"appels": 0, "depense_usd": 0.0, "plafond_usd": 50.0, "reserve_par_appel_usd": 4.0}
        appels = []
        simule = lanceur.AdaptateurIdeationSimule(1)

        class FauxKit:
            nom = "claude-sdk"

            def __init__(self, *a, **k):
                pass

            def lancer(self, role, consigne, dossier, budget_usd, max_tours, modele=None):
                ctrl = consigne.startswith(idn.APPEL_DE_CONTROLE_CONSIGNE)
                appels.append((modele, ctrl))
                r = simule.lancer(role, consigne, dossier, budget_usd, max_tours, modele)
                cout = 0.2 if ctrl else r.cout_declare_usd
                relais["appels"] += 1
                relais["depense_usd"] = round(relais["depense_usd"] + cout, 6)
                return Resultat(r.texte_final, [], cout, "ok")
        argon = v41.script(v41.SCRIPT_PLAFOND, "argon-relais.py")
        sortie = os.path.join(self.tmp, "l-relais")
        argv = v41.base(sortie, prep, att, "--commande-externe", argon, "--moteur", "claude-sdk", "--confirmer-moteur-reel",
                        "--url-relais", "http://127.0.0.1:9", "--racine-depot", self.tmp, "--budget-total-usd", "41")

        def panne(*a, **k):
            raise idn.CourseInterrompue("panne simulée du cœur avant son départ")
        coeur = idn.executer_ideation
        with unittest.mock.patch.object(pa, "AdaptateurClaudeSDK", FauxKit), \
                unittest.mock.patch.object(pa, "importer_sdk", lambda: types.SimpleNamespace(__version__="faux")), \
                unittest.mock.patch.object(pa, "etat_bac_a_sable_detaille",
                                           lambda *a, **k: {"actif": True, "proc_neuf": True, "motif": "faux"}), \
                unittest.mock.patch.object(lanceur, "version_outil_ligne_de_commande", lambda sdk: {"version": "faux"}), \
                unittest.mock.patch.object(lanceur, "lecteur_relais", lambda url: (lambda: dict(relais))):
            with unittest.mock.patch.object(idn, "executer_ideation", panne):
                code, _, err = v41.principal(lanceur, argv)
                self.assertEqual(code, 2, err)
                self.assertEqual(sum(1 for _, c in appels if c), 2)
                self.assertAlmostEqual(relais["depense_usd"], 0.4)
                appels.clear()
                code, _, err = v41.principal(lanceur, argv)  # relais gardé
                self.assertEqual(code, 2, err)
            self.assertEqual(appels, [])
            with open(os.path.join(sortie + "-controle", "tentative-2.json")) as f:
                r2 = json.load(f)["reglages"]
            self.assertEqual(sorted(r2["controles_repris"]), ["claude-fable-5-1", "claude-opus-5-5", "externe:argon"])
            relais.update(appels=0, depense_usd=0.0)  # relais relancé à la même adresse
            self.assertIs(idn.executer_ideation, coeur)
            code, _, err = v41.principal(lanceur, argv)
        self.assertIn(code, (0, 4), err)
        self.assertEqual(sorted(m for m, c in appels if c), ["claude-fable-5-1", "claude-opus-5-5"])  # rejoués
        self.assertIn("relais relancé", err)
        with open(os.path.join(sortie, "manifeste-depart.json")) as f:
            d = json.load(f)["reglages"]
        self.assertEqual(sorted(d["versions"]["controles_repris"]), ["externe:argon"])
        motifs = d["versions"]["motifs_reprise_controles"]
        self.assertEqual(sorted(motifs), ["claude-fable-5-1", "claude-opus-5-5"])
        self.assertTrue(all(m.startswith("rejoué : relais relancé") for m in motifs.values()))
        with open(os.path.join(sortie, "manifeste-fin.json")) as f:
            self.assertEqual(json.load(f)["reglages"]["journal"]["motifs_reprise_controles"], motifs)
        self.assertAlmostEqual(d["cout_deja_engage_usd"], 0.8)  # 0,4 de la tentative 1, 0,4 rejoués
        self.assertTrue(all("relais non relancé" in m for m in r2["motifs_reprise_controles"].values()))
        # unitaire : dépense non lue à la tentative, relais illisible
        rep = {"claude-opus-5-5": {"repris_de_tentative": 1, "relais_apres_depense_usd": None}}
        self.assertEqual(lanceur.filtrer_reprises_claude(rep, lambda: {"depense_usd": 5.0})[0], {})

        def illisible():
            raise OSError("relais muet")
        self.assertEqual(lanceur.filtrer_reprises_claude(
            {"claude-opus-5-5": {"repris_de_tentative": 1, "relais_apres_depense_usd": 0.2}}, illisible)[0], {})

    # --- X01 (CL43-07) ---------------------------------------------------------------------------------------------------

    def test_x01_fichier_d_entree_change_entre_deux_tentatives(self):
        """X01 (CL43-07) : tentative 1, contrôles réussis, panne du cœur ; la pièce change (liste blanche refaite) ; tentative
        2, même commande d'Argon : la consigne de contrôle d'Argon a changé (empreinte dans la clé de reprise) → **Argon
        rejoué** ; le contrôle Claude (consigne courte et fixe) est repris. Le code de la v43 était juste : cet essai passe
        sur la v43 et tue le défaut X01 (clé sans l'empreinte de la consigne)."""
        import unittest.mock
        v43 = self.v43()
        v41 = v43.v41()
        prep, att = v41.prep_devis()
        lanceur = v41.lanceur()
        journal = os.path.join(self.tmp, "argon-x01.jsonl")
        argon = v43.argon_journal(journal, "argon-x01.py")
        sortie = os.path.join(self.tmp, "l-x01")

        def panne(*a, **k):
            raise idn.CourseInterrompue("panne simulée du cœur avant son départ")
        with unittest.mock.patch.object(idn, "executer_ideation", panne):
            code, _, err = v41.principal(lanceur, v41.base(sortie, prep, att, "--commande-externe", argon))
        self.assertEqual(code, 2, err)
        self.assertEqual([a["controle"] for a in self.journal(journal)], [True])
        p2 = os.path.join(self.tmp, "piece-x01.md")
        with open(p2, "w", encoding="utf-8") as f:
            f.write("# Pièce A changée\nAutre texte de contexte.")
        lb2 = os.path.join(self.tmp, "liste-blanche-x01.json")
        idn.construire_liste_blanche([p2, prep["question"], prep["materiau"][0], prep["temoins"]], lb2)
        prep2 = dict(prep, liste_blanche=lb2, pieces=[p2])
        code, _, err = v41.principal(lanceur, v41.base(sortie, prep2, att, "--commande-externe", argon))
        self.assertIn(code, (0, 4), err)
        appels = self.journal(journal)
        self.assertEqual([a["controle"] for a in appels[:2]], [True, True])  # Argon rejoué avant ses passes
        with open(os.path.join(sortie, "manifeste-depart.json")) as f:
            v = json.load(f)["reglages"]["versions"]
        self.assertEqual(sorted(v["controles_repris"]), ["claude-fable-5-1", "claude-opus-5-5"])
        self.assertEqual(sorted(v["appel_de_controle"]), ["externe:argon"])
        with open(os.path.join(sortie + "-controle", "tentative-1.json")) as f:
            avant = json.load(f)["reglages"]["lectures"]["externe:argon"]["consigne_sha256"]
        self.assertNotEqual(v["appel_de_controle"]["externe:argon"]["consigne_sha256"], avant)

    # --- CL43-05 ---------------------------------------------------------------------------------------------------------

    def test_cl43_05_relance_bornee_par_les_sommes_et_par_trois_tentatives(self):
        """CL43-05 : trois tentatives scellées (contrôles réussis puis repris, rien payé) : la troisième dit « 3 tentatives
        faites (borne MAX_TENTATIVES_BRAS, en plus des sommes) » ; la quatrième est refusée avant tout appel et le message dit
        les deux bornes (v43 : « plus de relance sans un mot de Lazar » seul)."""
        import unittest.mock
        v41 = self.v43().v41()
        prep, att = v41.prep_devis()
        lanceur = v41.lanceur()
        argon = v41.script(v41.SCRIPT_PLAFOND, "argon-cl43-05.py")
        sortie = os.path.join(self.tmp, "l-cl43-05")

        def panne(*a, **k):
            raise idn.CourseInterrompue("panne simulée du cœur avant son départ")
        with unittest.mock.patch.object(idn, "executer_ideation", panne):
            for _ in range(3):
                code, _, err = v41.principal(lanceur, v41.base(sortie, prep, att, "--commande-externe", argon))
                self.assertEqual(code, 2, err)
            code, _, err = v41.principal(lanceur, v41.base(sortie, prep, att, "--commande-externe", argon))
        self.assertEqual(code, 2)
        with open(os.path.join(sortie + "-controle", "tentative-3.json")) as f:
            self.assertIn("3 tentatives faites (borne MAX_TENTATIVES_BRAS, en plus des sommes)",
                          " ".join(json.load(f)["reglages"]["motifs_relance"]))
        self.assertIn("bornée par les sommes ET par 3 tentatives (MAX_TENTATIVES_BRAS)", err)
        self.assertFalse(os.path.exists(os.path.join(sortie + "-controle", "tentative-4.json")))

    # --- ajout de Lazar : mesures de convergence ------------------------------------------------------------------------

    def test_mesures_de_convergence_au_manifeste_de_fin(self):
        """Ajout de Lazar (29 octobre, 10:09 heure de Paris) : deux passes simulées ; Opus modifie sa fiche (énoncé changé,
        une source nouvelle, la pièce citée) → distance d'édition = 1 − rapport de SequenceMatcher sur les mots, Jaccard des
        sources 1 − 1/3, deux sources en passe 1 et 2, une nouvelle, part des pièces citées 0 puis 1 ; Fable rend la même
        fiche → distances 0, aucune source nouvelle ; `pages_lues` nul, motif « course sans outils de lecture » ; rien
        dans les fiches servies aux juges ni dans le classement (v43 : aucune mesure)."""
        import difflib
        c = self.v43().cours()
        c._prep = self.v43().prep()
        f1 = fiche_brute(nom="Pente", anteriorite=[{"reference": "Ramtin arXiv:2601.20022 [p.3]", "statut": "RAPPORTE"}])
        f2 = fiche_brute(nom="Pente", enonce="La pente du transfert, mesurée sur piece-a, est-elle prédite avant le test ?",
                         anteriorite=[{"reference": "Ramtin arXiv:2601.20022v2", "statut": "RAPPORTE"},
                                      {"reference": "Autre arXiv:2501.00001", "statut": "SUPPOSE"}])
        stable = fiche_brute(nom="Stable")
        ad = FauxAdaptateur({"opus": lambda passe, consigne: [f1] if passe == "passe-1" else [f2],
                             "fable": lambda passe, consigne: [stable]},
                            notes_par_juge={"juge-fable": c.notes_temoins_ok, "juge-opus": c.notes_temoins_ok})
        res = c.lancer(ad, "c-conv", seconde_passe=True)
        with open(os.path.join(self.tmp, "c-conv", "manifeste-fin.json")) as f:
            m = json.load(f)["reglages"]["mesures_convergence"]
        self.assertEqual((m["pages_lues"], m["motif_pages_lues"]), (None, "course sans outils de lecture"))
        o = m["par_proposeur"]["opus"]["opus-p1-01"]
        v1 = next(x for x in res["fiches"] if x["identifiant_auteur"] == "opus-p1-01")
        v2 = next(x for x in res["fiches"] if x["identifiant_auteur"] == "opus-p2-01")
        attendu = round(1 - difflib.SequenceMatcher(None, idn.texte_fiche(v1).split(), idn.texte_fiche(v2).split()).ratio(), 6)
        self.assertEqual((o["identifiant_passe_2"], o["appariement"], o["distance_edition"]), ("opus-p2-01", "même nom", attendu))
        self.assertGreater(o["distance_edition"], 0)
        self.assertEqual((o["distance_jaccard_sources"], o["sources_passe_1"], o["sources_passe_2"], o["sources_nouvelles_passe_2"]),
                         (0.666667, 2, 2, 1))
        self.assertEqual((o["part_pieces_citees_passe_1"], o["part_pieces_citees_passe_2"]), (0.0, 1.0))
        self.assertEqual((o["pages_lues"], o["motif_pages_lues"]), (None, "course sans outils de lecture"))
        s = m["par_proposeur"]["fable"]["fable-p1-01"]
        self.assertEqual((s["distance_edition"], s["distance_jaccard_sources"], s["sources_nouvelles_passe_2"]), (0.0, 0.0, 0))
        for nom in ("classement.json", "fiches-validees.json", "lecture.json"):
            with open(os.path.join(self.tmp, "c-conv", nom), encoding="utf-8") as f:
                self.assertNotIn("distance_edition", f.read())
        for a in ad.appels:
            if a["role"] == "juge_ideation":
                self.assertNotIn("distance", a["consigne"])



class TestV45(CasAvecDossier):
    """v45 (bloquant de lancement démontré par session-depot sur la v44, message n° 175) : `anonymiser` normalisait la
    typographie sur le texte JSON, un guillemet « » ou “ ” y devenait un `"` non échappé (`JSONDecodeError`) après toutes
    les passes des proposeurs, avant le premier juge. v45 : normalisation valeur par valeur. Chaque essai échoue sur la v44."""

    GUILLEMETS = "Le « moniteur » dit “diffus” — l’écart… "

    def v43(self):
        t = TestV43("test_cl42_03_mesurer_consignes_sans_appel")
        t.tmp = self.tmp
        return t

    def temoins_guillemets(self):
        g = self.GUILLEMETS
        return {"temoins": [
            {"fiche": fiche_brute(nom="Sobre fort", enonce=g + "sobre ?"), "attendu": "eligible", "classe": "vrai"},
            {"fiche": fiche_brute(nom="Verbeux vide", enonce=g * 10), "attendu": "ineligible",
             "note_max": {"falsifiabilite": 1}, "classe": "faux_falsifiabilite"},
            {"fiche": fiche_brute(nom="Assuré occupé", originalite={"niveau": "inedite", "texte": "« jamais vu »"}),
             "attendu": "ineligible", "note_max": {"originalite": 1}, "classe": "faux_anteriorite"},
            {"fiche": fiche_brute(nom="Jumeau", piege="“" + g + "”"), "attendu": "eligible", "jumeau_de": "Sobre fort",
             "classe": "jumeau"}]}

    def prep_guillemets(self):
        v41 = self.v43().v41()
        prep = v41.cours().preparer(temoins_json=self.temoins_guillemets())
        att = os.path.join(self.tmp, "att-materiau-v45.json")
        idn.ecrire_json_scelle(att, {"lecteur": "Lazar", "lu_le": "2026-10-29", "materiau_sha256": {
            os.path.basename(prep["materiau"][0]): idn.sha256_fichier(prep["materiau"][0])}})
        return v41, prep, att

    def argon_guillemets(self, nom):
        """Le script commun d'Argon (`SCRIPT_OK`), dont les fiches portent des guillemets « » et “ ”."""
        fiche = json.dumps(fiche_brute(nom="Argon A", enonce=self.GUILLEMETS + "?", piege="« piège » “anglais”"),
                           ensure_ascii=False)
        script = TestCommandeExterne.SCRIPT_OK.replace(repr(TestCommandeExterne.FICHE), repr(fiche), 1)
        self.assertNotEqual(script, TestCommandeExterne.SCRIPT_OK)
        return self.v43().v41().script(script, nom)

    def test_v45_1_fiche_et_temoin_a_guillemets_servis_aux_juges(self):
        """Une fiche et un témoin à guillemets « » et “ ” : anonymisés sans erreur (v44 : `JSONDecodeError`), chaque valeur
        normalisée comme avant (`normaliser_typographie`), structure intacte (mêmes clés, mêmes listes) ; la consigne du
        juge se relit en JSON."""
        fiche = idn.valider_fiche_ideation(fiche_brute(nom="Fiche « A »", enonce=self.GUILLEMETS + "?",
                                                       anteriorite=[{"reference": "“Where” 2601.1", "statut": "RAPPORTE"}]),
                                           "opus", 1)
        p = os.path.join(self.tmp, "temoins-v45.json")
        with open(p, "w", encoding="utf-8") as f:
            json.dump(self.temoins_guillemets(), f, ensure_ascii=False)
        temoins = idn.charger_temoins(p, idn.construire_liste_blanche([p], os.path.join(self.tmp, "lb-v45.json")))
        toutes = [fiche] + temoins
        anonymes, cle = idn.anonymiser(toutes, 7, "juge-v45")
        self.assertEqual(len(anonymes), 5)
        par_auteur = {cle[a["identifiant"]]: a for a in anonymes}

        def attendu(o):
            if isinstance(o, str):
                return idn.normaliser_typographie(o)
            if isinstance(o, list):
                return [attendu(x) for x in o]
            if isinstance(o, dict):
                return {k: attendu(v) for k, v in o.items()}
            return o
        for f in toutes:
            a = dict(par_auteur[f["identifiant_auteur"]])
            ident = a.pop("identifiant")
            self.assertRegex(ident, r"^T0[1-5]$")
            self.assertEqual(a, attendu(idn.vue_servie(f)))
            self.assertEqual(sorted(a), sorted(idn.vue_servie(f)))
        a = par_auteur[fiche["identifiant_auteur"]]
        self.assertEqual(a["nom"], 'Fiche " A "')
        self.assertTrue(a["enonce"].startswith('Le " moniteur " dit "diffus" - l\'écart... '))
        self.assertEqual(a["anteriorite"], [{"reference": '"Where" 2601.1', "statut": "RAPPORTE"}])
        texte = json.dumps(anonymes, ensure_ascii=False)
        for c in "«»“”’—…":
            self.assertNotIn(c, texte)
        self.assertEqual(json.loads(texte), anonymes)

    def test_v45_2_mesurer_consignes_temoins_a_guillemets(self):
        """`--mesurer-consignes` avec des témoins à guillemets → code 0 (v44 : code 2, `JSONDecodeError`), aucun appel."""
        import unittest.mock
        from pole.adaptateurs import AdaptateurCommandeExterne
        v41, prep, att = self.prep_guillemets()
        argon = self.argon_guillemets("argon-v45-2.py")
        sortie = os.path.join(self.tmp, "l-v45-2")

        def piege(*a, **k):
            raise AssertionError("aucun appel ne doit partir")
        lanceur = v41.lanceur()
        with unittest.mock.patch.object(lanceur.AdaptateurIdeationSimule, "lancer", piege), \
                unittest.mock.patch.object(AdaptateurCommandeExterne, "lancer", piege):
            code, out, err = v41.principal(lanceur, v41.base(sortie, prep, att, "--commande-externe", argon,
                                                             "--mesurer-consignes"))
        self.assertEqual(code, 0, err)
        self.assertGreater(json.loads(out)["consignes"]["consigne_du_juge_maximale"], 0)
        self.assertFalse(os.path.exists(sortie) or os.path.exists(sortie + "-controle"))

    def test_v45_3_course_simulee_complete_a_guillemets(self):
        """Course simulée complète (passe 1, passe 2, Argon proposeur ; juges ; classement) avec témoins et fiches d'Argon à
        guillemets → code 0, classement écrit (v44 : code 2 après les passes, avant le premier juge, sans classement)."""
        v41, prep, att = self.prep_guillemets()
        argon = self.argon_guillemets("argon-v45-3.py")
        sortie = os.path.join(self.tmp, "l-v45-3")
        code, out, err = v41.principal(v41.lanceur(), v41.base(sortie, prep, att, "--commande-externe", argon))
        self.assertEqual(code, 0, err)
        with open(os.path.join(sortie, "manifeste-fin.json"), encoding="utf-8") as f:
            fin = json.load(f)["reglages"]
        self.assertIsNone(fin["erreur"])
        self.assertEqual(fin["lecture"]["juges_rendus"], 2)
        self.assertTrue(fin["lecture"]["temoins"]["temoins_ok"])
        with open(os.path.join(sortie, "fiches-validees.json"), encoding="utf-8") as f:
            self.assertIn("« piège » “anglais”", f.read())  # la fiche d'Argon à guillemets est bien passée aux juges
        with open(os.path.join(sortie, "notes-par-juge.json"), encoding="utf-8") as f:
            self.assertTrue(json.load(f))
        # bras rapporté différé (juge externe) : anonymisation chez le juge externe, puis classement écrit
        att_lecture = v41.cmd().attester(os.path.join(self.tmp, "att-v45-3.json"), sortie, "argon-j")
        code, out, err = v41.principal(v41.lanceur(), [sortie, "--bras-rapporte-differe", "--attestation-lecture-humaine",
                                                       att_lecture, "--juge-externe", "argon-j=gemini-argon",
                                                       "--commande-externe", argon])
        self.assertEqual(code, 0, err)
        with open(os.path.join(sortie, "classement.json"), encoding="utf-8") as f:
            lignes = json.load(f)["lignes"]
        self.assertTrue(lignes)
        self.assertTrue(all(l["nombre_juges"] == 3 for l in lignes))

# --- v46 : tour (c) « outils clôturés » (décisions de Lazar du 29 octobre 2026, R-433, R-434, R-441, R-444, R-448) et
# corrections de la contre-lecture CL12 de la v45 (CL45-01 : TestV45 et TestV46 avant `unittest.main()` ; CL45-02 :
# caviardage valeur par valeur après l'analyse JSON). En préparation hors ligne : moteur simulé, Argon factice qui émet des
# demandes, faux kit qui passe ses appels d'outils par le vrai crochet ; aucune session réelle, aucun réseau, aucune clé.
# Un essai par point : (1) dossier fermé ; (2) outils confinés du kit et épreuves R5 du crochet ; (3) outils par protocole ;
# (4) aucun nombre de tours, plafonds de sûreté, garde-fou (incident), avertissement de budget ; (5) mesures au manifeste
# de fin seulement ; (6) cache partagé ; (7) citations vérifiées (L7) ; (8) moisson refusée ; rétrocompatibilité.
import asyncio  # noqa: E402
import time  # noqa: E402

from pole import dossier_ferme as dfm  # noqa: E402
from pole.adaptateurs import AdaptateurCommandeExterne, reglages_kit_par_role  # noqa: E402
from pole.garde_outils import evaluer_appel, evaluer_appel_lecture, fabriquer_crochet_lecture  # noqa: E402
from pole.outils import extraire_bloc_json  # noqa: E402

PAGE_2 = "Le taux de détection atteint 0,73 sur les épisodes diffus."
TEXTE_A = ("# Extrait A\n[p.1] Introduction : moniteurs et menaces diffuses.\n"
           "[p.2] " + PAGE_2 + "\nUne seconde ligne de la page deux.\n"
           "[p.3] Conclusion : la borne tient à dix familles.\n")
TEXTE_B = "Extrait B, page une : grille de mesure bêta.\fExtrait B, page deux : le taux de rappel.\f"
CITATION_JUSTE = "« Le taux de détection atteint 0,73 » [extrait-a.md, p.2]"
CITATION_FAUSSE = "« un passage inventé de toutes pièces » [extrait-a.md, p.3]"
CITATION_ABSENTE = "[extrait-a.md, p.9]"


def fiche_citante(nom):
    return fiche_brute(nom=nom, anteriorite=[{"reference": CITATION_JUSTE + " ; " + CITATION_FAUSSE + " ; " + CITATION_ABSENTE,
                                              "statut": "RAPPORTE"}])


# Argon factice : à chaque tour, lit dans la consigne le nombre de tours déjà servis ; joue le scénario (demandes, version
# provisoire), puis rend ses fiches ; « toujours » : demande sans fin (garde-fou) ; coût = min(cout, part × plafond restant)
SCRIPT_ARGON = r'''
import sys, json, os, re, time
c = sys.stdin.read()
plafond = float(os.environ.get('PLAFOND_SESSION_USD', '1'))
role = os.environ.get('ROLE_POLE')
S = json.loads(%(scenario)r)
def sortir(t, cout):
    with open(%(journal)r, 'a') as j:
        j.write(json.dumps({'role': role, 'taille': len(c), 'plafond': plafond, 'tours_servis': c.count('"tour": '),
                            'avertissement': 'Il te reste' in c, 'passe2': 'première passe' in c}) + '\n')
    print(json.dumps({'texte': t, 'cout_usd': cout})); sys.exit(0)
if c.startswith('Réponds exactement OK'): sortir('OK', 0.001)
if role == 'juge_ideation':
    bloc = json.loads(re.search(r'```json\n(\[.*\])\n```', c, re.S).group(1)); par_nom = {f['nom']: f['identifiant'] for f in bloc}
    notes = []
    for f in bloc:
        k = {x: 2 for x in ('avantage', 'originalite', 'falsifiabilite', 'traitabilite', 'robustesse')}
        if f['nom'] in ('Verbeux vide', 'Assuré occupé'): k.update({'avantage': 1, 'originalite': 0, 'falsifiabilite': 0})
        notes.append({'identifiant': f['identifiant'], 'criteres': k, 'justifications': {}})
    sortir('```json\n' + json.dumps({'notes': notes, 'doublons': [[par_nom['Jumeau'], par_nom['Sobre fort']]]}) + '\n```', 0.01)
time.sleep(S.get('dormir', 0))
n = c.count('"tour": ')
cout = min(S.get('cout', 0.05), S.get('part', 0.5) * plafond)
fiche = S['fiche']
if 'première passe' in c: fiche = dict(fiche, nom=fiche['nom'] + ' revue')
if S.get('toujours') or n < len(S['tours']):
    t = {'demandes': [{'lire': 'extrait-a.md', 'pages': [1, 1]}]} if S.get('toujours') else S['tours'][n]
    texte = '```json\n' + json.dumps({'demandes': t['demandes']}, ensure_ascii=False) + '\n```'
    if t.get('version'):
        texte += '\n```json\n' + json.dumps({'fiches': [dict(fiche, nom=fiche['nom'] + ' brouillon')]}, ensure_ascii=False) + '\n```'
    sortir(texte, cout)
sortir('```json\n' + json.dumps({'fiches': [fiche]}, ensure_ascii=False) + '\n```', cout)
'''


class FauxProtocole:
    """Proposeur Claude par protocole (en processus) : même scénario que l'Argon factice ; juge : notes qui tiennent les
    témoins ; consigne chaque appel et ses arguments de lecture."""
    nom = "faux-protocole"

    def __init__(self, scenarios, juge, dormir=0.0):
        self.scenarios, self.juge, self.dormir = scenarios, juge, dormir
        self.appels = []

    def lancer(self, role, consigne, dossier, budget_usd, max_tours, modele=None, **lecture):
        self.appels.append({"role": role, "consigne": consigne, "dossier": dossier, "budget": budget_usd,
                            "max_tours": max_tours, "lecture": lecture})
        if consigne.startswith(idn.APPEL_DE_CONTROLE_CONSIGNE):
            return Resultat("OK", [], 0.01, "ok")
        if role == "juge_ideation":
            idents = sorted(set(re.findall(r'"identifiant": "(T\d\d)"', consigne)))
            return Resultat("```json\n" + json.dumps(self.juge(idents, consigne)) + "\n```", [], 0.1, "ok")
        time.sleep(self.dormir)
        etiquette = dossier.split(os.sep)[-3]
        s = self.scenarios[etiquette]
        n = consigne.count('"tour": ')
        if n < len(s["tours"]):
            return Resultat("```json\n" + json.dumps({"demandes": s["tours"][n]["demandes"]}, ensure_ascii=False) + "\n```",
                            [], s.get("cout", 0.05), "ok")
        return Resultat("```json\n" + json.dumps({"fiches": [s["fiche"]]}, ensure_ascii=False) + "\n```", [],
                        s.get("cout", 0.05), "ok")


class FauxKit:
    """Faux kit d'agent : pour un proposeur à outils, construit les vraies options (`construire_options`, racine de lecture,
    crochet de lecture seule) et passe chaque appel d'outil scripté par le vrai crochet ; un `Read` admis lit le fichier
    pour de bon. Juges : notes qui tiennent les témoins. Rend le journal du crochet comme l'adaptateur réel."""
    nom = "faux-kit"

    def __init__(self, sortie, appels_outils, juge, fiche, ecrire_dans_copie=False, depense=None):
        self.sortie, self.appels_outils, self.juge, self.fiche = sortie, appels_outils, juge, fiche
        self.ecrire_dans_copie, self.depense = ecrire_dans_copie, depense
        self.appels, self.lus, self.decisions = [], [], []

    def lancer(self, role, consigne, dossier, budget_usd, max_tours, modele=None, **lecture):
        self.appels.append({"role": role, "consigne": consigne, "dossier": dossier, "max_tours": max_tours, "lecture": lecture})
        if consigne.startswith(idn.APPEL_DE_CONTROLE_CONSIGNE):
            return Resultat("OK", [], 0.01, "ok")
        if role == "juge_ideation":
            idents = sorted(set(re.findall(r'"identifiant": "(T\d\d)"', consigne)))
            return Resultat("```json\n" + json.dumps(self.juge(idents, consigne)) + "\n```", [], 0.1, "ok")
        racine = lecture["racine_lecture"]
        o = construire_options(dossier, budget_usd, max_tours, url_relais="http://127.0.0.1:8787", modele=modele, role=role,
                               interdire_lecture=[self.sortie], racine_lecture=racine,
                               max_demandes_lecture=lecture["max_demandes_lecture"], lire_depense=self.depense)
        self.options = o
        crochet = o["crochets"]["PreToolUse"][0]["crochet"]
        for outil, entree in self.appels_outils(racine):
            sortie = asyncio.run(crochet({"tool_name": outil, "tool_input": entree}, "id", None))
            self.decisions.append((outil, entree, sortie))
            if not sortie and outil == "Read":
                with open(entree["file_path"], encoding="utf-8") as f:
                    self.lus.append(f.read())
        if self.ecrire_dans_copie:
            with open(os.path.join(racine, "extrait-a.md"), "a", encoding="utf-8") as f:
                f.write("altéré\n")
        texte = "```json\n" + json.dumps({"fiches": [self.fiche]}, ensure_ascii=False) + "\n```"
        return Resultat(texte, [], 0.2, "ok", journal_outils=list(crochet.journal), incident_outils=crochet.incident,
                        avertissement_outils=crochet.avertissement)


class TestV46(CasAvecDossier):
    """v46 : tour (c) « outils clôturés » en préparation, et corrections de CL12 (voir le commentaire qui précède)."""

    # --- préparation ---------------------------------------------------------------------------------------------------

    def cours(self):
        c = TestCourse("test_course_complete")
        c.tmp = self.tmp
        return c

    def v41(self):
        t = TestV41("test_tolerances_separees")
        t.tmp = self.tmp
        return t

    def ecrire_dossier(self, nom="dossier-ferme", index=True, pages_a=3):
        d = os.path.join(self.tmp, nom)
        os.makedirs(d)
        with open(os.path.join(d, "extrait-a.md"), "w", encoding="utf-8") as f:
            f.write(TEXTE_A)
        os.makedirs(os.path.join(d, "sous"))
        with open(os.path.join(d, "sous", "extrait-b.md"), "w", encoding="utf-8") as f:
            f.write(TEXTE_B)
        if index:
            dfm.ecrire_index(d, [{"chemin": "extrait-a.md", "titre": "Extrait A", "resume": "Résumé de l'extrait A",
                                  "sections": ["Introduction", "Résultats"], "pages": pages_a},
                                 {"chemin": "sous/extrait-b.md", "titre": "Extrait B", "resume": "Résumé B"}])
        return d

    def preparer(self, dossier=None):
        """Pièces des essais (TestCourse) et une liste blanche qui porte aussi l'index du dossier fermé."""
        if not hasattr(self, "_base"):
            self._base = self.cours().preparer()  # liste blanche des pièces écrite une fois (jamais écrasée)
        prep = dict(self._base)
        dossier = dossier or self.ecrire_dossier()
        lb = os.path.join(self.tmp, "lb-v46-" + os.path.basename(dossier) + ".json")
        idn.construire_liste_blanche([prep["question"], prep["pieces"][0], prep["materiau"][0], prep["temoins"],
                                      os.path.join(dossier, "index.json")], lb)
        return dict(prep, liste_blanche=lb), dossier

    def budgets(self, argon=True):
        b = dict(self.cours().budgets())
        if argon:
            b[("proposeur_ideation", "gemini-argon")] = 1.0
        return b

    def course(self, ad, nom, prep, dossier, argon=None, **modifs):
        args = dict(liste_blanche=prep["liste_blanche"], question=prep["question"], pieces=prep["pieces"],
                    temoins=prep["temoins"], proposeurs=[("opus", "claude-opus-5-5")], juges=[("juge-opus", "claude-opus-5-5")],
                    graine=7, budget_total_usd=20.0, budgets=self.budgets(), dossier_ferme=dossier)
        if argon is not None:
            args.update(proposeurs_externes=[("argon", "gemini-argon", argon)], budget_externe_usd=3.0)
        args.update(modifs)
        return idn.executer_ideation(ad, os.path.join(self.tmp, nom), **args)

    def argon(self, scenario, nom):
        journal = os.path.join(self.tmp, nom + ".journal")
        script = SCRIPT_ARGON % {"scenario": json.dumps(scenario, ensure_ascii=False), "journal": journal}
        cmd = TestCommandeExterne("test_commande_factice_notes_et_controle")
        cmd.tmp = self.tmp
        return AdaptateurCommandeExterne(cmd.commande(script, nom + ".py"), environnement={}), journal, cmd.commande(script, nom + ".py")

    @staticmethod
    def lignes(journal):
        with open(journal, encoding="utf-8") as f:
            return [json.loads(l) for l in f if l.strip()]

    @staticmethod
    def lire(chemin):
        with open(chemin, encoding="utf-8") as f:
            return f.read()

    def fin(self, nom):
        return json.loads(self.lire(os.path.join(self.tmp, nom, "manifeste-fin.json")))["reglages"]

    def consignes_des_juges(self, nom):
        base = os.path.join(self.tmp, nom)
        trouves = []
        for racine, _, fichiers in os.walk(base):
            for f in fichiers:
                if f in ("consigne.md", "consigne-en-attente.md") and "juges" in racine:
                    trouves.append(self.lire(os.path.join(racine, f)))
        return trouves

    # --- point 1 : dossier fermé ---------------------------------------------------------------------------------------

    def test_v46_1_dossier_ferme_index_scelle_empreintes_et_artefacts(self):
        """Cas sain : le dossier est chargé (pages par `[p.N]` et par saut de page), la consigne porte l'index (titre,
        résumé, taille, pages, sections) et **jamais le texte** ; `taille_max_pieces` ne s'applique pas au dossier (pièces
        de 30 caractères au plus, dossier plus grand : accepté). Artefacts (R5), tous refusés **avant tout appel** (aucun
        appel, SORTIE jamais créée) : fichier en plus, fichier absent, empreinte changée, index non scellé, index hors de la
        liste blanche, lien symbolique, chemin remontant dans l'index, fichier non texte (octets d'un PDF), secret, nombre
        de pages faux, fragment interdit."""
        prep, dossier = self.preparer()
        d = dfm.charger_dossier_ferme(dossier, idn.charger_liste_blanche(prep["liste_blanche"]))
        self.assertEqual(sorted(d.fichiers["extrait-a.md"]["pages"]), [1, 2, 3])
        self.assertIn(PAGE_2, d.page("extrait-a.md", 2))
        self.assertEqual(sorted(d.fichiers["sous/extrait-b.md"]["pages"]), [1, 2])
        self.assertEqual(d.pages_total, 5)
        index = json.dumps(d.vue_index(), ensure_ascii=False)
        for attendu in ("Extrait A", "Résumé de l'extrait A", "taille_caracteres", "Résultats"):
            self.assertIn(attendu, index)
        ad = FauxKit(os.path.join(self.tmp, "c1"), lambda r: [], self.cours().notes_temoins_ok, fiche_brute(nom="O1"))
        res = self.course(ad, "c1", prep, dossier, taille_max_pieces=30)
        consigne = ad.appels[0]["consigne"]
        self.assertIn("Le dossier fermé (index seulement", consigne)
        self.assertIn("Résumé de l'extrait A", consigne)
        self.assertNotIn(PAGE_2, consigne)
        self.assertNotIn("grille de mesure bêta", consigne)
        self.assertEqual(len(res["fiches"]), 1)
        depart = json.loads(self.lire(os.path.join(self.tmp, "c1", "manifeste-depart.json")))["reglages"]
        self.assertEqual(depart["dossier_ferme"]["index_sha256"], d.index_sha256)
        self.assertEqual(depart["dossier_ferme"]["mode_claude"], "outils")

        def refuse(nom, modifier, motif):
            p2, d2 = self.preparer(self.ecrire_dossier(nom))
            modifier(d2, p2)
            faux = FauxKit(os.path.join(self.tmp, "s-" + nom), lambda r: [], self.cours().notes_temoins_ok, fiche_brute())
            with self.assertRaises(idn.CourseInterrompue, msg=nom) as ctx:
                self.course(faux, "s-" + nom, p2, d2)
            self.assertIn(motif, str(ctx.exception), nom)
            self.assertEqual(faux.appels, [], nom)
            self.assertFalse(os.path.exists(os.path.join(self.tmp, "s-" + nom)), nom)

        def ajouter(d2, _):
            with open(os.path.join(d2, "intrus.md"), "w") as f:
                f.write("x")

        def retirer(d2, _):
            os.remove(os.path.join(d2, "sous", "extrait-b.md"))

        def changer(d2, _):
            with open(os.path.join(d2, "extrait-a.md"), "a") as f:
                f.write("changé")

        def desceller(d2, _):
            with open(os.path.join(d2, "index.json.sha256"), "w") as f:
                f.write("0" * 64 + "  index.json\n")

        def lien(d2, _):
            os.symlink("/etc/hostname", os.path.join(d2, "lien.md"))

        def reindexer(d2, p2, entrees):
            os.remove(os.path.join(d2, "index.json"))
            os.remove(os.path.join(d2, "index.json.sha256"))
            dfm.ecrire_index(d2, entrees)
            idn.construire_liste_blanche([p2["question"], p2["pieces"][0], p2["temoins"], os.path.join(d2, "index.json")],
                                         p2["liste_blanche"] + ".2.json")
            p2["liste_blanche"] = p2["liste_blanche"] + ".2.json"

        def pdf(d2, p2):
            with open(os.path.join(d2, "extrait-a.md"), "wb") as f:
                f.write(b"%PDF-1.7\n\xff\xfe\x00\x81binaire")
            reindexer(d2, p2, [{"chemin": "extrait-a.md", "titre": "A", "resume": "r"},
                               {"chemin": "sous/extrait-b.md", "titre": "B", "resume": "r"}])

        def secret(d2, p2):
            with open(os.path.join(d2, "extrait-a.md"), "w") as f:
                f.write("clé : " + "sk-" + "ant-" + "abcdefghijklmnopqrstu\n")
            reindexer(d2, p2, [{"chemin": "extrait-a.md", "titre": "A", "resume": "r"},
                               {"chemin": "sous/extrait-b.md", "titre": "B", "resume": "r"}])

        def remontant(d2, p2):
            reindexer(d2, p2, [{"chemin": "extrait-a.md", "titre": "A", "resume": "r"},
                               {"chemin": "sous/../sous/extrait-b.md", "titre": "B", "resume": "r"}])

        def interdit(d2, p2):
            os.rename(os.path.join(d2, "extrait-a.md"), os.path.join(d2, "donnees-a.md"))
            reindexer(d2, p2, [{"chemin": "donnees-a.md", "titre": "A", "resume": "r"},
                               {"chemin": "sous/extrait-b.md", "titre": "B", "resume": "r"}])

        def hors_liste(d2, p2):
            idn.construire_liste_blanche([p2["question"], p2["pieces"][0], p2["temoins"]], p2["liste_blanche"] + ".3.json")
            p2["liste_blanche"] = p2["liste_blanche"] + ".3.json"

        refuse("plus", ajouter, "non listés")
        refuse("moins", retirer, "absents")
        refuse("change", changer, "empreinte différente de l'index")
        refuse("descelle", desceller, "non scellé")
        refuse("lien", lien, "lien symbolique")
        refuse("pdf", pdf, "pas un texte UTF-8")
        refuse("secret", secret, "secret")
        refuse("remonte", remontant, "chemin relatif propre")
        refuse("interdit", interdit, "'donnees'")
        refuse("horsliste", hors_liste, "hors de la liste blanche")
        p3, d3 = self.preparer(self.ecrire_dossier("pages", pages_a=4))
        with self.assertRaisesRegex(idn.CourseInterrompue, "déclare 4 pages, 3 trouvées"):
            self.course(FauxKit(self.tmp, lambda r: [], None, fiche_brute()), "s-pages", p3, d3)

    # --- point 2 : outils confinés du kit, épreuves R5 ---------------------------------------------------------------

    def test_v46_2_outils_confines_du_kit_et_epreuves_r5_du_crochet(self):
        """Options : proposeur à dossier fermé → `tools` = `allowed_tools` = Read, Grep, Glob, dossier courant = la racine
        de lecture, crochet de lecture seule ; juge → toujours aucun outil (racine refusée) ; sans dossier : `tools=[]`
        comme en v45 ; ligne de commande du kit (jamais exécutée) : `--tools Read,Grep,Glob`, juge `--tools ''`.
        Crochet, cas sain : lecture d'un fichier du dossier et recherche d'un motif (Grep, Glob) admises. Artefacts, tous
        refusés avec motif : `Read /etc/passwd`, `Glob {"pattern": "/etc/*"}`, `Grep {"glob": "/root/**"}`, `Read` d'un
        lien symbolique vers l'extérieur, chemins à `..`, `~`, accolades, `path` hors racine, paramètre inconnu, `Write`,
        `Edit`, `MultiEdit`, `Bash`, `WebFetch`, `Task`, `mcp__…`. La garde générale (`evaluer_appel`, autres rôles)
        refuse aussi `Glob /etc/*` et `Grep glob /root/**` (v45 : admis). Garde-fou du crochet (incident) et avertissement
        de budget (« il te reste … : rends ta fiche »). Course : copie du dossier vérifiée par empreinte, appels consignés,
        juges sans argument de lecture ; copie altérée → incident dit, jamais silencieux."""
        dossier_agent = self.sous_dossier("course", "proposeurs", "opus", "passe-1")
        d = dfm.charger_dossier_ferme(self.ecrire_dossier())
        racine = os.path.join(dossier_agent, "lecture")
        d.copier_vers(racine)
        dehors = os.path.join(self.tmp, "secret-dehors.txt")
        with open(dehors, "w") as f:
            f.write("secret")
        os.symlink(dehors, os.path.join(racine, "lien-dehors.md"))
        interdits = [os.path.join(self.tmp, "course")]
        o = construire_options(dossier_agent, 1.0, 50, url_relais="http://127.0.0.1:8787", modele="claude-opus-5-5",
                               role="proposeur_ideation", interdire_lecture=interdits, racine_lecture=racine)
        self.assertEqual((o["tools"], o["allowed_tools"], o["cwd"]), (["Read", "Grep", "Glob"], ["Read", "Grep", "Glob"], racine))
        self.assertIn("Read, Grep et Glob", o["system_prompt"])
        juge = os.path.join(self.tmp, "course", "juges", "j")
        os.makedirs(juge)
        with self.assertRaises(ValueError):
            construire_options(juge, 1.0, 2, url_relais="http://127.0.0.1:8787", role="juge_ideation",
                               interdire_lecture=interdits, racine_lecture=racine)
        o_sans = construire_options(dossier_agent, 1.0, 2, url_relais="http://127.0.0.1:8787", role="proposeur_ideation",
                                    interdire_lecture=interdits)
        self.assertEqual((o_sans["tools"], o_sans["cwd"]), ([], dossier_agent))
        o_proto = construire_options(dossier_agent, 1.0, 2, url_relais="http://127.0.0.1:8787", role="proposeur_ideation",
                                     interdire_lecture=interdits, mode_lecture="protocole")
        self.assertEqual(o_proto["tools"], [])
        self.assertIn("bloc JSON {demandes}", o_proto["system_prompt"])
        self.assertEqual(reglages_kit_par_role("outils")["proposeur_ideation"]["tools"], ["Read", "Grep", "Glob"])
        self.assertEqual(reglages_kit_par_role("outils")["juge_ideation"]["tools"], [])
        self.assertEqual(reglages_kit_par_role("protocole")["proposeur_ideation"]["tools"], [])
        self.assertEqual(reglages_kit_par_role()["proposeur_ideation"]["tools"], [])
        try:
            import claude_agent_sdk as sdk
            from claude_agent_sdk._internal.transport.subprocess_cli import SubprocessCLITransport
        except ImportError:
            sdk = None
        if sdk is not None:
            from pole.adaptateurs import AdaptateurClaudeSDK
            for opts, attendu in ((o, "Read,Grep,Glob"), (construire_options(juge, 1.0, 2, url_relais="http://127.0.0.1:8787",
                                                                               role="juge_ideation", interdire_lecture=interdits), "")):
                options = AdaptateurClaudeSDK.options_sdk(sdk, opts)
                options.cli_path = "/bin/true"
                cmd = SubprocessCLITransport("x", options)._build_command()
                self.assertEqual(cmd[cmd.index("--tools") + 1], attendu)
            for nom in [n for n in sys.modules if n.startswith("claude_agent_sdk")]:
                del sys.modules[nom]
        # crochet : cas sain
        fichier = os.path.join(racine, "extrait-a.md")
        sains = [("Read", {"file_path": fichier}), ("Read", {"file_path": "sous/extrait-b.md", "offset": 1, "limit": 5}),
                 ("Grep", {"pattern": "taux", "path": racine}), ("Grep", {"pattern": "taux", "glob": "*.md", "-i": True}),
                 ("Glob", {"pattern": "**/*.md"}), ("Glob", {"pattern": racine + "/sous/*.md"})]
        for outil, entree in sains:
            self.assertEqual(evaluer_appel_lecture(outil, entree, racine)[0], True, (outil, entree))
        artefacts = [("Read", {"file_path": "/etc/passwd"}), ("Glob", {"pattern": "/etc/*"}),
                     ("Grep", {"pattern": "cle", "glob": "/root/**"}), ("Read", {"file_path": os.path.join(racine, "lien-dehors.md")}),
                     ("Read", {"file_path": os.path.join(racine, "..", "..", "traces-passe-1", "consigne.md")}),
                     ("Read", {"file_path": os.path.join(racine, "sous", "..", "extrait-a.md")}),
                     ("Read", {"file_path": "~/.bashrc"}), ("Glob", {"pattern": "../*"}), ("Glob", {"pattern": "~/*"}),
                     ("Glob", {"pattern": "{x,/etc}/*"}), ("Glob", {"pattern": "*", "path": "/etc"}),
                     ("Grep", {"pattern": "x", "path": "/root"}), ("Grep", {"pattern": "x", "glob": "../**"}),
                     ("Read", {"file_path": fichier, "inconnu": 1}), ("Read", {}),
                     ("Write", {"file_path": fichier, "content": "x"}), ("Edit", {"file_path": fichier}),
                     ("MultiEdit", {"file_path": fichier}), ("Bash", {"command": "cat extrait-a.md"}),
                     ("WebFetch", {"url": "https://exemple.org"}), ("Task", {}), ("Agent", {}), ("mcp__serveur__outil", {})]
        for outil, entree in artefacts:
            autorise, motif = evaluer_appel_lecture(outil, entree, racine)
            self.assertFalse(autorise, (outil, entree, motif))
            self.assertTrue(motif)
        # garde générale des autres rôles : les deux trous de la note de conception fermés
        self.assertFalse(evaluer_appel("Glob", {"pattern": "/etc/*"}, dossier_agent)[0])
        self.assertFalse(evaluer_appel("Grep", {"pattern": "cle", "glob": "/root/**"}, dossier_agent)[0])
        self.assertTrue(evaluer_appel("Glob", {"pattern": "**/*.py"}, dossier_agent)[0])
        # crochet : garde-fou anti-boucle et avertissement de budget
        crochet = fabriquer_crochet_lecture(racine, max_demandes=2)
        sorties = [asyncio.run(crochet({"tool_name": "Read", "tool_input": {"file_path": fichier}}, "i", None)) for _ in range(3)]
        self.assertEqual(sorties[:2], [{}, {}])
        self.assertEqual(sorties[2]["hookSpecificOutput"]["permissionDecision"], "deny")
        self.assertIn("garde-fou anti-boucle", sorties[2]["hookSpecificOutput"]["permissionDecisionReason"])
        self.assertEqual(crochet.incident["type"], "garde-fou anti-boucle")
        crochet = fabriquer_crochet_lecture(racine, lire_depense=lambda: 0.85, plafond_usd=1.0)
        s = asyncio.run(crochet({"tool_name": "Read", "tool_input": {"file_path": fichier}}, "i", None))
        self.assertIn("il te reste 0.15 USD : rends ta fiche", s["hookSpecificOutput"]["permissionDecisionReason"])
        self.assertEqual(asyncio.run(crochet({"tool_name": "Read", "tool_input": {"file_path": fichier}}, "i", None)), {})
        self.assertAlmostEqual(crochet.avertissement["reste_usd"], 0.15)
        # course à outils du kit (faux kit, vrai crochet)
        prep, dossier = self.preparer(self.ecrire_dossier("dossier-c2"))

        def appels(r):
            return [("Read", {"file_path": os.path.join(r, "extrait-a.md")}), ("Grep", {"pattern": "taux", "path": r}),
                    ("Read", {"file_path": "/etc/passwd"}), ("Glob", {"pattern": "/etc/*"}),
                    ("Grep", {"pattern": "x", "glob": "/root/**"}), ("Write", {"file_path": os.path.join(r, "x.md")}),
                    ("Bash", {"command": "ls"})]
        sortie = os.path.join(self.tmp, "c2")
        kit = FauxKit(sortie, appels, self.cours().notes_temoins_ok, fiche_citante("O1"))
        res = self.course(kit, "c2", prep, dossier)
        self.assertEqual(len(res["fiches"]), 1)
        self.assertEqual(kit.lus, [TEXTE_A])  # une seule lecture admise, celle du dossier
        refus = [(o_, e_) for o_, e_, s_ in kit.decisions if s_]
        self.assertEqual([o_ for o_, _ in refus], ["Read", "Glob", "Grep", "Write", "Bash"])
        prop = [a for a in kit.appels if a["role"] == "proposeur_ideation"][0]
        self.assertEqual(prop["lecture"]["racine_lecture"], os.path.join(sortie, "proposeurs", "opus", "passe-1", "lecture"))
        self.assertEqual(prop["max_tours"], dfm.MAX_DEMANDES_LECTURE_DEFAUT + 5)
        self.assertTrue(all(a["lecture"] == {} for a in kit.appels if a["role"] == "juge_ideation"))
        fin = self.fin("c2")
        copie = fin["journal"]["copies_dossier_ferme"][0]
        self.assertEqual(copie["empreintes"]["extrait-a.md"], dfm.charger_dossier_ferme(dossier).fichiers["extrait-a.md"]["sha256"])
        m = fin["mesures_lecture"]["par_proposeur"]["opus"]["passe-1"]
        self.assertEqual(m["mode"], "outils")
        self.assertEqual((m["demandes"]["total"], m["demandes"]["refusees"], m["demandes"]["lire"]), (7, 5, 2))
        self.assertEqual(sorted({p["page"] for p in m["pages_lues"]}), [1, 2, 3])
        self.assertEqual(fin["journal"]["incidents"], [])
        depart = json.loads(self.lire(os.path.join(sortie, "manifeste-depart.json")))["reglages"]
        self.assertEqual(depart["reglages_kit"]["proposeur_ideation"]["tools"], ["Read", "Grep", "Glob"])
        self.assertEqual(depart["reglages_kit"]["juge_ideation"]["tools"], [])
        # copie altérée pendant la session : incident dit (R5), la course continue, fiches lues avec réserve
        kit2 = FauxKit(os.path.join(self.tmp, "c2b"), lambda r: [], self.cours().notes_temoins_ok, fiche_brute(nom="O1"),
                       ecrire_dans_copie=True)
        self.course(kit2, "c2b", prep, dossier)
        inc = self.fin("c2b")["journal"]["incidents"]
        self.assertEqual(inc[0]["type"], "copie du dossier fermé altérée")
        self.assertEqual(inc[0]["ecarts"], [{"chemin": "extrait-a.md", "ecart": "empreinte différente"}])
        # garde-fou franchi dans le kit : incident, session et course arrêtées
        kit3 = FauxKit(os.path.join(self.tmp, "c2c"), lambda r: [("Read", {"file_path": os.path.join(r, "extrait-a.md")})] * 4,
                       self.cours().notes_temoins_ok, fiche_brute(nom="O1"))
        with self.assertRaisesRegex(idn.CourseInterrompue, "garde-fou anti-boucle"):
            self.course(kit3, "c2c", prep, dossier, max_demandes_lecture=3)
        fin3 = self.fin("c2c")
        self.assertEqual(fin3["journal"]["incidents"][0]["type"], "garde-fou anti-boucle")
        self.assertIn("garde-fou anti-boucle", fin3["erreur"])

    # --- point 3 : outils par protocole -------------------------------------------------------------------------------

    def test_v46_3_outils_par_protocole_argon_et_claude_a_egalite(self):
        """Argon (commande factice) demande une page et une recherche au tour 1 ; le noyau les sert au tour 2 depuis le
        dossier fermé — le texte de la page demandée seulement, et les lignes trouvées avec chemin et page —, rien
        d'autre ; demandes hors du dossier (`/etc/passwd`, `../`, plage vide) refusées avec motif. Claude sous
        `outils_par_protocole` : même mécanisme, **aucun outil du kit** (aucune racine de lecture, `mode_lecture` «
        protocole »). Par le lanceur (moteur simulé, `--dossier-ferme`, seconde passe, puis bras) : code 0, classement à
        trois juges."""
        prep, dossier = self.preparer()
        scenario = {"tours": [{"demandes": [{"lire": "extrait-a.md", "pages": [2, 2]}, {"chercher": "taux"},
                                            {"lire": "/etc/passwd"}, {"lire": "../extrait-a.md"},
                                            {"lire": "extrait-a.md", "pages": [7, 9]}]}],
                    "fiche": fiche_citante("Argon A")}
        argon, journal, _ = self.argon(scenario, "argon-3")
        faux = FauxProtocole({"opus": {"tours": [{"demandes": [{"lire": "sous/extrait-b.md"}]}], "fiche": fiche_brute(nom="O1")}},
                             self.cours().notes_temoins_ok)
        res = self.course(faux, "c3", prep, dossier, argon=argon, outils_par_protocole=True)
        self.assertEqual({f["auteur"] for f in res["fiches"]}, {"argon", "opus"})
        tours = self.lignes(journal)
        self.assertEqual([t["tours_servis"] for t in tours if t["role"] == "proposeur_ideation"], [0, 1])
        c2 = self.lire(os.path.join(self.tmp, "c3", "proposeurs", "argon", "passe-1", "traces-tour-002", "consigne.md"))
        self.assertIn(PAGE_2, c2)
        self.assertNotIn("Introduction : moniteurs", c2)  # page 1 jamais demandée, jamais servie
        self.assertNotIn("grille de mesure bêta", c2)  # l'autre fichier non plus
        self.assertIn('"ligne": "Extrait B, page deux : le taux de rappel."', c2)
        self.assertIn('"chemin": "sous/extrait-b.md"', c2)
        servi = json.loads(re.search(r"Ce que le noyau t'a servi[^\n]*\n+```json\n(.*?)\n```", c2, re.S).group(1))
        statuts = [r["statut"] for r in servi[0]["reponses"]]
        self.assertEqual(statuts, ["servie", "servie", "refusée", "refusée", "refusée"])
        self.assertIn("hors du dossier fermé", servi[0]["reponses"][2]["motif"])
        self.assertEqual({(r["chemin"], r["page"]) for r in servi[0]["reponses"][1]["resultats"]},
                         {("extrait-a.md", 2), ("sous/extrait-b.md", 2)})
        claude = [a for a in faux.appels if a["role"] == "proposeur_ideation"]
        self.assertEqual(len(claude), 2)
        self.assertTrue(all(a["lecture"] == {"mode_lecture": "protocole"} for a in claude))
        self.assertIn("grille de mesure bêta", claude[1]["consigne"])
        depart = json.loads(self.lire(os.path.join(self.tmp, "c3", "manifeste-depart.json")))["reglages"]
        self.assertEqual(depart["reglages_kit"]["proposeur_ideation"]["tools"], [])
        self.assertEqual((depart["dossier_ferme"]["mode_claude"], depart["dossier_ferme"]["mode_externes"]),
                         ("protocole", "protocole"))
        # par le lanceur, moteur simulé : course à dossier fermé, seconde passe, puis bras différé
        v41 = self.v41()
        att = os.path.join(self.tmp, "att-mat-3.json")
        idn.ecrire_json_scelle(att, {"lecteur": "Lazar", "lu_le": "2026-10-29", "materiau_sha256": {
            os.path.basename(prep["materiau"][0]): idn.sha256_fichier(prep["materiau"][0])}})
        idn.construire_liste_blanche([prep["question"], prep["pieces"][0], prep["materiau"][0], prep["temoins"],
                                      os.path.join(dossier, "index.json")], os.path.join(self.tmp, "lb-l3.json"))
        prep_l = dict(prep, liste_blanche=os.path.join(self.tmp, "lb-l3.json"))
        _, _, cmd = self.argon(scenario, "argon-3l")
        sortie = os.path.join(self.tmp, "l3")
        code, out, err = v41.principal(v41.lanceur(), v41.base(sortie, prep_l, att, "--commande-externe", " ".join(cmd),
                                                               "--dossier-ferme", dossier))
        self.assertEqual(code, 0, err)
        self.assertTrue(os.path.isdir(os.path.join(sortie, "proposeurs", "argon", "passe-2", "tour-002")))
        att_l = v41.cmd().attester(os.path.join(self.tmp, "att-l3.json"), sortie, "argon-j")
        code, out, err = v41.principal(v41.lanceur(), [sortie, "--bras-rapporte-differe", "--attestation-lecture-humaine",
                                                       att_l, "--juge-externe", "argon-j=gemini-argon", "--commande-externe",
                                                       " ".join(cmd)])
        self.assertEqual(code, 0, err)
        lignes = json.loads(self.lire(os.path.join(sortie, "classement.json")))["lignes"]
        self.assertTrue(lignes and all(l["nombre_juges"] == 3 for l in lignes))
        with open(os.path.join(sortie, "juges-bras-rapporte", "traces-argon-j", "consigne-en-attente.md"), encoding="utf-8") as f:
            self.assertIn("citations_verifiees", f.read())

    # --- point 4 : aucun nombre de tours ; plafonds de sûreté --------------------------------------------------------

    def test_v46_4_tours_libres_garde_fou_incident_avertissement_et_delai(self):
        """Aucun nombre de tours fixé : Argon lit sept tours (plus que `MAX_TOURS_IDEATION`) puis rend sa fiche, acceptée.
        Garde-fou : `max_demandes_lecture` = 3 et un Argon qui demande sans fin → arrêt au quatrième tour, **incident** au
        journal et aux mesures (pas un réglage), manifeste de fin en erreur. Avertissement de budget : Argon à 0,45 par
        tour sur un plafond de 1,0 → le troisième tour porte « Il te reste 0.10 USD : rends ta fiche. », la fiche rendue
        est **marquée** sous avertissement, jamais rejetée. Délai de session (`delai_session_s`) sur l'ensemble des tours :
        dépassé → arrêt. Options du lanceur : `--max-demandes-lecture` < 1 ou sans `--dossier-ferme` refusé."""
        prep, dossier = self.preparer()
        juge = self.cours().notes_temoins_ok
        sept = {"tours": [{"demandes": [{"lire": "extrait-a.md", "pages": [1 + k % 3, 1 + k % 3]}]} for k in range(7)],
                "fiche": fiche_brute(nom="Argon A"), "cout": 0.01}
        argon, journal, _ = self.argon(sept, "argon-4a")
        res = self.course(FauxProtocole({"opus": {"tours": [], "fiche": fiche_brute(nom="O1")}}, juge), "c4a", prep, dossier,
                          argon=argon, outils_par_protocole=True)
        self.assertTrue(any(f["auteur"] == "argon" for f in res["fiches"]))
        m = self.fin("c4a")["mesures_lecture"]["par_proposeur"]["argon"]["passe-1"]
        self.assertEqual((m["tours"], m["demandes"]["total"]), (8, 7))
        self.assertGreater(m["tours"], idn.MAX_TOURS_IDEATION)
        # garde-fou anti-boucle
        argon, journal, _ = self.argon({"tours": [], "toujours": True, "fiche": fiche_brute(nom="Argon A"), "cout": 0.01},
                                       "argon-4b")
        with self.assertRaisesRegex(idn.CourseInterrompue, "garde-fou anti-boucle"):
            self.course(FauxProtocole({"opus": {"tours": [], "fiche": fiche_brute(nom="O1")}}, juge), "c4b", prep, dossier,
                        argon=argon, outils_par_protocole=True, max_demandes_lecture=3)
        fin = self.fin("c4b")
        self.assertEqual(len(self.lignes(journal)), 4)  # quatre tours envoyés ; le quatrième n'est pas servi
        incident = fin["journal"]["incidents"][0]
        self.assertEqual((incident["type"], incident["tour"], incident["consigne"]),
                         ("garde-fou anti-boucle", 4, "incident (garde-fou), pas un réglage"))
        self.assertEqual(fin["mesures_lecture"]["incidents"][0]["type"], "garde-fou anti-boucle")
        self.assertIn("garde-fou anti-boucle", fin["erreur"])
        self.assertEqual(fin["mesures_lecture"]["par_proposeur"]["argon"]["passe-1"]["demandes"]["total"], 3)
        # avertissement de budget
        argon, journal, _ = self.argon({"tours": [{"demandes": [{"lire": "extrait-a.md", "pages": [1, 1]}]},
                                                  {"demandes": [{"lire": "extrait-a.md", "pages": [2, 2]}]}],
                                        "fiche": fiche_brute(nom="Argon A"), "cout": 0.45, "part": 1.0}, "argon-4c")
        res = self.course(FauxProtocole({"opus": {"tours": [], "fiche": fiche_brute(nom="O1")}}, juge), "c4c", prep, dossier,
                          argon=argon, outils_par_protocole=True)
        prop = [t for t in self.lignes(journal) if t["role"] == "proposeur_ideation"]
        self.assertEqual([t["avertissement"] for t in prop], [False, False, True])
        self.assertEqual([round(t["plafond"], 6) for t in prop], [1.0, 0.55, 0.1])
        c3 = self.lire(os.path.join(self.tmp, "c4c", "proposeurs", "argon", "passe-1", "traces-tour-003", "consigne.md"))
        self.assertIn("Il te reste 0.10 USD : rends ta fiche.", c3)
        m = self.fin("c4c")["mesures_lecture"]["par_proposeur"]["argon"]["passe-1"]
        self.assertTrue(m["sous_avertissement"])
        self.assertTrue(any(f["auteur"] == "argon" for f in res["fiches"]))  # jamais rejetée
        self.assertAlmostEqual(res["journal"]["cout_externe_usd"], 1.0)
        # délai de session sur l'ensemble des tours
        lent = FauxProtocole({"opus": {"tours": [{"demandes": [{"chercher": "taux"}]}] * 5, "fiche": fiche_brute(nom="O1")}},
                             juge, dormir=0.15)
        with self.assertRaisesRegex(idn.CourseInterrompue, "délai de session dépassé"):
            self.course(lent, "c4d", prep, dossier, outils_par_protocole=True, delai_session_s=0.2)
        self.assertLess(len([a for a in lent.appels if a["role"] == "proposeur_ideation"]), 5)
        # options du lanceur
        v41 = self.v41()
        for argv in (["s", "--max-demandes-lecture", "5"], ["s", "--dossier-ferme", dossier, "--max-demandes-lecture", "0"]):
            with self.assertRaises(SystemExit):
                v41.principal(v41.lanceur(), argv)

    # --- point 5 : mesures au manifeste de fin seulement --------------------------------------------------------------

    def test_v46_5_mesures_de_lecture_au_manifeste_de_fin_jamais_aux_juges(self):
        """Par proposeur et par passe : pages lues dans l'ordre (chemin, page, tour), répétitions, nombre de demandes par
        type, versions de la fiche (une version provisoire rendue avec des demandes, puis la finale : deux versions,
        distance > 0), part du dossier lu ; au manifeste de fin seulement : ni les consignes des juges, ni les fiches
        servies, ni le classement ne les portent (N-053) ; `mesures_convergence` renvoie aux mesures de lecture."""
        prep, dossier = self.preparer()
        scenario = {"tours": [{"demandes": [{"lire": "extrait-a.md", "pages": [2, 3]}], "version": True},
                              {"demandes": [{"lire": "extrait-a.md", "pages": [2, 2]}, {"chercher": "borne"}]}],
                    "fiche": fiche_brute(nom="Argon A"), "cout": 0.01}
        argon, _, _ = self.argon(scenario, "argon-5")
        res = self.course(FauxProtocole({"opus": {"tours": [], "fiche": fiche_brute(nom="O1")}}, self.cours().notes_temoins_ok),
                          "c5", prep, dossier, argon=argon, outils_par_protocole=True)
        fin = self.fin("c5")
        m = fin["mesures_lecture"]["par_proposeur"]["argon"]["passe-1"]
        self.assertEqual([(p["ordre"], p["tour"], p["chemin"], p["page"]) for p in m["pages_lues"]],
                         [(1, 1, "extrait-a.md", 2), (2, 1, "extrait-a.md", 3), (3, 2, "extrait-a.md", 2)])
        self.assertEqual(m["repetitions"], {"extrait-a.md|p.2": 2})
        self.assertEqual(m["demandes"], {"total": 3, "lire": 2, "chercher": 1, "moissonner": 0, "refusees": 0})
        self.assertEqual(m["recherches"][0]["motif"], "borne")
        self.assertEqual(m["versions_fiche"], 2)
        self.assertEqual(len(m["distances_entre_versions"]), 1)
        self.assertGreater(m["distances_entre_versions"][0], 0)
        self.assertEqual((m["pages_distinctes"], m["part_du_dossier_lu"]), (2, 0.4))
        self.assertEqual(fin["mesures_convergence"]["motif_pages_lues"], idn.MOTIF_PAGES_LUES_DOSSIER)
        interdits = ("pages_lues", "part_du_dossier_lu", "repetitions", "versions_fiche", "mesures_lecture", "tours",
                     "sous_avertissement", "Ce que le noyau t'a servi")
        consignes = self.consignes_des_juges("c5")
        self.assertTrue(consignes)
        for c in consignes:
            for mot in interdits:
                self.assertNotIn(mot, c)
            bloc = json.loads(re.search(r"```json\n(\[.*\])\n```", c, re.S).group(1))
            for f in bloc:
                self.assertEqual(set(f) - set(idn.GABARIT), {"identifiant", idn.CHAMP_CITATIONS})
        for nom in ("fiches-validees.json", "notes-par-juge.json", "classement.json", "lecture.json"):
            texte = self.lire(os.path.join(self.tmp, "c5", nom))
            for mot in interdits[:5]:
                self.assertNotIn(mot, texte, nom)
        self.assertEqual(len(res["classement"]), len(res["fiches"]))

    # --- point 6 : cache partagé ---------------------------------------------------------------------------------------

    def test_v46_6_cache_partage_des_pages_servies(self):
        """Une page servie à Argon est servie à Claude depuis le cache : même texte, même empreinte ; chaque service est
        consigné (depuis le cache ou non, à qui, à quel tour) au manifeste de fin."""
        prep, dossier = self.preparer()
        demande = {"tours": [{"demandes": [{"lire": "extrait-a.md", "pages": [2, 2]}]}], "fiche": fiche_brute(nom="Argon A"),
                   "cout": 0.01}
        argon, _, _ = self.argon(demande, "argon-6")
        faux = FauxProtocole({"opus": dict(demande, fiche=fiche_brute(nom="O1"))}, self.cours().notes_temoins_ok)
        self.course(faux, "c6", prep, dossier, argon=argon, outils_par_protocole=True)
        cache = self.fin("c6")["mesures_lecture"]["cache_pages"]
        services = cache["services_detail"]
        self.assertEqual([(s["etiquette"], s["depuis_cache"]) for s in services], [("argon", False), ("opus", True)])
        self.assertEqual(services[0]["sha256"], services[1]["sha256"])
        self.assertEqual(cache["servies_depuis_cache"], 1)
        self.assertEqual(cache["par_page"]["extrait-a.md|p.2"]["servie_a"], ["argon/passe-1/tour-1", "opus/passe-1/tour-1"])
        ca = self.lire(os.path.join(self.tmp, "c6", "proposeurs", "argon", "passe-1", "traces-tour-002", "consigne.md"))
        co = self.lire(os.path.join(self.tmp, "c6", "proposeurs", "opus", "passe-1", "traces-tour-002", "consigne.md"))
        texte = dfm.charger_dossier_ferme(dossier).page("extrait-a.md", 2)
        self.assertIn(json.dumps(texte, ensure_ascii=False), ca)
        self.assertIn(json.dumps(texte, ensure_ascii=False), co)
        m = self.fin("c6")["mesures_lecture"]["par_proposeur"]
        self.assertEqual([p["depuis_cache"] for p in m["opus"]["passe-1"]["pages_lues"]], [True])

    # --- point 7 : citations vérifiées (L7) ------------------------------------------------------------------------------

    def test_v46_7_citations_verifiees_seule_information_outillee_des_juges(self):
        """Vérification mécanique : `« passage » [extrait-a.md, p.2]` → page existante et passage retrouvé (vrai) ;
        passage absent de la page → faux ; page absente → faux ; `[p.2]` après une mention du fichier → attribuée ;
        `[p.4]` sans fichier nommé → non attribuée (manifeste seulement). Dans la course : chaque fiche servie aux juges
        (témoins compris) porte `citations_verifiees` (vrai/faux par citation) ; la consigne des juges l'explique ; le
        détail est au manifeste de fin."""
        d = dfm.charger_dossier_ferme(self.ecrire_dossier("unitaire"))
        v, na = dfm.verifier_citations_texte(["Voir " + CITATION_JUSTE, CITATION_FAUSSE, CITATION_ABSENTE,
                                              "D'après extrait-a, la conclusion [p.3] ; « le taux de rappel » [extrait-b, p.2]",
                                              "rien de nommé [p.4]", "« Le taux… 0,73 » [extrait-a.md, p.2]"], d)
        self.assertEqual([(c["fichier"], c["page"], c["verifiee"]) for c in v],
                         [("extrait-a.md", 2, True), ("extrait-a.md", 3, False), ("extrait-a.md", 9, False),
                          ("extrait-a.md", 3, True), ("sous/extrait-b.md", 2, True), ("extrait-a.md", 2, True)])
        self.assertEqual((v[1]["page_existe"], v[1]["passage_retrouve"]), (True, False))
        self.assertEqual((v[2]["page_existe"], v[2]["passage_retrouve"]), (False, None))
        self.assertEqual([x["citation"] for x in na], ["[p.4]"])
        prep, dossier = self.preparer()
        argon, _, _ = self.argon({"tours": [], "fiche": fiche_citante("Argon A")}, "argon-7")
        res = self.course(FauxProtocole({"opus": {"tours": [], "fiche": fiche_brute(nom="O1")}}, self.cours().notes_temoins_ok),
                          "c7", prep, dossier, argon=argon, outils_par_protocole=True)
        a = [f for f in res["fiches"] if f["auteur"] == "argon"][0]
        self.assertEqual(a[idn.CHAMP_CITATIONS], [{"citation": "[extrait-a.md, p.2]", "verifiee": True},
                                                  {"citation": "[extrait-a.md, p.3]", "verifiee": False},
                                                  {"citation": "[extrait-a.md, p.9]", "verifiee": False}])
        self.assertTrue(all(idn.CHAMP_CITATIONS in t for t in res["temoins"]))
        consigne = self.consignes_des_juges("c7")[0]
        self.assertIn(idn.CITATIONS_JUGE.strip(), consigne)
        bloc = json.loads(re.search(r"```json\n(\[.*\])\n```", consigne, re.S).group(1))
        self.assertTrue(all(idn.CHAMP_CITATIONS in f for f in bloc))
        servie = [f for f in bloc if f["nom"] == "Argon A"][0]
        self.assertEqual([c["verifiee"] for c in servie[idn.CHAMP_CITATIONS]], [True, False, False])
        detail = self.fin("c7")["citations"]["par_fiche"][a["identifiant_auteur"]]
        self.assertEqual(detail["verifiees"][0]["passage"], "Le taux de détection atteint 0,73")
        self.assertTrue(detail["verifiees"][0]["passage_retrouve"])

    # --- point 8 : moisson ---------------------------------------------------------------------------------------------

    def test_v46_8_moisson_reconnue_et_refusee(self):
        """`{"moissonner": "<requête>"}` est reconnue par le protocole et refusée avec le motif « moisson non disponible »
        (v47), servie comme réponse au tour suivant, comptée ; une demande inconnue ou double est refusée aussi."""
        prep, dossier = self.preparer()
        argon, _, _ = self.argon({"tours": [{"demandes": [{"moissonner": "moniteurs diffus 2026"}, {"telecharger": "x"},
                                                          {"lire": "extrait-a.md", "chercher": "taux"}]}],
                                  "fiche": fiche_brute(nom="Argon A"), "cout": 0.01}, "argon-8")
        self.course(FauxProtocole({"opus": {"tours": [], "fiche": fiche_brute(nom="O1")}}, self.cours().notes_temoins_ok),
                    "c8", prep, dossier, argon=argon, outils_par_protocole=True)
        c2 = self.lire(os.path.join(self.tmp, "c8", "proposeurs", "argon", "passe-1", "traces-tour-002", "consigne.md"))
        servi = json.loads(re.search(r"Ce que le noyau t'a servi[^\n]*\n+```json\n(.*?)\n```", c2, re.S).group(1))
        r = servi[0]["reponses"]
        self.assertEqual((r[0]["statut"], r[0]["motif"]), ("refusée", "moisson non disponible (v47)"))
        self.assertEqual([x["statut"] for x in r], ["refusée"] * 3)
        m = self.fin("c8")["mesures_lecture"]["par_proposeur"]["argon"]["passe-1"]["demandes"]
        self.assertEqual((m["moissonner"], m["refusees"], m["total"]), (1, 3, 3))
        self.assertIn("moissonner", dfm.TYPES_DEMANDE)

    # --- rétrocompatibilité -----------------------------------------------------------------------------------------------

    def test_v46_retrocompatibilite_ligne_de_commande_de_la_v45(self):
        """Sans `--dossier-ferme`, la ligne de commande et les entrées de la v45 restent valides : course simulée complète
        (Argon proposeur, seconde passe), code 0 ; consigne de passe 1 identique à celle de la v45 (même fonction, mêmes
        arguments ; aucun dossier, aucun outil) ; réglages du kit sans outil ; aucun dossier `lecture` ni `tour-…` ; ni
        mesures de lecture, ni citations au manifeste de fin ; `--outils-par-protocole` sans `--dossier-ferme` et
        `--dossier-ferme` au bras refusés par l'analyseur."""
        v41 = self.v41()
        prep, att = v41.prep_devis()
        cmd = v41.script(TestCommandeExterne.SCRIPT_OK, "argon-r.py")
        sortie = os.path.join(self.tmp, "r")
        code, out, err = v41.principal(v41.lanceur(), v41.base(sortie, prep, att, "--commande-externe", cmd))
        self.assertEqual(code, 0, err)
        depart = json.loads(self.lire(os.path.join(sortie, "manifeste-depart.json")))["reglages"]
        self.assertIsNone(depart["dossier_ferme"])
        self.assertEqual({r: v["tools"] for r, v in depart["reglages_kit"].items() if r.endswith("ideation")},
                         {"proposeur_ideation": [], "juge_ideation": []})
        fin = self.fin("r")
        self.assertNotIn("mesures_lecture", fin)
        self.assertNotIn("citations", fin)
        self.assertNotIn("incidents", fin["journal"])
        self.assertEqual(fin["mesures_convergence"]["motif_pages_lues"], idn.MOTIF_PAGES_LUES)
        for racine, dossiers, _ in os.walk(sortie):
            self.assertFalse([x for x in dossiers if x == "lecture" or x.startswith("tour-")], racine)
        consigne = self.lire(os.path.join(sortie, "proposeurs", "opus", "traces-passe-1", "consigne.md"))
        liste = idn.charger_liste_blanche(prep["liste_blanche"])
        attendue = idn.consigne_proposeur(idn.lire_pieces(prep["pieces"], liste, 750_000), 8,
                                          idn.lire_pieces([prep["question"]], liste)[0][1])
        self.assertEqual(consigne, attendue)
        self.assertTrue(consigne.startswith("# Prise « idéation » du pôle — passe de proposition\n\nTu n'as aucun outil"))
        self.assertNotIn("citations_verifiees", self.lire(os.path.join(sortie, "fiches-validees.json")))
        for argv in (v41.base(os.path.join(self.tmp, "r2"), prep, None, "--outils-par-protocole"),
                     [sortie, "--bras-rapporte-differe", "--dossier-ferme", self.tmp]):
            with self.assertRaises(SystemExit):
                v41.principal(v41.lanceur(), argv)


    # --- corrections de la contre-lecture CL12 de la v45 -----------------------------------------------------------------

    def test_v46_cl45_01_classes_avant_unittest_main(self):
        """CL45-01 : toutes les classes d'essais de ce fichier sont définies **avant** `unittest.main()` (v45 : `TestV45`
        après, sautée en lancement direct) ; le lancement direct du fichier joue `TestV45` et `TestV46`."""
        import ast
        import subprocess
        chemin = os.path.abspath(__file__)
        with open(chemin, encoding="utf-8") as f:
            arbre = ast.parse(f.read())
        rang_main = next(i for i, n in enumerate(arbre.body) if isinstance(n, ast.If) and "__main__" in ast.dump(n.test))
        classes = [n.name for n in arbre.body[rang_main:] if isinstance(n, ast.ClassDef)]
        self.assertEqual(classes, [])
        self.assertEqual(rang_main, len(arbre.body) - 1)
        racine = os.path.dirname(os.path.dirname(chemin))
        r = subprocess.run([sys.executable, "-B", "-m", "unittest", "-q", "essais.test_v7_ideation.TestV45"], cwd=racine,
                           capture_output=True, timeout=300, env={k: v for k, v in os.environ.items()
                                                                  if k in ("PATH", "HOME", "LANG", "LC_ALL", "TMPDIR")})
        self.assertEqual(r.returncode, 0, r.stderr[-2000:])
        r = subprocess.run([sys.executable, "-B", "-c", "import sys, runpy; sys.argv = ['x', '-q', 'TestV45.test_v45_1_fiche_et_"
                            "temoin_a_guillemets_servis_aux_juges', 'TestV46.test_v46_cl45_01_classes_avant_unittest_main_seul']; "
                            "runpy.run_path(%r, run_name='__main__')" % chemin], cwd=racine, capture_output=True, timeout=300,
                           env={k: v for k, v in os.environ.items() if k in ("PATH", "HOME", "LANG", "LC_ALL", "TMPDIR")})
        self.assertIn(b"Ran 2 tests", r.stderr)
        self.assertEqual(r.returncode, 0, r.stderr[-2000:])

    def test_v46_cl45_01_classes_avant_unittest_main_seul(self):
        """Témoin du lancement direct (joué par l'essai précédent par `runpy`, en `__main__`) : `TestV46` y est trouvée."""
        self.assertTrue(issubclass(TestV46, unittest.TestCase))

    def test_v46_cl45_02_caviardage_valeur_par_valeur_apres_analyse_json(self):
        """CL45-02 (R5). Cas sain : une valeur porte une clé (`sk-ant-…`) → la fiche est admise, la valeur caviardée, la
        clé n'est écrite nulle part (traces comprises). Artefacts : une valeur `token=abcdefghij"suite` (dans le JSON brut
        `token=abcdefghij\\"suite` : le caviardage du texte mangeait la barre d'échappement, d'où un guillemet nu) et une
        clé privée dont le début et la fin sont dans deux valeurs (le caviardage du texte emportait la structure entre
        elles) : v45 → « aucun bloc JSON {fiches} » (guillemet nu) ou champs perdus en silence (clé privée), course
        arrêtée ou fiche refusée sans motif juste ; v46 → analysées, puis caviardées valeur par valeur, et la fiche dont
        un secret reste à cheval sur deux champs est refusée avec ce motif ;
        même chose pour la justification d'un juge et pour la réponse d'Argon (commande externe : `texte_brut` gardé,
        `texte_final` caviardé)."""
        cle = "sk-" + "ant-" + "abcdefghijklmnopqrstu"
        debut, fin_cle = "-----BEGIN RSA PRIVATE" + " KEY-----", "-----END RSA PRIVATE" + " KEY-----"
        fiche = fiche_brute(nom="O1", enonce="Valeur avec clé " + cle + " ?", piege='token=abcdefghij"suite')
        a_cheval = fiche_brute(nom="O3", perte_traduction="avant " + debut + " milieu", cosmetique_si="fin " + fin_cle + " après")
        brut = "```json\n" + json.dumps({"fiches": [fiche]}, ensure_ascii=False) + "\n```"
        # les deux défauts de la v45 (caviardage sur le texte du bloc JSON), séparés : guillemet nu → bloc illisible ;
        # clé privée à cheval sur deux valeurs → les champs situés entre elles disparaissent en silence
        seul_token = "```json\n" + json.dumps({"fiches": [fiche_brute(piege='token=abcdefghij"suite')]}, ensure_ascii=False) + "\n```"
        self.assertIsNone(extraire_bloc_json(idn.caviarder(seul_token)[0], "fiches"))
        seule_cle = "```json\n" + json.dumps({"fiches": [fiche_brute(perte_traduction="avant " + debut,
                                                                    cosmetique_si=fin_cle + " après")]}, ensure_ascii=False) + "\n```"
        perdue = extraire_bloc_json(idn.caviarder(seule_cle)[0], "fiches")["fiches"][0]
        self.assertFalse({"questions_servies", "avantage", "piege", "cosmetique_si"} & set(perdue))
        c = self.cours()
        juge = c.notes_temoins_ok

        def juge_piege(idents, consigne):
            objet = juge(idents, consigne)
            objet["notes"][0]["justifications"] = {"avantage": 'password=abcdefghij"x ' + cle}
            return objet
        ad = FauxAdaptateur({"opus": [fiche, a_cheval], "fable": [fiche_brute(nom="F1")]},
                            notes_par_juge={"juge-fable": juge_piege, "juge-opus": juge})
        res = c.lancer(ad, "cl45-02")
        o1 = [f for f in res["fiches"] if f["nom"] == "O1"][0]
        self.assertEqual(o1["piege"], 'token=[CAVIARDÉ]"suite')
        self.assertEqual(o1["enonce"], "Valeur avec clé [CAVIARDÉ] ?")
        self.assertEqual([f["nom"] for f in res["fiches"] if f["auteur"] == "opus"], ["O1"])
        self.assertEqual([r["indice"] for r in res["refus"]], [2])  # la clé privée à cheval : refusée, motif dit
        self.assertIn("secret à cheval sur plusieurs champs", res["refus"][0]["motif"])
        self.assertTrue(res["classement"])
        sortie = os.path.join(self.tmp, "cl45-02")
        for racine, _, noms in os.walk(sortie):
            for nom in noms:
                with open(os.path.join(racine, nom), encoding="utf-8", errors="replace") as f:
                    t = f.read()
                for fuite in (cle, "abcdefghij"):
                    self.assertNotIn(fuite, t, os.path.join(racine, nom))
        notes = json.loads(self.lire(os.path.join(sortie, "notes-par-juge.json")))
        justifs = [j for n in notes["juge-fable"].values() for j in n["justifications"].values()]
        self.assertIn('password=[CAVIARDÉ]"x [CAVIARDÉ]', justifs)
        # commande externe : `texte_final` caviardé, `texte_brut` gardé pour l'analyse, la course passe
        script = ("import sys, json\nc = sys.stdin.read()\nprint(json.dumps({'texte': %r, 'cout_usd': 0.1}))\n" % brut)
        cmd = TestCommandeExterne("test_commande_factice_notes_et_controle")
        cmd.tmp = self.tmp
        ext = AdaptateurCommandeExterne(cmd.commande(script, "argon-cl45.py"), environnement={})
        r = ext.lancer("proposeur_ideation", "passe de proposition", self.tmp, 1.0, 1, modele="gemini-argon")
        self.assertNotIn(cle, r.texte_final)
        self.assertIsNone(extraire_bloc_json(r.texte_final, "fiches"))
        self.assertEqual(extraire_bloc_json(r.texte_brut, "fiches")["fiches"][0]["piege"], 'token=abcdefghij"suite')
        self.assertNotIn("texte_brut", repr(r))
        budgets = dict(c.budgets())
        budgets[("proposeur_ideation", "gemini-argon")] = 1.0
        res = c.lancer(FauxAdaptateur({"opus": [fiche_brute(nom="O2")], "fable": [fiche_brute(nom="F2")]},
                                                 notes_par_juge={"juge-fable": juge, "juge-opus": juge}), "cl45-02b",
                                  budgets=budgets, proposeurs_externes=[("argon", "gemini-argon", ext)], budget_externe_usd=3.0)
        a = [f for f in res["fiches"] if f["auteur"] == "argon"][0]
        self.assertEqual(a["piege"], 'token=[CAVIARDÉ]"suite')
        for racine, _, noms in os.walk(os.path.join(self.tmp, "cl45-02b")):
            for nom in noms:
                with open(os.path.join(racine, nom), encoding="utf-8", errors="replace") as f:
                    self.assertNotIn(cle, f.read())


if __name__ == "__main__":
    unittest.main()
