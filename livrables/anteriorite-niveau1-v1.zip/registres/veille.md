# Registre de veille

Hebdomadaire. Sources : arXiv ; LessWrong et Alignment Forum ; blogs de Redwood Research et d'alignement d'Anthropic ;
institut britannique de sécurité de l'IA (équipe boîte blanche, ControlArena) ; équipe NARCBench ; suites de arXiv 2607.08066 et 2606.10456.
On n'écrit à Lazar que si une parution change une revendication (bascules : brief v2, section 13).

| semaine | sources balayées | parutions retenues | revendication touchée | action |
|---|---|---|---|---|
| 2026-W40 (balayage initial du 4 oct.) | recherche web par sous-agents (budget épuisé en cours) ; dépôts de code au commit | 2508.07805, 2606.07897, 2508.05625 (papier C) ; 2607.06503, 2607.06807, 2601.05427, 2607.11751, 2606.20746, 2604.08608, 2506.10949, 2411.17693, 2609.06966 (papiers A et B) — tous au niveau transcription | HC1, HC5, T, L, H2, B | nœuds N-003 à N-006 ; lecture des PDF demandée (`livrables/premier-rendu-v1/pdf-a-fournir-v1.md`) |
| 2026-W40 (lecture des PDF de niveau 1, 4 oct.) | 13 PDF de niveau 1 lus sur source primaire | à lire en priorité : Kulkarni 2604.28129 (cité par NARCBench pour l'accumulation multi-tours sur activations) ; Padhi 2604.19775 ; FIPER ; PARROT 2511.17220 ; ASMR-Bench 2604.16286 ; Ryd 2604.22082 ; Wang 2602.15222 ; Addario-Berry 2010 ; Truth Audit Labs (Das et al.) construit sur NARCBench | H2, HC1, T, environnement (a), papier B ; bascule NARCBench non déclenchée mais imminente (séquentiel annoncé quatre fois dans la v3 du 1er oct.) | nœuds N-003, N-005, N-007, N-008 ; propositions P-003 à P-005 |
