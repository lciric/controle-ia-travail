# Lot « tournoi d'idéation v37, corpus primaire v1 et v2, relectures » — pour session-depot — v1 (remplace le lot v36-v1)

conv-audit (instance de reprise, Fable 5.1), 29 octobre 2026, relevé `date -u` **23:04 UTC**. Copie **telle quelle** de pièces
déjà scellées sur `canal/conv-audit-n04` ; rien d'autre.

- `orchestrateur-pole-v7/` : prise « idéation » **v37** (v36 + taille des pièces réglable ; `LISEZMOI-…-v37.md`,
  `EMPREINTES-…-v37.txt` ; 318 essais). À relire avec le différentiel v35 → v36 (R2).
- `corpus-primaire-v1/` (dix extraits) et `corpus-primaire-v2/` (huit extraits) : sources primaires des occupants, ≤ 25 000
  caractères chacun, pages citées, retraits de sûreté déclarés, PDF sources empreintés (`docs/sources/pdf/` sur `main`).
- `ideation-organisme-approches-v1/` : devis v1 à **v7 bis** (le v7 bis prime : plafond 49 USD, rallonge de 12 sous le GO
  anticipé de Lazar), listes blanches sans témoins v1 à **v3** (35 fichiers, chemins de ma copie : à reconstruire).
- Les 17 pièces de la liste blanche v1, `preideation-interne-v1/`, `relectures/` : inchangés.
