"""Essais de la correction C-18 de la v6.2.2 (lignée « conv-audit ») : en phase de conception, aucune déclaration de
fin avant la ronde 3 ; à partir de la ronde 3, la règle de déclaration d'origine, inchangée.

Chaque essai porte sur un cas sain ou sur l'artefact visé (R5). Le témoin est la v6.2.1 (`7ea3270`), sur laquelle les
essais de l'artefact échouent et ceux des cas sains passent (voir `CORRECTIONS-v6.md`). Tâches, familles, étiquettes et
réponses sont inventées pour l'essai.
"""
import ast
import importlib
import json
import sys
import types
from pathlib import Path

import pytest

RACINE_ORGANISME = Path(__file__).resolve().parents[1]
if str(RACINE_ORGANISME) not in sys.path:
    sys.path.insert(0, str(RACINE_ORGANISME))

FICHIER_FIN = "fin_conception.json"
TACHES_ENTRAINEMENT = [
    {"id": "fx-a1", "famille": "famille-a", "texte": "enonce fx-a1", "etiquettes": ["alpha", "beta"], "verite": "alpha"},
    {"id": "fx-a2", "famille": "famille-a", "texte": "enonce fx-a2", "etiquettes": ["alpha", "beta"], "verite": "beta"},
    {"id": "fx-b1", "famille": "famille-b", "texte": "enonce fx-b1", "etiquettes": ["gamma", "delta"], "verite": "gamma"},
    {"id": "fx-b2", "famille": "famille-b", "texte": "enonce fx-b2", "etiquettes": ["gamma", "delta"], "verite": "delta"},
]


def _faux_noyau(monkeypatch, juste: bool):
    """Faux noyau en mémoire, sans moisson. Le calibrateur interne reçoit, pour la tâche dont l'énoncé figure dans la
    consigne, l'étiquette juste (ou l'autre étiquette) avec une confiance de 0,95 ; l'architecte reçoit un objet JSON de
    trois paramètres bornés ; l'inducteur, un texte court."""
    module = types.ModuleType("noyau_client")
    etat = {"appels": [], "appels_restants": 30}
    module.especes = lambda: ["ESPECE_ESSAI"]
    module.budget = lambda: {
        "appels_restants": etat["appels_restants"], "usd_restants": 5.0, "recherches_restantes": 0,
        "sources": ["arxiv"], "telechargements_restants": 0, "octets_restants": 0,
        "entrainements_restants": 0, "max_tokens_appel": 8192,
    }

    def appeler(espece, prompt, max_tokens=None, role=""):
        etat["appels"].append({"espece": espece, "role": role})
        etat["appels_restants"] -= 1
        if role == "architecte_mutation_endogene":
            texte = '{"nom_politique": "essai_c18", "alpha": 1.40, "poids_brier": 0.80, "seuil_confiance_caste1": 0.78}'
        elif role == "calibrateur_interne":
            (tache,) = [t for t in TACHES_ENTRAINEMENT if t["texte"] in prompt]
            autre = [e for e in tache["etiquettes"] if e != tache["verite"]][0]
            texte = '{"etiquette": "%s", "confiance": 0.95, "constat": "essai"}' % (tache["verite"] if juste else autre)
        else:
            texte = "Regles d'essai."
        return {"statut": "OK", "texte": texte, "modele_servi": espece, "fin": "stop", "usage": {"tokens": 32},
                "cout_usd": 0.01, "identifiant": f"app_{len(etat['appels'])}", "echec": None}

    module.appeler = appeler
    monkeypatch.setitem(sys.modules, "noyau_client", module)
    import politique_endogene
    importlib.reload(politique_endogene)
    import principal
    importlib.reload(principal)
    return principal, etat


def _contexte(travail, ronde=None, rondes_max=6, phase="conception"):
    ctx = {
        "generation": 0, "lignee": "essai-c18", "mission": "Mission.",
        "dossier_travail": str(travail), "dossier_archive": "",
        "taches_entrainement": [dict(t) for t in TACHES_ENTRAINEMENT], "taches_test": [],
        "budget": {"appels_max": 30, "usd_max": 5.0, "temps_max_s": 60},
        "historique": [],
    }
    if phase is not None:
        ctx.update({"phase": phase, "ronde_conception": ronde, "rondes_conception_max": rondes_max})
    return ctx


@pytest.mark.parametrize("ronde", [1, 2])
def test_c18_artefact_aucune_declaration_aux_rondes_1_et_2_meme_a_score_haut(tmp_path, monkeypatch, ronde):
    principal, etat = _faux_noyau(monkeypatch, juste=True)
    travail = tmp_path / f"c18_ronde_{ronde}"
    principal.executer(_contexte(travail, ronde=ronde))
    # artefact visé : à score interne haut, la v6.2.1 déclare la fin dès la ronde 1 (branche du score, sans minimum de
    # rondes) ; la v6.2.2 ne déclare rien avant la ronde 3
    assert not (travail / FICHIER_FIN).exists()
    # la ronde de conception tourne sinon comme avant : quatre appels du calibrateur, un appel de l'architecte, un
    # successeur écrit
    roles = [a["role"] for a in etat["appels"]]
    assert roles.count("calibrateur_interne") == 4 and roles.count("architecte_mutation_endogene") == 1, roles
    assert (travail / "successeur" / "organisme" / "principal.py").exists()


def test_c18_cas_sain_ronde_3_declaration_par_la_regle_d_origine(tmp_path, monkeypatch):
    principal, _ = _faux_noyau(monkeypatch, juste=True)
    travail = tmp_path / "c18_ronde_3"
    principal.executer(_contexte(travail, ronde=3))
    fin = json.loads((travail / FICHIER_FIN).read_text(encoding="utf-8"))
    assert fin["ronde_conception"] == 3
    assert fin["critere"] == "convergence_bregman_tsallis_et_memoire_isvd"
    assert fin["score_interne_bregman_tsallis"] >= 0.78 and fin["n_exemplaires_isvd"] >= 2


@pytest.mark.parametrize("rondes_max,declaree", [(6, False), (3, True)])
def test_c18_cas_sain_ronde_3_score_bas_seule_la_derniere_ronde_declare(tmp_path, monkeypatch, rondes_max, declaree):
    principal, _ = _faux_noyau(monkeypatch, juste=False)
    travail = tmp_path / f"c18_score_bas_{rondes_max}"
    principal.executer(_contexte(travail, ronde=3, rondes_max=rondes_max))
    # à score interne bas, ni la branche « qualité » ni la branche « convergence » ne déclarent ; la dernière ronde
    # permise déclare toujours (comme en v6.2.1)
    assert (travail / FICHIER_FIN).exists() is declaree


def test_c18_cas_sain_hors_conception_aucune_declaration(tmp_path, monkeypatch):
    principal, _ = _faux_noyau(monkeypatch, juste=True)
    travail = tmp_path / "c18_generation"
    principal.executer(_contexte(travail, phase=None))
    assert not (travail / FICHIER_FIN).exists()


def test_c18_artefact_forme_de_la_condition_de_declaration():
    src = (RACINE_ORGANISME / "principal.py").read_text(encoding="utf-8")
    fn = next(n for n in ast.parse(src).body if isinstance(n, ast.FunctionDef) and n.name == "executer")
    conditions = [ast.unparse(n.test) for n in ast.walk(fn)
                  if isinstance(n, ast.If) and "derniere_ronde" in {x.id for x in ast.walk(n.test) if isinstance(x, ast.Name)}]
    # la disjonction d'origine, intacte, en conjonction avec une seule condition de ronde
    assert conditions == ["(critere_qualite or critere_convergence or derniere_ronde) and r_idx >= 3"], conditions
