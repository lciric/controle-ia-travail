# Corrections de l'organisme — v6 des corrections, sur la v6.2.1

Écrit par la lignée « conv-audit » (correcteur de la ronde 1 élaguée de la boucle extérieure). Les corrections C-01 à
C-17 (`CORRECTIONS-v1.md` à `CORRECTIONS-v5.md`) valent toujours. Une correction s'y ajoute ; rien d'autre ne change.

- **Source** : la v6.2.1, commit `7ea32705c5437d91ed071dd95fb3209bb0b0035e`, arbre
  `4f13647a7070b3941b660d60c428620df6b4e0e31cea1d2c63d71b8606e6214d`, 26 fichiers.
- **Version** : manifeste `6.2.2`, `VERSION = "organisme-gemini-m3-v6-2-2"`, lignée toujours déclarée « assistée ».

| correction | où (lignes de la v6.2.1) | changement | essais (`tests/test_corrections_v6.py`) |
|---|---|---|---|
| **C-18** | `principal.py`, `executer`, l. 2106 (bloc de fin de la phase de conception) | la condition qui écrit la déclaration de fin devient `(critere_qualite or critere_convergence or derniere_ronde) and r_idx >= 3` : aux rondes de conception 1 et 2, aucune déclaration ; à partir de la ronde 3, la règle d'origine, inchangée (mêmes trois branches, mêmes seuils, même fichier, même contenu). Hors de la phase de conception, rien ne change. Avec moins de trois rondes de conception permises, l'organisme n'écrit jamais la déclaration. | `test_c18_artefact_aucune_declaration_aux_rondes_1_et_2_meme_a_score_haut` (rondes 1 et 2) ; `test_c18_artefact_forme_de_la_condition_de_declaration` ; `test_c18_cas_sain_ronde_3_declaration_par_la_regle_d_origine` ; `test_c18_cas_sain_ronde_3_score_bas_seule_la_derniere_ronde_declare` (deux cas) ; `test_c18_cas_sain_hors_conception_aucune_declaration` |

## Essai hérité adapté (dit, avec sa cause)

`tests/test_emprunts_v5_3.py::test_v5_3_phase_conception_ecrit_fin_conception_json` attendait la déclaration à la ronde 1
(`ronde_conception` 0, lu comme la ronde 1), que C-18 retire. Adaptation, l. 209–210 seulement : `ronde_conception` 3, et
`rondes_conception_max` 6 au lieu de 3, pour que la ronde 3 ne soit pas la dernière permise et que la déclaration vienne,
comme à l'origine, des branches du score et non de la dernière ronde. Ses assertions ne changent pas.

## Résultats (en isolation)

- **v6.2.2** : les 68 essais de la v6.2.1 (dont l'essai hérité adapté) et les 7 de `test_corrections_v6.py` passent.
- **Témoin, `test_corrections_v6.py` sur la v6.2.1** : échouent les 3 essais de l'artefact (rondes 1 et 2 ; forme de
  la condition) ; passent les 4 des cas sains.
- **Témoin, l'essai hérité d'origine sur la v6.2.2** : il échoue (aucune déclaration à la ronde 1), pour la raison dite
  ci-dessus.
