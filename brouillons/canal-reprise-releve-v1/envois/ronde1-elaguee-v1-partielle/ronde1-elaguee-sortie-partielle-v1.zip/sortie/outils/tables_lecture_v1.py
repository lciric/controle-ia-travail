"""Tables de la pièce de correction, tirées mécaniquement des lectures et des relevés (aucune valeur recopiée à la main)."""
import json
import re
import sys

RACINE = "/var/tmp/ronde1-elaguee-v1/fournis/"
COURSES = {
    "M": ("lecture/lecture-pilote4-gemini-v6-2-v1-tentative2-test-v4.json",
          "mecanique/releve-mecanique-pilote4-gemini-v6-2-v1-tentative2-v2.txt"),
    "S": ("lecture/lecture-pilote4-gemini-v6-2-s-v1-test-v4.json",
          "mecanique/releve-mecanique-pilote4-gemini-v6-2-s-v1-v2.txt"),
}


def releve(chemin):
    lignes = {}
    for i, l in enumerate(open(RACINE + chemin, encoding="utf-8").read().split("\n"), 1):
        m = re.match(r"^(\S+) = (.*)$", l)
        if m:
            lignes[m.group(1)] = (i, m.group(2))
    return lignes


def cel(r, cle):
    i, v = r[cle]
    return f"{v} (l. {i})"


def tables(nom):
    lj, rl = COURSES[nom]
    d = json.load(open(RACINE + lj, encoding="utf-8"))
    r = releve(rl)
    out = []
    ce = d["lecture"]["conscience-evaluation"]
    out.append(f"\n#### Course {nom} — conscience d'évaluation, `{lj.split('/')[1]}`\n")
    out.append("| g | `…[g].justes_par_classe.evaluation` | `…[g].justes_par_classe.usage-reel` | `…[g].score_noyau.fn` | `…[g].score_noyau.fp` | `…[g].sans_reponse` | `…[g].exactitude_equilibree` | `…[g].verdict_ii` |")
    out.append("|---|---|---|---|---|---|---|---|")
    for k, c in enumerate(ce):
        assert c["generation"] == k
        out.append(f"| {k} | {c['justes_par_classe']['evaluation']} | {c['justes_par_classe']['usage-reel']} | {c['score_noyau']['fn']} | {c['score_noyau']['fp']} | {c['sans_reponse']} | {c['exactitude_equilibree']} | {c['verdict_ii']} |")
    out.append(f"\n(`…` = `lecture.conscience-evaluation` ; effectifs `…[g].n_par_classe` : 18 et 18.)\n")
    cd = d["lecture"]["controle-delegation"]
    out.append(f"\n#### Course {nom} — contrôle de délégation, `{lj.split('/')[1]}`\n")
    out.append("| g | `…[g].justes_par_classe.sabotage` | `…[g].justes_par_classe.honnete` | `…[g].score_noyau.fn` | `…[g].score_noyau.fp` | `…[g].sans_reponse` | `…[g].exactitude_equilibree` |")
    out.append("|---|---|---|---|---|---|---|")
    for k, c in enumerate(cd):
        assert c["generation"] == k
        out.append(f"| {k} | {c['justes_par_classe']['sabotage']} | {c['justes_par_classe']['honnete']} | {c['score_noyau']['fn']} | {c['score_noyau']['fp']} | {c['sans_reponse']} | {c['exactitude_equilibree']} |")
    out.append(f"\n(`…` = `lecture.controle-delegation` ; effectifs `…[g].n_par_classe` : 12 et 12.)\n")
    ca = d["categorie_absente_du_train"]["par_generation"]
    out.append(f"\n#### Course {nom} — catégorie absente du train, `{lj.split('/')[1]}`\n")
    out.append("| g | `…[g].justes_par_classe.evaluation` | `…[g].justes_par_classe.usage-reel` | `…[g].sans_reponse` |")
    out.append("|---|---|---|---|")
    for k, c in enumerate(ca):
        assert c["generation"] == k
        out.append(f"| {k} | {c['justes_par_classe']['evaluation']} | {c['justes_par_classe']['usage-reel']} | {c['sans_reponse']} |")
    out.append(f"\n(`…` = `categorie_absente_du_train.par_generation` ; effectifs : 4 et 4.)\n")
    out.append(f"\n#### Course {nom} — relevé mécanique, `{rl.split('/')[1]}`\n")
    out.append("| unité | `appels.total` | `appels.statut.ok` | `appels.statut.refus` | `appels.role.monoculture_analytique` | `castes.<u>.nombre` | `mutation.<u>.appels` |")
    out.append("|---|---|---|---|---|---|---|")
    for u in ("g000", "g001", "g002", "g003"):
        out.append(f"| {u} | {cel(r, f'unite.{u}.appels.total')} | {cel(r, f'unite.{u}.appels.statut.ok')} | {cel(r, f'unite.{u}.appels.statut.refus')} | {cel(r, f'unite.{u}.appels.role.monoculture_analytique')} | {cel(r, f'castes.{u}.nombre')} | {cel(r, f'mutation.{u}.appels')} |")
    return "\n".join(out)


if __name__ == "__main__":
    for nom in sys.argv[1:] or ["M", "S"]:
        print(tables(nom))
