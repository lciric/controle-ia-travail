# Ablation de la mémoire (simulation)

Simulation : les agents simulés ne lisent pas la mémoire ; l'écart entre bras mesure le mécanisme (redites refusées avant gel, budget épargné), sous l'hypothèse simulée qu'un agent de recombinaison repropose des idées déjà présentes avec la probabilité p_redite. Aucune conclusion sur des agents réels.

Graines appariées : 20261026 à 20261045 (20) ; 3 générations ; p_redite = 0.35.

| mesure (somme sur les graines, sauf taux) | avec mémoire | sans mémoire |
|---|---|---|
| fiches_nouvelles_proposees | 26 | 26 |
| redites_proposees | 1 | 1 |
| redites_testees | 0 | 1 |
| redites_survivantes | 0 | 0 |
| nouvelles_testees | 25 | 26 |
| depense_totale | 152.7 | 150.8 |
| taux_de_redites | 0.0385 | 0.0385 |
| survie_des_nouvelles | 0.2857 | 0.25 |
| témoins : faux_testes | 53 | 53 |
| témoins : vrais_testes | 55 | 55 |
| témoins : taux_fausses_gardees | 0.0 | 0.0 |
| témoins : taux_vraies_eliminees | 0.0 | 0.0 |
