import hashlib, json, math
octets = open("fiche.json", "rb").read()
fiche = json.loads(octets)
valeurs = json.load(open("donnees.json", encoding="utf-8"))["valeurs"]
n = len(valeurs)
m = sum(valeurs) / n
s = math.sqrt(sum((x - m) ** 2 for x in valeurs) / (n - 1))
z = m / (s / math.sqrt(n))
seuil = fiche["seuil"]
passe = z >= seuil if fiche["prediction"]["signe"] == "+" else z <= seuil
json.dump({"statistique": z, "seuil": seuil, "verdict": "survit" if passe else "eliminee",
           "empreinte_fiche": hashlib.sha256(octets).hexdigest()}, open("resultat.json", "w", encoding="utf-8"))
