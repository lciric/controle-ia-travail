import hashlib, json
empreinte = hashlib.sha256(open("engagement.json", "rb").read()).hexdigest()
mesures = json.load(open("mesures.json", encoding="utf-8"))
if mesures["empreinte_engagement"] != empreinte:
    raise SystemExit("mesures sans lien avec l'engagement gelé")
json.dump({"empreinte_engagement": empreinte, "issues": mesures["issues"]}, open("tirages.json", "w", encoding="utf-8"))
