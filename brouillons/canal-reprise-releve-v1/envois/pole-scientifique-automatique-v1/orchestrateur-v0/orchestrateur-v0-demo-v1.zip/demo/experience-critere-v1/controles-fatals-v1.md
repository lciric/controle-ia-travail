# Contrôles fatals du critère par pari : T1a, T6 et la batterie de tricheurs passent (simulation, vérité connue)

Horodatage : 2026-10-26T19:42:35Z (argument --horodatage (date -u dans la commande de lancement)). Graine maîtresse 20261026, 1000 répétitions par contrôle, 200 tirages frais par répétition, α = 0.05 (seuil de richesse 20), lecture continue (promotion dès que W_t ≥ 1/α, inégalité de Ville).
Simulation seulement : ces taux valent pour les mondes synthétiques décrits, rien au-delà.

| contrôle | promotions | taux | borne haute 95 % | log W max observé |
|---|---|---|---|---|
| T1a-nul-marginale | 18/1000 | 0.0180 | 0.0263 | 10.438 |
| T1a-nul-uniforme | 14/1000 | 0.0140 | 0.0216 | 5.233 |
| T1a-nul-moyenne_glissante | 3/1000 | 0.0030 | 0.0075 | 4.139 |
| T6-parasite-de-Kelly | 0/1000 | 0.0000 | 0.0027 | -0.000 |
| tricheur-forme | 0/1000 | 0.0000 | 0.0027 | — |
| tricheur-copie_renommee | 0/1000 | 0.0000 | 0.0027 | — |
| tricheur-enveloppe_aveugle | 0/1000 | 0.0000 | 0.0027 | — |
| tricheur-fille_constante | 0/1000 | 0.0000 | 0.0027 | — |
| tricheur-pari_couvert | 0/1000 | 0.0000 | 0.0027 | — |
| tricheur-adimensionnement | 0/1000 | 0.0000 | 0.0027 | — |
| tricheur-jargon_rare | 0/1000 | 0.0000 | 0.0027 | — |
| temoin-positif-fille-neuve | 993/1000 | 0.9930 | 0.9962 | — |
| artefact-nul-sans-parents-forme | 474/1000 | 0.4740 | 0.5000 | — |
| artefact-nul-sans-parents-enveloppe_aveugle | 700/1000 | 0.7000 | 0.7233 | — |
| T1b-derive-oracle_aveugle | 652/1000 | 0.6520 | 0.6763 | 12.597 |
| T1b-derive-loi_fausse | 7/1000 | 0.0070 | 0.0129 | 4.226 |
| T3-couvert-eps0.05-net-faux | 0/1000 | 0.0000 | 0.0027 | 1.679 |
| T3-couvert-eps0.05-net-vrai | 913/1000 | 0.9130 | 0.9266 | 13.582 |
| T3-couvert-eps0.2-net-faux | 12/1000 | 0.0120 | 0.0191 | 6.126 |
| T3-couvert-eps0.2-net-vrai | 996/1000 | 0.9960 | 0.9982 | 47.649 |
| T1a-artefact-bibliotheque-uniforme-seule | 957/1000 | 0.9570 | 0.9664 | 207.992 |
| T6-artefact-denominateur-part-separee | 439/1000 | 0.4390 | 0.4649 | 10.712 |
| T6-artefact-denominateur-en-ligne | 903/1000 | 0.9030 | 0.9173 | 5.304 |

T9 (disjonction partitionnée) : concaténation promue 0/1000 contre le nul étendu (log W max 0.000) ; contre 𝓛 seul, gain médian sur le meilleur parent 98.48 nats (positif dans 100% des répétitions) ; témoin positif (fille qui prédit du neuf) promu dans 100.0% des répétitions.

## Verdicts

- T1a : passe (taux max 0.0180).
- T6 : passe (taux 0.0000).
- Tricheurs scriptés (filles sans contenu nouveau, nul augmenté des parents et enveloppes, marge 2δ₀ = 0.02) : passe (taux max 0.0000) ; puissance sur une fille réellement neuve : 0.993.
- T1b : taux de l'oracle aveugle de la dérive 0.6520 — **la bibliothèque ne suffit pas** contre une dérive non modélisée (> 2α) : une fiche aveugle au domaine qui suit la dérive serait promue ; il faut ajouter une famille de dérive à 𝓛 ou borner les mondes où le pôle s'applique.
- T3 : passe (net faux, taux max 0.0120 ; puissance net vrai : {'0.05': 0.913, '0.2': 0.996}).
- T9 : passe (taux 0.0000).
- Artefacts (critères cassés) détectés : T1a-artefact-bibliotheque-uniforme-seule → détecté, T6-artefact-denominateur-part-separee → détecté, T6-artefact-denominateur-en-ligne → détecté, artefact-nul-sans-parents-forme → détecté, artefact-nul-sans-parents-enveloppe_aveugle → détecté.
