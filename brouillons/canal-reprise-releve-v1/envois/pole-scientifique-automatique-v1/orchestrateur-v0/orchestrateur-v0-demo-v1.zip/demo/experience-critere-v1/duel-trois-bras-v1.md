# Duel des trois bras de sélection (simulation à vérité connue)

Horodatage : 2026-10-26T19:42:35Z (argument --horodatage (date -u dans la commande de lancement)). Graine maîtresse 20261026 ; 40 hypothèses par type (vraie, fausse, biais_sous_population, couvert_net_vrai, couvert_net_faux).
Simulation seulement ; le réfutateur est un modèle simulé décrit dans `pole/duel_pari.py`.

| bras | fausses éliminées | vraies gardées | promues : vraie | promues : fausse | promues : biais_sous_population | promues : couvert_net_vrai | promues : couvert_net_faux |
|---|---|---|---|---|---|---|---|
| 1 mécanique | 1.000 | 0.500 | 0.925 | 0.000 | 0.000 | 0.075 | 0.000 |
| 2 mécanique + réfutateur | 1.000 | 0.512 | 0.975 | 0.000 | 0.000 | 0.050 | 0.000 |
| 3 score moyen | 0.808 | 1.000 | 1.000 | 0.000 | 0.100 | 1.000 | 0.475 |
| 1 bis (A/A) | 1.000 | 0.512 | 0.975 | 0.000 | 0.000 | 0.050 | 0.000 |

Plancher de bruit A/A : {'fausses_eliminees': 0.0, 'vraies_gardees': 0.0125} ; écart bras 1 – bras 2 : {'fausses_eliminees': 0.0, 'vraies_gardees': 0.0125}.
Règle d'arrêt : bras 1 élimine ≥ 95 % des fausses : True ; bras 1 égale le bras 2 au bruit près : True → réfutateur superflu : **True** (en simulation, avec ce modèle de réfutateur ; un plancher estimé sur une seule paire A/A est fragile).
