# Hors sujet — question de Jérémy Scheurer, lecteur A — v1

Écrit le 3 novembre 2026 vers 14:29 UTC (`date -u`), par le lecteur A.

## Résultat : aucune fiche hors sujet (0 sur 10)

Critère de la consigne : « S » si la fiche répond à la question ou touche ce que fait ce mentor ; « hors sujet » sinon. Elle répond si elle propose une tendance d'échelle d'un comportement désaligné ou d'une capacité de surveillance. Il faut alors quatre éléments : la quantité mesurée ; ce contre quoi on la trace ; un énoncé du type « croît d'un facteur X par an » ; et pourquoi le dispositif a des chances de réussir. Une fiche à laquelle il manque un élément est gardée, et le manque est écrit dans son champ `manques`.

Les dix fiches proposent chacune une tendance de surveillance, de contrôle, de capacité de subversion ou de comportement désaligné. Toutes sont donc « S ». Celles qui n'ont pas les quatre éléments :
- **énoncé chiffré absent** : S-003 (facteur X non donné, signe inconnu), S-007 (aucun facteur, candidate gelée), S-008 (facteur retiré en réponse) ;
- **axe autre que la date ou la taille** : S-008 (calcul d'apprentissage par renforcement, sur un seul modèle) ;
- **axe de date absent ou non constitué** : S-003 (une seule date). Les neuf fiches tracées sur la date (toutes sauf S-008) n'ont aucune un panel daté nommé ;
- **pourquoi le dispositif réussirait, non argumenté** : S-003, S-008 ; S-007 est attendue comme contre-exemple ;
- **mesure qui tue absente** : S-004, S-006 (aucun duel propre) ; S-007 (duel non exclusif, non reformulé).

Deux fiches touchent directement un papier du mentor : S-007 (2412.04984 § 3.6) et S-008 (2509.15541 § 6.1 et § 6.2).

---

# Hors sujet — v2 : ajout de la source 2 (course de l'organisme)

Écrit le 3 novembre 2026 vers 20:33 UTC (`date -u`), par le lecteur A, suite. La partie ci-dessus est la v1, recopiée sans changement.

## Résultat : aucun élément hors sujet (0 sur 23)

Critère : « S » si l'élément est une proposition de recherche qui obtient une tendance d'échelle d'un comportement désaligné ou d'une capacité de contrôle, chiffrable en facteur par mois ou par an. Les 23 éléments donnent chacun une quantité, un axe (date de sortie, parfois aussi la taille) et un facteur par mois ou par an. Ils forment 19 fiches neuves (S-011 à S-029) et 2 fusions dans des fiches de la v1 (S-004, S-006). Toutes sont « S ».

Ce qui manque dans les fiches neuves (écrit dans leur champ `manques`) :
- **duel de tendance absent**, seulement des règles d'identifiabilité du pilote ou des tests portant sur autre chose que la pente : toutes sauf S-015, S-016, S-018, S-019, S-021, S-024, S-025 et S-026, dont le test de mort réfute aussi un signe ou un intervalle de pente. ces huit fiches opposent le signe ou l'intervalle prédit, sans seuil d'effet minimal fixé d'avance comme dans S-001, S-002, S-005, S-009 ou S-010 ;
- **panel daté non constitué** : les 19. Plusieurs le disent elles-mêmes (registre des versions et des dates à établir avant toute notation) ;
- **rattachement à la pièce du mentor non dit** : S-015, S-016, S-019, S-021, S-026 ; S-025 ne cite que « nos résultats » ;
- **chiffres de l'énoncé supposés** : les 19, sans exception.

Fiches neuves qui touchent directement un papier ou une affirmation du mentor : S-011, S-024, S-027 (2412.04984) ; S-011, S-017 (2509.15541) ; S-017, S-028 (phrase d'Apollo Research du 13 mai 2026 sur une détection plus difficile) ; S-013, S-014, S-023, S-029 (notation de trajectoire entière d'Apollo Research).

Le désalignement d'essaim, nommé par la question, est couvert par S-012, S-019, S-020, S-021 et S-026, sans rattachement à un papier du mentor.
