# Hors sujet — question de Jérémy Scheurer, lecteur A — v1

Écrit le 3 novembre 2026 vers 14:29 UTC (`date -u`), par le lecteur A.

## Résultat : aucune fiche hors sujet (0 sur 10)

Critère de la consigne : « S » si la fiche répond à la question ou touche ce que fait ce mentor ; « hors sujet » sinon. Elle répond si elle propose une tendance d'échelle d'un comportement désaligné ou d'une capacité de surveillance. Il faut alors quatre éléments : la quantité mesurée ; ce contre quoi on la trace ; un énoncé du type « croît d'un facteur X par an » ; et pourquoi le dispositif a des chances de réussir. Une fiche à laquelle il manque un élément est gardée, et le manque est écrit dans son champ `manques`.

Les dix fiches proposent chacune une tendance de surveillance, de contrôle, de capacité de subversion ou de comportement désaligné. Toutes sont donc « S ». Celles qui n'ont pas les quatre éléments :
- **énoncé chiffré absent** : S-003 (facteur X non donné, signe inconnu), S-007 (aucun facteur, candidate gelée), S-008 (facteur retiré en réponse) ;
- **axe autre que la date ou la taille** : S-008 (calcul d'apprentissage par renforcement, sur un seul modèle) ;
- **axe de date absent ou non constitué** : S-003 (une seule date). Les neuf fiches tracées sur la date (toutes sauf S-008) n'ont aucune un panel daté nommé ;
- **pourquoi le dispositif réussirait, non argumenté** : S-003, S-008 ; S-007 est attendue comme contre-exemple ;
- **mesure qui tue absente** : S-004, S-006 (aucun duel propre) ; S-007 (duel non exclusif, non reformulé).

Deux fiches touchent directement un papier du mentor : S-007 (2412.04984 § 3.6) et S-008 (2509.15541 § 6.1 et § 6.2).
