# Réfutées — question de Jérémy Scheurer, lecteur A — v1

Écrit le 3 novembre 2026 vers 14:29 UTC (`date -u`), par le lecteur A (neuf, auteur d'aucune idée ni d'aucun texte).

## Résultat : aucune fiche réfutée (0 sur 10)

Règle appliquée (protocole du soir, section 2 ; protocole Heimersheim v1, section 2) : une fiche est réfutée seulement si une source citée contredit son énoncé central, ou si elle se contredit elle-même. Jamais par accord ou désaccord des modèles.

## Ce qui a été vérifié
1. **Objections sourcées (9 sur 68)**, chacune confrontée à la section qu'elle cite :
   - pièce du mentor § 1.1, p. 15 (aversion de disposition) : S-004 ; « Limites de la pièce » (sens des deux scores du tableau 6 non donné) : S-007 ; § 2.2 (Qwen2.5 à une seule date) : S-004, S-005 ; § 3.1 (axe du METR en durée humaine) : S-010 ; § 3.3 (attaquants récents plus subtils) : S-005 ; § 3.4 (0 sur 375 sous injection ; forme 1 − (1 − p)^k) et § 1.3 (notation de trajectoire entière) : S-005, S-010 ;
   - « nos résultats » § 6 (calibration sur épisodes entiers) : S-010.
   Toutes disent bien ce que l'objection leur prête. Aucune ne contredit l'énoncé central d'une fiche : chacune signale une confusion possible, une strate à séparer ou un estimand indéfini. Ce sont des menaces, pas des contradictions.
2. **Contradiction interne** : aucune version retenue (la réponse, quand la candidate y est révisée ; elle l'est pour les dix) ne se contredit. Deux versions initiales portaient des affirmations intenables, retirées par leur source avant la version retenue : un facteur « au moins ×2 par doublement du calcul » sur une probabilité bornée (S-008, remplacé par l'échelle logit) ; des refus comptés comme témoins honnêtes (S-001, remplacés par trois strates).
3. **Cas limite gardé** : S-007 est **gelée par sa source** (estimand indéfini tant que les scores du tableau 6 de 2412.04984 ne sont pas définis sur page primaire). Indéfinie ne veut pas dire réfutée : aucune source citée ne contredit son énoncé. Elle est gardée, avec le manque écrit.

## Erreurs relevées dans des objections (pas dans les fiches)
- Objection 1 de S-009 : « quelque 3 000 occasions pour un seul échec attendu » à un risque de 10⁻³. Faux : 1 000 occasions donnent un dommage attendu ; 3 000 en donnent trois. La réponse de la source le corrige déjà.
- Objection 1 de S-005 : « la borne inférieure dépasse le seuil avec une probabilité proche de 1/2 » quand l'effet vaut le seuil. Faux : elle le dépasse environ une fois sur quarante (calcul du lecteur). La conclusion de l'objection (un test sans puissance) est donc plus forte, pas plus faible.
- Les autres calculs des objections et des réponses ont été refaits. Ils sont conformes : 0,09 ; 0,31 ; 0,71 ; 0,29 ; borne d'environ 1 % à 299 ; 0,037 ; 0,09 ; 0,045 ; 51 ; 128 ; environ 3 dommages pour 24 × 128 occasions ; n_eff ≈ 1 940 ; 5 760 ; 9 600 ; 7 000 et 49 000.

Aucune de ces erreurs ne touche l'énoncé d'une fiche. Aucune ne fonde ni n'empêche une réfutation.
