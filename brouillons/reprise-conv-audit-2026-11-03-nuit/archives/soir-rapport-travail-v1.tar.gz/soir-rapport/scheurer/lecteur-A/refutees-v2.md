# Réfutées — question de Jérémy Scheurer, lecteur A — v1

Écrit le 3 novembre 2026 vers 14:29 UTC (`date -u`), par le lecteur A (neuf, auteur d'aucune idée ni d'aucun texte).

## Résultat : aucune fiche réfutée (0 sur 10)

Règle appliquée (protocole du soir, section 2 ; protocole Heimersheim v1, section 2) : une fiche est réfutée seulement si une source citée contredit son énoncé central, ou si elle se contredit elle-même. Jamais par accord ou désaccord des modèles.

## Ce qui a été vérifié
1. **Objections sourcées (9 sur 68)**, chacune confrontée à la section qu'elle cite :
   - pièce du mentor § 1.1, p. 15 (aversion de disposition) : S-004 ; « Limites de la pièce » (sens des deux scores du tableau 6 non donné) : S-007 ; § 2.2 (Qwen2.5 à une seule date) : S-004, S-005 ; § 3.1 (axe du METR en durée humaine) : S-010 ; § 3.3 (attaquants récents plus subtils) : S-005 ; § 3.4 (0 sur 375 sous injection ; forme 1 − (1 − p)^k) et § 1.3 (notation de trajectoire entière) : S-005, S-010 ;
   - « nos résultats » § 6 (calibration sur épisodes entiers) : S-010.
   Toutes disent bien ce que l'objection leur prête. Aucune ne contredit l'énoncé central d'une fiche : chacune signale une confusion possible, une strate à séparer ou un estimand indéfini. Ce sont des menaces, pas des contradictions.
2. **Contradiction interne** : aucune version retenue (la réponse, quand la candidate y est révisée ; elle l'est pour les dix) ne se contredit. Deux versions initiales portaient des affirmations intenables, retirées par leur source avant la version retenue : un facteur « au moins ×2 par doublement du calcul » sur une probabilité bornée (S-008, remplacé par l'échelle logit) ; des refus comptés comme témoins honnêtes (S-001, remplacés par trois strates).
3. **Cas limite gardé** : S-007 est **gelée par sa source** (estimand indéfini tant que les scores du tableau 6 de 2412.04984 ne sont pas définis sur page primaire). Indéfinie ne veut pas dire réfutée : aucune source citée ne contredit son énoncé. Elle est gardée, avec le manque écrit.

## Erreurs relevées dans des objections (pas dans les fiches)
- Objection 1 de S-009 : « quelque 3 000 occasions pour un seul échec attendu » à un risque de 10⁻³. Faux : 1 000 occasions donnent un dommage attendu ; 3 000 en donnent trois. La réponse de la source le corrige déjà.
- Objection 1 de S-005 : « la borne inférieure dépasse le seuil avec une probabilité proche de 1/2 » quand l'effet vaut le seuil. Faux : elle le dépasse environ une fois sur quarante (calcul du lecteur). La conclusion de l'objection (un test sans puissance) est donc plus forte, pas plus faible.
- Les autres calculs des objections et des réponses ont été refaits. Ils sont conformes : 0,09 ; 0,31 ; 0,71 ; 0,29 ; borne d'environ 1 % à 299 ; 0,037 ; 0,09 ; 0,045 ; 51 ; 128 ; environ 3 dommages pour 24 × 128 occasions ; n_eff ≈ 1 940 ; 5 760 ; 9 600 ; 7 000 et 49 000.

Aucune de ces erreurs ne touche l'énoncé d'une fiche. Aucune ne fonde ni n'empêche une réfutation.

---

# Réfutées — v2 : ajout de la source 2 (course de l'organisme)

Écrit le 3 novembre 2026 vers 20:33 UTC (`date -u`), par le lecteur A, suite (neuf, auteur d'aucune idée ni d'aucun texte). La partie ci-dessus est la v1, recopiée sans changement.

## Résultat : aucun élément réfuté (0 sur 23)

Même règle : réfutée seulement si une source citée contredit l'énoncé central, ou si l'élément se contredit lui-même. La source 2 n'apporte aucune objection croisée ; les vérifications portent sur les citations des éléments eux-mêmes.

## Ce qui a été vérifié
1. **Citations de la pièce du mentor** (`piece-scheurer-v1.md`), confrontées aux sections citées : 2412.04984 (§ 1.1 : § 3.6, 0,96 contre 0,61 ; § 4 ; p. 15) ; 2509.15541 (§ 1.2 : 2,0 % → 20,5 % ; 13,2 % → 24,2 % ; 24,9 % → 18,6 %) ; Apollo Research, 13 mai 2026 (§ 1.3) ; 2603.01608 (§ 2.1 : 0 % sauf 3 % ; 59 % → 3 % ; « jusqu'à 25 % ») ; METR et TastEval (§ 3.1, § 3.2) ; 2506.05296 (§ 3.3 : § 2.3, § 7) ; 2510.09462 (§ 3.4 : figure 2, § 4.4, § 6, formule 1 − (1 − p)^k). Les chiffres cités sont conformes.
2. **Citations de « nos résultats »**, vérifiées sur la pièce servie (`brouillons/ideation-kirchner-q2-v1/piece-nos-resultats-v1.md`) : § 1 (929 essais), § 2 (0 sur 1 000 sur 11 lignes), § 3 (W2 12 sur 12, 11 au premier essai ; 0,560 à n = 16), § 4 (11 sur 12, κ = 0), § 6 (P3 : 2 400 actions, 60 tâches, 1,5227 [1,2464 ; 1,8012], 0,5313 contre 0,5717, 0,4813 contre 0,5356), § 7 (ρ = 0,684 ; Zenodo 10.5281/zenodo.23892810). Conformes.
3. **Tensions relevées, aucune n'est une réfutation** :
   - S-011 (une variante) : la baisse du seuil de dose y est dite « équivaloir » à une hausse de la propension spontanée, et la courbe « permettre d'extrapoler rigoureusement la propension de base ». C'est une affirmation non soutenue, en tension avec la règle d'arrêt de la même variante, qui refuse l'extrapolation. Ce n'est pas une contradiction de l'énoncé central (le seuil conditionnel baisse avec la date). La même variante appelle « hypothèse d'Apollo Research » ce que la pièce § 1.3 rapporte comme une question à l'étude.
   - S-012 : la pièce « nos résultats » § 3 rapporte une promotion en W2 « avec ou sans retour des verdicts ». Cela affaiblit la justification d'un contrôle (le retrait des verdicts), pas l'énoncé central.
   - S-017 : le test de mort conclut à un aveuglement structurel « quelle que soit l'échelle d'échantillonnage » à partir d'une plage finie. C'est une inférence trop large, pas une contradiction ; S-025 traite le même cas comme une censure.
   - S-022 : la pièce § 3.3 rapporte une surveillance « stable sur un large groupe d'attaquants de capacités diverses ». C'est une menace pour la pente, sur une autre mesure, et le test de mort de l'élément prévoit ce cas. Pas une contradiction.
4. **Calculs refaits**, tous conformes : 1 600 ; 4 800 ; 720 ; 11 520 ; 1 − 0,995^16 ≈ 0,077 ; 648 ; 12 960 ; 1 440 ; 21 600 ; 1 280 ; 576 ; 4 608 ; 38 400 = 300 × 2⁷ ; 16 ; 9 600 ; 240 ; 14 ; H = ln(1/2)/ln(1 − R) ; 4 320 ; 5 760 ; 480 ; 2 592 ; 25 920 ; 1 200 ; 2 400 ; 9 600 000 ; 169 ; 500 ; 5 000 ; 720, 144, 864, 8 640 ; 28 800 ; 31 200 ; 1,90 [1,30 ; 2,80] ; 7 440 ; 14 880.

## Défaut de forme relevé (pas une réfutation)
- L'élément de la fiche S-024 est livré comme chaîne JSON mal formée, avec une accolade fermante en trop à la fin. Il a été lu par décodage du premier objet. Son contenu est complet (huit champs) et rien n'est perdu.
