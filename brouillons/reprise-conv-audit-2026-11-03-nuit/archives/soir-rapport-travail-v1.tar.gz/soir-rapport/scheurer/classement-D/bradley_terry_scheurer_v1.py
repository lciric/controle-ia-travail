#!/usr/bin/env python3
"""Forces de Bradley-Terry du classement D (question de Jérémy Scheurer) - v1.

numpy seul, aucun modèle. Usage :
  python3 -I bradley_terry_scheurer_v1.py --epreuves
  python3 -I bradley_terry_scheurer_v1.py PAIRES.jsonl NOTES.json SORTIE.json

Gardes (R5) : toute anomalie d'entrée lève une erreur nommée ; aucun repli silencieux.
Les épreuves (cas sains et artefacts) tournent avant tout calcul ; un échec arrête tout.
Si le graphe des victoires n'est pas fortement connexe, le maximum de vraisemblance
n'existe pas : c'est déclaré dans la sortie, puis une estimation régularisée annoncée
(pseudo-compte ALPHA victoire par sens sur chaque paire comparée) est donnée à part.
Cohérence = part des paires non ordonnées dont les deux ordres désignent la même fiche.
La sortie n'écrase jamais un fichier existant (R12).
"""
import hashlib
import itertools
import json
import os
import platform
import sys

import numpy as np

ALPHA = 0.5
TOL = 1e-12
MAX_ITER = 200000
SEUIL_COHERENCE_BAS = 0.8
SEUIL_PRESQUE_PARFAITE = 0.95
GRAINE_EPREUVES = 20261103


class ErreurEntree(Exception):
    pass


class ErreurConvergence(Exception):
    pass


class MLEInexistant(Exception):
    pass


def paires_canoniques(ids):
    return list(itertools.combinations(sorted(ids), 2))


def ordre_attendu(e, n):
    return np.random.default_rng(np.random.SeedSequence(e)).permutation(n).tolist()


def valider(jugements, ids, e=None):
    ids = sorted(ids)
    if len(set(ids)) != len(ids):
        raise ErreurEntree("identifiants en double dans la liste retenue")
    paires = paires_canoniques(ids)
    n_attendu = 2 * len(paires)
    if len(jugements) != n_attendu:
        raise ErreurEntree(f"{len(jugements)} jugements, {n_attendu} attendus")
    vus_indices, vus_rangs = set(), set()
    orientations = {p: [] for p in paires}
    for r in jugements:
        for cle in ("rang", "indice", "paire", "ordre", "A", "B", "gagnant", "position_gagnant"):
            if cle not in r:
                raise ErreurEntree(f"champ manquant {cle}")
        a_, b_, g = r["A"], r["B"], r["gagnant"]
        if a_ not in ids or b_ not in ids:
            raise ErreurEntree(f"identifiant inconnu au rang {r['rang']}")
        if a_ == b_:
            raise ErreurEntree(f"paire réflexive au rang {r['rang']}")
        if g not in (a_, b_):
            raise ErreurEntree(f"gagnant hors de la paire au rang {r['rang']}")
        if r["position_gagnant"] != ("A" if g == a_ else "B"):
            raise ErreurEntree(f"position du gagnant incohérente au rang {r['rang']}")
        i = r["indice"]
        if not (isinstance(i, int) and 0 <= i < n_attendu):
            raise ErreurEntree(f"indice hors bornes au rang {r['rang']}")
        if i in vus_indices:
            raise ErreurEntree(f"indice {i} en double")
        vus_indices.add(i)
        if r["rang"] in vus_rangs:
            raise ErreurEntree(f"rang {r['rang']} en double")
        vus_rangs.add(r["rang"])
        k = i // 2
        if r["paire"] != k:
            raise ErreurEntree(f"indice {i} : paire {r['paire']}, attendue {k}")
        a, b = paires[k]
        attendu = (a, b) if i % 2 == 0 else (b, a)
        if (a_, b_) != attendu:
            raise ErreurEntree(f"indice {i} : présentation {a_}/{b_}, attendue {attendu[0]}/{attendu[1]}")
        if r["ordre"] != ("canonique" if i % 2 == 0 else "inverse"):
            raise ErreurEntree(f"indice {i} : ordre mal étiqueté")
        orientations[(a, b)].append((a_, b_))
    if vus_rangs != set(range(1, n_attendu + 1)):
        raise ErreurEntree("rangs non contigus de 1 à n")
    for p, o in orientations.items():
        if sorted(o) != sorted([p, (p[1], p[0])]):
            raise ErreurEntree(f"paire {p} sans ses deux ordres")
    if e is not None:
        par_rang = [r["indice"] for r in sorted(jugements, key=lambda r: r["rang"])]
        if par_rang != ordre_attendu(e, n_attendu):
            raise ErreurEntree("ordre de présentation différent du tirage SeedSequence")
    return ids, paires


def matrices(jugements, ids):
    pos = {x: n for n, x in enumerate(ids)}
    w = np.zeros((len(ids), len(ids)))
    for r in jugements:
        g = r["gagnant"]
        perdant = r["B"] if g == r["A"] else r["A"]
        w[pos[g], pos[perdant]] += 1
    return w, w + w.T


def fortement_connexe(w):
    n = w.shape[0]
    adj = w > 0

    def tout_atteint(m):
        vus, pile = {0}, [0]
        while pile:
            u = pile.pop()
            for v in np.nonzero(m[u])[0]:
                v = int(v)
                if v not in vus:
                    vus.add(v)
                    pile.append(v)
        return len(vus) == n

    return tout_atteint(adj) and tout_atteint(adj.T)


def ajuster_bt(w, n, alpha=0.0, tol=TOL, max_iter=MAX_ITER):
    """Algorithme MM (Hunter 2004). alpha = 0 : maximum de vraisemblance strict."""
    if np.any(np.diag(n) != 0):
        raise ErreurEntree("diagonale non nulle")
    if not np.array_equal(n, n.T):
        raise ErreurEntree("matrice des comparaisons non symétrique")
    if alpha == 0 and not fortement_connexe(w):
        raise MLEInexistant("graphe des victoires non fortement connexe : le maximum de vraisemblance n'existe pas")
    wa = w + alpha * (n > 0)
    na = wa + wa.T
    victoires = wa.sum(axis=1)
    if np.any(victoires <= 0):
        raise MLEInexistant("un élément sans aucune victoire")
    k = w.shape[0]
    p = np.ones(k) / k
    for it in range(1, max_iter + 1):
        denom = (na / (p[:, None] + p[None, :])).sum(axis=1)
        p_new = victoires / denom
        p_new = p_new / p_new.sum()
        if np.max(np.abs(np.log(p_new) - np.log(p))) < tol:
            return p_new, it
        p = p_new
    raise ErreurConvergence(f"pas de convergence en {max_iter} itérations")


def coherence(jugements, paires):
    par_paire = {}
    for r in jugements:
        par_paire.setdefault(tuple(sorted((r["A"], r["B"]))), []).append(r["gagnant"])
    discordantes = [list(p) for p in paires if len(set(par_paire[p])) != 1]
    return (len(paires) - len(discordantes)) / len(paires), discordantes


def verifier_sortie_absente(chemin):
    if os.path.exists(chemin):
        raise ErreurEntree(f"sortie déjà présente, jamais écrasée : {chemin}")


def sha256(chemin):
    with open(chemin, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


# ---------------------------------------------------------------- épreuves (R5)

def _jugements_synthetiques(ids, e, rang_force, discordantes=()):
    """Jugements valides : le mieux classé selon rang_force gagne, sauf dans le second
    ordre des paires listées dans discordantes (qui deviennent discordantes)."""
    ids = sorted(ids)
    paires = paires_canoniques(ids)
    perm = ordre_attendu(e, 2 * len(paires))
    sortie = []
    for rang, i in enumerate(perm, start=1):
        k = i // 2
        a, b = paires[k]
        A, B = (a, b) if i % 2 == 0 else (b, a)
        g = A if rang_force[A] < rang_force[B] else B
        if (a, b) in discordantes and i % 2 == 1:
            g = B if g == A else A
        sortie.append({"rang": rang, "indice": i, "paire": k, "ordre": "canonique" if i % 2 == 0 else "inverse",
                       "A": A, "B": B, "gagnant": g, "position_gagnant": "A" if g == A else "B"})
    return sortie


def _doit_lever(exception, fonction):
    try:
        fonction()
    except exception:
        return True
    return False


def epreuves():
    res = []
    ids = [f"T-{n}" for n in range(8)]
    e_t = 123456789
    rf = {x: n for n, x in enumerate(sorted(ids))}

    # cas sain 1 : cycle à trois, forces égales attendues
    w = np.array([[0, 1, 0], [0, 0, 1], [1, 0, 0]], dtype=float)
    p, _ = ajuster_bt(w, w + w.T)
    res.append(("sain : cycle à trois, forces égales", bool(np.ptp(np.log(p)) < 1e-9)))

    # cas sain 2 : récupération de forces connues (400 parties par paire)
    theta = np.linspace(1.5, -1.5, 8)
    rng = np.random.default_rng(np.random.SeedSequence(GRAINE_EPREUVES))
    w = np.zeros((8, 8))
    for i, j in itertools.combinations(range(8), 2):
        v = rng.binomial(400, 1 / (1 + np.exp(-(theta[i] - theta[j]))))
        w[i, j], w[j, i] = v, 400 - v
    p, _ = ajuster_bt(w, w + w.T)
    lp = np.log(p) - np.log(p).mean()
    ok = bool(np.max(np.abs(lp - (theta - theta.mean()))) < 0.25 and list(np.argsort(-lp)) == list(range(8)))
    res.append(("sain : forces connues retrouvées (écart < 0,25, ordre exact)", ok))

    # cas sain 3 : chaîne complète sur 56 jugements valides, trois paires discordantes
    # le retournement (T-0, T-7) ferme un cycle : graphe fortement connexe
    disc = {("T-0", "T-7"), ("T-2", "T-5"), ("T-3", "T-4")}
    j = _jugements_synthetiques(ids, e_t, rf, disc)
    i2, pa = valider(j, ids, e_t)
    c, d = coherence(j, pa)
    wm, nm = matrices(j, i2)
    p, _ = ajuster_bt(wm, nm)
    res.append(("sain : validation, cohérence 25/28, maximum de vraisemblance existant",
                bool(abs(c - 25 / 28) < 1e-12 and len(d) == 3 and wm.sum() == 56 and fortement_connexe(wm))))

    base = _jugements_synthetiques(ids, e_t, rf)

    def copie():
        return [dict(r) for r in base]

    def art_manquant():
        valider(copie()[:-1], ids, e_t)

    def art_double():
        x = copie()
        x[-1] = dict(x[0], rang=56)
        valider(x, ids, e_t)

    def art_inconnu():
        x = copie()
        x[3]["A"] = "T-99"
        valider(x, ids, e_t)

    def art_gagnant_hors():
        x = copie()
        x[4]["gagnant"] = next(z for z in sorted(ids) if z not in (x[4]["A"], x[4]["B"]))
        valider(x, ids, e_t)

    def art_reflexive():
        x = copie()
        x[5]["B"] = x[5]["A"]
        valider(x, ids, e_t)

    def art_meme_ordre():
        x = copie()
        r = x[6]
        r["A"], r["B"] = r["B"], r["A"]
        r["position_gagnant"] = "A" if r["gagnant"] == r["A"] else "B"
        valider(x, ids, e_t)

    def art_position():
        x = copie()
        x[7]["position_gagnant"] = "B" if x[7]["position_gagnant"] == "A" else "A"
        valider(x, ids, e_t)

    def art_ordre_presentation():
        x = copie()
        x[0]["rang"], x[1]["rang"] = x[1]["rang"], x[0]["rang"]
        valider(x, ids, e_t)

    for nom, f in [("artefact : jugement manquant", art_manquant), ("artefact : jugement en double", art_double),
                   ("artefact : identifiant inconnu", art_inconnu), ("artefact : gagnant hors de la paire", art_gagnant_hors),
                   ("artefact : paire réflexive", art_reflexive), ("artefact : deux fois le même ordre", art_meme_ordre),
                   ("artefact : position du gagnant fausse", art_position),
                   ("artefact : ordre de présentation hors tirage", art_ordre_presentation)]:
        res.append((nom + " -> ErreurEntree", _doit_lever(ErreurEntree, f)))

    # artefact : tournoi parfait (transitif) -> maximum de vraisemblance inexistant, déclaré
    wp, np_ = matrices(base, sorted(ids))
    leve = _doit_lever(MLEInexistant, lambda: ajuster_bt(wp, np_))
    pr, _ = ajuster_bt(wp, np_, alpha=ALPHA)
    ordre_ok = list(np.argsort(-pr)) == list(np.argsort(-wp.sum(axis=1), kind="stable"))
    res.append(("artefact : tournoi parfait -> MLEInexistant levé, régularisé fini et ordonné comme les victoires",
                bool(leve and np.all(np.isfinite(pr)) and ordre_ok)))

    # artefact : non-convergence
    w = np.array([[0, 3, 1], [1, 0, 2], [2, 1, 0]], dtype=float)
    res.append(("artefact : itérations épuisées -> ErreurConvergence",
                _doit_lever(ErreurConvergence, lambda: ajuster_bt(w, w + w.T, max_iter=1))))

    # artefact : sortie existante jamais écrasée
    res.append(("artefact : sortie existante -> ErreurEntree", _doit_lever(ErreurEntree, lambda: verifier_sortie_absente(__file__))))
    return res


# ---------------------------------------------------------------- exécution

def principal(chemin_paires, chemin_notes, chemin_sortie):
    verifier_sortie_absente(chemin_sortie)
    res = epreuves()
    if not all(ok for _, ok in res):
        raise SystemExit("épreuves en échec : " + json.dumps([n for n, ok in res if not ok], ensure_ascii=False))
    with open(chemin_notes, encoding="utf-8") as f:
        notes = json.load(f)
    ids = notes["huit_retenues_ordre_canonique_trie"]
    graine = notes["departage_au_seuil"]["graine"]
    e = int(graine["sha256_fiches_16_hex"], 16)
    if e != graine["e"]:
        raise ErreurEntree("graine incohérente dans les notes")
    jugements = []
    with open(chemin_paires, encoding="utf-8") as f:
        for n, ligne in enumerate(f, start=1):
            if not ligne.strip():
                raise ErreurEntree(f"ligne vide {n}")
            try:
                jugements.append(json.loads(ligne))
            except json.JSONDecodeError as err:
                raise ErreurEntree(f"ligne {n} illisible : {err}")
    ids, paires = valider(jugements, ids, e)
    w, n = matrices(jugements, ids)
    c, disc = coherence(jugements, paires)
    part_a = sum(r["position_gagnant"] == "A" for r in jugements) / len(jugements)
    connexe = fortement_connexe(w)
    mle = {"existe": connexe}
    if connexe:
        p_mle, it = ajuster_bt(w, n)
        mle.update({"forces": dict(zip(ids, p_mle.round(6).tolist())), "iterations": it})
    else:
        try:
            ajuster_bt(w, n)
            raise ErreurEntree("incohérence : graphe non connexe mais ajustement strict accepté")
        except MLEInexistant as err:
            mle["raison"] = str(err)
    p_reg, it_reg = ajuster_bt(w, n, alpha=ALPHA)
    note = {x["id"]: x for x in notes["notes"]}
    log_reg = np.log(p_reg)
    cle = {x: (-round(float(log_reg[k]), 9), -note[x]["originalite"], -note[x]["somme"], x) for k, x in enumerate(ids)}
    ordre_final = sorted(ids, key=lambda x: cle[x])
    victoires = dict(zip(ids, w.sum(axis=1).astype(int).tolist()))
    ordre_victoires = sorted(ids, key=lambda x: (-victoires[x], -note[x]["originalite"], -note[x]["somme"], x))
    egalites = [[a, b] for a, b in itertools.combinations(ids, 2) if cle[a][0] == cle[b][0]]
    reserves = []
    if c < SEUIL_COHERENCE_BAS:
        reserves.append(f"cohérence {c:.3f} sous {SEUIL_COHERENCE_BAS}")
    if c >= SEUIL_PRESQUE_PARFAITE:
        reserves.append(f"cohérence {c:.3f} presque parfaite d'un juge unique (seuil gelé {SEUIL_PRESQUE_PARFAITE}) : "
                        "les deux ordres ne sont pas indépendants (même juge, mémoire du premier ordre) ; "
                        "elle ne mesure pas la robustesse du classement")
    if not connexe:
        reserves.append("maximum de vraisemblance inexistant (graphe des victoires non fortement connexe) ; "
                        f"forces données par l'estimation régularisée annoncée (alpha = {ALPHA})")
    if ordre_final != ordre_victoires:
        reserves.append("ordre régularisé différent de l'ordre par victoires")
    sortie = {
        "script": {"chemin": os.path.abspath(__file__), "sha256": sha256(__file__)},
        "versions": {"python": platform.python_version(), "numpy": np.__version__},
        "entrees": {"paires": {"chemin": os.path.abspath(chemin_paires), "sha256": sha256(chemin_paires)},
                    "notes": {"chemin": os.path.abspath(chemin_notes), "sha256": sha256(chemin_notes)},
                    "graine_e": e},
        "epreuves": [{"epreuve": nom, "reussie": ok} for nom, ok in res],
        "validation": "56 jugements valides, deux ordres par paire, ordre de présentation conforme au tirage",
        "identifiants": ids,
        "matrice_victoires_ligne_bat_colonne": w.astype(int).tolist(),
        "victoires": victoires,
        "coherence": {"valeur": round(c, 6), "concordantes": len(paires) - len(disc), "paires": len(paires),
                      "discordantes": disc},
        "part_gagnee_par_la_position_A": round(part_a, 6),
        "maximum_de_vraisemblance": mle,
        "estimation_regularisee": {"alpha": ALPHA, "iterations": it_reg,
                                   "forces_somme_1": dict(zip(ids, p_reg.round(6).tolist())),
                                   "log_forces_centrees": dict(zip(ids, (log_reg - log_reg.mean()).round(6).tolist()))},
        "departage_des_forces": "force régularisée (log arrondi à 1e-9), puis note d'originalité, puis somme, puis identifiant",
        "egalites_de_force": egalites,
        "ordre_final": ordre_final,
        "ordre_par_victoires": ordre_victoires,
        "reserves": reserves,
    }
    verifier_sortie_absente(chemin_sortie)
    with open(chemin_sortie, "x", encoding="utf-8") as f:
        json.dump(sortie, f, ensure_ascii=False, indent=2)
        f.write("\n")
    return sortie


if __name__ == "__main__":
    if sys.argv[1:] == ["--epreuves"]:
        r = epreuves()
        for nom, ok in r:
            print(("RÉUSSIE " if ok else "ÉCHEC   ") + nom)
        sys.exit(0 if all(ok for _, ok in r) else 1)
    if len(sys.argv) != 4:
        raise SystemExit(__doc__)
    s = principal(*sys.argv[1:])
    print(json.dumps({k: s[k] for k in ("ordre_final", "victoires", "coherence", "part_gagnee_par_la_position_A",
                                         "maximum_de_vraisemblance", "reserves")}, ensure_ascii=False, indent=1))
