#!/usr/bin/env python3
"""Forces de Bradley-Terry, cohérence des deux ordres et gardes — classement D, Ibrahim Q1, v1.

numpy seul, aucun modèle. Usage :
  python3 -I bradley_terry_ibrahim_q1_v1.py --auto-test        # gardes sur cas sain et artefacts
  python3 -I bradley_terry_ibrahim_q1_v1.py --sortie FICHIER   # auto-test puis calcul réel
Toute garde qui échoue lève GardeEchec : aucun repli silencieux. La seule régularisation
(pseudo-comptes ALPHA par côté et par paire) est déclarée dans la sortie, avec l'existence
ou non de l'estimateur du maximum de vraisemblance (condition de Ford).
"""
import argparse
import hashlib
import itertools
import json
import os
import sys

import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
FICHES = "/home/claude/scratch/soir-rapport/ibrahim-q1-ensemble/prep-v1/fiches-servies-v1.json"
SHA_FICHES = "b77b8c5fa07069de944171bdd07ace2c509a117ebd3d83f1c199685c3c94a9e1"
PAIRES = os.path.join(ICI, "paires-v1.jsonl")
NOTES = os.path.join(ICI, "notes-v1.json")
ALPHA = 0.5            # pseudo-victoire ajoutée à chaque côté de chaque paire comparée (déclarée)
SEUIL_COHERENCE = 0.8  # consigne
SEUIL_PRESQUE_PARFAITE = 0.9  # choisi par le classeur après les jugements, non gelé (déclaré)
N_BOOT = 2000


class GardeEchec(Exception):
    pass


def sha256(chemin):
    with open(chemin, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def entier_e(sha_hex):
    return int(sha_hex[:16], 16)


def plan_presentation(ids, e):
    """Indice k = 2p + o ; paires p en ordre lexicographique des identifiants triés ;
    o = 0 : (i, j) ; o = 1 : (j, i). Rang r présente l'indice perm[r]."""
    ids = sorted(ids)
    paires = list(itertools.combinations(range(len(ids)), 2))
    n = 2 * len(paires)
    perm = np.random.default_rng(np.random.SeedSequence(e)).permutation(n)
    plan = []
    for r, k in enumerate(perm):
        p, o = divmod(int(k), 2)
        i, j = paires[p]
        a, b = (ids[i], ids[j]) if o == 0 else (ids[j], ids[i])
        plan.append((r, int(k), a, b))
    return plan


def valider(jugements, ids, e):
    """Gardes sur le fichier des jugements ; lève GardeEchec au premier défaut."""
    ids = sorted(ids)
    if len(set(ids)) != len(ids) or len(ids) < 2:
        raise GardeEchec("identifiants à classer invalides")
    plan = plan_presentation(ids, e)
    if len(jugements) != len(plan):
        raise GardeEchec("nombre de jugements %d, attendu %d" % (len(jugements), len(plan)))
    rangs = [j.get("rang") for j in jugements]
    if sorted(rangs) != list(range(len(plan))):
        raise GardeEchec("rangs manquants ou en double")
    vus = set()
    for j in jugements:
        for c in ("rang", "indice", "premiere", "seconde", "gagnante"):
            if c not in j:
                raise GardeEchec("champ %s absent au rang %s" % (c, j.get("rang")))
        r, k, a, b = plan[j["rang"]]
        if j["indice"] != k or j["premiere"] != a or j["seconde"] != b:
            raise GardeEchec("rang %d ne suit pas le plan tiré (attendu %d %s/%s)" % (j["rang"], k, a, b))
        if j["premiere"] not in ids or j["seconde"] not in ids:
            raise GardeEchec("identifiant inconnu au rang %d" % j["rang"])
        if j["gagnante"] not in (j["premiere"], j["seconde"]):
            raise GardeEchec("gagnante hors de la paire au rang %d" % j["rang"])
        cle = (j["premiere"], j["seconde"])
        if cle in vus:
            raise GardeEchec("présentation en double %s" % (cle,))
        vus.add(cle)
    for a, b in itertools.combinations(ids, 2):
        if (a, b) not in vus or (b, a) not in vus:
            raise GardeEchec("paire %s/%s absente dans un ordre" % (a, b))
    return True


def comptes(jugements, ids):
    ids = sorted(ids)
    pos = {x: i for i, x in enumerate(ids)}
    n = len(ids)
    W = np.zeros((n, n))  # W[i, j] = victoires de i sur j
    for j in jugements:
        g = j["gagnante"]
        p = j["seconde"] if g == j["premiere"] else j["premiere"]
        W[pos[g], pos[p]] += 1
    return W


def connexe(N):
    """Graphe non orienté des comparaisons connexe ?"""
    n = N.shape[0]
    vu = {0}
    pile = [0]
    while pile:
        i = pile.pop()
        for j in range(n):
            if N[i, j] > 0 and j not in vu:
                vu.add(j)
                pile.append(j)
    return len(vu) == n


def ford(W):
    """Existence de l'estimateur du maximum de vraisemblance : graphe orienté
    des victoires (i -> j si i a battu j) fortement connexe."""
    n = W.shape[0]
    A = (W > 0)
    R = A.copy() | np.eye(n, dtype=bool)
    for m in range(n):
        R = R | (R[:, [m]] & R[[m], :])
    return bool(R.all())


def bradley_terry(W, alpha=0.0, tol=1e-12, max_iter=200000):
    """Algorithme MM (Hunter 2004). alpha : pseudo-victoires ajoutées à chaque côté
    de chaque paire déjà comparée. Lève GardeEchec si non identifiable ou non convergent."""
    W = np.asarray(W, dtype=float)
    if W.ndim != 2 or W.shape[0] != W.shape[1]:
        raise GardeEchec("matrice des victoires non carrée")
    if not np.all(np.isfinite(W)) or (W < 0).any():
        raise GardeEchec("matrice des victoires invalide")
    N0 = W + W.T
    if not connexe(N0):
        raise GardeEchec("graphe des comparaisons non connexe : forces non identifiables")
    Wr = W + alpha * (N0 > 0)
    if alpha == 0.0 and not ford(W):
        raise GardeEchec("estimateur du maximum de vraisemblance inexistant (condition de Ford)")
    N = Wr + Wr.T
    n = W.shape[0]
    p = np.ones(n)
    vict = Wr.sum(axis=1)
    np.fill_diagonal(N, 0.0)
    for it in range(max_iter):
        den = (N / (p[:, None] + p[None, :])).sum(axis=1)
        nouv = vict / den
        nouv = nouv / np.exp(np.mean(np.log(nouv)))
        if not np.all(np.isfinite(nouv)) or (nouv <= 0).any():
            raise GardeEchec("forces non finies ou nulles")
        if np.max(np.abs(np.log(nouv) - np.log(p))) < tol:
            return nouv, it + 1
        p = nouv
    raise GardeEchec("pas de convergence en %d itérations" % max_iter)


def coherence(jugements, ids):
    par = {}
    for j in jugements:
        par.setdefault(tuple(sorted((j["premiere"], j["seconde"]))), []).append(j["gagnante"])
    conc = [k for k, v in par.items() if len(v) == 2 and v[0] == v[1]]
    disc = [k for k, v in par.items() if len(v) == 2 and v[0] != v[1]]
    if len(conc) + len(disc) != len(par):
        raise GardeEchec("paire sans ses deux ordres")
    return len(conc) / len(par), sorted(conc), sorted(disc)


def spearman(x, y):
    rx = np.argsort(np.argsort(x))
    ry = np.argsort(np.argsort(y))
    return float(np.corrcoef(rx, ry)[0, 1])


# ---------------------------------------------------------------- auto-test
def _jugements_synthetiques(ids, e, gagne):
    out = []
    for r, k, a, b in plan_presentation(ids, e):
        out.append({"rang": r, "indice": k, "premiere": a, "seconde": b, "gagnante": gagne(a, b)})
    return out


def auto_test():
    rapport = []
    ids = ["X%d" % i for i in range(8)]
    e = 12345
    # 1. cas sain : forces connues, beaucoup de comparaisons, estimateur retrouvé
    rng = np.random.default_rng(np.random.SeedSequence(e).spawn(3)[2])
    vrai = np.exp(np.linspace(-1.5, 1.5, 8))
    W = np.zeros((8, 8))
    for i, j in itertools.combinations(range(8), 2):
        m = 200
        wi = rng.binomial(m, vrai[i] / (vrai[i] + vrai[j]))
        W[i, j] += wi
        W[j, i] += m - wi
    if not ford(W):
        raise GardeEchec("auto-test : cas sain sans estimateur")
    est, _ = bradley_terry(W)
    rho = spearman(est, vrai)
    err = float(np.max(np.abs(np.log(est) - (np.log(vrai) - np.mean(np.log(vrai))))))
    if rho < 0.95 or err > 0.3:
        raise GardeEchec("auto-test : cas sain mal retrouvé (rho %.3f, erreur %.3f)" % (rho, err))
    rapport.append({"test": "cas sain simulé", "ok": True, "spearman": rho, "erreur_log_max": err})
    # 2. cas sain au format réel : 56 jugements cohérents, validation acceptée
    ordre = {x: i for i, x in enumerate(ids)}
    sain = _jugements_synthetiques(ids, e, lambda a, b: a if ordre[a] > ordre[b] else b)
    valider(sain, ids, e)
    c, _, _ = coherence(sain, ids)
    if c != 1.0:
        raise GardeEchec("auto-test : cohérence du juge parfait != 1")
    Ws = comptes(sain, ids)
    if ford(Ws):
        raise GardeEchec("auto-test : ordre total parfait déclaré estimable")
    p, _ = bradley_terry(Ws, alpha=ALPHA)
    if spearman(p, np.arange(8)) < 0.999:
        raise GardeEchec("auto-test : ordre total mal restitué sous pseudo-comptes")
    rapport.append({"test": "56 jugements cohérents au format réel", "ok": True,
                    "note": "validation acceptée ; séparation parfaite détectée (pas d'estimateur sans pseudo-comptes)"})
    # 3. artefacts : chacun doit lever GardeEchec
    def doit_echouer(nom, f):
        try:
            f()
        except GardeEchec as ex:
            rapport.append({"test": nom, "ok": True, "refus": str(ex)})
            return
        raise GardeEchec("auto-test : artefact accepté : " + nom)

    doit_echouer("jugement manquant", lambda: valider(sain[:-1], ids, e))
    dup = [dict(x) for x in sain]
    dup[5] = dict(dup[4])
    doit_echouer("rang en double", lambda: valider(dup, ids, e))
    inv = [dict(x) for x in sain]
    inv[0]["premiere"], inv[0]["seconde"] = inv[0]["seconde"], inv[0]["premiere"]
    doit_echouer("ordre de présentation hors plan", lambda: valider(inv, ids, e))
    hors = [dict(x) for x in sain]
    hors[3]["gagnante"] = "X99"
    doit_echouer("gagnante hors paire", lambda: valider(hors, ids, e))
    doit_echouer("mauvaise graine", lambda: valider(sain, ids, e + 1))
    doit_echouer("identifiants différents", lambda: valider(sain, ids[:-1] + ["Y7"], e))
    Wd = np.zeros((4, 4)); Wd[0, 1] = 2; Wd[1, 0] = 1; Wd[2, 3] = 2; Wd[3, 2] = 1
    doit_echouer("graphe non connexe", lambda: bradley_terry(Wd, alpha=ALPHA))
    doit_echouer("séparation parfaite sans pseudo-comptes", lambda: bradley_terry(Ws, alpha=0.0))
    Wn = Ws.copy(); Wn[0, 1] = np.nan
    doit_echouer("matrice non finie", lambda: bradley_terry(Wn, alpha=ALPHA))
    return rapport


# ---------------------------------------------------------------- calcul réel
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--auto-test", action="store_true")
    ap.add_argument("--sortie", default=None)
    args = ap.parse_args()
    rapport_tests = auto_test()
    if args.auto_test and not args.sortie:
        print(json.dumps(rapport_tests, ensure_ascii=False, indent=1))
        return 0
    sha = sha256(FICHES)
    if sha != SHA_FICHES:
        raise GardeEchec("empreinte des fiches inattendue : " + sha)
    e = entier_e(sha)
    with open(NOTES, encoding="utf-8") as f:
        notes = json.load(f)
    ids = sorted(notes["selection_huit"]["huit"])
    if len(ids) != 8:
        raise GardeEchec("la sélection ne compte pas huit fiches")
    with open(PAIRES, encoding="utf-8") as f:
        jugements = [json.loads(l) for l in f if l.strip()]
    valider(jugements, ids, e)
    W = comptes(jugements, ids)
    c, conc, disc = coherence(jugements, ids)
    emv_existe = ford(W)
    p_reg, it_reg = bradley_terry(W, alpha=ALPHA)
    p_emv = None
    if emv_existe:
        p_emv, _ = bradley_terry(W, alpha=0.0)
    premiere_gagne = sum(1 for j in jugements if j["gagnante"] == j["premiere"])
    # rééchantillonnage des 28 paires (les deux ordres ensemble), flux distinct
    par = {}
    for j in jugements:
        par.setdefault(tuple(sorted((j["premiere"], j["seconde"]))), []).append(j)
    cles = sorted(par)
    rng = np.random.default_rng(np.random.SeedSequence(e).spawn(2)[1])
    pos = {x: i for i, x in enumerate(ids)}
    lignes = []
    non_identifiables = 0
    for bt in range(N_BOOT):
        Wb = np.zeros_like(W)
        for idx in rng.integers(0, len(cles), size=len(cles)):
            for j in par[cles[idx]]:
                g = j["gagnante"]
                q = j["seconde"] if g == j["premiere"] else j["premiere"]
                Wb[pos[g], pos[q]] += 1
        if not connexe(Wb + Wb.T):
            non_identifiables += 1  # fiche absente du rééchantillon : compté et déclaré, exclu
            continue
        pb, _ = bradley_terry(Wb, alpha=ALPHA)
        lignes.append(np.argsort(np.argsort(-pb)) + 1)
    if len(lignes) < 0.95 * N_BOOT:
        raise GardeEchec("trop de rééchantillons non identifiables : %d" % non_identifiables)
    rangs_boot = np.array(lignes)
    ordre = sorted(ids, key=lambda x: -p_reg[pos[x]])
    reserves = []
    if c < SEUIL_COHERENCE:
        reserves.append("cohérence %.3f sous le seuil de 0,8" % c)
    if c >= SEUIL_PRESQUE_PARFAITE:
        reserves.append("cohérence %.3f presque parfaite d'un juge unique (seuil %.2f choisi après les jugements)" % (c, SEUIL_PRESQUE_PARFAITE))
    if not emv_existe:
        reserves.append("estimateur du maximum de vraisemblance inexistant (séparation) : forces sous pseudo-comptes ALPHA=%.2f, déclarées" % ALPHA)
    sortie = {
        "version": "v1",
        "script": {"chemin": os.path.abspath(__file__), "sha256": sha256(os.path.abspath(__file__))},
        "numpy": np.__version__,
        "entrees": {"fiches": {"chemin": FICHES, "sha256": sha},
                    "paires": {"chemin": PAIRES, "sha256": sha256(PAIRES)},
                    "notes": {"chemin": NOTES, "sha256": sha256(NOTES)}},
        "graine": {"e": e, "hex16": sha[:16], "plan": "numpy.random.default_rng(numpy.random.SeedSequence(e)).permutation(56)",
                   "reechantillonnage": "SeedSequence(e).spawn(2)[1]", "plan_verifie": True},
        "auto_test": rapport_tests,
        "ids": ids,
        "victoires": {x: int(W[pos[x]].sum()) for x in ids},
        "matrice_victoires": {x: {y: int(W[pos[x], pos[y]]) for y in ids if y != x} for x in ids},
        "coherence": {"valeur": c, "concordantes": len(conc), "paires": len(conc) + len(disc),
                      "discordantes": [list(k) for k in disc], "seuil": SEUIL_COHERENCE},
        "position": {"premiere_gagne": premiere_gagne, "sur": len(jugements), "part": premiere_gagne / len(jugements)},
        "emv_existe": emv_existe,
        "alpha_pseudo_comptes": ALPHA,
        "iterations": it_reg,
        "forces_regularisees": {x: float(p_reg[pos[x]]) for x in ids},
        "log_forces_regularisees": {x: float(np.log(p_reg[pos[x]])) for x in ids},
        "forces_emv": ({x: float(p_emv[pos[x]]) for x in ids} if p_emv is not None else None),
        "ordre_final": ordre,
        "reechantillonnage": {"n": N_BOOT, "non_identifiables_exclus": non_identifiables,
                              "unite": "les 28 paires, chacune avec ses deux ordres",
                              "rang_median": {x: float(np.median(rangs_boot[:, pos[x]])) for x in ids},
                              "part_rang_1": {x: float(np.mean(rangs_boot[:, pos[x]] == 1)) for x in ids},
                              "intervalle_rang_95": {x: [int(np.percentile(rangs_boot[:, pos[x]], 2.5)),
                                                         int(np.percentile(rangs_boot[:, pos[x]], 97.5))] for x in ids}},
        "reserves": reserves,
    }
    if args.sortie:
        if os.path.exists(args.sortie):
            raise GardeEchec("sortie existante, on n'écrase pas : " + args.sortie)
        with open(args.sortie, "w", encoding="utf-8") as f:
            json.dump(sortie, f, ensure_ascii=False, indent=1)
    print(json.dumps({k: sortie[k] for k in ("ordre_final", "victoires", "coherence", "position", "emv_existe", "reserves")},
                     ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except GardeEchec as ex:
        print("GARDE : " + str(ex), file=sys.stderr)
        sys.exit(2)
