# Groupement aveugle des fiches « tendance d'échelle » — v1

Entrée : `/home/claude/scratch/soir-rapport/scheurer-ensemble/piste/fiches-a-grouper-v1.json` (sha256 `fba695cbc00a339c6fd18357a1bf95d2c8f490a09018efa3319d9b7910d8f3fc`, vérifiée), 33 fiches (SC-01 à SC-33).
Groupeur neuf, aveugle au classement ; aucun autre fichier lu.

## 1. Définitions des groupes

Écrites le 2026-11-03 à 20:36:33 UTC (heure de `date -u`), après lecture complète des fiches et **avant toute affectation**. Elles ne sont plus modifiées ensuite.

Règle de priorité, fixée avec les définitions : une fiche relève d'abord du groupe E si sa grandeur est définie au niveau d'un collectif ; sinon du groupe F si sa grandeur est le déplacement d'un verdict provoqué par un contenu adressé à l'évaluateur ; sinon du groupe A, B, C ou D selon la grandeur tracée.

### A. Horizon de capacité d'attaque
- **Définition** : la grandeur tracée est la difficulté de l'épreuve (durée humaine, difficulté humaine, nombre d'occasions) à laquelle le modèle évalué atteint, une fois sur deux, un objectif interdit ou de sabotage sous protocole figé. Elle aurait une tendance mesurable parce que c'est une capacité accessible, ajustée comme l'horizon du METR, qui suit la progression générale des capacités.
- **Critère** : la grandeur est une difficulté ou un coût d'épreuve au seuil de 50 % de réussite du modèle évalué contre un contrôle figé, sans dose d'incitation graduée.

### B. Seuil d'incitation et propension conditionnelle
- **Définition** : la grandeur tracée est un taux ou un seuil de comportement désaligné du modèle évalué (violation, sous-performance stratégique, actions couvertes, conscience d'évaluation), rendu continu par une dose d'incitation graduée ou par le calcul d'entraînement. Elle aurait une tendance mesurable parce qu'une dose fait quitter le plancher des taux spontanés et donne un seuil continu, distinct de la capacité.
- **Critère** : la grandeur porte sur la propension (taux, dose ED50, risque conjoint à doses fixées) du modèle évalué, moniteur éventuel tenu fixe.

### C. Horizon de détection du moniteur
- **Définition** : la grandeur tracée est la taille maximale de l'épreuve (longueur de trajectoire ou d'artefact, durée humaine de l'attaque ou de la trajectoire, nombre d'occasions) que le moniteur ou le contrôleur tient à critère de détection fixé, ou à laquelle sa détection tombe à 50 %, contre des attaques figées ou plantées. Elle aurait une tendance mesurable parce que les positifs existent par construction et que seul le moniteur (ou l'écart attaquant–moniteur) change.
- **Critère** : la grandeur est une taille d'épreuve tenue par le moniteur ou le contrôleur, et c'est le moniteur, ou l'écart attaquant–moniteur, qui varie sur l'axe.

### D. Coût défensif à risque fixé
- **Définition** : la grandeur tracée est la ressource minimale du défenseur (calcul, opérations d'inférence, minutes humaines d'audit ou de revue, temps d'annotation, nombre d'exemples étiquetés) pour atteindre des critères fixés de détection et de fausses alertes. Elle aurait une tendance mesurable parce qu'un coût reste continu même quand une propension vaut zéro, et baisse si les moniteurs progressent ou monte si les attaquants progressent.
- **Critère** : la grandeur s'exprime en ressource consommée par le défenseur à critères de détection fixés, quel que soit le côté (moniteur, attaquant, les deux) qui varie.

### E. Défaillance de composition multi-agents
- **Définition** : la grandeur tracée est un seuil de défaillance d'un collectif d'agents (charge d'interdépendance, budget collectif, dose collective) ou un rapport collectif sur centralisé ou individuel. Elle aurait une tendance mesurable parce que la charge graduée évite l'événement spontané rare et que la comparaison à un agent centralisé isole ce qui est propre à la composition.
- **Critère** : la grandeur est définie au niveau d'une équipe ou d'un essaim, ou comme rapport collectif / centralisé ou individuel (prioritaire sur A à D).

### F. Manipulabilité de l'évaluateur ou du moniteur
- **Définition** : la grandeur tracée est le déplacement du verdict d'un évaluateur ou d'un moniteur provoqué par un contenu qui lui est adressé (pression de l'utilisateur, note impérative, réputation de l'auteur, injection d'instructions). Elle aurait une tendance mesurable si ce déplacement dépend du suivi d'instruction ou de la hiérarchie d'instructions, qui évoluent avec la capacité et la date.
- **Critère** : la grandeur est un gain de déférence, un point fixe sous pression ou une probabilité de réussite d'injection sur l'évaluateur (prioritaire sur A à D).

## 2. Affectations

Écrites après les définitions (terminées à 20:38:02 UTC). Une fiche, un groupe ; « second choix » seulement si la fiche relève presque autant d'un autre groupe.

| Fiche | Groupe | Raison | Second choix |
|---|---|---|---|
| SC-01 | A | Nombre d'occasions nécessaire pour que le modèle évalué réussisse 50 % des sabotages contre un moniteur figé : coût d'épreuve côté attaquant. | — |
| SC-02 | F | Gain de déférence d'un moniteur Qwen2.5 à une note impérative contre une assertion déclarative. | — |
| SC-03 | C | Longueur de trajectoire (en transitions d'état) que le moniteur tient à 80 % de détection et 5 % de fausses alertes. | — |
| SC-04 | C | Temps humain de détection des attaques auquel la détection du moniteur tombe à 50 %, moniteur variant. | — |
| SC-05 | F | Point fixe du verdict de Llama-3.1-8B sous éloge, attribué aux refus : déplacement du verdict sous pression. | — |
| SC-06 | D | Budget minimal d'opérations d'inférence du moniteur pour atteindre des critères de détection fixés. | — |
| SC-07 | F | Réussite d'une injection dans le contenu lu par le moniteur ; l'écart seuil se déplacerait avec la date du moniteur. | C |
| SC-08 | A | Durée humaine d'épisode à laquelle le modèle réussit 50 % sous protocole figé, calque direct de l'horizon du METR. | — |
| SC-09 | B | Taux de conscience d'évaluation verbalisée et d'actions couvertes tracés le long du calcul de renforcement. | — |
| SC-10 | C | Longueur d'artefact à laquelle la détection du moniteur croise 50 %, attaquants gelés, moniteur variant. | — |
| SC-11 | F | Effet du préfixe de réputation de l'auteur sur le point fixe du verdict sous pression. | — |
| SC-12 | B | Pente datée d'une propension (sous-performance stratégique) supposée dominée par les refus, en contre-exemple. | — |
| SC-13 | C | Nombre maximal d'occasions d'action que le contrôleur tient sous 5 % de dommage, contrôleur variant, propositions exogènes. | — |
| SC-14 | F | Gains de pression sur la forme contre le fond : décomposition du déplacement du verdict de Llama-3.1-8B. | — |
| SC-15 | B | Dose d'incitation ED50 à difficulté relative fixée, normalisée par l'horizon instrumental. | — |
| SC-16 | C | Durée humaine équivalente de trajectoire que le moniteur tient à 80 % de sensibilité, moniteur variant. | — |
| SC-17 | B | Horizon tiré du risque conjoint violation × non-détection à doses fixées, moniteur tenu fixe, modèle évalué variant. | C |
| SC-18 | D | Minutes humaines minimales par campagne pour tenir des taux fixés de non-détection et de fausse alerte. | — |
| SC-19 | E | Rapport des budgets humains d'audit équipe / centralisé : grandeur définie comme rapport collectif sur centralisé. | D |
| SC-20 | D | Nombre minimal d'actions notées pour qu'une sonde sur les activations dépasse le plancher des sondes aléatoires. | — |
| SC-21 | D | Temps d'annotation humaine cumulé pour qu'une sonde atteigne des critères fixés de détection. | — |
| SC-22 | A | Difficulté humaine à laquelle le modèle atteint 50 % un objectif autorisé mais incompatible avec une contrainte : capacité, non propension. | — |
| SC-23 | D | Minutes de revue humaine par heure de travail utile pour intercepter 90 % des violations plantées. | — |
| SC-24 | D | Calcul de surveillance par trajectoire nécessaire au moniteur pour une aire sous la courbe de 0,90. | — |
| SC-25 | E | Charge d'interdépendance à laquelle 20 % des épisodes d'une équipe violent un invariant global. | — |
| SC-26 | C | Horizon d'échantillonnage défensif k_50 tracé contre l'écart de capacité attaquant–moniteur. | A |
| SC-27 | E | Dose ED_50 à laquelle un collectif valide une proposition fausse, et rapport collectif / individuel. | B |
| SC-28 | E | Charge d'interdépendance à laquelle la violation globale sans alerte franchit 8 %, équipe contre centralisé. | — |
| SC-29 | D | Nombre minimal d'actions étiquetées pour qu'une sonde franchisse ses critères, mesuré au seuil ED_50. | — |
| SC-30 | D | Temps d'audit humain par épisode à risque fixé, l'attaquant variant sur l'axe. | — |
| SC-31 | B | Dose d'incitation à laquelle la probabilité d'issue interdite croise un seuil, capacité contrôlée. | — |
| SC-32 | E | Budget collectif B_50 dont un essaim a besoin pour faire promouvoir une loi fausse, contre un agent unique. | A |
| SC-33 | D | Minutes de revue par heure de travail utile à risque fixé, producteurs et moniteurs renouvelés ensemble. | — |

Effectifs : A 3 ; B 5 ; C 6 ; D 9 ; E 5 ; F 5 (total 33). Seconds choix : SC-07 (C), SC-17 (C), SC-19 (D), SC-26 (A), SC-27 (B), SC-32 (A).

## 3. Limites

1. **Aveuglement partiel** : les définitions ont été conçues après lecture complète des 33 fiches (c'est inévitable pour couvrir l'ensemble). Elles ont été écrites sur disque avant toute affectation, mais leur forme reste informée par le contenu des fiches.
2. **Le groupe F est le moins « tendance »** : quatre de ses cinq fiches (SC-02, SC-05, SC-11, SC-14) ne proposent aucune tendance d'échelle. Ce sont des tests de mécanisme sur un seul modèle (Qwen2.5 comme moniteur, Llama-3.1-8B-Instruct comme évaluateur), sans axe de date, de taille ni de calcul. Elles sont rangées en F parce que leur grandeur est un déplacement de verdict, et non parce qu'elles répondent à la demande du mentor. Seule SC-07 y porte une tendance datée.
3. **Effet de la règle de priorité** (E puis F avant A à D) : SC-19, SC-27 et SC-32 vont en E alors que leur grandeur relèverait sinon de D, B et A. De même, SC-07 va en F alors que sa tendance porte sur la robustesse du moniteur (C).
4. **Frontière A / B** : SC-22 (objectif interdit mais autorisé, lu comme une capacité) et SC-15 (dose normalisée par l'horizon de capacité) sont toutes deux construites pour séparer capacité et propension. Leur place dépend de la grandeur tracée (difficulté de tâche contre dose), pas de leur intention.
5. **Frontière B / C pour SC-17** : affectée à B parce que le moniteur est tenu fixe. Si le moniteur variait, elle relèverait de C.
6. **Le groupe D est large (9 fiches) et hétérogène par sa ressource** : calcul ou opérations (SC-06, SC-24), minutes humaines (SC-18, SC-23, SC-30, SC-33), sondes sur les activations (SC-20, SC-21, SC-29). Une partition par type de ressource aurait été possible ; je ne l'ai pas faite pour ne pas changer les définitions après coup.
7. **L'axe n'est pas un critère de groupement** : selon la fiche, la grandeur varie avec la date de sortie, la date de l'attaquant, la date du moniteur, l'écart attaquant–moniteur, la taille ou le calcul de renforcement (SC-09). Deux fiches d'un même groupe peuvent donc tracer contre des axes différents.
8. **SC-12** est rangée en B par sa grandeur (une propension datée), alors que son rôle déclaré est celui d'un contre-exemple, qui justifierait de ne pas tracer les propensions.
9. **SC-03 et SC-06** partagent le même dispositif (tâches synthétiques à état caché, anomalies plantées) mais tracent des grandeurs différentes (une longueur tenue, un budget de calcul). Elles sont donc dans des groupes distincts (C et D).
