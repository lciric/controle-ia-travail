"""Forces de Bradley-Terry et cohérence des comparaisons par paires — question 1 de Lujain Ibrahim, ensemble — v1.

Numpy seul, sans modèle. Usage :
    python3 -I bradley_terry_ibrahim_q1_v1.py PAIRES.jsonl FICHES.json SORTIE.json

Gardes (aucun repli silencieux) : toute anomalie lève GardeErreur et arrête le script.
Les gardes sont éprouvées à chaque exécution sur un cas sain et sur des artefacts, avant le calcul réel ;
le résultat de ces épreuves est écrit dans la sortie.

Ajustement : algorithme de minorisation-majorisation (Hunter 2004) avec un lissage de 0,5 victoire fictive
par sens et par paire (sans lui, une fiche qui gagne toutes ses comparaisons a une force infinie).
"""
import copy
import hashlib
import itertools
import json
import sys

import numpy as np

HUIT = ["IB-03", "IB-17", "IB-18", "IB-21", "IB-27", "IB-24", "IB-20", "IB-10"]
SHA_FICHES = "b1aa08dbd2bef0de24eb573a331a35a29b235c65f992530ca3d5cc7521b5f3d2"
LISSAGE = 0.5
SEUIL_COHERENCE = 0.8
SEUIL_PRESQUE_PARFAITE = 0.95


class GardeErreur(Exception):
    pass


def sha256(chemin):
    h = hashlib.sha256()
    with open(chemin, "rb") as f:
        for bloc in iter(lambda: f.read(1 << 16), b""):
            h.update(bloc)
    return h.hexdigest()


def presentations(ids):
    """Indice k < 28 : paire k (ordre lexicographique) présentée (a, b) ; k >= 28 : paire k-28 présentée (b, a)."""
    paires = list(itertools.combinations(sorted(ids), 2))
    return [(a, b) for a, b in paires] + [(b, a) for a, b in paires]


def permutation_attendue(sha_hex, n):
    e = int(sha_hex[:16], 16)
    return np.random.default_rng(np.random.SeedSequence(e)).permutation(n)


def verifier(jugements, ids, sha_hex):
    ids = list(ids)
    n_attendu = len(ids) * (len(ids) - 1)
    pres = presentations(ids)
    perm = permutation_attendue(sha_hex, n_attendu)
    if len(jugements) != n_attendu:
        raise GardeErreur(f"{len(jugements)} jugements au lieu de {n_attendu}")
    rangs = [j.get("rang") for j in jugements]
    if sorted(rangs) != list(range(n_attendu)):
        raise GardeErreur("rangs manquants ou en double")
    vus = set()
    for j in sorted(jugements, key=lambda x: x["rang"]):
        for cle in ("rang", "indice", "A", "B", "gagnant"):
            if cle not in j:
                raise GardeErreur(f"clé {cle} absente au rang {j.get('rang')}")
        a, b, g = j["A"], j["B"], j["gagnant"]
        if a not in ids or b not in ids:
            raise GardeErreur(f"identifiant inconnu au rang {j['rang']} : {a}, {b}")
        if a == b:
            raise GardeErreur(f"fiche comparée à elle-même au rang {j['rang']}")
        if g not in (a, b):
            raise GardeErreur(f"gagnant {g} hors de la paire au rang {j['rang']}")
        if int(perm[j["rang"]]) != j["indice"]:
            raise GardeErreur(f"ordre de présentation non conforme à la permutation au rang {j['rang']}")
        if pres[j["indice"]] != (a, b):
            raise GardeErreur(f"indice {j['indice']} ne correspond pas à ({a}, {b})")
        if (a, b) in vus:
            raise GardeErreur(f"présentation ({a}, {b}) jugée deux fois")
        vus.add((a, b))
    for a, b in itertools.combinations(ids, 2):
        if (a, b) not in vus or (b, a) not in vus:
            raise GardeErreur(f"paire {a}/{b} non jugée dans les deux ordres")


def ajuster(jugements, ids, lissage=LISSAGE, max_iter=10000, tol=1e-12):
    idx = {x: i for i, x in enumerate(ids)}
    n = len(ids)
    w = np.zeros((n, n))
    for j in jugements:
        g = j["gagnant"]
        p = j["B"] if g == j["A"] else j["A"]
        w[idx[g], idx[p]] += 1.0
    w_l = w + lissage * (1 - np.eye(n))
    nij = w_l + w_l.T
    victoires = w_l.sum(axis=1)
    if np.any(victoires <= 0):
        raise GardeErreur("une fiche sans aucune victoire même lissée")
    p = np.ones(n)
    for it in range(1, max_iter + 1):
        denom = (nij / (p[:, None] + p[None, :])).sum(axis=1)
        p_nv = victoires / denom
        p_nv = p_nv / np.exp(np.mean(np.log(p_nv)))
        if np.max(np.abs(np.log(p_nv) - np.log(p))) < tol:
            p = p_nv
            break
        p = p_nv
    else:
        raise GardeErreur(f"pas de convergence en {max_iter} itérations")
    if not np.all(np.isfinite(p)) or np.any(p <= 0):
        raise GardeErreur("forces non finies")
    return p, w, it


def coherence(jugements, ids):
    par = {}
    for j in jugements:
        cle = tuple(sorted((j["A"], j["B"])))
        par.setdefault(cle, []).append(j["gagnant"])
    concord = [k for k, v in par.items() if len(v) == 2 and v[0] == v[1]]
    discord = [k for k, v in par.items() if len(v) == 2 and v[0] != v[1]]
    return len(concord) / len(par), sorted(discord)


def cas_sain(ids, sha_hex):
    """Jugements synthétiques valides : la fiche de rang plus haut dans un ordre vrai gagne toujours."""
    vrai = list(ids)
    rang_vrai = {x: i for i, x in enumerate(vrai)}
    pres = presentations(ids)
    perm = permutation_attendue(sha_hex, len(pres))
    js = []
    for r, k in enumerate(perm):
        a, b = pres[int(k)]
        g = a if rang_vrai[a] < rang_vrai[b] else b
        js.append({"rang": r, "indice": int(k), "A": a, "B": b, "gagnant": g})
    return js, vrai


def eprouver_gardes(ids, sha_hex):
    rapport = []
    sain, vrai = cas_sain(ids, sha_hex)
    verifier(sain, ids, sha_hex)
    p, _, _ = ajuster(sain, ids)
    ordre = [ids[i] for i in np.argsort(-p)]
    if ordre != vrai:
        raise GardeErreur("cas sain : ordre vrai non retrouvé")
    c, _ = coherence(sain, ids)
    if c != 1.0:
        raise GardeErreur("cas sain : cohérence attendue 1")
    rapport.append({"cas": "sain (ordre vrai déterministe)", "attendu": "passe", "obtenu": "passe, ordre retrouvé"})

    def artefact(nom, js, **kw):
        try:
            verifier(js, ids, sha_hex)
            ajuster(js, ids, **kw)
        except GardeErreur as e:
            rapport.append({"cas": nom, "attendu": "arrêt", "obtenu": f"arrêt : {e}"})
            return
        raise GardeErreur(f"artefact non détecté : {nom}")

    a = copy.deepcopy(sain); a.pop(); artefact("ligne manquante", a)
    a = copy.deepcopy(sain); a[1]["rang"] = a[0]["rang"]; artefact("rang en double", a)
    a = copy.deepcopy(sain); a[0]["gagnant"] = next(x for x in ids if x not in (a[0]["A"], a[0]["B"])); artefact("gagnant hors de la paire", a)
    a = copy.deepcopy(sain); a[0]["A"] = "IB-99"; artefact("identifiant inconnu", a)
    a = copy.deepcopy(sain); a[0]["B"] = a[0]["A"]; artefact("fiche contre elle-même", a)
    a = copy.deepcopy(sain); a[0]["indice"], a[1]["indice"] = a[1]["indice"], a[0]["indice"]; a[0]["A"], a[1]["A"] = a[1]["A"], a[0]["A"]; a[0]["B"], a[1]["B"] = a[1]["B"], a[0]["B"]; artefact("ordre de présentation permuté", a)
    a = copy.deepcopy(sain)
    pres = presentations(ids)
    k0 = a[0]["indice"]; k_miroir = (k0 + 28) % 56
    for j in a:
        if j["indice"] == k_miroir:
            j["A"], j["B"] = a[0]["A"], a[0]["B"]
    artefact("paire jugée deux fois dans le même ordre", a)
    a = copy.deepcopy(sain); del a[3]["gagnant"]; artefact("clé absente", a)
    try:
        verifier(sain, ids, "0" * 64)
        raise GardeErreur("artefact non détecté : graine fausse")
    except GardeErreur as e:
        if "non détecté" in str(e):
            raise
        rapport.append({"cas": "graine fausse (empreinte des fiches changée)", "attendu": "arrêt", "obtenu": f"arrêt : {e}"})
    artefact("non-convergence forcée (une itération)", copy.deepcopy(sain), max_iter=1)
    return rapport


def main(chemin_paires, chemin_fiches, chemin_sortie):
    sha_f = sha256(chemin_fiches)
    if sha_f != SHA_FICHES:
        raise GardeErreur(f"empreinte des fiches inattendue : {sha_f}")
    ids = sorted(HUIT)
    epreuves = eprouver_gardes(ids, sha_f)
    with open(chemin_paires, encoding="utf-8") as f:
        lignes = [l for l in f.read().splitlines()]
    if any(not l.strip() for l in lignes):
        raise GardeErreur("ligne vide dans le fichier des paires")
    jugements = [json.loads(l) for l in lignes]
    verifier(jugements, ids, sha_f)
    p, w, it = ajuster(jugements, ids)
    c, discord = coherence(jugements, ids)
    ordre = [ids[i] for i in np.argsort(-p, kind="stable")]
    gains_a = sum(1 for j in jugements if j["gagnant"] == j["A"]) / len(jugements)
    reserves = []
    if c < SEUIL_COHERENCE:
        reserves.append(f"cohérence {c:.3f} sous le seuil {SEUIL_COHERENCE}")
    if c >= SEUIL_PRESQUE_PARFAITE:
        reserves.append(f"cohérence presque parfaite ({c:.3f}) d'un juge unique : mesure peu informative de la stabilité, possible mémoire du premier jugement")
    sortie = {
        "script": "bradley_terry_ibrahim_q1_v1.py",
        "sha256_script": sha256(__file__),
        "numpy": np.__version__,
        "entrees": {"paires": chemin_paires, "sha256_paires": sha256(chemin_paires), "fiches": chemin_fiches, "sha256_fiches": sha_f},
        "graine": {"e": int(sha_f[:16], 16), "construction": "numpy.random.default_rng(numpy.random.SeedSequence(e)).permutation(56)"},
        "epreuves_des_gardes": epreuves,
        "lissage": LISSAGE,
        "iterations": it,
        "ordre_final": ordre,
        "forces": {ids[i]: round(float(p[i]), 6) for i in range(len(ids))},
        "log_forces": {ids[i]: round(float(np.log(p[i])), 6) for i in range(len(ids))},
        "victoires_brutes_sur_14": {ids[i]: int(w[i].sum()) for i in range(len(ids))},
        "coherence": round(c, 6),
        "paires_discordantes": [list(x) for x in discord],
        "part_gagnee_par_la_premiere_presentee": round(gains_a, 6),
        "reserves": reserves,
    }
    with open(chemin_sortie, "x", encoding="utf-8") as f:
        json.dump(sortie, f, ensure_ascii=False, indent=1)
    print(json.dumps({k: sortie[k] for k in ("ordre_final", "forces", "victoires_brutes_sur_14", "coherence", "paires_discordantes", "part_gagnee_par_la_premiere_presentee", "reserves")}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    if len(sys.argv) != 4:
        raise SystemExit("usage : PAIRES.jsonl FICHES.json SORTIE.json")
    main(*sys.argv[1:])
