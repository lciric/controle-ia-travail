#!/usr/bin/env python3
"""Forces de Bradley-Terry, classeur D, question de Shi Feng et Eyon Jang, v1.

Lit `paires-v1.jsonl` (56 jugements : 28 paires, chacune dans les deux ordres), contrôle le
fichier par des gardes, ajuste un modèle de Bradley-Terry (numpy seul, aucun modèle de langue),
mesure la cohérence entre ordres et écrit une sortie JSON.

Les gardes sont d'abord éprouvées sur des cas sains et sur des artefacts (`epreuves`) ; si une
épreuve échoue, aucun classement n'est calculé et le script sort en erreur. Aucun repli silencieux :
quand l'estimateur du maximum de vraisemblance n'existe pas (un identifiant invaincu ou sans
victoire), l'ajustement non pénalisé lève une erreur et seul l'ajustement pénalisé, déclaré, est
rapporté.

Usage :
  python3 -I bradley_terry_jang_feng_v1.py --paires paires-v1.jsonl --notes notes-v1.json \
      --fiches FICHES.json --sortie bradley_terry_jang_feng_v1-sortie.json --heure "$(date -u ...)"
"""
import argparse
import hashlib
import io
import itertools
import json
import sys

import numpy as np

IDS = ["JF-06", "JF-10", "JF-14", "JF-18", "JF-19", "JF-21", "JF-26", "JF-28"]
SHA_FICHES_ATTENDU = "79c0befdf57fa2b4e9a2bc897cda9450f8c3489b2f05829c6e047f95a313a1c5"
LAMBDA_PRINCIPAL = 0.25  # pénalité sur les log-forces (a priori normal centré, variance 4)
LAMBDAS = (0.05, 0.25, 1.0)
SEUIL_COHERENCE = 0.8
SEUIL_PRESQUE_PARFAIT = 0.95
TOLERANCE_EGALITE = 1e-6
RANG_SOUS_LECTURE = {"+": 0, "=": 1, "−": 2}

# Corrections déclarées du fichier des paires, laissé tel qu'écrit (jamais réécrit). Seul le champ
# « indice », redondant avec (A, B) et le rang, peut être corrigé ; A, B et le gagnant, jamais.
CORRECTIONS_DECLAREES = [
    {"rang": 53, "champ": "indice", "lu": 45, "corrige": 44,
     "raison": "faute de frappe à l'écriture : la présentation JF-19 puis JF-21 au rang 53 est l'indice 44 "
               "(l'indice 45 est JF-21 puis JF-19, rang 21) ; trouvée par la garde du plan au premier passage"},
]


class GardeError(Exception):
    """Une garde a refusé l'entrée ou le calcul."""


def appliquer_corrections(jugements, corrections, ids, e):
    """Applique des corrections déclarées d'indice ; refuse tout autre champ ou toute valeur inattendue."""
    attendu = {rang: (k, a, b) for rang, k, a, b in plan(ids, e)}
    sortie = [dict(x) for x in jugements]
    journal = []
    for c in corrections:
        if c.get("champ") != "indice":
            raise GardeError(f"correction refusée : champ {c.get('champ')!r} non corrigeable")
        r = c["rang"]
        cibles = [x for x in sortie if x.get("rang") == r]
        if len(cibles) != 1:
            raise GardeError(f"correction refusée : rang {r} absent ou répété")
        x = cibles[0]
        if x.get("indice") != c["lu"]:
            raise GardeError(f"correction refusée : rang {r}, indice lu {x.get('indice')!r} et non {c['lu']!r}")
        k, a, b = attendu[r]
        if c["corrige"] != k or (x.get("A"), x.get("B")) != (a, b):
            raise GardeError(f"correction refusée : rang {r}, la valeur corrigée ne rend pas le plan")
        x["indice"] = c["corrige"]
        journal.append(dict(c))
    return sortie, journal


def sha256_fichier(chemin):
    h = hashlib.sha256()
    with open(chemin, "rb") as f:
        for bloc in iter(lambda: f.read(1 << 16), b""):
            h.update(bloc)
    return h.hexdigest()


def graine_depuis_sha(sha_hex):
    return int(sha_hex[:16], 16)


def plan(ids, e):
    """Plan de présentation : (rang, indice, A, B) selon la consigne."""
    paires = list(itertools.combinations(ids, 2))
    perm = np.random.default_rng(np.random.SeedSequence(e)).permutation(2 * len(paires))
    sortie = []
    for rang, k in enumerate(perm.tolist()):
        i, j = paires[k // 2]
        a, b = (i, j) if k % 2 == 0 else (j, i)
        sortie.append((rang, k, a, b))
    return sortie


def lire_jsonl(flux):
    jugements = []
    for n, ligne in enumerate(flux, 1):
        ligne = ligne.strip()
        if not ligne:
            raise GardeError(f"ligne {n} vide")
        try:
            jugements.append(json.loads(ligne))
        except json.JSONDecodeError as exc:
            raise GardeError(f"ligne {n} : JSON invalide ({exc})") from exc
    return jugements


def verifier(jugements, ids, e):
    """Gardes sur les jugements ; renvoie la liste triée par rang ou lève GardeError."""
    attendu = plan(ids, e)
    if len(jugements) != len(attendu):
        raise GardeError(f"{len(jugements)} jugements lus, {len(attendu)} attendus")
    vus = set()
    for n, x in enumerate(jugements, 1):
        for champ in ("rang", "indice", "A", "B", "gagnant"):
            if champ not in x:
                raise GardeError(f"jugement {n} : champ « {champ} » absent")
        if x["A"] == x["B"]:
            raise GardeError(f"jugement {n} : A et B identiques ({x['A']})")
        for c in ("A", "B"):
            if x[c] not in ids:
                raise GardeError(f"jugement {n} : identifiant inconnu {x[c]!r}")
        if x["gagnant"] not in (x["A"], x["B"]):
            raise GardeError(f"jugement {n} : gagnant {x['gagnant']!r} hors de la paire")
        cle = (x["A"], x["B"])
        if cle in vus:
            raise GardeError(f"jugement {n} : présentation {cle} en double")
        vus.add(cle)
    rangs_fichier = [x["rang"] for x in jugements]
    if rangs_fichier != sorted(rangs_fichier):
        raise GardeError("le fichier n'est pas écrit dans l'ordre des rangs de présentation")
    if rangs_fichier != list(range(len(attendu))):
        raise GardeError("rangs manquants, répétés ou hors bornes")
    for x, (rang, k, a, b) in zip(jugements, attendu):
        if (x["indice"], x["A"], x["B"]) != (k, a, b):
            raise GardeError(
                f"rang {rang} : plan attendu (indice {k}, {a} puis {b}), lu "
                f"(indice {x['indice']}, {x['A']} puis {x['B']})")
    for i, j in itertools.combinations(ids, 2):
        if (i, j) not in vus or (j, i) not in vus:
            raise GardeError(f"paire {i}, {j} : il manque un ordre")
    return list(jugements)


def matrice_victoires(jugements, ids):
    pos = {x: n for n, x in enumerate(ids)}
    w = np.zeros((len(ids), len(ids)))
    for x in jugements:
        g = x["gagnant"]
        p = x["B"] if g == x["A"] else x["A"]
        w[pos[g], pos[p]] += 1
    return w


def emv_existe(w):
    """Condition de Ford : le graphe « i a battu j au moins une fois » est fortement connexe."""
    n = w.shape[0]
    atteint = (w > 0) | np.eye(n, dtype=bool)
    for k in range(n):
        atteint = atteint | (atteint[:, [k]] & atteint[[k], :])
    return bool(atteint.all())


def ajuster(w, lam, max_iter=200, tol=1e-10):
    """Log-forces de Bradley-Terry par Newton ; lam = 0 exige que l'estimateur existe."""
    n = w.shape[0]
    if lam < 0:
        raise GardeError("pénalité négative")
    if lam == 0 and not emv_existe(w):
        raise GardeError("estimateur du maximum de vraisemblance inexistant (condition de Ford violée) : "
                         "ajustement non pénalisé refusé")
    nij = w + w.T
    theta = np.zeros(n)
    for it in range(1, max_iter + 1):
        d = theta[:, None] - theta[None, :]
        p = 1.0 / (1.0 + np.exp(-d))
        grad = (w - nij * p).sum(axis=1) - lam * theta
        v = nij * p * (1.0 - p)
        hess = v.copy()
        np.fill_diagonal(hess, 0.0)
        hess[np.diag_indices(n)] = -v.sum(axis=1) + np.diag(v) - lam
        if lam == 0:
            # contrainte de somme nulle : on retire la direction constante
            a = np.vstack([np.hstack([hess, np.ones((n, 1))]), np.hstack([np.ones((1, n)), np.zeros((1, 1))])])
            pas = np.linalg.solve(a, -np.concatenate([grad, [0.0]]))[:n]
        else:
            pas = np.linalg.solve(hess, -grad)
        theta = theta + pas
        if lam == 0:
            theta = theta - theta.mean()
        if np.max(np.abs(grad)) < tol and np.max(np.abs(pas)) < 1e-8:
            return theta, it
    raise GardeError(f"non convergé après {max_iter} itérations (pénalité {lam})")


def coherence(jugements, ids):
    gagnant = {(x["A"], x["B"]): x["gagnant"] for x in jugements}
    detail = []
    for i, j in itertools.combinations(ids, 2):
        g1, g2 = gagnant[(i, j)], gagnant[(j, i)]
        detail.append({"paire": [i, j], "ordre_i_j": g1, "ordre_j_i": g2, "concordant": g1 == g2})
    part = sum(d["concordant"] for d in detail) / len(detail)
    return part, detail


def cycles_majoritaires(w, ids):
    """Triplets intransitifs sous la préférence majoritaire stricte (2 victoires sur 2)."""
    n = len(ids)
    bat = w > w.T
    cyc = []
    for a, b, c in itertools.combinations(range(n), 3):
        if (bat[a, b] and bat[b, c] and bat[c, a]) or (bat[b, a] and bat[c, b] and bat[a, c]):
            cyc.append([ids[a], ids[b], ids[c]])
    return cyc


def groupes_egalite(theta, ids, tol=TOLERANCE_EGALITE):
    ordre = sorted(range(len(ids)), key=lambda k: -theta[k])
    groupes = []
    for k in ordre:
        if groupes and abs(theta[groupes[-1][0]] - theta[k]) < tol:
            groupes[-1].append(k)
        else:
            groupes.append([k])
    return [[ids[k] for k in g] for g in groupes]


def ordre_final(theta, ids, notes, e):
    """Égalités de force : somme des notes, puis originalité, puis sous-lecture de la moisson, puis tirage."""
    tirage = np.random.default_rng(np.random.SeedSequence(e, spawn_key=(1,))).permutation(len(ids))
    rang_tirage = {ids[k]: r for r, k in enumerate(tirage.tolist())}
    cles = {}
    for k, x in enumerate(ids):
        nt = notes[x]
        cles[x] = (-round(float(theta[k]) / TOLERANCE_EGALITE),
                   -nt["somme"], -nt["originalite"], RANG_SOUS_LECTURE[nt["sous_lecture"]], rang_tirage[x])
    ordre = sorted(ids, key=lambda x: cles[x])
    decide_par = []
    for a, b in zip(ordre, ordre[1:]):
        ca, cb = cles[a], cles[b]
        crit = ["force", "somme des notes", "originalité", "sous-lecture de la moisson", "tirage"]
        for c, va, vb in zip(crit, ca, cb):
            if va != vb:
                decide_par.append({"devant": a, "derriere": b, "departage_par": c})
                break
    return ordre, decide_par, {x: r for x, r in rang_tirage.items()}


# ---------------------------------------------------------------- épreuves des gardes
def _synthetique(ids, e, rang_cache, basculer=()):
    """Jugements du plan, gagnant = le mieux classé dans rang_cache ; basculer : présentations inversées."""
    sortie = []
    for rang, k, a, b in plan(ids, e):
        g = a if rang_cache[a] < rang_cache[b] else b
        if (a, b) in basculer:
            g = b if g == a else a
        sortie.append({"rang": rang, "indice": k, "A": a, "B": b, "gagnant": g})
    return sortie


def epreuves(e):
    res = []

    def attendre_refus(nom, fonction):
        try:
            fonction()
        except GardeError as exc:
            res.append({"epreuve": nom, "attendu": "refus", "obtenu": "refus", "message": str(exc), "tenue": True})
            return
        res.append({"epreuve": nom, "attendu": "refus", "obtenu": "accepté", "tenue": False})

    def attendre(nom, condition, detail=""):
        res.append({"epreuve": nom, "attendu": "vrai", "obtenu": bool(condition), "detail": detail,
                    "tenue": bool(condition)})

    cache = {x: r for r, x in enumerate(["JF-21", "JF-06", "JF-28", "JF-14", "JF-10", "JF-26", "JF-18", "JF-19"])}
    sain = _synthetique(IDS, e, cache)

    # Cas sain 1 : ordre parfait connu, cohérence 1, estimateur inexistant (repli pénalisé déclaré).
    try:
        verifier(sain, IDS, e)
        attendre("sain 1 : gardes acceptent un fichier conforme", True)
    except GardeError as exc:
        attendre("sain 1 : gardes acceptent un fichier conforme", False, str(exc))
    w = matrice_victoires(sain, IDS)
    part, _ = coherence(sain, IDS)
    attendre("sain 1 : cohérence = 1", abs(part - 1.0) < 1e-12, f"{part}")
    attendre("sain 1 : condition de Ford détectée violée", not emv_existe(w))
    attendre_refus("sain 1 : ajustement non pénalisé refusé sans estimateur", lambda: ajuster(w, 0.0))
    th, _ = ajuster(w, LAMBDA_PRINCIPAL)
    retrouve = [IDS[k] for k in np.argsort(-th)]
    attendre("sain 1 : ajustement pénalisé retrouve l'ordre caché", retrouve == sorted(IDS, key=cache.get),
             " > ".join(retrouve))
    attendre("sain 1 : réserve « presque parfait » déclenchée", part >= SEUIL_PRESQUE_PARFAIT)

    # Cas sain 2 : paires voisines partagées 1-1, estimateur existe, ordre conservé, cohérence 0,75.
    ordre_cache = sorted(IDS, key=cache.get)
    voisins = set()
    for a, b in zip(ordre_cache, ordre_cache[1:]):
        voisins.add((a, b))
    sain2 = _synthetique(IDS, e, cache, basculer=voisins)
    verifier(sain2, IDS, e)
    w2 = matrice_victoires(sain2, IDS)
    part2, _ = coherence(sain2, IDS)
    attendre("sain 2 : cohérence = 21/28", abs(part2 - 21 / 28) < 1e-12, f"{part2}")
    attendre("sain 2 : réserve « sous 0,8 » déclenchée", part2 < SEUIL_COHERENCE)
    attendre("sain 2 : condition de Ford satisfaite", emv_existe(w2))
    th2, _ = ajuster(w2, 0.0)
    retrouve2 = [IDS[k] for k in np.argsort(-th2)]
    attendre("sain 2 : ajustement non pénalisé retrouve l'ordre caché", retrouve2 == ordre_cache,
             " > ".join(retrouve2))
    gr = np.abs((w2 - (w2 + w2.T) / (1 + np.exp(-(th2[:, None] - th2[None, :])))).sum(axis=1)).max()
    attendre("sain 2 : gradient nul à la solution", gr < 1e-8, f"{gr:.2e}")

    # Cas sain 3 : simulation sous forces connues, 400 comparaisons par paire, erreur < 0,15.
    rng = np.random.default_rng(np.random.SeedSequence(e, spawn_key=(9,)))
    vrai = np.array([1.2, 0.8, 0.5, 0.1, -0.1, -0.4, -0.8, -1.3])
    vrai = vrai - vrai.mean()
    w3 = np.zeros((8, 8))
    for i, j in itertools.combinations(range(8), 2):
        g = rng.binomial(400, 1 / (1 + np.exp(-(vrai[i] - vrai[j]))))
        w3[i, j], w3[j, i] = g, 400 - g
    th3, _ = ajuster(w3, 0.0)
    err = float(np.max(np.abs(th3 - vrai)))
    attendre("sain 3 : forces simulées retrouvées à 0,15 près", err < 0.15, f"erreur max {err:.3f}")

    # Artefacts.
    def copie():
        return [dict(x) for x in sain]

    a = copie(); a[5] = dict(a[4]); attendre_refus("artefact : présentation en double", lambda: verifier(a, IDS, e))
    b = copie()[:-1]; attendre_refus("artefact : un jugement manquant", lambda: verifier(b, IDS, e))
    c = copie(); c[3]["gagnant"] = "JF-99"; attendre_refus("artefact : gagnant hors paire", lambda: verifier(c, IDS, e))
    d = copie(); d[7]["A"] = "JF-77"; attendre_refus("artefact : identifiant inconnu", lambda: verifier(d, IDS, e))
    f = copie(); f[9]["B"] = f[9]["A"]; attendre_refus("artefact : A et B identiques", lambda: verifier(f, IDS, e))
    g = copie(); g[2]["A"], g[2]["B"] = g[2]["B"], g[2]["A"]
    attendre_refus("artefact : ordre de présentation inversé sur une ligne", lambda: verifier(g, IDS, e))
    h = copie(); h[10], h[11] = h[11], h[10]
    attendre_refus("artefact : lignes hors de l'ordre des rangs", lambda: verifier(h, IDS, e))
    k = copie(); k[0].pop("gagnant"); attendre_refus("artefact : champ absent", lambda: verifier(k, IDS, e))
    attendre_refus("artefact : graine fausse (plan d'une autre permutation)", lambda: verifier(sain, IDS, e + 1))
    attendre_refus("artefact : ligne JSON invalide", lambda: lire_jsonl(io.StringIO('{"rang": 0}\n{rang: 1}\n')))
    attendre_refus("artefact : ligne vide", lambda: lire_jsonl(io.StringIO('{"rang": 0}\n\n')))
    attendre_refus("artefact : non-convergence forcée", lambda: ajuster(w2, 0.0, max_iter=1, tol=1e-30))
    attendre_refus("artefact : pénalité négative", lambda: ajuster(w2, -1.0))

    # Corrections déclarées : saine sur une faute d'indice, refusées sinon.
    faute = copie()
    r0 = faute[53]["rang"]
    k_vrai = faute[53]["indice"]
    faute[53]["indice"] = k_vrai + 1 if k_vrai % 2 == 0 else k_vrai - 1
    attendre_refus("artefact : faute d'indice non déclarée", lambda: verifier(faute, IDS, e))
    corr = [{"rang": r0, "champ": "indice", "lu": faute[53]["indice"], "corrige": k_vrai}]
    try:
        corrige, _ = appliquer_corrections(faute, corr, IDS, e)
        verifier(corrige, IDS, e)
        attendre("sain : faute d'indice déclarée corrigée, fichier accepté", True)
    except GardeError as exc:
        attendre("sain : faute d'indice déclarée corrigée, fichier accepté", False, str(exc))
    attendre_refus("artefact : correction dont la valeur lue ne correspond pas",
                   lambda: appliquer_corrections(faute, [dict(corr[0], lu=999)], IDS, e))
    attendre_refus("artefact : correction qui ne rend pas le plan",
                   lambda: appliquer_corrections(faute, [dict(corr[0], corrige=k_vrai + 2)], IDS, e))
    attendre_refus("artefact : correction d'un champ interdit (gagnant)",
                   lambda: appliquer_corrections(faute, [dict(corr[0], champ="gagnant")], IDS, e))
    return res


# ---------------------------------------------------------------- principal
def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--paires", required=True)
    ap.add_argument("--notes", required=True)
    ap.add_argument("--fiches", required=True)
    ap.add_argument("--sortie", required=True)
    ap.add_argument("--heure", required=True, help="heure UTC lue par date -u")
    arg = ap.parse_args(argv)

    sha_fiches = sha256_fichier(arg.fiches)
    if sha_fiches != SHA_FICHES_ATTENDU:
        raise GardeError(f"empreinte des fiches {sha_fiches} différente de l'attendue")
    e = graine_depuis_sha(sha_fiches)

    ep = epreuves(e)
    sortie = {
        "titre": "Forces de Bradley-Terry, classeur D, question de Shi Feng et Eyon Jang, v1",
        "heure_utc_date_u": arg.heure,
        "numpy": np.__version__,
        "entrees": {
            "paires": {"chemin": arg.paires, "sha256": sha256_fichier(arg.paires)},
            "notes": {"chemin": arg.notes, "sha256": sha256_fichier(arg.notes)},
            "fiches": {"chemin": arg.fiches, "sha256": sha_fiches},
            "script": {"chemin": __file__, "sha256": sha256_fichier(__file__)},
        },
        "graine_e": e,
        "epreuves": ep,
        "epreuves_toutes_tenues": all(x["tenue"] for x in ep),
    }
    if not sortie["epreuves_toutes_tenues"]:
        with open(arg.sortie, "x", encoding="utf-8") as fo:
            json.dump(sortie, fo, ensure_ascii=False, indent=1)
        print("ÉCHEC : une épreuve des gardes n'est pas tenue ; aucun classement calculé", file=sys.stderr)
        return 1

    with open(arg.paires, encoding="utf-8") as fl:
        bruts = lire_jsonl(fl)
    corriges, journal = appliquer_corrections(bruts, CORRECTIONS_DECLAREES, IDS, e)
    jugements = verifier(corriges, IDS, e)
    sortie["corrections_appliquees"] = journal
    with open(arg.notes, encoding="utf-8") as fn:
        nj = json.load(fn)
    notes = {}
    for x in nj["fiches"]:
        if x["id"] in IDS:
            notes[x["id"]] = {"somme": x["somme"], "originalite": x["originalite"]["note"],
                              "sous_lecture": x["sous_lecture_moisson"]}
    if sorted(notes) != sorted(IDS):
        raise GardeError("notes manquantes pour un des huit identifiants")
    if sorted(nj["huit_premieres_par_somme"]) != sorted(IDS):
        raise GardeError("les huit identifiants du script ne sont pas ceux de notes-v1.json")

    w = matrice_victoires(jugements, IDS)
    part, detail = coherence(jugements, IDS)
    victoires_a = sum(1 for x in jugements if x["gagnant"] == x["A"])
    existe = emv_existe(w)
    forces = {}
    for lam in LAMBDAS:
        th, it = ajuster(w, lam)
        forces[str(lam)] = {"log_forces": {x: round(float(t), 6) for x, t in zip(IDS, th)},
                            "iterations": it, "groupes_par_force": groupes_egalite(th, IDS)}
    stable = len({json.dumps(v["groupes_par_force"]) for v in forces.values()}) == 1
    th, _ = ajuster(w, LAMBDA_PRINCIPAL)
    ordre, decide, rang_tirage = ordre_final(th, IDS, notes, e)
    cyc = cycles_majoritaires(w, IDS)

    reserves = []
    if part < SEUIL_COHERENCE:
        reserves.append(f"cohérence {part:.3f} sous {SEUIL_COHERENCE} : classement peu fiable")
    if part >= SEUIL_PRESQUE_PARFAIT:
        reserves.append(f"cohérence {part:.3f} presque parfaite pour un juge unique : elle mesure la constance "
                        "d'un seul jugement, pas son exactitude (un juge qui se souvient de ses choix concorde par construction)")
    if not existe:
        reserves.append("estimateur non pénalisé inexistant (un identifiant invaincu ou sans victoire) : forces pénalisées "
                        f"(pénalité {LAMBDA_PRINCIPAL}), à lire comme un ordre, pas comme des écarts")
    if not stable:
        reserves.append("l'ordre par force change avec la pénalité")
    if cyc:
        reserves.append(f"triplets intransitifs : {cyc}")
    if any(len(g) > 1 for g in forces[str(LAMBDA_PRINCIPAL)]["groupes_par_force"]):
        reserves.append("forces exactement égales dans au moins un groupe : l'ordre strict y vient de la règle de départage")

    sortie.update({
        "matrice_victoires": {"lignes_battent_colonnes": IDS, "valeurs": w.astype(int).tolist()},
        "victoires_sur_14": {x: int(w[k].sum()) for k, x in enumerate(IDS)},
        "coherence": {"part": round(part, 6), "concordantes": int(sum(d["concordant"] for d in detail)),
                      "paires": len(detail), "discordantes": [d for d in detail if not d["concordant"]]},
        "biais_de_position": {"victoires_du_premier_presente": victoires_a, "sur": len(jugements)},
        "estimateur_non_penalise_existe": existe,
        "penalite_principale": LAMBDA_PRINCIPAL,
        "forces_par_penalite": forces,
        "ordre_par_force_stable": stable,
        "cycles_majoritaires": cyc,
        "regle_de_departage": "force (égalité à 1e-6 près), puis somme des notes, puis originalité, puis sous-lecture "
                              "de la moisson (+ avant = avant −), puis tirage default_rng(SeedSequence(e, spawn_key=(1,)))",
        "rang_au_tirage": rang_tirage,
        "ordre_final": ordre,
        "departages": decide,
        "reserves": reserves,
    })
    with open(arg.sortie, "x", encoding="utf-8") as fo:
        json.dump(sortie, fo, ensure_ascii=False, indent=1)
    print(json.dumps({"ordre_final": ordre, "coherence": part, "groupes": forces[str(LAMBDA_PRINCIPAL)]["groupes_par_force"],
                      "epreuves": f"{sum(x['tenue'] for x in ep)}/{len(ep)}"}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except GardeError as exc:
        print(f"GARDE : {exc}", file=sys.stderr)
        sys.exit(2)
