# Hors sujet — question de Shi Feng et Eyon Jang — lecteur A — v1

Écrit le 3 novembre 2026, 17:17 UTC (`date -u`), par le lecteur A.
Règle : une fiche est dans le sujet (« J ») si elle dit une valeur ou une limite des moniteurs ou des méthodes boîte blanche pour l'audit (lecture des activations, sondes, autoencodeurs épars, élicitation par les poids) avec l'expérience ou la mesure qui la montrerait, ou si elle touche ce que font ces mentors ; hors sujet sinon.

## Résultat : 0 fiche hors sujet sur 29

Les 29 fiches portent sur une méthode boîte blanche (sondes linéaires et leur plancher aléatoire, autoencodeurs épars, bruit de poids, élicitation par affinage, sondes dans l'accumulation de preuves) et ont toutes une mesure qui tue ; les manques de mesure partiels sont écrits dans les fiches (champ `manques`).

## Cas limites, gardés dans le sujet

- **J-012** : porte sur la correction par intervention plus que sur la détection ; gardée parce qu'elle dit une limite d'une méthode boîte blanche (une direction lisible n'est pas un levier causal) qui touche la confiance qu'un auditeur peut mettre dans l'explication d'une sonde, et parce qu'elle prolonge les sondes étudiées par Feng.
- **J-008** : ne touche aucun outil propre des mentors ; gardée parce qu'elle répond à la question (limites de calibrage et d'évasion des moniteurs latents).

## Note sur l'entrée

La source annonce deux fusions inachevées parmi les 31 éléments ; aucun champ ne les distingue, elles sont traitées comme les autres. Une fusion sans contenu est déclarée non fournie par la source ; elle n'est pas comptée.
