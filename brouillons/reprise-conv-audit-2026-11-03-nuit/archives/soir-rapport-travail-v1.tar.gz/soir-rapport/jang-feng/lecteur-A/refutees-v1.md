# Réfutées — question de Shi Feng et Eyon Jang — lecteur A — v1

Écrit le 3 novembre 2026, 17:17 UTC (`date -u`), par le lecteur A (normalisation et dédoublonnage), qui n'a écrit aucune des idées.
Règle appliquée : une fiche est réfutée seulement si une source citée (point d'une pièce, ou source primaire ouverte et citée avec page ou section) contredit son énoncé central, ou si la fiche se contredit elle-même. Jamais par accord ou désaccord entre fiches.

## Résultat : 0 fiche réfutée sur 29

Aucune source citée ne contredit un énoncé central, et aucune fiche ne se contredit sur son énoncé central. Les tensions relevées sont gardées comme objections dans les fiches (champ `objections`, marquées « Lecteur A »).

## Tensions examinées, qui n'atteignent pas l'énoncé central

- **J-008** : la pièce « Feng et Jang » § 2.2 (87 % de l'alignement reste avec 10 % de verdicts faux) contredit la branche « verdicts bruités » de l'épreuve, pas l'énoncé (privation de tout retour de verdict, branche non informative). Même section : la retouche se calcule à partir des verdicts, donc le second test de mort ne peut guère se déclencher ; c'est une faiblesse du test, pas une contradiction.
- **J-018** : même section, « le contexte suffit à viser, l'amplitude manque » ; cela rend probable le second test de mort, mais la pièce ne donne aucun taux sans amplification : pas de contradiction chiffrée.
- **J-016** et **J-007** : pièce « Feng et Jang » § 2.1 (Oak +35 à +36 points contre +10 pour les bénins) discute l'affirmation « le gain brut ne sépare pas ». Pour J-016, l'affirmation est annexe ; pour J-007, l'énoncé porte sur une aire sous la courbe sur un panel, que la pièce ne donne pas.
- **J-029** et **J-005** : le départ à 80,0 % prêté à l'organisme distillé ne figure pas dans la pièce « Feng et Jang » § 1.2, qui le donne au seul organisme « verrouillé » ; détail de plan, pas énoncé central.
- **J-029**, **J-002**, **J-028** : la prémisse « le bruit de 2512.07810 était uniforme, à dose unique, ponctuel » n'est pas dans la pièce (§ 2.1). Non vérifiée sur la source primaire (pas d'ouverture web, faute de temps) : question ouverte, à trancher sur 2512.07810 § 6.5.2 p. 22. Elle touche le cadrage de la nouveauté, pas l'énoncé testable.
- **J-009** : dans le cas Maple (pièce « Feng et Jang » § 2.1), c'est la petite ligne hors politique qui fait le faux positif et Alpaca qui le retire. Le cas appuie la dépendance au calibrage (énoncé central), pas le sens particulier « Alpaca est le mauvais calibrage ».
- **J-022** : attribue au point 1.4 de la pièce « Feng et Jang » une distinction entre détection et causalité qui n'y est pas ; citation inexacte hors énoncé central.
- **J-024** : prend en prémisse un défaut de transfert entre recettes que la pièce ne montre pas ; c'est une hypothèse (celle de J-004), et la fiche dit elle-même quel résultat réfuterait sa prémisse.
- **J-020** : la structure de P3 (quatre conditions, 60 tâches, pièce « nos résultats » § 6) ne permet pas les séquences de 40 actions ni les 1 000 épisodes honnêtes indépendants prévus ; défaut de plan, pas contradiction de l'énoncé.
- **J-011** : la pièce « Feng et Jang » § 2.6 (0,50 sur les organismes non verbalisants) va dans le sens de la fiche ; elle n'y contredit rien.
- **J-006** : le 0 sur 375 (pièce « Feng et Jang » § 2.4) est mesuré sur un autre moniteur ; pas de contradiction.

## Fiches dont le test de mort est plus faible que l'énoncé (lacune, pas contradiction)

J-026 et J-022 (énoncé : au moins 20 % ; mort : zéro), J-027 (au moins moitié ; mort sous 10 %), J-005 et J-025 (zone de 0,05 à 0,10 ni vraie ni tuée), J-016 (attente de 20 points ; mort sous 5). Parties sans mesure qui tue : J-017 (supériorité sur le juge boîte noire et la sonde passive), J-011 (« 0,94 mêle concept et séparabilité »), J-027 (moitié hors domaine).
