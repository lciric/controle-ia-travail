"""Envoi brut à Lazar d'un tour du collisionneur (protocole mentors du soir v1, §1) : cellules concaténées par tour de parole,
espèces désignées par leur lettre seule, aucun contenu modifié ; empreinte de chaque cellule rappelée."""
import hashlib, sys, os, glob
cellules_d, titre, sortie_prop, sortie_crit = sys.argv[1:5]
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
def bloc(motif):
    out = []
    for p in sorted(glob.glob(os.path.join(cellules_d, motif))):
        if p.endswith('.sha256'): continue
        out.append(f"\n\n---\n\n## {os.path.basename(p)} (sha256 `{sha(p)}`)\n\n" + open(p).read())
    return out
prop = [f"# {titre} — propositions (E3-T1) et réponses aux critiques (E3-T3), brutes\n\nCopie à l'octet vérifiée contre les compagnons ; espèces par lettre ; rien lu ni modifié par conv-audit.\n"] + bloc('E3-T1-*.md') + bloc('E3-T3-*.md')
crit = [f"# {titre} — critiques croisées (E3-T2), brutes\n\nCopie à l'octet vérifiée contre les compagnons ; espèces par lettre ; rien lu ni modifié par conv-audit.\n"] + bloc('E3-T2-*.md')
open(sortie_prop, 'w').write(''.join(prop)); open(sortie_crit, 'w').write(''.join(crit))
print(sortie_prop, sha(sortie_prop)); print(sortie_crit, sha(sortie_crit))
