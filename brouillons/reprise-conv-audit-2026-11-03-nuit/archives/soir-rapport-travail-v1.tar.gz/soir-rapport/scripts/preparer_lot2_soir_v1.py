"""Mentors du soir, lot 2 (course) : les fiches neuves de la v2 du lecteur A (identifiant ≥ premier_neuf), réidentifiées PREF-<debut>…
dans un ordre permuté par SeedSequence (graine : entier des 16 premiers hexadécimaux du sha256 de la v2), champs du noyau commun ;
puis l'ensemble (lot 1 réel pris dans la v2, fiches du matin inchangées, lot 2) et sa moisson (lot 1 + lot 2) quand la moisson du lot 2 existe."""
import hashlib, json, sys
import numpy as np
v2_p, pref, premier_neuf, debut, d, cle1_p, cle2_p = sys.argv[1:8]
premier_neuf, debut = int(premier_neuf), int(debut)
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
NOYAU = ('type', 'enonce', 'mecanisme', 'mesure_qui_tue', 'prediction', 'echec_le_plus_probable', 'cout')
v2 = json.load(open(v2_p)); v2 = v2 if isinstance(v2, list) else next(v for v in v2.values() if isinstance(v, list))
def noyau(f):
    x = {k: f.get(k, '') for k in NOYAU}; x['prediction'] = f.get('resultat_attendu', '') or f.get('prediction', ''); return x
neuves = [f for f in v2 if int(f['id'].split('-')[1]) >= premier_neuf and f.get('statut') == 'gardée' and f.get('classement') not in ('hors sujet', ['hors sujet'])]
graine = int(sha(v2_p)[:16], 16)
perm = np.random.default_rng(np.random.SeedSequence(graine)).permutation(len(neuves))
lot2, cle2 = [], {}
for r, i in enumerate(perm, debut):
    f = neuves[i]; nid = f'{pref}-{r:02d}'; lot2.append(dict(id=nid, **noyau(f))); cle2[nid] = {'source': 'tour-course', 'ident': f['id']}
json.dump(lot2, open(f'{d}/prep-v1/fiches-lot2-a-moissonner-v1.json', 'w'), ensure_ascii=False, indent=1)
json.dump({'cle': cle2, 'regle': f'{pref}-{debut} et suivants = rang dans la permutation du lot 2'}, open(cle2_p, 'w'), ensure_ascii=False, indent=1)
# ensemble
cle1 = json.load(open(cle1_p))['cle']; v2d = {f['id']: f for f in v2}
serv1 = {f['id']: f for f in json.load(open(f'{d}/prep-v1/fiches-servies-v1.json'))}
ens = []
for nid in sorted(serv1):
    k = cle1[nid]
    ens.append(dict(id=nid, **noyau(v2d[k['ident']])) if k['source'] == 'tour' else serv1[nid])
ens += lot2
json.dump(ens, open(f'{d}/prep-v1/fiches-ensemble-v1.json', 'w'), ensure_ascii=False, indent=1)
json.dump([{'id': f['id'], 'enonce': f['enonce'], 'mecanisme': f['mecanisme']} for f in ens], open(f'{d}/piste/fiches-a-grouper-ensemble-v1.json', 'w'), ensure_ascii=False, indent=1)
print('lot2', len(lot2), sha(f'{d}/prep-v1/fiches-lot2-a-moissonner-v1.json'), '| ensemble', len(ens), sha(f'{d}/prep-v1/fiches-ensemble-v1.json'),
      '| à grouper', sha(f'{d}/piste/fiches-a-grouper-ensemble-v1.json'), '| clé', sha(cle2_p), '| graine', graine)
