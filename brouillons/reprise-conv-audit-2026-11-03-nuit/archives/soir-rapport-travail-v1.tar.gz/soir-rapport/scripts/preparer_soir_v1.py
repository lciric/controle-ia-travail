"""Préparation sans provenance (protocole du soir v1, §2, étape A, part du directeur) : fiches gardées du tour (lecteur A) et fiches du
matin pour ce mentor (classement B), réidentifiées (PREF-01…), ordre permuté par SeedSequence (graine : entier des 16 premiers
hexadécimaux du sha256 du fichier du lecteur), champs réduits au noyau commun ; la moisson du matin est reportée sous le nouvel
identifiant ; seules les fiches du tour sont à moissonner. Clé à part."""
import hashlib, json, sys
import numpy as np
lect_p, matin_p, mentor_b, moisson_matin_p, pref, sortie_d, cle_p = sys.argv[1:8]
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
lect = json.load(open(lect_p)); lect = lect if isinstance(lect, list) else next(v for v in lect.values() if isinstance(v, list))
matin = [f for f in json.load(open(matin_p)) if f'B:{mentor_b}' in f['classement']]
mm = {e['id']: e for e in json.load(open(moisson_matin_p))}
NOYAU = ('type', 'enonce', 'mecanisme', 'mesure_qui_tue', 'prediction', 'echec_le_plus_probable', 'cout')
fondues = {f.get('doublon_du_matin') for f in lect if f.get('doublon_du_matin')}
el = []
for f in lect:
    if f.get('statut') != 'gardée' or f.get('classement') in ('hors sujet', ['hors sujet']): continue
    d = {k: f.get(k, '') for k in NOYAU}; d['prediction'] = f.get('resultat_attendu', '') or f.get('prediction', '')
    el.append((('tour', f['id']), d))
for f in matin:
    if f['id'] in fondues: continue  # fondue dans une fiche du tour : déjà représentée
    el.append((('matin', f['id']), {k: f.get(k, '') for k in NOYAU}))
h = sha(lect_p); graine = int(h[:16], 16)
perm = np.random.default_rng(np.random.SeedSequence(graine)).permutation(len(el))
servies, cle, a_moissonner, moisson_reportee = [], {}, [], []
for r, i in enumerate(perm, 1):
    (src, ident), d = el[i]; nid = f'{pref}-{r:02d}'
    servies.append(dict(id=nid, **d)); cle[nid] = {'source': src, 'ident': ident}
    if src == 'tour': a_moissonner.append(dict(id=nid, **d))
    else:
        e = dict(mm.get(ident, {})); e['id'] = nid; e['note_directeur'] = 'moisson du matin, reportée'; moisson_reportee.append(e)
json.dump(servies, open(f'{sortie_d}/fiches-servies-v1.json', 'w'), ensure_ascii=False, indent=1)
json.dump(a_moissonner, open(f'{sortie_d}/fiches-a-moissonner-v1.json', 'w'), ensure_ascii=False, indent=1)
json.dump(moisson_reportee, open(f'{sortie_d}/moisson-matin-reportee-v1.json', 'w'), ensure_ascii=False, indent=1)
json.dump({'cle': cle, 'regle': f'{pref}-xx = rang dans la permutation'}, open(cle_p, 'w'), ensure_ascii=False, indent=1)
man = {'entrees': {lect_p: h, matin_p: sha(matin_p), moisson_matin_p: sha(moisson_matin_p)}, 'graine': str(graine), 'numpy': np.__version__,
       'champs_servis': ['id'] + list(NOYAU), 'regle': 'prediction ← resultat_attendu pour les fiches du tour ; fiches du matin fondues par le lecteur exclues',
       'comptes': {'servies': len(servies), 'tour': len(a_moissonner), 'matin': len(moisson_reportee), 'fondues': sorted(fondues)},
       'sorties': {k: sha(f'{sortie_d}/{k}') for k in ('fiches-servies-v1.json', 'fiches-a-moissonner-v1.json', 'moisson-matin-reportee-v1.json')}, 'cle': sha(cle_p)}
json.dump(man, open(f'{sortie_d}/manifeste-preparation-v1.json', 'w'), ensure_ascii=False, indent=1)
print(json.dumps(man['comptes'], ensure_ascii=False), 'graine', graine)
