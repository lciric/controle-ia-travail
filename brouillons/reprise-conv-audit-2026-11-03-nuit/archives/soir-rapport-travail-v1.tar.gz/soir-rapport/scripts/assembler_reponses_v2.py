"""Assemble pour Lazar les réponses rédigées (dernière version de chaque réponse), avec compte de mots, empreinte et notes."""
import hashlib, json, sys, re, os, glob
D = '/home/claude/controle-ia-travail/brouillons/redaction-finale-v1/'
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
ordre = [('kirchner-q1', 'Kirchner Q1 — projet mené soi-même', 'aucune limite écrite'),
         ('kirchner-q2', 'Kirchner Q2 — problème sous-estimé, première expérience, ce qui ferait changer d\'avis', 'aucune limite écrite'),
         ('ibrahim-q1', 'Ibrahim Q1 — première expérience', 'aucune limite écrite'),
         ('ibrahim-q2', 'Ibrahim Q2 — projet technique', 'aucune limite écrite'),
         ('heimersheim-q2', 'Heimersheim Q2 — pourquoi l\'interprétabilité mécaniste', '150 mots au plus'),
         ('scheurer', 'Scheurer — proposition de tendance d\'échelle', 'aucune limite écrite'),
         ('colognese-ward-q1', 'Colognese et Ward Q1 — une expérience de bout en bout', '200 mots au plus'),
         ('colognese-ward-q2', 'Colognese et Ward Q2 — leur billet', 'aucune limite écrite'),
         ('jang-feng', 'Feng et Jang — boîte blanche : valeur et limites', 'aucune limite écrite')]
notes = json.load(open(sys.argv[1])) if len(sys.argv) > 1 else {}
sortie = sys.argv[2] if len(sys.argv) > 2 else D + 'reponses-revisees-v2.md'
L = ["# Réponses rédigées page blanche, vérifiées — assemblage", "",
     "Chaque réponse : le texte à coller (entre les filets), son compte de mots (découpage sur les blancs), ce que la vérification a trouvé, ce qui reste à ta décision. Heimersheim Q1 : squelette à part (`heimersheim-q1/squelette-heimersheim-q1-v1.md`), à écrire par toi.", ""]
for slug, titre, lim in ordre:
    vs = sorted(glob.glob(D + slug + '/reponse-v*.md'), key=lambda p: int(re.search(r'reponse-v(\d+)\.md$', p).group(1)) if re.search(r'reponse-v(\d+)\.md$', p) else 0)
    vs = [p for p in vs if re.search(r'reponse-v\d+\.md$', p)]
    if not vs:
        L += [f"## {titre}", "", "*Pas encore rédigée.*", ""]; continue
    p = vs[-1]; s = open(p).read().split('\n---\n')[0].strip()
    L += [f"## {titre}", "", f"Fichier `{slug}/{os.path.basename(p)}` (sha256 `{sha(p)[:16]}…`) ; **{len(s.split())} mots** ; limite : {lim}.", "", "---", "", s, "", "---", ""]
    for n in notes.get(slug, []): L.append(f"- {n}")
    L.append("")
open(sortie, 'w').write('\n'.join(L) + '\n'); print(sortie, sha(sortie))
