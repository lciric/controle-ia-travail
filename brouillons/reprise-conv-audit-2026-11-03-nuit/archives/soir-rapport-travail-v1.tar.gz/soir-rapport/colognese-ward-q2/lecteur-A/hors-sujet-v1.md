# Hors sujet — Colognese et Ward, question 2 (facultative) — lecteur A — v1

Écrit le 3 novembre 2026, achevé à 13:18 UTC (`date -u`) par le lecteur A. Même consigne et mêmes entrées que `refutees-v1.md`.

**Sans témoin déguisé : l'axe d'originalité n'est pas contrôlé.**

## Résultat : aucune idée hors sujet

Question du mentor (texte exact) : « (Optional) Read this post. Should we have done anything differently? What was the most interesting finding in your view and why? »

Les 22 fiches sont classées « W » : chacune propose un changement du dispositif du billet avec la mesure qui le montrerait (ou le manque est écrit), ou donne la trouvaille la plus intéressante avec l'expérience qui la confirmerait ou la tuerait (W-022, W-011, W-021). Toutes portent sur le billet (seuil mis en commun, moniteurs et vues, distillation, classes de triche, silence, commentaire dans la réponse, juges) ; aucune ne porte seulement sur les travaux de Lazar, qui n'apparaissent qu'en appuis.

## Lu sans devenir fiche (ce n'est pas une idée)

- Les tableaux de présupposés (« ce que la question suppose ») et les points « supposé » : repris dans les champs `ce_qui_rendrait_le_resultat_trompeur` et `manques` des fiches concernées.
- Les conditions « ce qui ferait échouer l'analyse » : reprises dans les mêmes champs.
- Les sections d'ancrage matériel (modèles, cartes, budgets) : reprises dans `cout` et `appuis_lazar`.
- Les notations et les défauts transversaux des critiques : joints comme objections aux fiches qu'ils visent.

## Dédoublonnage avec les fiches de ce matin

Fiches du matin pour ce mentor (`fiches-classement-B-v1.json`, sha256 `84af169b…`, vérifiée) : M-008 (syntaxe constante et convergence des cibles à forte dose), M-054 (réactance et aplatissement dose–réponse sous critique), M-006 (sonde de sycophantie projetée sur la reconstruction d'un autoencodeur épars contre des sous-espaces aléatoires). Toutes trois portent sur la loi d'attraction de la sycophancie, aucune sur le billet. Aucune idée du tour n'a la même hypothèse et la même mesure qui tue : **aucune fusion** ; le champ `doublon_du_matin` est vide partout. La plus proche par la forme, W-015 (sonde contre un plancher de sondes aléatoires), diffère par sa cible (la triche, non la sycophancie) et par sa mesure.

## Comptes

30 idées lues dans les douze cellules (27 dans les propositions, 3 nées dans les réponses, dont une par scission d'une expérience en deux contrastes) ; 22 fiches après dédoublonnage par structure, toutes dans le sujet ; 0 réfutée ; 0 doublon du matin. Fusions : W-021 (cinq idées), W-007 (trois), W-008, W-018 et W-004 (deux chacune) ; une ligne d'instruments couvrant deux juges est répartie entre W-007 et W-018.
