# Réfutées — Colognese et Ward, question 2 (facultative) — lecteur A — v1

Écrit le 3 novembre 2026, achevé à 13:18 UTC (`date -u`) par le lecteur A (normalisation et dédoublonnage), qui n'a écrit aucune des idées. Consigne `soir-lecteur-A-colognese-ward-q2-v1.md` (sha256 `f85b8884…`, vérifiée avant lecture) ; protocole `protocole-rapport-mentors-soir-v1.md` (`fbbbb520…`, vérifié) et section 2 de `protocole-rapport-idees-v1.md` (`942b9324…`, égal à son compagnon). Douze cellules lues en entier, empreintes égales à leurs compagnons ; une espèce absente, déclarée par l'état du tour. Aucun appel de modèle ; aucune page web ouverte.

**Sans témoin déguisé : l'axe d'originalité n'est pas contrôlé** (protocole du soir, section 2).

## Résultat : aucune fiche réfutée

Règle appliquée : réfutée seulement si une source citée contredit l'énoncé central, ou si l'idée se contredit elle-même ; jamais par accord ou désaccord des critiques. Les 22 fiches sont gardées. Sur 85 objections jointes, 28 sont sourcées (une pièce et sa section) ; aucune ne contredit un énoncé central. Ce qu'elles font, et pourquoi cela ne réfute pas :

1. **« Vrai par construction »** (W-001, W-017, et la version initiale de W-010) : la pièce Colognese-Ward §3.2 (triche anti-triche presque entièrement par réécriture des tests) rend le résultat probable ou peu informatif ; elle ne le contredit pas. Les versions révisées en tiennent compte (oracle indépendant, classe « sans toucher aux tests » analysée à part) ou rejettent l'objection avec raison écrite (W-017 : retirer une récompense ne garantit pas que la conduite cesse).
2. **Confusions et strates vides** (W-005, W-004, W-013, W-006, W-019, W-008) : faits sourcés de la pièce §3.1, §3.2, §3.5 ; ils limitent l'identification, ne contredisent rien. Les versions révisées ont retiré les appariements ou standardisations visés.
3. **Censure de la résistance** (W-016, W-004 ; pièce §3.5, triche délibérée à l'étape 89) : objection acceptée et transformée en analyse de survie ou en horizon prolongé. W-014 ne la lève pas : écrit dans sa note, sans réfutation (l'objection ne la visait pas).
4. **Catégorie « silencieuse » trouvée dans les ratés des moniteurs** (W-022, W-021 ; pièce §3.1, billet §2.5) : met en cause la base du contraste 16 % contre 91 %, ne contredit aucune des idées, qui en font précisément l'objet d'un ré-étiquetage aveugle.

## Contrôles faits par le lecteur sur des objections et des appuis sourcés

- **Renvoi d'appui de W-022** : l'objection dit que R7 est en pièce Colognese-Ward §3.6 et que « nos résultats » §7 cite R6. Vérifié sur les deux pièces (`piece-nos-resultats-v1.md`, sha256 `d6fa8011…`, égal à son compagnon) : exact. La version révisée corrige son renvoi ; l'idée n'est pas touchée.
- **Méthode de classement délibéré/accidentel** (objection à la version initiale de W-004) : elle cite la pièce §3.5 pour dire que le classement se fait en lisant le raisonnement ; la section donne le décompte (9 accidentelles sur 12), pas la méthode. Marquée « sourcée » pour le décompte seulement. Sans effet : la version révisée a mis ce critère en secondaire.
- **« Le billet n'a aucune référence mécanique (pièce §3.4) »** (W-001) : la section §3.4 ne le dit pas (elle relève l'absence de piste boîte blanche et de chiffres par moniteur). La pièce est muette, elle ne contredit pas : gardée, écrit dans `manques` et dans la note.
- **Calcul dans une objection** (W-004, version initiale) : 18!/(6!)³ vaut environ 1,7·10⁷, non « de l'ordre de 17 000 » ; la conclusion de l'objection (« suffisant ») n'en dépend pas.
- **Appuis de « nos résultats »** invoqués par les fiches (§3 W1, §4, §5, §6 : P3, simulation T0.3, Llama-3.1-8B-Instruct) : concordent avec la pièce. Ils sont repris tels quels dans `appuis_lazar`, non revérifiés sur les dépôts publics.

## Réserve (R4)

Zéro réfutée, zéro hors sujet, zéro doublon du matin : c'est propre. Mais cela s'explique : la règle ne réfute que par contradiction d'une source citée ; les cellules ne citent que les pièces, et les critiques sont des objections de méthode ; les fiches du matin portent sur un autre sujet (voir `hors-sujet-v1.md`). Un second lecteur pourrait fondre davantage : cinq couples voisins sont gardés séparés parce que leur hypothèse ou leur mesure qui tue diffère (W-010 et W-001 ; W-014 et W-016 ; W-004 et W-013 ; W-003 et W-019 ; W-022 et W-011), chacun l'écrit dans sa note.
