# Hors sujet — Colognese et Ward, question 2 (facultative) — lecteur A — v2

Écrit le 3 novembre 2026, achevé à 17:29 UTC (`date -u`) par un second lecteur A (suite, seconde source), qui n'a écrit aucune des idées ni aucun des textes. Consigne `soir-lecteur-A-colognese-ward-q2-source-2-v2.md` (sha256 `cfb15d27…`, vérifiée avant lecture) ; protocole `protocole-rapport-mentors-soir-v1.md` (`fbbbb520…`, vérifié) ; format et règles de `soir-lecteur-A-colognese-ward-q2-v1.md` (`f85b8884…`) ; pièce `piece-colognese-ward-v1.md` (`7533e4b5…`). Entrées de la v1 vérifiées par empreinte et lues en entier : `fiches-normalisees-v1.json` (`43f2ed8c…`), `refutees-v1.md` (`243dc528…`), `hors-sujet-v1.md` (`6dd49fe8…`) ; `cle-provenances-v1.json` non ouvert. Seconde source : 31 éléments (`fce23e27…`, vérifié), lus en entier. Aucun appel de modèle ; aucune page web ouverte.

**Sans témoin déguisé : l'axe d'originalité n'est pas contrôlé** (protocole du soir, section 2).

## Partie 1 — la v1, reprise sans modification

---

# Hors sujet — Colognese et Ward, question 2 (facultative) — lecteur A — v1

Écrit le 3 novembre 2026, achevé à 13:18 UTC (`date -u`) par le lecteur A. Même consigne et mêmes entrées que `refutees-v1.md`.

**Sans témoin déguisé : l'axe d'originalité n'est pas contrôlé.**

## Résultat : aucune idée hors sujet

Question du mentor (texte exact) : « (Optional) Read this post. Should we have done anything differently? What was the most interesting finding in your view and why? »

Les 22 fiches sont classées « W » : chacune propose un changement du dispositif du billet avec la mesure qui le montrerait (ou le manque est écrit), ou donne la trouvaille la plus intéressante avec l'expérience qui la confirmerait ou la tuerait (W-022, W-011, W-021). Toutes portent sur le billet (seuil mis en commun, moniteurs et vues, distillation, classes de triche, silence, commentaire dans la réponse, juges) ; aucune ne porte seulement sur les travaux de Lazar, qui n'apparaissent qu'en appuis.

## Lu sans devenir fiche (ce n'est pas une idée)

- Les tableaux de présupposés (« ce que la question suppose ») et les points « supposé » : repris dans les champs `ce_qui_rendrait_le_resultat_trompeur` et `manques` des fiches concernées.
- Les conditions « ce qui ferait échouer l'analyse » : reprises dans les mêmes champs.
- Les sections d'ancrage matériel (modèles, cartes, budgets) : reprises dans `cout` et `appuis_lazar`.
- Les notations et les défauts transversaux des critiques : joints comme objections aux fiches qu'ils visent.

## Dédoublonnage avec les fiches de ce matin

Fiches du matin pour ce mentor (`fiches-classement-B-v1.json`, sha256 `84af169b…`, vérifiée) : M-008 (syntaxe constante et convergence des cibles à forte dose), M-054 (réactance et aplatissement dose–réponse sous critique), M-006 (sonde de sycophantie projetée sur la reconstruction d'un autoencodeur épars contre des sous-espaces aléatoires). Toutes trois portent sur la loi d'attraction de la sycophancie, aucune sur le billet. Aucune idée du tour n'a la même hypothèse et la même mesure qui tue : **aucune fusion** ; le champ `doublon_du_matin` est vide partout. La plus proche par la forme, W-015 (sonde contre un plancher de sondes aléatoires), diffère par sa cible (la triche, non la sycophancie) et par sa mesure.

## Comptes

30 idées lues dans les douze cellules (27 dans les propositions, 3 nées dans les réponses, dont une par scission d'une expérience en deux contrastes) ; 22 fiches après dédoublonnage par structure, toutes dans le sujet ; 0 réfutée ; 0 doublon du matin. Fusions : W-021 (cinq idées), W-007 (trois), W-008, W-018 et W-004 (deux chacune) ; une ligne d'instruments couvrant deux juges est répartie entre W-007 et W-018.

---

## Partie 2 — ce qu'ajoute la seconde source

### Résultat : aucun élément hors sujet

Question du mentor (texte exact) : « (Optional) Read this post. Should we have done anything differently? What was the most interesting finding in your view and why? »

Les 31 éléments répondent : 24 proposent un changement du dispositif du billet avec la mesure ou l'expérience qui le montrerait ; 4 donnent la trouvaille la plus intéressante et l'expérience qui la confirmerait ou la tuerait (classées dans W-036, W-022 et W-008) ; 3 portent sur « ce que le billet ne dit pas », chacun avec une expérience et une mesure qui tue (W-029, W-023, W-032). Aucun ne porte seulement sur les travaux de Lazar : « Nos résultats » n'y apparaît qu'en appui.

### Non fourni par la source

La source déclare elle-même : « fusions-inachevees.json n° 0 : contenu absent (fusion non écrite) ». Rien à lire ; déclaré absent, non compté.

### Fiches du matin

Pour la seconde source, la consigne exclut le dédoublonnage avec les fiches du matin : `doublon_du_matin` est vide dans les 21 fiches neuves.

### Comptes

31 éléments lus en entier ; 21 fiches neuves, W-023 à W-043 (identifiants permutés par `numpy.random.SeedSequence`, graine dans la clé), dont trois nées d'une fusion entre éléments (W-024 : trois ; W-026 et W-029 : deux chacune), soit 25 éléments ; 6 éléments fondus dans des fiches de la v1 (W-022 : quatre ; W-008 et W-006 : un chacun). Aucune de ces fusions ne remplit un champ vide (le seul champ vide de ces trois fiches est « échec le plus probable », que les éléments ne donnent pas) : les 22 fiches de la v1 sont reprises identiques. Total de la v2 : 43 fiches, toutes « W », toutes « gardée » ; 0 réfuté ; 0 hors sujet.

### Couples voisins gardés séparés (un autre lecteur pourrait fondre)

Hypothèse ou mesure qui tue différente, écrit dans chaque note : W-024 et W-006, W-019 (la mesure qui tue de W-024 joint les deux leurs) ; W-042 et W-015 ; W-030 et W-017 ; W-034, W-031 et W-014 ; W-033 et W-013 ; W-035, W-025 et W-002 (W-025 de sens opposé) ; W-036 et W-027 ; W-040 et W-039 ; W-043, W-026 et W-037 ; W-032, W-041 et W-037. Fusions discutables dans l'autre sens : W-029 (une version sans l'hypothèse de non-additivité), W-022 (dépouillement de tous les commentaires à seuil recalibré, et un facteur « raisonnement » qui rouvre le duel commentaire contre silence), W-008 (rattachement possible à W-021), W-006 (prédiction incohérente, voir `refutees-v2.md`).
