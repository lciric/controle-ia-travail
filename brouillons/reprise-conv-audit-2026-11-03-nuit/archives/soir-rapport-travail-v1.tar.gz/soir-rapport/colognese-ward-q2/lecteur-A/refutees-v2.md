# Réfutées — Colognese et Ward, question 2 (facultative) — lecteur A — v2

Écrit le 3 novembre 2026, achevé à 17:29 UTC (`date -u`) par un second lecteur A (suite, seconde source), qui n'a écrit aucune des idées ni aucun des textes. Consigne `soir-lecteur-A-colognese-ward-q2-source-2-v2.md` (sha256 `cfb15d27…`, vérifiée avant lecture) ; protocole `protocole-rapport-mentors-soir-v1.md` (`fbbbb520…`, vérifié) ; format et règles de `soir-lecteur-A-colognese-ward-q2-v1.md` (`f85b8884…`) ; pièce `piece-colognese-ward-v1.md` (`7533e4b5…`). Entrées de la v1 vérifiées par empreinte et lues en entier : `fiches-normalisees-v1.json` (`43f2ed8c…`), `refutees-v1.md` (`243dc528…`), `hors-sujet-v1.md` (`6dd49fe8…`) ; `cle-provenances-v1.json` non ouvert. Seconde source : 31 éléments (`fce23e27…`, vérifié), lus en entier. Aucun appel de modèle ; aucune page web ouverte.

**Sans témoin déguisé : l'axe d'originalité n'est pas contrôlé** (protocole du soir, section 2).

## Partie 1 — la v1, reprise sans modification

---

# Réfutées — Colognese et Ward, question 2 (facultative) — lecteur A — v1

Écrit le 3 novembre 2026, achevé à 13:18 UTC (`date -u`) par le lecteur A (normalisation et dédoublonnage), qui n'a écrit aucune des idées. Consigne `soir-lecteur-A-colognese-ward-q2-v1.md` (sha256 `f85b8884…`, vérifiée avant lecture) ; protocole `protocole-rapport-mentors-soir-v1.md` (`fbbbb520…`, vérifié) et section 2 de `protocole-rapport-idees-v1.md` (`942b9324…`, égal à son compagnon). Douze cellules lues en entier, empreintes égales à leurs compagnons ; une espèce absente, déclarée par l'état du tour. Aucun appel de modèle ; aucune page web ouverte.

**Sans témoin déguisé : l'axe d'originalité n'est pas contrôlé** (protocole du soir, section 2).

## Résultat : aucune fiche réfutée

Règle appliquée : réfutée seulement si une source citée contredit l'énoncé central, ou si l'idée se contredit elle-même ; jamais par accord ou désaccord des critiques. Les 22 fiches sont gardées. Sur 85 objections jointes, 28 sont sourcées (une pièce et sa section) ; aucune ne contredit un énoncé central. Ce qu'elles font, et pourquoi cela ne réfute pas :

1. **« Vrai par construction »** (W-001, W-017, et la version initiale de W-010) : la pièce Colognese-Ward §3.2 (triche anti-triche presque entièrement par réécriture des tests) rend le résultat probable ou peu informatif ; elle ne le contredit pas. Les versions révisées en tiennent compte (oracle indépendant, classe « sans toucher aux tests » analysée à part) ou rejettent l'objection avec raison écrite (W-017 : retirer une récompense ne garantit pas que la conduite cesse).
2. **Confusions et strates vides** (W-005, W-004, W-013, W-006, W-019, W-008) : faits sourcés de la pièce §3.1, §3.2, §3.5 ; ils limitent l'identification, ne contredisent rien. Les versions révisées ont retiré les appariements ou standardisations visés.
3. **Censure de la résistance** (W-016, W-004 ; pièce §3.5, triche délibérée à l'étape 89) : objection acceptée et transformée en analyse de survie ou en horizon prolongé. W-014 ne la lève pas : écrit dans sa note, sans réfutation (l'objection ne la visait pas).
4. **Catégorie « silencieuse » trouvée dans les ratés des moniteurs** (W-022, W-021 ; pièce §3.1, billet §2.5) : met en cause la base du contraste 16 % contre 91 %, ne contredit aucune des idées, qui en font précisément l'objet d'un ré-étiquetage aveugle.

## Contrôles faits par le lecteur sur des objections et des appuis sourcés

- **Renvoi d'appui de W-022** : l'objection dit que R7 est en pièce Colognese-Ward §3.6 et que « nos résultats » §7 cite R6. Vérifié sur les deux pièces (`piece-nos-resultats-v1.md`, sha256 `d6fa8011…`, égal à son compagnon) : exact. La version révisée corrige son renvoi ; l'idée n'est pas touchée.
- **Méthode de classement délibéré/accidentel** (objection à la version initiale de W-004) : elle cite la pièce §3.5 pour dire que le classement se fait en lisant le raisonnement ; la section donne le décompte (9 accidentelles sur 12), pas la méthode. Marquée « sourcée » pour le décompte seulement. Sans effet : la version révisée a mis ce critère en secondaire.
- **« Le billet n'a aucune référence mécanique (pièce §3.4) »** (W-001) : la section §3.4 ne le dit pas (elle relève l'absence de piste boîte blanche et de chiffres par moniteur). La pièce est muette, elle ne contredit pas : gardée, écrit dans `manques` et dans la note.
- **Calcul dans une objection** (W-004, version initiale) : 18!/(6!)³ vaut environ 1,7·10⁷, non « de l'ordre de 17 000 » ; la conclusion de l'objection (« suffisant ») n'en dépend pas.
- **Appuis de « nos résultats »** invoqués par les fiches (§3 W1, §4, §5, §6 : P3, simulation T0.3, Llama-3.1-8B-Instruct) : concordent avec la pièce. Ils sont repris tels quels dans `appuis_lazar`, non revérifiés sur les dépôts publics.

## Réserve (R4)

Zéro réfutée, zéro hors sujet, zéro doublon du matin : c'est propre. Mais cela s'explique : la règle ne réfute que par contradiction d'une source citée ; les cellules ne citent que les pièces, et les critiques sont des objections de méthode ; les fiches du matin portent sur un autre sujet (voir `hors-sujet-v1.md`). Un second lecteur pourrait fondre davantage : cinq couples voisins sont gardés séparés parce que leur hypothèse ou leur mesure qui tue diffère (W-010 et W-001 ; W-014 et W-016 ; W-004 et W-013 ; W-003 et W-019 ; W-022 et W-011), chacun l'écrit dans sa note.

---

## Partie 2 — ce qu'ajoute la seconde source

### Résultat : aucun élément réfuté

Règle appliquée : réfuté seulement si une source citée contredit l'énoncé central, ou si l'élément se contredit lui-même ; jamais par accord ou désaccord de modèles. La seconde source n'a pas d'objections croisées : les 21 fiches neuves n'ont ni objection ni réponse ; les trois fiches de la v1 qui ont absorbé des éléments (W-006, W-008, W-022) gardent les leurs, inchangées.

### Contrôles faits par le lecteur

1. **Prédiction qui se contredit (élément fondu dans W-006).** L'élément annonce, sous le seuil commun, des fausses alertes anti-triche de 4 à 8 % et pro-triche sous 1 %, puis, avec un seuil recalibré à 2 % par caractère, une capture anti-triche qui monte de 29 % à 35–50 % et un écart avec le pro-triche qui se resserre (de 67 à 45–60 points). Preuve : le taux de fausses alertes ne croît pas quand le seuil monte ; ramener les fausses alertes anti-triche de 4–8 % à 2 % exige un seuil anti-triche plus haut, donc une capture anti-triche égale ou plus basse ; le pro-triche, sous 1 %, voit son seuil baisser et sa capture monter : l'écart s'élargit. Les deux moitiés de la prédiction ne peuvent être vraies ensemble (sauf une compensation entre moniteurs que l'élément ne dit pas). La contradiction ne touche ni son énoncé central (les honnêtes anti-triche, qui parlent de leur tentation, déplacent le seuil commun) ni sa mesure qui tue (fausses alertes de chaque caractère à 2 % ± 1 sous le seuil commun), qui sont ceux de W-006 : **fondu, non réfuté** ; le texte de W-006 est gardé et ne porte pas la prédiction fautive. Une lecture stricte de « se contredit lui-même » le réfuterait : doute déclaré.
2. **Analogie contredite par la pièce (W-040, W-039).** Les deux éléments disent la distillation sur sorties seules du billet « précisément » la configuration de débordement de la rétroaction de 2601.23086. La pièce Colognese-Ward, §2, précise que la pression de 2601.23086 est une pénalité pendant le renforcement, non une distillation préalable : l'analogie est contredite sur ce point. L'énoncé central (le silence serait un artefact de la distillation sur sorties seules, ou le produit de cette dissociation et d'un motif de dissimulation) n'est pas contredit : gardées, écrit dans leurs notes.
3. **Attribution des juges (W-025).** L'élément appelle « juges de silence » Opus 5 et DeepSeek V4.1 Flash ; la pièce, §3.1, les donne pour le raisonnement motivé. Détail de méthode, non central : écrit dans `manques`.
4. **Renvoi de R7.** Trois éléments fondus dans W-022 renvoient R7 à « Nos résultats » §7 ; le premier lecteur a vérifié que §7 y décrit R6 et que R7 est en pièce Colognese-Ward §3.6 ; W-022 porte déjà le renvoi corrigé. Sans effet.
5. **Calculs.** Vérifiés exacts : 6 × 11 520 = 69 120 ; 3 × 11 520 = 34 560 ; 18 × 11 520 = 207 360 ; 36 × 11 520 = 414 720 ; 24 × 11 520 = 276 480 ; 27 × 90 × 256 = 622 080 ; 6 × 3 × 3 × 30 × 256 = 414 720 ; 300 / 0,01 = 30 000 ; 12 × 100 = 1 200 ; 500 × 2 % = 10 ; 29 − 78 = −49 ; 96 − 29 = 67 ; 16 − 91 = −75 ; 93 + 89 − 100 = 82 (borne basse de l'intersection, si les deux parts portent sur les mêmes triches). Incohérent : W-025, où « 207 360 par régime » est le total à 11 520 trajectoires par exécution, alors que ses 414 720 supposent 90 × 256 = 23 040 par exécution (la pièce, §3.1, porte elle-même les deux nombres ; écart déjà relevé dans W-010). Sans effet sur l'énoncé.
6. **Coût contre contrôle (W-032).** Le coût dit « pas de renforcement », mais un contrôle demande « point de départ sans caractère, même renforcement » : incohérence de coût, écrite dans `manques`.
7. **Appuis de « Nos résultats »** invoqués par les fiches neuves (§2 et §3 ; §6, P3 « 0,5313 contre 0,5717 » ; §6, simulation T0.3 ; §7, R6 et « une direction lisible n'est pas nécessairement causale ») : repris tels quels dans `appuis_lazar`, **non revérifiés** par ce lecteur (pièce non rouverte, échéance). Les deux nombres de P3 ne figurent pas dans les notes du premier lecteur.

### Réserve (R4)

Encore zéro réfuté et zéro hors sujet. Explication : la seconde source ne cite que la pièce Colognese-Ward, les articles que celle-ci résume et « Nos résultats » ; ses éléments sont des propositions d'expériences sur le billet, donc dans le sujet ; la règle ne réfute que par contradiction d'une source citée ou de l'élément par lui-même. Le contrôle le plus sévère (point 1) a trouvé une vraie contradiction, tenue pour non centrale : c'est la décision la plus discutable de cette partie.
