#!/usr/bin/env python3
"""Forces de Bradley-Terry et cohérence des comparaisons par paires — v1.

Classeur D, question 2 (facultative) de Paul Colognese et Francis Rhys Ward.
numpy seulement, aucun appel de modèle. Au lancement, chaque garde est éprouvée
sur un cas sain et sur des artefacts ; si une garde ne se déclenche pas comme
attendu, le script s'arrête sans rien écrire (aucun repli silencieux).

Usage :
  python3 -I bradley_terry_colognese_ward_q2_v1.py PAIRES.jsonl NOTES.json FICHES.json SORTIE.json
"""
import copy
import datetime
import hashlib
import itertools
import json
import os
import platform
import sys

import numpy as np

SEUIL_COHERENCE = 0.8          # consigne : sous 0,8, réserve écrite
SEUIL_PRESQUE_PARFAITE = 0.95  # déclaré ici : à partir de 0,95, « presque parfaite » d'un juge unique, réserve
SIGMA = 2.0                    # écart type de la loi a priori gaussienne centrée des log-forces (maximum a posteriori)
SIGMAS_SENSIBILITE = (1.0, 2.0, 4.0)
N_REECHANTILLONNAGE = 2000
TOL_EGALITE = 1e-9
# Tâches dérivées de la graine e par SeedSequence(e).spawn(3) : 0 rééchantillonnage, 1 départage, 2 cas sain.
# L'ordre de présentation, lui, vient de SeedSequence(e) directement, comme le veut la consigne.


class ErreurGarde(Exception):
    pass


def empreinte(chemin):
    h = hashlib.sha256()
    with open(chemin, "rb") as f:
        for bloc in iter(lambda: f.read(1 << 16), b""):
            h.update(bloc)
    return h.hexdigest()


def liste_canonique(huit):
    paires = list(itertools.combinations(sorted(huit), 2))
    return [(a, b) for a, b in paires] + [(b, a) for a, b in paires]


def ordre_de_presentation(huit, e):
    L = liste_canonique(huit)
    perm = np.random.default_rng(np.random.SeedSequence(e)).permutation(len(L))
    return L, perm


def verifier_sortie_neuve(chemin):
    if os.path.exists(chemin):
        raise ErreurGarde(f"la sortie {chemin} existe déjà : on n'écrase jamais")


# ---------------------------------------------------------------- validation
def valider(jugements, huit, e):
    huit = sorted(huit)
    if len(set(huit)) != 8:
        raise ErreurGarde("il faut huit identifiants distincts")
    L, perm = ordre_de_presentation(huit, e)
    if len(jugements) != len(L):
        raise ErreurGarde(f"{len(jugements)} jugements au lieu de {len(L)}")
    vus_indices, vus_ordonnes = set(), set()
    for rang, j in enumerate(jugements):
        for cle in ("t", "indice", "premier", "second", "gagnant", "raison"):
            if cle not in j:
                raise ErreurGarde(f"clé {cle} absente au rang {rang}")
        if j["t"] != rang:
            raise ErreurGarde(f"rang {j['t']} lu à la position {rang}")
        if j["premier"] not in huit or j["second"] not in huit:
            raise ErreurGarde(f"identifiant inconnu au rang {rang}")
        if j["premier"] == j["second"]:
            raise ErreurGarde(f"auto-comparaison au rang {rang}")
        if j["gagnant"] not in (j["premier"], j["second"]):
            raise ErreurGarde(f"gagnant hors de la paire au rang {rang}")
        if j["indice"] != int(perm[rang]):
            raise ErreurGarde(f"indice {j['indice']} au rang {rang} ; la graine donne {int(perm[rang])}")
        if (j["premier"], j["second"]) != L[j["indice"]]:
            raise ErreurGarde(f"paire du rang {rang} différente de la liste canonique")
        if j["indice"] in vus_indices:
            raise ErreurGarde(f"indice {j['indice']} en double")
        if not str(j["raison"]).strip():
            raise ErreurGarde(f"raison vide au rang {rang}")
        vus_indices.add(j["indice"])
        vus_ordonnes.add((j["premier"], j["second"]))
    for a, b in itertools.combinations(huit, 2):
        if (a, b) not in vus_ordonnes or (b, a) not in vus_ordonnes:
            raise ErreurGarde(f"la paire {a}–{b} n'est pas jugée dans les deux ordres")
    return True


def coherence(jugements):
    par_paire = {}
    for j in jugements:
        par_paire.setdefault(tuple(sorted((j["premier"], j["second"]))), []).append(j)
    concordantes, discordantes = [], []
    for cle, js in sorted(par_paire.items()):
        if len(js) != 2:
            raise ErreurGarde(f"paire {cle} vue {len(js)} fois")
        if js[0]["premier"] == js[1]["premier"]:
            raise ErreurGarde(f"paire {cle} vue deux fois dans le même ordre")
        fiche = {"paire": list(cle), "rangs": [js[0]["t"], js[1]["t"]],
                 "premiers": [js[0]["premier"], js[1]["premier"]],
                 "gagnants": [js[0]["gagnant"], js[1]["gagnant"]]}
        (concordantes if js[0]["gagnant"] == js[1]["gagnant"] else discordantes).append(fiche)
    return len(concordantes) / len(par_paire), concordantes, discordantes


def lecture_coherence(c):
    reserves = []
    if c < SEUIL_COHERENCE:
        reserves.append(f"cohérence {c:.3f} sous le seuil {SEUIL_COHERENCE} : réserve écrite")
    if c >= SEUIL_PRESQUE_PARFAITE:
        reserves.append(f"cohérence {c:.3f} presque parfaite d'un juge unique (seuil déclaré {SEUIL_PRESQUE_PARFAITE}) : "
                        "le juge garde la mémoire de ses jugements, les deux ordres ne sont pas indépendants")
    return reserves


# ---------------------------------------------------------------- Bradley-Terry
def matrice_victoires(jugements, items):
    pos = {x: k for k, x in enumerate(items)}
    W = np.zeros((len(items), len(items)))
    for j in jugements:
        g = j["gagnant"]
        p = j["second"] if g == j["premier"] else j["premier"]
        W[pos[g], pos[p]] += 1
    return W


def fortement_connexe(W):
    n = W.shape[0]
    A = W > 0

    def atteint_tout(M):
        vus, pile = {0}, [0]
        while pile:
            i = pile.pop()
            for k in np.nonzero(M[i])[0]:
                k = int(k)
                if k not in vus:
                    vus.add(k)
                    pile.append(k)
        return len(vus) == n

    return atteint_tout(A) and atteint_tout(A.T)


def _log_post(theta, W, prec):
    D = theta[:, None] - theta[None, :]
    return float((W * (-np.logaddexp(0.0, -D))).sum() - 0.5 * prec * float((theta ** 2).sum()))


def bradley_terry(W, sigma, max_iter=200):
    """sigma=None : maximum de vraisemblance (refusé si le graphe n'est pas fortement connexe) ;
    sinon maximum a posteriori sous une loi gaussienne centrée d'écart type sigma sur les log-forces."""
    n = W.shape[0]
    N = W + W.T
    if sigma is None and not fortement_connexe(W):
        raise ErreurGarde("maximum de vraisemblance inexistant : graphe des victoires non fortement connexe")
    prec = 0.0 if sigma is None else 1.0 / sigma ** 2
    theta = np.zeros(n)
    Wi = W.sum(axis=1)
    for it in range(1, max_iter + 1):
        D = theta[:, None] - theta[None, :]
        P = 1.0 / (1.0 + np.exp(-D))
        g = Wi - (N * P).sum(axis=1) - prec * theta
        Q = N * P * (1.0 - P)
        H = Q.copy()
        np.fill_diagonal(H, -Q.sum(axis=1) - prec)
        if np.max(np.abs(g)) < 1e-10 * max(1.0, float(N.sum())):
            cov = np.linalg.inv(-H) if prec > 0 else np.linalg.pinv(-H)
            se = np.sqrt(np.clip(np.diag(cov), 0.0, None))
            if not (np.all(np.isfinite(theta)) and np.all(np.isfinite(se))):
                raise ErreurGarde("force ou erreur type non finie")
            return theta, se, it
        if prec > 0:
            delta = np.linalg.solve(H, -g)
        else:
            delta = np.linalg.lstsq(H, -g, rcond=None)[0]
            delta -= delta.mean()
        pas, base = 1.0, _log_post(theta, W, prec)
        for _ in range(60):
            essai = theta + pas * delta
            if _log_post(essai, W, prec) >= base - 1e-12:
                break
            pas /= 2.0
        else:
            raise ErreurGarde("recherche linéaire sans progrès")
        theta = essai
        if prec == 0:
            theta = theta - theta.mean()
        if not np.all(np.isfinite(theta)):
            raise ErreurGarde("force non finie")
    raise ErreurGarde("méthode de Newton non convergée")


def rangs_competition(theta):
    return np.array([1 + int(np.sum(theta > t + TOL_EGALITE * max(1.0, abs(t)))) for t in theta])


# ---------------------------------------------------------------- sélection des huit (recalcul depuis les notes)
def huit_depuis_notes(notes, e):
    ss_departage = np.random.SeedSequence(e).spawn(3)[1]
    tri_ids = sorted(x["id"] for x in notes["notes"])
    tirage = np.random.default_rng(ss_departage).permutation(len(tri_ids))
    rang_tirage = {tri_ids[k]: int(r) for k, r in enumerate(np.argsort(tirage))}
    def cle(x):
        return (-x["somme"], -x["originalite"][0], -x["testable"][0], -x["outil"][0], rang_tirage[x["id"]])
    tries = sorted(notes["notes"], key=cle)
    for x in tries:
        if x["somme"] != x["originalite"][0] + x["testable"][0] + x["outil"][0]:
            raise ErreurGarde(f"somme fausse pour {x['id']}")
    huitieme, neuvieme = tries[7], tries[8]
    niveau = "somme"
    if (huitieme["somme"]) == (neuvieme["somme"]):
        niveau = "originalité"
        if huitieme["originalite"][0] == neuvieme["originalite"][0]:
            niveau = "testable"
            if huitieme["testable"][0] == neuvieme["testable"][0]:
                niveau = "outil"
                if huitieme["outil"][0] == neuvieme["outil"][0]:
                    niveau = "tirage SeedSequence(e).spawn(3)[1]"
    return sorted(x["id"] for x in tries[:8]), niveau, [x["id"] for x in tries]


# ---------------------------------------------------------------- rééchantillonnage des paires
def stabilite(jugements, items, e, sigma, n_tirages):
    rng = np.random.default_rng(np.random.SeedSequence(e).spawn(3)[0])
    par_paire = {}
    for j in jugements:
        par_paire.setdefault(tuple(sorted((j["premier"], j["second"]))), []).append(j)
    cles = sorted(par_paire)
    pos = {x: k for k, x in enumerate(items)}
    n = len(items)
    rangs = np.zeros((n_tirages, n), dtype=int)
    thetas = np.zeros((n_tirages, n))
    for b in range(n_tirages):
        W = np.zeros((n, n))
        for c in rng.integers(0, len(cles), len(cles)):
            for j in par_paire[cles[c]]:
                g = j["gagnant"]
                p = j["second"] if g == j["premier"] else j["premier"]
                W[pos[g], pos[p]] += 1
        th = bradley_terry(W, sigma)[0]
        thetas[b] = th
        rangs[b] = rangs_competition(th)
    return rangs, thetas


# ---------------------------------------------------------------- gardes éprouvées
def epreuves_des_gardes(jugements_reels, huit, e):
    resultats = []

    def attendre_erreur(nom, fonction):
        try:
            fonction()
        except ErreurGarde as err:
            resultats.append({"epreuve": nom, "attendu": "garde déclenchée", "obtenu": f"garde déclenchée : {err}", "ok": True})
            return
        resultats.append({"epreuve": nom, "attendu": "garde déclenchée", "obtenu": "AUCUNE GARDE", "ok": False})

    # cas sain 1 : un jeu de 56 jugements synthétiques bien formé passe la validation, cohérence connue
    L, perm = ordre_de_presentation(huit, e)
    rang_vrai = {x: k for k, x in enumerate(sorted(huit))}
    synth = []
    for t, i in enumerate(perm):
        a, b = L[int(i)]
        g = a if rang_vrai[a] < rang_vrai[b] else b
        synth.append({"t": t, "indice": int(i), "premier": a, "second": b, "gagnant": g, "raison": "synthétique"})
    try:
        valider(synth, huit, e)
        c1, _, _ = coherence(synth)
        ok = abs(c1 - 1.0) < 1e-12
        resultats.append({"epreuve": "cas sain : 56 jugements synthétiques bien formés, ordre total", "attendu": "validés, cohérence 1",
                          "obtenu": f"validés, cohérence {c1}", "ok": ok})
    except ErreurGarde as err:
        resultats.append({"epreuve": "cas sain : jugements synthétiques", "attendu": "validés", "obtenu": f"refusés : {err}", "ok": False})
    # cas sain 2 : cohérence connue 21/28 = 0,75 (sept paires discordantes)
    mixte = copy.deepcopy(synth)
    paires_vues = {}
    for j in mixte:
        paires_vues.setdefault(tuple(sorted((j["premier"], j["second"]))), []).append(j)
    for cle in sorted(paires_vues)[:7]:
        j = paires_vues[cle][1]
        j["gagnant"] = j["second"] if j["gagnant"] == j["premier"] else j["premier"]
    c2, _, d2 = coherence(mixte)
    resultats.append({"epreuve": "cas sain : sept paires discordantes sur 28", "attendu": "cohérence 0,75 et réserve sous 0,8",
                      "obtenu": f"cohérence {c2}, {len(d2)} discordantes, réserves {len(lecture_coherence(c2))}",
                      "ok": abs(c2 - 0.75) < 1e-12 and len(d2) == 7 and any("sous le seuil" in r for r in lecture_coherence(c2))})
    # cas sain 3 : forces connues retrouvées
    rng = np.random.default_rng(np.random.SeedSequence(e).spawn(3)[2])
    vrai = np.linspace(-1.5, 1.5, 8)
    W = np.zeros((8, 8))
    for _ in range(40):
        for i in range(8):
            for j in range(8):
                if i != j:
                    if rng.random() < 1.0 / (1.0 + np.exp(-(vrai[i] - vrai[j]))):
                        W[i, j] += 1
                    else:
                        W[j, i] += 1
    connexe = fortement_connexe(W)
    th, se, it = bradley_terry(W, None)
    th_map = bradley_terry(W, SIGMA)[0]
    rv, re_ = np.argsort(np.argsort(vrai)), np.argsort(np.argsort(th))
    spearman = float(np.corrcoef(rv, re_)[0, 1])
    erreur = float(np.max(np.abs(th - (vrai - vrai.mean()))))
    meme_ordre_map = bool(np.array_equal(np.argsort(th), np.argsort(th_map)))
    resultats.append({"epreuve": "cas sain : forces connues (8 objets, 2 240 comparaisons simulées)",
                      "attendu": "graphe fortement connexe, Spearman ≥ 0,95, écart maximal < 0,4, même ordre au maximum a posteriori",
                      "obtenu": f"connexe {connexe}, Spearman {spearman:.4f}, écart maximal {erreur:.4f}, {it} itérations, même ordre {meme_ordre_map}",
                      "ok": connexe and spearman >= 0.95 and erreur < 0.4 and meme_ordre_map})
    # artefacts sur copies des jugements réels
    base = jugements_reels
    attendre_erreur("artefact : ligne en double", lambda: valider(base + [copy.deepcopy(base[-1])], huit, e))
    attendre_erreur("artefact : ligne manquante", lambda: valider(base[:-1], huit, e))
    def gagnant_hors():
        x = copy.deepcopy(base); x[3]["gagnant"] = "CW-99"; valider(x, huit, e)
    attendre_erreur("artefact : gagnant hors de la paire", gagnant_hors)
    def inconnu():
        x = copy.deepcopy(base); x[5]["second"] = "CW-01"; valider(x, huit, e)
    attendre_erreur("artefact : identifiant hors des huit", inconnu)
    def echange():
        x = copy.deepcopy(base)
        for cle in ("indice", "premier", "second", "gagnant", "raison"):
            x[0][cle], x[1][cle] = x[1][cle], x[0][cle]
        valider(x, huit, e)
    attendre_erreur("artefact : ordre de présentation qui ne suit pas la graine", echange)
    def auto():
        x = copy.deepcopy(base); x[7]["second"] = x[7]["premier"]; valider(x, huit, e)
    attendre_erreur("artefact : auto-comparaison", auto)
    def vide():
        x = copy.deepcopy(base); x[9]["raison"] = "  "; valider(x, huit, e)
    attendre_erreur("artefact : raison vide", vide)
    attendre_erreur("artefact : mauvaise graine", lambda: valider(base, huit, e + 1))
    def meme_ordre():
        x = copy.deepcopy(base)
        cible = tuple(sorted((x[0]["premier"], x[0]["second"])))
        autre = next(j for j in x[1:] if tuple(sorted((j["premier"], j["second"]))) == cible)
        autre["premier"], autre["second"] = x[0]["premier"], x[0]["second"]
        coherence(x)
    attendre_erreur("artefact : paire vue deux fois dans le même ordre (cohérence)", meme_ordre)
    # artefact : ordre total parfait -> vraisemblance sans maximum, refus explicite ; a posteriori fini
    Wt = matrice_victoires(synth, sorted(huit))
    attendre_erreur("artefact : ordre total parfait, maximum de vraisemblance demandé", lambda: bradley_terry(Wt, None))
    th_t, se_t, _ = bradley_terry(Wt, SIGMA)
    ok_t = bool(np.all(np.isfinite(th_t)) and not fortement_connexe(Wt) and np.all(np.diff(th_t) < 0))
    resultats.append({"epreuve": "artefact : ordre total parfait, maximum a posteriori", "attendu": "forces finies, ordre respecté, non-connexité signalée",
                      "obtenu": f"forces {np.round(th_t, 3).tolist()}, connexe {fortement_connexe(Wt)}", "ok": ok_t})
    # artefact : juge qui suit toujours le premier présenté -> cohérence 0, réserve
    premier = copy.deepcopy(base)
    for j in premier:
        j["gagnant"] = j["premier"]
    c0, _, _ = coherence(premier)
    resultats.append({"epreuve": "artefact : juge qui donne toujours raison au premier présenté", "attendu": "cohérence 0 et réserve",
                      "obtenu": f"cohérence {c0}, réserves {lecture_coherence(c0)}", "ok": c0 == 0.0 and len(lecture_coherence(c0)) == 1})
    # artefact : juge parfaitement constant -> réserve « presque parfaite »
    resultats.append({"epreuve": "artefact : cohérence 1 d'un juge unique", "attendu": "réserve « presque parfaite »",
                      "obtenu": str(lecture_coherence(1.0)), "ok": any("presque parfaite" in r for r in lecture_coherence(1.0))})
    attendre_erreur("artefact : sortie existante (on n'écrase pas)", lambda: verifier_sortie_neuve(os.path.abspath(__file__)))
    return resultats


# ---------------------------------------------------------------- principal
def principal(chemin_paires, chemin_notes, chemin_fiches, chemin_sortie):
    verifier_sortie_neuve(chemin_sortie)
    sha = {p: empreinte(p) for p in (chemin_paires, chemin_notes, chemin_fiches, os.path.abspath(__file__))}
    e = int(sha[chemin_fiches][:16], 16)
    notes = json.load(open(chemin_notes, encoding="utf-8"))
    fiches = json.load(open(chemin_fiches, encoding="utf-8"))
    jugements = [json.loads(l) for l in open(chemin_paires, encoding="utf-8") if l.strip()]
    if notes["graine_des_paires"]["e"] != e:
        raise ErreurGarde("la graine des notes ne correspond pas au fichier des fiches")
    ids_fiches = {f["id"] for f in fiches}
    dans_sujet = set(notes["porte"]["dans_le_sujet"])
    if not dans_sujet <= ids_fiches or {x["id"] for x in notes["notes"]} != dans_sujet:
        raise ErreurGarde("notes et porte incohérentes avec les fiches")
    huit_recalc, niveau, ordre_sommes = huit_depuis_notes(notes, e)
    huit = sorted(notes["huit_premieres_par_identifiant"])
    if huit_recalc != huit:
        raise ErreurGarde(f"les huit des notes {huit} ne sont pas celles que donnent les sommes {huit_recalc}")

    epreuves = epreuves_des_gardes(jugements, huit, e)
    if not all(x["ok"] for x in epreuves):
        for x in epreuves:
            print(("OK   " if x["ok"] else "ÉCHEC ") + x["epreuve"] + " — " + x["obtenu"], file=sys.stderr)
        raise ErreurGarde("une garde n'a pas réagi comme attendu : arrêt sans sortie")

    valider(jugements, huit, e)
    c, conc, disc = coherence(jugements)
    reserves = lecture_coherence(c)
    part_premier = sum(1 for j in jugements if j["gagnant"] == j["premier"]) / len(jugements)
    items = huit
    W = matrice_victoires(jugements, items)
    victoires = {x: int(W[k].sum()) for k, x in enumerate(items)}
    connexe = fortement_connexe(W)
    if connexe:
        th_mle, se_mle, _ = bradley_terry(W, None)
        mle = {x: [round(float(th_mle[k]), 6), round(float(se_mle[k]), 6)] for k, x in enumerate(items)}
    else:
        mle = "inexistant : graphe des victoires non fortement connexe (un objet gagne ou perd toutes ses comparaisons) ; estimateur a posteriori déclaré"
        reserves.append("maximum de vraisemblance inexistant ; forces au maximum a posteriori, loi gaussienne centrée d'écart type "
                        f"{SIGMA} sur les log-forces")
    th, se, it = bradley_terry(W, SIGMA)
    sens = {}
    for s in SIGMAS_SENSIBILITE:
        ts = bradley_terry(W, s)[0]
        sens[str(s)] = [items[k] for k in np.argsort(-ts, kind="stable")]
    rangs = rangs_competition(th)
    # départage des égalités de force : originalité (règle de la consigne pour la sélection), puis somme, puis tirage
    note_par_id = {x["id"]: x for x in notes["notes"]}
    tirage = np.random.default_rng(np.random.SeedSequence(e).spawn(3)[1]).permutation(len(items))
    rang_tirage = {items[k]: int(r) for k, r in enumerate(np.argsort(tirage))}
    def cle_finale(k):
        x = items[k]
        return (rangs[k], -note_par_id[x]["originalite"][0], -note_par_id[x]["somme"], rang_tirage[x])
    ordre = [items[k] for k in sorted(range(len(items)), key=cle_finale)]
    egalites = []
    for r in sorted(set(rangs.tolist())):
        groupe = [items[k] for k in range(len(items)) if rangs[k] == r]
        if len(groupe) > 1:
            g_trie = [x for x in ordre if x in groupe]
            niveau_dep = "originalité"
            o = [note_par_id[x]["originalite"][0] for x in g_trie]
            if len(set(o)) < len(o):
                niveau_dep = "somme ou tirage"
            egalites.append({"rang": int(r), "ex_aequo": g_trie, "departage": niveau_dep,
                             "originalites": o, "sommes": [note_par_id[x]["somme"] for x in g_trie],
                             "face_a_face": [j["gagnant"] for j in jugements if {j["premier"], j["second"]} == set(groupe)] if len(groupe) == 2 else None})
            reserves.append(f"égalité de force au rang {int(r)} entre {', '.join(g_trie)} : départagée par {niveau_dep}")
    rangs_b, thetas_b = stabilite(jugements, items, e, SIGMA, N_REECHANTILLONNAGE)
    pos = {x: k for k, x in enumerate(items)}
    stab = {}
    for x in ordre:
        k = pos[x]
        stab[x] = {"rang_moyen": round(float(rangs_b[:, k].mean()), 3),
                   "part_rang_1": round(float((rangs_b[:, k] == 1).mean()), 4),
                   "part_rangs_1_a_3": round(float((rangs_b[:, k] <= 3).mean()), 4)}
    voisins = []
    for a, b in zip(ordre[:-1], ordre[1:]):
        ka, kb = pos[a], pos[b]
        voisins.append({"au_dessus": a, "au_dessous": b,
                        "p_bradley_terry": round(float(1.0 / (1.0 + np.exp(-(th[ka] - th[kb])))), 4),
                        "part_reechantillons_strictement_au_dessus": round(float((thetas_b[:, ka] > thetas_b[:, kb] + TOL_EGALITE).mean()), 4)})
    sortie = {
        "version": "v1",
        "ecrit_utc": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "script": os.path.abspath(__file__),
        "empreintes_sha256": sha,
        "versions": {"python": platform.python_version(), "numpy": np.__version__},
        "graine": {"e_hex": sha[chemin_fiches][:16], "e": e,
                   "ordre_de_presentation": "numpy.random.default_rng(numpy.random.SeedSequence(e)).permutation(56)",
                   "taches_derivees": "SeedSequence(e).spawn(3) : 0 rééchantillonnage, 1 départage, 2 cas sain"},
        "selection_des_huit": {"recalculee": huit_recalc, "niveau_du_departage_a_la_frontiere": niveau, "ordre_par_somme": ordre_sommes},
        "epreuves_des_gardes": epreuves,
        "coherence": {"valeur": c, "paires_concordantes": len(conc), "paires": len(conc) + len(disc),
                      "discordantes": disc, "seuil": SEUIL_COHERENCE, "seuil_presque_parfaite_declare": SEUIL_PRESQUE_PARFAITE},
        "part_des_jugements_gagnes_par_le_premier_presente": part_premier,
        "victoires_sur_14": victoires,
        "graphe_fortement_connexe": connexe,
        "maximum_de_vraisemblance": mle,
        "maximum_a_posteriori": {"sigma": SIGMA, "iterations": it,
                                 "log_forces_et_erreurs_types": {x: [round(float(th[k]), 6), round(float(se[k]), 6)] for k, x in enumerate(items)},
                                 "forces_normalisees_somme_1": {x: round(float(np.exp(th[k]) / np.exp(th).sum()), 6) for k, x in enumerate(items)}},
        "sensibilite_sigma_ordres": sens,
        "ordre_final": ordre,
        "egalites": egalites,
        "voisins_dans_l_ordre": voisins,
        "stabilite_par_reechantillonnage_des_paires": {"tirages": N_REECHANTILLONNAGE, "par_fiche": stab},
        "reserves": reserves,
    }
    with open(chemin_sortie, "x", encoding="utf-8") as f:
        json.dump(sortie, f, ensure_ascii=False, indent=1)
        f.write("\n")
    print(json.dumps({"ordre_final": ordre, "coherence": c, "reserves": reserves, "gardes_ok": all(x["ok"] for x in epreuves)}, ensure_ascii=False))


if __name__ == "__main__":
    if len(sys.argv) != 5:
        sys.exit(__doc__)
    try:
        principal(*sys.argv[1:])
    except ErreurGarde as err:
        sys.exit(f"ARRÊT (garde) : {err}")
