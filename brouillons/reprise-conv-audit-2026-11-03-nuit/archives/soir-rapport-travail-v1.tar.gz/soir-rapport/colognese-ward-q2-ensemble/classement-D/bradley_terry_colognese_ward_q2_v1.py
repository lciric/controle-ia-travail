"""Classement D, question 2 de Colognese et Ward : sélection des huit, ordre des paires, forces de Bradley-Terry.

Numpy seul, aucun modèle. Deux modes :
  ordre   : relit notes-v1.json, vérifie l'empreinte du fichier des fiches, refait la sélection des huit
            (somme, puis originalité, puis testable, puis outil, puis tirage reproductible), puis tire l'ordre
            des 56 présentations ; imprime tout ; n'écrit rien.
  forces  : refait « ordre », vérifie que paires-v1.jsonl suit exactement cet ordre, calcule la cohérence,
            les forces de Bradley-Terry (maximum de vraisemblance si il existe, sinon estimation régularisée
            déclarée), éprouve d'abord chaque garde sur un cas sain et sur des artefacts, et écrit
            bradley_terry_colognese_ward_q2_v1-sortie.json (refuse d'écraser un fichier existant).

Graines : numpy.random.SeedSequence (numpy >= 1.25), e = entier des 16 premiers hexadécimaux du sha256 du
fichier des fiches ; l'ordre des paires utilise SeedSequence(e) ; le tirage des égalités utilise le flux
enfant SeedSequence(e).spawn(1)[0].
"""

import hashlib
import itertools
import json
import os
import sys

import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
FICHES = "/home/claude/scratch/soir-rapport/colognese-ward-q2-ensemble/prep-v1/fiches-servies-v1.json"
SHA_FICHES_ATTENDU = "fe29f4fb70142ce1389b292b2331c5cc368c712f5a918d92721e9024bf850a10"
NOTES = os.path.join(ICI, "notes-v1.json")
PAIRES = os.path.join(ICI, "paires-v1.jsonl")
SORTIE = os.path.join(ICI, "bradley_terry_colognese_ward_q2_v1-sortie.json")
N_SELECTION = 8
SEUIL_COHERENCE = 0.8
SEUIL_PRESQUE_PARFAITE = 27 / 28  # au plus une paire discordante


class GardeErreur(Exception):
    """Toute anomalie d'entrée arrête le calcul : aucun repli silencieux."""


def sha256(chemin):
    h = hashlib.sha256()
    with open(chemin, "rb") as f:
        for bloc in iter(lambda: f.read(1 << 16), b""):
            h.update(bloc)
    return h.hexdigest()


def graine_e():
    s = sha256(FICHES)
    if s != SHA_FICHES_ATTENDU:
        raise GardeErreur(f"empreinte du fichier des fiches inattendue : {s}")
    return int(s[:16], 16), s


# ---------------------------------------------------------------- sélection
def selection(notes, e, n_sel=N_SELECTION):
    """Ordre lexicographique : somme, originalité, testable, outil (décroissants) ; le reste par tirage."""
    for k, v in notes.items():
        for c in ("originalite", "testable", "outil"):
            if v[c] not in (0, 1, 2, 3):
                raise GardeErreur(f"note hors de 0..3 : {k} {c}={v[c]}")
        if v["somme"] != v["originalite"] + v["testable"] + v["outil"]:
            raise GardeErreur(f"somme fausse : {k}")
    cle = lambda k: (notes[k]["somme"], notes[k]["originalite"], notes[k]["testable"], notes[k]["outil"])
    ids = sorted(notes, key=lambda k: tuple(-x for x in cle(k)) + (k,))
    # groupes à égalité sur la clé entière
    groupes = [list(g) for _, g in itertools.groupby(ids, key=cle)]
    ordre, tirage = [], None
    for g in groupes:
        if len(ordre) >= n_sel:
            break
        if len(ordre) + len(g) <= n_sel:
            ordre.extend(sorted(g))
            continue
        # le groupe chevauche la coupure : tirage reproductible sur le groupe trié par identifiant
        g = sorted(g)
        rng = np.random.default_rng(np.random.SeedSequence(e).spawn(1)[0])
        perm = rng.permutation(len(g))
        tire = [g[int(p)] for p in perm]
        besoin = n_sel - len(ordre)
        tirage = {"groupe_trie": g, "permutation": perm.tolist(), "ordre_tire": tire,
                  "retenues": tire[:besoin], "egales_non_retenues": tire[besoin:],
                  "cle_commune": dict(zip(("somme", "originalite", "testable", "outil"), cle(g[0])))}
        ordre.extend(tire[:besoin])
        break
    return ordre, tirage


def presentations(huit, e):
    """28 paires dans l'ordre canonique (identifiants triés), chacune dans les deux ordres : 56 présentations."""
    h = sorted(huit)
    canon = []
    for a, b in itertools.combinations(h, 2):
        canon.append((a, b))
        canon.append((b, a))
    perm = np.random.default_rng(np.random.SeedSequence(e)).permutation(len(canon))
    return [canon[int(p)] for p in perm], perm.tolist()


# ---------------------------------------------------------------- lecture des jugements
def lire_jugements(lignes, ordre_attendu, huit):
    jug = []
    for i, ligne in enumerate(lignes):
        ligne = ligne.strip()
        if not ligne:
            raise GardeErreur(f"ligne vide à la position {i}")
        try:
            d = json.loads(ligne)
        except json.JSONDecodeError as exc:
            raise GardeErreur(f"ligne {i} illisible : {exc}")
        jug.append(d)
    if len(jug) != len(ordre_attendu):
        raise GardeErreur(f"{len(jug)} jugements pour {len(ordre_attendu)} présentations attendues")
    vus = set()
    for i, (d, (a, b)) in enumerate(zip(jug, ordre_attendu)):
        if d.get("rang") != i:
            raise GardeErreur(f"rang {d.get('rang')} à la ligne {i}")
        if [d.get("A"), d.get("B")] != [a, b]:
            raise GardeErreur(f"ligne {i} : présentation {d.get('A')},{d.get('B')} au lieu de {a},{b}")
        if d.get("gagnant") not in (a, b):
            raise GardeErreur(f"ligne {i} : gagnant {d.get('gagnant')} hors de la paire")
        if (a, b) in vus:
            raise GardeErreur(f"présentation en double : {a},{b}")
        vus.add((a, b))
        for x in (a, b):
            if x not in huit:
                raise GardeErreur(f"identifiant inconnu : {x}")
    return jug


# ---------------------------------------------------------------- mesures
def matrice_victoires(jug, ids):
    idx = {k: i for i, k in enumerate(ids)}
    W = np.zeros((len(ids), len(ids)))
    for d in jug:
        g = d["gagnant"]
        p = d["B"] if g == d["A"] else d["A"]
        W[idx[g], idx[p]] += 1
    return W


def coherence(jug):
    par_paire = {}
    for d in jug:
        par_paire.setdefault(frozenset((d["A"], d["B"])), []).append(d["gagnant"])
    for k, v in par_paire.items():
        if len(v) != 2:
            raise GardeErreur(f"paire {sorted(k)} jugée {len(v)} fois au lieu de 2")
    conc = sum(1 for v in par_paire.values() if v[0] == v[1])
    discord = sorted(sorted(k) for k, v in par_paire.items() if v[0] != v[1])
    premier = sum(1 for d in jug if d["gagnant"] == d["A"]) / len(jug)
    return conc / len(par_paire), conc, len(par_paire), discord, premier


def fortement_connexe(W):
    """Condition de Ford : le graphe « i bat j » est fortement connexe ; sinon le maximum de vraisemblance n'existe pas."""
    n = W.shape[0]
    adj = W > 0
    def atteint(depart, A):
        vu = {depart}
        pile = [depart]
        while pile:
            u = pile.pop()
            for v in np.nonzero(A[u])[0]:
                if int(v) not in vu:
                    vu.add(int(v))
                    pile.append(int(v))
        return vu
    return len(atteint(0, adj)) == n and len(atteint(0, adj.T)) == n


def bradley_terry(W, pseudo=0.0, iters=100000, tol=1e-12):
    """Algorithme MM de Hunter (2004). pseudo > 0 : demi-victoire virtuelle ajoutée à chaque côté de chaque paire
    comparée (estimation régularisée, déclarée comme telle)."""
    W = W.astype(float).copy()
    N = W + W.T
    if pseudo > 0:
        W = W + pseudo * (N > 0)
        N = W + W.T
    n = W.shape[0]
    gains = W.sum(axis=1)
    p = np.ones(n)
    for it in range(iters):
        denom = np.array([sum(N[i, j] / (p[i] + p[j]) for j in range(n) if j != i and N[i, j] > 0) for i in range(n)])
        q = gains / denom
        q = q / np.exp(np.mean(np.log(np.maximum(q, 1e-300))))
        if np.max(np.abs(np.log(np.maximum(q, 1e-300)) - np.log(np.maximum(p, 1e-300)))) < tol:
            p = q
            break
        p = q
    else:
        raise GardeErreur("l'algorithme MM n'a pas convergé")
    return np.log(p), it


def erreurs_types(theta, W):
    """Écarts-types de Fisher sur les log-forces, contrainte somme nulle (pseudo-inverse)."""
    N = W + W.T
    n = len(theta)
    H = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            if i != j and N[i, j] > 0:
                pij = 1 / (1 + np.exp(theta[j] - theta[i]))
                v = N[i, j] * pij * (1 - pij)
                H[i, i] += v
                H[i, j] -= v
    cov = np.linalg.pinv(H)
    return np.sqrt(np.maximum(np.diag(cov), 0))


def triades_circulaires(W):
    """Nombre de triades intransitives dans la préférence majoritaire (égalité 1-1 : pas d'arc)."""
    n = W.shape[0]
    P = (W > W.T)
    c = 0
    for i, j, k in itertools.combinations(range(n), 3):
        if (P[i, j] and P[j, k] and P[k, i]) or (P[j, i] and P[k, j] and P[i, k]):
            c += 1
    return c


def analyser(jug, ids):
    W = matrice_victoires(jug, ids)
    coh, conc, npaires, discord, premier = coherence(jug)
    existe = fortement_connexe(W)
    if existe:
        theta, it = bradley_terry(W)
        methode = "maximum de vraisemblance (MM de Hunter)"
        se = erreurs_types(theta, W)
    else:
        theta, it = bradley_terry(W, pseudo=0.5)
        methode = ("RÉGULARISÉE : le maximum de vraisemblance n'existe pas (graphe des victoires non fortement "
                   "connexe) ; demi-victoire virtuelle ajoutée à chaque côté de chaque paire")
        se = erreurs_types(theta, W + 0.5 * ((W + W.T) > 0))
    reserves = []
    if coh < SEUIL_COHERENCE:
        reserves.append(f"cohérence {coh:.3f} sous 0,8")
    if coh >= SEUIL_PRESQUE_PARFAITE:
        reserves.append(f"cohérence {coh:.3f} presque parfaite d'un juge unique : elle mesure la mémoire du juge "
                        "entre les deux ordres plus que la stabilité du jugement")
    if not existe:
        reserves.append("forces régularisées (voir méthode)")
    if abs(premier - 0.5) > 0.2:
        reserves.append(f"biais de position : le premier présenté gagne {premier:.2f}")
    ordre = [ids[i] for i in np.argsort(-theta, kind="stable")]
    return {
        "methode": methode, "iterations": int(it), "mle_existe": bool(existe),
        "forces_log": {ids[i]: round(float(theta[i]), 4) for i in range(len(ids))},
        "ecarts_types_log": {ids[i]: round(float(se[i]), 4) for i in range(len(ids))},
        "victoires": {ids[i]: int(W[i].sum()) for i in range(len(ids))},
        "ordre_final": ordre,
        "coherence": round(coh, 4), "paires_concordantes": conc, "paires": npaires,
        "paires_discordantes": discord, "part_gagnees_par_le_premier_presente": round(premier, 4),
        "triades_circulaires_majoritaires": triades_circulaires(W),
        "reserves": reserves,
    }


# ---------------------------------------------------------------- épreuves des gardes (R5)
def _faux_jugements(ordre, gagnant_de):
    return [json.dumps({"rang": i, "A": a, "B": b, "gagnant": gagnant_de(a, b, i)}) for i, (a, b) in enumerate(ordre)]


def epreuves():
    res = {}
    ids = [f"X{i}" for i in range(8)]
    canon = []
    for a, b in itertools.combinations(ids, 2):
        canon += [(a, b), (b, a)]
    rng = np.random.default_rng(np.random.SeedSequence(20261103).spawn(2)[1])
    ordre = [canon[int(p)] for p in rng.permutation(len(canon))]
    vrai = {k: float(v) for k, v in zip(ids, np.linspace(1.5, -1.5, 8))}

    # cas sain : préférences tirées d'un modèle de Bradley-Terry connu, répétées 40 fois pour vérifier la récupération
    from math import exp
    def tirage(a, b, i):
        pa = 1 / (1 + exp(vrai[b] - vrai[a]))
        return a if rng.random() < pa else b
    Wtot = np.zeros((8, 8))
    for _ in range(40):
        jug = lire_jugements(_faux_jugements(ordre, tirage), ordre, set(ids))
        Wtot += matrice_victoires(jug, ids)
    theta, _ = bradley_terry(Wtot)
    corr = float(np.corrcoef(theta, [vrai[k] for k in ids])[0, 1])
    res["sain_recuperation"] = {"correlation_vraies_forces": round(corr, 4), "passe": corr > 0.95}

    # cas sain : un passage de 56 jugements cohérent, ordre strict sauf une inversion qui ferme un cycle
    # (X7 bat X0) : graphe fortement connexe, le maximum de vraisemblance existe
    rang = {k: i for i, k in enumerate(ids)}
    inverses = {frozenset(("X0", "X7"))}
    def presque(a, b, i):
        meilleur = a if rang[a] < rang[b] else b
        pire = b if meilleur == a else a
        return pire if frozenset((a, b)) in inverses else meilleur
    an = analyser(lire_jugements(_faux_jugements(ordre, presque), ordre, set(ids)), ids)
    res["sain_un_passage"] = {"mle_existe": an["mle_existe"], "coherence": an["coherence"],
                              "passe": an["mle_existe"] and an["coherence"] == 1.0 and an["ordre_final"][0] in ("X0", "X1")}

    # artefact : dominance totale -> le maximum de vraisemblance n'existe pas, régularisation déclarée
    def total(a, b, i):
        return a if rang[a] < rang[b] else b
    an = analyser(lire_jugements(_faux_jugements(ordre, total), ordre, set(ids)), ids)
    res["artefact_dominance_totale"] = {"mle_existe": an["mle_existe"], "reserves": an["reserves"],
                                        "passe": (not an["mle_existe"]) and any("RÉGULARISÉE" in an["methode"] for _ in [0])
                                        and any("presque parfaite" in r for r in an["reserves"])}

    # artefact : juge qui choisit toujours le premier présenté -> cohérence 0, réserve « sous 0,8 » et biais de position
    an = analyser(lire_jugements(_faux_jugements(ordre, lambda a, b, i: a), ordre, set(ids)), ids)
    res["artefact_biais_de_position"] = {"coherence": an["coherence"], "reserves": an["reserves"],
                                         "passe": an["coherence"] == 0.0 and any("sous 0,8" in r for r in an["reserves"])
                                         and any("biais de position" in r for r in an["reserves"])}

    # artefacts de fichier : chacun doit lever GardeErreur
    bons = _faux_jugements(ordre, presque)
    cas = {
        "gagnant_hors_paire": bons[:5] + [json.dumps({**json.loads(bons[5]), "gagnant": "X9"})] + bons[6:],
        "ordre_permute": [bons[1], bons[0]] + bons[2:],
        "jugement_manquant": bons[:-1],
        "ligne_illisible": bons[:3] + ["{pas du json"] + bons[4:],
        "presentation_en_double": bons[:10] + [json.dumps({**json.loads(bons[3]), "rang": 10})] + bons[11:],
        "ligne_vide": bons[:7] + [""] + bons[8:],
    }
    for nom, lignes in cas.items():
        try:
            lire_jugements(lignes, ordre, set(ids))
            res["artefact_" + nom] = {"passe": False, "detail": "aucune erreur levée"}
        except GardeErreur as exc:
            res["artefact_" + nom] = {"passe": True, "detail": str(exc)}

    # artefact de notes : somme fausse et note hors bornes
    for nom, notes in {
        "somme_fausse": {"A": {"originalite": 1, "testable": 1, "outil": 1, "somme": 4}},
        "note_hors_bornes": {"A": {"originalite": 4, "testable": 1, "outil": 1, "somme": 6}},
    }.items():
        try:
            selection(notes, 1, 1)
            res["artefact_" + nom] = {"passe": False, "detail": "aucune erreur levée"}
        except GardeErreur as exc:
            res["artefact_" + nom] = {"passe": True, "detail": str(exc)}

    # cas sain de la sélection : égalité à la coupure -> tirage reproductible, identique à deux appels
    notes = {f"F{i}": {"originalite": 1, "testable": 2, "outil": 3, "somme": 6} for i in range(5)}
    notes["G"] = {"originalite": 2, "testable": 1, "outil": 3, "somme": 6}
    s1, t1 = selection(notes, 12345, 3)
    s2, _ = selection(notes, 12345, 3)
    res["sain_selection_egalites"] = {"selection": s1, "passe": s1 == s2 and s1[0] == "G" and t1 is not None and len(s1) == 3}
    return res


# ---------------------------------------------------------------- principal
def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "ordre"
    e, sfi = graine_e()
    with open(NOTES, encoding="utf-8") as f:
        notes_doc = json.load(f)
    notes = notes_doc["notes"]
    huit, tirage = selection(notes, e)
    ordre, perm = presentations(huit, e)
    info = {"e": e, "sha256_fiches": sfi, "sha256_notes": sha256(NOTES), "numpy": np.__version__,
            "huit_dans_l_ordre_de_selection": huit, "tirage_des_egalites": tirage,
            "permutation_56": perm, "presentations": [{"rang": i, "A": a, "B": b} for i, (a, b) in enumerate(ordre)]}
    if mode == "ordre":
        print(json.dumps(info, ensure_ascii=False, indent=1))
        return
    if mode != "forces":
        raise SystemExit("mode inconnu")
    if os.path.exists(SORTIE):
        raise GardeErreur(f"{SORTIE} existe déjà : on n'écrase jamais (R12)")
    ep = epreuves()
    if not all(v["passe"] for v in ep.values()):
        raise GardeErreur("une épreuve de garde a échoué : " + json.dumps(ep, ensure_ascii=False))
    with open(PAIRES, encoding="utf-8") as f:
        lignes = f.read().splitlines()
    jug = lire_jugements(lignes, ordre, set(huit))
    res = analyser(jug, sorted(huit))
    sortie = {"script": os.path.basename(__file__), "sha256_script": sha256(os.path.abspath(__file__)),
              "sha256_paires": sha256(PAIRES), **info, "epreuves_des_gardes": ep, "resultat": res}
    with open(SORTIE, "x", encoding="utf-8") as f:
        json.dump(sortie, f, ensure_ascii=False, indent=1)
    print(json.dumps(res, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
