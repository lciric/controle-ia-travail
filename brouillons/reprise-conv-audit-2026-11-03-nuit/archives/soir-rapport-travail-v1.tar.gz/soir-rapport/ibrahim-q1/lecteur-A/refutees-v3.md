# Réfutées — Ibrahim, question 1 — lecteur A — v3 (avec la source 3)

Écrit le 3 novembre 2026 vers 20:12 UTC (`date -u`). Fiches : `fiches-normalisees-v3.json` (même dossier). La v2 (`refutees-v2.md`) n'est pas modifiée ; son contenu est repris ci-dessous tel quel, puis la source 3 est ajoutée.
Règle inchangée : une fiche n'est réfutée que si une source citée contredit son énoncé central, ou si elle se contredit elle-même ; jamais par accord ou désaccord des modèles. Les 38 éléments de la source 3 arrivent sans sortie des juges : aucune objection ne leur est jointe. Aucun appel `WebFetch` : aucune source primaire hors des pièces n'est citée contre un énoncé central. Pièces relues pour vérifier : pièce Ibrahim (`piece-ibrahim-v1.md`, sha256 `4e3851e3…`) et pièce sycophancie publique (`piece-sycophancie-publique-v1.md`, sha256 `9e424a02…`).

## Résultat : aucune fiche réfutée (0 sur 28 ; 0 sur 38 éléments de la source 3)

---

## Repris de la v2 (cas de la source 2, inchangés)

1. **« Point fixe v₀ » (deux éléments, fondus dans I-003, I-006 et I-014).** La pièce sycophancie publique, §1, écrit Δ = g·(c − v₀), où la note se déplace d'une part de sa distance « à un point fixe propre au cadre ». Le point fixe est donc c, et v₀ est la note sans pression. Deux éléments appellent v₀ « le point fixe » : la source citée contredit cette identification. Ce n'est pas une réfutation, pour trois raisons :
   - dans I-003, la partie fondue est la mesure qui tue sur g, indépendante de cette étiquette ;
   - dans I-006, l'élément fautif n'apporte qu'une prédiction, sans mesure qui tue ;
   - dans I-014, l'énoncé et la mesure qui tue principale portent sur les taux bruts des deux cellules. Le Δv₀ mal nommé n'y est qu'une variante, et la pièce ne contredit pas l'hypothèse (effet de la persona concentré dans la cellule sociale).
   À corriger avant toute écriture.
2. **« Jugées en entier » (I-017, et une variante de I-001).** La pièce sycophancie publique, §3, dit seulement que les réponses de l'essai initial étaient tronquées à 300 caractères avant jugement, et que l'ablation ne s'est pas reproduite en réplication. Elle n'écrit pas que la réplication les a jugées en entier. Le détail ne porte pas l'énoncé central.
3. **« +11 points » comme ordre de grandeur pour Loving (I-014).** La pièce Ibrahim, §1.1 et §4, dit que la portée du chiffre n'est pas établie. Il est employé comme ordre de grandeur et déclaré supposé : ce n'est pas une contradiction.

Observations v2 (non réfutantes), reprises : méthode de la mentore « à une seule dose » non établie par la pièce Ibrahim §1.1 (I-003, I-006, I-009) ; « jamais mesurée » à traiter comme une question (R8) ; couplage et découplage (I-018) non jugeables sans remontée de capitulation (I-015).

---

## Ajouts de la source 3 (cas examinés, non réfutants ; écrits dans les notes des fiches qu'ils touchent)

4. **« Point fixe v₀ », de nouveau (quatre éléments : volets fondus dans I-006, I-009, I-022, I-028).** Même défaut qu'en v2 : la pièce sycophancie §1 nomme c le point fixe. Un élément mesure même « v₀ sous éloge », ce qui contredit la définition (v₀ est la note sans pression). Ce n'est pas une réfutation :
   - dans I-009, les mesures qui tuent fondues portent sur g ;
   - dans I-006, l'élément fautif n'apporte qu'une prédiction ;
   - dans I-022, l'énoncé suit l'élément qui emploie c correctement, et la variante mal nommée est rapportée avec son défaut ;
   - dans I-028, la condition sur « v₀ » est secondaire, la mesure primaire porte sur g.
   À corriger avant toute écriture.
5. **Chiffres de Lazar cités par la source 3, vérifiés sur la pièce sycophancie publique.** Tous conformes :
   - g ≈ 0,7 (0,718 et 0,678) et g sous éloge 0,276 à la dose la plus douce (§1) ;
   - points fixes 2,60, puis 1,92 et 2,03 sous 3,11 sans les 14 items à refus (§1) ;
   - greffe des couches 13 à 25 à 65 % [42 ; 87], et 2 % [−22 ; 28] pour un autre item sous pression (§3).
   Une seule réserve : sous éloge, g croît avec la dose (0,276 → 0,797). Le prérequis « la base reproduit g ≈ 0,7 », qui ne nomme ni cadre ni dose (I-006, I-022), est donc à préciser. Ce n'est pas une contradiction de l'énoncé central.
6. **−15,06 points pris comme valeur de départ de Loving (I-001, I-023).** La pièce Ibrahim §1.1 donne ce chiffre pour le modèle chaleureux du papier (ajustement supervisé, prépublication v2, tableau E5), et §4 le dit non revérifié dans *Nature*. Les éléments l'emploient comme repère ou comme valeur supposée pour une persona d'Open Character Training. C'est une hypothèse de départ, pas une contradiction.
7. **« +11 points » annulé par le RL (I-020).** Deux éléments prédisent l'annulation des « +11 points d'erreur des modèles chaleureux ». La portée du chiffre n'est pas établie (pièce Ibrahim §1.1 et §4) ; il sert d'ordre de grandeur supposé. Ce n'est pas une contradiction.
8. **Cohérence interne vérifiée.** Pour I-020, l'intervalle de D_I et D_S, [−20 ; −6], est bien celui qui découle des intervalles supposés de F et de I ou S (calcul refait). Pour I-028, l'intervalle de Δg_orig (+0,22 à +0,47) découle bien de 0,276 → [0,50 ; 0,75]. Aucun élément ne se contredit lui-même.

## Observations du lecteur à vérifier avant d'écrire devant la mentore (non réfutantes), source 3

- **« Première mesure directe » de la persistance (fondu dans I-002), « aucune mesure de persistance n'est publiée » (I-021).** La pièce Ibrahim §2 dit seulement qu'Open Character Training ne traite pas la persistance. La pièce §4 ajoute qu'aucune chaîne publique avec une étape d'apprentissage par renforcement n'a été lue. Zone vierge à traiter comme une question (R8).
- **« Les travaux de la mentore mesurent la sycophancie par condition et par taux » (fondu dans I-009 et I-022).** La pièce Ibrahim §1.1 rapporte des écarts de justesse par condition. L'affirmation qu'ils « confondent gain et point fixe » est une lecture de la source. La mentore pourrait la contester à partir de ses propres papiers (même réserve qu'en v2).
- **Appuis tirés de la « pièce Nos résultats » (§4, §6, §7 ; I-020, I-025, I-027).** Ils sont rapportés tels que cités, non vérifiés par le lecteur : cette pièce n'est pas dans ses entrées.
