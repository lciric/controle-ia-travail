# Hors sujet — Ibrahim, question 1 — lecteur A — v1

Écrit le 3 novembre 2026 vers 13:12 UTC (`date -u`). Fiches : `fiches-normalisees-v1.json` (même dossier).
Critère (consigne) : classement « I » si l'idée répond à la question de la mentore ou touche ce qu'elle fait ; « hors sujet » sinon. Une idée **répond** si elle donne le projet choisi, la première expérience (ce qu'on entraîne ou mesure), le résultat attendu et une chose qui rendrait le résultat trompeur ; s'il en manque, elle reste gardée et le manque est écrit dans la fiche.

## Résultat : aucune idée hors sujet (0 sur 17 idées lues ; 0 sur 10 fiches)

Chacune des 17 idées porte sur la direction visée, ou sur l'instrument de sa première expérience. Cette direction : la persistance, après un apprentissage par renforcement, d'une persona installée par entraînement de caractère, et la sycophancie.

| Fiche | Pourquoi « I » | Éléments manquants (écrits dans la fiche) |
|---|---|---|
| I-001 | Conservation, après renforcement, du coût factuel de la persona (papier sur la chaleur) | aucun |
| I-002 | Persistance de la persona sous RLVR : la direction elle-même | aucun |
| I-003 | Sycophancie sous pression (loi d'attraction) avant et après renforcement, sur points de contrôle à persona ; aucun travail de la mentore invoqué | aucun |
| I-004 | Conservation de la sycophancie sociale (approbation injustifiée) après renforcement | aucun |
| I-005 | Sycophancie factuelle de la persona Sycophantic, sans entraînement (porte de la première expérience) | aucun |
| I-006 | Ce que la persona déplace dans la sycophancie sous pression (gain ou point fixe) | aucun |
| I-007 | Validité des instruments de la première expérience (classifieur de persona, juge de sycophancie) | résultat attendu |
| I-009 | Rôle de l'optimisation par préférences dans la sycophancie (limite déclarée du papier sur la chaleur) | résultat attendu |
| I-010 | Amplification de la persona par un renforcement à préférences (reportée par sa source) | résultat attendu |
| I-008 | Sélectivité sociale ou factuelle de l'effet persona × renforcement (taxonomie) | aucun |

Aucune annexe d'idées hors sujet n'est donc à joindre.
