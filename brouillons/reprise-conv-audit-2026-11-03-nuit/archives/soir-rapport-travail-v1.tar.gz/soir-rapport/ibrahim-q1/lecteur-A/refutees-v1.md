# Réfutées — Ibrahim, question 1 — lecteur A — v1

Écrit le 3 novembre 2026 vers 13:12 UTC (`date -u`). Fiches : `fiches-normalisees-v1.json` (même dossier).
Règle appliquée (protocole des mentors du soir, étape A, et protocole Heimersheim v1, section 2) : une fiche n'est réfutée que si une source citée (point d'une pièce, ou source primaire ouverte et citée avec page ou section) contredit son énoncé central, ou si elle se contredit elle-même. Jamais par accord ou désaccord des modèles. La version jugée est la plus récente de chaque idée.

## Résultat : aucune fiche réfutée (0 sur 10)

Aucune source primaire hors des pièces n'est citée par les objections ; aucune page n'a donc été ouverte (aucun appel `WebFetch`).

## Cas examinés : erreurs d'une version antérieure, corrigées dans la version retenue (pas de réfutation)

1. **I-006.** Une version antérieure confondait v₀ (note de l'item sans pression) et c (point fixe) dans Δ = g·(c − v₀). La pièce sycophancie publique, §1, définit c comme « un point fixe propre au cadre » : elle contredisait donc l'énoncé de cette version. La version retenue reconnaît l'erreur et porte ses hypothèses sur c et g, avec v₀ en covariable. Gardée.
2. **I-005.** Une version antérieure prenait « +11 points » comme niveau attendu sur Llama-3.1-8B-Instruct et posait H_A à « ≥ +11 » contre un seuil opérationnel de 5. Or la pièce Ibrahim, §1.1 et §4, dit que la portée du « +11 » n'est pas établie (pour ce modèle seul ou pour l'ensemble). La version retenue retire ce chiffre comme attendu. Gardée.
3. **I-002 et I-003.** Une version antérieure disait qu'une issue « réfute l'a priori de R8 ». La pièce sycophancie publique, §2, place R8 sur la chaîne Tülu 3. La pièce Ibrahim, §2, montre que les points de contrôle d'Open Character Training sont déjà passés par une optimisation directe des préférences. Dans la version retenue, cette prétention est retirée : il ne reste qu'un test de généralité, ou une invariance locale. Gardées.
4. **I-008.** Une version antérieure attendait ΔS = +12 points. L'objection cite le plus grand effet du papier sur la chaleur (11,9 points, en ajustement supervisé avec tristesse, pièce Ibrahim, §1.1). Ce n'est pas une contradiction : un effet d'interaction attendu n'est pas contredit par la taille d'un effet d'ajustement supervisé. L'attendu est retiré de toute façon (attendu 0). Gardée.
5. **I-006.** Une version antérieure annonçait un coût marginal faible, en réutilisant les générations de l'expérience de persistance. Elle se contredisait, car cette expérience ne produit pas le protocole dosé ; sa source l'a reconnu. La version retenue a son propre protocole. Gardée.
6. **I-001 et I-004.** Des versions antérieures disaient mesurer une « conservation » avec un contraste lu après renforcement seulement. C'était incohérent avec leur propre question. Les versions retenues mesurent un contraste longitudinal (avant et après). Gardées.

## Observations du lecteur sur les versions retenues (non réfutantes, écrites dans les notes des fiches)

- **I-005** : l'attendu de +3 à +8 points chevauche le seuil de 5 points ; l'issue attendue serait plutôt « indécis ». Autre point : la phrase « points fixes 2,60 contre 1,92/2,03 » ne suit pas la pièce sycophancie publique, §1. Dans la pièce, 2,60 est la moyenne sans pression, que les points fixes « rejoignent » à la dose forte (2,367 sous critique et 2,475 sous éloge).
- **I-006** : à volume ×4, la demi-largeur annoncée (≈ 0,1) égale la marge d'équivalence |Δg| < 0,1 de l'une des variantes. Sa branche « point fixe » y serait pratiquement inconfirmable.
- **I-009** : « réfute la cause désignée par les experts » repose sur une seule lecture (g) d'un construit que la pièce Ibrahim dit fragmenté (§1.2). La source borne elle-même la portée à ce modèle et à cette récompense.

Aucune de ces observations ne contredit l'énoncé central d'une fiche : toutes restent gardées.
