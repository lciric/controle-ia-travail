# Réfutées — Ibrahim, question 1 — lecteur A — v2 (avec la source 2)

Écrit le 3 novembre 2026 vers 14:46 UTC (`date -u`). Fiches : `fiches-normalisees-v2.json` (même dossier). La v1 (`refutees-v1.md`) n'est pas modifiée ; ses six cas restent valables tels quels.
Règle inchangée : une fiche n'est réfutée que si une source citée contredit son énoncé central, ou si elle se contredit elle-même ; jamais par accord ou désaccord des modèles. Les éléments de la source 2 arrivent sans critique (paquet sans sortie des juges) : aucune objection ne leur est jointe. Aucune source primaire hors des pièces n'est citée ; aucune page ouverte (aucun appel `WebFetch`).

## Résultat : aucune fiche réfutée (0 sur 19)

## Cas examinés dans la source 2 (non réfutants ; écrits dans les notes des fiches quand ils les touchent)

1. **« Point fixe v₀ » (deux éléments, fondus dans I-003, I-006 et I-014).** La pièce sycophancie publique, §1, écrit Δ = g·(c − v₀), où la note se déplace d'une part de sa distance « à un point fixe propre au cadre ». Le point fixe est donc c, et v₀ est la note sans pression. Deux éléments appellent v₀ « le point fixe » : la source citée contredit cette identification. Ce n'est pas une réfutation, pour trois raisons :
   - dans I-003, la partie fondue est la mesure qui tue sur g, indépendante de cette étiquette ;
   - dans I-006, l'élément fautif n'apporte qu'une prédiction, sans mesure qui tue ;
   - dans I-014, l'énoncé et la mesure qui tue principale portent sur les taux bruts des deux cellules. Le Δv₀ mal nommé n'y est qu'une variante, et la pièce ne contredit pas l'hypothèse (effet de la persona concentré dans la cellule sociale).
   À corriger avant toute écriture.
2. **« Jugées en entier » (I-017, et une variante de I-001).** La pièce sycophancie publique, §3, dit seulement que les réponses de l'essai initial étaient tronquées à 300 caractères avant jugement, et que l'ablation ne s'est pas reproduite en réplication. Elle n'écrit pas que la réplication les a jugées en entier. Le détail ne porte pas l'énoncé central.
3. **« +11 points » comme ordre de grandeur pour Loving (I-014).** La pièce Ibrahim, §1.1 et §4, dit que la portée du chiffre n'est pas établie. Il est employé comme ordre de grandeur et déclaré supposé : ce n'est pas une contradiction.

## Observations du lecteur à vérifier avant d'écrire devant la mentore (non réfutantes)

- **Méthode de la mentore.** Des éléments fondus dans I-003, I-006 et I-009 affirment que la mentore « mesure la sycophancie par un écart de justesse ou un taux à une seule dose, ce qui confond g et c ». La pièce Ibrahim, §1.1, rapporte bien des écarts de justesse, mais ne dit rien de doses. L'affirmation n'y est donc pas établie : c'est une affirmation qu'elle pourrait contredire à partir de ses propres papiers.
- **« Jamais mesurée ».** Un élément écrit que la sycophancie de la persona Sycophantic « n'a jamais été mesurée ». La pièce Ibrahim, §2, dit seulement qu'Open Character Training ne l'a pas mesurée, d'après le rapport. Une autre formulation, plus juste, dit « reste à vérifier si elle l'a été ailleurs ». C'est une zone vierge à traiter comme une question (R8).
- **Couplage et découplage (I-018).** Ce sont des prédictions opposées sur la même mesure. La fiche n'est pas jugeable si la remontée de capitulation (I-015) n'existe pas.
