#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Forces de Bradley-Terry, cohérence entre les deux ordres et gardes éprouvées.

Classement D, question 1 de Lujain Ibrahim, v1. numpy seul, aucun modèle.

Usage (avec -I, depuis un dossier quelconque, chemins en arguments) :
  nice -n 10 python3 -I bradley_terry_ibrahim_q1_v1.py \
      --notes notes-v1.json --paires paires-v1.jsonl \
      --fiches .../prep-v1/fiches-servies-v1.json \
      --sortie bradley_terry_ibrahim_q1_v1-sortie.json

Les gardes sont éprouvées sur un cas sain et sur des artefacts AVANT le calcul
réel ; un seul échec arrête tout sans rien écrire (aucun repli silencieux, R5).
"""
import argparse
import copy
import datetime
import hashlib
import itertools
import json
import platform
import sys

import numpy as np

SHA_FICHES_ATTENDU = "46efe88c21e33f6f99461f1c2d9343d4fcc3b635b938e668a317edd715f3f462"
LAMBDA_PRINCIPAL = 1.0
LAMBDAS_SENSIBILITE = (0.1, 1.0, 10.0)
SEUIL_COHERENCE = 0.8
SEUIL_PRESQUE_PARFAITE = 0.95


class GardeEchec(Exception):
    """Une garde a refusé l'entrée ou le calcul."""


# ---------------------------------------------------------------- entrées

def sha256_fichier(chemin):
    h = hashlib.sha256()
    with open(chemin, "rb") as f:
        for bloc in iter(lambda: f.read(1 << 16), b""):
            h.update(bloc)
    return h.hexdigest()


def verifier_empreinte(chemin, attendu):
    obtenu = sha256_fichier(chemin)
    if obtenu != attendu:
        raise GardeEchec(f"empreinte de {chemin} : {obtenu} au lieu de {attendu}")
    return obtenu


def graine_depuis_empreinte(sha_hex):
    return int(sha_hex[:16], 16)


def calendrier(items, e):
    """Indice 2k : (A = i, B = j) ; 2k + 1 : (A = j, B = i), pour la k-ième paire i < j."""
    canon = []
    for i, j in itertools.combinations(range(len(items)), 2):
        canon.append((items[i], items[j]))
        canon.append((items[j], items[i]))
    perm = np.random.default_rng(np.random.SeedSequence(e)).permutation(len(canon))
    return canon, perm


def verifier_paires(lignes, items, canon, perm):
    n = len(canon)
    if len(lignes) != n:
        raise GardeEchec(f"{len(lignes)} jugements lus, {n} attendus")
    ts, vus = [], set()
    for l in lignes:
        for cle in ("t", "indice_canonique", "A", "B", "gagnant"):
            if cle not in l:
                raise GardeEchec(f"clé {cle} absente (présentation {l.get('t')})")
        t = l["t"]
        if not isinstance(t, int) or isinstance(t, bool) or not 1 <= t <= n:
            raise GardeEchec(f"numéro de présentation invalide : {t!r}")
        ts.append(t)
        a, b, g = l["A"], l["B"], l["gagnant"]
        if a not in items or b not in items:
            raise GardeEchec(f"identifiant inconnu à la présentation {t} : {a}, {b}")
        if a == b:
            raise GardeEchec(f"paire réflexive à la présentation {t}")
        if g not in (a, b):
            raise GardeEchec(f"gagnant {g} hors de la paire à la présentation {t}")
        k = int(perm[t - 1])
        if l["indice_canonique"] != k:
            raise GardeEchec(f"indice canonique {l['indice_canonique']} au lieu de {k} (présentation {t})")
        if (a, b) != canon[k]:
            raise GardeEchec(f"ordre ({a}, {b}) différent du tirage {canon[k]} (présentation {t})")
        if (a, b) in vus:
            raise GardeEchec(f"présentation ({a}, {b}) en double")
        vus.add((a, b))
    if sorted(ts) != list(range(1, n + 1)):
        raise GardeEchec("numéros de présentation en double ou manquants")
    for i, j in itertools.combinations(items, 2):
        if (i, j) not in vus or (j, i) not in vus:
            raise GardeEchec(f"paire {i}–{j} sans ses deux ordres")


# ---------------------------------------------------------------- calcul

def verifier_fini(x):
    if not np.all(np.isfinite(x)):
        raise GardeEchec("valeur non finie dans les forces")


def matrice_victoires(lignes, items):
    idx = {x: i for i, x in enumerate(items)}
    W = np.zeros((len(items), len(items)))
    for l in lignes:
        g = l["gagnant"]
        p = l["B"] if g == l["A"] else l["A"]
        W[idx[g], idx[p]] += 1
    return W


def fortement_connexe(W):
    """Condition d'existence (finie) de l'estimateur du maximum de vraisemblance de
    Bradley-Terry (Ford 1957 ; Hunter 2004) : le graphe « i a battu j au moins une
    fois » est fortement connexe."""
    m = W.shape[0]
    adj = W > 0

    def tout_atteint(a):
        vu = np.zeros(m, bool)
        vu[0] = True
        pile = [0]
        while pile:
            u = pile.pop()
            for v in np.nonzero(a[u])[0]:
                if not vu[v]:
                    vu[v] = True
                    pile.append(v)
        return bool(vu.all())

    return tout_atteint(adj) and tout_atteint(adj.T)


def bt_mm(W, max_iter=100000, tol=1e-12):
    """Maximum de vraisemblance, algorithme MM de Hunter (2004). Refuse si
    l'estimateur n'existe pas ou si l'algorithme ne converge pas."""
    if not fortement_connexe(W):
        raise GardeEchec("maximum de vraisemblance inexistant (séparation) : MM refusé")
    N = W + W.T
    victoires = W.sum(axis=1)
    p = np.ones(W.shape[0])
    for it in range(1, max_iter + 1):
        denom = (N / (p[:, None] + p[None, :])).sum(axis=1)
        q = victoires / denom
        q = q / np.exp(np.mean(np.log(q)))
        if np.max(np.abs(np.log(q) - np.log(p))) < tol:
            theta = np.log(q)
            verifier_fini(theta)
            return theta, it
        p = q
    raise GardeEchec(f"MM non convergé en {max_iter} itérations")


def log_post(W, theta, lam):
    d = theta[:, None] - theta[None, :]
    return float((W * (-np.logaddexp(0.0, -d))).sum() - 0.5 * lam * float((theta ** 2).sum()))


def bt_penalise(W, lam, max_iter=500, tol=1e-12):
    """Maximum a posteriori sous une loi a priori normale N(0, 1/lam) sur les
    log-forces ; Newton avec recherche linéaire. Existe pour tout lam > 0."""
    if not lam > 0:
        raise GardeEchec("lambda doit être strictement positif")
    m = W.shape[0]
    N = W + W.T
    theta = np.zeros(m)
    for it in range(1, max_iter + 1):
        d = theta[:, None] - theta[None, :]
        s = 1.0 / (1.0 + np.exp(-d))
        grad = (W - N * s).sum(axis=1) - lam * theta
        poids = N * s * (1.0 - s)
        H = poids.copy()
        H[np.diag_indices(m)] = -poids.sum(axis=1) - lam
        pas = np.linalg.solve(H, grad)
        base = log_post(W, theta, lam)
        t = 1.0
        while log_post(W, theta - t * pas, lam) < base - 1e-14 and t > 1e-12:
            t /= 2.0
        theta = theta - t * pas
        if np.max(np.abs(t * pas)) < tol or np.max(np.abs(grad)) < 1e-11:
            verifier_fini(theta)
            return theta, it
    raise GardeEchec(f"Newton non convergé en {max_iter} itérations")


def coherence(lignes, items):
    gag = {}
    for l in lignes:
        gag.setdefault(frozenset((l["A"], l["B"])), []).append(l["gagnant"])
    attendu = len(items) * (len(items) - 1) // 2
    if len(gag) != attendu or any(len(v) != 2 for v in gag.values()):
        raise GardeEchec("cohérence : chaque paire doit avoir exactement deux jugements")
    disc = sorted(sorted(k) for k, v in gag.items() if v[0] != v[1])
    return (attendu - len(disc)) / attendu, attendu - len(disc), attendu, disc


def ordre_depuis(theta, items):
    # tri par force décroissante ; égalité exacte : ordre des identifiants (déclaré)
    return [items[i] for i in sorted(range(len(items)), key=lambda i: (-theta[i], items[i]))]


def triades_intransitives(W, items):
    m = len(items)
    net = W - W.T
    cycles, indecises = [], 0
    for i, j, k in itertools.combinations(range(m), 3):
        paires = [(i, j), (j, k), (i, k)]
        if any(net[a, b] == 0 for a, b in paires):
            indecises += 1
            continue
        bat = lambda a, b: net[a, b] > 0
        if (bat(i, j) and bat(j, k) and bat(k, i)) or (bat(j, i) and bat(k, j) and bat(i, k)):
            cycles.append([items[i], items[j], items[k]])
    return cycles, indecises


def tau_kendall(ordre1, ordre2):
    r2 = {x: i for i, x in enumerate(ordre2)}
    c = d = 0
    for a, b in itertools.combinations(ordre1, 2):
        if r2[a] < r2[b]:
            c += 1
        else:
            d += 1
    return (c - d) / (c + d)


def classer_par_somme(notes):
    return sorted(notes, key=lambda n: (-n["somme"], -n["originalite"], n["id"]))


# ---------------------------------------------------------------- gardes éprouvées

def eprouver_gardes(items, e, chemin_fiches):
    res = []

    def consigner(nom, attendu, fonction):
        try:
            obtenu = fonction()
            ok = attendu == "passe"
            detail = obtenu if isinstance(obtenu, str) else "passe"
        except GardeEchec as exc:
            ok = attendu == "refus"
            detail = f"refus : {exc}"
        res.append({"nom": nom, "attendu": attendu, "obtenu": detail, "reussi": ok})

    canon, perm = calendrier(items, e)
    rng = np.random.default_rng(np.random.SeedSequence(e, spawn_key=(2,)))
    saines = []
    for t, k in enumerate(perm, 1):
        a, b = canon[int(k)]
        saines.append({"t": t, "indice_canonique": int(k), "A": a, "B": b,
                       "gagnant": a if rng.random() < 0.5 else b})

    consigner("cas sain : 56 jugements conformes au tirage", "passe",
              lambda: verifier_paires(saines, items, canon, perm))

    def artefact(modif):
        lignes = copy.deepcopy(saines)
        modif(lignes)
        return lambda: verifier_paires(lignes, items, canon, perm)

    consigner("artefact : une ligne manquante", "refus", artefact(lambda L: L.pop(10)))
    consigner("artefact : une ligne en double", "refus",
              artefact(lambda L: L.__setitem__(5, copy.deepcopy(L[4]))))
    consigner("artefact : identifiant inconnu", "refus",
              artefact(lambda L: L[3].update({"A": "IB-99"})))
    consigner("artefact : gagnant hors de la paire", "refus",
              artefact(lambda L: L[7].update({"gagnant": next(x for x in items if x not in (L[7]["A"], L[7]["B"]))})))
    consigner("artefact : ordre A/B inversé par rapport au tirage", "refus",
              artefact(lambda L: L[12].update({"A": L[12]["B"], "B": L[12]["A"]})))
    consigner("artefact : indice canonique faux", "refus",
              artefact(lambda L: L[20].update({"indice_canonique": (L[20]["indice_canonique"] + 1) % 56})))
    consigner("artefact : clé « gagnant » absente", "refus",
              artefact(lambda L: L[30].pop("gagnant")))

    consigner("empreinte des fiches : valeur attendue", "passe",
              lambda: (verifier_empreinte(chemin_fiches, SHA_FICHES_ATTENDU), "passe")[1])
    consigner("artefact : empreinte des fiches fausse", "refus",
              lambda: verifier_empreinte(chemin_fiches, "0" * 64))

    # Bradley-Terry, cas sain : forces connues, 200 comparaisons par paire
    rng2 = np.random.default_rng(np.random.SeedSequence(e, spawn_key=(1,)))
    vrai = np.linspace(1.5, -1.5, len(items))
    m = len(items)
    Ws = np.zeros((m, m))
    for i, j in itertools.combinations(range(m), 2):
        g = rng2.binomial(200, 1.0 / (1.0 + np.exp(-(vrai[i] - vrai[j]))))
        Ws[i, j], Ws[j, i] = g, 200 - g

    def sain_bt():
        th, _ = bt_mm(Ws)
        th = th - th.mean()
        if list(np.argsort(-th)) != list(range(m)):
            raise GardeEchec("cas sain : ordre des forces connues non retrouvé")
        if np.max(np.abs(th - (vrai - vrai.mean()))) >= 0.3:
            raise GardeEchec("cas sain : écart aux forces connues ≥ 0,3")
        thp, _ = bt_penalise(Ws, 1e-6)
        if np.max(np.abs((thp - thp.mean()) - th)) >= 1e-3:
            raise GardeEchec("cas sain : pénalisée (lambda = 1e-6) loin du maximum de vraisemblance")
        return f"passe (écart maximal {np.max(np.abs(th - (vrai - vrai.mean()))):.3f})"

    consigner("cas sain Bradley-Terry : forces connues retrouvées", "passe", sain_bt)

    # séparation parfaite : ordre linéaire, deux ordres concordants
    Wsep = np.zeros((m, m))
    for i, j in itertools.combinations(range(m), 2):
        Wsep[i, j] = 2
    consigner("artefact : séparation parfaite, maximum de vraisemblance refusé", "refus",
              lambda: bt_mm(Wsep))

    def sep_penalise():
        th, _ = bt_penalise(Wsep, LAMBDA_PRINCIPAL)
        verifier_fini(th)
        if list(np.argsort(-th)) != list(range(m)):
            raise GardeEchec("séparation : la pénalisée ne rend pas l'ordre linéaire")
        return "passe"

    consigner("séparation parfaite : pénalisée finie et dans l'ordre", "passe", sep_penalise)
    consigner("artefact : MM limité à une itération (non-convergence)", "refus",
              lambda: bt_mm(Ws, max_iter=1))
    consigner("artefact : valeur non finie", "refus",
              lambda: verifier_fini(np.array([0.0, np.nan])))
    consigner("artefact : lambda nul", "refus", lambda: bt_penalise(Wsep, 0.0))

    # cohérence : ensemble concordant puis un gagnant retourné
    conc = []
    for t, k in enumerate(perm, 1):
        a, b = canon[int(k)]
        conc.append({"t": t, "indice_canonique": int(k), "A": a, "B": b,
                     "gagnant": min(a, b, key=items.index)})

    def coh_test():
        c1 = coherence(conc, items)[0]
        L = copy.deepcopy(conc)
        L[0]["gagnant"] = L[0]["B"] if L[0]["gagnant"] == L[0]["A"] else L[0]["A"]
        c2 = coherence(L, items)[0]
        if c1 != 1.0 or abs(c2 - 27 / 28) > 1e-15:
            raise GardeEchec(f"cohérence : {c1}, {c2} au lieu de 1 et 27/28")
        return "passe"

    consigner("cohérence : 1 sur un ensemble concordant, 27/28 après un retournement", "passe", coh_test)
    consigner("artefact : cohérence sur une paire jugée une seule fois", "refus",
              lambda: coherence(conc[:-1], items))
    return res


# ---------------------------------------------------------------- principal

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--notes", required=True)
    ap.add_argument("--paires", required=True)
    ap.add_argument("--fiches", required=True)
    ap.add_argument("--sortie", required=True)
    args = ap.parse_args()

    notes = json.load(open(args.notes, encoding="utf-8"))
    items = list(notes["huit_premieres"]["ordre_canonique"])
    sha_fiches = sha256_fichier(args.fiches)
    e = graine_depuis_empreinte(sha_fiches)

    gardes = eprouver_gardes(items, e, args.fiches)
    if not all(g["reussi"] for g in gardes):
        for g in gardes:
            print(("ok   " if g["reussi"] else "ÉCHEC"), g["nom"], "→", g["obtenu"], file=sys.stderr)
        raise SystemExit("une garde a échoué à l'épreuve : rien n'est écrit")

    # contrôles des entrées réelles
    verifier_empreinte(args.fiches, SHA_FICHES_ATTENDU)
    if e != notes["tirage"]["e"]:
        raise GardeEchec("graine recalculée différente de celle des notes")
    canon, perm = calendrier(items, e)
    if perm.tolist() != notes["tirage"]["permutation"]:
        raise GardeEchec("permutation recalculée différente de celle des notes")
    notes_simples = [{"id": n["id"], "somme": n["somme"], "originalite": n["originalite"]["note"]}
                     for n in notes["notes"]]
    for n in notes["notes"]:
        s = n["originalite"]["note"] + n["testable"]["note"] + n["outil_mentor"]["note"]
        if s != n["somme"]:
            raise GardeEchec(f"somme fausse pour {n['id']}")
    huit = [n["id"] for n in classer_par_somme(notes_simples)[:8]]
    if huit != items:
        raise GardeEchec(f"huit premières recalculées {huit} différentes des notes {items}")

    lignes = [json.loads(x) for x in open(args.paires, encoding="utf-8") if x.strip()]
    verifier_paires(lignes, items, canon, perm)

    W = matrice_victoires(lignes, items)
    victoires = W.sum(axis=1)
    existe = fortement_connexe(W)
    mv = None
    if existe:
        th_mv, it_mv = bt_mm(W)
        mv = {"log_forces": {x: float(v) for x, v in zip(items, th_mv - th_mv.mean())},
              "iterations": it_mv, "ordre": ordre_depuis(th_mv, items)}
    th, it = bt_penalise(W, LAMBDA_PRINCIPAL)
    forces = np.exp(th) / np.exp(th).sum()
    ordre_final = ordre_depuis(th, items)
    sens = {}
    for lam in LAMBDAS_SENSIBILITE:
        t_l, _ = bt_penalise(W, lam)
        sens[str(lam)] = {"ordre": ordre_depuis(t_l, items),
                          "ecart_max_log_forces": float(t_l.max() - t_l.min())}
    ordre_victoires = [items[i] for i in sorted(range(len(items)), key=lambda i: (-victoires[i], items[i]))]

    coh, nconc, npaires, disc = coherence(lignes, items)
    part_a = sum(l["gagnant"] == l["A"] for l in lignes) / len(lignes)
    cycles, indecises = triades_intransitives(W, items)

    somme = {n["id"]: n["somme"] for n in notes_simples}
    net = W - W.T
    renversements = []
    for i, j in itertools.combinations(range(len(items)), 2):
        if net[i, j] == 0:
            continue
        g, p = (i, j) if net[i, j] > 0 else (j, i)
        if somme[items[g]] < somme[items[p]]:
            renversements.append({"gagnant": items[g], "somme_gagnant": somme[items[g]],
                                  "perdant": items[p], "somme_perdant": somme[items[p]],
                                  "score": f"{int(W[g, p])}–{int(W[p, g])}"})

    # sensibilité à la porte (recalcul, fait foi sur la phrase des notes)
    indic = [{"id": n["id"], "somme": n["somme"], "originalite": n["originalite"]}
             for n in notes["notes_indicatives_hors_sujet"]["notes"]]
    tous = classer_par_somme(notes_simples + indic)
    huit_porte = [n["id"] for n in tous[:8]]
    cle8 = (tous[7]["somme"], tous[7]["originalite"])
    ex_aequo_coupure = [n["id"] for n in tous if (n["somme"], n["originalite"]) == cle8]
    places_ex_aequo = sum(1 for n in tous[:8] if (n["somme"], n["originalite"]) == cle8)

    reserves = []
    if coh < SEUIL_COHERENCE:
        reserves.append(f"Cohérence {coh:.3f} sous le seuil de {SEUIL_COHERENCE} : ordre peu fiable.")
    if coh >= SEUIL_PRESQUE_PARFAITE:
        reserves.append(f"Cohérence {coh:.3f}, presque parfaite d'un juge unique qui se souvient de ses "
                        "jugements : elle mesure la constance du juge, pas la robustesse de l'ordre (R4).")
    if not existe:
        reserves.append("Maximum de vraisemblance inexistant (séparation : au moins un élément gagne ou perd "
                        "tous ses duels) ; forces données par la pénalisée déclarée (loi a priori normale de "
                        f"précision {LAMBDA_PRINCIPAL} sur les log-forces) ; leur échelle dépend de lambda, "
                        "seul l'ordre est à lire.")
    if not cycles and indecises == 0:
        reserves.append("Aucune triade intransitive ni paire partagée : ordre linéaire parfait, trop propre "
                        "pour être lu comme une mesure ; aucun intervalle n'est donné, les jugements d'un "
                        "même juge n'étant pas indépendants.")

    sortie = {
        "version": "v1",
        "execute_le_utc": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "script": {"chemin": __file__, "sha256": sha256_fichier(__file__)},
        "versions": {"python": platform.python_version(), "numpy": np.__version__},
        "entrees": {
            "notes": {"chemin": args.notes, "sha256": sha256_fichier(args.notes)},
            "paires": {"chemin": args.paires, "sha256": sha256_fichier(args.paires)},
            "fiches": {"chemin": args.fiches, "sha256": sha_fiches},
        },
        "graine": {"e_hex": sha_fiches[:16], "e": e,
                   "permutation_conforme_aux_notes": True,
                   "graines_derivees_des_epreuves": "SeedSequence(e, spawn_key=(1,)) et (2,)"},
        "gardes_eprouvees": gardes,
        "elements_ordre_canonique": items,
        "matrice_victoires": {"lignes_gagnant_colonnes_perdant": items, "valeurs": W.astype(int).tolist()},
        "victoires": {x: int(v) for x, v in zip(items, victoires)},
        "maximum_de_vraisemblance": {"existe": existe, "detail": mv},
        "forces_penalisees": {
            "lambda": LAMBDA_PRINCIPAL,
            "log_forces_centrees": {x: round(float(v - th.mean()), 6) for x, v in zip(items, th)},
            "forces_normalisees_somme_1": {x: round(float(v), 6) for x, v in zip(items, forces)},
            "iterations_newton": it,
        },
        "sensibilite_a_lambda": sens,
        "ordre_final": ordre_final,
        "ordre_par_victoires": ordre_victoires,
        "accord_ordre_final_victoires": ordre_final == ordre_victoires,
        "ordre_stable_sur_les_lambdas": all(v["ordre"] == ordre_final for v in sens.values()),
        "coherence": {"valeur": coh, "paires_concordantes": nconc, "paires": npaires,
                      "paires_discordantes": disc, "seuil": SEUIL_COHERENCE},
        "biais_de_position": {"part_des_victoires_de_la_premiere_presentee": part_a},
        "triades": {"intransitives": cycles, "avec_paire_partagee": indecises},
        "comparaison_avec_la_somme": {
            "ordre_par_somme": items,
            "tau_de_kendall_final_contre_somme": tau_kendall(ordre_final, items),
            "renversements_de_la_somme": renversements,
        },
        "sensibilite_a_la_porte": {
            "huit_si_les_quatre_hors_sujet_entraient": huit_porte,
            "entreraient": [x for x in huit_porte if x not in items],
            "sortiraient": [x for x in items if x not in huit_porte],
            "ex_aequo_a_la_coupure": ex_aequo_coupure,
            "places_disputees_par_ces_ex_aequo": places_ex_aequo,
            "note": "Recalcul : fait foi sur la phrase de sensibilité de notes-v1.json.",
        },
        "reserves": reserves,
    }
    with open(args.sortie, "x", encoding="utf-8") as f:
        json.dump(sortie, f, ensure_ascii=False, indent=1)
        f.write("\n")
    print(json.dumps({"ordre_final": ordre_final, "coherence": coh, "existe_mv": existe,
                      "gardes": f"{sum(g['reussi'] for g in gardes)}/{len(gardes)}",
                      "porte": sortie["sensibilite_a_la_porte"], "renversements": renversements,
                      "sensibilite_lambda": sens, "part_A": part_a, "reserves": reserves},
                     ensure_ascii=False, indent=1))


if __name__ == "__main__":
    try:
        main()
    except GardeEchec as exc:
        raise SystemExit(f"garde : {exc}")
