"""Étape B du protocole Kirchner v1 (68919ec9…, §3) : mêle les deux témoins déguisés aux 14 fiches K gardées du lecteur A,
identifiants opaques réattribués (KM-01…), ordre permuté par SeedSequence (graine : entier des 16 premiers hexadécimaux du sha256
du fichier des fiches) ; champs servis réduits au noyau commun aux fiches et aux témoins ; « rattachement_piece » retiré (toutes les
fiches disent « prolonge la pièce », les témoins « neuve » : le servir les désignerait) ; deux parts pour la moisson."""
import hashlib, json, sys
import numpy as np
fiches_p, temoins_p, sortie_d, cle_p = sys.argv[1:5]
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
fiches = json.load(open(fiches_p)); temoins = json.load(open(temoins_p))
NOYAU = ('type', 'enonce', 'mecanisme', 'premiere_experience', 'resultat_qui_ferait_changer_d_avis', 'mesure_qui_tue', 'prediction',
         'echec_le_plus_probable', 'outil_de_kirchner', 'cout')
def bas(s):  # première lettre en minuscule (les témoins commencent par une majuscule, les fiches non)
    s = (s or '').strip()
    return s[:1].lower() + s[1:] if s else s
elements = []
for f in fiches:
    assert f['statut'] == 'gardée' and f['classement'] in ('K', ['K']), f['id']
    elements.append((('fiche', f['id']), {k: f.get(k, '') for k in NOYAU}))
for i, t in enumerate(temoins, 1):
    d = {k: t.get(k, '') for k in NOYAU}; d['outil_de_kirchner'] = bas(d['outil_de_kirchner'])
    elements.append((('temoin', f'T{i}'), d))
h = sha(fiches_p); graine = int(h[:16], 16)
perm = np.random.default_rng(np.random.SeedSequence(graine)).permutation(len(elements))
servies, cle = [], {}
for rang, i in enumerate(perm, 1):
    src, d = elements[i]
    mid = f'KM-{rang:02d}'
    servies.append(dict(id=mid, **d)); cle[mid] = {'source': src[0], 'ident': src[1]}
moitie = (len(servies) + 1) // 2
fichiers = {'fiches-a-moissonner-v1.json': servies, 'fiches-moisson-part-1-v1.json': servies[:moitie], 'fiches-moisson-part-2-v1.json': servies[moitie:]}
for nom, contenu in fichiers.items():
    json.dump(contenu, open(f'{sortie_d}/{nom}', 'w'), ensure_ascii=False, indent=1)
json.dump({'cle': cle, 'regle': 'KM-xx = rang dans la permutation ; témoins T1, T2 = ordre de temoins-deguises-kirchner-v1.json'}, open(cle_p, 'w'), ensure_ascii=False, indent=1)
man = {'entrees': {fiches_p: h, temoins_p: sha(temoins_p)}, 'graine': str(graine), 'regle_graine': "int(sha256(fiches)[:16], 16) → SeedSequence → default_rng → permutation",
       'numpy': np.__version__, 'champs_servis': ['id'] + list(NOYAU), 'retires': ['rattachement_piece (désignerait les témoins)', 'objections, réponses, manques, appuis, note du lecteur (absents des témoins)'],
       'normalisation': 'outil_de_kirchner des témoins : première lettre en minuscule', 'comptes': {k: len(v) for k, v in fichiers.items()},
       'sorties': {k: sha(f'{sortie_d}/{k}') for k in fichiers}, 'cle': sha(cle_p)}
json.dump(man, open(f'{sortie_d}/manifeste-melange-v1.json', 'w'), ensure_ascii=False, indent=1)
print(json.dumps(man['comptes']), 'graine', graine)
