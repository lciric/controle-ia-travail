"""Kirchner Q2, ensemble tour + course (R-1377) : fiches servies KM-01 à KM-31 (lot 1 : témoins inchangés, fiches réelles prises dans
la v2 du lecteur A, enrichies par la course ; lot 2 : tel que préparé) et moisson fusionnée des deux lots. Clés du coffre lues ici
seulement, jamais servies."""
import hashlib, json, sys
R = '/home/claude/scratch/kirchner-rapport/'; C = '/home/claude/coffre-ideation-kirchner/'
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
NOYAU = ('type', 'enonce', 'mecanisme', 'premiere_experience', 'resultat_qui_ferait_changer_d_avis', 'mesure_qui_tue', 'prediction', 'echec_le_plus_probable', 'outil_de_kirchner', 'cout')
lot1 = {f['id']: f for f in json.load(open(R + 'melange-v1/fiches-a-moissonner-v1.json'))}
lot2 = {f['id']: f for f in json.load(open(R + 'melange-v1/fiches-lot2-a-moissonner-v1.json'))}
cle1 = json.load(open(C + 'cle-melange-kirchner-v1.json'))['cle']
v2 = {f['id']: f for f in json.load(open(R + 'lecteur-A/fiches-normalisees-v2.json'))}
servies = []
for mid in sorted(lot1):
    k = cle1[mid]
    if k['source'] == 'temoin': servies.append(lot1[mid])
    else: servies.append(dict(id=mid, **{c: v2[k['ident']].get(c, '') for c in NOYAU}))
servies += [lot2[m] for m in sorted(lot2)]
def lst(x): return x if isinstance(x, list) else next(v for v in x.values() if isinstance(v, list) and v and isinstance(v[0], dict) and 'id' in v[0])
mois = json.load(open(R + 'moisson-C/moisson-fusionnee-v1.json'))
for p in ('moisson-lot2-part-1-v1.json', 'moisson-lot2-part-2-v1.json'): mois += lst(json.load(open(R + 'moisson-C/' + p)))
ids_s = sorted(f['id'] for f in servies); ids_m = sorted(e['id'] for e in mois)
assert ids_s == ids_m and len(ids_s) == 31, (set(ids_s) ^ set(ids_m))
mois.sort(key=lambda e: e['id'])
a = R + 'melange-v1/fiches-classement-K-v2.json'; b = R + 'moisson-C/moisson-fusionnee-v2.json'
json.dump(servies, open(a, 'w'), ensure_ascii=False, indent=1); json.dump(mois, open(b, 'w'), ensure_ascii=False, indent=1)
temoins = [m for m, k in cle1.items() if k['source'] == 'temoin']
g = R + 'piste-kirchner/fiches-a-grouper-v2.json'
json.dump([{'id': f['id'], 'enonce': f['enonce'], 'mecanisme': f['mecanisme'], 'premiere_experience': f['premiere_experience'][:900]} for f in servies if f['id'] not in temoins], open(g, 'w'), ensure_ascii=False, indent=1)
print('fiches', a, sha(a)); print('moisson', b, sha(b)); print('a grouper', g, sha(g))
