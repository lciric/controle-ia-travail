"""Second lot Kirchner (course) : les fiches neuves du lecteur A v2 (K-015 et suivantes), réidentifiées KM-17… dans un ordre permuté
par SeedSequence (graine : entier des 16 premiers hexadécimaux du sha256 de fiches-normalisees-v2.json), champs du noyau commun
(mêmes que le lot 1, sans rattachement_piece) ; les témoins ne sont mêlés qu'au lot 1 (écart déclaré R-1377). Clé ajoutée au coffre."""
import hashlib, json, sys
import numpy as np
v2_p, sortie_d, cle_p = sys.argv[1:4]
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
v2 = json.load(open(v2_p))
NOYAU = ('type', 'enonce', 'mecanisme', 'premiere_experience', 'resultat_qui_ferait_changer_d_avis', 'mesure_qui_tue', 'prediction', 'echec_le_plus_probable', 'outil_de_kirchner', 'cout')
neuves = [f for f in v2 if int(f['id'].split('-')[1]) >= 15 and f.get('statut') == 'gardée' and f.get('classement') in ('K', ['K'])]
graine = int(sha(v2_p)[:16], 16)
perm = np.random.default_rng(np.random.SeedSequence(graine)).permutation(len(neuves))
servies, cle = [], {}
for r, i in enumerate(perm, 17):
    f = neuves[i]; nid = f'KM-{r:02d}'
    servies.append(dict(id=nid, **{k: f.get(k, '') for k in NOYAU})); cle[nid] = {'source': 'fiche', 'ident': f['id']}
json.dump(servies, open(f'{sortie_d}/fiches-lot2-a-moissonner-v1.json', 'w'), ensure_ascii=False, indent=1)
m = (len(servies) + 1) // 2
json.dump(servies[:m], open(f'{sortie_d}/fiches-lot2-part-1-v1.json', 'w'), ensure_ascii=False, indent=1)
json.dump(servies[m:], open(f'{sortie_d}/fiches-lot2-part-2-v1.json', 'w'), ensure_ascii=False, indent=1)
json.dump({'cle': cle, 'regle': 'KM-17 et suivants = rang dans la permutation du lot 2'}, open(cle_p, 'w'), ensure_ascii=False, indent=1)
print(len(servies), 'graine', graine, {k: sha(f'{sortie_d}/{k}') for k in ('fiches-lot2-a-moissonner-v1.json', 'fiches-lot2-part-1-v1.json', 'fiches-lot2-part-2-v1.json')}, sha(cle_p))
