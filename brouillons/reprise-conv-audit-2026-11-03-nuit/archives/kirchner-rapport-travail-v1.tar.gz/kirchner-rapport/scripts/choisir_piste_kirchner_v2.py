"""Version 2 : ensemble tour plus course (R-1395, R-1396). Règle gelée R-1371 (lecture R-1375) appliquée à Kirchner Q2 (R-1372) : score d'un groupe = somme des sommes (quatre critères)
de ses fiches parmi les douze comparées par paires ; égalité : meilleur rang de Bradley-Terry, puis nombre de « ouverte » ou
« voisin lointain » ; lecture de contrôle : groupe de la meilleure fiche seule. Témoins exclus (absents du groupement)."""
import json, hashlib, sys
R = '/home/claude/scratch/kirchner-rapport/'
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
gp = sys.argv[1]
G = json.load(open(gp)); aff = {a['id']: a['groupe'] for a in G['affectations']}
bt = json.load(open(R + 'classement-D/bradley_terry_kirchner_v2-sortie.json'))
notes = {n['id']: n for n in json.load(open(R + 'classement-D/notes-K-v2.json'))['fiches']}
moisson = {e['id']: e for e in json.load(open(R + 'moisson-C/moisson-fusionnee-v2.json'))}
ordre = bt['ordre_final']; rang = {i: k for k, i in enumerate(ordre, 1)}
def somme(i): return sum(v['note'] for v in notes[i]['notes'].values())
def ouverte(i):
    e = moisson.get(i, {}); c = (e.get('classe') or '').lower(); d = (e.get('distance') or '').lower()
    return c.startswith('ouverte') or 'lointain' in d
tab = []
for g in sorted(set(aff.values())):
    m = [i for i, x in aff.items() if x == g]; d12 = sorted([i for i in m if i in rang], key=lambda i: rang[i])
    tab.append(dict(groupe=g, n=len(m), dans_les_douze=d12, score=sum(somme(i) for i in d12), meilleur_rang=min([rang[i] for i in d12], default=99), ouvertes_ou_lointaines=sum(ouverte(i) for i in m)))
tab.sort(key=lambda t: (-t['score'], t['meilleur_rang'], -t['ouvertes_ou_lointaines']))
meill = min((i for i in rang if i in aff), key=lambda i: rang[i])
res = dict(entrees={gp: sha(gp), 'bt': sha(R + 'classement-D/bradley_terry_kirchner_v2-sortie.json'), 'notes': sha(R + 'classement-D/notes-K-v2.json'), 'moisson': sha(R + 'moisson-C/moisson-fusionnee-v2.json')},
           tableau=tab, piste=tab[0]['groupe'], egalite_au_sommet=len(tab) > 1 and (tab[0]['score'], tab[0]['meilleur_rang']) == (tab[1]['score'], tab[1]['meilleur_rang']),
           controle_meilleure_fiche=dict(fiche=meill, groupe=aff[meill], concorde=aff[meill] == tab[0]['groupe']), hors_groupe=[i for i in rang if i not in aff])
out = R + 'piste-kirchner/choix-piste-v2.json'; json.dump(res, open(out, 'w'), ensure_ascii=False, indent=1)
for t in tab: print(t)
print('PISTE :', res['piste'], '| égalité :', res['egalite_au_sommet'], '| contrôle :', res['controle_meilleure_fiche'], '| hors groupe (témoins attendus) :', res['hors_groupe'])
print(out, sha(out))
