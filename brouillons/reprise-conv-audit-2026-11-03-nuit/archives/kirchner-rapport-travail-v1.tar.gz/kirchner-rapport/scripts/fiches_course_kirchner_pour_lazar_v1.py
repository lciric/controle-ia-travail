"""Document de lecture pour Lazar : fiches de la seconde course de l'organisme sur Kirchner Q2, telles que produites (contenu intégral,
sans nom de modèle), fusions d'abord ; ni classement ni notes des juges ; coffre de la course jamais ouvert."""
import hashlib, json, sys
k = json.load(open(sys.argv[1])); s = json.load(open(sys.argv[2])); sortie = sys.argv[3]
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
items = {i['item']: i['contenu'] for i in s['items']}
def ordre(sid):
    m = k['cles'][sid]
    if m['fichier'] == 'fusions-inachevees.json': return (1, sid)
    return (0 if m['meta'].get('origine') == 'fusion' else 2, sid)
CH = [('probleme', 'Problème'), ('sous_estime', 'Pourquoi sous-estimé'), ('hypothese', 'Hypothèse'), ('premiere_experience', 'Première expérience'),
      ('changer_d_avis', "Ce qui ferait changer d'avis"), ('test_de_mort', 'Test de mort'), ('cout', 'Coût'), ('axe', 'Axe')]
L = ["# Seconde course de l'organisme sur ta question 2 de Kirchner — les fiches telles que la course les a produites — v1", "",
     f"Course du 3 novembre 2026 (GO-2026-11-03-05, 12:21:42 → 13:27:35 UTC, code 0, 10,84 USD). Copie à l'octet vérifiée (81 empreintes, 0 écart) ; paquet sans provenance `{sha(sys.argv[2])[:16]}…`. "
     f"**Brut** : ni dédoublonné, ni moissonné, ni classé ; sans nom de modèle ; sans les notes des juges ; {len(s['non_fourni'])} fiche(s) classée(s) « à corriger » par l'aiguilleur, sans contenu dans la sortie : comptées, absentes ici. Les chiffres des fiches ne sont pas vérifiés.", ""]
G = {0: "## 1. Fusions du bisociateur", 1: "## 2. Fusions inachevées (jamais jugées)", 2: "## 3. Propositions"}
cur, n = None, 0
for sid in sorted(items, key=ordre):
    g = ordre(sid)[0]
    if g != cur: L += [G[g], ""]; cur = g
    n += 1; c = items[sid]
    L += [f"### {n}. {c.get('titre', '(sans titre)')}  ·  `{sid}`", ""] + [f"- **{nom}** : {c[cl]}" for cl, nom in CH if c.get(cl)] + [""]
open(sortie, 'w').write('\n'.join(L) + '\n'); print(sortie, sha(sortie), n)
