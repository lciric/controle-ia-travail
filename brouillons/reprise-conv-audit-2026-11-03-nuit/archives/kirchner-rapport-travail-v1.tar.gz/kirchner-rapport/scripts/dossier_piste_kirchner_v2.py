"""v2 : entrées de l'ensemble v2 (lecteur A v2, notes K v2, moisson v2, Bradley-Terry v2, clés du mélange et du lot 2) ; piste donnée par le fichier de choix (y compris un choix de Lazar hors règle, dit dans l'en-tête). Dossier de piste pour le rédacteur de Kirchner Q2 (après levée de la clé du mélange) : pour chaque fiche du groupe choisi,
la fiche complète du lecteur A (objections et réponses comprises), sa moisson, ses notes et son drapeau ; puis les autres fiches
classées, en une ligne. Sans provenance d'espèce."""
import json, hashlib, sys
R = '/home/claude/scratch/kirchner-rapport/'
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
choix_p, groupes_p, sortie = sys.argv[1:4]
choix = json.load(open(choix_p)); G = json.load(open(groupes_p))
aff = {a['id']: a for a in G['affectations']}; gdef = {g['nom']: g for g in G['groupes']}
cle = dict(json.load(open('/home/claude/coffre-ideation-kirchner/cle-melange-kirchner-v1.json'))['cle']); cle.update(json.load(open('/home/claude/coffre-ideation-kirchner/cle-melange-lot2-kirchner-v1.json'))['cle'])
lect = {f['id']: f for f in json.load(open(R + 'lecteur-A/fiches-normalisees-v2.json'))}
notes = {n['id']: n for n in json.load(open(R + 'classement-D/notes-K-v2.json'))['fiches']}
moisson = {e['id']: e for e in json.load(open(R + 'moisson-C/moisson-fusionnee-v2.json'))}
bt = json.load(open(R + 'classement-D/bradley_terry_kirchner_v2-sortie.json')); rang = {i: k for k, i in enumerate(bt.get('ordre_final') or bt['resultat']['ordre_final'], 1)}
piste = choix['piste']; L = [f"# Dossier de piste — Kirchner Q2 — groupe « {piste} »", "",
     f"Définition (groupeur aveugle) : {gdef[piste]['definition']}", "", f"{choix.get('origine', 'Choix par la règle gelée')} : `{choix_p}` (sha256 `{sha(choix_p)}`) ; contrôle (meilleure fiche seule) : {choix['controle_meilleure_fiche']}.", ""]
membres = sorted([i for i, a in aff.items() if a['groupe'] == piste], key=lambda i: rang.get(i, 99))
for i in membres:
    f = lect[cle[i]['ident']]; n = notes[i]; m = moisson.get(i, {})
    L += [f"## {i} (rang {rang.get(i, 'hors des douze')}, somme {sum(v['note'] for v in n['notes'].values())})", "",
          f"- Drapeau devant Kirchner : {json.dumps(n.get('drapeau_risque_devant_kirchner'), ensure_ascii=False)}",
          f"- Notes : " + " ; ".join(f"{k} {v['note']} ({v['raison']})" for k, v in n['notes'].items()),
          f"- Moisson : {m.get('classe')} {m.get('distance') or ''} — " + " ; ".join(f"{s.get('identifiant')} « {s.get('titre','')[:100]} » ({s.get('date','')}) : {s.get('phrase','')[:220]}" for s in m.get('sources', [])[:5]) + (f" — contradiction proposée : {json.dumps(m.get('contradiction'), ensure_ascii=False)[:400]}" if m.get('contradiction') else ''),
          f"- Compte même problème, même mesure : {m.get('compte_meme_probleme_meme_mesure')}"]
    for k in ('enonce', 'probleme_sous_estime', 'mecanisme', 'premiere_experience', 'resultat_qui_ferait_changer_d_avis', 'mesure_qui_tue', 'prediction', 'echec_le_plus_probable', 'outil_de_kirchner', 'appuis_lazar', 'objections', 'reponses', 'manques', 'note_du_lecteur', 'cout'):
        v = f.get(k); L.append(f"- **{k}** : {json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v}")
    L.append("")
L += ["## Les autres fiches (une ligne chacune)", ""]
for i in sorted(aff, key=lambda i: rang.get(i, 99)):
    if i in membres: continue
    f = lect[cle[i]['ident']]; L.append(f"- {i} (groupe « {aff[i]['groupe']} », rang {rang.get(i, 'hors des douze')}) : {f['enonce'][:260]}")
open(sortie, 'w').write('\n'.join(L) + '\n'); print(sortie, sha(sortie), len(membres), 'fiches dans la piste')
