"""Forces de Bradley-Terry du classement K v2 (classeur neuf D, question 2 de Kirchner).

numpy seul, aucun modèle. Usage :
    nice -n 10 python -I bradley_terry_kirchner_v2.py PAIRES.jsonl FICHES.json SORTIE.json "$(date -u)"

Règles fixées avant toute lecture des jugements :
- ordre de présentation : paires des douze identifiants triés, dans l'ordre lexicographique ;
  indice 2k = paire k dans l'ordre direct, 2k+1 = ordre inverse ; présentation n = indice
  numpy.random.default_rng(numpy.random.SeedSequence(e)).permutation(132)[n], e = entier des
  16 premiers hexadécimaux du sha256 du fichier des fiches ;
- forces : maximum de vraisemblance de Bradley-Terry par l'algorithme MM (Hunter 2004),
  normalisées à moyenne géométrique 1 ; il n'existe que si le graphe des victoires est
  fortement connexe. Sinon le script le dit et donne, déclarées comme telles, les forces sous
  un adversaire virtuel (une victoire et une défaite de chaque élément contre lui) : jamais de
  repli silencieux. Les forces sous adversaire virtuel sont toujours données en sensibilité ;
- cohérence = part des 66 paires dont les deux ordres donnent le même gagnant ;
  sous 0,8 : réserve ; à 0,95 ou plus (au plus 3 paires discordantes) : réserve « presque
  parfaite d'un juge unique » ;
- gardes (R5) éprouvées à chaque exécution, avant les vrais jugements, sur un cas sain et sur
  des artefacts construits en mémoire ; une épreuve qui échoue arrête tout, sans sortie.
"""
import hashlib
import itertools
import json
import platform
import sys

import numpy as np

N_ATTENDU = 132
SEUIL_COHERENCE_BAS = 0.8
SEUIL_COHERENCE_PRESQUE_PARFAITE = 0.95
TOL = 1e-12
MAX_IT = 200000


class GardeError(Exception):
    pass


def sha256(chemin):
    with open(chemin, 'rb') as f:
        return hashlib.sha256(f.read()).hexdigest()


def ordre_tire(ids, sha_fiches):
    ids = sorted(ids)
    paires = list(itertools.combinations(ids, 2))
    J = [x for (a, b) in paires for x in ((a, b), (b, a))]
    e = int(sha_fiches[:16], 16)
    p = np.random.default_rng(np.random.SeedSequence(e)).permutation(len(J))
    return paires, J, p, e


def valider(lignes, ids, sha_fiches):
    """Garde d'entrée : nombre, champs, ordre tiré, paires et choix, deux ordres par paire."""
    ids = sorted(ids)
    if len(set(ids)) != len(ids) or len(ids) != 12:
        raise GardeError('il faut douze identifiants distincts')
    paires, J, p, _ = ordre_tire(ids, sha_fiches)
    if len(lignes) != N_ATTENDU or len(J) != N_ATTENDU:
        raise GardeError(f'{len(lignes)} jugements au lieu de {N_ATTENDU}')
    vus = set()
    for k, l in enumerate(lignes):
        for champ in ('n', 'indice_tire', 'A', 'B', 'choix'):
            if champ not in l:
                raise GardeError(f'ligne {k} : champ « {champ} » absent')
        if l['n'] != k:
            raise GardeError(f'ligne {k} : rang de présentation {l["n"]}, attendu {k}')
        if l['indice_tire'] != int(p[k]):
            raise GardeError(f'ligne {k} : indice {l["indice_tire"]}, le tirage donne {int(p[k])}')
        if l['A'] not in ids or l['B'] not in ids:
            raise GardeError(f'ligne {k} : identifiant inconnu ({l["A"]}, {l["B"]})')
        if (l['A'], l['B']) != J[l['indice_tire']]:
            raise GardeError(f'ligne {k} : présentée ({l["A"]}, {l["B"]}), le tirage donne {J[l["indice_tire"]]}')
        if l['choix'] not in (l['A'], l['B']):
            raise GardeError(f'ligne {k} : choix {l["choix"]} hors de la paire')
        if (l['A'], l['B']) in vus:
            raise GardeError(f'ligne {k} : présentation en double')
        vus.add((l['A'], l['B']))
    for a, b in paires:
        if (a, b) not in vus or (b, a) not in vus:
            raise GardeError(f'paire ({a}, {b}) sans ses deux ordres')
    return paires


def matrice(lignes, ids):
    ids = sorted(ids)
    ix = {x: i for i, x in enumerate(ids)}
    W = np.zeros((len(ids), len(ids)))
    for l in lignes:
        g = l['choix']
        perdant = l['B'] if g == l['A'] else l['A']
        W[ix[g], ix[perdant]] += 1
    return W


def fortement_connexe(W):
    A = W > 0
    n = W.shape[0]

    def atteints(adj):
        vu, pile = {0}, [0]
        while pile:
            u = pile.pop()
            for v in np.nonzero(adj[u])[0]:
                v = int(v)
                if v not in vu:
                    vu.add(v)
                    pile.append(v)
        return vu

    return len(atteints(A)) == n and len(atteints(A.T)) == n


def bt_mm(W, max_it=MAX_IT, tol=TOL):
    n = W.shape[0]
    N = W + W.T
    w = W.sum(axis=1)
    if np.any(w == 0):
        raise GardeError('un élément sans victoire : maximum de vraisemblance inexistant')
    pi = np.ones(n)
    for it in range(1, max_it + 1):
        den = (N / (pi[:, None] + pi[None, :])).sum(axis=1)
        nouv = w / den
        nouv = nouv / np.exp(np.mean(np.log(nouv)))
        if np.max(np.abs(np.log(nouv) - np.log(pi))) < tol:
            return nouv, it
        pi = nouv
    raise GardeError(f'pas de convergence en {max_it} itérations')


def bt_adversaire_virtuel(W, max_it=MAX_IT):
    n = W.shape[0]
    W2 = np.zeros((n + 1, n + 1))
    W2[:n, :n] = W
    W2[:n, n] = 1.0
    W2[n, :n] = 1.0
    pi, it = bt_mm(W2, max_it=max_it)
    pi = pi[:n]
    return pi / np.exp(np.mean(np.log(pi))), it


def bt(W, regularisation_declaree):
    if fortement_connexe(W):
        pi, it = bt_mm(W)
        return {'estimateur': 'maximum de vraisemblance (algorithme MM)', 'existe': True, 'forces': pi, 'iterations': it}
    if not regularisation_declaree:
        raise GardeError('graphe des victoires non fortement connexe : maximum de vraisemblance inexistant')
    pi, it = bt_adversaire_virtuel(W)
    return {'estimateur': 'adversaire virtuel (déclaré : le maximum de vraisemblance n\'existe pas)', 'existe': False, 'forces': pi, 'iterations': it}


def coherence(lignes, paires):
    par = {(l['A'], l['B']): l['choix'] for l in lignes}
    concord, discord = 0, []
    for a, b in paires:
        if par[(a, b)] == par[(b, a)]:
            concord += 1
        else:
            discord.append({'paire': [a, b], 'ordre_direct_choisit': par[(a, b)], 'ordre_inverse_choisit': par[(b, a)]})
    return concord / len(paires), concord, discord


def lecture_coherence(c):
    r = []
    if c < SEUIL_COHERENCE_BAS:
        r.append('cohérence sous 0,8 : réserve écrite')
    if c >= SEUIL_COHERENCE_PRESQUE_PARFAITE:
        r.append("cohérence presque parfaite (≥ 0,95) d'un juge unique : réserve (le juge garde en mémoire ses jugements précédents ; la concordance n'est pas une épreuve indépendante)")
    return r


def spearman(x, y):
    rx = np.argsort(np.argsort(x)).astype(float)
    ry = np.argsort(np.argsort(y)).astype(float)
    return float(np.corrcoef(rx, ry)[0, 1])


def lignes_synthetiques(ids, sha_fiches, choisir):
    paires, J, p, _ = ordre_tire(ids, sha_fiches)
    out = []
    for n in range(N_ATTENDU):
        a, b = J[int(p[n])]
        out.append({'n': n, 'indice_tire': int(p[n]), 'A': a, 'B': b, 'choix': choisir(a, b, n)})
    return out


def epreuves(ids, sha_fiches):
    """Cas sains et artefacts ; renvoie la liste des épreuves, lève si l'une échoue."""
    res = []

    def attendre_garde(nom, f):
        try:
            f()
        except GardeError as ex:
            res.append({'epreuve': nom, 'attendu': 'garde déclenchée', 'observe': f'garde déclenchée : {ex}', 'tenue': True})
            return
        res.append({'epreuve': nom, 'attendu': 'garde déclenchée', 'observe': 'aucune garde', 'tenue': False})
        raise SystemExit(f'ÉPREUVE ÉCHOUÉE : {nom}')

    rng = np.random.default_rng(np.random.SeedSequence(20261103))
    ids = sorted(ids)
    vraies = {x: v for x, v in zip(ids, np.linspace(-1.5, 1.5, len(ids)))}

    def choix_sain(a, b, n):
        pa = 1.0 / (1.0 + np.exp(vraies[b] - vraies[a]))
        return a if rng.random() < pa else b

    saines = lignes_synthetiques(ids, sha_fiches, choix_sain)
    valider(saines, ids, sha_fiches)
    res.append({'epreuve': 'sain : 132 jugements synthétiques bien formés', 'attendu': 'acceptés', 'observe': 'acceptés', 'tenue': True})

    # récupération des forces sur un cas sain à beaucoup de parties
    vrai_log = np.array([vraies[x] for x in ids])
    P = 1.0 / (1.0 + np.exp(vrai_log[None, :] - vrai_log[:, None]))
    Wg = np.zeros((12, 12))
    for i in range(12):
        for j in range(i + 1, 12):
            g = rng.binomial(400, P[i, j])
            Wg[i, j], Wg[j, i] = g, 400 - g
    r = bt(Wg, regularisation_declaree=False)
    err = float(np.max(np.abs(np.log(r['forces']) - (vrai_log - vrai_log.mean()))))
    rho = spearman(r['forces'], vrai_log)
    ok = r['existe'] and err < 0.2 and rho > 0.95
    res.append({'epreuve': 'sain : forces connues retrouvées (400 parties par paire)', 'attendu': 'écart maximal des log-forces < 0,2 et corrélation des rangs > 0,95',
                'observe': f'écart {err:.4f}, corrélation {rho:.4f}, {r["iterations"]} itérations', 'tenue': bool(ok)})
    if not ok:
        raise SystemExit('ÉPREUVE ÉCHOUÉE : récupération des forces')

    # cohérence : cas sain (deux ordres d'accord) et artefact (toujours le premier présenté)
    paires = list(itertools.combinations(ids, 2))
    toujours_meilleur = lignes_synthetiques(ids, sha_fiches, lambda a, b, n: a if vraies[a] > vraies[b] else b)
    c1, _, _ = coherence(toujours_meilleur, paires)
    toujours_premier = lignes_synthetiques(ids, sha_fiches, lambda a, b, n: a)
    c0, _, d0 = coherence(toujours_premier, paires)
    ok = c1 == 1.0 and c0 == 0.0 and len(d0) == 66
    res.append({'epreuve': 'cohérence : juge constant (1) et juge qui choisit toujours le premier présenté (0)', 'attendu': '1,0 et 0,0',
                'observe': f'{c1} et {c0}', 'tenue': bool(ok)})
    if not ok:
        raise SystemExit('ÉPREUVE ÉCHOUÉE : cohérence')
    ok = lecture_coherence(0.79)[0].startswith('cohérence sous 0,8') and lecture_coherence(0.97)[0].startswith('cohérence presque parfaite') and lecture_coherence(0.9) == []
    res.append({'epreuve': 'lecture des seuils de cohérence (0,79 ; 0,90 ; 0,97)', 'attendu': 'réserve basse ; aucune ; réserve presque parfaite',
                'observe': 'conforme' if ok else 'non conforme', 'tenue': bool(ok)})
    if not ok:
        raise SystemExit('ÉPREUVE ÉCHOUÉE : seuils de cohérence')

    # artefacts d'entrée
    attendre_garde('artefact : une ligne manquante (131)', lambda: valider(saines[:-1], ids, sha_fiches))
    dbl = [dict(l) for l in saines]
    dbl[5] = dict(dbl[4], n=5)
    attendre_garde('artefact : présentation en double', lambda: valider(dbl, ids, sha_fiches))
    hors = [dict(l) for l in saines]
    hors[7]['choix'] = next(x for x in ids if x not in (hors[7]['A'], hors[7]['B']))
    attendre_garde('artefact : choix hors de la paire', lambda: valider(hors, ids, sha_fiches))
    inconnu = [dict(l) for l in saines]
    inconnu[9]['A'] = 'KM-99'
    attendre_garde('artefact : identifiant inconnu', lambda: valider(inconnu, ids, sha_fiches))
    echange = [dict(l) for l in saines]
    echange[10], echange[11] = dict(echange[11], n=10), dict(echange[10], n=11)
    attendre_garde("artefact : deux présentations interverties (ordre non tiré)", lambda: valider(echange, ids, sha_fiches))
    inv = [dict(l) for l in saines]
    inv[12]['A'], inv[12]['B'] = inv[12]['B'], inv[12]['A']
    attendre_garde('artefact : A et B intervertis dans une ligne', lambda: valider(inv, ids, sha_fiches))
    attendre_garde('artefact : onze identifiants', lambda: valider(saines, ids[:-1], sha_fiches))

    # artefacts d'estimation
    sep = lignes_synthetiques(ids, sha_fiches, lambda a, b, n: a if a == ids[0] else (b if b == ids[0] else (a if vraies[a] > vraies[b] else b)))
    Ws = matrice(sep, ids)
    attendre_garde('artefact : un élément gagne tout (maximum de vraisemblance inexistant, sans régularisation déclarée)',
                   lambda: bt(Ws, regularisation_declaree=False))
    rs = bt(Ws, regularisation_declaree=True)
    ok = (not rs['existe']) and rs['estimateur'].startswith('adversaire virtuel') and int(np.argmax(rs['forces'])) == 0
    res.append({'epreuve': 'artefact : même cas avec régularisation déclarée', 'attendu': "estimateur « adversaire virtuel » déclaré, l'élément qui gagne tout en tête",
                'observe': f'{rs["estimateur"]} ; tête : {ids[int(np.argmax(rs["forces"]))]}', 'tenue': bool(ok)})
    if not ok:
        raise SystemExit('ÉPREUVE ÉCHOUÉE : régularisation déclarée')
    attendre_garde('artefact : itérations plafonnées à 1 (non-convergence)', lambda: bt_mm(Wg, max_it=1))
    return res


def main():
    if len(sys.argv) != 5:
        raise SystemExit('usage : PAIRES.jsonl FICHES.json SORTIE.json "$(date -u)"')
    chemin_paires, chemin_fiches, chemin_sortie, heure = sys.argv[1:]
    sha_fiches = sha256(chemin_fiches)
    with open(chemin_paires, encoding='utf-8') as f:
        lignes = [json.loads(x) for x in f if x.strip()]
    ids = sorted({l['A'] for l in lignes} | {l['B'] for l in lignes})

    tests = epreuves(ids, sha_fiches)
    paires = valider(lignes, ids, sha_fiches)
    W = matrice(lignes, ids)
    r = bt(W, regularisation_declaree=True)
    rv, itv = bt_adversaire_virtuel(W)
    c, nc, discord = coherence(lignes, paires)
    premier = sum(1 for l in lignes if l['choix'] == l['A'])
    victoires = W.sum(axis=1)
    ordre = sorted(range(len(ids)), key=lambda i: (-r['forces'][i], -victoires[i], ids[i]))
    _, _, _, e = ordre_tire(ids, sha_fiches)
    sortie = {
        'fichier': 'bradley_terry_kirchner_v2-sortie.json',
        'heure_utc': heure + ' (date -u)',
        'script': {'chemin': __file__, 'sha256': sha256(__file__)},
        'versions': {'python': platform.python_version(), 'numpy': np.__version__},
        'entrees': {'paires': {'chemin': chemin_paires, 'sha256': sha256(chemin_paires)},
                    'fiches': {'chemin': chemin_fiches, 'sha256': sha_fiches}, 'graine_e': e},
        'epreuves_des_gardes': tests,
        'toutes_les_epreuves_tenues': all(t['tenue'] for t in tests),
        'identifiants': ids,
        'matrice_des_victoires': {'lignes_gagnent_contre_colonnes': W.astype(int).tolist()},
        'victoires_sur_22': {ids[i]: int(victoires[i]) for i in range(len(ids))},
        'graphe_fortement_connexe': bool(fortement_connexe(W)),
        'estimateur': r['estimateur'], 'iterations': r['iterations'],
        'forces': {ids[i]: round(float(r['forces'][i]), 6) for i in range(len(ids))},
        'log_forces': {ids[i]: round(float(np.log(r['forces'][i])), 6) for i in range(len(ids))},
        'ordre_final': [ids[i] for i in ordre],
        'sensibilite_adversaire_virtuel': {'forces': {ids[i]: round(float(rv[i]), 6) for i in range(len(ids))},
                                           'ordre': [ids[i] for i in sorted(range(len(ids)), key=lambda i: (-rv[i], ids[i]))], 'iterations': itv},
        'coherence': {'part': round(c, 6), 'paires_concordantes': nc, 'paires': len(paires), 'discordantes': discord},
        'choix_du_premier_presente': {'compte': premier, 'sur': len(lignes), 'part': round(premier / len(lignes), 6)},
        'reserves': lecture_coherence(c),
    }
    with open(chemin_sortie, 'x', encoding='utf-8') as f:
        json.dump(sortie, f, ensure_ascii=False, indent=1)
    print(json.dumps({k: sortie[k] for k in ('toutes_les_epreuves_tenues', 'graphe_fortement_connexe', 'estimateur', 'ordre_final', 'coherence', 'choix_du_premier_presente', 'reserves', 'victoires_sur_22')}, ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()
