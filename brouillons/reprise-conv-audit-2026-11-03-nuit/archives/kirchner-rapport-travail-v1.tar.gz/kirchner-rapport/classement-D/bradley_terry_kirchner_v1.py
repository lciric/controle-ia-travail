#!/usr/bin/env python3
"""Forces de Bradley-Terry du classement K (question 2 de Jan Hendrik Kirchner) — classeur neuf D, v1.

Numpy seulement, aucun appel de modèle. Usage :
    nice -n 10 python3 -I bradley_terry_kirchner_v1.py --heure "$(date -u)"

Ordre d'exécution :
  1. épreuve des gardes (un cas sain, des cas connus, dix artefacts) ; un échec arrête tout, rien n'est écrit ;
  2. vérification de l'empreinte du fichier des fiches et tirage de la graine e (16 premiers hexadécimaux) ;
  3. les douze premières par somme, recalculées depuis notes-K-v1.json (égalités : premier critère, puis deuxième) ;
     arrêt si la coupure tombe dans une égalité ;
  4. vérification des 132 jugements : nombre, ordre de présentation identique au tirage
     numpy.random.default_rng(numpy.random.SeedSequence(e)).permutation(132), chaque paire dans les deux ordres ;
  5. forces de Bradley-Terry par l'algorithme de minoration-majoration de Hunter (2004) :
     estimation déclarée d'avance = régularisée par ALPHA victoire fictive par sens et par paire
     (le maximum de vraisemblance simple n'existe que si le graphe des victoires est fortement connexe ;
     il est calculé et rapporté seulement dans ce cas, sans jamais remplacer l'estimation déclarée) ;
  6. cohérence (part des paires dont les deux ordres concordent), biais de position, triades cycliques.
Écrit bradley_terry_kirchner_v1-sortie.json à côté du script ; refuse d'écraser une sortie existante.

Convention d'indice : les douze identifiants triés ; paires = itertools.combinations dans cet ordre (66) ;
jugement d'indice k = 2 p + o, p l'indice de la paire (a, b), o = 0 : a présenté en premier, o = 1 : b en premier.
"""
import argparse
import hashlib
import itertools
import json
import os
import platform
import sys

import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
FICHES = "/home/claude/scratch/kirchner-rapport/melange-v1/fiches-a-moissonner-v1.json"
SHA_FICHES = "41a5b0b5fe3a7b2626b39b849255a26a8037e79a78fd814772ee770256b802b6"
NOTES = os.path.join(ICI, "notes-K-v1.json")
PAIRES = os.path.join(ICI, "paires-K-v1.jsonl")
SORTIE = os.path.join(ICI, "bradley_terry_kirchner_v1-sortie.json")
CRITERES = [
    "sous_estime_d_apres_la_moisson",
    "lie_a_ce_que_fait_kirchner",
    "premiere_experience_faisable_en_jours",
    "resultat_qui_ferait_changer_d_avis_enonce_d_avance",
]
N_TETE = 12
SEUIL_COHERENCE = 0.8          # protocole : sous 0,8, réserve écrite
SEUIL_PRESQUE_PARFAITE = 0.95  # consigne : cohérence presque parfaite d'un juge unique = réserve (seuil fixé ici)
ALPHA = 0.5                    # régularisation déclarée : victoires fictives par sens et par paire
ALPHAS_SENSIBILITE = (0.1, 0.5, 1.0)
TOL = 1e-12
MAX_ITER = 200000


class GardeEchouee(Exception):
    """Arrêt explicite : jamais de repli silencieux."""


# ---------------------------------------------------------------- outils
def sha256_fichier(chemin):
    h = hashlib.sha256()
    with open(chemin, "rb") as f:
        for bloc in iter(lambda: f.read(1 << 16), b""):
            h.update(bloc)
    return h.hexdigest()


def verifier_empreinte(chemin, attendu):
    obtenu = sha256_fichier(chemin)
    if obtenu != attendu:
        raise GardeEchouee(f"empreinte de {chemin} : {obtenu} au lieu de {attendu}")
    return obtenu


def graine_depuis_empreinte(sha_hex):
    return int(sha_hex[:16], 16)


# ---------------------------------------------------------------- étape 3 : tête par somme
def cle_somme(notes4):
    return (-sum(notes4), -notes4[0], -notes4[1])


def tete_par_somme(lignes, n=N_TETE):
    """lignes : liste de (identifiant, [quatre notes]). Rend (ordre complet, identifiants de tête triés)."""
    for ident, notes4 in lignes:
        if len(notes4) != 4 or any((not isinstance(x, int)) or x < 0 or x > 3 for x in notes4):
            raise GardeEchouee(f"notes invalides pour {ident} : {notes4}")
    ordre = sorted(lignes, key=lambda r: (cle_somme(r[1]), r[0]))
    if len(ordre) < n:
        raise GardeEchouee(f"{len(ordre)} fiches pour une tête de {n}")
    if len(ordre) > n and cle_somme(ordre[n - 1][1]) == cle_somme(ordre[n][1]):
        raise GardeEchouee(
            f"coupure dans une égalité non départagée par les deux premiers critères : "
            f"{ordre[n - 1][0]} et {ordre[n][0]} ({ordre[n - 1][1]} contre {ordre[n][1]})"
        )
    return ordre, sorted(r[0] for r in ordre[:n])


# ---------------------------------------------------------------- étape 4 : jugements
def ordre_attendu(tete_triee, e):
    paires = list(itertools.combinations(tete_triee, 2))
    perm = np.random.default_rng(np.random.SeedSequence(e)).permutation(2 * len(paires))
    attendu = []
    for rang, k in enumerate(perm, 1):
        p, o = divmod(int(k), 2)
        a, b = paires[p]
        attendu.append((rang, int(k), p, (a, b) if o == 0 else (b, a)))
    return paires, attendu


def verifier_jugements(jugements, tete_triee, e):
    paires, attendu = ordre_attendu(tete_triee, e)
    if len(jugements) != len(attendu):
        raise GardeEchouee(f"{len(jugements)} jugements pour {len(attendu)} attendus")
    vus = set()
    for j, (rang, k, p, (a, b)) in zip(jugements, attendu):
        for champ in ("rang", "indice", "paire", "premier", "second", "gagnant", "position_du_gagnant", "raison"):
            if champ not in j:
                raise GardeEchouee(f"champ {champ} absent au rang {rang}")
        if (j["rang"], j["indice"], j["paire"]) != (rang, k, p):
            raise GardeEchouee(
                f"ordre de présentation différent du tirage au rang {rang} : "
                f"{(j['rang'], j['indice'], j['paire'])} au lieu de {(rang, k, p)}"
            )
        if (j["premier"], j["second"]) != (a, b):
            raise GardeEchouee(f"présentation {(j['premier'], j['second'])} au rang {rang}, attendue {(a, b)}")
        if j["gagnant"] not in (a, b):
            raise GardeEchouee(f"gagnant {j['gagnant']} hors de la paire au rang {rang}")
        pos = "premier" if j["gagnant"] == a else "second"
        if j["position_du_gagnant"] != pos:
            raise GardeEchouee(f"position du gagnant incohérente au rang {rang}")
        if not str(j["raison"]).strip():
            raise GardeEchouee(f"raison vide au rang {rang}")
        if (a, b) in vus:
            raise GardeEchouee(f"présentation {(a, b)} en double")
        vus.add((a, b))
    for a, b in paires:
        if (a, b) not in vus or (b, a) not in vus:
            raise GardeEchouee(f"paire {(a, b)} absente dans un des deux ordres")
    return paires


# ---------------------------------------------------------------- étape 5 : Bradley-Terry
def matrice_victoires(jugements, ids):
    idx = {x: i for i, x in enumerate(ids)}
    W = np.zeros((len(ids), len(ids)))
    for j in jugements:
        g = j["gagnant"]
        perdant = j["second"] if g == j["premier"] else j["premier"]
        W[idx[g], idx[perdant]] += 1.0
    return W


def atteignables(A, s):
    vus, pile = {s}, [s]
    while pile:
        u = pile.pop()
        for v in np.nonzero(A[u])[0]:
            v = int(v)
            if v not in vus:
                vus.add(v)
                pile.append(v)
    return vus


def composantes_fortes(W):
    A = W > 0
    n = A.shape[0]
    acc = [atteignables(A, i) for i in range(n)]
    restants, comps = set(range(n)), []
    while restants:
        i = min(restants)
        comp = sorted(j for j in restants if j in acc[i] and i in acc[j])
        comps.append(comp)
        restants -= set(comp)
    return comps


def fortement_connexe(W):
    return len(composantes_fortes(W)) == 1


def bradley_terry(W, alpha, tol=TOL, max_iter=MAX_ITER):
    n = W.shape[0]
    hors_diag = 1.0 - np.eye(n)
    Wa = W + alpha * hors_diag
    if alpha == 0 and not fortement_connexe(W):
        raise GardeEchouee("maximum de vraisemblance inexistant : graphe des victoires non fortement connexe")
    w = Wa.sum(axis=1)
    N = Wa + Wa.T
    if np.any(w <= 0):
        raise GardeEchouee("un élément sans aucune victoire : force nulle, estimation impossible")
    p = np.ones(n)
    for it in range(1, max_iter + 1):
        denom = (N / (p[:, None] + p[None, :])).sum(axis=1)
        p_new = w / denom
        p_new = p_new / np.exp(np.mean(np.log(p_new)))
        if not np.all(np.isfinite(p_new)):
            raise GardeEchouee("forces non finies")
        if np.max(np.abs(np.log(p_new) - np.log(p))) < tol:
            return p_new, it
        p = p_new
    raise GardeEchouee(f"pas de convergence en {max_iter} itérations")


def verifier_monotonie(p, W):
    """Plan équilibré (même nombre de jugements par paire) : l'ordre des forces doit suivre les victoires."""
    v = W.sum(axis=1)
    n = len(v)
    for i in range(n):
        for k in range(n):
            if v[i] > v[k] and not p[i] > p[k]:
                raise GardeEchouee("forces incohérentes avec les victoires dans un plan équilibré")
            if v[i] == v[k] and not np.isclose(p[i], p[k], rtol=1e-8):
                raise GardeEchouee("victoires égales mais forces différentes dans un plan équilibré")


# ---------------------------------------------------------------- étape 6 : cohérence et contrôles
def coherence(jugements, paires):
    par_paire = {}
    for j in jugements:
        par_paire.setdefault(frozenset((j["premier"], j["second"])), []).append(j["gagnant"])
    desaccords = []
    for a, b in paires:
        v = par_paire[frozenset((a, b))]
        if len(v) != 2:
            raise GardeEchouee(f"paire {(a, b)} jugée {len(v)} fois")
        if v[0] != v[1]:
            desaccords.append([a, b])
    return 1.0 - len(desaccords) / len(paires), desaccords


def biais_de_position(jugements):
    return sum(1 for j in jugements if j["position_du_gagnant"] == "premier") / len(jugements)


def triades_cycliques(W, ids):
    n = len(ids)
    M = W > W.T  # majorité stricte ; une paire partagée 1-1 n'a pas d'arc
    cycles = []
    for i, j, k in itertools.combinations(range(n), 3):
        if (M[i, j] and M[j, k] and M[k, i]) or (M[j, i] and M[k, j] and M[i, k]):
            cycles.append([ids[i], ids[j], ids[k]])
    return cycles


# ---------------------------------------------------------------- étape 1 : épreuve des gardes
def _doit_arreter(nom, fonction):
    try:
        fonction()
    except GardeEchouee as exc:
        return {"epreuve": nom, "attendu": "arrêt", "obtenu": "arrêt", "message": str(exc), "tenue": True}
    return {"epreuve": nom, "attendu": "arrêt", "obtenu": "passe", "message": "", "tenue": False}


def _jugements_simules(tete, e, forces, rng):
    _, attendu = ordre_attendu(tete, e)
    sortie = []
    for rang, k, p, (a, b) in attendu:
        pa = forces[a] / (forces[a] + forces[b])
        g = a if rng.random() < pa else b
        sortie.append({"rang": rang, "indice": k, "paire": p, "premier": a, "second": b, "gagnant": g,
                       "position_du_gagnant": "premier" if g == a else "second", "raison": "simulé"})
    return sortie


def epreuve_des_gardes(e):
    res = []
    tete = [f"S-{i:02d}" for i in range(1, 13)]
    vraies = dict(zip(tete, np.exp(np.linspace(-1.0, 1.0, 12))))
    rng = np.random.default_rng(np.random.SeedSequence(entropy=e, spawn_key=(1,)))
    sains = _jugements_simules(tete, e, vraies, rng)

    # cas sain : toutes les gardes passent, l'ordre retrouvé suit l'ordre vrai
    paires = verifier_jugements(sains, tete, e)
    W = matrice_victoires(sains, tete)
    p_reg, _ = bradley_terry(W, ALPHA)
    verifier_monotonie(p_reg, W)
    rang_vrai = np.argsort(np.argsort([vraies[x] for x in tete]))
    rang_estime = np.argsort(np.argsort(p_reg))
    spearman = float(np.corrcoef(rang_vrai, rang_estime)[0, 1])
    sain_ok = spearman >= 0.8
    entree = {"epreuve": "cas sain simulé (12 éléments, forces vraies exp(linspace(-1, 1)), 132 jugements tirés)",
              "attendu": "passe, corrélation de rang au moins 0,8", "obtenu": f"passe, corrélation de rang {spearman:.3f}",
              "tenue": sain_ok, "message": ""}
    if fortement_connexe(W):
        p_mv, it = bradley_terry(W, 0.0)
        entree["maximum_de_vraisemblance"] = f"existe, convergé en {it} itérations"
    else:
        entree["maximum_de_vraisemblance"] = "inexistant pour ce tirage (graphe non fortement connexe), signalé"
    res.append(entree)
    c, _ = coherence(sains, paires)
    res.append({"epreuve": "cohérence calculée sur le cas sain", "attendu": "valeur dans [0, 1]",
                "obtenu": f"{c:.3f}", "tenue": 0.0 <= c <= 1.0, "message": ""})

    # cas connus
    p2, _ = bradley_terry(np.array([[0.0, 3.0], [1.0, 0.0]]), 0.0)
    res.append({"epreuve": "deux éléments, 3 victoires contre 1", "attendu": "rapport des forces 3",
                "obtenu": f"{p2[0] / p2[1]:.6f}", "tenue": bool(np.isclose(p2[0] / p2[1], 3.0)), "message": ""})
    p3, _ = bradley_terry(np.array([[0.0, 2.0, 1.0], [1.0, 0.0, 2.0], [2.0, 1.0, 0.0]]), 0.0)
    res.append({"epreuve": "trois éléments en cycle symétrique", "attendu": "forces égales",
                "obtenu": str(np.round(p3, 6).tolist()), "tenue": bool(np.allclose(p3, 1.0)), "message": ""})

    # artefacts : chaque garde doit arrêter
    res.append(_doit_arreter("une ligne manquante", lambda: verifier_jugements(sains[:-1], tete, e)))
    res.append(_doit_arreter("une ligne en double à la place de la dernière",
                             lambda: verifier_jugements(sains[:-1] + [dict(sains[0])], tete, e)))
    permute = list(sains)
    permute[0], permute[1] = permute[1], permute[0]
    res.append(_doit_arreter("deux lignes interverties (ordre différent du tirage)",
                             lambda: verifier_jugements(permute, tete, e)))
    mauvais = [dict(x) for x in sains]
    mauvais[5]["gagnant"] = "S-99"
    res.append(_doit_arreter("gagnant hors de la paire", lambda: verifier_jugements(mauvais, tete, e)))
    meme_ordre = [dict(x) for x in sains]
    a, b = meme_ordre[7]["premier"], meme_ordre[7]["second"]
    meme_ordre[7]["premier"], meme_ordre[7]["second"] = b, a
    res.append(_doit_arreter("une paire présentée deux fois dans le même ordre",
                             lambda: verifier_jugements(meme_ordre, tete, e)))
    position = [dict(x) for x in sains]
    position[9]["position_du_gagnant"] = "second" if position[9]["position_du_gagnant"] == "premier" else "premier"
    res.append(_doit_arreter("position du gagnant incohérente", lambda: verifier_jugements(position, tete, e)))
    lignes_egalite = [(f"T-{i:02d}", [2, 2, 2, 2] if i <= 13 else [0, 0, 0, 0]) for i in range(1, 17)]
    res.append(_doit_arreter("coupure de la tête dans une égalité", lambda: tete_par_somme(lignes_egalite)))
    total = np.triu(np.ones((12, 12)), 1) * 2.0  # ordre total, séparation parfaite
    res.append(_doit_arreter("séparation parfaite sans régularisation (maximum de vraisemblance inexistant)",
                             lambda: bradley_terry(total, 0.0)))
    p_sep, _ = bradley_terry(total, ALPHA)
    res.append({"epreuve": "séparation parfaite avec la régularisation déclarée", "attendu": "converge, forces décroissantes",
                "obtenu": "converge", "tenue": bool(np.all(np.diff(p_sep) < 0)), "message": ""})
    res.append(_doit_arreter("une seule itération permise (non-convergence)",
                             lambda: bradley_terry(W, ALPHA, max_iter=1)))
    res.append(_doit_arreter("empreinte attendue fausse pour le fichier des fiches",
                             lambda: verifier_empreinte(FICHES, "0" * 64)))
    res.append(_doit_arreter("note hors de 0 à 3",
                             lambda: tete_par_somme([("U-01", [4, 0, 0, 0])] + [(f"U-{i:02d}", [1, 1, 1, 1]) for i in range(2, 14)])))
    echecs = [r for r in res if not r["tenue"]]
    if echecs:
        raise GardeEchouee(f"épreuve des gardes non tenue : {[r['epreuve'] for r in echecs]}")
    return res


# ---------------------------------------------------------------- principal
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--heure", required=True, help="sortie de date -u au lancement")
    args = ap.parse_args()
    if os.path.exists(SORTIE):
        raise GardeEchouee(f"{SORTIE} existe déjà : on n'écrase jamais (nouvelle version = nouveau nom)")

    sha_fiches = verifier_empreinte(FICHES, SHA_FICHES)
    e = graine_depuis_empreinte(sha_fiches)
    epreuves = epreuve_des_gardes(e)

    with open(NOTES, encoding="utf-8") as f:
        notes = json.load(f)
    lignes = []
    for fiche in notes["fiches"]:
        n4 = [fiche["notes"][c]["note"] for c in CRITERES]
        if sum(n4) != fiche["somme"]:
            raise GardeEchouee(f"somme écrite fausse pour {fiche['id']}")
        lignes.append((fiche["id"], n4))
    ordre_somme, tete = tete_par_somme(lignes)

    jugements = []
    with open(PAIRES, encoding="utf-8") as f:
        for num, ligne in enumerate(f, 1):
            if not ligne.strip():
                raise GardeEchouee(f"ligne vide {num} dans {PAIRES}")
            jugements.append(json.loads(ligne))
    paires = verifier_jugements(jugements, tete, e)

    W = matrice_victoires(jugements, tete)
    victoires = W.sum(axis=1)
    comps = composantes_fortes(W)
    p_reg, it_reg = bradley_terry(W, ALPHA)
    verifier_monotonie(p_reg, W)
    mv = None
    if len(comps) == 1:
        p_mv, it_mv = bradley_terry(W, 0.0)
        mv = {"existe": True, "iterations": it_mv,
              "log_forces": {tete[i]: float(np.log(p_mv[i])) for i in range(len(tete))}}
    else:
        mv = {"existe": False,
              "raison": "graphe des victoires non fortement connexe : la vraisemblance croît sans borne",
              "composantes_fortes": [[tete[i] for i in c] for c in comps]}

    sens = {}
    ordres_sens = []
    for a in ALPHAS_SENSIBILITE:
        pa, _ = bradley_terry(W, a)
        verifier_monotonie(pa, W)
        sens[str(a)] = {tete[i]: float(np.log(pa[i])) for i in range(len(tete))}
        ordres_sens.append(tuple(np.argsort(-pa, kind="stable")))

    rang_somme = {ident: r for r, (ident, _) in enumerate(ordre_somme, 1)}
    # ordre final : force régularisée décroissante ; égalité exacte de forces (victoires égales) départagée
    # par l'ordre des sommes (somme, premier critère, deuxième), puis par l'identifiant — règle déclarée
    final = sorted(range(len(tete)), key=lambda i: (-round(float(np.log(p_reg[i])), 9), rang_somme[tete[i]], tete[i]))
    egalites = []
    for i, k in itertools.combinations(range(len(tete)), 2):
        if victoires[i] == victoires[k]:
            egalites.append([tete[i], tete[k]])

    c, desaccords = coherence(jugements, paires)
    reserves = []
    if c < SEUIL_COHERENCE:
        reserves.append(f"cohérence {c:.3f} sous {SEUIL_COHERENCE} : réserve du protocole")
    if c >= SEUIL_PRESQUE_PARFAITE:
        reserves.append(
            f"cohérence {c:.3f} au moins {SEUIL_PRESQUE_PARFAITE} pour un juge unique qui se souvient de ses jugements : "
            "elle mesure la stabilité de ses préférences, pas l'absence de biais d'ordre ; réserve de la consigne"
        )
    if mv["existe"] is False:
        reserves.append("maximum de vraisemblance simple inexistant ; forces rapportées = estimation régularisée déclarée")

    sortie = {
        "titre": "Forces de Bradley-Terry du classement K — classeur neuf D, v1",
        "heure_utc_lancement": args.heure,
        "versions": {"python": platform.python_version(), "numpy": np.__version__},
        "entrees": {
            "fiches": {"chemin": FICHES, "sha256": sha_fiches},
            "notes": {"chemin": NOTES, "sha256": sha256_fichier(NOTES)},
            "paires": {"chemin": PAIRES, "sha256": sha256_fichier(PAIRES)},
            "script": {"chemin": os.path.abspath(__file__), "sha256": sha256_fichier(os.path.abspath(__file__))},
        },
        "graine": {"regle": "entier des 16 premiers hexadécimaux du sha256 du fichier des fiches", "e": e,
                   "tirage": "numpy.random.default_rng(numpy.random.SeedSequence(e)).permutation(132)"},
        "epreuve_des_gardes": epreuves,
        "tete_par_somme": [{"rang": r, "id": ident, "notes": n4, "somme": sum(n4)}
                           for r, (ident, n4) in enumerate(ordre_somme, 1)],
        "tete_douze": tete,
        "jugements": {"nombre": len(jugements), "ordre_conforme_au_tirage": True, "chaque_paire_dans_les_deux_ordres": True},
        "victoires_sur_22": {tete[i]: int(victoires[i]) for i in range(len(tete))},
        "estimation_declaree": {"methode": "minoration-majoration de Hunter (2004), régularisée",
                                "alpha_victoires_fictives_par_sens_et_par_paire": ALPHA, "iterations": it_reg,
                                "normalisation": "moyenne des log-forces nulle",
                                "log_forces": {tete[i]: float(np.log(p_reg[i])) for i in range(len(tete))},
                                "forces": {tete[i]: float(p_reg[i]) for i in range(len(tete))}},
        "maximum_de_vraisemblance_simple": mv,
        "sensibilite_alpha": {"log_forces": sens,
                              "ordre_identique_pour_tous_les_alpha": len(set(ordres_sens)) == 1},
        "ordre_final": [tete[i] for i in final],
        "regle_d_egalite": "forces égales (victoires égales) départagées par l'ordre des sommes (somme, premier critère, deuxième), puis par l'identifiant",
        "egalites_de_victoires": egalites,
        "coherence": {"part_des_paires_concordantes": c, "paires_discordantes": desaccords,
                      "seuil_protocole": SEUIL_COHERENCE, "seuil_presque_parfaite": SEUIL_PRESQUE_PARFAITE},
        "biais_de_position": {"part_des_victoires_du_premier_presente": biais_de_position(jugements)},
        "triades_cycliques_de_la_majorite": triades_cycliques(W, tete),
        "reserves": reserves,
    }
    with open(SORTIE, "x", encoding="utf-8") as f:
        json.dump(sortie, f, ensure_ascii=False, indent=1)
        f.write("\n")
    print(json.dumps({"ordre_final": sortie["ordre_final"], "victoires": sortie["victoires_sur_22"],
                      "coherence": c, "discordantes": desaccords, "reserves": reserves,
                      "gardes_tenues": all(r["tenue"] for r in epreuves)}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    try:
        main()
    except GardeEchouee as exc:
        print(f"ARRÊT : {exc}", file=sys.stderr)
        sys.exit(2)
