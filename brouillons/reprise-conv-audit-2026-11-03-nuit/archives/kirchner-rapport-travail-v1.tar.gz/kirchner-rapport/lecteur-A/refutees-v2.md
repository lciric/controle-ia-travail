# Fiches réfutées — lecteur A, rapport des idées sur la question 2 de Kirchner — v2

Lecteur A (normalisation et dédoublonnage), 3 novembre 2026, 13:45 UTC (`date -u`). Remplace la v1 (`refutees-v1.md`, gardée telle quelle) pour une seule raison : une seconde source, la course de l'organisme (paquet `source-2-course-kirchner-seconde-v1.json`, sha256 `6c915ecb…`, vérifié avant lecture). Fichier des fiches : `fiches-normalisees-v2.json` (29 fiches, K-001 à K-029).

Règle appliquée (inchangée) : une fiche est réfutée seulement si une source citée (une pièce servie et sa section, ou une source primaire ouverte) contredit son énoncé central, ou si la fiche se contredit elle-même. Jamais par accord ou désaccord des modèles, jamais par une critique de méthode, jamais par le retrait d'une idée par son auteur. La seconde source ne comporte ni critiques ni sorties des juges : ses éléments n'apportent aucune objection.

Éléments de la seconde source : 37 lus en entier (33 fiches, dont 4 fusions, et 4 fusions inachevées, lues comme des fiches) ; 3 fiches classées « à corriger » par l'aiguilleur n'ont de contenu nulle part dans la sortie : **comptées, non lues**.

## Résultat

**Aucune fiche réfutée** (0 sur 29). Les candidats examinés pour K-001 à K-014 en v1 restent valables (voir `refutees-v1.md`) ; ci-dessous, ce qu'apporte la seconde source. Aucune source primaire n'est citée contre un énoncé : aucun `WebFetch`.

## Affirmations de la seconde source confrontées aux pièces (aucune ne porte sur un énoncé central)

| Fiche | Affirmation de la source | Ce que dit la pièce | Portée |
|---|---|---|---|
| K-027 | Nos résultats « établissent qu'avec n tentatives et un retour binaire, le taux de fausses promotions atteint 1 − (1 − α)ⁿ » | Pièce nos résultats, point 3 : « borne écrite d'avance : avec n tentatives et arrêt à la première promotion, 1 − (1 − α)ⁿ (0,560 à n = 16) » | Une borne, pas un taux établi. L'appui est mal lu ; l'énoncé (épuisement du banc par la sélection des meneurs) n'est pas touché. |
| K-008, K-025 | Les tricheries qui percent « visent le haut du classement » (§3, figure 32) | Pièce Kirchner, point 3 : une seule triche signalée a atteint le top 3 ; aucune copie de format ni tromperie du relecteur ne l'a atteint | La pièce ne parle pas de visée. Argument d'appui ; les énoncés (baisse du rappel par décile ; part de recombinaisons au-delà de la médiane) ne sont pas contredits. |
| K-013 | « Deux garde-fous successifs du même juge partageaient le même trou » (nos résultats, §2) | Pièce nos résultats, point 2 : quatre types de tricheurs qui recousaient des acceptations passaient (75 à 95 % de 200 courses) ; le juge n'avait pas de nulle pour les mélanges de ses propres acceptations | La pièce ne parle pas de deux garde-fous successifs. Appui relu de travers ; l'énoncé (ratés corrélés de deux étages du même modèle) n'est pas en cause. |
| K-022 | Kirchner « n'en a pas planté » (§3) | Pièce Kirchner, point 3 : aucun test du moniteur contre des tricheries plantées dans le texte lu, « à vérifier en G avant de l'affirmer » | Affirmation plus forte que la pièce. Contexte ; l'énoncé (rappel sur triche née de la sélection contre triche instruite) n'est pas touché. |
| K-018 | 2608.28945 et 2605.06390 supposeraient que des moniteurs boîte blanche prendront le relais quand la chaîne de pensée deviendra opaque | Pièce Kirchner, point 4 : remèdes déclarés = échafaudage de contrôle et surveillabilité ; point 6 : 2605.06390 ne traite ni des moniteurs ni de la surveillabilité | Non appuyé par les pièces, sans les contredire frontalement. Argument de sous-estimation ; l'énoncé (échec des sondes génériques contre leur plancher sur des trajectoires de chercheurs automatiques) n'est pas en cause. |
| K-020 | Kale et coll. compareraient « binairement » présence ou absence d'indice de surveillance | Pièce Kirchner, points 0 et 3 : seul le résumé de 2508.19461 a été lu | Non vérifiable dans les pièces ; à laisser au moissonneur. |

## Incohérences internes relevées dans la seconde source (aucune ne porte sur un énoncé central)

| Fiche | Incohérence | Portée |
|---|---|---|
| K-008 | Une version formule l'hypothèse comme « filtrer par le moniteur puis sélectionner » ; mesuré sur les survivants du même moniteur, le rappel serait nul par construction ; sa première expérience mesure le rappel parmi les 10 % meilleurs au score, sans filtrage explicite. | Écart entre hypothèse et protocole d'une version ; l'énoncé central de la fiche n'est pas touché. |
| K-016 | Taux de fausses disqualifications simulé : 0,25 dans l'hypothèse, 0,30 dans l'expérience. | Paramètre. |
| K-023 | Deux critères : la mesure qui tue porte sur une pente (intervalle excluant −2 points par rival), le changement d'avis sur une différence entre 0 et 5 rivaux (≥ −3 points). | Règle de décision à unifier avant préenregistrement. |
| K-018 | Deux critères proches mais distincts (borne inférieure de la sonde contre le plancher ; AUROC contre le 95e centile des sondes aléatoires). | Idem. |
