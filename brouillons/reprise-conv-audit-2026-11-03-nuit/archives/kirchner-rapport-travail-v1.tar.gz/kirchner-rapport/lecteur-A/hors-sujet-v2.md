# Fiches hors sujet — lecteur A, rapport des idées sur la question 2 de Kirchner — v2

Lecteur A (normalisation et dédoublonnage), 3 novembre 2026, 13:45 UTC (`date -u`). Remplace la v1 (`hors-sujet-v1.md`, gardée telle quelle) pour une seule raison : la seconde source (course de l'organisme, `source-2-course-kirchner-seconde-v1.json`, sha256 `6c915ecb…`). Fichier des fiches : `fiches-normalisees-v2.json` (29 fiches).

Critère appliqué (inchangé) : « K » si la fiche répond à la question de Kirchner ou touche ce qu'il construit (pièce « Kirchner » servie : classement, moniteur de triche, banc tenu à l'écart, Petri, harnais ouvert, garde de capacité, forum, remèdes déclarés) ; « hors sujet » sinon. Une fusion inachevée de la seconde source a été lue comme une fiche : n'avoir jamais été jugée n'est pas une raison de l'écarter. Les 3 fiches classées « à corriger » sans contenu dans la sortie sont comptées, non lues : elles ne sont ni « K » ni « hors sujet ».

## Résultat

**Aucune fiche hors sujet** (0 sur 29) : les 29 fiches sont classées « K ». Les cas limites de la v1 (K-001, K-003, K-004, K-007, K-012) gardent leur motif (voir `hors-sujet-v1.md`).

## Cas limites apportés par la seconde source, classés « K », et pourquoi

| Fiche | Ce qui la rend limite | Pourquoi « K » |
|---|---|---|
| K-026 | Plateforme simulée (simulateur public de contrôle et juge de l'organisme) ; la source dit elle-même qu'une validation sur texte serait nécessaire avant toute conclusion sur le moniteur de Kirchner. | Elle porte sur la validité du seuil du moniteur de triche après sélection par le classement, deux outils de Kirchner. |
| K-018 | Sondes sur activations, outil absent du harnais. | Elle vise le remède « Better control scaffolding » et la surveillance des chercheurs automatiques quand la triche n'est plus écrite, et mesure le rappel après sélection par le classement. |
| K-017, K-028 | Expériences sur l'organisme seul. | Elles portent sur le forum partagé et sur l'archive de méthodes réutilisables du harnais (pièce Kirchner, point 2, item 1), avec une issue chiffrée qui changerait la conduite d'une boucle de sa forme. |
