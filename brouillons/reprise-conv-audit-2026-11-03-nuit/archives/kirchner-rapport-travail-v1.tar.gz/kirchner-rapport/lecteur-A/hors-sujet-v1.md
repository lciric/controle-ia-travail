# Fiches hors sujet — lecteur A, rapport des idées sur la question 2 de Kirchner — v1

Lecteur A (normalisation et dédoublonnage), 3 novembre 2026, 12:09 UTC (`date -u`). Fichier des fiches : `fiches-normalisees-v1.json` (même dossier).

Critère appliqué (protocole Kirchner v1, section 2) : une fiche est classée « K » si elle répond à la question de Kirchner (« Pick an open problem in AI alignment you think is underrated. What experiment would you run first, and what result would change your mind? ») ou si elle touche ce qu'il construit (pièce « Kirchner » servie : chercheurs automatiques qui grimpent un classement, moniteur de triche, banc tenu à l'écart, Petri, harnais ouvert faible-vers-fort, garde de capacité, remèdes déclarés) ; « hors sujet » sinon. Qu'une fiche réponde, au sens des trois éléments (problème dit sous-estimé, première expérience, résultat qui ferait changer d'avis), est noté dans son champ `manques`, pas ici.

## Résultat

**Aucune fiche hors sujet** (0 sur 14) : les 14 fiches sont classées « K ».

## Cas limites, classés « K », et pourquoi

| Fiche | Ce qui la rend limite | Pourquoi « K » |
|---|---|---|
| K-001 | Expérience sur l'organisme seul (tricheurs scriptés de classe W2) ; aucun outil de Kirchner touché directement ; idée retirée par son auteur dans la version la plus récente. | Elle pose un problème d'alignement (trou de couverture d'un sélecteur figé), une expérience et des issues chiffrées, et la source la rattache explicitement à la question de savoir si le danger d'une boucle « à la Kirchner » est la couverture ou la réutilisation du banc réservé. C'est le lien le plus faible des quatorze. |
| K-004 | Expérience sur l'organisme seul ; la source dit elle-même qu'elle « ne dit rien de Kirchner directement » (test de structure). | Elle répond à la question (problème, expérience, issue à seuil) et la source en tire un argument pour ajouter un moniteur non sélectionnant à côté du classement de Kirchner (rôle de Petri). |
| K-007 | Expérience sur l'organisme seul. | Elle porte sur la réutilisation du banc tenu à l'écart pour choisir parmi les meneurs (pièce Kirchner, point 2, item 5), avec une issue qui changerait la recommandation pour une boucle de sa forme. |
| K-003 | Expérience sur l'organisme seul. | Elle teste l'effet de la transparence des règles d'un filtre, transposé au moniteur avant exécution de Kirchner (pièce Kirchner, point 2, item 4) et à « Better control scaffolding ». |
| K-012 | Fiche-sac d'épreuves minimales par instrument, sans problème unique. | Chaque épreuve porte sur un instrument de Kirchner (classement, banc tenu à l'écart, garde, Petri, banc de surveillabilité, forum, échafaudage de contrôle). |
