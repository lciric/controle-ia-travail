# Fiches réfutées — lecteur A, rapport des idées sur la question 2 de Kirchner — v1

Lecteur A (normalisation et dédoublonnage), 3 novembre 2026, 12:09 UTC (`date -u`). Source : tour du collisionneur (quinze cellules : conceptions, critiques croisées, réponses). Fichier des fiches : `fiches-normalisees-v1.json` (même dossier).

Règle appliquée (protocole Kirchner v1, section 3, étape A ; protocole Heimersheim v1, section 2) : une fiche est réfutée seulement si une source citée (une pièce servie et sa section, ou une source primaire ouverte et citée) contredit son énoncé central, ou si la fiche se contredit elle-même. Jamais par accord ou désaccord des modèles, jamais par une critique de méthode, jamais par le retrait de l'idée par son auteur.

## Résultat

**Aucune fiche réfutée** (0 sur 14).

Aucune objection ne cite de source primaire qu'il aurait fallu ouvrir : les objections sourcées renvoient toutes à une pièce servie ou à la question servie, vérifiées ci-dessous sur le texte des pièces. Aucun `WebFetch` n'a été fait.

## Candidats examinés, et pourquoi aucun ne réfute

### Objections sourcées

| Fiche | Objection (résumé) | Source vérifiée | Pourquoi ce n'est pas une réfutation |
|---|---|---|---|
| K-001 | « Vrai par construction » ; « ne fait que répliquer l'attaque A1 » | Pièce nos résultats, point 3 : W2, classe que le nul v8 déclare ne pas couvrir, promue 12 fois sur 12 par un proposeur de langage, avec ou sans retour des verdicts | La pièce **appuie** l'énoncé (absence de correction) au lieu de le contredire, et pour un agent de langage, pas pour des scripts. Le retrait par l'auteur n'est pas une réfutation. |
| K-002 | Contamination de l'étiquetage par le forum | Pièce Kirchner, point 5 (annexe D.5 : retirer le forum coûte environ six points) | Objection à la mesure du rappel dans une boucle active, pas à l'énoncé sur la contagion. |
| K-003 | Explication du plateau de Petri présentée comme acquise | Pièce Kirchner, point 5 (annexe D.3) | La pièce dit que le classement ne prédit plus Petri au-delà de la médiane ; elle ne donne pas de cause. L'objection vise un argument d'appui (requalifié en hypothèse), pas l'énoncé (effet de la transparence des règles). |
| K-004 | Non jugeable avec les taux rapportés (W2 12 sur 12 ; copie renommée 0 sur 200) | Pièce nos résultats, points 2 et 3 | Les chiffres sont exacts et rendent **l'ancien plan** non jugeable ; ils ne disent rien de la corrélation d'erreurs à une dose intermédiaire, que la version la plus récente mesure. |
| K-006 | Sélectionner et auditer avec le même moniteur, ou un LoRA entraîné contre un vérificateur, rejoint « ce qui est déjà pris » | Question servie, « Ce qui est déjà pris » | Question de nouveauté et de plan (étape C), pas une contradiction de l'énoncé ; corrigé dans la version la plus récente (moniteurs distincts, aucun gradient). |
| K-006 | Conscience d'évaluation notée par un juge non spécifié ; juges de ce type au plafond | Pièce nos résultats, point 4 (κ = 0) ; pièce Kirchner, point 2, item 8 | Vise une variable secondaire, retirée de l'hypothèse. Note : la pièce Kirchner dit la conscience d'évaluation notée de 1 à 10 par conversation (annexe E.1) sans nommer l'auditeur ; l'auditeur Sonnet 4.6 y est dit pour Petri (item 6). |
| K-006 | Banc P3 figé, plancher de sondes défini pour des activations | Pièce nos résultats, point 6 | Vise une plateforme d'une version, corrigée (traces régénérées, plancher retiré). |
| K-006, K-008 | Statut « VÉRIFIÉ » sans web ni exécution | Question servie, « Règles d'intégrité » | Vise l'étiquette de statut d'un appui, corrigée ; l'énoncé n'est pas en cause. |
| K-007 | La borne 1 − (1 − α)ⁿ supposerait des tentatives adaptatives | Pièce nos résultats, point 3 | La pièce écrit « avec n tentatives et arrêt à la première promotion », sans le mot « adaptatives » ; l'objection ne contredit pas l'énoncé (effet de réutilisation au-delà de la multiplicité), qui en sort au contraire reformulé. |
| K-008 | Contrôle par le juge v8 mal défini pour la classe de recombinaison | Pièce nos résultats, points 2 et 3 | Exact sur le contrôle d'une version (W2 non couverte, recoutures couvertes) ; corrigé (classes séparées) ; l'énoncé (baisse du rappel parmi les violations retenues) n'est pas en cause. |
| K-008 | Sur l'organisme, la promotion ne classe pas et seule W2 passe | Pièce nos résultats, points 1 et 2 | Vise la plateforme d'une version (le processus de richesse promeut ou non) ; corrigé (micro-harnais à score calculable). |
| K-008 | Le forum déplace la distribution des scores | Pièce Kirchner, point 5 (annexe D.5) | Confusion de composition à contrôler, pas une contradiction. |
| K-008 | Filtre avant classement : « score seul » ne mesure pas le pipeline | Pièce Kirchner, point 2, item 4 | Le moniteur avant exécution lit le code ; l'objection porte sur l'estimand d'une version, corrigé (audit passif avant filtrage, analyse « filtre puis score » à part). |
| K-009 | T0.3 décrit « calibré par permutation » | Pièce nos résultats, point 6 : « calibré sur 1 000 épisodes honnêtes entiers » | La pièce contredit **une description de détail** de la fiche, pas son énoncé central (l'arrêt par e-valeurs calibrées vaut le 99e centile). Voir aussi l'incohérence interne ci-dessous. |
| K-009 | Seuil de −0,5 point justifié par la dispersion de Petri ; dose-réponse prise pour un équivalent de Petri | Pièce Kirchner, point 5 (annexe D.3 : 5,65 ± 0,61 et 5,42 ± 0,64) | Le ± de la pièce est une dispersion entre méthodes ; l'objection invalide un seuil et une équivalence d'échelle (abandonnés), pas l'énoncé. |
| K-009 | Résolution avec 3 lois vraies ; référence instable | Pièce nos résultats, point 5 (3 sur 3 avec le plan plein, 2 sur 3 avec le plan gelé) | Limite de puissance d'un contrôle, pas une contradiction. |
| K-012 | Analogie « classement au plafond comme nos juges (κ = 0) » ; écart 1,00 contre 0,91 pris pour une référence à battre | Pièce Kirchner, point 5 ; pièce nos résultats, point 4 | Vise deux lignes du tableau d'instruments, corrigées ou requalifiées ; l'énoncé de la fiche n'est pas en cause. |
| K-014 | Soumissions corrélées : 26 des 39 signalements sont des relances | Pièce Kirchner, point 3 | Vise la formule de l'ancien plan (indépendance), remplacée par une mesure directe sur verdicts répétés ; l'énoncé (franchissement par resoumission) n'est pas contredit. |

### Incohérences internes relevées (aucune ne porte sur un énoncé central)

| Fiche | Incohérence | Portée |
|---|---|---|
| K-010 | Une version dit la prédiction « effet plus fort sur l'écart proposition/code » testable dans le seul bras des violations suscitées, alors que ce bras n'étiquette que la relance et les données au format d'un banc. | Sous-prédiction intestable dans le plan ; l'énoncé (moindre rappel sur sa propre famille, mesuré par l'interaction) reste cohérent. |
| K-009 | La version la plus récente accepte que T0.3 n'est pas calibré par permutation, puis le décrit encore comme une « nulle de permutation d'épisodes honnêtes entiers ». | Détail de protocole. |
| K-003 | Seuil de perte de puissance de 0,10 dans l'hypothèse et de 15 points dans la règle de changement d'avis. | Paramètre secondaire. |
| K-008 | Une version donne deux effectifs pour le même seuil (au moins 150 et au moins 200 violations retenues par bras) ; dans des versions antérieures (remplacées) : « 500 trajectoires plantées » pour 200 plants calculés, et une règle de rejet dont le seuil (−0,10) ne correspondait à aucun des seuils posés (−0,20 et −0,05). | Effectifs illustratifs et règles remplacées dans les versions les plus récentes. |
