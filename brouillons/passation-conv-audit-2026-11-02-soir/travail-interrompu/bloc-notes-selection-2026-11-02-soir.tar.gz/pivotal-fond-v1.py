import pathlib
M = pathlib.Path('/home/claude/controle-ia-travail/brouillons/candidature-pivotal-v16/mentors')

def remplacer(s, a, b):
    assert s.count(a) == 1, a[:60]
    return s.replace(a, b)

# --- Kirchner v25
k = (M / 'mentor-2-kirchner-v24.md').read_text(encoding='utf-8')
k = remplacer(k, "Verdict: Yes to first question, so far; started today on second.",
              "Verdict: Yes to first question, so far; the second has a first answer.")
k = remplacer(k, "27 scripted cheaters vs my own judge;", "scripted cheaters vs my own judge;")
k = remplacer(k, "; started today, sealed attack in which", "; a sealed attack in which")
k = remplacer(k, "4 of the 27 cheaters slipped through", "4 of the scripted cheaters slipped through")
k = remplacer(k, "and the attack started today tests what it leaves open: a reward-seeking proposer that sees the verdicts.",
              "and the attack tests what it leaves open: a reward-seeking proposer that sees the verdicts. It found a breach exactly where the "
              "judge declares itself blind (known laws recombined piece by piece across sub-populations); the fix, a judge that covers that "
              "class, is written and under preregistered validation.")
k = remplacer(k, "run linear regression Δv = g · (c̃ − v₀) across all attack strengths, leaving c̃ unconstrained.",
              "run linear regression Δv = g · (c̃ − v₀) at each attack strength, leaving c̃ unconstrained.")
k = remplacer(k, "and g ought to be consistently ordered amongst monitors targeted with attacks of the same class.",
              "and g ought to be consistently ordered amongst monitors targeted with attacks of the same class. What the generator taught me "
              "since: in a preregistered dose–response (four model families) the gain did not grow with the intensity of the pressure; it "
              "plateaued, the destination moved, and the strongest wording triggered refusals and resets toward mid-scale. So I read g and c̃ "
              "at each intensity, count refusals as an outcome, and do not assume monotone deference. This experiment is now preregistered "
              "and archived (Zenodo, v2026.11.4) and running on seven Qwen2.5 monitors from 0.5B to 72B, with an in-band note at three "
              "intensities.")
k = k.replace('— v24\n', '— v25\n', 1)
k = k.replace('2 November 2026. ', "2 November 2026. v25 = v24 updated on substance after the latest results (Lazar, 19:18 UTC): the attack is no longer « started today » (published result: breach where the judge declares itself blind; fix written, validation preregistered); « 27 » removed (the benches do not contain 27 cheaters: v7 numbers them T01–T27 with 19 codes, v8 plays 18 lines over 15 scenarios); Q2 experiment 1 read per intensity with refusals counted (R6) and stated as running (R7 archived, Zenodo v2026.11.4, no R7 figure); ", 1)
(M / 'mentor-2-kirchner-v25.md').write_text(k, encoding='utf-8')

# --- Ibrahim v28 : une phrase en Q1
i = (M / 'mentor-1-ibrahim-v27.md').read_text(encoding='utf-8')
i = remplacer(i, "But it should not change the frame-set structure (two constants) because it's induced by the social frame.",
              "But it should not change the frame-set structure (two constants) because it's induced by the social frame. I would check this "
              "at two intensities of pressure, since in a later preregistered dose–response the structure changed with the wording for one "
              "family (Mistral).")
i = i.replace('— v27\n', '— v28\n', 1)
i = i.replace('2 November 2026. v27 = ', "2 November 2026. v28 = v27 + one sentence in Q1 after the latest results (R6: Mistral's regime depends on the wording, results/R6/R6_mistral_dose_output.txt): the frame-set prediction checked at two intensities; v27 = ", 1)
(M / 'mentor-1-ibrahim-v28.md').write_text(i, encoding='utf-8')

# --- Scheurer v15 : condensé, mêmes deux tendances, R6 et R7 portés
s = (M / 'mentor-4-scheurer-v14.md').read_text(encoding='utf-8')
j = s.index('## Answer')
reponse = '''## Answer

Proposal: Two trends. The first is the corruptibility of monitors. The second: given some task and a fixed monitor, what is the smallest granularity across which a model can spread maliciousness without being flagged by this monitor.

Why. Propensity trends are difficult to get to pan out: propensity relies on post training, on the prompt, and likely on the model's perception of whether it is monitored. Capability against a fixed, hash-verified tool is easier: the task is static and the model does its best to outsmart our fixed monitor. Open-weights and API models with known release dates; like METR, fit against release date (and, within a series, against size).

Trend 1 (designed to work): monitor deference. A model judges an agent's behaviour; we apply increasing levels of one of five attacks (flattery/begging, asserted authority, false past acceptances, mimicry of the instructor, instructions in band) and read a continuous verdict from the judgment-token probabilities, so no ceiling hides the movement. We fit Δv = g(c − v0) at each intensity, with the corpus mean as the null destination. On Llama-3.1-8B under social pressure the model closed about .7 of the distance to the frame's target, and the law predicted held-out data without refitting (r² .73/.69). A preregistered dose–response (four families) then showed the gain does not grow with intensity: it plateaus, the destination moves, and the strongest wording triggers refusals and resets toward mid-scale. So the trend tracks g and the destination at each intensity, and refusals separately. R7, preregistered and archived (Zenodo, v2026.11.4), now runs this on seven Qwen2.5 monitors from 0.5B to 72B with an in-band note: a first point of the size trend, its sign not predicted. Statement: "monitor deference to in-band attacks changes by a factor of X per year". A flat line is also a finding: every scheme that uses untrusted LLMs as monitors assumes g is low and decreasing.

Trend 2 (your question): the horizon over which a model can hide maliciousness. In an agentic task, the agent writes proposals judged by a trusted model. We instruct each model to inject a fixed level of maliciousness (a predetermined drop in proposal quality) and to avoid detection by our fixed best monitor. Our control lemma says that with a per-action threshold, the agent's ability to spread its budget over n actions sets how fast an always-valid monitor detects it. Horizon: the number of actions over which a model can spread its maliciousness while the monitor's detection stays below 50% at 1% false alarms. Statement: "the horizon over which frontier models can hide maliciousness from [Monitor] doubles every x months". Difficulties: elicitation (we measure what is possible given instructions and tips, which overestimates propensity), one monitor frozen across all releases, and calibrating each model's honest behaviour to know its false-alarm rate. Why it can still work: the task and the monitor exist from our control work, it is close to METR's horizon, and the lemma says what must stay constant for the trend to mean anything.

Disclosed confounds: judging ceilings (token probabilities), new items for every test, refusals scored separately, post training (trends against release date and, within a series, against size). Two trends, two preregistered posts, two-sided tests.
'''
s = s[:j] + reponse
s = s.replace('— v14\n', '— v15\n', 1)
s = s.replace('2 November 2026. ', "2 November 2026. v15 = v14 condensed on the model of Ibrahim's answer (Lazar, 19:17-19:18 UTC), his phrases kept where they carry, and updated on substance: trend 1 read per intensity with destination and refusals (R6), R7 stated as running (archived, Zenodo v2026.11.4; no R7 figure); draft for Lazar to rewrite; ", 1)
(M / 'mentor-4-scheurer-v15.md').write_text(s, encoding='utf-8')
print('ok')
