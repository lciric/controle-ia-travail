"""Contre-lecture R2 du préenregistrement de validation du nul v9 : mutations du contre-lecteur, en mémoire, contre **toute** la
suite `essais/test_nul_v9.py` (33 essais), avec la mécanique de `essais/mutations_nul_v9.py` (recompilation de la fonction
dans l'espace réel du module, puis restauration). Aucun fichier du dépôt n'est écrit ; le dépôt n'est que lu.

Puis une sonde sans mutation : la valeur certifiée contre « valeur atteinte + tolérance » quand l'optimisation est tronquée
(paliers et pas réduits), sur les 30 mondes de l'essai de domination.

  nice -n 10 python3 -I -B sondes_mutations_contre_lecture_v1.py /chemin/vers/orchestrator
"""

import io
import math
import os
import random
import sys
import unittest

RACINE = os.path.abspath(sys.argv[1])
sys.path[:0] = [RACINE, os.path.join(RACINE, "essais")]
sys.dont_write_bytecode = True

from essais import mutations_nul_v9 as mv  # noqa: E402
from essais import test_nul_v9 as t9  # noqa: E402
from pole import nul_v9  # noqa: E402
from pole import selection_pari as sp  # noqa: E402

B = t9.banc
ORDRE_23_A = ('    elif NON_TENUE in lecture["perte_de_puissance"].values():\n        issue = "puissance perdue"\n'
              '    elif not valeurs_art or any(v != TENUE for v in valeurs_art):\n        issue = "non concluant (banc sans dents)"\n')
ORDRE_23_N = ('    elif not valeurs_art or any(v != TENUE for v in valeurs_art):\n        issue = "non concluant (banc sans dents)"\n'
              '    elif NON_TENUE in lecture["perte_de_puissance"].values():\n        issue = "puissance perdue"\n')
ORDRE_12_A = ('    elif NON_TENUE in lecture["fatales"].values():\n        issue = "trou"\n'
              '    elif NON_TENUE in lecture["perte_de_puissance"].values():\n        issue = "puissance perdue"\n')
ORDRE_12_N = ('    elif NON_TENUE in lecture["perte_de_puissance"].values():\n        issue = "puissance perdue"\n'
              '    elif NON_TENUE in lecture["fatales"].values():\n        issue = "trou"\n')

# (libellé, [(module, fonction, ancien, nouveau), ...])
MUTATIONS = [
    ("C1 certificat sans le terme d'écart : min(0, f) aux deux endroits", [
        (nul_v9, "maximiser_par_lots", "certificat = np.minimum(0.0, f + np.maximum(0.0, V - actif.sum(axis=0)))",
         "certificat = np.minimum(0.0, f)"),
        (nul_v9, "_certificats", "return f, np.minimum(0.0, f + np.maximum(0.0, V - actif.sum(axis=0)))",
         "return f, np.minimum(0.0, f)")]),
    ("C2 t_c = n (toutes les instances, masque ignoré) au lieu des instances de la coupe", [
        (nul_v9, "maximiser_par_lots", "np.maximum(0.0, V - actif.sum(axis=0))", "np.maximum(0.0, V - actif.shape[0])"),
        (nul_v9, "_certificats", "np.maximum(0.0, V - actif.sum(axis=0))", "np.maximum(0.0, V - actif.shape[0])")]),
    ("C3 masque des instances futures décalé d'un cran (< devient <=)", [
        (nul_v9, "_coupes", "dedans = (np.arange(n) < t).astype(float)", "dedans = (np.arange(n) <= t).astype(float)")]),
    ("C4 sommets : moyenne des gradients d'un morceau au lieu du maximum", [
        (nul_v9, "maximiser_par_lots", "V = V + g[:, sl].max(axis=1)", "V = V + g[:, sl].mean(axis=1)"),
        (nul_v9, "_certificats", "V = V + (L.T @ (M[p] * inv)).T.max(axis=1)", "V = V + (L.T @ (M[p] * inv)).T.mean(axis=1)")]),
    ("C5 valeur du membre = meilleure valeur atteinte + 10^-3 (confiance dans l'optimiseur)", [
        (nul_v9, "detail_morceaux_groupe", "valeur, atteinte = float(bornes[sel].max()), float(atteintes[sel].max())",
         "valeur, atteinte = float(atteintes[sel].max()) + 1e-3, float(atteintes[sel].max())")]),
    ("G1 mode décisif : --lignes accepté", [(B, "principal", "if args.lignes or ", "if ")]),
    ("G2 mode décisif : autre nombre de répétitions accepté", [
        (B, "principal", "args.repetitions != REPETITIONS_DECISIVES or ", "")]),
    ("G3 mode décisif toujours refusé (le cas sain n'est jamais joué)", [
        (B, "principal", "if args.lignes or args.repetitions != REPETITIONS_DECISIVES or args.duree_max_s != DUREE_MAX_S:",
         "if True:")]),
    ("G4 durée transmise à la course plafonnée à 8 h (la garde accepte 48 h, la course coupe à 8 h)", [
        (B, "principal", "debut, args.duree_max_s)", "debut, min(args.duree_max_s, 28800.0))")]),
    ("G5 monotonie : écart de richesse non gardé (seule la promotion inversée arrête)", [
        (B, "verifier_monotonie", "if max(ecarts) > TOLERANCE_MONOTONIE + 1e-6 or (ev9", "if (ev9")]),
    ("L1 ordre des issues : « banc sans dents » avant « puissance perdue »", [(B, "lire_v9", ORDRE_23_A, ORDRE_23_N)]),
    ("L2 ordre des issues : « puissance perdue » avant « trou »", [(B, "lire_v9", ORDRE_12_A, ORDRE_12_N)]),
]


def suite_complete():
    return unittest.defaultTestLoader.loadTestsFromModule(t9)


def jouer():
    r = unittest.TextTestRunner(stream=io.StringIO(), verbosity=0).run(suite_complete())
    return r.testsRun, [(str(t), txt) for t, txt in r.failures + r.errors]


def derniere(txt):
    lignes = [l for l in txt.strip().splitlines() if l.strip()]
    return lignes[-1][:200] if lignes else ""


def principal():
    n, echecs = jouer()
    print(f"témoin : {n} essais, {len(echecs)} en échec", flush=True)
    for libelle, parties in MUTATIONS:
        restaurer = []
        try:
            for module, nom, ancien, nouveau in parties:
                restaurer.append(mv.appliquer_fonction(module, nom, ancien, nouveau))
        except LookupError as e:
            print(f"NON APPLIQUÉE  {libelle} : {e}", flush=True)
            for r in reversed(restaurer):
                r()
            continue
        try:
            n, echecs = jouer()
        finally:
            for r in reversed(restaurer):
                r()
        verdict = "tuée" if echecs else "SURVIVANTE"
        print(f"{verdict}  {libelle} : {len(echecs)}/{n} essais en échec", flush=True)
        for t, txt in echecs[:3]:
            print(f"      {t.split(' ')[0]} : {derniere(txt)}", flush=True)
    n, echecs = jouer()
    print(f"témoin après restauration : {n} essais, {len(echecs)} en échec", flush=True)
    sonde_troncature()


def sonde_troncature():
    """Les 30 mondes de `test_cas_sain_valeur_domine…` (mêmes graines), optimisation tronquée (un palier, un pas) : combien
    d'instants où (a) la valeur certifiée, (b) la meilleure valeur atteinte + 10⁻³, sont sous la log-vraisemblance du monde."""
    sauve = (nul_v9.PALIERS_MU, nul_v9.PAS_MAX_PAR_PALIER)
    instants = [25, 50, 100, 150, 200]
    for paliers, pas in (((1e-2,), 1), ((1e-2,), 3), (sauve[0], sauve[1])):
        nul_v9.PALIERS_MU, nul_v9.PAS_MAX_PAR_PALIER = paliers, pas
        sous_cert = sous_att = total = 0
        pire_cert = -math.inf
        for r in range(30):
            rng = random.Random(1000 + r)
            L = t9._lois(2000 + r)
            S1, S2 = L["S1"], L["S2"]
            j, s = rng.randrange(t9.DIM), rng.uniform(-1.5, 1.5)
            q = {"type": "fixe", "probas": [rng.random() + 0.01 for _ in range(t9.K)]}
            eps = rng.uniform(0.0, 0.4)
            choix = r % 4
            if choix == 0:
                monde, nom = B._par_sp(S1, S2), "morceaux:sous_population"
            elif choix == 1:
                monde, nom = B._si_seuil(j, s, S1, S2), f"morceaux:seuil:z{j}"
            elif choix == 2:
                monde, nom = B._melange([B._si_seuil(j, s, S2, S1), q], [1 - eps, eps]), f"morceaux:seuil:z{j}"
            else:
                monde = B._par_sp(B._melange([S1, S2, q], [0.24, 0.56, 0.2]), B._melange([S1, S2, q], [0.6, 0.2, 0.2]))
                nom = "morceaux:sous_population"
            instances, issues = t9._donnees(monde, 200, rng)
            d = nul_v9.detail_morceaux_groupe(nul_v9.membres_morceaux([S1, S2], t9.DIM), sp.Cache(issues, instances),
                                              issues, instants)
            lv = nul_v9.log_vraisemblance(monde, issues, instances)
            for t in instants:
                total += 1
                sous_cert += d[nom][t]["valeur"] < lv[t - 1] - 1e-9
                sous_att += d[nom][t]["atteinte"] + 1e-3 < lv[t - 1] - 1e-9
                pire_cert = max(pire_cert, lv[t - 1] - d[nom][t]["valeur"])
        print(f"troncature paliers={paliers} pas={pas} : instants {total} ; valeur certifiée sous la vraisemblance du monde : "
              f"{sous_cert} (pire écart {pire_cert:.3g}) ; atteinte + 1e-3 sous la vraisemblance : {sous_att}", flush=True)
    nul_v9.PALIERS_MU, nul_v9.PAS_MAX_PAR_PALIER = sauve


if __name__ == "__main__":
    principal()
