"""Contre-lecture R2 : fermeture **dynamique** des imports du banc v9 — modules du dépôt chargés pendant une course réduite
(une répétition de M01, M06 et T01|v1 à la graine exploratoire 5, appelée par `jouer_ligne` en mémoire ; aucun fichier écrit ;
taux non lus), comparés à `FICHIERS_GELES`. Lecture seule du dépôt.

  nice -n 10 python3 -I -B fermeture_dynamique_v1.py /chemin/vers/orchestrator
"""

import importlib.util
import os
import sys

RACINE = os.path.realpath(sys.argv[1])
sys.path.insert(0, RACINE)
spec = importlib.util.spec_from_file_location("banc_v9_fermeture", os.path.join(RACINE, "demonstrations", "banc_tricheurs_v9.py"))
banc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(banc)


def charges():
    fichiers = set()
    for m in list(sys.modules.values()):
        f = os.path.realpath(getattr(m, "__file__", "") or "")
        if f.startswith(RACINE + os.sep):
            fichiers.add(os.path.relpath(f, RACINE))
    return fichiers | {"demonstrations/banc_tricheurs_v9.py", "demonstrations/banc_tricheurs_v8.py",
                       "demonstrations/banc_tricheurs_v7.py"}


avant = charges()
for nom, nul, role in (("M01", "v9", "fatale"), ("M06", "v9", "fatale"), ("T01", "v1", "artefact_requis")):
    banc.jouer_ligne(5, nom, nul, role, 1)
apres = charges()
geles = set(banc.FICHIERS_GELES)
print("chargés au chargement du banc = gelés :", avant == geles)
print("chargés après la course réduite = gelés :", apres == geles)
print("chargés en plus des gelés :", sorted(apres - geles), " ; gelés jamais chargés :", sorted(geles - apres))
