"""Contre-lecture du préenregistrement de validation du nul v9 : recalcul indépendant des tables de la section 6.

Lecture seule du dépôt ; les fonctions statistiques sont celles du banc v8 (gelé), rechargées par chemin ; un recalcul
indépendant (scipy.stats.binom) les recoupe."""

import importlib.util
import os
import sys

RACINE = sys.argv[1]
sys.path.insert(0, RACINE)
spec = importlib.util.spec_from_file_location("b8", os.path.join(RACINE, "demonstrations", "banc_tricheurs_v8.py"))
b8 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b8)
from scipy.stats import binom  # noqa: E402

N, A = 1000, 0.05


def max_tenue(m, niveau=0.05, seuil=A):
    return b8.promotions_max_tenue(N, m, seuil, niveau)


def min_non_tenue(m, niveau=0.05, seuil=A):
    sortie = []
    for j in range(1, m + 1):
        a = niveau / (m - j + 1)
        x = 0
        while b8.binom_sf(x, N, seuil) > a:
            x += 1
        sortie.append(x)
    return sortie


def recoupe_max_tenue(m, niveau=0.05, seuil=A):
    sortie = []
    for j in range(1, m + 1):
        a = niveau / (m - j + 1)
        x = -1
        while binom.cdf(x + 1, N, seuil) <= a:
            x += 1
        sortie.append(x)
    return sortie


def recoupe_min_non_tenue(m, niveau=0.05, seuil=A):
    sortie = []
    for j in range(1, m + 1):
        a = niveau / (m - j + 1)
        x = 0
        while binom.sf(x - 1, N, seuil) > a:
            x += 1
        sortie.append(x)
    return sortie


print("fatales, max pour tenue (18) :", max_tenue(18), "recoupe", recoupe_max_tenue(18))
print("fatales, min pour non tenue (18) :", min_non_tenue(18), "recoupe", recoupe_min_non_tenue(18))
print("artefact, min (Clopper-Pearson basse > alpha) :", b8.promotions_min_artefact(N))
cp62, cp63 = b8.clopper_pearson(62, N), b8.clopper_pearson(63, N)
print("Clopper-Pearson 62/1000 :", cp62, " 63/1000 :", cp63)
print("pertes, max pour tenue (5) :", max_tenue(5), "recoupe", recoupe_max_tenue(5))
print("pertes, min pour non tenue (5) :", min_non_tenue(5), "recoupe", recoupe_min_non_tenue(5))
mt18, mt5, mn5 = max_tenue(18), max_tenue(5), min_non_tenue(5)
for p in (0.01, 0.02, 0.03, 0.04, 0.05):
    print(f"fatale vrai taux {p} : P(tenue) rang 1 {binom.cdf(mt18[0], N, p):.4f} ; rang 18 {binom.cdf(mt18[-1], N, p):.4f}")
for d in (0.02, 0.03, 0.04, 0.05):
    print(f"perte vraie {d} : P(tenue) rang 1 {binom.cdf(mt5[0], N, d):.4f} ; rang 5 {binom.cdf(mt5[-1], N, d):.4f}")
for d in (0.06, 0.07, 0.08, 0.10, 0.11):
    print(f"perte vraie {d} : P(non tenue) rang 1 (>= {mn5[0]}) {binom.sf(mn5[0] - 1, N, d):.4f} ; rang 5 (>= {mn5[-1]}) "
          f"{binom.sf(mn5[-1] - 1, N, d):.4f}")
# Holm : rang 1 du test « non tenue » des pertes = la plus petite valeur p ; avec I02 seule au-dessus de la marge, c'est I02.
print("valeur p basse de 67 et 68 pertes à la marge 0,05 :", b8.binom_sf(67, N, 0.05), b8.binom_sf(68, N, 0.05))
print("valeur p haute de 34 et 35 pertes à la marge 0,05 :", b8.binom_cdf(34, N, 0.05), b8.binom_cdf(35, N, 0.05))
