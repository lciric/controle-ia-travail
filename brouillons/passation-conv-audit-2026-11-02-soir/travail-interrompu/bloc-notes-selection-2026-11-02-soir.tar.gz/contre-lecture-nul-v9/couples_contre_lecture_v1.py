"""Couples de remplacement de la contre-lecture R2 n° 1 du préenregistrement de validation du nul v9 (brouillon 2).

Chaque « ancien » est pris **dans le fichier** (plage de lignes ou fragment littéral) et vérifié présent une seule fois dans le
brouillon 2 ; les couples sont ensuite appliqués dans l'ordre à une copie en mémoire (chaque « ancien » doit encore y être
unique au moment de son application), puis le texte obtenu est contrôlé : bloc des empreintes = 14 lignes au format du banc,
noms = `FICHIERS_GELES`, empreintes = fichiers présents ; jeton absent. Écrit le JSON et le texte appliqué dans le bloc-notes.

  nice -n 10 python3 -I -B couples_contre_lecture_v1.py ORCHESTRATEUR SORTIE_JSON SORTIE_TEXTE_APPLIQUE
"""

import hashlib
import json
import os
import re
import sys

RACINE, SORTIE_JSON, SORTIE_TEXTE = sys.argv[1], sys.argv[2], sys.argv[3]
BROUILLON = os.path.join(RACINE, "prereg", "preenregistrement-validation-nul-v9-brouillon2.md")
with open(BROUILLON, encoding="utf-8") as f:
    TEXTE = f.read()
LIGNES = TEXTE.splitlines(keepends=True)
BANC = "7e4bff5995df2a7d62a4f5a2f5f9176da614e657a55b05183325fa2fc6e24e44"
CL = "`prereg/contre-lecture-preenregistrement-validation-nul-v9-v1.md`"


def plage(a, b):
    """Lignes a à b (numérotation à partir de 1, b comprise), sans le saut de ligne final."""
    return "".join(LIGNES[a - 1:b]).rstrip("\n")


COUPLES = []


def couple(ancien, nouveau):
    COUPLES.append({"ancien": ancien, "nouveau": nouveau})


# T1 — statut
couple("**Statut : brouillon 2, non contre-lu, non scellé.**",
       "**Statut : brouillon 2, contre-lu (R2 n° 1, " + CL + "), couples appliqués ; non scellé.**")
# T2 — paragraphe du marqueur : la correction est faite
couple(plage(10, 14),
       "**La correction du code demandée par ce brouillon est faite** (annexe B) au commit `e58cfec` (2 novembre 2026) : le banc\n"
       "gèle une durée maximale de **48 heures** (`demonstrations/banc_tricheurs_v9.py`, ligne 84, `DUREE_MAX_S = 48 * 3600.0`,\n"
       "comparée ligne 524 ; docstring et usage, lignes 40 et 47) ; un essai (`test_duree_du_mode_decisif_48_h`) et une mutation\n"
       "(« durée du mode décisif non gardée ») sont ajoutés. Le jeton de la section 12 porte désormais l'empreinte du banc corrigé,\n"
       f"`{BANC}` (sha256 au commit `e58cfec`, égal à l'arbre de\n"
       "travail ; recalculé par le contre-lecteur R2 n° 1 le 2 novembre à 19:06 UTC). Écart à l'annexe B : l'essai livré ne joue pas\n"
       "le cas sain demandé (B1 de la contre-lecture, essais à ajouter, aucun fichier gelé touché).")
# T3 à T5 — tableau de l'en-tête : banc, essais, mutations au commit e58cfec
couple(plage(23, 23),
       "| `demonstrations/banc_tricheurs_v9.py` | le banc, corrigé au commit `e58cfec` (durée 48 h, annexe B) ; à `5e352ec` : "
       f"`c7ab5470…fcf466`, non gelé | `{BANC}` |")
couple(plage(24, 24),
       "| `essais/test_nul_v9.py` | essais ; au commit `e58cfec` (un essai de plus, durée) ; version finale : celle du commit de "
       "scellement (essais de B1 ajoutés ; fichier non gelé) | `9eb966ad4220fc6cd297eef53ebec36a0f77655c2eadaceedc52ad72a1a67b21` |")
couple(plage(25, 25),
       "| `essais/mutations_nul_v9.py` | banc de mutations ; au commit `e58cfec` (34 mutations) ; version finale : celle du commit "
       "de scellement (mutations de B1 ajoutées ; fichier non gelé) | `9cb305e45b8c005564184df621e68c05f1ac36b92e520ee081dbed735a252d16` |")
# T6 — passages des essais et des mutations
couple(plage(29, 33),
       plage(29, 33) + " Au commit `e58cfec` (banc,\n"
       "essais et mutations corrigés), passage du contre-lecteur R2 n° 1 : 33 essais réussis, 32 sous-essais (19:11:17 à 19:11:58 UTC) ;\n"
       "34 mutations tuées pour la raison attendue sur 34, témoin 22 essais sans échec avant et après (19:14:31 à 19:17:56 UTC) ;\n"
       "section 10, L10.")
# T7, T8 — section 0
couple("**Correction du code indispensable, non faite** (annexe B).",
       "**Correction du code faite au commit `e58cfec`** (annexe B ; essais du mode décisif à compléter, B1 de la contre-lecture).")
couple(plage(55, 56),
       "7. **Section 12 : 13 des 14 empreintes gelées calculées au commit `5e352ec`** (aucune n'est touchée par la correction de la\n"
       "   durée) ; la quatorzième, celle du banc v9 corrigé, est celle du commit `e58cfec` (`7e4bff59…6e24e44`), portée par la\n"
       "   contre-lecture R2 n° 1. Le brouillon 1 laissait tout le bloc vide.")
# T9 — section 2 : couvert (même poids du bruit)
couple(plage(130, 133),
       "- **Couvert en plus du v8** : toute loi qui, sur chaque morceau d'une partition à un niveau — par sous-population (un morceau\n"
       "  par valeur de g), ou par un seuil réel quelconque sur un seul trait —, est un mélange de lois connues propre au morceau,\n"
       "  mélangé à une même loi aveugle fixe **avec le même poids** sur tous les morceaux (un même vecteur de bruit r, de masse\n"
       "  commune ; dont le monde W2, tout si/sinon de deux lois connues ou de deux mélanges de lois connues sur un seuil, et ces lois\n"
       "  « avec bruit » commun). Preuve : rapport, section 3 ; refaite par la contre-lecture R2 n° 1, section 1.")
# T10 — section 2 : hors du nul, trous et choix
couple(plage(134, 137),
       "- **Hors du nul v9** (`nul_v9.NON_COUVERT_V9` en dit cinq phrases ; « lois hors de l'archive » n'est que dans la docstring du\n"
       "  module ; la description publique du juge v9 n'existe pas au commit `e58cfec` : celle de l'attaque v4, non commitée, reprend\n"
       "  `NON_COUVERT_V9`) : (a) **trous** — recombinaisons de lois connues que le v9 ne couvre pas : profondeur 2 et plus,\n"
       "  plusieurs seuils sur un même trait, seuils sur une combinaison de traits ; poids qui varient continûment avec l'instance\n"
       "  (aiguillage doux) ; lois tempérées ou inclinées différemment par morceau ; compositions d'étapes ; produits de lois (sauf,\n"
       "  pour une fille, celui des deux parents) ; déformations non monotones (question de nouveauté, T12) ; (b) **hors du nul par le\n"
       "  choix du point suivant**, promouvables comme dépendances nouvelles : bruit aveugle propre à un morceau (autre loi aveugle,\n"
       "  ou même loi aveugle avec un autre poids), loi aveugle seule sur un morceau, loi en escalier aveugle ; (c) lois hors de\n"
       "  l'archive ; mondes avec mémoire (réserve du v8) ; traits non finis (hors de la preuve ; impossibles dans le banc).\n"
       "  `NON_COUVERT_V9` range (b) parmi les non-couverts sans dire que c'est un choix : la description publique du v9 (attaque v4,\n"
       "  production) doit le dire.")
# T11 — section 2 : le choix de revendication n'a pas de défaut
couple("porté par défaut et à confirmer par Lazar** (décision du 2 novembre, défaut sous 48 heures)",
       "proposé, à confirmer par Lazar** (proposition du 2 novembre ; la course n'en dépend pas ; aucune revendication publique\n"
       "  ni mise en production sur ce sens avant sa réponse explicite, section 14, étape 2)")
# T12 — section 3 : M01
couple(plage(168, 168),
       "| M01 | sans parent | S1 si g = 0, S2 si g = 1 (**forme du monde W2**, lois tirées à chaque répétition ; les cartes 0 à 3 "
       "de W2 : essai `test_monde_w2_de_l_attaque_membre_du_nul_v9`) | par morceaux | fatale |")
# T13 — section 3 : I01, I02
couple(plage(189, 191),
       "Les interactions I01 et I02 ne dépendent que du signe de z0·z1 : la loi de l'issue sachant un seul trait, ou sachant g, est\n"
       "la même partout, et aucune loi du nul v9 ne les égale (en général). Un membre par morceaux peut toutefois en approcher une\n"
       "partie : sur un morceau coupé sur un trait, les survivantes, qui dépendent des deux traits, suivent en partie l'autre signe —\n"
       "c'est le prix mesuré (P4). Elles sont « hors de l'archive et hors du nul v9 » au sens de la demande.")
# T14 — section 4 : P6
couple("- **P6** (mesurées sous v9, hors de la classe couverte : taux de fausse promotion des trous restants) : T07 **≤ 0,03** ;",
       "- **P6** (mesurées sous v9, hors de la classe couverte ; taux de fausse promotion pour les recombinaisons de lois connues que\n"
       "  le v9 ne couvre pas, T07, H01, H02, H03, H05 ; pour T12b, dont la fiche dit vrai, et pour H04, dont le bruit propre au\n"
       "  morceau est une dépendance aveugle nouvelle que le choix de la section 2 tient pour neuve, taux de promotion d'une loi qui\n"
       "  n'est pas, ou pas seulement, une recombinaison de l'archive) : T07 **≤ 0,03** ;")
# T15 — section 5 : un scellement, une course décisive
couple(plage(238, 240),
       "- **Un scellement, une course décisive** (règle du v8, section 4 de son préenregistrement, transposée) : aucune course en\n"
       "  mode décisif sur aucune version de ce fichier avant son scellement (vérifié avant scellement : aucun dossier\n"
       "  `resultats/banc-tricheurs-v9-validation-v1*`, aucun compagnon `.sha256` de ce texte) ; la course décisive n'est lancée\n"
       "  qu'après la poussée du commit qui contient ce fichier, son compagnon `.sha256` et les 14 fichiers gelés (section 14). Toute\n"
       "  course décisive dont le manifeste est écrit est rapportée, qu'elle aille à son terme ou non. Une issue rendue (code 0 ou 1)\n"
       "  fait foi : modifier ce fichier, le resceller (nouvelle graine) et rejouer n'est pas admis ; une reprise passe par un\n"
       "  préenregistrement de version nouvelle (R12) qui cite la première course, son dossier et son empreinte. Un arrêt sans taux\n"
       "  (code 3) n'autorise que le rejeu de la section 9, et seulement pour un arrêt que les mêmes graines ne reproduisent pas\n"
       "  (durée) : un arrêt déterministe (erreur, richesse non finie, monotonie violée) est un défaut du code du v9 (section 9).")
# T16 — section 5 : durée, ordre de grandeur
couple("soit onze fois le pire coût mesuré)",
       "soit onze fois le coût moyen mesuré et six fois le pire coût mesuré par ligne, T12b à ≈ 0,93 s par répétition en L3)")
# T17 — section 7 : « puissance perdue » à deux étages
couple(plage(297, 300),
       "2. **« puissance perdue »** — aucune ligne fatale non tenue, une perte au moins non tenue. Lecture **à deux étages** : (i) si\n"
       "   les 18 lignes fatales sont « tenues » **et** les 3 artefacts « tenus » (champs `lecture.fatales` et `lecture.artefact`), et\n"
       "   si la règle de P1b (section 8) ne joue pas, le v9 ferme les lignes, au prix mesuré sur la ligne nommée ; **décision de\n"
       "   Lazar** : accepter le prix (le v9 devient le nul du juge, la description publique dit le prix) ou chercher un nul moins\n"
       "   coûteux (version nouvelle) ; (ii) sinon (une ligne fatale « non jugeable », un artefact non tenu ou non jugeable, ou la\n"
       "   réserve log-linéaire), la perte est établie mais pas la validité sur cette course : « puissance perdue, validité non\n"
       "   établie », le v9 n'est pas proposé en production. Les pertes et puissances observées sont publiées avec leurs bornes.\n"
       "   C'est l'issue attendue sous la marge (a) (P7).")
# T18 — section 7 : usage en production
couple("Le v9 n'est proposé comme nul de production qu'après une issue « confirmé », ou « puissance perdue » avec le prix accepté par\n"
       "Lazar ;",
       "Le v9 n'est proposé comme nul de production qu'après une issue « confirmé », ou « puissance perdue » lue au premier étage\n"
       "(18 lignes fatales et 3 artefacts tenus, réserve log-linéaire non déclenchée) avec le prix accepté par Lazar ;")
# T19 — section 8 : A5 (comptes tronqués, repère M07)
couple(plage(333, 336),
       "- **A5** — **propreté suspecte** : sur une ligne M, un membre par morceaux domine à l'instant final dans moins de la moitié\n"
       "  des répétitions (un 0/1 000 qui ne viendrait pas du nul v9), compté parmi les quatre premiers membres dominants que le banc\n"
       "  rapporte (`dominants` de `jouer_ligne`) : la troncature peut sous-estimer la part des membres par morceaux, jamais la\n"
       "  surestimer ; un A5 déclenché se vérifie, pour l'audit écrit, en recomptant les dominants de la ligne sur les mêmes graines\n"
       "  (calcul déterministe, sans effet sur l'issue). Repère L3 : `morceaux:sous_population` 100/100 sur M01 ; seuils 100/100 sur\n"
       "  M02 ; M07 : seuils 90/100 (z0 : 41, z1 : 49) et `ajuste_log:archive:S2` 10 (le seuil extrême laisse dominer d'autres\n"
       "  membres : à lire, pas un défaut).")
# T20 — section 8 : réserve log-linéaire sous « puissance perdue »
couple("sauf défaut localisé (règle du\nv8).",
       "sauf défaut localisé (règle du\nv8) ; sous « puissance perdue », lecture au second étage (section 7, issue 2). Cette issue, appliquée par le\n"
       "lecteur du verdict (R13), s'ajoute aux cinq de `lire_v9`.")
# T21 à T24 — section 9 : tableau (certificat sous optimisation tronquée, I6)
couple(plage(350, 350),
       "| certificat | valeur ≥ log-vraisemblance du monde, 30 mondes de la famille, 5 instants ; seuil égal à une valeur observée ; "
       "référence scipy (SLSQP) sur 14 instances, à 10⁻² près ; mêmes 30 mondes sous optimisation tronquée (un palier, un pas) : "
       "valeur ≥ log-vraisemblance du monde (à ajouter, I6) | valeur atteinte au départ sous la vraisemblance du monde W2 (ce qu'un "
       "calcul sans certificat rendrait) ; monde hors famille (bruit propre au morceau) non dominé ; sous optimisation tronquée, "
       "« meilleure valeur atteinte + 10⁻³ » sous la vraisemblance du monde (mutation C5 de la contre-lecture, à tuer : I6) | "
       "`CertificatMorceaux.*` |")
couple(plage(355, 355),
       "| lecture gelée | tout tenu → « confirmé », aucun audit | « trou », « puissance perdue », « banc sans dents », « précision "
       "insuffisante », plan incomplet ; audits A1, A3, A4, A5 ; **ordre des issues** : fatale non tenue et perte non tenue → "
       "« trou » ; perte non tenue et artefact non tenu → « puissance perdue » (à ajouter, I5 de la contre-lecture) | "
       "`LectureGelee.*` |")
couple(plage(357, 357),
       "| refus avant course | texte décisif scellé et conforme, sans option → les gardes passent et la course démarre (bouchon de "
       "`jouer_tout` : 31 tâches, 1 000 répétitions, 172 800 s, entropie = empreinte du texte) (à ajouter, B1) | brouillon en mode "
       "décisif, ligne inconnue, graine ≥ 2⁶⁴, graine négative, dossier non vide → code 2, aucune course ; en mode décisif, "
       "`--lignes M01` et `--repetitions 999` → code 2, texte jamais lu (à ajouter, B1) | `test_refus_du_banc_avant_toute_course`, "
       "`test_mode_decisif_cas_sain_et_refus` (B1) |")
couple(plage(358, 358),
       "| durée gelée (48 h) | texte décisif scellé, durée par défaut → durée transmise à chaque ligne = 172 800 s (à ajouter, B1 ; "
       "l'essai livré ne vérifie que la constante) | texte décisif et `--duree-max-s 28800` (l'ancienne valeur) → code 2, texte "
       "jamais lu | `test_duree_du_mode_decisif_48_h` (artefact), `test_mode_decisif_cas_sain_et_refus` (cas sain, B1) |")
couple(plage(359, 359),
       "| liste d'arrêt | course réduite → code 0 | fatale promue → 1 ; durée → 3 (`ArretDuree`) ; erreur du juge → 3 ; **monotonie "
       "violée → 3** (`MonotonieViolee`) : par une promotion sous v9 sans promotion sous v8, et (à ajouter, B1) par la seule richesse, "
       "log W v9 > log W v8 + 10⁻⁶ sans promotion inversée | `test_banc_reduit_et_liste_d_arret` |")
# T25 — section 9 : arrêts déterministes
couple("Après un arrêt, rejeu dans un dossier de sortie neuf, même fichier scellé (règle du\nv8).",
       "Après un arrêt de durée, rejeu dans un dossier de sortie neuf, même fichier scellé (règle du\n"
       "v8). Après un arrêt déterministe (ligne en erreur, richesse non finie, monotonie violée : les mêmes graines le reproduisent),\n"
       "pas de rejeu : l'arrêt est rapporté comme un défaut du code du v9 (le v9 n'est pas validé ; audit écrit, R4) ; réparation =\n"
       "version nouvelle, préenregistrement nouveau.")
# T26 — section 9 : banc de mutations
couple(plage(368, 370),
       "Banc de mutations (`essais/mutations_nul_v9.py`) : au commit `e58cfec`, **34 mutations, 34 tuées pour la raison attendue**,\n"
       "témoin 22 essais sans échec avant et après (passage du contre-lecteur R2 n° 1, 2 novembre, 19:14:31 à 19:17:56 UTC, section 10,\n"
       "L10) ; s'y ajoutent les mutations des essais de B1, I5 et I6 (mode décisif : `--lignes` et répétitions acceptés, cas sain\n"
       "toujours refusé, durée transmise plafonnée à 8 h ; monotonie par la seule richesse ; ordre des issues ; valeur du membre\n"
       "remplacée par la meilleure valeur atteinte + 10⁻³), chacune tuée pour la raison attendue ; à rejouer sur l'arbre scellé.")
# T27 — section 10 : L10
L10 = os.environ.get("LIGNE_L10")
couple(plage(391, 391), plage(391, 391) + "\n" + L10)
# T27 bis — section 10 : quand la marge (a) a été retenue pour le v9
couple("La marge (a) est celle du v8,\nfixée par Lazar avant toute course du v9 ; le choix ne s'appuie pas sur L3 (R3 : la marge est le "
       "prix acceptable, non l'issue\nvisée).",
       "La marge (a) est la règle du v8,\n"
       "écrite avant toute course du v9 ; elle a été retenue pour le v9 le 2 novembre, après L3 et la recommandation (a) du brouillon\n"
       "1, dont l'annexe A donnait l'issue prédite de chaque option : l'option retenue est celle dont l'issue prédite est « puissance\n"
       "perdue », non celle qui promettait « confirmé » (R3 : la marge est le prix acceptable, non l'issue visée).")
# T27 ter — section 11 : H04 n'est pas un trou sous le choix de la section 2
couple("les lignes H01 à H05 mesurent, sans seuil, les trous restants de la description\npublique ;",
       "les lignes H01 à H05 mesurent, sans seuil, ce que la description\n"
       "publique dit hors du nul v9 (des trous pour H01, H02, H03 et H05 ; pour H04, une dépendance aveugle nouvelle, promouvable par\n"
       "le choix de la section 2) ;")
# T28, T29, T30 — section 12
couple("Valeurs du 2 novembre 2026, 18:50 UTC, sur l'arbre de travail égal au commit `5e352ec` pour ces fichiers.",
       "Valeurs du 2 novembre 2026, 18:50 UTC, sur l'arbre de travail égal au commit `5e352ec` pour ces fichiers ; revérifiées par le\n"
       "contre-lecteur R2 n° 1 à 19:06 UTC au commit `e58cfec` (13 inchangées ; le banc corrigé, ci-dessous).")
couple("sa ligne reste un jeton jusqu'à la\ncorrection (au commit, avant correction : `c7ab5470…fcf466`, valeur **à ne pas "
       "geler**). Tant que le jeton est là, le banc\nrefuse le texte (« code importé par la course non gelé »).",
       "sa ligne porte l'empreinte du banc\n"
       "corrigé au commit `e58cfec` (recalculée sur disque et sur `git show e58cfec:…`) ; la valeur d'avant correction\n"
       "(`c7ab5470…fcf466`) n'est pas gelée. Les essais de B1, I5 et I6 ne touchent aucun des 14 fichiers : le bloc ne change\npas.")
couple("<<EMPREINTE_DU_BANC_CORRIGE>>  demonstrations/banc_tricheurs_v9.py", f"{BANC}  demonstrations/banc_tricheurs_v9.py")
# T31 — section 13
couple("## 13. Contre-lecture (R2) — à faire", "## 13. Contre-lecture (R2) — faite (n° 1 : " + CL + ")")
# T32, T33 — section 14
couple(plage(452, 456),
       "1. **Correction du banc (annexe B)** : faite au commit `e58cfec` ; essais et banc de mutations rejoués par le contre-lecteur\n"
       "   (L10) ; jeton de la section 12 remplacé par l'empreinte du banc corrigé. **Reste (B1, I5 et I6 de la contre-lecture)** :\n"
       "   les essais du mode décisif, de la monotonie par la seule richesse, de l'ordre des issues et de la valeur certifiée sous\n"
       "   optimisation tronquée, et leurs mutations, dans `essais/test_nul_v9.py` et `essais/mutations_nul_v9.py` (aucun fichier gelé\n"
       "   touché) ; puis essais et banc de mutations rejoués, toutes les mutations tuées pour la raison attendue :\n"
       "   `nice -n 10 python3 -I -B -m pytest -q -p no:cacheprovider essais/test_nul_v9.py` ;\n"
       "   `nice -n 10 python3 -I -B essais/mutations_nul_v9.py`.")
couple(plage(457, 458),
       "2. **Confirmation du sens de « rien au-delà de l'archive »** par Lazar (section 2 ; proposition : bruit commun). La course\n"
       "   n'en dépend pas et peut avoir lieu sans réponse ; la revendication publique et l'usage en production attendent la réponse\n"
       "   explicite de Lazar (nœud « revendication », sans défaut) ; une réponse contraire arrête ce texte (nul v10).")
# T34, T35 — annexe B
couple("## Annexe B. Correction indispensable du banc v9 (dite, non faite) et marqueur restant",
       "## Annexe B. Correction du banc v9 (faite au commit `e58cfec`) et marqueur levé")
couple(plage(510, 511),
       "**Marqueur levé** : le jeton EMPREINTE_DU_BANC_CORRIGE (entre doubles chevrons) du bloc de la section 12 porte l'empreinte du\n"
       "banc corrigé au commit `e58cfec` (`7e4bff59…6e24e44`). Les marqueurs du brouillon 1 sont levés (marge : annexe A). Écart à\n"
       "cette annexe, dit : l'essai livré (`test_duree_du_mode_decisif_48_h`) joue l'artefact (28 800 s → code 2, texte jamais lu) et\n"
       "vérifie la constante, mais pas le cas sain demandé (durée par défaut → la course démarre, durée transmise 172 800 s) : B1 de la\n"
       "contre-lecture.")


def verifier():
    for i, c in enumerate(COUPLES, 1):
        n = TEXTE.count(c["ancien"])
        assert n == 1, f"couple {i} : « ancien » trouvé {n} fois dans le brouillon 2 : {c['ancien'][:80]!r}"
        assert c["ancien"] != c["nouveau"], f"couple {i} : identique"
    texte = TEXTE
    for i, c in enumerate(COUPLES, 1):
        n = texte.count(c["ancien"])
        assert n == 1, f"couple {i} : « ancien » trouvé {n} fois au moment de son application"
        texte = texte.replace(c["ancien"], c["nouveau"])
    assert "<<EMPREINTE_DU_BANC_CORRIGE>>" not in texte
    debut, fin = texte.find("<!-- empreintes-du-code : début -->"), texte.find("<!-- empreintes-du-code : fin -->")
    assert texte.count("<!-- empreintes-du-code : début -->") == 1 and 0 <= debut < fin
    gelees = re.findall(r"^([0-9a-f]{64})  (\S+)$", texte[debut:fin], re.M)
    attendus = ("demonstrations/banc_tricheurs_v7.py", "demonstrations/banc_tricheurs_v8.py", "demonstrations/banc_tricheurs_v9.py",
                "pole/__init__.py", "pole/caviardage.py", "pole/controles_pari.py", "pole/cycle.py", "pole/fiche.py",
                "pole/memoire.py", "pole/nul_filles_v2.py", "pole/nul_v8.py", "pole/nul_v9.py", "pole/outils.py",
                "pole/selection_pari.py")
    assert [p for _, p in gelees] == list(attendus), [p for _, p in gelees]
    for h, p in gelees:
        with open(os.path.join(RACINE, p), "rb") as f:
            assert hashlib.sha256(f.read()).hexdigest() == h, p
    return texte


texte = verifier()
with open(SORTIE_JSON, "w", encoding="utf-8") as f:
    json.dump(COUPLES, f, ensure_ascii=False, indent=1)
    f.write("\n")
with open(SORTIE_TEXTE, "w", encoding="utf-8") as f:
    f.write(texte)
print(f"{len(COUPLES)} couples ; chaque « ancien » unique dans le brouillon 2 et au moment de son application ; bloc : 14 "
      f"empreintes conformes ; texte appliqué : {len(texte.splitlines())} lignes")
