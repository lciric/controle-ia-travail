"""Contre-lecture R2 du préenregistrement de validation du nul v9 : sondes indépendantes de la domination et de la précision.

1. Domination sur des mondes neufs (graines disjointes de celles des essais) : fiches sans parent (2 lois connues) et filles
   (4 lois connues : A, B, S1, S2), deux ou trois sous-populations, seuils au milieu, aux bords et hors de l'étendue observée,
   poids aux sommets (une loi connue par morceau, bruit nul), bruit commun ; instants petits compris (5, 10) — morceaux vides
   ou réduits à une instance. Critère : valeur du membre ≥ log-vraisemblance du monde − 10⁻⁹ à chaque instant.
2. Référence indépendante (scipy SLSQP, plusieurs départs) sur des tirages neufs, t = 12 à 20, deux et quatre lois connues :
   valeur ≥ référence − 10⁻⁷ (certificat) et ≤ référence + 10⁻² (précision).
3. Égalités de z : traits arrondis à 0,1 (nombreuses égalités), seuil égal à une valeur observée.
Lecture seule du dépôt.

  nice -n 10 python3 -I -B sonde_domination_v1.py /chemin/vers/orchestrator
"""

import math
import os
import random
import sys

import numpy as np

RACINE = os.path.abspath(sys.argv[1])
sys.path.insert(0, RACINE)
from pole import nul_v9  # noqa: E402
from pole import selection_pari as sp  # noqa: E402

K, DIM = 3, 2


def lois(rng):
    return {n: sp.loi_softmax_aleatoire(rng, K, DIM) for n in ("A", "B", "S1", "S2", "N")}


def par_sp(lois_g):
    return {"type": "par_sous_population", "lois": {str(g): l for g, l in enumerate(lois_g)}}


def si_seuil(j, s, si, sinon):
    return {"type": "si_sinon", "condition": {"indice": j, "seuil": s}, "si": si, "sinon": sinon}


def melange(composantes, poids):
    return {"type": "melange", "composantes": list(composantes), "poids": list(poids)}


def donnees(monde, n, rng, nb_sp=2, arrondi=None):
    instances = sp.tirer_instances(rng, n, DIM, nb_sp)
    if arrondi is not None:
        for x in instances:
            x["z"] = [round(v, arrondi) for v in x["z"]]
    issues = [sp.tirer_categorie(rng, sp.proba(monde, x, [], 0)) for x in instances]
    return instances, issues


def sonde_domination():
    instants = [5, 10, 25, 50, 100, 200]
    pire, echecs, total, cas = -math.inf, 0, 0, {}
    for r in range(48):
        rng = random.Random(910000 + r)
        L = lois(rng)
        fille = r % 2 == 1
        connues = [L["A"], L["B"], L["S1"], L["S2"]] if fille else [L["S1"], L["S2"]]
        q = {"type": "fixe", "probas": [rng.random() + 1e-3 for _ in range(K)]}
        eps = rng.choice([0.0, rng.uniform(0.01, 0.6)])
        nb_sp = 3 if r % 6 in (2, 3) else 2
        j = rng.randrange(DIM)
        s = rng.choice([rng.uniform(-1.0, 1.0), rng.uniform(1.8, 3.5), rng.uniform(-3.5, -1.8), 9.0, -9.0])
        genre = r % 4
        if genre == 0:  # une loi connue par sous-population (sommet), bruit commun éventuel
            base = par_sp([rng.choice(connues) for _ in range(nb_sp)])
            nom = "morceaux:sous_population"
        elif genre == 1:  # si/sinon sur un seuil, une loi connue de chaque côté
            base = si_seuil(j, s, rng.choice(connues), rng.choice(connues))
            nom = f"morceaux:seuil:z{j}"
        elif genre == 2:  # mélanges propres à chaque sous-population
            base = par_sp([melange(connues, list(np.random.default_rng(r * 7 + g).dirichlet(np.ones(len(connues)))))
                           for g in range(nb_sp)])
            nom = "morceaux:sous_population"
        else:  # mélanges propres à chaque côté d'un seuil
            base = si_seuil(j, s, melange(connues, list(np.random.default_rng(r).dirichlet(np.ones(len(connues))))),
                            melange(connues[:2], [0.5, 0.5]))
            nom = f"morceaux:seuil:z{j}"
        monde = base if eps == 0.0 else melange([base, q], [1.0 - eps, eps])
        instances, issues = donnees(monde, 200, rng, nb_sp)
        d = nul_v9.detail_morceaux_groupe(nul_v9.membres_morceaux(connues, DIM), sp.Cache(issues, instances), issues, instants)
        lv = nul_v9.log_vraisemblance(monde, issues, instances)
        for t in instants:
            total += 1
            ecart = lv[t - 1] - d[nom][t]["valeur"]
            pire = max(pire, ecart)
            if ecart > 1e-9:
                echecs += 1
                print(f"  ÉCHEC monde {r} ({nom}, fille {fille}, {nb_sp} sous-populations, s {s:.3g}, eps {eps:.3g}) t {t} : "
                      f"valeur {d[nom][t]['valeur']:.6f} < vraisemblance {lv[t - 1]:.6f}")
            cas[nom.split(":")[1]] = cas.get(nom.split(":")[1], 0) + 1
    print(f"domination : {total} instants sur 48 mondes neufs, {echecs} échec(s), pire (vraisemblance − valeur) {pire:.3g} ; "
          f"par type {cas}")


def maximum_scipy(Lm, Y, pieces, J):
    from scipy.optimize import minimize
    P = len(pieces)

    def f(x):
        tot = 0.0
        for p, idx in enumerate(pieces):
            if len(idx):
                m = Lm[idx] @ x[p * J:(p + 1) * J] + Y[idx] @ x[P * J:]
                tot += np.log(np.maximum(m, 1e-300)).sum()
        return -tot
    cons = [{"type": "eq", "fun": (lambda x, p=p: x[p * J:(p + 1) * J].sum() + x[P * J:].sum() - 1.0)} for p in range(P)]
    meilleur = -np.inf
    for depart in range(6):
        rs = np.random.default_rng(1000 + depart)
        x0 = np.concatenate([rs.dirichlet(np.ones(J)) * 0.5 for _ in range(P)] + [rs.dirichlet(np.ones(K)) * 0.5])
        res = minimize(f, x0, method="SLSQP", bounds=[(0, 1)] * (P * J + K), constraints=cons,
                       options={"ftol": 1e-13, "maxiter": 800})
        if res.success:
            meilleur = max(meilleur, -res.fun)
    return meilleur


def sonde_reference():
    pire_bas, pire_haut, n = -math.inf, -math.inf, 0
    for r in range(8):
        rng = random.Random(920000 + r)
        L = lois(rng)
        connues = [L["A"], L["B"], L["S1"], L["S2"]] if r % 2 else [L["S1"], L["S2"]]
        J = len(connues)
        t = 12 + r
        instances, issues = donnees(L["N"], t, rng)
        d = nul_v9.detail_morceaux_groupe(nul_v9.membres_morceaux(connues, DIM), sp.Cache(issues, instances), issues, [t])
        Lm = np.array([[sp.proba(l, x, [], 0)[y] for l in connues] for x, y in zip(instances, issues)])
        Y = np.eye(K)[issues]
        g = np.array([x["g"] for x in instances])
        refs = {"morceaux:sous_population": maximum_scipy(Lm, Y, [np.flatnonzero(g == v) for v in sorted(set(g))], J)}
        for jj in range(DIM):
            z = np.array([x["z"][jj] for x in instances])
            refs[f"morceaux:seuil:z{jj}"] = max(maximum_scipy(Lm, Y, [np.flatnonzero(z <= s), np.flatnonzero(z > s)], J)
                                               for s in [-np.inf] + sorted(set(z)))
        for nom, ref in refs.items():
            v = d[nom][t]["valeur"]
            n += 1
            pire_bas = max(pire_bas, ref - v)
            pire_haut = max(pire_haut, v - ref)
            if v < ref - 1e-7 or v > ref + 1e-2:
                print(f"  ÉCART tirage {r} (J = {J}, t = {t}) {nom} : valeur {v:.6f}, référence {ref:.6f}")
    print(f"référence scipy : {n} comparaisons ; pire (référence − valeur) {pire_bas:.3g} (doit être ≤ 1e-7) ; "
          f"pire (valeur − référence) {pire_haut:.3g} (précision, ≤ 1e-2 attendu)")


def sonde_egalites():
    echecs, total = 0, 0
    for r in range(12):
        rng = random.Random(930000 + r)
        L = lois(rng)
        connues = [L["S1"], L["S2"]]
        j = r % DIM
        instances = sp.tirer_instances(rng, 200, DIM)
        for x in instances:
            x["z"] = [round(v, 1) for v in x["z"]]
        s = instances[rng.randrange(200)]["z"][j]  # seuil égal à une valeur observée, très souvent répétée
        monde = si_seuil(j, s, L["S1"], L["S2"])
        issues = [sp.tirer_categorie(rng, sp.proba(monde, x, [], 0)) for x in instances]
        d = nul_v9.detail_morceaux_groupe(nul_v9.membres_morceaux(connues, DIM), sp.Cache(issues, instances), issues,
                                          [10, 50, 200])
        lv = nul_v9.log_vraisemblance(monde, issues, instances)
        for t in (10, 50, 200):
            total += 1
            echecs += d[f"morceaux:seuil:z{j}"][t]["valeur"] < lv[t - 1] - 1e-9
            if t == 200:
                nb = d[f"morceaux:seuil:z{j}"][t]["coupes"]
                distinctes = len({x["z"][j] for x in instances})
                assert nb == distinctes + 1, (nb, distinctes)
    print(f"égalités de z (traits arrondis à 0,1, seuil égal à une valeur observée) : {total} instants, {echecs} échec(s) ; "
          f"nombre de coupes = valeurs distinctes + 1 vérifié")


if __name__ == "__main__":
    sonde_domination()
    sonde_egalites()
    sonde_reference()
