import pathlib
p = pathlib.Path('/home/claude/controle-ia-travail/registres/go.md')
s = p.read_text(encoding='utf-8')
assert 'GO-2026-11-02-32' not in s
src = ("mots de Lazar dans la session conv-audit, 2 novembre 2026 : 17:30 UTC « on doit corriger ça […] go dépenses » (juges modèles de langage au plafond) ; 18:27 UTC « prends des budgets et plafonds très larges » ; 18:26 UTC « je ne veux pas de blocage, de résultats non concluants par défaut de conception, de plafond ou que sais-je » ; 18:53 UTC « je suis tes recos »")
ligne = (f"| GO-2026-11-02-32 | 2026-11-02 | calcul | **Juges modèles de langage de l'idéation, version 2 : course de validation, juges et taille précisés** (même objet que la ligne de 60 USD inscrite plus tôt pour cette course, qui n'est pas utilisée) : juges **Argon (commande externe, relais 8805) et Astra (commande 8807)** — Kimi exclu par le concepteur (trop cher et trop lent pour des comparaisons par paires ; 5 appels réussis sur 621 à A1) ; **15 bons et 15 mauvais témoins plantés par classe** (trois mondes simulés ; puissance ≥ 0,9 à une aire de 0,8, contre 0,73 à 10 contre 10) ; bras « ancien protocole sans dossier » ajouté ; garde de durée 48 h (boucle folle seulement) ; parts 24 USD Argon et 36 USD Astra ; texte `preenregistrement-juges-idees-v2-v<N>.md` contre-lu (règle R2), scellé, committé et poussé avant la course ; course chez session-depot ; sortie scellée avant lecture ; verdict par lecteur neuf ; attendu ≈ 30 à 43 USD ; **le plafond du texte scellé doit être exactement 60 USD** | 60 USD | 2026-11-16 | Lazar | {src} |")
i = s.index('| GO-2026-11-02-31 |')
j = s.index('\n', i)
s = s[:j+1] + ligne + '\n' + s[j+1:]
p.write_text(s, encoding='utf-8')
print('ok')
