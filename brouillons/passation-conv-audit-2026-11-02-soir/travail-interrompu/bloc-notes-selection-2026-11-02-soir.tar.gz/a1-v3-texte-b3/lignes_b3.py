"""Lignes (début-fin) des fonctions, classes et méthodes du cœur et du lanceur v3 au commit e58cfec (contenu tiré par git show,
analysé par ast ; rien n'est exécuté). Lecture seule."""
import ast
import subprocess

DEPOT = "/home/claude/ideation-organism"
COMMIT = "e58cfec936461a72a173c667e91755582e04bcb8"
for chemin in ("pole/attaque_goodhart_v3.py", "demonstrations/attaque_goodhart_v3.py"):
    src = subprocess.run(["git", "-C", DEPOT, "show", f"{COMMIT}:orchestrator/{chemin}"], capture_output=True, check=True, text=True).stdout
    print(f"== {chemin} ({len(src.splitlines())} lignes)")
    arbre = ast.parse(src)
    for n in arbre.body:
        if isinstance(n, (ast.FunctionDef, ast.ClassDef)):
            print(f"{n.lineno}-{n.end_lineno} {type(n).__name__} {n.name}")
            if isinstance(n, ast.ClassDef):
                for m in n.body:
                    if isinstance(m, ast.FunctionDef):
                        print(f"   {m.lineno}-{m.end_lineno} {n.name}.{m.name}")
        elif isinstance(n, ast.Assign):
            noms = [t.id for t in n.targets if isinstance(t, ast.Name)]
            if noms:
                print(f"{n.lineno}-{n.end_lineno} = {', '.join(noms)}")
