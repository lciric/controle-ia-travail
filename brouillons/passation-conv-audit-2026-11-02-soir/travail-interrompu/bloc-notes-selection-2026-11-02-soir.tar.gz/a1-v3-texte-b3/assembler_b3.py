"""Assemble le brouillon 3 : cinq parties de gabarit + parties engendrées (bloc d'empreintes, table des mutations, essais v2) +
heures et résultats + empreintes des fichiers du rédacteur. Écrit dans le bloc-notes seulement :
python3 -I -B assembler_b3.py FIN HEURE_VERIF FIN_L13"""
import hashlib
import os
import sys
import textwrap

ICI = os.path.dirname(os.path.abspath(__file__))
fin, heure_verif, fin_l13 = sys.argv[1], sys.argv[2], sys.argv[3]
lire = lambda n: open(os.path.join(ICI, n), encoding="utf-8").read()  # noqa: E731
parties = [f"gabarit-b3-partie{i}.md" for i in range(1, 6)]
g = "".join(lire(n) for n in parties)
fichiers = ["lignes_b3.py", "lignes-b3.txt", "empreintes_b3.py", "empreintes-b3.txt", "bloc-empreintes-b3.txt", "noms_b3.py", "noms-b3.txt",
            "mutations-b3.json", "mutations-b3.md", "essais-b3.json", "essais-v2-b3.md", "devis_b3.py", "devis-b3.txt", "essais-rejoues-b3.txt",
            "banc-rejoue-b3.txt"] + parties + ["assembler_b3.py", "verif_b3.py"]
lignes = [f"- `{n}` `{hashlib.sha256(open(os.path.join(ICI, n), 'rb').read()).hexdigest()}`" for n in fichiers]
emp = ("`sha256sum` à l'assemblage (" + fin + " UTC) ; la sortie de `verif_b3.py` (`verif-b3.txt`) et son relevé des renvois\n"
       "(`renvois-b3.txt`) dépendent de ce texte : leurs empreintes sont données avec la remise.\n" + "\n".join(lignes))
rempl = {
    "{{BLOC_EMPREINTES}}": lire("bloc-empreintes-b3.txt"),
    "{{TABLE_MUTATIONS}}": lire("mutations-b3.md").rstrip("\n"),
    "{{ESSAIS_V2}}": lire("essais-v2-b3.md").rstrip("\n"),
    "{{FIN}}": fin, "{{HEURE_VERIF}}": heure_verif, "{{FIN_L13}}": fin_l13, "{{FIN_BANC}}": "19:26",
    "{{ESSAIS_REJOUES}}": textwrap.fill("19:13 à 19:26 UTC, `essais/test_attaque_goodhart_v3.py` 68 réussis, 98 sous-essais, 0 échec ; "
                                        "`essais/test_attaque_goodhart_v2.py` 45 réussis, 54 sous-essais, 0 échec ; banc 40 mutations, 40 tuées "
                                        "pour la raison attendue, témoin 29 essais sans échec avant et après", width=128),
    "{{ESSAIS_REJOUES_DETAIL}}": ("essais v3 : 68 réussis, 98 sous-essais, 0 échec (152 s, 19:13:37 à 19:16:10) ; essais v2 : 45 réussis, 54 "
                                  "sous-essais, 0 échec (100 s, jusqu'à 19:17:51) ; banc : 40 mutations, 40 tuées pour la raison attendue, 0 pour "
                                  "une autre raison, 0 défaut du banc, 0 survivante, 0 non appliquée, témoin 29 essais sans échec avant et après, "
                                  "code 0 (19:22:48 à 19:26:40 ; un premier passage, 19:17:51 à 19:20:54, donnait déjà 40 sur 40, sortie "
                                  "tronquée) ; joués dans l'arbre extrait, hors du dépôt, qui n'en garde ni `__pycache__` ni `_tmp` ; "
                                  "sorties `essais-rejoues-b3.txt` et `banc-rejoue-b3.txt`"),
    "{{RESULTAT_VERIF}}": ("résultats (`verif-b3.txt`, empreinte donnée avec la remise) : bloc accepté et devis égal à la section 12 ; GO simulé "
                           "accepté à 400 USD, artefacts refusés ; copie renommée acceptée par `lire_preenregistrement`, artefacts refusés ; "
                           "aucun jeton ; noms, numéros de mutation et renvois conformes ; contrôles faits deux fois, avec le code du dépôt et "
                           "avec l'arbre extrait du commit"),
    "{{EMPREINTES_REDACTEUR}}": emp,
}
for k, v in rempl.items():
    assert g.count(k) >= 1, k
    g = g.replace(k, v)
assert "{{" not in g and "}}" not in g, "gabarit non rempli"
sortie = os.path.join(ICI, "preenregistrement-attaque-goodhart-v3-brouillon3.md")
with open(sortie, "w", encoding="utf-8") as f:
    f.write(g)
print("assemblé :", len(g.splitlines()), "lignes ; sha256", hashlib.sha256(g.encode("utf-8")).hexdigest())
