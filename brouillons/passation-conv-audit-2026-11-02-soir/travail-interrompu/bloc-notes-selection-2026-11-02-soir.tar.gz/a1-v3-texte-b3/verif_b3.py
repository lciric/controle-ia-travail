"""Vérifications du brouillon 3 (lecture seule ; aucun .sha256 écrit dans le dépôt ; dossiers temporaires dans le bloc-notes,
supprimés à la fin). Usage : python3 -I -B verif_b3.py CHEMIN_DU_BROUILLON RACINE_ORCHESTRATOR [RACINE_ORCHESTRATOR …]
(par exemple le dépôt, puis l'arbre extrait du commit).
- texte : aucun jeton de marqueur (motif du lanceur), aucun commentaire « MARQUEUR », aucun reste de gabarit ; marqueurs de blocs
  une fois chacun ; un seul identifiant de GO, GO-2026-11-02-21 ;
- bloc plan-gele lu par `lire_plan` du lanceur de la racine donnée : accepté, valeurs, devis ; chiffres du devis présents en
  section 12 ;
- GO simulé : `verifier_go` du lanceur sur un registre factice (ligne reconstituée au format du registre), cas sain et artefacts ;
- `lire_preenregistrement` sur une copie nommée preenregistrement-attaque-goodhart-v3-v1.md avec un compagnon .sha256 factice,
  dans un dossier temporaire hors du dépôt (DOSSIER_PREREG remplacé en mémoire ; contrôle du scellement réel) : acceptée ;
  artefacts : sans compagnon, nom du brouillon, jeton injecté ;
- bloc empreintes-du-code = calcul (bloc-empreintes-b3.txt) = FICHIERS_GELES ;
- noms : essais v3 cités (tous les 68), essais v2 (45), table des 40 mutations (libellé, fonction, essai), numéros de mutation
  cités par les gardes et dans le texte cohérents avec l'essai qui les tue ;
- renvois fichier:ligne dans les bornes des fichiers, et relevé des renvois (fichier présumé, première ligne de code) pour relecture."""
import ast
import datetime
import hashlib
import importlib.util
import os
import re
import shutil
import sys
import tempfile

ICI = os.path.dirname(os.path.abspath(__file__))
chemin, racines = sys.argv[1], sys.argv[2:]
texte = open(chemin, encoding="utf-8").read()
ok = True


def dire(nom, cond, detail=""):
    global ok
    ok = ok and bool(cond)
    print(("OUI " if cond else "NON ") + nom + (f" — {detail}" if detail else ""), flush=True)


print("texte :", chemin, "; sha256", hashlib.sha256(texte.encode("utf-8")).hexdigest(), ";", len(texte.splitlines()), "lignes")
GO = "GO-2026-11-02-21"


def charger(racine):
    sys.path.insert(0, racine)
    for nom in [m for m in sys.modules if m == "pole" or m.startswith("pole.")]:
        del sys.modules[nom]
    spec = importlib.util.spec_from_file_location(f"l3_{len(sys.path)}", os.path.join(racine, "demonstrations", "attaque_goodhart_v3.py"))
    l3 = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(l3)
    sys.path.remove(racine)
    return l3


for racine in racines:
    print(f"=== racine du code : {racine}")
    l3 = charger(racine)
    from pole import configuration_v56 as cfg  # noqa: E402  (de la racine chargée)
    from pole.outils import ecrire_scelle  # noqa: E402
    # --- texte
    dire("aucun jeton de marqueur (motif du lanceur)", l3.MARQUEUR.findall(texte) == [], str(l3.MARQUEUR.findall(texte)))
    dire("aucun commentaire MARQUEUR", "<!-- MARQUEUR" not in texte)
    dire("aucun reste de gabarit", "{{" not in texte and "}}" not in texte)
    for m in (l3.DEBUT_PLAN, l3.FIN_PLAN, l3.DEBUT_EMPREINTES, l3.FIN_EMPREINTES):
        dire(f"marqueur de bloc une fois : {m}", texte.count(m) == 1)
    gos = sorted(set(re.findall(r"GO-\d{4}-\d{2}-\d{2}-\d{2}", texte)))
    dire("un seul identifiant de GO dans le texte : " + GO, gos == [GO], str(gos))
    dire("aucun nom de jeton ancien", all(x not in texte for x in ("RELAIS_ARGON_A_CONFIRMER", "GO_A_PORTER", "EMPREINTES_A_RECALCULER")))
    # --- bloc plan-gele
    p = l3.lire_plan(texte, "course")
    f = p["fournisseurs"][0]
    d = p["devis"]["total"]
    dire("bloc plan-gele accepté par lire_plan (course)", True,
         f"cartes {p['cartes']}, unités {p['unites_par_case']}, ε {p['eps']}, mondes {p['mondes']}, {f['nom']} {f['modele']} port {f['port']} "
         f"fils {f['fils']} taux {f['taux_usd']} secondes {f['secondes']}, relais_perdu_h {p['relais_perdu_h']!r} → relais_perdu_s "
         f"{p['relais_perdu_s']}, plafond {p['plafond_usd']}, durée {p['duree_max_s'] / 3600} h, go {p['go']}, configuration "
         f"{p['configuration_sha256'][:12]}…, essais_avant_repli {p['essais_avant_repli']}")
    dire("valeurs du bloc", (p["cartes"], p["unites_par_case"], p["eps"], p["mondes"], len(p["fournisseurs"]), f["nom"], f["port"], f["modele"],
                             f["fils"], f["taux_usd"], f["secondes"], p["relais_perdu_h"], p["relais_perdu_s"], p["plafond_usd"],
                             p["duree_max_s"], p["go"], p["configuration_sha256"])
         == (24, 24, 0.25, ["W1", "W2"], 1, "argon", 8805, "gemini-4-argon", 1, 0.062, (8.0, 40.0), "aucun", None, 400.0, 72 * 3600.0, GO,
             "e5306c47e1b21a5e55b599411dba92c97e88aa98bb6d6fa91fc5d358a2bdde30"))
    attendu = {"appels_attendus": [1152, 2112], "appels_max": 3072, "usd_attendus": [71.42, 130.94], "usd_max": 190.46,
               "duree_appels_h_parallele": [2.56, 23.47], "duree_appels_max_h_parallele": 34.13, "evaluations_v8_rejeux": 212256,
               "rejeux_h": 1.65, "duree_attendue_haute_h": 25.12, "duree_max_h": 35.78}
    dire("devis du bloc = section 12", d == attendu, str(d))
    s12 = texte[texte.index("## 12. Devis"):texte.index("## 13. Avant la course")]
    for chaine in ("1 152 à 2 112", "3 072", "71,42 à 130,94", "190,46", "2,56 à 23,47", "34,13", "1,65 h", "25,12 h", "35,78 h", "212 256",
                   "`plafond_usd: 400`", "`duree_max_h: 72`"):
        dire(f"section 12 porte « {chaine} »", chaine in s12)
    # --- GO simulé (registre factice hors du dépôt)
    tmp = tempfile.mkdtemp(dir=ICI, prefix="simulation-go-")
    try:
        def registre(*lignes):
            r = os.path.join(tmp, f"go-{len(os.listdir(tmp))}.md")
            with open(r, "w", encoding="utf-8") as fh:
                fh.write("# Registre des GO (simulation du rédacteur, factice)\n\n| id | accordé le | type | périmètre | plafond | échéance | "
                         "accordé par | référence |\n|---|---|---|---|---|---|---|---|\n" + "".join(lignes))
            return r

        def ligne(ident=GO, plafond="400 USD", typ="calcul", perimetre="A1-v3, Argon seul (ligne factice de simulation)", echeance="2026-11-16"):
            return f"| {ident} | 2026-11-02 | {typ} | {perimetre} | {plafond} | {echeance} | Lazar | simulation du rédacteur |\n"
        g = l3.verifier_go(registre(ligne()), GO, p, cfg)
        dire("GO simulé : ligne factice « 400 USD » acceptée par verifier_go (plafond du bloc)", g["plafond_lu_usd"] == 400.0 and g["identifiant"] == GO,
             f"{g['plafond_lu_usd']} USD, échéance {g['echeance']}")
        g2 = l3.verifier_go(registre(ligne(), ligne("GO-2026-11-02-25", "0 USD", "décision", f"note sur {GO}", "—")), GO, p, cfg)
        dire("GO simulé : une ligne de décision qui nomme le GO ne le révoque pas", g2["identifiant"] == GO)
        artefacts = [("399 USD", registre(ligne(plafond="399 USD")), GO), ("401 USD", registre(ligne(plafond="401 USD")), GO),
                     ("ligne de révocation qui nomme le GO", registre(ligne(), ligne("GO-2026-11-02-26", "0 USD", "révocation", f"révoque {GO}", "—")), GO),
                     ("autre GO en ligne de commande", registre(ligne()), "GO-2026-11-02-22"),
                     ("GO absent du registre", registre(ligne("GO-2026-11-02-27")), GO)]
        for nom, reg, ident in artefacts:
            try:
                l3.verifier_go(reg, ident, p, cfg)
                dire(f"GO simulé, artefact refusé : {nom}", False)
            except l3.ag.AttaqueRefusee as e:
                dire(f"GO simulé, artefact refusé : {nom}", True, str(e)[:110])
        try:
            cfg.verifier_go_v56(GO, registre(ligne()), 400.0, aujourd_hui=datetime.date(2026, 11, 17))
            dire("GO simulé, artefact refusé : lancement après l'échéance (17 novembre)", False)
        except cfg.GoRefuse as e:
            dire("GO simulé, artefact refusé : lancement après l'échéance (17 novembre)", True, str(e)[:110])
    finally:
        shutil.rmtree(tmp)
    # --- lire_preenregistrement sur une copie renommée, compagnon factice, dossier temporaire hors du dépôt
    tmp = tempfile.mkdtemp(dir=ICI, prefix="simulation-scellement-")
    garde = l3.DOSSIER_PREREG
    try:
        l3.DOSSIER_PREREG = tmp
        copie = os.path.join(tmp, "preenregistrement-attaque-goodhart-v3-v1.md")
        h = ecrire_scelle(copie, texte)  # copie et compagnon .sha256 factice, dans le dossier temporaire seulement
        e_, h_, gelees, plan = l3.lire_preenregistrement(copie)
        dire("lire_preenregistrement : copie renommée -v1, compagnon factice, acceptée",
             e_ >= 2 ** 64 and h_ == h and len(gelees) == 73 and plan["go"] == GO and plan["plafond_usd"] == 400.0 and plan["relais_perdu_s"] is None,
             f"entropie {e_.bit_length()} bits (≥ 2^64), empreinte {h_[:16]}…, {len(gelees)} empreintes vérifiées, go {plan['go']}, fils "
             f"{plan['fournisseurs'][0]['fils']}, plafond {plan['plafond_usd']}, durée {plan['duree_max_s'] / 3600} h, relais_perdu_s {plan['relais_perdu_s']}")
        os.remove(copie + ".sha256")
        try:
            l3.lire_preenregistrement(copie)
            dire("lire_preenregistrement : la même copie sans compagnon refusée", False)
        except l3.PreenregistrementRefuse as e:
            dire("lire_preenregistrement : la même copie sans compagnon refusée", "non scellé" in str(e), str(e)[:90])
        brouillon = os.path.join(tmp, os.path.basename(chemin))
        ecrire_scelle(brouillon, texte)
        try:
            l3.lire_preenregistrement(brouillon)
            dire("lire_preenregistrement : le texte sous son nom de brouillon refusé", False)
        except l3.PreenregistrementRefuse as e:
            dire("lire_preenregistrement : le texte sous son nom de brouillon refusé", "pas" in str(e), str(e)[:90])
        jeton = os.path.join(tmp, "preenregistrement-attaque-goodhart-v3-v2.md")
        ecrire_scelle(jeton, texte + "\nJeton : " + "<<" + "ESSAI_DE_JETON" + ">>\n")
        try:
            l3.lire_preenregistrement(jeton)
            dire("lire_preenregistrement : la même copie avec un jeton injecté refusée", False)
        except l3.PreenregistrementRefuse as e:
            dire("lire_preenregistrement : la même copie avec un jeton injecté refusée", "marqueur" in str(e), str(e)[:90])
    finally:
        l3.DOSSIER_PREREG = garde
        shutil.rmtree(tmp)
    # --- bloc d'empreintes
    lignes_bloc = re.findall(r"^([0-9a-f]{64})  (\S+)$", l3.l2._bloc(texte, l3.DEBUT_EMPREINTES, l3.FIN_EMPREINTES, "e"), re.M)
    calcul = open(os.path.join(ICI, "bloc-empreintes-b3.txt"), encoding="utf-8").read()
    dire("bloc d'empreintes = calcul (73 lignes)", "".join(f"{h}  {r}\n" for h, r in lignes_bloc) == calcul and len(lignes_bloc) == 73)
    dire("73 chemins = FICHIERS_GELES", sorted(r for _, r in lignes_bloc) == sorted(l3.FICHIERS_GELES))

# --- noms (fichiers du commit, analyse syntaxique : dépôt = commit pour ces fichiers)
ORCH = racines[0]


def classes(fichier):
    a = ast.parse(open(fichier, encoding="utf-8").read())
    return {n.name: {x.name for x in n.body if isinstance(x, ast.FunctionDef)} for n in a.body if isinstance(n, ast.ClassDef)}


v3 = classes(ORCH + "/essais/test_attaque_goodhart_v3.py")
v2 = classes(ORCH + "/essais/test_attaque_goodhart_v2.py")
tous = {(c, m) for c, ms in v3.items() for m in ms if m.startswith("test_")}
refs = set(re.findall(r"`([A-Z][A-Za-z]+)\.(test_[A-Za-z0-9_]+)`", texte))
manquants = sorted(f"{c}.{m}" for c, m in refs if m not in v3.get(c, set()))
dire(f"noms « Classe.test_… » du texte présents dans les essais v3 ({len(refs)} distincts)", not manquants, str(manquants))
dire(f"tous les essais v3 cités ({len(refs & tous)} sur {len(tous)})", len(tous) == 68 and tous <= refs, str(sorted(tous - refs)))
debut, fin = texte.index("Noms exacts, par"), texte.index("**Gardes du code v3")
manq2, n2 = [], 0
for c, reste in re.findall(r"^- `([A-Za-z]+)` : (.+)$", texte[debut:fin], re.M):
    for m in re.findall(r"`(test_[A-Za-z0-9_]+)`", reste):
        n2 += 1
        if m not in v2.get(c, set()):
            manq2.append(f"{c}.{m}")
dire(f"liste des essais v2 ({n2} noms) présente dans les essais v2", not manq2 and n2 == 45 == sum(len([m for m in ms if m.startswith("test_")]) for ms in v2.values()), str(manq2))
src = open(ORCH + "/essais/mutations_attaque_goodhart_v3.py", encoding="utf-8").read()
mut = next(n.value for n in ast.parse(src).body if isinstance(n, ast.Assign) and any(getattr(t, "id", "") == "MUTATIONS" for t in n.targets))
banc = [(e.elts[0].value, e.elts[2].value, [x.right.value for x in e.elts[5].elts]) for e in mut.elts]
rangs = re.findall(r"^\| (\d+) \| (.+?) \| `[^`]+`, `([^`]+)` \| (.+) \|$", texte, re.M)
ecarts = [r for r in rangs if (r[1], r[2], re.findall(r"`([^`]+)`", r[3])) != banc[int(r[0]) - 1]]
dire(f"table des mutations : {len(rangs)} lignes, libellés, fonctions et essais exacts du banc", len(rangs) == 40 == len(banc) and not ecarts, str(ecarts[:2]))
tueur = {k + 1: set(b[2]) for k, b in enumerate(banc)}
s8 = texte[texte.index("**Gardes du code v3"):texte.index("**Banc de mutations**")]
cites, incoherents = set(), []
for ligne_t in [l for l in s8.splitlines() if l.startswith("| ") and not l.startswith("| garde") and not l.startswith("|---")]:
    essais_ligne = {f"{c}.{m}" for c, m in re.findall(r"`([A-Z][A-Za-z]+)\.(test_[A-Za-z0-9_]+)`", ligne_t)}
    for groupe in re.findall(r"\(mutations? ([\d, ]+)\)", ligne_t):
        for n in [int(x) for x in re.findall(r"\d+", groupe)]:
            cites.add(n)
            if not tueur[n] & essais_ligne:
                incoherents.append((n, sorted(tueur[n]), ligne_t[:60]))
dire(f"numéros de mutation des gardes : chacun tué par un essai de sa ligne ({len(cites)} cités)", not incoherents, str(incoherents[:3]))
dire("les 40 mutations citées par au moins une garde", cites == set(range(1, 41)), str(sorted(set(range(1, 41)) - cites)))
prose = re.findall(r"mutation (\d+)(?:, « [^»]+ »)?, tuée par\s+`([A-Za-z]+\.test_[A-Za-z0-9_]+)`", texte)
dire(f"mutations citées dans la prose ({len(prose)}) : essai qui les tue exact", prose and all(e in tueur[int(n)] for n, e in prose), str(prose))
# --- renvois fichier:ligne
longueurs = {p: len(open(os.path.join(ORCH, p), encoding="utf-8").read().splitlines()) for p in
             ("pole/attaque_goodhart_v3.py", "demonstrations/attaque_goodhart_v3.py", "pole/attaque_goodhart_v2.py", "demonstrations/attaque_goodhart_v2.py",
              "pole/adaptateurs.py")}
releve, hors = [], []
courant = None
for m in re.finditer(r"`((?:pole|demonstrations)/[a-z0-9_]+\.py)?:(\d+)(?:-(\d+))?`", texte):
    fichier = m.group(1) or courant
    if m.group(1):
        courant = m.group(1)
    a, b = int(m.group(2)), int(m.group(3) or m.group(2))
    n = longueurs.get(fichier)
    if n is None or not (1 <= a <= b <= n):
        hors.append((fichier, a, b))
    else:
        premiere = open(os.path.join(ORCH, fichier), encoding="utf-8").read().splitlines()[a - 1].strip()[:90]
        releve.append(f"{fichier}:{a}-{b} | {premiere}")
dire(f"renvois fichier:ligne dans les bornes ({len(releve)} renvois)", not hors, str(hors[:5]))
with open(os.path.join(ICI, "renvois-b3.txt"), "w", encoding="utf-8") as fh:
    fh.write("\n".join(releve) + "\n")
print("TOUT CONFORME" if ok else "ÉCARTS : voir NON ci-dessus")
