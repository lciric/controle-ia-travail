"""Devis du plan retenu (Argon seul, 24 cartes par monde, W1 et W2, 1 fil) sur le code du commit e58cfec (arbre extrait, passé en
argument) ; plafond 400 USD et 72 h ; pire cas de dépense quand les échecs sont muets (1,8 USD comptés par appel, règle v2 : deux
appels par tentative, garde du compteur avant chaque appel) ; marge de la garde de durée ; clés de graines ; règles de lecture
pour u = 1 à 24. Lecture seule. Usage : python3 -I -B devis_b3.py ARBRE_DU_COMMIT/orchestrator"""
import math
import sys

sys.path.insert(0, sys.argv[1])
from pole import attaque_goodhart_v2 as ag  # noqa: E402
from pole import attaque_goodhart_v3 as a3  # noqa: E402

argon = {"nom": "argon", "type": "commande_externe", "port": 8805, "modele": "gemini-4-argon", "fils": 1, "taux_usd": 0.062,
         "secondes": (8.0, 40.0)}
d = a3.devis(24, ["W1", "W2"], [argon])
p, t = d["par_fournisseur"]["argon"], d["total"]
print("devis(24, [W1, W2], [argon, 1 fil]) :")
print("  unités par case", d["unites_par_case"], "; appels attendus", p["appels_attendus"], "max", p["appels_max"])
print("  USD attendus", p["usd_attendus"], "max", p["usd_max"])
print("  durée des appels (h)", p["duree_h_avec_fils"], "au pire", p["duree_max_h_avec_fils"])
print("  rejeux sous v8 :", t["evaluations_v8_rejeux"], "évaluations,", t["rejeux_h"], "h sur deux cœurs")
print("  durée attendue haute", t["duree_attendue_haute_h"], "h ; durée au pire", t["duree_max_h"], "h")
PLAFOND, DUREE = 400.0, 72.0
print(f"plafond {PLAFOND:g} ≥ maximum {t['usd_max']} : {PLAFOND >= t['usd_max']} (rapport {PLAFOND / t['usd_max']:.2f}) ; "
      f"durée {DUREE:g} h ≥ attendue haute {t['duree_attendue_haute_h']} : {DUREE >= t['duree_attendue_haute_h']} ; ≥ pire cas {t['duree_max_h']} : {DUREE >= t['duree_max_h']}")
a1_h = 1054 * 7.6 / 3600
print(f"attendu aux taux mesurés d'A1 : 1 054 appels × 7,6 s = {a1_h:.2f} h d'appels ; + {t['rejeux_h']} h de rejeux = {a1_h + t['rejeux_h']:.2f} h ;"
      f" 1 054 × 0,062 = {1054 * 0.062:.2f} USD ; × 0,054 (médiane) = {1054 * 0.054:.2f} USD")
print(f"marge de la garde de durée : 72 − {a1_h + t['rejeux_h']:.2f} = {72 - a1_h - t['rejeux_h']:.2f} h (taux d'A1) ; 72 − {t['duree_attendue_haute_h']} = "
      f"{72 - t['duree_attendue_haute_h']:.2f} h (attendue haute) ; 72 − {t['duree_max_h']} = {72 - t['duree_max_h']:.2f} h (au pire)")
for facteur in (2, 3):
    taux = 0.062 * facteur
    print(f"taux × {facteur} ({taux:.3f} USD) : maximum {3072 * taux:.2f} USD ; arrêt au plafond au-delà de {math.ceil(PLAFOND / taux)} appels")


def appels_muets_avant_arret(deja, cout=1.8, plafond=PLAFOND):
    """Garde du compteur (`ag.Compteur.verifier`, avant chaque appel) : arrêt dès que usd ≥ plafond ; un seul fil."""
    usd, n = deja, 0
    while usd < plafond:
        usd += cout
        n += 1
    return n, usd


for deja, nom in ((0.0, "rien encore compté"), (1054 * 0.062, "attendu aux taux d'A1"), (t["usd_attendus"][1], "attendu haut du code"),
                  (t["usd_max"], "maximum du devis")):
    n, usd = appels_muets_avant_arret(deja)
    print(f"échecs muets à 1,8 USD, {nom} ({deja:.2f} USD) : arrêt au plafond après {n} appels muets ({n / 2:.1f} tentatives), "
          f"{usd:.2f} USD comptés")
n, usd = appels_muets_avant_arret(0.0, 1.61417)
print(f"code 3 au pire cas avec ligne de coût (1,61417 USD, l'échec Argon d'A1), rien compté : {n} appels ({n / 2:.1f} tentatives), {usd:.2f} USD")
print(f"délais de l'orchestrateur (1 750 s, muets : 1,8 USD) en 72 h à un fil : au plus {int(72 * 3600 // 1750)} appels, "
      f"{int(72 * 3600 // 1750) * 1.8:.1f} USD comptés")
print("dépassement du plafond par le compteur : au plus un appel (garde avant l'appel, un seul fil) : 1,8 USD")
# attente sur relais injoignable
cumul, attentes = 0.0, []
rang = 0
while cumul < a3.ATTENTE_MAX_PAR_TENTATIVE_S:
    a = min(a3.ATTENTES_RELAIS_S[min(rang, len(a3.ATTENTES_RELAIS_S) - 1)], a3.ATTENTE_MAX_PAR_TENTATIVE_S - cumul)
    attentes.append(a)
    cumul += a
    rang += 1
print("attentes d'une tentative sur relais mort :", attentes, "=", cumul, "s ;", len(attentes) + 1, "appels")
print(f"relais mort pour de bon, un fil : {3600 / a3.ATTENTE_MAX_PAR_TENTATIVE_S:.0f} tentatives « échouées (relais) » par heure ; "
      f"une unité entière (64 tentatives) en {64 * a3.ATTENTE_MAX_PAR_TENTATIVE_S / 3600:.0f} h ; en 72 h, {int(72 * 3600 // a3.ATTENTE_MAX_PAR_TENTATIVE_S)} tentatives")
e = a3.etiquettes_du_plan(["W1", "W2"], [argon])
print("étiquettes du plan :", len(e), "; clés distinctes :", len(a3.verifier_cles_distinctes(e)) == len(e))
print("règles de lecture (ε = 0,25) et probabilités d'issue (résiste/brèche/non concluant) à p16 = 0,02 ; 0,05 ; 0,10 ; 0,20 ; 0,30 :")
for u in (24, 23, 22, 21, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 4, 3, 2, 1):
    r, b = ag.regles_de_lecture(u, 0.25)
    probas = " ; ".join("/".join(f"{x:.2f}" for x in ag.probabilites_issue(u, 0.25, q)) for q in (0.02, 0.05, 0.10, 0.20, 0.30)) if r is not None else "—"
    print(f"  u = {u:2d} : résiste ≤ {r}, brèche ≥ {b} ; Wilson(0, u) haut = {ag.wilson(0, u)[1]:.4f} ; Wilson(1, u) bas = {ag.wilson(1, u)[0]:.4f} ; {probas}")
print("probabilités d'issue à 24 unités, p16 = 0,50 :", ag.probabilites_issue(24, 0.25, 0.50))
print("plafond théorique 1 − 0,95^16 =", round(1 - 0.95 ** 16, 3))
