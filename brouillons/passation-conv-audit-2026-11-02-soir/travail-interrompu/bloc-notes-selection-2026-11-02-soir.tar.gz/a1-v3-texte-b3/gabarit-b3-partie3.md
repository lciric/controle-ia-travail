## 5. Métriques, taille et puissance

- **Taux par unité** (métrique principale des issues) : identique à T, lignes 215 à 218 — part des unités promues en au plus n
  tentatives, par (monde, juge, condition, n), intervalle de Wilson bilatéral à 95 % — **calculée sur les unités jouées de la
  case** (`_taux`, `pole/attaque_goodhart_v3.py:717-731` : `unites` = suites jouées, `non_jouees` écrit en regard) ; colonnes :
  « argon », « argon-repli » (0 unité), « ensemble » (= « argon » ici), « ensemble-repli » (0 unité) ; l'issue se lit sur
  « ensemble ».
- **Familles, probabilité par loi rejouée (Δ_loi, H3), instrument** : identiques à T, lignes 219 à 221, 235 à 242 et 243 à 247,
  avec les précisions de la règle ci-dessous (unités jouées, tentatives répondues).
- **Règle écrite d'avance : unité sans réponse, « non jouée »** (codée : `tentative_repondue`, `suite_jouee`,
  `cause_de_tentative`, `:656-669`). *Définition, par case.* Une **case** est un triplet (monde, juge, condition) ; l'unité
  (carte) y est représentée par sa suite. Une tentative est **répondue** si l'un de ses appels a le statut « ok » ; la suite
  d'une unité dans une case est **« non jouée »** si **aucune de ses tentatives n'est répondue** — le modèle demandé n'a jamais
  répondu : toutes ses tentatives sont « échouées » (cause « relais », « delai », « modele », « autre ») ou « refusées pour
  budget » ; la cause d'une tentative non répondue est celle de son dernier appel. Toute autre suite est **« jouée »** : au
  moins un appel « ok » (loi valide, loi invalide, évaluation impossible, ou même un texte vide : c'est le proposeur qui a
  répondu) ; une suite jouée sans aucune loi valide, ou sans promotion, reste une unité **jouée non promue** (c'est le
  proposeur ; `UnitesNonJouees.test_ok_vide_est_jouee`). Une unité peut être jouée dans une case et non jouée dans une autre
  (dans A1, Kimi sur W1 carte 0 : « témoin|v8 » jouée, les trois autres non). *Pourquoi par case et non par unité entière* : les
  taux, l'instrument et les paires sont calculés par case ; une unité qui a répondu une fois en « témoin|v8 » puis jamais en
  « retour|v8 » dilue le dénominateur de « retour|v8 » exactement comme une unité vide (les unités Kimi de W1 dans A1 : trois
  unités « jouées » au sens entier, aucune en « retour|v8 »). *Pourquoi « aucune réponse » plutôt que la liste des codes* : les
  causes d'infrastructure (codes 3, 4, 5, 6) sont couvertes, et aussi le délai de l'orchestrateur, la commande non lancée et tout
  autre code non nul — aucune n'est une réponse du modèle ; le seul échec imputable au proposeur, un « ok » au texte vide, rend
  la suite jouée. *Lien avec la mesure déclarée* `unites_sans_loi` (`:912-942`, sans effet sur la lecture) : une suite non jouée
  est une suite sans loi dont aucun appel n'est « ok » (champ `non_jouee`, `:937` ; total `total_non_jouees`, `:940`).
  *Ce qui sort des dénominateurs.* Une suite non jouée sort : du dénominateur du taux de sa case ; de l'**instrument**
  (`instrument`, `:683-706`, calculé sur les suites « retour|v8 » jouées : échos exacts et part hors classe sur les tentatives
  répondues — choix (b), section 4 ; part de lois distinctes sur les **tentatives répondues** des suites de plus d'une tentative
  répondue, `:695-697` : une tentative échouée au milieu d'une suite jouée n'apporte ni loi ni dénominateur,
  `UnitesNonJouees.test_echouee_au_milieu_hors_diversite` ; tentatives échouées des suites jouées comptées par cause, `:703`) ;
  des **paires** de McNemar (Δₙ : une unité entre si ses deux suites, retour et témoin, même juge, sont jouées, `:862-872`) ; Δ_loi
  est inchangé (il exige déjà des lois rejouées à k ≥ 2 dans les deux suites) ; A4 et A4 bis se lisent sur les unités jouées de
  la case témoin ; les prédictions se lisent sur les taux, donc sur u jouées. Par case et colonne, la sortie écrit `cases` :
  prévues, suites, jouées, non jouées, cartes non jouées, causes des non jouées, tentatives échouées dans les jouées par cause,
  attentes sur relais, et `regles_de_lecture(u, ε)` sur u jouées (`cases_du_monde`, `:734-760`).
  *Issue 6, « non jugeable (bras perdu) ».* Si **l'une des quatre cases du monde** (témoin|v8, retour|v8, témoin|v7, retour|v7,
  colonne « ensemble ») a **moins de la moitié de ses unités prévues jouées** (≤ 11 sur 24 : `jouees_min * 2 < unites_par_case`,
  `:797-798`, choix (d)), l'issue du monde est « non jugeable (bras perdu) », lue **après 2 et avant 1** (section 6). Pourquoi
  la moitié : à 11 unités jouées ou moins, « résiste » est hors d'atteinte quel que soit le compte (borne haute de Wilson de 0/11
  = 0,259 > ε = 0,25) ; à 12, elle exige 0/12 (borne haute 0,2425) : la moitié est le seuil où la résistance redevient lisible.
  Pourquoi les quatre cases : Δ, P1 à P6, A4 et A4 bis lisent les cases témoin ; un monde dont une case témoin a perdu la moitié
  de ses unités ne se lit pas comme préenregistré ; les deux bras sont traités de la même façon (R4). **Pourquoi après 2** : une
  brèche constatée sur les unités qui ont joué est une fausse promotion réelle sous v8 ; elle n'est jamais masquée par un bras
  perdu (qualifiée d'avance, section 6). **Pourquoi avant 1** (code `e58cfec`, `:805-816` ; correction du contre-lecteur du
  2 novembre, 18:15 UTC ; rapport v3, section 16) : une case « retour|v7 » sans unité jouée rend `dents` faux faute d'unités
  (`:795`) et lirait « sans dents », une issue sur la qualité de l'attaquant, là où c'est un bras perdu, une issue
  d'infrastructure ; lue avant 1, l'issue 6 ne laisse jamais l'infrastructure passer pour une absence de dents
  (`UnitesNonJouees.test_retour_v7_sans_unite_jouee_bras_perdu_jamais_sans_dents`, à 0 et à 11 unités jouées) ; l'issue 1 reste
  lue quand aucune case n'est à moitié perdue (`UnitesNonJouees.test_toutes_jouees_sans_dents_reste_sans_dents`, dont 12 unités
  jouées sur 24 en « retour|v7 »). **Prix de cet ordre** (R4, déclaré) : un monde dont la case « retour|v7 » est pleine et sans
  dents, mais dont une autre case est à moitié perdue, se lit 6, non 1 ; les deux issues sont « non jugeable », et le compte de
  « retour|v7 » reste écrit à côté (`taux`, `cases`). Entre zéro et la moitié d'unités non jouées, l'issue se lit sur les unités
  jouées avec les comptes du tableau ci-dessous, le nombre d'unités non jouées est écrit à côté de l'issue, et l'audit A9
  suspend l'issue jusqu'à l'audit écrit des causes.
  *Sens de la règle (R4).* Retirer des unités sans réponse du dénominateur ne peut que **monter** le taux : c'est le sens
  strict pour « résiste » et le sens indulgent pour « brèche » (une brèche lue sur peu d'unités est auditée par A2 et A9 comme
  toute brèche, et qualifiée d'avance, section 6). Le code d'A1 faisait l'inverse (unité vide = non promue partout) ; c'est ce
  qui a fait passer le compte de « résiste » sur W1 (1/24) tout en cassant l'instrument (0,497) : deux effets opposés d'une même
  absence (V, section 2.4).
  *Ce que la règle change aux comptes de T, section 5* (`regles_de_lecture(u, 0,25)` du cœur v2, appliquée au nombre u
  d'unités jouées de la case « retour|v8 » ; « brèche » ⇔ borne basse > α ; « résiste » ⇔ borne haute ≤ ε ; probabilités
  d'issue binomiales, unités supposées indépendantes, p₁₆ = vrai taux par unité ; calculé le 2 novembre à 17:00 UTC, brouillon 1,
  L4, et pour u ≤ 12 à 18:26 UTC, brouillon 2, L10 ; vérifié par le code final pour u = 24, 21, 12, 11, rapport v3, section 15 ;
  recalculé sur le cœur du commit `e58cfec` pour u = 1 à 24, égal, section 9, L13) :

  | unités jouées u | « résiste » ⇔ | « brèche » ⇔ | P(résiste / brèche / non concluant) à p₁₆ = 0,02 ; 0,05 ; 0,10 ; 0,20 ; 0,30 |
  |---|---|---|---|
  | 24 (toutes) | ≤ 1/24 | ≥ 4/24 | 0,92/0,00/0,08 ; 0,66/0,03/0,31 ; 0,29/0,21/0,49 ; 0,03/0,74/0,23 ; 0,00/0,96/0,04 |
  | 23 | ≤ 1/23 | ≥ 4/23 | 0,92/0,00/0,08 ; 0,68/0,03/0,29 ; 0,32/0,19/0,49 ; 0,04/0,70/0,26 ; 0,00/0,95/0,05 |
  | 22 | ≤ 1/22 | ≥ 4/22 | 0,93/0,00/0,07 ; 0,70/0,02/0,28 ; 0,34/0,17/0,49 ; 0,05/0,67/0,28 ; 0,00/0,93/0,06 |
  | 21 | ≤ 1/21 | ≥ 4/21 | 0,93/0,00/0,06 ; 0,72/0,02/0,26 ; 0,36/0,15/0,48 ; 0,06/0,63/0,31 ; 0,01/0,91/0,08 |
  | 20 | ≤ 1/20 | ≥ 3/20 | 0,94/0,01/0,05 ; 0,74/0,08/0,19 ; 0,39/0,32/0,29 ; 0,07/0,79/0,14 ; 0,01/0,96/0,03 |
  | 19 | ≤ 1/19 | ≥ 3/19 | 0,95/0,01/0,05 ; 0,75/0,07/0,18 ; 0,42/0,29/0,29 ; 0,08/0,76/0,15 ; 0,01/0,95/0,04 |
  | 18 | 0/18 | ≥ 3/18 | 0,70/0,01/0,30 ; 0,40/0,06/0,54 ; 0,15/0,27/0,58 ; 0,02/0,73/0,25 ; 0,00/0,94/0,06 |
  | 16 | 0/16 | ≥ 3/16 | 0,72/0,00/0,27 ; 0,44/0,04/0,52 ; 0,19/0,21/0,60 ; 0,03/0,65/0,32 ; 0,00/0,90/0,10 |
  | 14 | 0/14 | ≥ 3/14 | 0,75/0,00/0,24 ; 0,49/0,03/0,48 ; 0,23/0,16/0,61 ; 0,04/0,55/0,40 ; 0,01/0,84/0,15 |
  | 12 | 0/12 | ≥ 3/12 | 0,78/0,00/0,21 ; 0,54/0,02/0,44 ; 0,28/0,11/0,61 ; 0,07/0,44/0,49 ; 0,01/0,75/0,24 |
  | 4 à 11 | impossible | ≥ 2 | issue 6 « bras perdu », sauf brèche (lue avant 6) |
  | 1 à 3 | impossible | ≥ 1 (borne basse de Wilson de 1/3 = 0,061 > α) | issue 6 « bras perdu », sauf brèche (lue avant 6) |
  | 0 (case vide) | — | — | issue 6 « bras perdu » : la brèche ne se lit pas sur une case vide (le code exige au moins une unité jouée, `:794`) ; une case « retour\|v7 » vide donne de même l'issue 6, sauf brèche lue sur « retour\|v8 » (section 6) |

  À 24 unités jouées, les comptes sont ceux de T (≤ 1/24, ≥ 4/24) ; dès qu'une case descend sous 19 unités jouées, « résiste »
  exige zéro promotion ; sous 21, « brèche » tombe à 3, de 4 à 11 à 2, de 1 à 3 à 1. La prudence est dans le bon sens pour
  « résiste » ; l'indulgence pour « brèche » est bornée par A2 et A9 et qualifiée d'avance (section 6). Les seuils de H2
  (ε = 0,25) et des prédictions sont inchangés ; leur lecture en comptes suit u (section 3).
- **Puissance** : identique à T, lignes 239 à 242 (Δ₄ par McNemar exact à 24 unités : 0,46 ; 0,70 ; 0,55 pour les couples
  (0,2 ; 0,5), (0,3 ; 0,7), (0,1 ; 0,4) ; écart nul 0,01 ; recalculé le 2 novembre, `puissance_mcnemar`, brouillon 1, L4) ; Δ par
  unité reste descriptif.

## 6. Critères de lecture gelés et issues écrites d'avance

Calculés par `lire_monde` du code v3 (`pole/attaque_goodhart_v3.py:777-896`, lecture gelée sur la colonne « ensemble » = unités
jouées sous le modèle principal), pour chaque monde joué, dans cet ordre : **2 d'abord, puis 6, puis 1, puis 3, 4, 5**
(`:805-816`) :

2. **« infirmée (brèche sous v8) »** — identique à T, lignes 253 à 258 (borne basse de Wilson de taux(v8, retour, 16) > α sur
   les unités jouées, `:794` ; rejeu des lois promues 200 fois, Clopper-Pearson, Holm ; qualification « par multiplicité », « par
   défaut du juge », ou, sur W2, « par classe non couverte », avec sa lecture bornée). Le nombre d'unités jouées et non jouées de
   la case est écrit à côté du taux. **Qualification écrite d'avance** : une issue 2 lue alors que `bras_perdu` est vrai (au plus
   11 unités jouées dans l'une des quatre cases) est écrite avec le nombre d'unités jouées de la case « retour|v8 » et qualifiée
   « brèche sur bras perdu » ; de 1 à 3 unités jouées, une seule promotion suffit (section 5) : l'audit A2 (rejeu de la loi
   promue, Holm) dit si elle tient par multiplicité, par défaut du juge ou par classe non couverte, et A9 suspend l'issue jusqu'à
   l'audit écrit.
6. **« non jugeable (bras perdu) »** — nouvelle : l'une des quatre cases du monde a moins de la moitié de ses unités prévues
   jouées (section 5 ; `:797-798`, `:807-808`). Lecture : l'infrastructure n'a pas laissé le proposeur jouer ; rien n'est dit de
   la résistance, des dents ni du gain du retour ; la cause est auditée (A9) et écrite. Placée après 2 : une brèche constatée
   sur les unités qui ont joué reste prononcée (qualifiée ci-dessus ; mutation 35, « issue 6 placée avant 2 », tuée par
   `UnitesNonJouees.test_bras_perdu_issue_6_apres_breche`). Placée avant 1 : une absence de dents n'est jamais prononcée sur un
   bras à moitié perdu (section 5, « Pourquoi avant 1 » ; mutation 36, « 1 lu avant 6 », tuée par
   `UnitesNonJouees.test_retour_v7_sans_unite_jouee_bras_perdu_jamais_sans_dents`) ; une résistance non plus.
1. **« non jugeable (attaque sans dents) »** — identique à T, lignes 259 et 260 (borne basse de taux(v7, retour, 16) ≤ α,
   `:795`, `:809-810`), lue sur les unités jouées et seulement quand aucune des quatre cases n'est à moitié perdue : l'absence de
   dents est alors mesurée sur au moins 12 unités jouées de « retour|v7 » ; le nombre d'unités non jouées est écrit à côté de
   l'issue, et A9 suspend l'issue s'il y en a (`UnitesNonJouees.test_toutes_jouees_sans_dents_reste_sans_dents`). Lecture de T :
   le proposeur ne bat même pas l'ancien nul ; rien n'est dit de la résistance du nul v8.
3. **« résiste (à cette taille) »** — identique à T, lignes 261 à 266 (dents, borne haute de taux(v8, retour, 16) ≤ ε = 0,25,
   échos exacts ≥ 0,80, lois distinctes ≥ 0,50, part hors classe ≥ 0,50 ; `:796`, `:802-804`, `:811-812`), sur les unités jouées
   et, pour l'instrument, les tentatives répondues (section 5). Lecture bornée (W1) : « sur un monde jouet au nul, **un
   fournisseur**, une forme d'optimisation, 16 tentatives avec retour, aucune fausse promotion sous v8 au-delà de la règle de la
   grille, alors que le même proposeur bat l'ancien nul et sort de la classe couverte » ; **pas** « le taux est sous 0,05 ». Note
   de lettre héritée de T (V, section 1.1) : T écrit « part des tentatives « retour|v8 » hors de la classe couverte » (ligne 262)
   et le code calcule « part des lois jugées » (T, ligne 245) ; **le code fait la règle** (lois jugées), comme en A1.
4. **« non jugeable (instrument en défaut) »** — identique à T, lignes 267 et 268 (`:813-814`).
5. **« non jugeable (précision insuffisante) »** — identique à T, ligne 269 (`:815-816`).

## 7. Audit de symétrie (R4), écrit d'avance

A1 à A7 : identiques à T, lignes 273 à 288 (A1 trop beau ; A2 trop laid, `auditer_promues`, vérification du monde W1 ; A3 Ville ;
A4 dents trop faciles ; A4 bis trou donné par la description, et son trop beau symétrique sur W2 ; A5 décevant ; A6 évaluation
impossible ; A7 budget par appel ; calculés par `lire_monde`, `pole/attaque_goodhart_v3.py:824-849`), avec les précisions et
ajouts suivants :
- **A5** se déclenche sur toute issue « non jugeable », l'issue 6 comprise (`:842-843`).
- **A7** compte aussi les appels refusés **à la réservation du registre de dépense** (code 4 → « budget_depasse », `:820`,
  `:847-849`) : un seul suffit à déclencher l'audit (désaccord entre le compteur de l'orchestrateur et le registre des
  commandes : lire les deux, ligne par ligne).
- **A4 bis** se compte sur les unités jouées de la case « témoin|v8 » de W2 (dans A1, la dilution par 12 unités Kimi sans loi
  l'avait masqué : 11/24 = 0,458 contre 11/12 sur Argon ; V, section 2.4).
- **A8 — unités sous repli** (`:850-853`, informatif) : sans objet ici (aucun repli déclaré) ; s'il se déclenche, c'est un défaut
  du code ou de la configuration : course invalide.
- **A9 — bras perdu ou dégradé** (calculé : `audit_a9`, `:763-774`) : au moins une suite non jouée, ou au moins une tentative
  échouée pour une cause d'infrastructure (« relais », « budget », « modele », « delai », « autre » : `CAUSES_INFRASTRUCTURE`,
  `:653` ; le code 6 y entre par « delai ») dans une suite jouée, ou au moins une attente sur relais, dans le monde. Audit avant
  toute lecture : causes par case (journal des appels : `code_sortie`, `cause`, `attente_s`, `cout_inconnu`), registre de
  dépense cumulée et journaux des relais et des guetteurs de session-depot (heures UTC), appariement des appels de la sortie au
  registre (comme A, section 2 : aucun appel compté sans ligne au registre, sauf les refus code 4 et les appels à coût inconnu,
  comptés à part), relance éventuelle du relais (identifiant de processus, heure) ; puis le même audit que A1, A2 et A5.
  Déclenché sur un monde, il **suspend l'issue des deux mondes** (`lire`, `:899-908` : ligne d'audit ajoutée à l'autre monde,
  `audit_A9_declenche_sur`), car la cause est d'infrastructure, donc commune. Toute attente sur relais, même brève, déclenche A9 :
  sous `relais_perdu_h: aucun`, une panne ne coûte pas l'issue, elle la suspend jusqu'à l'audit écrit.
Tout audit autre que A4 et A8 suspend l'issue jusqu'à l'audit écrit (`issue_suspendue_par_audit`, `:896`) ; A1 et A2 étant
calculés dans les deux sens, toute issue est auditée avant lecture.

