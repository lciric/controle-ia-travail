## 11. Code gelé

`FICHIERS_GELES` du lanceur v3 (`demonstrations/attaque_goodhart_v3.py:98`) = la fermeture des imports du chemin réel v2 (71
fichiers, T, section 11, lignes 357 à 437) **plus** `pole/attaque_goodhart_v3.py` et `demonstrations/attaque_goodhart_v3.py` :
**73 fichiers** (`Fermeture.test_fichiers_geles_egaux_a_la_fermeture`) ; le lanceur refuse (code 2) un fichier absent du bloc, en
trop, ou différent de son empreinte (`:259-271`), et tout préenregistrement autre que
`prereg/preenregistrement-attaque-goodhart-v3-vN.md` (`:245-249`). Empreintes calculées le 2 novembre 2026 à 19:12 UTC par
`sha256sum` lancé depuis `orchestrator/` d'un arbre extrait du commit `e58cfec` (`git archive`, dossier neuf hors du dépôt), et
recalculées sur le contenu tiré par `git show` et sur les fichiers du disque : les trois sont égales (`empreintes_b3.py`,
section 9, L13). Les 71 lignes de T sont **inchangées** (identiques, caractère pour caractère, à celles du bloc de T) ; les deux
fichiers v3 valent `b821bdb7…` et `ff8aa180…` (en-tête) ; l'ensemble des 73 chemins est égal à `FICHIERS_GELES` du lanceur du
commit. Le directeur recalcule au scellement et refuse tout écart.

<!-- empreintes-du-code : début -->
```
{{BLOC_EMPREINTES}}```
<!-- empreintes-du-code : fin -->

## 12. Devis

**Hypothèses, toutes mesurées sur A1** (A, sections 2 et 5 ; n° 284 ; section 9, L1, L4 et L13) : Argon, **0,062 USD par appel
réussi** en moyenne ((34,35943 − 1,61417)/526 = 0,0623 ; médiane 0,054 ; maximum 0,799 ; l'appel échoué repris a coûté 1,61417
« pire cas ») ; **≈ 7,6 s par appel** sur un fil (526 appels réussis entre 09:58:45 et 11:05:10, 3 985 s, n° 284 ; l'audit donne
09:58:47 à 11:05:16 pour les 527 appels, A, section 5) ; **≈ 22 appels par unité** (527 appels pour 24 unités : W1 ≈ 39,7 par
unité (476 appels pour 12), W2 ≈ 4,3 (51 pour 12, dont la reprise de l'appel échoué : le trou est trouvé dès la première
tentative) ; bras complet, 0 tentative échouée). Hypothèses du code, non remesurées : `APPELS_PAR_UNITE` W1 36 à 48, W2 12 à 40,
maximum 64 par unité (4 suites × 16) ; `LOIS_V8_PAR_UNITE` W1 32, W2 12 ; 56 ms par évaluation sous v8 (mesuré à blanc le
2 novembre, T, ligne 451).

**Option retenue (b′) : Argon seul, 24 cartes par monde, W1 et W2, un fil** — `devis(24, ["W1", "W2"], [argon])` du code du
commit (`pole/attaque_goodhart_v3.py:1019-1058`), `taux_usd` 0,062, `secondes` 8 à 40, `fils` 1 (calculé le 2 novembre à
19:14 UTC, L13 ; égal au devis à un fil du rapport v3, section 16) :
- **Attendu aux taux mesurés d'A1** : 48 unités × ≈ 22 appels ≈ **1 054 appels** (W1 ≈ 952, W2 ≈ 102), soit **≈ 65 USD**
  (65,35 à 0,062 ; 56,92 à la médiane) ; durée des appels ≈ 1 054 × 7,6 s ≈ **2,23 h** sur un fil ; rejeux sous v8
  ≈ 212 256 évaluations × 56 ms / 2 cœurs ≈ **1,65 h** ; **≈ 3,88 h en tout**. La course à blanc à un fil du code final au même
  plan (proposeur scripté) a fait 1 034 appels et 64,108 USD simulés (L12).
- **Attendu du code** (`APPELS_PAR_UNITE`, non remesuré sur un modèle) : 1 152 à 2 112 appels, **71,42 à 130,94 USD**, durée des
  appels 2,56 à 23,47 h à un fil (8 à 40 s) ; **durée attendue haute 25,12 h** (23,47 h d'appels + 1,65 h de rejeux).
- **Maximum** : 48 unités × 64 appels = **3 072 appels**, **190,46 USD** ; durée des appels 34,13 h à 40 s, **35,78 h** avec les
  rejeux.
- **Ce que le lanceur v3 exige** (`lire_plan`, `demonstrations/attaque_goodhart_v3.py:209-215`) : plafond ≥ maximum du devis
  (≥ 190,46 USD) ; durée ≥ durée attendue haute (≥ 25,12 h). **Ce que ce texte retient** (décisions (ii) et (vi)) :
  `plafond_usd: 400`, 2,1 fois le maximum, **montant de GO-2026-11-02-21** (le GO est un plafond d'autorisation, pas une
  prévision : la dépense attendue est de 65 à 131 USD) ; un taux par appel deux fois plus haut que mesuré (0,124 USD) n'atteint
  pas le plafond, même au maximum (380,93 USD) ; trois fois (0,186 USD) l'atteindrait au-delà de 2 151 appels, au-dessus de
  l'attendu haut du code (2 112) ; et `duree_max_h: 72`, au-dessus du pire cas (35,78 h) : une garde contre une boucle folle,
  jamais une coupe de la mesure.
- **Pannes et garde de durée** : la garde de 72 h (`Compteur.verifier`, vérifiée avant chaque appel et entre les rejeux) laisse
  au temps de panne cumulé ≈ 68,12 h aux taux mesurés d'A1 (72 − 3,88), 46,88 h à la durée attendue haute du code, 36,22 h au
  pire cas des appels ; sous `relais_perdu_h: aucun`, une panne de relais se paie en attente (aucune tentative perdue sous
  30 min, puis environ une par demi-heure, section 4) ; seule une panne plus longue que cette marge fait tomber la garde (code 3,
  arrêt d'infrastructure, section 8), par exemple un relais mort pour de bon que personne ne relance (règle des guetteurs).
- **Échecs muets** (choix (e), section 4) : 1,8 USD comptés par appel muet, aucune attente ; avant le plafond, le compteur en
  absorbe 186 (93 tentatives) à la dépense attendue aux taux d'A1 et 117 (58 tentatives) au maximum du devis ; le registre de
  dépense cumulée des commandes tient la même limite de 400 USD.
- **Probabilités d'issue par monde** (24 unités jouées ; p₁₆ sous v8 avec retour ; résiste / brèche / non concluant) : 0,02 →
  0,92 / 0,00 / 0,08 ; 0,05 → 0,66 / 0,03 / 0,31 ; 0,10 → 0,29 / 0,21 / 0,49 ; 0,20 → 0,03 / 0,74 / 0,23 ; 0,30 → 0,00 / 0,96 /
  0,04 ; 0,50 → 0,00 / 1,00 / 0,00 (section 5 pour u < 24). Sur W1, p₁₆ est borné par 0,56 (théorie, 1 − 0,95¹⁶) et attendu petit
  (A1, Argon : 1/12) ; sur W2, attendu grand (A1, Argon : 12/12). Les dents (H1) suivent la colonne « brèche » au taux sous v7
  (A1, Argon : 10/12). Gain du retour sur W2 (Δ₄, McNemar exact) : détecté avec probabilité 0,46 à 0,70 pour des écarts de 0,3 à
  0,4 (section 5) ; dans A1, Argon trouvait le trou dès la première tentative dans les deux conditions (A4 bis sur Argon seul) :
  Δ₄ y était nul.

Options (a) et (c), non retenues : annexe A.

## 13. Avant la course

1. **Code final** : fait (commit `e58cfec` ; essais et banc passés par le rédacteur du code, rejoués à 19:04 UTC selon le message
   du commit, et rejoués par le rédacteur de ce texte sur une copie extraite du commit : en-tête). Réserves du rapport v3 (section 10) maintenues : chemin réel
   jamais joué contre les commandes de session-depot ; attente sur relais en temps réel seulement sur une coupure scriptée ;
   rejeux à blanc à 20, non à 200.
2. **Contre-lecture neuve (R2)** par un sous-agent qui n'a écrit ni ce texte ni le code, avec la liste des fichiers à lire
   (section 14) ; couples de remplacement appliqués mot pour mot ; version contre-lue renommée
   `prereg/preenregistrement-attaque-goodhart-v3-vN.md`.
3. **GO de calcul** : GO-2026-11-02-21, 400 USD, échéance 2026-11-16 ; au lancement, le registre hors du clone suit la règle de la
   section 4 (aucune ligne de révocation ne le nomme ; `grep -n` au journal).
4. **Aucun marqueur** : le texte n'en porte aucun (le lanceur refuse un texte qui en porte un) ; la configuration est un fait
   (décision (viii)) ; les chemins hors du clone sont à confirmer par session-depot, sans bloquer le scellement (section 4).
5. **Bloc `empreintes-du-code`** : calculé sur le commit `e58cfec` ; le directeur le recalcule au scellement et refuse tout écart.
6. **Scellement par le directeur** (compagnon `.sha256`) ; **commit et poussée du texte scellé avant la course**.
7. **Chez session-depot** : configuration à l'empreinte `e5306c47…` ; relais Argon 8805 **neuf**, lancé pour cette course ;
   commande `commande_argon_v56_nuit_v2.py` et registre de dépense sous verrou exclusif (n° 286) ; aucun relais Kimi ;
   environnement de l'orchestrateur sans variable de clé ; registre des GO et dossier de sortie hors du clone (section 4), avec
   le commit, l'empreinte et la sortie de `grep -n` du registre au journal de lancement ; `git status --porcelain` vide, copié au
   journal ; **règle des guetteurs** (section 8) lue et acceptée : relancer seulement, jamais arrêter, tout écrit avec l'heure ;
   avec `relais_perdu_h: aucun`, la relance d'un relais mort est la seule voie de reprise : un guetteur actif pendant toute la
   course.
8. `--verifier-seulement` (aucun appel ; sortie imprimée gardée avec la course) ; puis **la course** (commande exacte, section 4).
9. **Sortie scellée avant lecture** ; livraison à l'audit de la sortie, du manifeste, du registre de dépense, du registre des GO
   lu, des journaux de session-depot (lancement, relais, guetteurs), chacun empreinté ; **audit écrit** (section 7, A1 à A9) par
   un auditeur neuf ; **verdict par un lecteur neuf (R13)** qui applique la section 6 dans l'ordre 2, 6, 1, 3, 4, 5, avec ses
   qualifications ; soumis à Lazar ; page publique : la reprise est rapportée **avec** A1 (section 0).

## 14. Contre-lecture (R2) — à faire

Ce brouillon n'a pas été contre-lu. Fichiers à donner au contre-lecteur neuf : ce texte ; le brouillon 2 (pour la liste des
changements, section 0.1) ; T ; le verdict et l'audit d'A1 (par empreintes, section 0.2) ; le rapport v3 final (`ef2f2503…`) ;
au commit `e58cfec` : `pole/attaque_goodhart_v3.py`, `demonstrations/attaque_goodhart_v3.py`, `essais/test_attaque_goodhart_v3.py`,
`essais/mutations_attaque_goodhart_v3.py`, `pole/attaque_goodhart_v2.py` (lignes 457 à 510, 513 à 545, 583 à 640, 750 à 830,
1002 à 1046), `demonstrations/attaque_goodhart_v2.py` (lignes 56 à 61, 98 à 102, 185 à 196, 233 à 250, 300 à 306),
`pole/adaptateurs.py` (lignes 600 à 779), `pole/configuration_v55.py` (lignes 72 à 100), `pole/configuration_v53.py` (lignes 258
à 281) ; les messages n° 286 et n° 287 de session-depot (copies du bloc-notes de la session) ; les scripts de calcul du
bloc-notes (L13). **Les dix points à vérifier en premier** :
1. **Bloc `plan-gele`** (section 4) : clés exactes ; `fils=1` ; `relais_perdu_h: aucun` ; `plafond_usd: 400` = montant de
   GO-2026-11-02-21 ; `duree_max_h: 72` ≥ 25,12 h ; lu par `lire_plan` (`demonstrations/attaque_goodhart_v3.py:152-221`) : accepté,
   devis égal à la section 12.
2. **GO** : GO-2026-11-02-21 est le seul identifiant de GO du texte ; `verifier_go` (`demonstrations/attaque_goodhart_v2.py:185-196`,
   puis `configuration_v55.verifier_go_v55`) exige 400 USD à 10⁻⁹ près ; règles (1) à (4) du registre hors du clone.
3. **Bloc `empreintes-du-code`** : 73 lignes = `FICHIERS_GELES` (`demonstrations/attaque_goodhart_v3.py:98`) ; les 71 de T
   inchangées ; `b821bdb7…` et `ff8aa180…` = fichiers v3 du commit `e58cfec`.
4. **Ordre 2, 6, 1, 3, 4, 5** (`pole/attaque_goodhart_v3.py:805-816`) et ce qu'il entraîne : section 5 (« Pourquoi après 2 »,
   « Pourquoi avant 1 », prix de l'ordre ; tableau, lignes 0 à 11) et section 6 (qualifications).
5. **Codes de sortie** (table de la section 4) contre `CODES_DE_SORTIE` (`:65`), `cause_d_echec` (`:286-299`) et `appeler`
   (`:302-359`) : code 6 → « delai », règle v2 ; seule la cause « relais » à coût ≤ 10⁻⁵ USD attend (`:335-346`).
6. **`relais_perdu_h: aucun`** → `lire_relais_perdu` rend `None` (`demonstrations/attaque_goodhart_v3.py:224-232`) →
   `Compteur.attendre_relais` (`pole/attaque_goodhart_v3.py:228-241`) ne s'arrête jamais sur le cumul ; coût d'une panne en
   tentatives ; la garde de 72 h comme seul arrêt de temps.
7. **Choix (e)** : coût d'un appel muet (1,8 USD, `pole/adaptateurs.py:751-765`), pire cas sous 400 USD (sections 4 et 12,
   `devis_b3.py`), règle de lecture (1) à (3).
8. **Section 8** : 68 noms d'essais, 40 mutations (libellés, fonctions, essais), 45 essais v2, numéros de mutation des gardes :
   vérifiés par programme (L13) ; à revoir à la main sur deux ou trois lignes.
9. **Simulation du lanceur** : copie `preenregistrement-attaque-goodhart-v3-v1.md`, compagnon factice, dossier hors du dépôt :
   acceptée par `lire_preenregistrement` (entropie ≥ 2⁶⁴, 73 empreintes vérifiées) ; à refaire sur la version contre-lue.
10. **Liste 0.1** contre le brouillon 2 (`551f5d2e…`) ; renvois à T (version scellée `fc81d015…`), à A et à V : aucun chiffre sans
    source.

## Annexe A. Options non retenues (trace de la décision du 2 novembre, R-1264)

Calculées par `devis` du v3 (brouillon 1, L4) ; `APPELS_PAR_UNITE` d'A1 ; Kimi aux mesures d'A1 (0,35 USD par appel, 600 à
1 500 s, 6 fils ; ou 944 s fixes, la moyenne mesurée) ; Argon comme en (b′) (à 2 fils dans ces calculs du brouillon 1, sans effet
sur les colonnes : Kimi y fixe la durée) ; Astra, Fable et Opus **non mesurés** (0,05 à 2,3 USD par appel, 10 à 120 s, 2 fils : à
calibrer en mode essai avant toute course). Le lanceur exige plafond ≥ maximum et durée ≥ durée attendue haute.

| option | unités par case | appels attendus (max), total | USD attendus (max), total | durée des appels, parallèle (h) | durée attendue haute (h) | pourquoi non retenue |
|---|---|---|---|---|---|---|
| (a) Argon et Kimi, 12 cartes par monde (comme A1) ; Kimi 600 à 1 500 s | 24 (12 × 2) | 1 152 à 2 112 (3 072) : Kimi 576 à 1 056, Argon idem | 237,3 à 435,1 (**632,8**) : Kimi 201,6 à 369,6 (537,6), Argon 35,7 à 65,5 (95,2) | 16,0 à 73,3 (Kimi à 6 fils ; 106,7 au pire) | **75,0** | Kimi à 944 s par appel et 0,35 USD : ≈ 185 USD attendus pour son seul bras aux ≈ 22 appels par unité d'A1 ; plafond exigé 633 USD ; au moins 6 fils ; Kimi d'abord calibré en mode essai (ordre de Lazar, n° 284) |
| (a) idem, Kimi à 944 s fixes | 24 | idem | idem | 25,2 à 46,2 (67,1 au pire) | 47,8 | idem |
| (c) quatre fournisseurs (Kimi, Astra `gpt-6-astra`, Fable `claude-fable-5-1`, Opus `claude-opus-5-5`), 6 cartes par monde ; autres à 0,05 USD | 24 (6 × 4) | 1 152 à 2 112 (3 072) : 288 à 528 (768) chacun | 144,0 à 264,0 (**384,0**) : Kimi 100,8 à 184,8 (268,8), les trois autres 14,4 à 26,4 (38,4) chacun | 8,0 à 36,7 (Kimi ; 53,3 au pire) | 38,3 | trois fournisseurs sans mesure (taux inconnu à un facteur 46 : voir la ligne suivante), commandes Claude et Astra au format v56 inexistantes (rapport v3, section 10) ; 6 cartes par fournisseur : quatre unités par carte, corrélées |
| (c) idem, autres à 2,3 USD | 24 | idem | 2 088 à 3 828 (**5 568**) : 662,4 à 1 214,4 (1 766,4) chacun | idem | 38,3 | idem |

Lecture : (b′) est la seule option dont tous les taux sont mesurés et dont le plafond exigé par le lanceur (≥ 190,46 USD) est du
même ordre que l'attendu (65 à 131 USD) ; ce texte retient 400 USD (décision (ii)). Elle répond à la question d'A1 pour Argon,
qui est le seul bras qu'A1 a réellement mesuré. Elle ne dit rien de Kimi ni des deux autres familles : c'est dit en portée
(section 10).

## Annexe B. Marqueurs

**Aucun marqueur dans ce brouillon** (aucun jeton au motif du lanceur, aucun commentaire « MARQUEUR » ; vérifié par programme,
section 9, L13).

**Levé par ce brouillon** : relais Argon (jeton de la dernière ligne du bloc `plan-gele` du brouillon 2 et son commentaire) —
n° 287 : relais 8805 à un seul fil, donc `fils=1` ; codes de sortie 2 à 6 et commande muette (table de la section 4, choix (e)) ;
la variante à un fil (annexe C du brouillon 2) devient le plan, avec le plafond et la durée des décisions (ii) à (vi) (400 USD et
72 h, au lieu de 191 USD et 36 h). **Levés par le brouillon 2** : GO de calcul, bloc `empreintes-du-code`, règle « relais perdu »
(tous trois remplacés ou recalculés ici). **Levés par le brouillon 1** : fournisseurs et grille (R-1264), configuration (n° 284),
`decision_ecart`. **Ne sont pas des marqueurs** : la configuration (fait, décision (viii)) et les chemins hors du clone (« à
confirmer par session-depot », non bloquants, section 4).

## Empreintes des fichiers du rédacteur (bloc-notes `…/scratchpad/a1-v3-texte-b3/`)

{{EMPREINTES_REDACTEUR}}
Ce fichier ne peut pas porter sa propre empreinte ; elle est donnée avec sa remise.
