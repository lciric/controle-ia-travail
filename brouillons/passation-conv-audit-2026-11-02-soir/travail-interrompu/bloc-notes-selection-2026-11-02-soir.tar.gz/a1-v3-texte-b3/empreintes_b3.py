"""Bloc empreintes-du-code du brouillon 3 : les 73 chemins de FICHIERS_GELES du lanceur v3, empreintes calculées trois fois sur
le commit e58cfec — (1) `sha256sum` lancé depuis `orchestrator/` d'un arbre extrait du commit (`git archive`, dossier neuf),
(2) contenu tiré par `git show`, (3) fichiers du disque — ; les 71 lignes du bloc de T comparées ligne pour ligne ; les deux
fichiers v3 comparés aux empreintes données par le directeur. Lecture seule ; rien n'est écrit dans le dépôt.
Usage : python3 -I -B empreintes_b3.py DOSSIER_EXTRAIT (dossier neuf, hors dépôt)."""
import hashlib
import importlib.util
import os
import re
import subprocess
import sys

DEPOT = "/home/claude/ideation-organism"
ORCH = DEPOT + "/orchestrator"
COMMIT = "e58cfec936461a72a173c667e91755582e04bcb8"
ICI = os.path.dirname(os.path.abspath(__file__))
extrait = sys.argv[1]
assert not os.path.exists(extrait) or not os.listdir(extrait), "dossier d'extraction non vide"
os.makedirs(extrait, exist_ok=True)
archive = subprocess.run(["git", "-C", DEPOT, "archive", COMMIT, "orchestrator"], capture_output=True, check=True).stdout
subprocess.run(["tar", "-x", "-C", extrait], input=archive, check=True)

# FICHIERS_GELES : lanceur v3 chargé depuis l'arbre extrait du commit (processus -I -B : aucun fichier .pyc écrit)
sys.path.insert(0, os.path.join(extrait, "orchestrator"))
spec = importlib.util.spec_from_file_location("l3", os.path.join(extrait, "orchestrator", "demonstrations", "attaque_goodhart_v3.py"))
l3 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(l3)
geles = sorted(l3.FICHIERS_GELES)
print("FICHIERS_GELES (lanceur du commit) :", len(geles), "chemins ; v2 :", len(l3.l2.FICHIERS_GELES))

# (1) sha256sum depuis orchestrator/ de l'arbre extrait
s = subprocess.run(["sha256sum", *geles], cwd=os.path.join(extrait, "orchestrator"), capture_output=True, check=True, text=True).stdout
par_sha256sum = {p: h for h, p in re.findall(r"^([0-9a-f]{64})  (\S+)$", s, re.M)}
assert sorted(par_sha256sum) == geles


def git_show(p):
    return hashlib.sha256(subprocess.run(["git", "-C", DEPOT, "show", f"{COMMIT}:orchestrator/{p}"], capture_output=True, check=True).stdout).hexdigest()


def disque(p):
    return hashlib.sha256(open(os.path.join(ORCH, p), "rb").read()).hexdigest()


ecarts = [(p, par_sha256sum[p], git_show(p), disque(p)) for p in geles if not (par_sha256sum[p] == git_show(p) == disque(p))]
print("écarts sha256sum (arbre extrait) / git show / disque :", ecarts if ecarts else "aucun")

T = ORCH + "/prereg/preenregistrement-attaque-goodhart-v2-v1.md"
texte_t = open(T, encoding="utf-8").read()
print("T :", hashlib.sha256(texte_t.encode("utf-8")).hexdigest())
i, j = texte_t.find("<!-- empreintes-du-code : début -->"), texte_t.find("<!-- empreintes-du-code : fin -->")
lignes_t = re.findall(r"^([0-9a-f]{64})  (\S+)$", texte_t[i:j], re.M)
print("lignes du bloc de T :", len(lignes_t))
t = {p: h for h, p in lignes_t}
print("71 chemins de T = FICHIERS_GELES du lanceur v2 :", sorted(t) == sorted(l3.l2.FICHIERS_GELES))
print("71 lignes de T inchangées au commit :", all(par_sha256sum[p] == h for p, h in t.items()),
      [p for p, h in t.items() if par_sha256sum[p] != h])
neufs = {"pole/attaque_goodhart_v3.py": "b821bdb73a2829a41d519800859bbf10216254ca97228b5a179438eed38a1c6a",
         "demonstrations/attaque_goodhart_v3.py": "ff8aa180c5f69290dd02b66f7252dfb47a78868220cd2260bdbe171844b7313a"}
for p, h in neufs.items():
    print(p, "= empreinte donnée par le directeur :", par_sha256sum[p] == h)
print("73 = 71 de T + 2 fichiers v3 :", sorted(set(t) | set(neufs)) == geles)
bloc = "".join(f"{par_sha256sum[p]}  {p}\n" for p in geles)
with open(os.path.join(ICI, "bloc-empreintes-b3.txt"), "w", encoding="utf-8") as f:
    f.write(bloc)
print("bloc écrit :", len(geles), "lignes ; sha256 du bloc", hashlib.sha256(bloc.encode("utf-8")).hexdigest())
# lignes du bloc de T restituées dans le même ordre : identiques caractère pour caractère
print("71 lignes identiques au texte de T (mêmes caractères) :",
      all(f"{h}  {p}" in texte_t for p, h in ((p, par_sha256sum[p]) for p in t)))
