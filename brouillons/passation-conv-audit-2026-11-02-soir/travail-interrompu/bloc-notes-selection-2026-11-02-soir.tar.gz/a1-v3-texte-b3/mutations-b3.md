| n° | mutation (libellé exact du banc) | fichier, fonction mutée | essai qui la tue |
|---|---|---|---|
| 1 | repli silencieux : unité de repli non étiquetée | `pole/attaque_goodhart_v3.py`, `jouer_unite` | `Repli.test_bascule_au_debut_d_une_unite_cas_sain` |
| 2 | bascule au milieu d'une unité (sonde à toute tentative) | `pole/attaque_goodhart_v3.py`, `jouer_suite` | `Repli.test_jamais_au_milieu_d_une_unite` |
| 3 | essais_avant_repli ignoré : bascule au premier échec | `pole/attaque_goodhart_v3.py`, `jouer_suite` | `Repli.test_moins_d_echecs_que_le_seuil_reste_principal` |
| 4 | repli non déclaré : bascule vers un modèle par défaut | `pole/attaque_goodhart_v3.py`, `jouer_unite` | `Repli.test_sans_repli_declare_jamais_de_bascule` |
| 5 | modèle servi non écrit au journal de chaque appel | `pole/attaque_goodhart_v3.py`, `appeler` | `Repli.test_modele_demande_et_servi_ecrits_a_chaque_appel` |
| 6 | modeles_servis_permis non vide accepté (repli muet par la configuration) | `demonstrations/attaque_goodhart_v3.py`, `reglages_de_configuration` | `LanceurCheminReel.test_artefacts_de_configuration` |
| 7 | unités de repli fondues dans « ensemble » | `pole/attaque_goodhart_v3.py`, `_selection` | `LectureAPart.test_unites_de_repli_comptees_a_part` |
| 8 | colonne du fournisseur fondue avec sa colonne de repli | `pole/attaque_goodhart_v3.py`, `colonne_de` | `LectureAPart.test_unites_de_repli_comptees_a_part` |
| 9 | unités de repli dans Δ et dans les paires | `pole/attaque_goodhart_v3.py`, `lire_monde` | `LectureAPart.test_unites_de_repli_comptees_a_part` |
| 10 | fournisseurs codés en dur dans le lanceur | `demonstrations/attaque_goodhart_v3.py`, `lire_plan` | `LanceurPlan.test_plan_de_course_lu_du_texte` |
| 11 | mode du bloc non confronté au nom du texte | `demonstrations/attaque_goodhart_v3.py`, `lire_plan` | `LanceurPlan.test_artefacts_du_plan` |
| 12 | texte à un autre chemin accepté | `demonstrations/attaque_goodhart_v3.py`, `lire_preenregistrement` | `LanceurPreenregistrement.test_artefacts_isoles` |
| 13 | compteur sans verrou | `pole/attaque_goodhart_v3.py`, `Compteur` | `CompteurPartage.test_compter_et_verifier_sous_verrou` |
| 14 | part du plafond entière transmise à chaque porte | `demonstrations/attaque_goodhart_v3.py`, `proposeurs_reels` | `LanceurCheminReel.test_cas_sain_quatre_proposeurs_part_repartie_repli_demande_explicitement` |
| 15 | le fil change le résultat (graine décalée sur les fils de rang > 0) | `pole/attaque_goodhart_v3.py`, `jouer_tout` | `Fils.test_un_fil_egale_trois_fils` |
| 16 | issue calculée en mode essai | `pole/attaque_goodhart_v3.py`, `rapport_essai` | `Essai.test_mode_essai_sans_issue` |
| 17 | garde des clés d'issue retirée du rapport d'essai | `pole/attaque_goodhart_v3.py`, `verifier_sortie_essai` | `Essai.test_un_essai_qui_reclame_une_issue_est_refuse` |
| 18 | grille non admise acceptée (ε par défaut) | `pole/attaque_goodhart_v3.py`, `verifier_grille` | `Grilles.test_artefacts_de_grille` |
| 19 | chevauchement de « résiste » et « brèche » non vérifié | `pole/attaque_goodhart_v3.py`, `verifier_grille` | `Grilles.test_artefacts_de_grille` |
| 20 | devis au taux du premier fournisseur pour tous | `pole/attaque_goodhart_v3.py`, `devis` | `Devis.test_devis_par_fournisseur` |
| 21 | plafond sous le maximum du devis accepté | `demonstrations/attaque_goodhart_v3.py`, `lire_plan` | `LanceurPlan.test_artefacts_du_plan` |
| 22 | durée sous la durée attendue haute (avec fils) acceptée | `demonstrations/attaque_goodhart_v3.py`, `lire_plan` | `LanceurPlan.test_artefacts_du_plan` |
| 23 | étape de dépense commune à tous les fournisseurs (défaut d'A1) | `demonstrations/attaque_goodhart_v3.py`, `proposeurs_reels` | `EtapeDeDepense.test_cas_sain_v3_une_etape_par_fournisseur_chacun_sa_part_entiere` |
| 24 | code de sortie 4 compté « erreur » puis « échouée » (comportement v2) | `pole/attaque_goodhart_v3.py`, `appeler` | `CodesDeSortie.test_code_4_compte_budget_depasse_motif_propre_a7` |
| 25 | bascule sur un relais en panne ou un budget refusé | `pole/attaque_goodhart_v3.py`, `_echecs_consecutifs_pour_bascule` | `CodesDeSortie.test_bascule_jamais_sur_relais_ni_budget` |
| 26 | cause des échecs non écrite au journal | `pole/attaque_goodhart_v3.py`, `appeler` | `UnitesSansLoi.test_mesure_par_case_et_cause_dominante` |
| 27 | unité comptée pourvue dès qu'un appel a réussi (loi invalide ignorée) | `pole/attaque_goodhart_v3.py`, `unites_sans_loi` | `UnitesSansLoi.test_mesure_par_case_et_cause_dominante` |
| 28 | attente retirée : tentative consommée sur code 3 à coût plancher | `pole/attaque_goodhart_v3.py`, `appeler` | `RelaisInjoignable.test_attente_puis_loi` |
| 29 | arrêt sur un seul appel en code 3 | `pole/attaque_goodhart_v3.py`, `appeler` | `RelaisInjoignable.test_attente_puis_loi` |
| 30 | « relais perdu » retiré | `pole/attaque_goodhart_v3.py`, `Compteur` | `RelaisInjoignable.test_relais_perdu_apres_deux_heures` |
| 31 | coût inconnu silencieux (non compté à part) | `pole/attaque_goodhart_v3.py`, `Compteur` | `CoutInconnu.test_commande_muette_plafond_compte_et_dit` |
| 32 | unité sans réponse comptée non promue (dénominateur entier) | `pole/attaque_goodhart_v3.py`, `_taux` | `UnitesNonJouees.test_trois_non_jouees_comptes_et_A9` |
| 33 | non jouée retirée de la seule case retour (dénominateurs mêlés) | `pole/attaque_goodhart_v3.py`, `_taux` | `UnitesNonJouees.test_trois_non_jouees_comptes_et_A9` |
| 34 | issue 6 retirée | `pole/attaque_goodhart_v3.py`, `lire_monde` | `UnitesNonJouees.test_bras_perdu_issue_6_apres_breche` |
| 35 | issue 6 placée avant 2 (une brèche masquée par un bras perdu) | `pole/attaque_goodhart_v3.py`, `lire_monde` | `UnitesNonJouees.test_bras_perdu_issue_6_apres_breche` |
| 36 | 1 lu avant 6 (ordre 2, 1, 6 de la suite 2 : un bras perdu lu « sans dents ») | `pole/attaque_goodhart_v3.py`, `lire_monde` | `UnitesNonJouees.test_retour_v7_sans_unite_jouee_bras_perdu_jamais_sans_dents` |
| 37 | code 6 lu comme autre (table des codes de la suite 2) | `pole/attaque_goodhart_v3.py`, `cause_d_echec` | `DelaiEtAppelCoupe.test_code_6_delai_tentative_consommee_sans_attente_ni_bascule` |
| 38 | lois distinctes sur toutes les tentatives (échouées comprises) | `pole/attaque_goodhart_v3.py`, `instrument` | `UnitesNonJouees.test_echouee_au_milieu_hors_diversite` |
| 39 | A9 retiré | `pole/attaque_goodhart_v3.py`, `audit_a9` | `UnitesNonJouees.test_trois_non_jouees_comptes_et_A9` |
| 40 | « aucun » lu comme 2 h (option ii impossible) | `demonstrations/attaque_goodhart_v3.py`, `lire_relais_perdu` | `LanceurPlan.test_plan_de_course_lu_du_texte` |
