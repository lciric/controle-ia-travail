# Préenregistrement — attaque de Goodhart contre le juge statistique, reprise propre d'A1 (course « A1-v3 »), brouillon 3

**Statut : brouillon 3, non contre-lu, non scellé ; aucun marqueur.** Rédigé le 2 novembre 2026 (19:05 à {{FIN}} UTC,
`date -u`) par un second rédacteur, qui reprend le brouillon 2 du premier (coupé par une panne de crédits) et qui n'a écrit ni
le texte d'A1, ni son code, ni le code v3, ni l'audit, ni le verdict, ni les brouillons 1 et 2 ; aucun appel de modèle, aucune
clé, aucun réseau ; aucun commit, aucun `.sha256` dans le dépôt, aucun fichier existant modifié (brouillon 1, sha256
`2c0465be02633ac6c78b37f3dc9c4b63b0c832286e600039574c77860d6a92fa`, et brouillon 2,
`prereg/preenregistrement-attaque-goodhart-v3-brouillon2.md`, sha256
`551f5d2e07263f4bd12e79e57da80ed1381e5d8737b77abc4a33e9336d826fbd`, intacts), rien sous `donnees/`, aucun `git fetch` ; seuls
calculs : lecture seule du code du commit et de ses essais (`nice -n 10 python3 -I -B`, scripts et sorties dans le bloc-notes
`…/scratchpad/a1-v3-texte-b3/`, empreintes en fin de texte ; essais et banc rejoués sur une copie extraite du commit, hors du
dépôt). Ce texte reprend la structure d'A1 (sections 1 à 14) ; tout ce qui est identique renvoie au texte scellé d'A1,
**T** = `prereg/preenregistrement-attaque-goodhart-v2-v1.md`, sha256
`fc81d015d27e60388099c7845a66b75d613187f99d5d0060950540a686925b65` (lignes de la version scellée) ; tout ce qui change est
écrit en entier. Le lanceur v3 refuse ce brouillon à son nom (hors de `preenregistrement-attaque-goodhart-v3-v<N>.md`) et faute
de scellement : c'est voulu ; renommé et scellé tel quel, il est accepté (simulation hors du dépôt, compagnon factice :
section 9, L13). Aucun jeton de marqueur (motif du lanceur : deux chevrons ouvrants, majuscules et soulignés, deux chevrons
fermants, `demonstrations/attaque_goodhart_v2.py:58`, repris par `demonstrations/attaque_goodhart_v3.py:86`) ne reste.

**Décisions de Lazar et faits portés** (relayés par le directeur ; décisions et registres privés cités par leur numéro, non lus
par le rédacteur) :
- (i) Fournisseurs et grille : **option (b′), Argon seul, 24 cartes par monde** (« (b′) Argon seul, 24 cartes par monde ; go »,
  2 novembre 2026, 16:56 UTC, session conv-audit ; registres/decisions.md, R-1264, dépôt privé). Ordre prévu chez session-depot
  (n° 284) : Argon d'abord, Kimi ensuite après calibrage, Claude et Astra ensuite. Options (a) et (c) : annexe A, non retenues.
- (ii) **Budgets et plafonds larges, aucune coupe** — mots de Lazar, 2 novembre 2026, 18:26 à 18:29 UTC : « arrête de mettre des
  budgets temps et de les couper », « prends des budgets et plafonds très larges », « je ne veux pas de résultats non concluants
  par défaut de conception, de plafond ». Ce texte les porte par (iii) à (vii).
- (iii) **GO de calcul : GO-2026-11-02-21**, type calcul, **400 USD** (égal à `plafond_usd`), échéance 2026-11-16. C'est le seul GO
  que ce texte nomme ; il remplace celui du brouillon 2 (191 USD, R-1271). Ligne du registre privé non lue par le rédacteur ; le
  contrôle que le lanceur en fera est simulé sur une ligne factice au même format (section 4, « GO » ; section 9, L13).
- (iv) **Un seul fil** : `fils=1` (n° 287 : le relais 8805 sert sur un serveur à un seul fil ; un second appel simultané
  attendrait dans la file d'acceptation et pourrait dépasser son délai, code 6 au coût du pire cas ; recommandation de
  session-depot : `fils=1`, sans code neuf).
- (v) **Aucun arrêt sur relais** : `relais_perdu_h: aucun`. Une panne met la course en attente (15, 30, 60, 120 puis 300 s,
  30 min au plus par tentative, puis « tentative échouée (relais) », suite poursuivie) ; jamais d'arrêt sur le cumul des attentes.
- (vi) **Plafond et durée** : `plafond_usd: 400` (2,1 fois le maximum du devis, 190,46 USD) ; `duree_max_h: 72`, garde contre une
  boucle folle seulement, jamais une coupe de la mesure (durée attendue haute 25,12 h, pire cas 35,78 h : devis du rapport v3,
  section 16, recalculé en section 12).
- (vii) **Ordre des issues 2 (brèche), 6 (bras perdu), 1 (sans dents)**, puis 3, 4, 5 (code du commit `e58cfec` ; correction du
  contre-lecteur, 2 novembre, 18:15 UTC ; rapport v3, section 16) ; **code 6** de la commande d'Argon = délai dépassé ou signal,
  compté au pire cas, cause « delai », sans attente ; codes de sortie 2 à 6 et commande muette selon n° 287 ; seul le code 3 à coût
  plancher déclenche l'attente (section 4).
- (viii) Configuration : la configuration v3 de session-depot (`configuration-mini-course-kimi-argon-v3.json`, sha256
  `e5306c47e1b21a5e55b599411dba92c97e88aa98bb6d6fa91fc5d358a2bdde30`) sert telle quelle pour Argon seul (n° 284). C'est un fait
  de ce texte, non un marqueur : si session-depot livre une autre configuration avant le scellement, son empreinte remplace
  celle-ci (version nouvelle du texte).
- (ix) Mesures d'Argon dans A1 (n° 284 ; A, sections 2 et 5) : 526 appels réussis sur un fil entre 09:58:45 et 11:05:10 UTC,
  soit ≈ 7,6 s par appel en moyenne ; 0,062 USD par appel réussi en moyenne, 0,054 en médiane, 0,799 au maximum ; bras Argon
  complet (96 suites sur 96, 0 tentative échouée).
- (x) Faits de session-depot (messages lus et vérifiés par conv-audit, copiés dans le bloc-notes de la session) : **n° 286**
  (18:14 UTC) — verrou du registre de dépense confirmé : `reserver` lit l'état puis écrit la ligne « debut » sous un même verrou
  exclusif `fcntl.flock` (`registre_depense_cumulee_v1.py`, lignes 103 à 113 et 133 à 148, chez session-depot) : deux réservations
  simultanées sont sérialisées ; registre des GO hors du clone : accepté (le fichier entier de la branche privée, au commit cité,
  placé hors du clone au chemin que ce texte écrit, section 4) ; **n° 287** (18:16 UTC) — relais 8805 à un seul fil (iv) ; codes de
  sortie 2 à 6 de `commande_argon_v56_nuit_v2.py appeler` et commande muette (section 4, table des codes).

**Code v3 final** (commit `e58cfec936461a72a173c667e91755582e04bcb8` de `ideation-organism`, branche `main`, 2 novembre 2026,
19:05 UTC ; arbre de travail égal au commit pour ces cinq fichiers, vérifié par `git diff --quiet` à 19:12 UTC) :

| fichier | lignes | sha256 |
|---|---|---|
| `pole/attaque_goodhart_v3.py` | 1 086 | `b821bdb73a2829a41d519800859bbf10216254ca97228b5a179438eed38a1c6a` |
| `demonstrations/attaque_goodhart_v3.py` | 581 | `ff8aa180c5f69290dd02b66f7252dfb47a78868220cd2260bdbe171844b7313a` |
| `essais/test_attaque_goodhart_v3.py` | 1 455 | `47e37a8e5e7f3283e76fa377423c656637548145b4ce76c1d6daf8d8abc19151` |
| `essais/mutations_attaque_goodhart_v3.py` | 257 | `dda239cd1b17736555b96ab30664dbcaf6e884b111cf8ff42b95f89d0f404f89` |
| `prereg/rapport-redaction-attaque-goodhart-v3.md` | 625 | `ef2f250312d7864faa305120717edeed7c49ba837722d6c92481b01ef244753d` |

Essais et banc sur ce code : rédacteur du code (suite 3), 18:50 à 18:54 UTC (rapport v3, section 16) :
`essais/test_attaque_goodhart_v3.py` 68 réussis, 98 sous-essais, 0 échec ; `essais/test_attaque_goodhart_v2.py` 45 réussis,
54 sous-essais, 0 échec ; banc `essais/mutations_attaque_goodhart_v3.py` 40 mutations, 40 tuées pour la raison attendue, témoin
29 essais sans échec avant et après ; message du commit : « 68 tests and 98 subtests pass (rerun 19:04 UTC) », « 40 of 40
mutations killed » ; rejoués par le rédacteur de ce texte sur une copie extraite du commit (section 9, L14) :
{{ESSAIS_REJOUES}}.

Le scellement (compagnon `.sha256` écrit par le directeur sur une version contre-lue renommée
`prereg/preenregistrement-attaque-goodhart-v3-vN.md`, N entier ≥ 1, sans « brouillon ») fixe la graine (section 4) ; le lanceur
n'accepte que ce chemin-là (`demonstrations/attaque_goodhart_v3.py:83-84`, `:245-249`). Aucune course réelle avant le scellement.

## 0. Écarts et raison de la reprise

### 0.1 Changements du brouillon 2 au brouillon 3 (une ligne chacun)

1. Rédacteur : un second rédacteur reprend le brouillon 2 (le premier a été coupé par une panne de crédits) ; en-tête, statut et liste des décisions et faits portés ((i) à (x)) réécrits.
2. Code : commit `e58cfec` (suite 3 du code : ordre 2, 6, 1 ; code 6) au lieu de `d15f489` ; cœur `b821bdb7…` (1 086 lignes), lanceur `ff8aa180…` (581) ; tous les renvois `fichier:ligne` du texte recalculés sur ce commit.
3. GO : celui du brouillon 2 (191 USD, R-1271) est remplacé par **GO-2026-11-02-21** (400 USD, échéance 2026-11-16) ; c'est le seul GO que le texte nomme.
4. Plafond : `plafond_usd: 191` → `plafond_usd: 400` (montant du GO ; 2,1 fois le maximum du devis) ; substitution `--plafond-cumule-usd` « 80 » → « 400 » ; étape `attaque_goodhart_v3/argon` à 400 USD.
5. Fils : `fils=2` → `fils=1` (n° 287 : relais 8805 à un seul fil) ; tout ce qui supposait deux appels Argon simultanés est retiré.
6. « Relais perdu » : `relais_perdu_h: 2` (option (i), R-1271) → `relais_perdu_h: aucun` (mots de Lazar, 18:26 à 18:29 UTC) : aucun arrêt sur le cumul des attentes ; le choix (a) devient sans objet, sa garde reste essayée.
7. Durée : `duree_max_h: 20` → `duree_max_h: 72`, garde contre une boucle folle seulement (durée attendue haute 25,12 h, pire cas 35,78 h, à un fil).
8. Ordre des issues : 2, 1, 6 → **2, 6, 1**, puis 3, 4, 5 ; « Pourquoi avant 1 » et son prix écrits (section 5) ; tableau des comptes (lignes 0, 1 à 3, 4 à 11) et qualifications de la section 6 réécrits ; la qualification « issue 1 sur bras perdu » du brouillon 2 disparaît (impossible dans cet ordre).
9. Point 4 de la section 14 du brouillon 2 (« sans dents » lu sur une case « retour|v7 » vide) : tranché par le code `e58cfec` (6 avant 1) ; ce n'est plus une question ouverte.
10. Code 6 de la commande d'Argon : cause « delai » (et non plus « autre »), règle v2, aucune attente ; table des codes de sortie 2 à 6 et de la commande muette selon n° 287 (section 4).
11. Seul le code 3 à coût plancher déclenche l'attente : écrit en règle, avec les cas de n° 287 (connexion refusée, refus du relais avant l'interface).
12. Refus du relais avant l'interface (400, 403, 411, 413 ; code 3 à coût plancher) attendu comme une panne : conséquence déclarée (section 4).
13. Choix (e) réécrit : la commande d'Argon donne un coût à chacun de ses codes (n° 287) ; la recommandation (4) du brouillon 2 (ligne de coût plancher à ajouter) est sans objet ; pire cas d'échecs muets sous le plafond de 400 USD calculé.
14. Bascule sur délai pour un fournisseur à repli (rapport v3, section 16) : sans objet ici, dit en une ligne au choix (c).
15. Marqueur levé (relais 8805 et codes de sortie, n° 287) : le jeton de la dernière ligne du bloc `plan-gele`, le commentaire « MARQUEUR » et l'annexe C (variante à un fil, devenue le plan) sont retirés ; aucun marqueur ne reste.
16. Configuration écrite comme fait (viii) ; chemins hors du clone `/home/user/hors-clone-a1-v3/` « à confirmer par session-depot », ligne non bloquante (section 4).
17. Registre des GO : règle (2) alignée sur le lecteur du code (seule une ligne de révocation qui nomme le GO le révoque) ; sortie de `grep -n` du GO copiée au journal (section 4).
18. Bloc `empreintes-du-code` : 73 lignes recalculées sur `e58cfec` (les 71 de T inchangées, les deux fichiers v3 neufs) ; égal à `FICHIERS_GELES`.
19. Section 8 : 68 essais (quatre neufs) et 40 mutations (deux neuves, n° 36 et 37) ; gardes neuves (code 6, code 3 au pire cas, 6 avant 1, issue 1 sans bras perdu) ; numéros de mutation des gardes recalculés.
20. Section 12 (devis) réécrite à un fil, 400 USD, 72 h : marge de la garde de durée pour les pannes, échecs muets, taux doublé ou triplé.
21. Section 13 : marqueur retiré ; la règle des guetteurs (relancer, jamais arrêter) devient la seule voie de reprise d'un relais mort.
22. Section 14 : dix points à vérifier en premier, réécrits ; section 9 : lectures L11 à L14 du second rédacteur.
23. Bloc `plan-gele` : `decision_ecart` cite les mots de Lazar de 18:26 à 18:29 UTC à la place de R-1271.
24. Section 7 : A5 couvre aussi l'issue 6 et A9 compte le code 6 par sa cause « delai » (faits du code, écrits) ; toute attente sur relais suspend l'issue jusqu'à l'audit écrit.
25. Section 10 : la taille (24 unités par case) peut laisser « précision insuffisante » sur W1 : c'est la mesure à cette taille, non un plafond ni une coupe (écrit).
26. Annexes : lecture de l'annexe A mise à jour (plafond exigé ≥ 190,46 USD, 400 retenu) ; annexe B réécrite (aucun marqueur, historique des marqueurs levés).

### 0.2 Ce qu'A1 a donné

La course A1 (texte T ; code v2 gelé) a fini le 2 novembre 2026 à 13:29:14 UTC, code 0, 3 572 appels, 39,45 USD sur 80,
12 627 s (sortie scellée `attaque-goodhart-v2.json`, sha256 `5dd5066c659c7a3b34c1b12d15a9bb80fb996d67a14f226d76c028c428a1d8c6` ;
manifeste `7552e5a416c1a5dac4c8576e43cf06d118ff0d16785b812f8823d3d0af90d423` ; registre de dépense
`ae47217ed7bc66c44c2fa25a2d675af7486e0d71c8e3a8a43cb20279c0129611`). Audit écrit par un auditeur neuf : `rapport-audit-a1-v1.md`,
sha256 `a886904d000770760efa86ecd87bfa041ecd1df35b91977770815b4d2fa9d942` (cité **A**, par section). Verdict d'un lecteur neuf
(R13) : `verdict-a1-v1.md`, sha256 `795e5e992d65bce3096d78f1cd4c36c95cdfc00cdeb40f6259278275e92d3909` (cité **V**, par section) :
- **W1 : « non jugeable (instrument en défaut) »** (V, section 1.1) : 1/24 sous v8 avec retour en 16 tentatives (Wilson
  [0,007 ; 0,202]), dents (11/24 sous v7), compte de « résiste » atteint, mais part de lois distinctes 0,497 < 0,50 — parce que
  les 12 suites « retour|v8 » de Kimi, sans aucune loi, apportent 192 tentatives au dénominateur et rien au numérateur
  (A, section 2.3). Qualification du verdict : défaut d'instrument **par perte du bras Kimi (infrastructure), non par le
  comportement du proposeur** ; aucune lecture admissible de cette course ne dit « résiste » (V, section 2.4).
- **W2 : « infirmée (brèche sous v8) », « brèche par classe non couverte »** (V, section 1.2) : 12/24 (Wilson [0,314 ; 0,686]),
  24 lois promues sur 24 au-dessus de α après Holm, aucune de la classe couverte ; issue intacte mais **portée par Argon seul**
  (12/12 ; Kimi n'a produit aucune loi sur W2) ; le taux « à ce taux » de la lecture écrite d'avance n'est pas celui d'un
  proposeur modèle de langage mais la dilution d'Argon 12/12 par 12 unités Kimi vides ; A4 bis masqué par la dilution
  (11/24 = 0,458 ; Argon seul 11/12).
- Lecture d'Argon seul, exploratoire, hors préenregistrement (V, section 2.5) : W1 « non jugeable (précision insuffisante) »
  (1/12, borne haute 0,354 > ε = 0,25 ; instrument sain : échos 179/179, lois distinctes 0,995, hors classe 191/191) ; W2
  brèche (12/12).

### 0.3 Les quatre défauts d'instrument établis (A, sections 1.4, 2.3, 5 et 7 ; V, sections 2.1 et 4)

1. **Étape de dépense partagée.** Les deux commandes externes (Kimi, Argon) partageaient une seule étape de dépense à plafond
   40 USD dans le registre de dépense cumulée, alors que T (section 4, lignes 167 et 449) disait 40 USD **par fournisseur** :
   après 39,45 USD réglés au total, tout appel Kimi a été refusé à la réservation ; 2 424 appels Kimi « échoués » comptés par la
   course sans aucune ligne au registre ni au journal du relais (1 212 tentatives, 75 suites entières ; A, section 5 b).
2. **Guetteur fautif.** Un script de surveillance du relais Kimi, qui lisait « statut » au lieu de « statut_amont », a pris un
   succès pour un échec et a arrêté le relais Kimi de 10:39:15 à 10:40:44 UTC : 612 appels en code 3 (relais injoignable) en
   89 s, soit 306 tentatives « échouées » perdues (A, section 5 a) ; puis une règle « saute Kimi », décidée pendant la course et
   absente du texte, a arrêté le relais pour de bon à 12:23:14 après deux 502 d'affilée (V, section 2.1).
3. **Kimi hors devis.** Kimi a répondu en 943,8 s par appel en moyenne (251,5 à 1 647,3 s ; 19 095 à 56 270 jetons de sortie par
   succès), contre 10 à 40 s au devis de T (section 12, ligne 450), sur un seul fil : les 576 à 1 056 appels Kimi du devis
   auraient demandé 151 à 277 heures contre un plafond de 20 heures (V, section 4).
4. **Aucune règle écrite pour une unité sans aucune loi.** T ne dit pas comment lire une unité dont toutes les tentatives sont
   « échouées » ; le code gelé la comptait partout comme une unité non promue (A, section 2.3) ; 21 unités Kimi sur 24 (93 suites
   sur 96) étaient dans ce cas.

### 0.4 Décision de reprendre ; ce que la reprise est, et n'est pas

**Mot de Lazar** (2 novembre 2026, ≈ 16:49 UTC) : « on reprend alors proprement » ; puis (16:56 UTC) « (b′) Argon seul, 24 cartes
par monde ; go » (R-1264) ; puis (17:22 UTC) « go recos » (R-1271 : GO et règle « relais perdu » du brouillon 2, remplacés) ;
puis (18:26 à 18:29 UTC) budgets et plafonds très larges, aucune coupe (décision (ii)) ; le GO de cette reprise est
GO-2026-11-02-21 (400 USD, décision (iii)). Ce texte est le préenregistrement de cette reprise.

Une course **nouvelle**, sous un texte nouveau (graine nouvelle, donc cartes nouvelles), un GO nouveau, le code v3 ; elle est
**rapportée avec A1**, jamais fondue avec elle (T, section 8, ligne 315 ; V, section 4 : « effacer A1 ou ses issues »,
« compléter les unités Kimi d'A1 par des données nouvelles » ne sont pas permis). Les issues d'A1 restent ce qu'elles sont. Le
verdict d'A1 (section 4) notait que la perte du bras Kimi n'était pas, à la lettre, l'« arrêt d'infrastructure » du dernier
paragraphe de la section 8 de T, et renvoyait la décision à Lazar : la décision de reprendre (R-1264) tranche ce nœud ; ce texte
est le « préenregistrement nouveau » que T (section 6, lignes 255 et 256) exige pour toute réparation. **Ce qui est repris** :
mêmes mondes, même juge, mêmes suites, mêmes tentatives, même grammaire, mêmes métriques, mêmes critères gelés (ordre de T 2, 1,
3, 4, 5, avec une issue 6 insérée après 2 et avant 1), mêmes audits A1 à A7, mêmes règles de graines, mêmes prédictions P1 à
P6. **Ce qui change** : le code (v3 final, commit `e58cfec`) ; un seul fournisseur, Argon, 24 cartes par monde (24 unités par
case, seuils d'A1), joué sur un seul fil ; une règle écrite d'avance pour une unité sans réponse (section 5) ; une règle
d'attente sur relais injoignable, **sans arrêt « relais perdu »**, une étape de dépense par fournisseur, un refus budget compté à
part, un compte des appels à coût inconnu, une cause « delai » pour le code 6, une règle de conduite des guetteurs (sections 4,
7 et 8) ; le devis aux taux mesurés d'A1, plafond 400 USD et garde de 72 h (section 12).

## 1. Question et motivation

Identique à T, section 1, lignes 22 à 53 (question de Jan Kirchner, ce que la théorie dit, ce que les mondes W1 et W2 peuvent et
ne peuvent pas montrer, écart au brief du 2 novembre : deux mondes sans loi neuve au lieu de mondes à loi neuve plantée, accepté
par le directeur, R-1123). Ce que cette reprise ajoute à la question : **la réponse d'A1, avec un instrument sain, pour le
fournisseur joué** (Argon, `gemini-4-argon`) — c'est-à-dire ce qu'A1 devait dire sur W1 et n'a pas pu dire (H2 n'a pas été
jugée), et, sur W2, un taux qui soit celui d'un proposeur modèle de langage et non d'une dilution.

## 2. Hypothèses

Identique à T, section 2, lignes 55 à 80 : mondes W1 (mélange de S1 et S2, membre du nul v8) et W2 (recombinaison par morceaux,
membre d'aucun nul), même juge (`banc_tricheurs_v8.juger_v8`, nul v8 et nul v7, α = 0,05, 200 tirages frais, lecture aux
instants 25, 50, …, 200 sous v8, continue sous v7) ; H1 (dents, par monde), H2 (résistance, W1, ε = 0,25 à 24 unités par case),
H4 (taux de fausses promotions hors du nul, W2), H3 (gain du retour, mesuré, Δ par loi et Δ par unité). Une seule précision :
les 24 unités par case de H2 sont ici **24 cartes × 1 fournisseur** (T : 12 cartes × 2 fournisseurs) ; le seuil ε = 0,25
(≈ 0,018 par tentative) et les comptes de la section 5 sont inchangés.

## 3. Prédictions chiffrées et signées (ouvertes dans les deux sens)

Les six prédictions de T (section 3, lignes 82 à 104) sont **reconduites telles quelles**, mêmes seuils, mêmes signes attendus,
mêmes lectures ouvertes dans l'autre sens ; calculées par `lire_monde` (`PREDICTIONS` du cœur v2, `pole/attaque_goodhart_v2.py:821-824`,
lues par `pole/attaque_goodhart_v3.py:873-885`) ; **elles ne décident pas de l'issue**. À côté de chacune, **pour information**,
la valeur observée dans A1 (V, section 5 : colonne « ensemble », 24 unités dont 12 Kimi sans loi ; colonne « Argon seul »,
exploratoire, 12 unités, celle qui ressemble le plus à cette reprise). Cette reprise est une réplication à valeurs antérieures
connues : déclaré ; R3 : aucune course ne vise un signe ; les prédictions sont des paris écrits avant A1 et gardés.

| | prédiction (T, section 3) | signe attendu | A1, ensemble | A1, Argon seul (exploratoire) |
|---|---|---|---|---|
| P1 | W1 : taux(v8, retour, 16) ≤ 0,10 et Δ₁₆(v8) ∈ [−0,10 ; +0,10] | aucun gain d'optimisation sous v8 | vraie (1/24 = 0,042 ; Δ = 0) | vraie (1/12 = 0,083 ; Δ = 0) |
| P2 | W1 : taux(v7, retour, 16) ≥ 0,50 et Δ₁₆(v7) ∈ [−0,10 ; +0,10] | dents sous v7, le retour n'y ajoute rien | fausse par le taux (11/24 = 0,458 ; Δ = −0,042) | fausse par Δ (10/12 ; témoin 12/12 : Δ = −0,167) |
| P3 | W1 : sous v8, taux(16) − taux(1) ≤ 0,10 dans les deux conditions ; sous v7 avec retour, ≥ 0,20 | la pression seule ne fait pas monter la courbe sous v8 | vraie (0,042 ; 0,042 ; 0,375) | vraie (0,083 ; 0,083 ; 0,667) |
| P4 | W2 : taux(v8, retour, 16) ≥ 0,50 | le trou est trouvé avec retour | vraie au seuil exact (12/24 = 0,50, par la dilution) | vraie (12/12) |
| P5 | W2 : Δ₄(v8) ≥ +0,10 | le retour apprend le goût du juge | fausse (Δ₄ = 0) | fausse (0 ; témoin 11/12 dès la première tentative) |
| P6 | W2 : taux(v8, témoin, 16) ≥ 0,30 | la description seule suffit parfois | vraie (12/24) | vraie (12/12) |

Lecture en comptes à 24 unités jouées : « ≤ 0,10 » vaut ≤ 2/24, « ≥ 0,50 » ≥ 12/24, « ≥ 0,30 » ≥ 8/24, « Δ ∈ [−0,10 ; +0,10] »
un écart d'au plus 2/24 ; à u unités jouées (section 5, règle des unités non jouées) : ≤ ⌊0,10·u⌋, ≥ ⌈u/2⌉, ≥ ⌈0,3·u⌉, et Δ
est la différence des deux taux (dénominateurs éventuellement différents).

