"""Noms exacts au commit e58cfec (contenu tiré par git show, analyse syntaxique, rien n'est exécuté) : les 40 mutations du banc
v3 (libellé, fichier, fonction mutée, essai qui la tue), les essais v3 (68) et v2 (45), classe par classe. Lecture seule."""
import ast
import json
import subprocess

DEPOT = "/home/claude/ideation-organism"
COMMIT = "e58cfec936461a72a173c667e91755582e04bcb8"


def show(p):
    return subprocess.run(["git", "-C", DEPOT, "show", f"{COMMIT}:orchestrator/{p}"], capture_output=True, check=True, text=True).stdout


arbre = ast.parse(show("essais/mutations_attaque_goodhart_v3.py"))
mut = next(n.value for n in arbre.body if isinstance(n, ast.Assign) and any(getattr(t, "id", "") == "MUTATIONS" for t in n.targets))
cibles = {"A3": "pole/attaque_goodhart_v3.py", "L": "demonstrations/attaque_goodhart_v3.py"}
lignes = []
for k, e in enumerate(mut.elts, 1):
    essais = [x.right.value for x in e.elts[5].elts]
    lignes.append({"n": k, "libelle": e.elts[0].value, "cible": cibles[e.elts[1].id], "fonction": e.elts[2].value, "essais": essais})
json.dump(lignes, open("mutations-b3.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
with open("mutations-b3.md", "w", encoding="utf-8") as f:
    f.write("| n° | mutation (libellé exact du banc) | fichier, fonction mutée | essai qui la tue |\n|---|---|---|---|\n")
    for m in lignes:
        f.write(f"| {m['n']} | {m['libelle']} | `{m['cible']}`, `{m['fonction']}` | " + ", ".join(f"`{x}`" for x in m["essais"]) + " |\n")
print(len(lignes), "mutations")


def essais(p):
    a = ast.parse(show(p))
    sortie = {}
    for n in a.body:
        if isinstance(n, ast.ClassDef):
            m = [x.name for x in n.body if isinstance(x, ast.FunctionDef) and x.name.startswith("test_")]
            if m:
                sortie[n.name] = m
    return sortie


v3 = essais("essais/test_attaque_goodhart_v3.py")
v2 = essais("essais/test_attaque_goodhart_v2.py")
json.dump({"v3": v3, "v2": v2}, open("essais-b3.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("v3 :", sum(map(len, v3.values())), "essais en", len(v3), "classes ; v2 :", sum(map(len, v2.values())), "essais en", len(v2), "classes")
for c, ms in v3.items():
    print(f"  {c} ({len(ms)}) : " + ", ".join(ms))
with open("essais-v2-b3.md", "w", encoding="utf-8") as f:
    for c, ms in v2.items():
        f.write(f"- `{c}` : " + ", ".join(f"`{x}`" for x in ms) + "\n")
