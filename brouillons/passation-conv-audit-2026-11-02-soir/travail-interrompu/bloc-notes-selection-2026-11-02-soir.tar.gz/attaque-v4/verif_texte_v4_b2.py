"""L6 : le bloc plan-gele du brouillon 1 v4 lu par lire_plan du lanceur v4 (jeton de configuration remplacé par une empreinte
factice) ; le texte complet lu par lire_preenregistrement (scellement simulé dans un dossier temporaire hors du dépôt) : refusé pour
ses jetons, accepté une fois les jetons remplacés (empreintes de l'arbre de travail). Aucun .sha256 dans le dépôt."""
import importlib.util, os, sys, tempfile, unittest.mock
R = sys.argv[1]
sys.path.insert(0, R)
s = importlib.util.spec_from_file_location("l4", os.path.join(R, "demonstrations", "attaque_goodhart_v4.py"))
l4 = importlib.util.module_from_spec(s); s.loader.exec_module(l4)
from pole.outils import ecrire_scelle, sha256_fichier
t = open(os.path.join(R, "prereg", "preenregistrement-attaque-goodhart-v4-brouillon2.md"), encoding="utf-8").read()
print("jetons :", sorted(set(l4.MARQUEUR.findall(t))))
faux = "f" * 64
p = l4.lire_plan(t.replace("<<CASE_CONFIGURATION>>", faux))
print("lire_plan (configuration factice) : accepté ;", {k: p[k] for k in ("cartes", "unites_par_case", "eps", "mondes", "plafond_usd", "relais_perdu_s", "go", "rejeux", "rejeux_audit")},
      "fils", p["fournisseurs"][0]["fils"], "devis usd_max", p["devis"]["total"]["usd_max"], "durée haute", p["devis"]["total"]["duree_attendue_haute_h"],
      "pire", p["devis"]["total"]["duree_max_h"])
try:
    l4.lire_plan(t)
    print("ERREUR : jeton de configuration accepté par lire_plan")
except l4.PreenregistrementRefuse as e:
    print("lire_plan avec le jeton : refus attendu :", str(e)[:90])
bloc = "".join(f"{sha256_fichier(os.path.join(R, r))}  {r}\n" for r in l4.FICHIERS_GELES)
with tempfile.TemporaryDirectory() as d:
    with unittest.mock.patch.object(l4, "DOSSIER_PREREG", d):
        c1 = os.path.join(d, "preenregistrement-attaque-goodhart-v4-v1.md"); ecrire_scelle(c1, t)
        try:
            l4.lire_preenregistrement(c1); print("ERREUR : texte à jetons accepté")
        except l4.PreenregistrementRefuse as e:
            print("texte à jetons : refus attendu :", str(e)[:110])
        c2 = os.path.join(d, "preenregistrement-attaque-goodhart-v4-v2.md")
        ecrire_scelle(c2, t.replace("<<CASE_CONFIGURATION>>", faux).replace("<<EMPREINTES_AU_COMMIT>>\n", bloc))
        e, h, gel, q = l4.lire_preenregistrement(c2)
        print("jetons remplacés (simulation) : accepté ;", len(gel), "fichiers gelés ; entropie ≥ 2^64 :", e >= 2 ** 64)
