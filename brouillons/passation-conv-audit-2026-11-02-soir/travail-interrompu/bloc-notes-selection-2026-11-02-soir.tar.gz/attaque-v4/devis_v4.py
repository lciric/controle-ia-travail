"""Devis et tables de lecture de l'attaque v4 (plan décidé : Argon seul, 1 fil, 24 cartes par monde, W1 et W2)."""
import json, sys
sys.path.insert(0, sys.argv[1])
from pole import attaque_goodhart_v4 as a4, attaque_goodhart_v2 as ag
argon = {"nom": "argon", "type": "commande_externe", "port": 8805, "modele": "gemini-4-argon", "fils": 1, "taux_usd": 0.062, "secondes": (7.6, 40.0)}
d = a4.devis(24, ["W1", "W2"], [argon])
print(json.dumps(d["total"], indent=1, ensure_ascii=False))
# attendu aux taux mesurés d'A1 (W1 ≈ 39,7 appels par unité ; W2 sous v9 ≈ 32 + 2) à 7,6 s
appels = 24 * 39.7 + 24 * 34
print("attendu mesuré :", round(appels), "appels,", round(appels * 0.062, 1), "USD,", round(appels * 7.6 / 3600, 2), "h d'appels")
print("règles 24 :", a4.regles_de_lecture(24, 0.25), "wilson(0,24) =", [round(x, 4) for x in ag.wilson(0, 24)], "wilson(1,24) =", [round(x, 4) for x in ag.wilson(1, 24)])
for u in (24, 23, 22, 21, 20, 19, 18, 16, 14, 12):
    r, b = a4.regles_de_lecture(u, 0.25)
    print(u, r, b, [a4.probabilites_issue(u, 0.25, p) for p in (0.02, 0.05, 0.10, 0.20, 0.30)])
print("plafond multiplicité 16 :", round(1 - 0.95 ** 16, 4))
