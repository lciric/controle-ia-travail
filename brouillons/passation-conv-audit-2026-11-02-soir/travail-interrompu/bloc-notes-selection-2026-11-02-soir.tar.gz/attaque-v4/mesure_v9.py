"""Mesure à blanc : durée d'une évaluation sous v9 (apparié ou non) sur les lois du proposeur « sortant_v9 » et les lois des mondes."""
import sys, time, json
sys.path.insert(0, sys.argv[1])
from pole import attaque_goodhart_v4 as a4, attaque_goodhart_v2 as ag
res = {}
for w in ("W1", "W2"):
    c = a4.carte(7, 0, w)
    lois = a4.candidats_hors_classe_v9(c["L"]["S1"], c["L"]["S2"]) + [c["monde"]]
    for ap in (False, True):
        d = time.perf_counter(); vs = []
        for k, loi in enumerate(lois):
            vs.append(a4.juger(loi, c, "v9", 7, f"{w}|argon|retour|v9", k + 1, apparie=ap))
        dt = (time.perf_counter() - d) / len(lois)
        res[f"{w}|apparie={ap}"] = {"s_par_eval": round(dt, 3), "promues": sum(v["promue"] for v in vs),
                                    "impossibles": sum(v["statut"] != "promue" and v["statut"] != "non_promue" for v in vs),
                                    "log_w_max": [round(v["log_w_max"], 2) if v["log_w_max"] is not None else None for v in vs]}
    va = a4.juger(c["monde"], c, "ancien", 7, f"{w}|argon|retour|ancien", 1)
    res[f"{w}|ancien"] = {"nul": va["nul"], "promue": va["promue"], "log_w_max": round(va["log_w_max"], 2)}
    res[f"{w}|couverte_monde"] = a4.structurellement_couverte(c["monde"], c["L"])
    res[f"{w}|hors_classe_candidats"] = sum(not a4.structurellement_couverte(l, c["L"]) for l in lois[:-1])
print(json.dumps(res, indent=1))
