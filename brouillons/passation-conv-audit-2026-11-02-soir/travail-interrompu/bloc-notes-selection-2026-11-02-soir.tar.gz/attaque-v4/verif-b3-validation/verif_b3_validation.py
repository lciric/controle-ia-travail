"""L10 du brouillon 3 de la validation du v9 : le texte, scellé dans un dossier temporaire hors du dépôt sous un nom décisif, est
accepté par `lire_preenregistrement` du banc v9 corrigé (14 fichiers gelés = FICHIERS_GELES, empreintes égales à l'arbre) ; le
même texte avec l'ancienne empreinte du banc (c7ab5470…) est refusé. Aucun .sha256 dans le dépôt."""
import importlib.util, os, sys, tempfile, unittest.mock
R = sys.argv[1]
sys.path.insert(0, R)
spec = importlib.util.spec_from_file_location("b9", os.path.join(R, "demonstrations", "banc_tricheurs_v9.py"))
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
from pole.outils import ecrire_scelle
texte = open(os.path.join(R, "prereg", "preenregistrement-validation-nul-v9-brouillon3.md"), encoding="utf-8").read()
print("durée gelée du banc :", b.DUREE_MAX_S)
with tempfile.TemporaryDirectory() as d:
    pr = os.path.join(d, "prereg"); os.makedirs(pr)
    with unittest.mock.patch.object(b, "DOSSIER_PREREG", pr):
        c = os.path.join(pr, "preenregistrement-validation-nul-v9-v1.md"); ecrire_scelle(c, texte)
        e, emp, gel = b.lire_preenregistrement(c)
        print("brouillon 3 (scellement simulé) : accepté ;", len(gel), "fichiers ; égal à FICHIERS_GELES :", set(gel) == set(b.FICHIERS_GELES), "; entropie ≥ 2^64 :", e >= 2 ** 64)
        c2 = os.path.join(pr, "preenregistrement-validation-nul-v9-v2.md")
        ecrire_scelle(c2, texte.replace("7e4bff5995df2a7d62a4f5a2f5f9176da614e657a55b05183325fa2fc6e24e44  demonstrations/banc_tricheurs_v9.py",
                                        "c7ab547065180b6e23e0e496d9c9dc96b674ed4c1b47766b3e108709fdbcf466  demonstrations/banc_tricheurs_v9.py"))
        try:
            b.lire_preenregistrement(c2); print("ERREUR : ancienne empreinte du banc acceptée")
        except b.EcartAuPlan as x:
            print("ancienne empreinte du banc : refus attendu :", str(x)[:110])
