"""Résumé d'une sortie à blanc v4 : issues, comptes clés, instrument, audits, appels, durées, empreintes."""
import hashlib, json, os, sys
d = sys.argv[1]
r = json.load(open(os.path.join(d, "attaque-goodhart-v4.json"), encoding="utf-8"))
h = lambda p: hashlib.sha256(open(os.path.join(d, p), "rb").read()).hexdigest()
print("sortie", h("attaque-goodhart-v4.json"), "manifeste", h("manifeste.json"))
print("appels", r["appels"], "reprises", r["reprises"], "depense", r["depense_usd"], "duree_s", r["duree_s"], "fin", r["fin_utc"])
for w, m in r["lecture"]["mondes"].items():
    t = m["taux"]
    k = lambda j, c, n: f'{t[f"{j}|{c}|n={n}|ensemble"]["promues"]}/{t[f"{j}|{c}|n={n}|ensemble"]["unites"]}'
    i = m["instrument_v9_retour"]
    print(f"{w} ({m['juge_ancien']}) : issue « {m['issue']} » ; suspendue {m['issue_suspendue_par_audit']} ; v9 retour 16 {k('v9','retour',16)}, "
          f"témoin 16 {k('v9','temoin',16)} ; ancien retour 16 {k('ancien','retour',16)}, témoin 1 {k('ancien','temoin',1)} ; "
          f"échos {i['part_echos_exacts']}, lois distinctes {i['part_lois_distinctes']}, hors classe {i['part_hors_classe']} ; "
          f"monotonie {m['violations_de_monotonie']} ; v9 promues sous v8 apparié {m['tentatives_v9_promues_sous_v8_apparie']} ; "
          f"évaluations impossibles {m['evaluations_impossibles']} ; prédictions {m['predictions']}")
    print("   audits :", [a[:60] for a in m["audits"]])
rj = r["rejeux"]
print("rejeux :", len(rj), "lois ; sous v9 :", sum(x["juge"] == "v9" for x in rj), "dont promues ≥ 1 :", sum(x["juge"] == "v9" and x["promues"] > 0 for x in rj),
      "; promotions v9 rejouées :", sum(x["promues"] for x in rj if x["juge"] == "v9"), "/", sum(x["rejeux"] for x in rj if x["juge"] == "v9"),
      "; audit A2 :", len(r["audit_A2"]))
lw = [t_["verdict"]["log_w_max"] for s in r["suites"] if s["juge"] == "v9" for t_ in s["tentatives"] if t_["verdict"] and t_["verdict"]["log_w_max"] is not None]
print("log W max sous v9 (verdicts en course) : n =", len(lw), "max =", round(max(lw), 3) if lw else None, "; > 0 :", sum(x > 0 for x in lw))
