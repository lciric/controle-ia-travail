"""Course à blanc A : la loi rejouée 1/2 sous v9 (A3 à 2 rejeux) est rejouée 200 fois sous v9 (étiquette « audit-blanc|… »,
graine exploratoire de la course), comme le ferait l'audit : taux, borne de Clopper-Pearson, type de la loi, classe."""
import json, os, sys
sys.path.insert(0, sys.argv[1])
from pole import attaque_goodhart_v4 as a4, attaque_goodhart_v2 as ag
r = json.load(open(os.path.join(sys.argv[2], "attaque-goodhart-v4.json"), encoding="utf-8"))
G = 20261102
for x in r["rejeux"]:
    if x["juge"] == "v9" and x["promues"] > 0:
        s = next(s for s in r["suites"] if s["monde"] == x["monde"] and s["carte"] == x["carte"] and s["juge"] == "v9"
                 and a4.etiquette_suite(s["monde"], s["fournisseur"], s["condition"], s["juge"]) == x["etiquette"])
        t = next(t for t in s["tentatives"] if t["k"] == x["k"])
        c = a4.carte(G, x["carte"], x["monde"])
        print("rejeu :", {k: x[k] for k in ("monde", "carte", "etiquette", "k", "promues", "rejeux")}, "; verdict en course log W", round(t["verdict"]["log_w_max"], 3),
              "; type", t["loi"]["type"], "; couverte", a4.structurellement_couverte(t["loi"], c["L"]))
        res = a4._rejouer_loi((G, x["monde"], x["carte"], x["etiquette"], x["k"], t["loi"], "v9", 200, "audit-blanc"))
        b = ag.banc()
        print("200 rejeux sous v9 :", res["promues"], "/ 200 ; Clopper-Pearson 95 % unilatérales", [round(v, 4) for v in b.clopper_pearson(res["promues"], 200)],
              "; évaluations impossibles", res["evaluations_impossibles"])
