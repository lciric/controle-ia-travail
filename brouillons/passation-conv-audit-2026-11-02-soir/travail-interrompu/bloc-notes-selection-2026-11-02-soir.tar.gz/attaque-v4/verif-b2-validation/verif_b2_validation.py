"""Vérifie, hors du dépôt, que le banc v9 refuse le brouillon 2 de la validation tant que le jeton est là, et l'accepte une fois
le jeton remplacé (scellement simulé dans un dossier temporaire ; aucun .sha256 dans le dépôt)."""
import importlib.util, os, sys, tempfile, unittest.mock
RACINE = sys.argv[1]
sys.path.insert(0, RACINE)
spec = importlib.util.spec_from_file_location("b9", os.path.join(RACINE, "demonstrations", "banc_tricheurs_v9.py"))
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
from pole.outils import ecrire_scelle, sha256_fichier
texte = open(os.path.join(RACINE, "prereg", "preenregistrement-validation-nul-v9-brouillon2.md"), encoding="utf-8").read()
with tempfile.TemporaryDirectory() as d:
    pr = os.path.join(d, "prereg"); os.makedirs(pr)
    with unittest.mock.patch.object(b, "DOSSIER_PREREG", pr):
        c = os.path.join(pr, "preenregistrement-validation-nul-v9-v1.md"); ecrire_scelle(c, texte)
        try:
            b.lire_preenregistrement(c); print("ERREUR : accepté avec le jeton")
        except b.EcartAuPlan as e:
            print("avec le jeton : refus attendu :", str(e)[:120])
        h = sha256_fichier(os.path.join(RACINE, "demonstrations", "banc_tricheurs_v9.py"))
        c2 = os.path.join(pr, "preenregistrement-validation-nul-v9-v2.md")
        ecrire_scelle(c2, texte.replace("<<EMPREINTE_DU_BANC_CORRIGE>>", h))
        e, emp, gel = b.lire_preenregistrement(c2)
        print("jeton remplacé (banc du commit, simulation) : accepté,", len(gel), "fichiers gelés, égal à FICHIERS_GELES :", set(gel) == set(b.FICHIERS_GELES))
