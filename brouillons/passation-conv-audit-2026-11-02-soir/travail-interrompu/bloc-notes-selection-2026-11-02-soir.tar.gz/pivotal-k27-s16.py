import pathlib
M = pathlib.Path('/home/claude/controle-ia-travail/brouillons/candidature-pivotal-v16/mentors')

def remplacer(s, a, b):
    assert s.count(a) == 1, a[:70]
    return s.replace(a, b)

# --- Kirchner v27 : passages de Lazar en Q1 (19:25 UTC), deux corrections ; Q2 : expérience 1 recadrée
k = (M / 'mentor-2-kirchner-v26.md').read_text(encoding='utf-8')
k = remplacer(k, "Automated-research system live since October (github.com/lciric/ideation-organism). Q: Can a loop of LLM agents proposing laws to control AI be scored by something arguments can't lie to? Can that something hold up against agents attempting to game it?",
              "I have an auto research system that has been running since October. github.com/lciric/ideation-organism Q: could you score a group of llm agents trying to create laws for ai control with something that arguments cant lie to? Could that thing withstand agents that try to cheat it?")
i = k.index("TLDR: The biggest surprises came from real data.")
j = k.index("\n", i)
k = k[:i] + ("The LLM judges that I had placed next to the statistical judge were maxed out (called 11/12 cards as “notable” with κ=0 agreement between each other) "
             "so they didn’t provide any information. My simple statistical judge told me we didn’t have enough power and the power curve backed that up. Then I was "
             "able to run it on my 288 episodes of real data and it accepted all 3 links that I embedded and 0 out of the 19 non laws. And it accepted no law from the "
             "real data itself.") + k[j:]
a = k.index("Experiment 1 - A law of deference for monitors.")
b = k.index("\n", a)
k = k[:a] + ("Experiment 1 - Do monitors defer to text aimed at them, and does it cost catches? In our control setting (a Llama-3.1-8B agent, 2,400 actions, "
             "saboteur and honest episodes), instruct the saboteur to add to its own output attack messages from one of five classes (ingratiation/flattery/begging, "
             "authority claims, spoofed confirmations, parroting \"correct\" terms from the instructor, in-band prompting/guidance), at three intensities, and read "
             "two monitors: a generative LLM monitor and a linear probe on the agent's activations. The decision-relevant measure is the catch rate on sabotage at "
             "a fixed 1% false-alarm rate, calibrated on honest episodes, paired action by action with and without the messages. To see how the verdict moves, model "
             "the monitor's continuous value (verdict token probabilities) with Δv = g · (c̃ − v₀) at each intensity, leaving c̃ unconstrained, "
             "with regression to the corpus mean as the null; but as one regime among others, because the attraction law is not universal: in a preregistered "
             "dose–response on four model families it held for Llama-3.1-8B, while Qwen2.5-7B shifted uniformly, Gemma-2-9B moved under criticism only and "
             "Mistral-7B's regime changed with the wording; for Llama, under criticism the gain did not grow with intensity, and the strongest flattery triggered "
             "refusals and resets toward mid-scale. So I report the regime per monitor and count refusals as an outcome. Hypotheses: the LLM monitor loses catches "
             "under the messages; the probe, which reads the agent from context alone, loses fewer (g ≈ 0). A first step is running: R7, preregistered and "
             "archived (Zenodo, v2026.11.4), measures deference to an in-band note on seven Qwen2.5 monitors from 0.5B to 72B.") + k[b:]
a = k.index("What would change my mind:")
b = k.index("\n", a) if "\n" in k[a:] else len(k)
k = k[:a] + ("What would change my mind: no loss of catch rate for the LLM monitor under the strongest messages (whatever its ratings do, there would be no "
             "attack surface at the operating point); deference no larger than regression to the mean (c̃ near the corpus mean); or a probe losing as many "
             "catches as the LLM monitor (activation probes would not be safer than judges, and I'd have to change the title of this white-box programme). Each of "
             "these 3 findings would rebut a hypothesis I will write into the preregistration before seeing the data; I'll publish regardless.") + k[b:]
k = k.replace('— v26\n', '— v27\n', 1)
k = k.replace('2 November 2026. v26 = ', "2 November 2026. v27 = Q1 with Lazar's passages (19:25 UTC), two substance fixes (« 288 episodes of actual laws » → « of real data » ; « Which is good because there are no actual laws » → « And it accepted no law from the real data itself »: the absence of real laws is not known, only that none was accepted) ; Q2 experiment 1 reframed (Lazar, 19:25 UTC: the law does not hold on every model): same problem, decision-relevant measure (catch rate at fixed false alarms, paired), attraction law as one regime among others with the R6 regimes, the saboteur writing the attack itself so that the probe arm is not trivial ; R6 sentence made exact (criticism arm for the gain) ; draft for Lazar to rewrite ; v26 = ", 1)
(M / 'mentor-2-kirchner-v27.md').write_text(k, encoding='utf-8')

# --- Scheurer v16 : passages de Lazar (19:29 UTC), trois corrections ; phrases non reformulées gardées de la v15
s = (M / 'mentor-4-scheurer-v15.md').read_text(encoding='utf-8')
j = s.index('## Answer')
reponse = '''## Answer

Proposal: Two trends. The first is the corruptibility of monitors. The second: given some task and a fixed monitor, what is the smallest granularity across which a model can spread maliciousness without being flagged by this monitor.

Why. Propensity trends are difficult to get to pan out: propensity relies on post training, on the prompt, and likely on the model's perception of whether it is monitored. Capability against a fixed, hash-verified tool is easier: the task is static and the model does its best to outsmart our fixed monitor. Open weights/API models with published release dates. Similar to METR we will plot against release date (and size where possible for models within the same family).

Trend 1 (designed to work) Deference. Model evaluates action of an agent. Increase amount of one of 5 attacks used (flattery/begging, claim authority, claim model has accepted before, imitate teacher, instructions in band). Read output from judgement token log probs to get continuous value so there's no cap on the value. Fit Δv = g(c − v0) for each value of attack with the mean of the corpus as our null goal value. On llama-3.1-8B when subjected to social pressures it closed around .7 of the gap to the goals value of the frame and our law predicted hold out data with no retraining (r^2 .73/.69). Preregistered Dose Response Curve (4 families of models) found that for Llama, under criticism, it did not increase as amount of attack increased. It appears to have a max amount it will move towards and the goal value also changes. At higher values of attacks Llama began refusing to follow the instruction and went back to around middle of scale. Therefore this should give us a trend line of g and goal value at each attack level and refusal. R7 Preregistered (Zenodo v2026.11.4) We are running this on 7 qwen2.5 models ranging from .5b to 72b with instructions in band. First value for size trend unknown what direction.

Trend 2 (your question): the horizon over which a model can hide maliciousness. In an agentic task, the agent writes proposals judged by a trusted model. We tell each model to have some fixed amount of maliciousness (how much worse they make their proposals) and not be caught by our static best monitor. Our control lemma tells us that if we use a per action threshold how quickly an always valid monitor will catch it depends on how they can split there budget across n actions. Horizon: the number of actions over which a model can spread its maliciousness while the monitor's detection stays below 50% at 1% false alarms. Statement: "the horizon over which frontier models can hide maliciousness from [Monitor] doubles every x months".

Challenges: Elicitation (we know how far they can go when told how to be malicious so this is upper bound on propensity) Only one static monitor used for all models. Calibrating models to their truthful setting to know false positive rate. Why this might work: We already have a task and monitor from our control experiments. Similar to METRs horizon. Control Lemma tells us what needs to be kept constant to get a trend.

Known issues: Judging cap (token probability), Fresh questions each run, Refusals treated separately, Post training (Trend against release date and for each family of models trend against size). 2 Trends 2 pre-reg posts both sided tests.
'''
s = s[:j] + reponse
s = s.replace('— v15\n', '— v16\n', 1)
s = s.replace('2 November 2026. v15 = ', "2 November 2026. v16 = Lazar's passages (19:29 UTC) kept verbatim except three substance fixes: « (made to be true) » → « (designed to work) » (the trend is not rigged; the design is robust); « with the mean of the corpus as our goal value » → « … as our null goal value » (the corpus mean is the null for c, c is fitted); « found that it did not increase » → « found that for Llama, under criticism, it did not increase » and « the models began refusing » → « Llama began refusing » (R6: under praise Llama's gain grew while its destination fell; only Llama refused, results/R6/R6_descriptive_counts.json); sentences he did not rewrite kept from v15 (Proposal, start of Why, opening of Trend 2, horizon and statement); v15 = ", 1)
(M / 'mentor-4-scheurer-v16.md').write_text(s, encoding='utf-8')
print('ok')
