"""Construit prereg/preenregistrement-validation-nul-v9-brouillon4.md depuis le brouillon 3 : (1) les 23 couples de la
contre-lecture R2 n° 1 qui s'appliquent tels quels, dans l'ordre du fichier ; (2) les 15 couples d'I7 refaits sur le texte du
brouillon 3 ; (3) mises à jour d'état (B1, I5, I6, I2 levés) et mineurs ; (4) section 0 ter. Chaque remplacement vérifie que son
« ancien » est présent exactement une fois."""
import hashlib, json, os, re, sys
R = sys.argv[1]
src = os.path.join(R, "prereg", "preenregistrement-validation-nul-v9-brouillon3.md")
dst = os.path.join(R, "prereg", "preenregistrement-validation-nul-v9-brouillon4.md")
t = open(src, encoding="utf-8").read()
H = lambda p: hashlib.sha256(open(os.path.join(R, p), "rb").read()).hexdigest()
h_nul, h_test, h_mut = H("pole/nul_v9.py"), H("essais/test_nul_v9.py"), H("essais/mutations_nul_v9.py")
h_banc = H("demonstrations/banc_tricheurs_v9.py")
assert h_banc == "7e4bff5995df2a7d62a4f5a2f5f9176da614e657a55b05183325fa2fc6e24e44"
journal = []


def rep(old, new, etiquette):
    global t
    n = t.count(old)
    assert n == 1, (etiquette, n, old[:90])
    t = t.replace(old, new)
    journal.append(etiquette)


# (1) les 23 couples applicables tels quels, dans l'ordre du fichier
couples = json.load(open(os.path.join(R, "prereg", "couples-contre-lecture-validation-nul-v9-v1.json"), encoding="utf-8"))
tels_quels = [7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 25, 26, 29, 30, 34, 36]
for i, c in enumerate(couples, 1):
    if i in tels_quels:
        rep(c["ancien"], c["nouveau"], f"T{i:02d} tel quel")

# (2) les 15 couples d'I7 refaits sur le brouillon 3
rep("# Préenregistrement — validation décisive du nul v9 du juge (banc des tricheurs v9), brouillon 3",
    "# Préenregistrement — validation décisive du nul v9 du juge (banc des tricheurs v9), brouillon 4", "titre")
rep("""**Statut : brouillon 3, non contre-lu, non scellé ; aucun marqueur ni jeton.** Brouillon 2 rédigé le 2 novembre 2026, de 18:51
à 18:55 UTC (`date -u`) ; brouillon 3 (le seul changement est la section 0 bis : la correction du banc faite par le directeur,
commit `e58cfec`, et le bloc d'empreintes complété) de 19:14 à 19:20 UTC ; tous deux par un""",
    """**Statut : brouillon 4 — contre-lu (R2 n° 1, `prereg/contre-lecture-preenregistrement-validation-nul-v9-v1.md`, sur le brouillon 2),
couples appliqués (38 : 23 tels quels, 15 refaits sur le brouillon 3), bloquant B1 et importants I5, I6 levés par des essais,
I2 levé par la description publique du nul (section 0 ter) ; non scellé ; aucun marqueur ni jeton.** Brouillon 2 rédigé le
2 novembre 2026, de 18:51 à 18:55 UTC (`date -u`) ; brouillon 3 (section 0 bis) de 19:14 à 19:20 UTC ; brouillon 4 (section 0 ter)
de 19:46 à 20:10 UTC ; tous trois par un""", "T01 refait (statut)")
rep("""**La correction du code que le brouillon 2 disait indispensable est faite** (par le directeur, commit `e58cfec`, section 0 bis) :
le banc gèle 48 heures en mode décisif ; le bloc de la section 12 porte ses 14 empreintes.""",
    """**La correction du code que le brouillon 2 disait indispensable est faite** (par le directeur, commit `e58cfec`, section 0 bis) :
le banc gèle 48 heures en mode décisif (`demonstrations/banc_tricheurs_v9.py`, ligne 84, `DUREE_MAX_S = 48 * 3600.0`, comparée
ligne 524 ; docstring et usage, lignes 40 et 47) ; un essai (`test_duree_du_mode_decisif_48_h`) et une mutation (« durée du mode
décisif non gardée ») l'accompagnent. Le cas sain que demandait l'annexe B (durée par défaut → la course démarre, durée transmise
172 800 s) manquait (B1 de la contre-lecture) : il est ajouté au brouillon 4 (`test_mode_decisif_cas_sain_et_refus`). Le bloc de
la section 12 porte les 14 empreintes du code final, dont celle de `pole/nul_v9.py` modifié pour sa description seulement
(section 0 ter, point 5).""", "T02 refait (correction faite)")
rep("""fichiers, vérifié par `git diff --quiet e58cfec` à 19:05 UTC) :""",
    """fichiers, vérifié par `git diff --quiet e58cfec` à 19:05 UTC). **Au brouillon 4, trois fichiers changent encore** (arbre de travail,
non commité ; le directeur recommite avant le scellement) : `pole/nul_v9.py` (description seulement, aucun calcul), les essais
et le banc de mutations (section 0 ter) ; dernière colonne :""", "T03-T05 refaits (phrase du tableau)")
rep("""| fichier | rôle | sha256 au commit `5e352ec` | sha256 au commit `e58cfec` |
|---|---|---|---|
| `pole/nul_v9.py` | le nul | `8cb44adf8b325ac656b077f03dddb44311071510a5785ebd3f0aa8c37aebc655` | inchangé |
| `demonstrations/banc_tricheurs_v9.py` | le banc (durée corrigée) | `c7ab547065180b6e23e0e496d9c9dc96b674ed4c1b47766b3e108709fdbcf466` | `7e4bff5995df2a7d62a4f5a2f5f9176da614e657a55b05183325fa2fc6e24e44` |
| `essais/test_nul_v9.py` | essais (un essai neuf) | `f674e9cac121d8930942738e28f938bd3613018c0c4371bd4621e53020212855` | `9eb966ad4220fc6cd297eef53ebec36a0f77655c2eadaceedc52ad72a1a67b21` |
| `essais/mutations_nul_v9.py` | banc de mutations (une mutation neuve) | `576eea7917cc9c0ed5213eeb22f191add217cc91b54fc4368a087911f153507d` | `9cb305e45b8c005564184df621e68c05f1ac36b92e520ee081dbed735a252d16` |
| `prereg/rapport-redaction-nul-v9.md` | conception, preuve, non-couvert, esquisse de la suite | `bbf9b38f3b2fca44ac33bf36c7e67f39c6525dfd6561c9f84a00cda758233089` | inchangé |
| `prereg/preenregistrement-validation-nul-v9-brouillon1.md` | brouillon 1 de ce texte | `253eece5598f582b09b0fd468fde55b0b7bda98454d25505971b65cbe6afccf0` | inchangé |
| `prereg/preenregistrement-validation-nul-v9-brouillon2.md` | brouillon 2 de ce texte (au commit `e58cfec`) | — | `0a906f8c43099670f1c6694d7ec67b847ff9bc28687d0906e8419e3e23d8bcb7` |""",
    f"""| fichier | rôle | sha256 au commit `5e352ec` | sha256 au commit `e58cfec` | sha256 au brouillon 4 (arbre) |
|---|---|---|---|---|
| `pole/nul_v9.py` | le nul (au brouillon 4 : description publique, aucun calcul changé) | `8cb44adf8b325ac656b077f03dddb44311071510a5785ebd3f0aa8c37aebc655` | inchangé | `{h_nul}` |
| `demonstrations/banc_tricheurs_v9.py` | le banc (durée corrigée) ; à `5e352ec`, non gelé | `c7ab547065180b6e23e0e496d9c9dc96b674ed4c1b47766b3e108709fdbcf466` | `7e4bff5995df2a7d62a4f5a2f5f9176da614e657a55b05183325fa2fc6e24e44` | inchangé |
| `essais/test_nul_v9.py` | essais (non gelé) ; au brouillon 4 : B1, I5, I6, I2 | `f674e9cac121d8930942738e28f938bd3613018c0c4371bd4621e53020212855` | `9eb966ad4220fc6cd297eef53ebec36a0f77655c2eadaceedc52ad72a1a67b21` | `{h_test}` |
| `essais/mutations_nul_v9.py` | banc de mutations (non gelé) ; au brouillon 4 : G1 à G5, L1, L2, C5, description | `576eea7917cc9c0ed5213eeb22f191add217cc91b54fc4368a087911f153507d` | `9cb305e45b8c005564184df621e68c05f1ac36b92e520ee081dbed735a252d16` | `{h_mut}` |
| `prereg/rapport-redaction-nul-v9.md` | conception, preuve, non-couvert, esquisse de la suite | `bbf9b38f3b2fca44ac33bf36c7e67f39c6525dfd6561c9f84a00cda758233089` | inchangé | inchangé |
| `prereg/preenregistrement-validation-nul-v9-brouillon1.md` | brouillon 1 de ce texte | `253eece5598f582b09b0fd468fde55b0b7bda98454d25505971b65cbe6afccf0` | inchangé | inchangé |
| `prereg/preenregistrement-validation-nul-v9-brouillon2.md` | brouillon 2 de ce texte (au commit `e58cfec`) | — | `0a906f8c43099670f1c6694d7ec67b847ff9bc28687d0906e8419e3e23d8bcb7` | inchangé |
| `prereg/preenregistrement-validation-nul-v9-brouillon3.md` | brouillon 3 de ce texte (commit `9e6ca23`) | — | — | `347523dd429745be47803a4676ac451371592c790def39a68da109676a460cb2` |
| `prereg/contre-lecture-preenregistrement-validation-nul-v9-v1.md` | contre-lecture R2 n° 1 (non commitée à la rédaction) | — | — | `41f4f56d85456520394835f96d7c6a5d06b51138dc985fd0d40fdb67cac9b9d5` |
| `prereg/couples-contre-lecture-validation-nul-v9-v1.json` | ses 38 couples | — | — | `78c9b1e5c1f2337c6a5ee09cd7d24c35b050242ea61b4c83b4a31d2479e71f20` |""",
    "T03-T05 refaits (tableau)")
rep("""33 essais réussis, 34 mutations tuées sur 34 (directeur, message du commit `e58cfec` et message au repreneur). Ce repreneur n'a
relancé ni les uns ni les autres (section 10, L9).""",
    """33 essais réussis, 34 mutations tuées sur 34 (directeur, message du commit `e58cfec` et message au repreneur) ; même résultat au
passage du contre-lecteur R2 n° 1 (33 essais, 32 sous-essais, 19:11:17 à 19:11:58 UTC ; 34 mutations sur 34, témoin 22 essais,
19:14:31 à 19:17:56 UTC ; section 10, L11). **Au brouillon 4, sur le code final** (repreneur, section 10, L12) : **37 essais
réussis, 35 sous-essais ; 43 mutations tuées pour la raison attendue sur 43**, témoin 26 essais sans échec avant et après.""",
    "T06 refait (passages)")
rep("""| durée gelée (48 h) | `DUREE_MAX_S` = 48 h (constante gelée ; la commande de la section 5 l'utilise par défaut) | texte décisif et `--duree-max-s 28800` (l'ancienne valeur) → code 2, aucune course, texte non lu | `test_duree_du_mode_decisif_48_h` |""",
    """| durée gelée (48 h) | texte décisif scellé, durée par défaut → durée transmise à chaque ligne = 172 800 s (et `DUREE_MAX_S` = 48 h) | texte décisif et `--duree-max-s 28800` (l'ancienne valeur) → code 2, texte jamais lu | `test_duree_du_mode_decisif_48_h` (artefact), `test_mode_decisif_cas_sain_et_refus` (cas sain, B1) |""",
    "T24 refait (durée)")
rep("""Banc de mutations (`essais/mutations_nul_v9.py`) : **34 mutations, 34 tuées** (directeur, après la correction, commit `e58cfec` ;
avant la correction : 33 sur 33, 18:23:58 à 18:25:08 UTC, section 10, L7) ; à rejouer sur l'arbre scellé.""",
    """Banc de mutations (`essais/mutations_nul_v9.py`) : au commit `e58cfec`, 34 mutations, 34 tuées (directeur ; contre-lecteur R2
n° 1, L11) ; avant la correction, 33 sur 33 (L7). **Au brouillon 4 : 43 mutations, 43 tuées pour la raison attendue**, témoin
26 essais sans échec avant et après (L12) : les 34 précédentes, les mutations G1 à G5 de la contre-lecture (mode décisif :
`--lignes` et répétitions acceptés, cas sain toujours refusé, durée transmise plafonnée à 8 h ; monotonie par la seule
richesse), L1 et L2 (ordre des issues), C5 (valeur du membre remplacée par la meilleure valeur atteinte + 10⁻³) et « description
publique : choix rangés parmi les trous » — fragments de G1 à G5, L1, L2 et C5 repris à l'identique du script du contre-lecteur.
À rejouer sur l'arbre scellé.""", "T27 refait (banc de mutations)")
rep("""## 11. Portée""", """| L11 | 19:06 à 19:36 (contre-lecteur R2 n° 1) | essais et banc de mutations rejoués sur le code du commit `e58cfec` ; 12 mutations du contre-lecteur, en mémoire, contre toute la suite ; sondes : domination sur 48 mondes neufs, égalités de z, référence scipy, optimisation tronquée (30 mondes de l'essai de domination) ; fermeture dynamique (une répétition de M01, M06 et T01\\|v1 par `jouer_ligne`, en mémoire, taux non lus) ; tables de la section 6 recalculées ; aucune course par `principal` | essais 20261102 ; sondes : graines 910000 à 930011 et celles de l'essai de domination ; fermeture 5 | 33 essais réussis ; 34 mutations tuées sur 34 ; 8 des 12 mutations du contre-lecteur survivent (B1, I5, I6) ; aucun écart de domination ; tables identiques | `prereg/contre-lecture-preenregistrement-validation-nul-v9-v1.md`, sections 0, 1 et 5 |
| L12 | 19:46 à 20:10 (repreneur, brouillon 4) | essais neufs (B1, I5, I6, I2) et mutations neuves (G1 à G5, L1, L2, C5, description) ; `pole/nul_v9.py` modifié pour sa description seulement, vérifié par comparaison des arbres syntaxiques avant et après (seuls changent `PHRASES_MEMBRES_V9`, `NON_COUVERT_V9`, trois constantes neuves de description, `description_publique` et `description`) ; essais et banc de mutations rejoués sur le code final ; texte lu par `lire_preenregistrement` du banc (scellement simulé hors du dépôt) ; aucune course par `principal` hors des bouchons des essais | essais 20261102 ; mutations : celles des essais | 37 essais réussis, 35 sous-essais ; 43 mutations tuées sur 43 pour la raison attendue ; texte accepté (14 fichiers gelés) | bloc-notes `…/scratchpad/validation-b4/` (empreintes à la remise) |

## 11. Portée""", "T28 refait (lignes L11 et L12)")
rep("""Valeurs du 2 novembre 2026, 19:15 UTC, sur l'arbre de travail égal au commit `e58cfec` pour ces fichiers. Les 12 dépendances
(tous les fichiers sauf les deux fichiers v9) sont **identiques** au bloc du préenregistrement scellé du v8
(`prereg/preenregistrement-validation-nul-v8-v2.md`, lignes 365 à 376, comparées ligne pour ligne). `pole/nul_v9.py` est celui du
commit `5e352ec` (inchangé) ; `demonstrations/banc_tricheurs_v9.py` est le banc corrigé du commit `e58cfec` (l'empreinte d'avant
la correction, `c7ab5470…fcf466`, n'est pas gelée). Le directeur recalcule le bloc au scellement et refuse tout écart.""",
    """Valeurs du 2 novembre 2026, à la remise du brouillon 4 (heure dans la section 10, L12), sur l'arbre de travail. Les 12
dépendances (tous les fichiers sauf les deux fichiers v9) sont **identiques** au bloc du préenregistrement scellé du v8
(`prereg/preenregistrement-validation-nul-v8-v2.md`, lignes 365 à 376, comparées ligne pour ligne ; revérifiées par le
contre-lecteur R2 n° 1 au commit `e58cfec`). `demonstrations/banc_tricheurs_v9.py` est le banc corrigé du commit `e58cfec`
(l'empreinte d'avant la correction, `c7ab5470…fcf466`, n'est pas gelée). **`pole/nul_v9.py` a changé au brouillon 4** (description
publique seulement, aucun calcul : section 0 ter, point 5) : sa ligne porte la nouvelle empreinte ; l'ancienne (`8cb44adf…aebc655`)
n'est plus gelée. Les essais de B1, I5 et I6 ne touchent aucun des 14 fichiers. Le directeur recommite, recalcule le bloc au
scellement et refuse tout écart.""", "T31-T32 refaits (section 12)")
rep("8cb44adf8b325ac656b077f03dddb44311071510a5785ebd3f0aa8c37aebc655  pole/nul_v9.py", f"{h_nul}  pole/nul_v9.py", "T33 refait (bloc : nul v9)")
rep("""1. **Correction du banc (annexe B) : faite** (directeur, commit `e58cfec` ; section 0 bis) ; essais et banc de mutations rejoués
   par le directeur (33 ; 34 sur 34) ; empreinte du banc corrigé portée à la section 12.""",
    """1. **Correction du banc (annexe B) : faite** (directeur, commit `e58cfec` ; section 0 bis) ; empreinte du banc corrigé portée à la
   section 12. **Essais de B1, I5 et I6 de la contre-lecture : faits au brouillon 4** (`test_mode_decisif_cas_sain_et_refus`,
   sous-essai « monotonie-richesse » de `test_banc_reduit_et_liste_d_arret`, `test_ordre_des_issues`,
   `test_valeur_certifiee_sous_optimisation_tronquee`) avec leurs mutations (G1 à G5, L1, L2, C5), toutes tuées pour la raison
   attendue ; description publique (I2) écrite. Essais et banc de mutations rejoués sur l'arbre scellé :
   `nice -n 10 python3 -I -B -m pytest -q -p no:cacheprovider essais/test_nul_v9.py` ;
   `nice -n 10 python3 -I -B essais/mutations_nul_v9.py`.""", "T35 refait (procédure, étape 1)")
rep("""## Annexe B. Correction du banc v9 (dite par le brouillon 2, faite par le directeur au commit `e58cfec`) — trace""",
    """## Annexe B. Correction du banc v9 (faite au commit `e58cfec`) et marqueur levé — trace""", "T37 refait (annexe B, titre)")
rep("""**Marqueurs** : aucun. Le jeton EMPREINTE_DU_BANC_CORRIGE du brouillon 2 est levé (section 12, empreinte du banc corrigé) ;
les marqueurs du brouillon 1 sont levés (marge : annexe A). La correction faite diffère de la proposition en un point : l'essai
neuf vérifie le cas sain par la constante gelée (section 0 bis, point 5).""",
    """**Marqueur levé** : le jeton EMPREINTE_DU_BANC_CORRIGE (entre doubles chevrons) du brouillon 2 porte l'empreinte du banc corrigé
au commit `e58cfec` (`7e4bff59…6e24e44`). Les marqueurs du brouillon 1 sont levés (marge : annexe A). Écart à cette annexe, dit
au brouillon 3 et relevé par la contre-lecture (B1) : l'essai livré au commit `e58cfec` (`test_duree_du_mode_decisif_48_h`) jouait
l'artefact (28 800 s → code 2, texte jamais lu) et vérifiait la constante, pas le cas sain demandé ; **levé au brouillon 4** par
`test_mode_decisif_cas_sain_et_refus` (durée par défaut → la course démarre, durée transmise 172 800 s à chacune des 31 lignes),
et la mutation G4 (durée transmise plafonnée à 8 h) est tuée.""", "T38 refait (annexe B, marqueur)")

# (3) mises à jour d'état après les couples (essais faits) et mineurs
rep("(annexe B ; essais du mode décisif à compléter, B1 de la contre-lecture)",
    "(annexe B ; essais du mode décisif complétés au brouillon 4, B1 de la contre-lecture)", "état T07")
rep("""- **Hors du nul v9** (`nul_v9.NON_COUVERT_V9` en dit cinq phrases ; « lois hors de l'archive » n'est que dans la docstring du
  module ; la description publique du juge v9 n'existe pas au commit `e58cfec` : celle de l'attaque v4, non commitée, reprend
  `NON_COUVERT_V9`) :""",
    """- **Hors du nul v9** (dit, depuis le brouillon 4, par la description publique du nul, `nul_v9.description_publique()` : (a) par
  `NON_COUVERT_V9`, (b) par `HORS_DU_NUL_PAR_CHOIX_V9`, (c) par `HORS_DU_NUL_PAR_NATURE_V9` et `RESERVES_V9` ; au commit `e58cfec`,
  `NON_COUVERT_V9` rangeait (b) parmi ses cinq phrases et aucune description publique du v9 n'existait, I2 de la contre-lecture) :""",
    "état T10 (description publique)")
rep("""  `NON_COUVERT_V9` range (b) parmi les non-couverts sans dire que c'est un choix : la description publique du v9 (attaque v4,
  production) doit le dire.""",
    """  La description publique sépare ces trois sortes (essai `DescriptionPublique.test_description_publique_separe_trous_choix_et_nature`) ;
  l'attaque v4 et toute production la reprennent. La promouvabilité d'une loi en escalier aveugle **pure** n'est mesurée par aucune
  ligne du banc (H04 n'en est qu'un voisin) : la revendication porte sur la famille du nul (aucun sommet mixte), pas sur une
  puissance (M10 de la contre-lecture).""", "état T10 (fin) et M10")
rep("mêmes 30 mondes sous optimisation tronquée (un palier, un pas) : valeur ≥ log-vraisemblance du monde (à ajouter, I6)",
    "mêmes 30 mondes sous optimisation tronquée (un palier, un pas) : valeur ≥ log-vraisemblance du monde (`test_valeur_certifiee_sous_optimisation_tronquee`, I6)",
    "état T21 (cas sain)")
rep("(mutation C5 de la contre-lecture, à tuer : I6)", "(mutation C5 de la contre-lecture, tuée : I6)", "état T21 (artefact)")
rep("perte non tenue et artefact non tenu → « puissance perdue » (à ajouter, I5 de la contre-lecture)",
    "perte non tenue et artefact non tenu → « puissance perdue » (`test_ordre_des_issues`, I5 de la contre-lecture ; mutations L1 et L2 tuées)",
    "état T22")
rep("172 800 s, entropie = empreinte du texte) (à ajouter, B1)", "172 800 s, entropie = empreinte du texte ; B1)", "état T23 (cas sain)")
rep("`--repetitions 999` → code 2, texte jamais lu (à ajouter, B1)", "`--repetitions 999` → code 2, texte jamais lu (B1 ; mutations G1 à G3 tuées)",
    "état T23 (artefacts)")
rep("et (à ajouter, B1) par la seule richesse, log W v9 > log W v8 + 10⁻⁶ sans promotion inversée",
    "et par la seule richesse, log W v9 > log W v8 + 10⁻⁶ sans promotion inversée (sous-essai « monotonie-richesse », B1 ; mutation G5 tuée)",
    "état T25")
rep("""3. Contre-lecture neuve (R2) ; couples de remplacement appliqués ; version contre-lue renommée
   `prereg/preenregistrement-validation-nul-v9-vN.md` (N ≥ 1).""",
    """3. Contre-lecture neuve (R2) : **faite** (n° 1, sur le brouillon 2) ; couples appliqués au brouillon 4 (section 0 ter) ;
   vérification courte des changements 3 → 4 recommandée avant le scellement (essais et mutations neufs, et surtout le changement
   de `pole/nul_v9.py`, description seulement, que la contre-lecture n'a pas vu) ; version renommée
   `prereg/preenregistrement-validation-nul-v9-vN.md` (N ≥ 1).""", "procédure, étape 3")

# (4) section 0 ter
ter = f"""## 0 ter. Changements du brouillon 3 au brouillon 4

1. **Contre-lecture R2 n° 1** (`prereg/contre-lecture-preenregistrement-validation-nul-v9-v1.md`, sha256
   `41f4f56d85456520394835f96d7c6a5d06b51138dc985fd0d40fdb67cac9b9d5`, sur le brouillon 2 ; couples
   `prereg/couples-contre-lecture-validation-nul-v9-v1.json`, sha256 `78c9b1e5c1f2337c6a5ee09cd7d24c35b050242ea61b4c83b4a31d2479e71f20`) :
   la preuve tient, refaite et éprouvée sans écart ; non scellable à cause de B1 ; scellable après couples une fois B1 levé.
2. **Couples** : les 23 qui s'appliquent tels quels au brouillon 3 (T07 à T23, T25, T26, T29, T30, T34, T36) sont appliqués
   tels quels, dans l'ordre du fichier ; les 15 d'I7, dont le passage du brouillon 2 n'existe plus (T01 à T06, T24, T27, T28, T31 à
   T33, T35, T37, T38), sont refaits sur le texte du brouillon 3 : statut, paragraphe de la correction, tableau d'en-tête (une
   colonne « brouillon 4 »), passages des essais et mutations, ligne « durée » de la section 9, paragraphe du banc de mutations,
   lignes L11 (contre-lecteur) et L12 (brouillon 4) de la section 10 (le brouillon 3 avait déjà une L10), section 12 et son bloc,
   étape 1 de la section 14, annexe B. Puis les mentions « à ajouter » des couples T07, T10, T21 à T23 et T25 sont mises à l'état
   du brouillon 4 (essais faits). Construction et contrôles (chaque « ancien » présent une seule fois) : `construire_b4.py`
   (bloc-notes `…/scratchpad/validation-b4/`).
3. **B1 levé** (essais seulement, aucun fichier gelé) : `GrainesEtPreenregistrement.test_mode_decisif_cas_sain_et_refus` — cas
   sain : texte d'essai scellé au nom décisif gelant les 14 empreintes, sans option → code 3 (course lancée une fois, bouchon de
   `jouer_tout`), 31 lignes du plan, 1 000 répétitions, durée transmise 172 800 s, entropie = empreinte du texte, manifeste
   « decisif » ; artefacts : `--lignes M01`, `--repetitions 999` → code 2, texte jamais lu, rien écrit ; sous-essai
   « monotonie-richesse » de `test_banc_reduit_et_liste_d_arret` (log W v9 2,0 contre v8 1,0, aucune promotion → code 3,
   `MonotonieViolee`). Mutations G1 à G5 du contre-lecteur ajoutées au banc : tuées pour la raison attendue.
4. **I5, I6 levés** : `LectureGelee.test_ordre_des_issues` (M03 à 90/1 000 et perte de I02 à 120/1 000 → « trou » ; perte de I02 et
   M02 apparié à 20/1 000 → « puissance perdue ») ; `CertificatMorceaux.test_valeur_certifiee_sous_optimisation_tronquee` (les 30
   mondes de l'essai de domination, `PALIERS_MU = (1e-2,)`, `PAS_MAX_PAR_PALIER = 1` : valeur ≥ vraisemblance du monde à chaque
   instant ; dents : meilleure valeur atteinte + 10⁻³ dessous à au moins un instant). Mutations L1, L2 et C5 : tuées.
5. **I2 levé — `pole/nul_v9.py` modifié pour sa description seulement** (empreinte `8cb44adf…aebc655` → `{h_nul[:8]}…{h_nul[-7:]}` ;
   la ligne du bloc de la section 12 suit) : `NON_COUVERT_V9` ne garde que les quatre trous (le « bruit aveugle propre à chaque
   morceau, ou loi aveugle seule sur un morceau » en sort) ; constantes neuves `HORS_DU_NUL_PAR_CHOIX_V9` (loi en escalier aveugle ;
   loi aveugle seule sur un morceau ; bruit aveugle propre à un morceau, autre loi aveugle ou même loi avec un autre poids),
   `HORS_DU_NUL_PAR_NATURE_V9` (lois hors de l'archive), `RESERVES_V9` (mondes sans mémoire ; traits finis ; marge de Newton des
   membres log-linéaires) ; `PHRASES_MEMBRES_V9` dit « même loi aveugle, même poids » ; fonction neuve `description_publique()`
   (maximum au dénominateur, classe couverte, garantie, puis trous, choix, nature et réserves, dans cet ordre) ; `description()` les
   rend. **Aucun calcul ne change** : comparaison des arbres syntaxiques du module avant et après (seuls changent ces constantes et
   les deux fonctions de description ; la docstring du module dit les trois sortes) ; essais `DescriptionPublique` (dont un
   artefact : la liste du brouillon 2, qui rangeait un choix parmi les trous, est détectée) ; mutation « description publique :
   choix rangés parmi les trous », tuée.
6. **I1, I3, I4** par couples : lecture de « puissance perdue » à deux étages (T17, T18, T20 : fermeture des 18 lignes fatales et
   des 3 artefacts d'abord, puissance ensuite ; sans changer le code, sur les champs `lecture.fatales` et `lecture.artefact`) ;
   revendication publique et production après le mot explicite de Lazar sur le sens du bruit commun, la course peut partir (T11,
   T36) ; interdit de resceller pour changer de graine, et un arrêt déterministe est un défaut du code, pas un rejeu (T15, T26).
7. **Mineurs** : M1, M2 (T19) ; M3 (T16) ; M4 (T13) ; M5 (T12) ; M6 (T10) ; M9 (T29) ; M10 (phrase ajoutée en section 2) ; M7 : les
   docstrings du code gelé qui citent le brouillon 1 (banc, et `pole/nul_v9.py` ligne 6) ne sont pas touchées (seule la
   description du nul l'est) ; M8 : aucun essai synthétique d'A2 (facultatif, inaccessible dans une course complète : l'arrêt de
   monotonie passe avant).
8. **Essais et mutations sur le code final** (L12) : 37 essais réussis, 35 sous-essais ; 43 mutations tuées pour la raison attendue
   sur 43 ; témoin 26 essais sans échec avant et après.

Rien d'autre ne change : lignes, scénarios, graines, métriques, familles de Holm, seuils, prédictions, audits, liste d'arrêt.

## 0 bis. Changements du brouillon 2 au brouillon 3"""
rep("## 0 bis. Changements du brouillon 2 au brouillon 3", ter, "section 0 ter")
assert not re.findall(r"<<[A-Z_]+>>", t)
open(dst, "w", encoding="utf-8").write(t)
print(len(journal), "remplacements :", journal)
print("à ajouter restants :", [m.start() for m in re.finditer("à ajouter", t)])
