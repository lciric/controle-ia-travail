import pathlib
p = pathlib.Path('/home/claude/controle-ia-travail/registres/go.md')
s = p.read_text(encoding='utf-8')
assert 'GO-2026-11-02-30' not in s
src = ("mots de Lazar dans la session conv-audit, 2 novembre 2026 : 18:26 UTC « go finir, arrête de mettre des budgets temps et de les couper » ; 18:27 UTC « prends des budgets et plafonds très larges » ; 18:53 UTC « Session-depot la relance sans budget de temps, sous un texte court. : prepare les » ; 18:26 UTC « je ne veux pas de blocage, de résultats non concluants par défaut de conception, de plafond ou que sais-je »")
ligne = (f"| GO-2026-11-02-30 | 2026-11-02 | calcul | **Contrôle, rejeu à graine : complément de validation, plafond relevé** (les 147 épisodes déjà résolus rejoués sous un texte complémentaire scellé, même code `c2a8b6e1` ; la validation du 2 novembre a été coupée par le budget d'étape de 2 400 s : 90 épisodes non tentés et 3 coupés pendant leur repli ; les 54 retrouvés rejoués servent d'épreuve de répétabilité ; la résolution des 7 et la table rejouées comme épreuves, la table de référence restant `ead8a668…`) ; **borne de recherche portée à la frontière écrite du repli** (`combinaisons_max` et `combinaisons_max_validation` 272 au lieu de 136, pour qu'aucun épisode ne soit perdu par une borne de travail) ; **aucun budget de temps qui coupe** (étape 72 h, épisode 4 h : gardes contre une boucle folle seulement) ; une instance A100 chez Vast.ai, arrêt par son identifiant (R10) ; sortie scellée avant lecture ; lecteur neuf ; attendu ≈ 6 à 20 USD ; le plafond de 15 USD inscrit plus tôt pour cette course n'est pas utilisé ; **plafond exactement 40 USD** | 40 USD | 2026-11-16 | Lazar | {src} |")
i = s.index('| GO-2026-11-02-29 |')
j = s.index('\n', i)
s = s[:j+1] + ligne + '\n' + s[j+1:]
p.write_text(s, encoding='utf-8')
print('ok')
