"""Exploratoire : discrimination du plan v1 selon l'exactitude par comparaison d'un juge scripté « bruite » (sans biais de
position), 30 graines de course par point. Aucune valeur ici n'est gelée."""
import sys, json, time
sys.path.insert(0, '/home/claude/ideation-organism/orchestrator')
from pole import juges_idees_v2 as J
from pole.graines_v53 import Graines
m = J.construire_materiaux()
A = {"etiquette": "juge-a", "fournisseur": "argon", "modele": "gemini-4-argon", "famille": "gemini", "prix_usd": 0.062, "secondes": (8, 40)}
B = {"etiquette": "juge-b", "fournisseur": "astra", "modele": "gpt-6-astra", "famille": "gpt", "prix_usd": 0.25, "secondes": (10, 120)}
oracle = J.oracle_depuis(m)
res = {}
for p in [float(x) for x in sys.argv[1].split(",")]:
    ligne = {"aire": [], "d1": 0, "retest": [], "kappa": [], "faux": [], "bascule": [], "premier": [], "issues": {}, "d4": 0, "d5": 0, "d6": 0, "nb": []}
    for graine in range(int(sys.argv[2])):
        g = Graines(1000 + graine)
        etapes, _ = J.etapes_v1(m, A, B, g)
        ad = {"argon": J.AdaptateurScripte("bruite", oracle, graine=graine, p_juste=p, biais_premier=0.0, p_item_bon=1.0, p_item_mauvais=1.0),
              "astra": J.AdaptateurScripte("bruite", oracle, graine=10_000 + graine, p_juste=p, biais_premier=0.0, p_item_bon=1.0, p_item_mauvais=1.0)}
        c = J.Compteur(1e9, 1e9, time.time, {"juge-a": 0.0, "juge-b": 0.0})
        jn = J.executer_validation(etapes, materiaux=m, juges={"juge-a": A, "juge-b": B}, adaptateurs=ad,
             consignes={"ancien": J.CONSIGNE_ANCIENNE_SUBSTITUTION, "v2": J.CONSIGNE_PAIRE_V2}, items=J.ITEMS_SUBSTITUTION, graines=g,
             compteur=c, plafond_session=0.5, interdites=J.ETIQUETTES_INTERDITES_TEMOINS, dossier_appel=lambda j, e: "/x")
        mes = J.mesurer(jn, m, A, B, etapes=etapes)
        lec = J.lire_validation(mes)
        v = mes["v2"]["juge-a"]["1"]
        ligne["aire"].append(v["aire"]); ligne["d1"] += bool(lec["criteres"]["D1"]["tenu"])
        ligne["retest"].append(mes["test_retest_a"]["spearman"] or 0.0)
        ligne["kappa"].append(mes["accord"]["kappa_paires_v2"]["kappa"] or 0.0)
        ligne["faux"].append(v["faux_notables"]); ligne["bascule"].append(mes["position_a"]["taux_bascule"]); ligne["premier"].append(mes["position_a"]["part_premier"])
        ligne["issues"][lec["issue"]] = ligne["issues"].get(lec["issue"], 0) + 1
        ligne["d4"] += bool(lec["criteres"]["D4"]["tenu"]); ligne["d5"] += bool(lec["criteres"]["D5"]["tenu"]); ligne["d6"] += bool(lec["criteres"]["D6"]["tenu"])
        ligne["nb"].append(sum(len(e["appels"]) for e in etapes if e["juge"] == "juge-b" and e["protocole"] == "v2"))
    n = int(sys.argv[2])
    import statistics as st
    res[p] = {"aire_moyenne": round(st.mean(ligne["aire"]), 3), "aire_q10": round(sorted(ligne["aire"])[n // 10], 3), "part_d1": round(ligne["d1"] / n, 3),
              "retest_moyen": round(st.mean(ligne["retest"]), 3), "part_retest_070": round(sum(r >= 0.7 for r in ligne["retest"]) / n, 3),
              "kappa_moyen": round(st.mean(ligne["kappa"]), 3), "part_kappa_030": round(sum(k >= 0.3 for k in ligne["kappa"]) / n, 3),
              "part_d4": round(ligne["d4"] / n, 3), "part_d5": round(ligne["d5"] / n, 3), "part_d6": round(ligne["d6"] / n, 3),
              "issues": ligne["issues"], "paires_b": (min(ligne["nb"]), round(st.mean(ligne["nb"]), 1), max(ligne["nb"])),
              "faux_notables": round(st.mean(ligne["faux"]), 3), "bascule": round(st.mean(ligne["bascule"]), 3), "premier": round(st.mean(ligne["premier"]), 3)}
    print(p, json.dumps(res[p]), flush=True)
