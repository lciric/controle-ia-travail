import sys, os
sys.path.insert(0, '/home/claude/ideation-organism/orchestrator'); sys.path.insert(0, '/home/claude/ideation-organism/orchestrator/essais')
import test_juges_idees_v2 as T
J = T.J
for graine in range(11, 21):
    journal, mes, lec, etapes = T.course("indulgent", "parfait", graine=graine)
    v = mes["v2"]["juge-a"]["1"]
    tem = J._temoins(T.MATERIAUX)
    faux = [i for i, x in v["verdicts"].items() if x and tem[i]["qualite"] == 0]
    print(graine, "aire", v["aire"], "faux", faux, "statuts", v["statuts_lots"])
    for i in faux:
        lot = tem[i]["lot"]
        comps = [(e["premier"], e["second"], e["gagnant"]) for e in journal["v2"] if e["juge"] == "juge-a" and e["tirage"] == 1 and i in e["paire"]]
        print("   ", i, tem[i]["classe"], "θ", round(v["forces"][i], 3), "plancher", round(v["lots"][lot]["plancher"], 3),
              [(tem[a]["classe"][:6], tem[b]["classe"][:6], tem[g]["classe"][:6]) for a, b, g in comps])
        print("    lot", sorted(((round(v["forces"][x], 2), tem[x]["classe"][:6], tem[x]["role"][:6]) for x in v["forces"] if tem[x]["lot"] == lot), reverse=True))
