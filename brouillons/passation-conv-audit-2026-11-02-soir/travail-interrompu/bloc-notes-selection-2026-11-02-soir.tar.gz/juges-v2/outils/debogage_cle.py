import sys, os, io, unittest
sys.path[:0] = ['/home/claude/ideation-organism/orchestrator', '/home/claude/ideation-organism/orchestrator/essais']
sys.dont_write_bytecode = True
from essais import mutations_juges_idees_v2 as M
m = [x for x in M.MUTATIONS if x[0] == "lanceur : variable de clé admise"][0]
r = M.appliquer(m[1], m[2], m[3], m[4])
import essais.test_juges_idees_v2 as T
t = T.LanceurCheminReel("test_artefacts_go_et_environnement")
t.setUp()
with unittest.mock.patch.dict(os.environ, {"GH_TOKEN": "x"}):
    err = io.StringIO()
    old = sys.stderr; sys.stderr = err
    code = T.lanceur.principal(t.argv("--verifier-seulement"))
    sys.stderr = old
print(code, err.getvalue()[:400])
t.doCleanups()
