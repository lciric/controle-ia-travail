import sys, json, time
sys.path.insert(0, '/home/claude/ideation-organism/orchestrator')
from pole import juges_idees_v2 as J
from pole.graines_v53 import Graines
m = J.construire_materiaux()
A = {"etiquette": "juge-a", "fournisseur": "argon", "modele": "gemini-4-argon", "famille": "gemini", "prix_usd": 0.062, "secondes": (8, 40)}
B = {"etiquette": "juge-b", "fournisseur": "astra", "modele": "gpt-6-astra", "famille": "gpt", "prix_usd": 0.25, "secondes": (10, 120)}
oracle = J.oracle_depuis(m)
for graine in range(int(sys.argv[1])):
    g = Graines(12345 + graine)
    etapes, _ = J.etapes_v1(m, A, B, g)
    ad = {"argon": J.AdaptateurScripte("parfait", oracle, graine=1), "astra": J.AdaptateurScripte("bruite", oracle, graine=2 + graine)}
    c = J.Compteur(1e9, 1e9, time.time, {"juge-a": 0.0, "juge-b": 0.0})
    jn = J.executer_validation(etapes, materiaux=m, juges={"juge-a": A, "juge-b": B}, adaptateurs=ad,
         consignes={"ancien": J.CONSIGNE_ANCIENNE_SUBSTITUTION, "v2": J.CONSIGNE_PAIRE_V2}, items=J.ITEMS_SUBSTITUTION, graines=g,
         compteur=c, plafond_session=0.5, interdites=J.ETIQUETTES_INTERDITES_TEMOINS, dossier_appel=lambda j, e: "/x")
    q = {f["ident"]: f["qualite"] for l in m["lots"] for f in l["fiches"]}
    eb = [e for e in jn["v2"] if e["juge"] == "juge-b"]
    mix = [e for e in eb if q[e["paire"][0]] != q[e["paire"][1]]]
    juste = sum(q[e["gagnant"]] == 1 for e in mix)
    mes = J.mesurer(jn, m, A, B, etapes=etapes)
    k = mes["accord"]["kappa_paires_v2"]
    print(graine, "B paires", len(eb), "mélangées", len(mix), "justes", juste, "kappa", round(k["kappa"], 3) if k["kappa"] is not None else None, k["paires"], k["accord"], k["attendu"])
