"""Exploratoire : plan circulant 3-régulier (actuel) contre plan « ancres en étoile » (chaque fiche contre les deux ancres, un
ordre ; cycle entre fiches évaluées, deux ordres ; paire des ancres, deux ordres). Juges scriptés « bruite » sans biais."""
import sys, time, statistics as st
sys.path.insert(0, '/home/claude/ideation-organism/orchestrator')
from pole import juges_idees_v2 as J
from pole.graines_v53 import Graines
m = J.construire_materiaux()
A = {"etiquette": "juge-a", "fournisseur": "argon", "modele": "gemini-4-argon", "famille": "gemini", "prix_usd": 0.062, "secondes": (8, 40)}
B = {"etiquette": "juge-b", "fournisseur": "astra", "modele": "gpt-6-astra", "famille": "gpt", "prix_usd": 0.25, "secondes": (10, 120)}
oracle = J.oracle_depuis(m)

def etapes_etoile(g):
    etapes = []
    lots = m["lots"]
    ev = {l["nom"]: [f["ident"] for f in l["fiches"] if f["role"] == "evaluation"] for l in lots}
    an = {l["nom"]: [next(f["ident"] for f in l["fiches"] if f["role"] == r) for r in ("ancre_bonne", "ancre_mauvaise")] for l in lots}
    graphes = {}
    for l in lots:
        for t in (1, 2):
            cyc = J.graphe_circulant(ev[l["nom"]], 2, g.generateur(f"graphe|{l['nom']}|tirage-{t}"))["paires"]
            hub = sorted(tuple(sorted((a, e))) for a in an[l["nom"]] for e in ev[l["nom"]])
            graphes[(l["nom"], t)] = (cyc, hub, [tuple(sorted(an[l["nom"]]))])
    for l in lots:
        etapes.append({"phase": "decisive-a", "protocole": "ancien", "lot": l["nom"], "juge": "juge-a", "tirage": 1, "fiches": ev[l["nom"]]})
    for t in (1, 2):
        for l in lots:
            cyc, hub, aa = graphes[(l["nom"], t)]
            rng = g.generateur(f"ordres|{l['nom']}|tirage-{t}|juge-a")
            appels = J.appels_paires(cyc + aa, True, rng) + J.appels_paires(hub, False, rng)
            appels = [appels[i] for i in rng.permutation(len(appels))]
            etapes.append({"phase": "decisive-a", "protocole": "v2", "lot": l["nom"], "juge": "juge-a", "tirage": t, "appels": appels})
    for l in lots:
        etapes.append({"phase": "decisive-b", "protocole": "ancien", "lot": l["nom"], "juge": "juge-b", "tirage": 1, "fiches": ev[l["nom"]]})
    for l in lots:
        q = {f["ident"]: f["qualite"] for f in l["fiches"]}
        cyc, hub, aa = graphes[(l["nom"], 1)]
        mel = [p for p in hub + aa if q[p[0]] != q[p[1]]]
        etapes.append({"phase": "decisive-b", "protocole": "v2", "lot": l["nom"], "juge": "juge-b", "tirage": 1,
                       "appels": J.appels_paires(mel, False, g.generateur(f"ordres|{l['nom']}|tirage-1|juge-b"))})
    return etapes

for plan in ("circulant", "etoile"):
    for p in (0.75, 0.85, 1.0):
        r = {"aire": [], "d1": 0, "faux": [], "inv": 0, "kappa": [], "i1": 0, "appels": None, "vrais": []}
        n = int(sys.argv[1])
        for k in range(n):
            g = Graines(5000 + k)
            etapes = J.etapes_v1(m, A, B, g)[0] if plan == "circulant" else etapes_etoile(g)
            r["appels"] = {j: sum(J.nombre_appels(e) for e in etapes if e["juge"] == j) for j in ("juge-a", "juge-b")}
            ad = {"argon": J.AdaptateurScripte("bruite", oracle, graine=k, p_juste=p, biais_premier=0.0, p_item_bon=1, p_item_mauvais=1),
                  "astra": J.AdaptateurScripte("bruite", oracle, graine=99999 + k, p_juste=p, biais_premier=0.0, p_item_bon=1, p_item_mauvais=1)}
            c = J.Compteur(1e9, 1e12, time.monotonic, {"juge-a": 0, "juge-b": 0})
            jn = J.executer_validation(etapes, materiaux=m, juges={"juge-a": A, "juge-b": B}, adaptateurs=ad, consignes={"ancien": J.CONSIGNE_ANCIENNE_SUBSTITUTION, "v2": J.CONSIGNE_PAIRE_V2},
                                       items=J.ITEMS_SUBSTITUTION, graines=g, compteur=c, plafond_session=1, interdites=J.ETIQUETTES_INTERDITES_TEMOINS, dossier_appel=lambda j, e: "/x")
            mes = J.mesurer(jn, m, A, B, etapes=etapes)
            lec = J.lire_validation(mes)
            v = mes["v2"]["juge-a"]["1"]
            r["aire"].append(v["aire"]); r["d1"] += lec["criteres"]["D1"]["tenu"]; r["faux"].append(v["faux_notables"]); r["vrais"].append(v["vrais_notables"])
            r["inv"] += sum(s == "ancres inversées" for s in v["statuts_lots"].values()); r["kappa"].append(mes["accord"]["kappa_paires_v2"]["kappa"] or 0)
            r["i1"] += lec["issue"] == "I1"
        print(plan, p, "appels", r["appels"], "aire", round(st.mean(r["aire"]), 3), "q10", round(sorted(r["aire"])[n // 10], 3), "D1", r["d1"] / n,
              "faux", round(st.mean(r["faux"]), 3), "vrais", round(st.mean(r["vrais"]), 3), "lots inversés", r["inv"], "kappa", round(st.mean(r["kappa"]), 3), "I1", r["i1"] / n, flush=True)
