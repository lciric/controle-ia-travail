import importlib.util, json, os, sys
R = os.path.realpath(sys.argv[1])
vus = set()
def crochet(e, a):
    if e == 'open' and a and isinstance(a[0], str) and a[0].endswith(('.py', '.pyc')):
        vus.add(os.path.realpath(a[0]))
sys.addaudithook(crochet)
sys.path.insert(0, R)
s = importlib.util.spec_from_file_location('l', os.path.join(R, 'demonstrations', 'validation_juges_idees_v2.py'))
m = importlib.util.module_from_spec(s)
s.loader.exec_module(m)
m.charger_ideation_v8()
import pole.relais, pole.configuration_v56, pole.configuration_v53
f = {os.path.realpath(getattr(x, '__file__', '') or '') for x in list(sys.modules.values())} | vus
def source(p):
    if p.endswith('.pyc') and os.path.basename(os.path.dirname(p)) == '__pycache__':
        p = os.path.join(os.path.dirname(os.path.dirname(p)), os.path.basename(p).split('.')[0] + '.py')
    return p
mesure = sorted({os.path.relpath(source(p), R) for p in f if p.startswith(R + os.sep)})
print(json.dumps(mesure))
print("egal", mesure == sorted(m.FICHIERS_GELES), sorted(set(mesure) - set(m.FICHIERS_GELES)), sorted(set(m.FICHIERS_GELES) - set(mesure)))
