import sys, json, time
sys.path.insert(0, '/home/claude/ideation-organism/orchestrator')
from pole import juges_idees_v2 as J
from pole.graines_v53 import Graines
strat_a, strat_b = sys.argv[1], sys.argv[2]
m = J.construire_materiaux()
objet, qualites = J.lot_reel_substitution(3)
correspondance = {"kimi": "kimi", "argon": "gemini"}
reel = J.lot_reel_depuis(objet, J.QUESTION_SUBSTITUTION, correspondance)
A = {"etiquette": "juge-a", "fournisseur": "argon", "modele": "gemini-4-argon", "famille": "gemini", "prix_usd": 0.062, "secondes": (8, 40)}
B = {"etiquette": "juge-b", "fournisseur": "astra", "modele": "gpt-6-astra", "famille": "gpt", "prix_usd": 0.25, "secondes": (10, 120)}
g = Graines(12345)
etapes, graphes = J.etapes_v1(m, A, B, g, lot_reel=reel)
print(json.dumps(J.devis(etapes, {"juge-a": A, "juge-b": B}), ensure_ascii=False))
oracle = J.oracle_depuis(m, reel, qualites)
ad = {"argon": J.AdaptateurScripte(strat_a, oracle, graine=1, cout_par_appel_usd=0.062),
      "astra": J.AdaptateurScripte(strat_b, oracle, graine=2, cout_par_appel_usd=0.25)}
t = time.time()
c = J.Compteur(30.0, 3600, time.time, {"juge-a": 0.062, "juge-b": 0.25})
journal = J.executer_validation(etapes, materiaux=m, juges={"juge-a": A, "juge-b": B}, adaptateurs=ad,
     consignes={"ancien": J.CONSIGNE_ANCIENNE_SUBSTITUTION, "v2": J.CONSIGNE_PAIRE_V2}, items=J.ITEMS_SUBSTITUTION, graines=g,
     compteur=c, plafond_session=0.5, interdites=J.ETIQUETTES_INTERDITES_TEMOINS, dossier_appel=lambda j, e: "/nonexistent", lot_reel=reel)
print("durée", round(time.time()-t, 2), "dépense", round(c.depense, 3), "appels", c.appels)
mes = J.mesurer(journal, m, A, B, etapes=etapes, lot_reel=reel)
lec = J.lire_validation(mes)
print(lec["issue"], lec["sous_issue"])
print(json.dumps({k: (v["valeur"], v["tenu"]) for k, v in lec["criteres"].items()}, ensure_ascii=False, default=str))
print(json.dumps(lec["audit"], ensure_ascii=False)[:600])
print(json.dumps({k: v["tenue"] for k, v in lec["predictions"].items()}, ensure_ascii=False))
print("classes", mes["classes"])
print("accord", {k: (v.get("kappa"), v.get("statut")) for k, v in mes["accord"].items()})
print("phases", journal["phases"])
print("reel", {k: (v if not isinstance(v, dict) else {kk: vv for kk, vv in v.items() if kk in ('ancien_part_notables','v2_joues','v2_valides','v2_etendue')}) for k, v in mes["reel"].items() if k != "kappa_ancien_communes"})
print("validite", {j: {t: (v.get("validite"), v.get("motifs_invalides")) for t, v in d.items()} for j, d in mes["v2"].items()})
