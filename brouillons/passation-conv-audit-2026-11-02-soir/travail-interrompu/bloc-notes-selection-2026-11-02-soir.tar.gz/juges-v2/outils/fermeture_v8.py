import importlib.util, json, os, sys
R = os.path.realpath(sys.argv[1])
vus = set()
def crochet(e, a):
    if e == 'open' and a and isinstance(a[0], str) and a[0].endswith(('.py', '.pyc')):
        vus.add(os.path.realpath(a[0]))
sys.addaudithook(crochet)
sys.path.insert(0, R)
s = importlib.util.spec_from_file_location('v8', os.path.join(R, 'demonstrations', 'ideation_v8.py'))
m = importlib.util.module_from_spec(s)
s.loader.exec_module(m)
import pole.relais, pole.configuration_v56, pole.adaptateurs_v56, pole.adaptateur_kimi_v53
f = {os.path.realpath(getattr(x, '__file__', '') or '') for x in list(sys.modules.values())} | vus
def source(p):
    if p.endswith('.pyc') and os.path.basename(os.path.dirname(p)) == '__pycache__':
        p = os.path.join(os.path.dirname(os.path.dirname(p)), os.path.basename(p).split('.')[0] + '.py')
    return p
print(json.dumps(sorted({os.path.relpath(source(p), R) for p in f if p.startswith(R + os.sep)}), indent=0))
