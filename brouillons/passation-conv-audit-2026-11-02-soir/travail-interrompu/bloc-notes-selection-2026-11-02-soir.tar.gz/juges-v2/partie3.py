

# --- plan de la validation v1 --------------------------------------------------------------------------------------------------

DEGRE_V1 = 3
DEGRE_REEL_V1 = 2
TIRAGES_A_V1 = (1, 2)
PHASES_V1 = ("decisive-a", "decisive-b", "reel-ancien", "reel-v2")
PHASES_DECISIVES = ("decisive-a", "decisive-b")
SEUIL_PLAFOND = 0.9
VALIDITE_GARDE_APPELS, VALIDITE_GARDE_PART = 20, 0.5
MINIMUM_APPEL_USD = 0.005


def lot_reel_depuis(objet, question, correspondance):
    """Lot réel (privé, lu descriptivement) : {"fiches": [{ident, contenu, meta: {fournisseur, origine?, parents_fournisseurs?}}]}
    + texte de la question servi comme dossier. Rend le lot au format des lots témoins (familles par fiche)."""
    if not isinstance(objet, dict) or not isinstance(objet.get("fiches"), list) or not objet["fiches"]:
        raise ProtocoleRefuse("lot réel : {fiches: [...]} non vide attendu")
    vus, fiches = set(), []
    for k, f in enumerate(objet["fiches"], 1):
        if not isinstance(f, dict) or not isinstance(f.get("ident"), str) or not f["ident"] or not isinstance(f.get("contenu"), dict):
            raise ProtocoleRefuse(f"lot réel : fiche n° {k} : {{ident, contenu, meta}} attendu")
        if f["ident"] in vus:
            raise ProtocoleRefuse(f"lot réel : identifiant en double {f['ident']!r}")
        vus.add(f["ident"])
        fiches.append({"ident": f["ident"], "contenu": f["contenu"], "role": "reel", "classe": None, "qualite": None,
                       "familles": sorted(familles_auteurs(f, correspondance)), "meta": f.get("meta")})
    if not isinstance(question, str) or not question.strip():
        raise ProtocoleRefuse("lot réel : texte de la question exigé (servi comme dossier)")
    dossier = "## Dossier d'étude (la question posée aux proposeurs)\n\n" + question.strip() + "\n"
    return {"nom": "reel", "dossier": dossier, "preuve_dossier": dossier_a_preuves(dossier), "fiches": fiches}


def _familles_lot(lot):
    return {f["ident"]: set(f.get("familles") or [FAMILLE_AUTEUR_TEMOINS]) for f in lot["fiches"]}


def etapes_v1(materiaux, juge_a, juge_b, graines, lot_reel=None):
    """Les étapes de la validation, dans l'ordre de jeu (structure fixée par le code, citée par le texte scellé) :
    - decisive-a : juge A, ancien protocole (tirage 1, fiches d'évaluation), puis v2 aux tirages 1 et 2 (graphe 3-régulier
      neuf à chaque tirage, deux ordres par paire) ;
    - decisive-b : juge B, ancien protocole (tirage 1), puis v2 sur le cycle du graphe du tirage 1 de A (un ordre, tiré
      indépendamment de ceux de A) ;
    - reel-ancien, reel-v2 (lot réel, descriptifs) : chaque juge sur les fiches où il est admis (règle de famille), v2 sur un
      cycle de ces fiches, un ordre.
    Rend (étapes, graphes)."""
    for j in (juge_a, juge_b):
        if j["famille"] == FAMILLE_AUTEUR_TEMOINS:
            raise ProtocoleRefuse(f"juge {j['etiquette']} de la famille {j['famille']!r}, celle de l'auteur des gabarits des témoins")
    if juge_a["famille"] == juge_b["famille"] or juge_a["etiquette"] == juge_b["etiquette"]:
        raise ProtocoleRefuse("juges A et B : étiquettes et familles distinctes exigées")
    etapes, graphes = [], {}
    lots = materiaux["lots"]
    evaluees = {l["nom"]: [f["ident"] for f in l["fiches"] if f["role"] == "evaluation"] for l in lots}
    for lot in lots:
        ids = [f["ident"] for f in lot["fiches"]]
        for t in TIRAGES_A_V1:
            graphes[(lot["nom"], t)] = graphe_circulant(ids, DEGRE_V1, graines.generateur(f"graphe|{lot['nom']}|tirage-{t}"))
    a, b = juge_a["etiquette"], juge_b["etiquette"]
    for lot in lots:
        etapes.append({"phase": "decisive-a", "protocole": "ancien", "lot": lot["nom"], "juge": a, "tirage": 1,
                       "fiches": evaluees[lot["nom"]]})
    for t in TIRAGES_A_V1:
        for lot in lots:
            rng = graines.generateur(f"ordres|{lot['nom']}|tirage-{t}|{a}")
            etapes.append({"phase": "decisive-a", "protocole": "v2", "lot": lot["nom"], "juge": a, "tirage": t,
                           "appels": appels_paires(graphes[(lot["nom"], t)]["paires"], True, rng)})
    for lot in lots:
        etapes.append({"phase": "decisive-b", "protocole": "ancien", "lot": lot["nom"], "juge": b, "tirage": 1,
                       "fiches": evaluees[lot["nom"]]})
    for lot in lots:
        rng = graines.generateur(f"ordres|{lot['nom']}|tirage-1|{b}")
        etapes.append({"phase": "decisive-b", "protocole": "v2", "lot": lot["nom"], "juge": b, "tirage": 1,
                       "appels": appels_paires(graphes[(lot["nom"], 1)]["cycle"], False, rng)})
    if lot_reel is not None:
        familles = _familles_lot(lot_reel)
        for j in (juge_b, juge_a):
            admises = [i for i, fam in familles.items() if juge_admissible(j["famille"], fam)]
            if admises:
                etapes.append({"phase": "reel-ancien", "protocole": "ancien", "lot": "reel", "juge": j["etiquette"], "tirage": 1,
                               "fiches": admises})
        for j in (juge_b, juge_a):
            admises = [i for i, fam in familles.items() if juge_admissible(j["famille"], fam)]
            if len(admises) >= 3:
                g = graphe_circulant(admises, DEGRE_REEL_V1, graines.generateur(f"graphe|reel|{j['etiquette']}"))
                graphes[("reel", j["etiquette"])] = g
                etapes.append({"phase": "reel-v2", "protocole": "v2", "lot": "reel", "juge": j["etiquette"], "tirage": 1,
                               "appels": appels_paires(g["cycle"], False, graines.generateur(f"ordres|reel|{j['etiquette']}"))})
    return etapes, graphes


def nombre_appels(etape):
    return len(etape["fiches"]) if etape["protocole"] == "ancien" else len(etape["appels"])


def devis(etapes, juges):
    """Appels × prix par juge et par phase, et durée séquentielle (bas, haut) ; `juges` : {étiquette: {prix_usd, secondes}}."""
    appels, par_phase = {}, {}
    for e in etapes:
        n = nombre_appels(e)
        appels[e["juge"]] = appels.get(e["juge"], 0) + n
        p = par_phase.setdefault(e["phase"], {})
        p[e["juge"]] = p.get(e["juge"], 0) + n
    usd = {j: round(n * juges[j]["prix_usd"], 4) for j, n in appels.items()}
    phases = {ph: {"appels": d, "usd": round(sum(n * juges[j]["prix_usd"] for j, n in d.items()), 4)} for ph, d in par_phase.items()}
    bas = sum(n * juges[j]["secondes"][0] for j, n in appels.items())
    haut = sum(n * juges[j]["secondes"][1] for j, n in appels.items())
    return {"appels": appels, "usd": usd, "total_usd": round(sum(usd.values()), 4), "phases": phases,
            "decisif_usd": round(sum(v["usd"] for ph, v in phases.items() if ph in PHASES_DECISIVES), 4),
            "duree_h": (round(bas / 3600, 3), round(haut / 3600, 3))}


# --- course : compteur, appels, jeu des deux protocoles ------------------------------------------------------------------------


class Compteur:
    """Dépense et durée de la course. Aucun appel dont le plafond de session ne tient plus dans le reste du plafond ; projection
    de la dépense au prix observé (moyenne des appels du juge, dès 3 appels) ou, avant, au prix du plan."""

    def __init__(self, plafond_usd, duree_max_s, horloge, prix_plan):
        if not (isinstance(plafond_usd, (int, float)) and math.isfinite(plafond_usd) and plafond_usd > 0):
            raise ProtocoleRefuse(f"plafond de dépense : réel > 0 exigé (reçu {plafond_usd!r})")
        self.plafond_usd, self.duree_max_s, self.horloge = float(plafond_usd), float(duree_max_s), horloge
        self.prix_plan = dict(prix_plan)
        self.debut = horloge()
        self.depense, self.appels, self.couts = 0.0, 0, {}

    def reste(self):
        return self.plafond_usd - self.depense

    def budget_appel(self, plafond_session):
        if self.reste() < MINIMUM_APPEL_USD:
            raise ArretDevis(f"plafond de dépense atteint ({self.depense:.4f} USD sur {self.plafond_usd:g})")
        return min(float(plafond_session), self.reste())

    def verifier_duree(self):
        ecoule = self.horloge() - self.debut
        if ecoule > self.duree_max_s:
            raise ArretDuree(f"durée maximale dépassée ({ecoule:.0f} s > {self.duree_max_s:.0f} s)")

    def noter(self, juge, cout):
        if not (isinstance(cout, (int, float)) and math.isfinite(cout) and cout >= 0):
            raise ArretDevis(f"coût déclaré illisible pour {juge} ({cout!r}) : arrêt, aucun repli")
        self.depense += float(cout)
        self.appels += 1
        self.couts.setdefault(juge, []).append(float(cout))

    def prix(self, juge):
        c = self.couts.get(juge, [])
        return sum(c) / len(c) if len(c) >= 3 else self.prix_plan[juge]

    def projection(self, appels_restants):
        return sum(n * self.prix(j) for j, n in appels_restants.items())

    def exiger_projection(self, appels_restants, quoi):
        p = self.projection(appels_restants)
        if p > self.reste() + 1e-9:
            raise ArretDevis(f"projection de {quoi} : {p:.4f} USD au prix observé, au-delà du reste ({self.reste():.4f} USD)")
        return p


def appeler(adaptateur, juge, entree, dossier_session, compteur, plafond_session):
    """Un appel de juge par l'adaptateur injecté ; coût compté ; A2 : modèle servi absent ou différent du modèle demandé sur une
    réponse « ok » = arrêt. Rend (texte ou None, informations)."""
    compteur.verifier_duree()
    budget = compteur.budget_appel(plafond_session)
    t0 = compteur.horloge()
    r = adaptateur.lancer("juge_ideation", entree, dossier_session, budget, 1, modele=juge["modele"])
    duree = compteur.horloge() - t0
    compteur.noter(juge["etiquette"], r.cout_declare_usd)
    info = {"statut": r.statut, "cout_usd": float(r.cout_declare_usd), "duree_s": round(duree, 3), "modele_servi": r.modele_servi}
    if r.statut == "ok" and not modele_conforme(juge["modele"], r.modele_servi):
        raise ArretModeleServi(f"A2 : juge {juge['etiquette']} servi par {r.modele_servi!r} pour {juge['modele']!r} : arrêt, aucune "
                               "bascule sans mot de Lazar")
    texte = (r.texte_brut or r.texte_final) if r.statut == "ok" else None
    return texte, info


def _garde_validite(enregistrements, juge):
    mien = [e for e in enregistrements if e["juge"] == juge]
    if len(mien) >= VALIDITE_GARDE_APPELS:
        debut = mien[:VALIDITE_GARDE_APPELS]
        mauvais = sum(1 for e in debut if not e.get("valide"))
        if mauvais > VALIDITE_GARDE_PART * len(debut):
            raise ArretValidite(f"juge {juge} : {mauvais} réponses inexploitables sur ses {len(debut)} premiers appels de l'étape : "
                                "instrument défaillant, arrêt")


def _empreinte(texte):
    return hashlib.sha256(texte.encode("utf-8")).hexdigest() if isinstance(texte, str) else None


def jouer_etape(etape, *, lots, juges, adaptateurs, consignes, items, graines, compteur, plafond_session, interdites,
                dossier_appel, journal, avec_dossier_ancien=True):
    """Joue une étape (une suite d'appels d'un juge) et range chaque appel dans `journal` au fil de l'eau (rien n'est perdu sur
    un arrêt). `lots` : {nom: lot} ; `juges` : {étiquette: juge} ; `consignes` : {"ancien", "v2"}."""
    lot = lots[etape["lot"]]
    juge = juges[etape["juge"]]
    adaptateur = adaptateurs[juge["fournisseur"]]
    fiches = {f["ident"]: f for f in lot["fiches"]}
    familles = _familles_lot(lot)
    servi = lambda i: identifiant_servi(graines, juge["etiquette"], etape["tirage"], f"{lot['nom']}|{i}")  # noqa: E731
    enregistrements = []
    if etape["protocole"] == "ancien":
        ordre = [etape["fiches"][k] for k in graines.permutation(f"ordre-ancien|{lot['nom']}|{juge['etiquette']}|tirage-{etape['tirage']}",
                                                                  len(etape["fiches"]))]
        for i in ordre:
            if not juge_admissible(juge["famille"], familles[i]):
                raise ProtocoleRefuse(f"règle de famille : {juge['etiquette']} ({juge['famille']}) sur la fiche {i} de {sorted(familles[i])}")
            dossier = lot["dossier"] if (avec_dossier_ancien and lot["nom"] != "reel") else None
            entree = entree_ancienne(consignes["ancien"], fiches[i], servi(i), interdites, dossier=dossier)
            texte, info = appeler(adaptateur, juge, entree, dossier_appel(juge["etiquette"], etape), compteur, plafond_session)
            v = lire_verdict_ancien(texte, list(items)) if texte is not None else None
            e = dict(info, lot=lot["nom"], juge=juge["etiquette"], tirage=etape["tirage"], phase=etape["phase"], ident=i,
                     ident_servi=servi(i), verdict=v, valide=v is not None, entree_sha256=_empreinte(entree),
                     reponse_sha256=_empreinte(texte), reponse=caviarder(texte)[0] if texte is not None else None)
            journal["ancien"].append(e)
            enregistrements.append(e)
            _garde_validite(enregistrements, juge["etiquette"])
    else:
        for premier, second in etape["appels"]:
            if not juge_admissible(juge["famille"], familles[premier], familles[second]):
                raise ProtocoleRefuse(f"règle de famille : {juge['etiquette']} sur la paire ({premier}, {second})")
            p, s = (servi(premier), fiches[premier]), (servi(second), fiches[second])
            entree = entree_paire(consignes["v2"], lot["dossier"], p, s, interdites)
            texte, info = appeler(adaptateur, juge, entree, dossier_appel(juge["etiquette"], etape), compteur, plafond_session)
            lu = lire_comparaison(texte, p, s, lot["dossier"]) if texte is not None else None
            valide = bool(lu and lu["valide"])
            gagnant = (premier if lu["premier_gagne"] else second) if valide else None
            e = dict(info, lot=lot["nom"], juge=juge["etiquette"], tirage=etape["tirage"], phase=etape["phase"],
                     paire=sorted((premier, second)), premier=premier, second=second, premier_servi=p[0], second_servi=s[0],
                     valide=valide, gagnant=gagnant, premier_gagne=(lu["premier_gagne"] if valide else None),
                     critere=(lu or {}).get("critere"), motif=(lu or {}).get("motif") if lu else "aucun bloc lisible",
                     entree_sha256=_empreinte(entree), reponse_sha256=_empreinte(texte),
                     reponse=caviarder(texte)[0] if texte is not None else None)
            journal["v2"].append(e)
            enregistrements.append(e)
            _garde_validite(enregistrements, juge["etiquette"])
    return enregistrements


def executer_validation(etapes, *, materiaux, juges, adaptateurs, consignes, items, graines, compteur, plafond_session,
                        interdites, dossier_appel, lot_reel=None):
    """Joue les phases dans l'ordre. Avant chaque étape décisive : projection de la dépense des étapes décisives restantes au
    prix observé (arrêt `ArretDevis` si elle dépasse le reste). Phase descriptive (lot réel) : jouée seulement si sa projection
    tient dans le reste, sinon consignée « non jouée (budget) ». Tout arrêt porte le journal partiel."""
    lots = {l["nom"]: l for l in materiaux["lots"]}
    if lot_reel is not None:
        lots["reel"] = lot_reel
    journal = {"ancien": [], "v2": [], "phases": [], "projections": []}
    try:
        for phase in PHASES_V1:
            siennes = [e for e in etapes if e["phase"] == phase]
            if not siennes:
                continue
            if phase not in PHASES_DECISIVES:
                besoin = {}
                for e in siennes:
                    besoin[e["juge"]] = besoin.get(e["juge"], 0) + nombre_appels(e)
                p = compteur.projection(besoin)
                if p > compteur.reste():
                    journal["phases"].append({"phase": phase, "jouee": False, "motif": f"budget : projection {p:.4f} USD > reste "
                                                                                       f"{compteur.reste():.4f} USD"})
                    continue
            for k, e in enumerate(siennes):
                if phase in PHASES_DECISIVES:
                    restantes = [x for x in etapes[etapes.index(e):] if x["phase"] in PHASES_DECISIVES]
                    besoin = {}
                    for x in restantes:
                        besoin[x["juge"]] = besoin.get(x["juge"], 0) + nombre_appels(x)
                    journal["projections"].append({"avant": f"{phase}/{k}", "usd": round(compteur.exiger_projection(
                        besoin, "des étapes décisives restantes"), 4), "reste": round(compteur.reste(), 4)})
                jouer_etape(e, lots=lots, juges=juges, adaptateurs=adaptateurs, consignes=consignes, items=items, graines=graines,
                            compteur=compteur, plafond_session=plafond_session, interdites=interdites,
                            dossier_appel=dossier_appel, journal=journal)
            journal["phases"].append({"phase": phase, "jouee": True})
    except ArretJuges as erreur:
        erreur.partiel = journal
        raise
    return journal


# --- mesures ----------------------------------------------------------------------------------------------------------------


def _temoins(materiaux):
    sortie = {}
    for lot in materiaux["lots"]:
        for f in lot["fiches"]:
            sortie[f["ident"]] = dict(f, lot=lot["nom"])
    return sortie


def _mesures_ancien(journal, juge, tirage, idents, bons, mauvais):
    recs = {e["ident"]: e for e in journal["ancien"] if e["juge"] == juge and e["tirage"] == tirage and e["ident"] in idents}
    lus = {i: e["verdict"] for i, e in recs.items() if e["verdict"] is not None}
    notables = {i: bool(v["notable"]) for i, v in lus.items()}
    x = {i: float(v["x"]) for i, v in lus.items()}
    part = sum(notables.values()) / len(notables) if notables else None
    test = test_mann_whitney([x[i] for i in bons if i in x], [x[i] for i in mauvais if i in x])
    faux = [notables[i] for i in mauvais if i in notables]
    vrais = [notables[i] for i in bons if i in notables]
    return {"joues": len(recs), "presents": len(lus), "absents": len(recs) - len(lus), "part_notables": part,
            "faux_notables": sum(faux) / len(faux) if faux else None, "vrais_notables": sum(vrais) / len(vrais) if vrais else None,
            "aire": test["aire"], "p_mann_whitney": test["p"], "methode": test["methode"], "notables": notables, "x": x,
            "au_plafond": part is not None and part >= SEUIL_PLAFOND}


def _mesures_v2(journal, juges, tirage, materiaux, bons, mauvais):
    juges = set(juges)
    recs = [e for e in journal["v2"] if e["juge"] in juges and e["tirage"] == tirage and e["lot"] != "reel"]
    forces, verdicts, statuts, positions, lots = {}, {}, {}, {}, {}
    for lot in materiaux["lots"]:
        ids = [f["ident"] for f in lot["fiches"]]
        siens = [e for e in recs if e["lot"] == lot["nom"]]
        if not siens:
            continue
        bt = ajuster_bt(ids, [(e["premier"], e["second"], e["premier_gagne"]) for e in siens if e["valide"]])
        ab = next(f["ident"] for f in lot["fiches"] if f["role"] == "ancre_bonne")
        am = next(f["ident"] for f in lot["fiches"] if f["role"] == "ancre_mauvaise")
        ev = [f["ident"] for f in lot["fiches"] if f["role"] == "evaluation"]
        v = verdicts_lot(bt["forces"], ev, ab, am)
        forces.update(bt["forces"])
        verdicts.update(v["verdicts"])
        statuts[lot["nom"]] = v["statut"]
        positions[lot["nom"]] = bt["position"]
        lots[lot["nom"]] = {"converge": bt["converge"], "sans_comparaison": bt["sans_comparaison"], "plancher": v["plancher"],
                            "k": v["k"], "ancre_bonne": bt["forces"][ab], "ancre_mauvaise": bt["forces"][am]}
    if not recs:
        return {"joues": 0}
    test = test_mann_whitney([forces[i] for i in bons if i in forces], [forces[i] for i in mauvais if i in forces])
    evaluees = [i for i in bons + mauvais if i in verdicts]
    faux = [verdicts[i] for i in mauvais if i in verdicts]
    vrais = [verdicts[i] for i in bons if i in verdicts]
    valides = sum(1 for e in recs if e["valide"])
    sortie = {"joues": len(recs), "valides": valides, "validite": valides / len(recs), "forces": forces, "verdicts": verdicts,
              "statuts_lots": statuts, "position_par_lot": positions, "lots": lots, "aire": test["aire"],
              "p_mann_whitney": test["p"], "methode": test["methode"],
              "part_notables": sum(verdicts[i] for i in evaluees) / len(evaluees) if evaluees else None,
              "faux_notables": sum(faux) / len(faux) if faux else None, "vrais_notables": sum(vrais) / len(vrais) if vrais else None,
              "motifs_invalides": _compte([e["motif"] for e in recs if not e["valide"]])}
    if len(juges) == 1:
        sortie["position"] = biais_position(recs)
    return sortie


def _compte(valeurs):
    d = {}
    for v in valeurs:
        d[str(v)] = d.get(str(v), 0) + 1
    return d


def _rangs_par_classe(forces, temoins):
    """Rang centile moyen (0 = dernier du lot, 1 = premier) des fiches d'évaluation, par classe."""
    par_lot = {}
    for i, f in temoins.items():
        if f["role"] == "evaluation" and i in forces:
            par_lot.setdefault(f["lot"], []).append(i)
    classes = {}
    for ids in par_lot.values():
        ordonnes = sorted(ids, key=lambda i: forces[i])
        for r, i in enumerate(ordonnes):
            classes.setdefault(temoins[i]["classe"], []).append(r / (len(ordonnes) - 1) if len(ordonnes) > 1 else 0.5)
    return {c: round(sum(v) / len(v), 4) for c, v in classes.items()}


def mesurer(journal, materiaux, juge_a, juge_b, etapes=None, lot_reel=None):
    """Toutes les mesures de la validation, depuis le journal (rien d'autre). Les témoins d'évaluation portent la décision ; le lot
    réel est décrit seulement."""
    temoins = _temoins(materiaux)
    evaluees = [i for i, f in temoins.items() if f["role"] == "evaluation"]
    bons = [i for i in evaluees if temoins[i]["qualite"] == 1]
    mauvais = [i for i in evaluees if temoins[i]["qualite"] == 0]
    a, b = juge_a["etiquette"], juge_b["etiquette"]
    m = {"version": VERSION, "juges": {"a": a, "b": b},
         "effectifs": {"evaluees": len(evaluees), "bons": len(bons), "mauvais": len(mauvais)}}
    m["ancien"] = {a: {"1": _mesures_ancien(journal, a, 1, set(evaluees), bons, mauvais)},
                   b: {"1": _mesures_ancien(journal, b, 1, set(evaluees), bons, mauvais)}}
    m["v2"] = {a: {str(t): _mesures_v2(journal, [a], t, materiaux, bons, mauvais) for t in TIRAGES_A_V1},
               b: {"1": _mesures_v2(journal, [b], 1, materiaux, bons, mauvais)},
               "deux_juges": {"1": _mesures_v2(journal, [a, b], 1, materiaux, bons, mauvais)}}
    va1, aa1 = m["v2"][a]["1"], m["ancien"][a]["1"]
    if va1.get("joues") and aa1["presents"]:
        communs = [i for i in evaluees if i in va1["forces"] and i in aa1["x"]]
        m["comparaison_a"] = delong_difference({i: va1["forces"][i] for i in communs}, {i: aa1["x"][i] for i in communs},
                                               [i for i in bons if i in communs], [i for i in mauvais if i in communs])
    else:
        m["comparaison_a"] = {"difference": None, "p": None, "statut": "non mesurée"}
    va2 = m["v2"][a]["2"]
    if va1.get("joues") and va2.get("joues"):
        communs = [i for i in evaluees if i in va1["forces"] and i in va2["forces"]]
        m["test_retest_a"] = {"spearman": spearman([va1["forces"][i] for i in communs], [va2["forces"][i] for i in communs]),
                              "kappa_verdicts": kappa_cohen([va1["verdicts"][i] for i in communs],
                                                            [va2["verdicts"][i] for i in communs]), "n": len(communs)}
    else:
        m["test_retest_a"] = {"spearman": None, "kappa_verdicts": None, "n": 0}
    ab1 = m["ancien"][b]["1"]
    communs = [i for i in evaluees if i in aa1["notables"] and i in ab1["notables"]]
    m["accord"] = {"kappa_ancien": kappa_cohen([aa1["notables"][i] for i in communs], [ab1["notables"][i] for i in communs]),
                   "kappa_paires_v2": kappa_paires([e for e in journal["v2"] if e["juge"] == a and e["tirage"] == 1 and e["lot"] != "reel"],
                                                   [e for e in journal["v2"] if e["juge"] == b and e["tirage"] == 1 and e["lot"] != "reel"])}
    vb1 = m["v2"][b]["1"]
    if va1.get("joues") and vb1.get("joues"):
        cv = [i for i in evaluees if i in va1["verdicts"] and i in vb1["verdicts"]]
        m["accord"]["kappa_verdicts_v2"] = kappa_cohen([va1["verdicts"][i] for i in cv], [vb1["verdicts"][i] for i in cv])
    notables_par_classe = {}
    for i in evaluees:
        if i in aa1["notables"]:
            notables_par_classe.setdefault(temoins[i]["classe"], []).append(aa1["notables"][i])
    m["classes"] = {"rang_v2_a1": _rangs_par_classe(va1.get("forces", {}), temoins),
                    "notables_ancien_a1": {c: round(sum(v) / len(v), 4) for c, v in notables_par_classe.items()}}
    m["completude"] = _completude(journal, etapes) if etapes is not None else None
    if lot_reel is not None:
        m["reel"] = _mesures_reel(journal, lot_reel, juge_a, juge_b)
    return m


def _completude(journal, etapes):
    joues = {}
    for e in journal["ancien"] + journal["v2"]:
        joues[(e["phase"], e["juge"])] = joues.get((e["phase"], e["juge"]), 0) + 1
    prevus = {}
    for e in etapes:
        prevus[(e["phase"], e["juge"])] = prevus.get((e["phase"], e["juge"]), 0) + nombre_appels(e)
    return {f"{ph}/{j}": {"prevus": n, "joues": joues.get((ph, j), 0), "complet": joues.get((ph, j), 0) == n}
            for (ph, j), n in sorted(prevus.items())}


def _mesures_reel(journal, lot_reel, juge_a, juge_b):
    """Lot réel : descriptif seulement (aucun seuil ne s'y applique)."""
    sortie = {"fiches": len(lot_reel["fiches"])}
    ids = [f["ident"] for f in lot_reel["fiches"]]
    for j in (juge_a, juge_b):
        e = j["etiquette"]
        anc = [x for x in journal["ancien"] if x["lot"] == "reel" and x["juge"] == e]
        lus = {x["ident"]: x["verdict"] for x in anc if x["verdict"] is not None}
        v2 = [x for x in journal["v2"] if x["lot"] == "reel" and x["juge"] == e]
        d = {"ancien_joues": len(anc), "ancien_presents": len(lus),
             "ancien_part_notables": (sum(v["notable"] for v in lus.values()) / len(lus)) if lus else None,
             "ancien_x": {i: v["x"] for i, v in lus.items()}, "v2_joues": len(v2), "v2_valides": sum(1 for x in v2 if x["valide"])}
        if v2:
            admises = sorted({i for x in v2 for i in x["paire"]})
            bt = ajuster_bt(admises, [(x["premier"], x["second"], x["premier_gagne"]) for x in v2 if x["valide"]])
            vv = verdicts_lot(bt["forces"], admises)
            f = sorted(bt["forces"].values())
            d.update(v2_forces=bt["forces"], v2_position=bt["position"], v2_etendue=(f[-1] - f[0]) if f else None,
                     v2_verdicts=vv["verdicts"], v2_statut=vv["statut"], v2_position_mesures=biais_position(v2))
        sortie[e] = d
    lus_a = {x["ident"]: x["verdict"]["notable"] for x in journal["ancien"] if x["lot"] == "reel" and x["juge"] == juge_a["etiquette"]
             and x["verdict"] is not None}
    lus_b = {x["ident"]: x["verdict"]["notable"] for x in journal["ancien"] if x["lot"] == "reel" and x["juge"] == juge_b["etiquette"]
             and x["verdict"] is not None}
    communs = [i for i in ids if i in lus_a and i in lus_b]
    sortie["kappa_ancien_communes"] = kappa_cohen([lus_a[i] for i in communs], [lus_b[i] for i in communs])
    return sortie
