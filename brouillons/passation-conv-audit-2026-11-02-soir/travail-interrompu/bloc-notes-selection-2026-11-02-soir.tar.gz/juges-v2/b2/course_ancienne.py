class Compteur:
    """Dépense et durée de la course. Aucun appel dont le plafond de session ne tient plus dans le reste du plafond ; projection
    de la dépense au prix observé (moyenne des appels du juge, dès 3 appels) ou, avant, au prix du plan."""

    def __init__(self, plafond_usd, duree_max_s, horloge, prix_plan):
        if not (isinstance(plafond_usd, (int, float)) and math.isfinite(plafond_usd) and plafond_usd > 0):
            raise ProtocoleRefuse(f"plafond de dépense : réel > 0 exigé (reçu {plafond_usd!r})")
        self.plafond_usd, self.duree_max_s, self.horloge = float(plafond_usd), float(duree_max_s), horloge
        self.prix_plan = dict(prix_plan)
        self.debut = horloge()
        self.depense, self.appels, self.couts = 0.0, 0, {}

    def reste(self):
        return self.plafond_usd - self.depense

    def budget_appel(self, plafond_session):
        if self.reste() < MINIMUM_APPEL_USD:
            raise ArretDevis(f"plafond de dépense atteint ({self.depense:.4f} USD sur {self.plafond_usd:g})")
        return min(float(plafond_session), self.reste())

    def verifier_duree(self):
        ecoule = self.horloge() - self.debut
        if ecoule > self.duree_max_s:
            raise ArretDuree(f"durée maximale dépassée ({ecoule:.0f} s > {self.duree_max_s:.0f} s)")

    def noter(self, juge, cout):
        if not (isinstance(cout, (int, float)) and math.isfinite(cout) and cout >= 0):
            raise ArretDevis(f"coût déclaré illisible pour {juge} ({cout!r}) : arrêt, aucun repli")
        self.depense += float(cout)
        self.appels += 1
        self.couts.setdefault(juge, []).append(float(cout))

    def prix(self, juge):
        c = self.couts.get(juge, [])
        return sum(c) / len(c) if len(c) >= 3 else self.prix_plan[juge]

    def projection(self, appels_restants):
        return sum(n * self.prix(j) for j, n in appels_restants.items())

    def exiger_projection(self, appels_restants, quoi):
        p = self.projection(appels_restants)
        if p > self.reste() + 1e-9:
            raise ArretDevis(f"projection de {quoi} : {p:.4f} USD au prix observé, au-delà du reste ({self.reste():.4f} USD)")
        return p


def appeler(adaptateur, juge, entree, dossier_session, compteur, plafond_session):
    """Un appel de juge par l'adaptateur injecté ; coût compté ; A2 : modèle servi absent ou différent du modèle demandé sur une
    réponse « ok » = arrêt. Rend (texte ou None, informations)."""
    compteur.verifier_duree()
    budget = compteur.budget_appel(plafond_session)
    t0 = compteur.horloge()
    r = adaptateur.lancer("juge_ideation", entree, dossier_session, budget, 1, modele=juge["modele"])
    duree = compteur.horloge() - t0
    compteur.noter(juge["etiquette"], r.cout_declare_usd)
    info = {"statut": r.statut, "cout_usd": float(r.cout_declare_usd), "duree_s": round(duree, 3), "modele_servi": r.modele_servi}
    if r.statut == "ok" and not modele_conforme(juge["modele"], r.modele_servi):
        raise ArretModeleServi(f"A2 : juge {juge['etiquette']} servi par {r.modele_servi!r} pour {juge['modele']!r} : arrêt, aucune "
                               "bascule sans mot de Lazar")
    texte = (r.texte_brut or r.texte_final) if r.statut == "ok" else None
    return texte, info


def _garde_validite(journal, juge, protocole):
    """Sur les `VALIDITE_GARDE_APPELS` derniers appels d'un juge dans un protocole (toutes étapes confondues) : plus de
    `VALIDITE_GARDE_PART` de réponses inexploitables (illisibles, ou comparaisons nulles) arrête la course."""
    mien = [e for e in journal[protocole] if e["juge"] == juge]
    if len(mien) >= VALIDITE_GARDE_APPELS:
        fenetre = mien[-VALIDITE_GARDE_APPELS:]
        mauvais = sum(1 for e in fenetre if not e.get("valide"))
        if mauvais > VALIDITE_GARDE_PART * len(fenetre):
            raise ArretValidite(f"juge {juge}, protocole {protocole} : {mauvais} réponses inexploitables sur ses {len(fenetre)} derniers "
                                "appels : instrument défaillant, arrêt")


def _empreinte(texte):
    return hashlib.sha256(texte.encode("utf-8")).hexdigest() if isinstance(texte, str) else None


def jouer_etape(etape, *, lots, juges, adaptateurs, consignes, items, graines, compteur, plafond_session, interdites,
                dossier_appel, journal, avec_dossier_ancien=True):
    """Joue une étape (une suite d'appels d'un juge) et range chaque appel dans `journal` au fil de l'eau (rien n'est perdu sur
    un arrêt). `lots` : {nom: lot} ; `juges` : {étiquette: juge} ; `consignes` : {"ancien", "v2"}."""
    lot = lots[etape["lot"]]
    interdites, mode = lot.get("interdites", interdites), lot.get("mode_a4", "prefixe")
    juge = juges[etape["juge"]]
    adaptateur = adaptateurs[juge["fournisseur"]]
    fiches = {f["ident"]: f for f in lot["fiches"]}
    familles = _familles_lot(lot)
    servi = lambda i: identifiant_servi(graines, juge["etiquette"], etape["tirage"], f"{lot['nom']}|{i}")  # noqa: E731
    enregistrements = []
    if etape["protocole"] == "ancien":
        ordre = [etape["fiches"][k] for k in graines.permutation(f"ordre-ancien|{lot['nom']}|{juge['etiquette']}|tirage-{etape['tirage']}",
                                                                  len(etape["fiches"]))]
        for i in ordre:
            if not juge_admissible(juge["famille"], familles[i]):
                raise ProtocoleRefuse(f"règle de famille : {juge['etiquette']} ({juge['famille']}) sur la fiche {i} de {sorted(familles[i])}")
            dossier = lot["dossier"] if (avec_dossier_ancien and lot["nom"] != "reel") else None
            try:
                entree = entree_ancienne(consignes["ancien"], fiches[i], servi(i), interdites, dossier=dossier, mode=mode)
            except EtiquetteDansEntree as e:
                raise ArretJuges(f"{e} (lot {lot['nom']}, fiche {i})") from None
            texte, info = appeler(adaptateur, juge, entree, dossier_appel(juge["etiquette"], etape), compteur, plafond_session)
            v = lire_verdict_ancien(texte, list(items)) if texte is not None else None
            e = dict(info, lot=lot["nom"], juge=juge["etiquette"], tirage=etape["tirage"], phase=etape["phase"], ident=i,
                     ident_servi=servi(i), verdict=v, valide=v is not None, entree_sha256=_empreinte(entree),
                     reponse_sha256=_empreinte(texte), reponse=caviarder(texte)[0] if texte is not None else None)
            journal["ancien"].append(e)
            enregistrements.append(e)
            _garde_validite(journal, juge["etiquette"], "ancien")
    else:
        for premier, second in etape["appels"]:
            if not juge_admissible(juge["famille"], familles[premier], familles[second]):
                raise ProtocoleRefuse(f"règle de famille : {juge['etiquette']} sur la paire ({premier}, {second})")
            p, s = (servi(premier), fiches[premier]), (servi(second), fiches[second])
            try:
                entree = entree_paire(consignes["v2"], lot["dossier"], p, s, interdites, mode=mode)
            except EtiquetteDansEntree as e:
                raise ArretJuges(f"{e} (lot {lot['nom']}, paire {premier}, {second})") from None
            texte, info = appeler(adaptateur, juge, entree, dossier_appel(juge["etiquette"], etape), compteur, plafond_session)
            lu = lire_comparaison(texte, p, s, lot["dossier"]) if texte is not None else None
            valide = bool(lu and lu["valide"])
            gagnant = (premier if lu["premier_gagne"] else second) if valide else None
            e = dict(info, lot=lot["nom"], juge=juge["etiquette"], tirage=etape["tirage"], phase=etape["phase"],
                     paire=sorted((premier, second)), premier=premier, second=second, premier_servi=p[0], second_servi=s[0],
                     valide=valide, gagnant=gagnant, premier_gagne=(lu["premier_gagne"] if valide else None),
                     critere=(lu or {}).get("critere"), motif=(lu or {}).get("motif") if lu else "aucun bloc lisible",
                     entree_sha256=_empreinte(entree), reponse_sha256=_empreinte(texte),
                     reponse=caviarder(texte)[0] if texte is not None else None)
            journal["v2"].append(e)
            enregistrements.append(e)
            _garde_validite(journal, juge["etiquette"], "v2")
    return enregistrements


def executer_validation(etapes, *, materiaux, juges, adaptateurs, consignes, items, graines, compteur, plafond_session,
                        interdites, dossier_appel, lot_reel=None):
    """Joue les phases dans l'ordre. Avant chaque étape décisive : projection de la dépense des étapes décisives restantes au
    prix observé (arrêt `ArretDevis` si elle dépasse le reste). Phase descriptive (lot réel) : jouée seulement si sa projection
    tient dans le reste, sinon consignée « non jouée (budget) ». Tout arrêt porte le journal partiel."""
    lots = {l["nom"]: l for l in materiaux["lots"]}
    if lot_reel is not None:
        lots["reel"] = lot_reel
    journal = {"ancien": [], "v2": [], "phases": [], "projections": []}
    try:
        for phase in PHASES_V1:
            siennes = [e for e in etapes if e["phase"] == phase]
            if not siennes:
                continue
            if phase not in PHASES_DECISIVES:
                besoin = {}
                for e in siennes:
                    besoin[e["juge"]] = besoin.get(e["juge"], 0) + nombre_appels(e)
                p = compteur.projection(besoin)
                if p > compteur.reste():
                    journal["phases"].append({"phase": phase, "jouee": False, "motif": f"budget : projection {p:.4f} USD > reste "
                                                                                       f"{compteur.reste():.4f} USD"})
                    continue
            for k, e in enumerate(siennes):
                if phase in PHASES_DECISIVES:
                    restantes = [x for x in etapes[etapes.index(e):] if x["phase"] in PHASES_DECISIVES]
                    besoin = {}
                    for x in restantes:
                        besoin[x["juge"]] = besoin.get(x["juge"], 0) + nombre_appels(x)
                    journal["projections"].append({"avant": f"{phase}/{k}", "usd": round(compteur.exiger_projection(
                        besoin, "des étapes décisives restantes"), 4), "reste": round(compteur.reste(), 4)})
                jouer_etape(e, lots=lots, juges=juges, adaptateurs=adaptateurs, consignes=consignes, items=items, graines=graines,
                            compteur=compteur, plafond_session=plafond_session, interdites=interdites,
                            dossier_appel=dossier_appel, journal=journal)
            journal["phases"].append({"phase": phase, "jouee": True})
    except ArretJuges as erreur:
        erreur.partiel = journal
        raise
    except Exception as erreur:  # noqa: BLE001 — toute autre erreur (relais, adaptateur) arrête la course, journal gardé
        raise ArretJuges(f"erreur pendant la course : {type(erreur).__name__} : {str(erreur)[:500]}", journal) from erreur
    return journal


# --- mesures ----------------------------------------------------------------------------------------------------------------
