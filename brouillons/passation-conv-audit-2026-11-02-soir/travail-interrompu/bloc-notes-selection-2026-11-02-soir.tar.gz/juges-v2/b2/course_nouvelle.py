class ArretInfrastructure(ArretJuges):
    """Pertes d'infrastructure (relais injoignable après attente, délai dépassé, réponse non conforme du relais) au-delà de la
    part admise dans la phase décisive de A : arrêt, issue I0 « infrastructure »."""


class Compteur:
    """Dépense et durée de la course. Aucun appel dont le budget ne tient plus dans le reste du plafond **ni dans le reste de la
    part de son juge** ; projection de la dépense au prix observé (moyenne des appels **à coût connu** du juge, dès 3 appels) ou,
    avant, au prix du plan, contre le reste du plafond et contre le reste de chaque part ; coûts inconnus (commande muette :
    plafond de session compté, jamais en silence) comptés à part, hors du prix observé ; refus de dépense (code 4) : rien compté.
    `dormir(secondes)` : attente sur relais injoignable, injectée (essais) ; `horloge()` : secondes."""

    def __init__(self, plafond_usd, duree_max_s, horloge, prix_plan, parts=None, dormir=None):
        if not (isinstance(plafond_usd, (int, float)) and math.isfinite(plafond_usd) and plafond_usd > 0):
            raise ProtocoleRefuse(f"plafond de dépense : réel > 0 exigé (reçu {plafond_usd!r})")
        if not (isinstance(duree_max_s, (int, float)) and math.isfinite(duree_max_s) and duree_max_s > 0):
            raise ProtocoleRefuse(f"durée maximale : réel > 0 exigé (reçu {duree_max_s!r})")
        self.plafond_usd, self.duree_max_s, self.horloge = float(plafond_usd), float(duree_max_s), horloge
        self.prix_plan = dict(prix_plan)
        self.parts = {j: float(v) for j, v in (parts or {j: plafond_usd for j in prix_plan}).items()}
        for j in self.prix_plan:
            if j not in self.parts or not self.parts[j] > 0:
                raise ProtocoleRefuse(f"part de dépense du juge {j} : réel > 0 exigé")
        self.dormir = dormir if dormir is not None else time.sleep
        self.debut = horloge()
        self.depense, self.appels, self.couts = 0.0, 0, {}
        self.depense_par_juge = {j: 0.0 for j in self.prix_plan}
        self.cout_inconnu = {j: {"appels": 0, "usd": 0.0} for j in self.prix_plan}
        self.attentes = {j: {"nombre": 0, "secondes": 0.0} for j in self.prix_plan}

    def reste(self):
        return self.plafond_usd - self.depense

    def reste_part(self, juge):
        return self.parts[juge] - self.depense_par_juge[juge]

    def budget_appel(self, plafond_session, juge=None):
        if self.reste() < MINIMUM_APPEL_USD:
            raise ArretDevis(f"plafond de dépense atteint ({self.depense:.4f} USD sur {self.plafond_usd:g})")
        budget = min(float(plafond_session), self.reste())
        if juge is not None:
            if self.reste_part(juge) < MINIMUM_APPEL_USD:
                raise ArretDevis(f"part du juge {juge} atteinte ({self.depense_par_juge[juge]:.4f} USD sur {self.parts[juge]:g})")
            budget = min(budget, self.reste_part(juge))
        return budget

    def verifier_duree(self):
        ecoule = self.horloge() - self.debut
        if ecoule > self.duree_max_s:
            raise ArretDuree(f"durée maximale dépassée ({ecoule:.0f} s > {self.duree_max_s:.0f} s)")

    def noter(self, juge, cout, connu=True):
        """Un appel compté : `connu` faux = coût inconnu (plafond de session compté par l'adaptateur) : dépense comptée, mais hors
        du prix observé et compté à part."""
        if not (isinstance(cout, (int, float)) and math.isfinite(cout) and cout >= 0):
            raise ArretDevis(f"coût déclaré illisible pour {juge} ({cout!r}) : arrêt, aucun repli")
        self.depense += float(cout)
        self.depense_par_juge[juge] = self.depense_par_juge.get(juge, 0.0) + float(cout)
        self.appels += 1
        if connu:
            self.couts.setdefault(juge, []).append(float(cout))
        else:
            self.cout_inconnu[juge]["appels"] += 1
            self.cout_inconnu[juge]["usd"] = round(self.cout_inconnu[juge]["usd"] + float(cout), 6)

    def attendre(self, juge, secondes):
        self.attentes[juge]["nombre"] += 1
        self.attentes[juge]["secondes"] += float(secondes)
        self.dormir(float(secondes))

    def prix(self, juge):
        c = self.couts.get(juge, [])
        return sum(c) / len(c) if len(c) >= 3 else self.prix_plan[juge]

    def projection(self, appels_restants):
        return sum(n * self.prix(j) for j, n in appels_restants.items())

    def exiger_projection(self, appels_restants, quoi):
        """Projection au prix observé contre le reste du plafond et contre le reste de la part de chaque juge."""
        p = self.projection(appels_restants)
        if p > self.reste() + 1e-9:
            raise ArretDevis(f"projection de {quoi} : {p:.4f} USD au prix observé, au-delà du reste ({self.reste():.4f} USD)")
        for j, n in appels_restants.items():
            pj = n * self.prix(j)
            if pj > self.reste_part(j) + 1e-9:
                raise ArretDevis(f"projection de {quoi} pour {j} : {pj:.4f} USD au prix observé, au-delà du reste de sa part "
                                 f"({self.reste_part(j):.4f} USD sur {self.parts[j]:g})")
        return p

    def bilan(self):
        return {"depense_usd": round(self.depense, 4), "appels": self.appels, "depense_par_juge_usd": {j: round(v, 4) for j, v in self.depense_par_juge.items()},
                "cout_inconnu": self.cout_inconnu, "attentes": self.attentes, "prix_observe": {j: round(self.prix(j), 6) for j in self.prix_plan}}


def classer_resultat(r, modele):
    """Lit le résultat d'un adaptateur comme réponse du juge ou comme événement du relais (contre-lecture v1, B2) :
    - « reponse » : statut « ok », modèle servi conforme ;
    - « a2 » : modèle servi absent ou différent sur une réponse « ok », ou statut « refus » que la commande v56 rend pour un
      modèle servi absent ou différent (`refus.evenement` commande.modele_servi, commande.modele_servi_absent,
      commande.modele_demande_inconnu) → arrêt A2 ;
    - « refus_modele » : la commande dit un refus du modèle lui-même (`commande.refus`) : réponse du juge, inexploitable ;
    - « budget » : code 4 (refus du registre de dépense avant l'envoi) ou statut « budget_depasse » → arrêt « dépense » ;
    - « relais » : code 3 (relais ou interface injoignable) ; à coût plancher, l'appel est repris après attente ;
    - « delai » : code 6 ou délai de la commande dépassé ; « non_conforme » : code 5 ; « autre » : tout autre échec.
    Rend {genre, code, motif}."""
    erreur = r.erreur if isinstance(r.erreur, str) else ""
    m = _CODE_SORTIE.search(erreur)
    code = int(m.group(1)) if m else None
    if r.statut == "ok":
        if not modele_conforme(modele, r.modele_servi):
            return {"genre": "a2", "code": code, "motif": f"modèle servi {r.modele_servi!r} pour {modele!r} sur une réponse « ok »"}
        return {"genre": "reponse", "code": code, "motif": None}
    if r.statut == "refus":
        ev = (r.refus or {}).get("evenement") if isinstance(r.refus, dict) else None
        if ev in ("commande.modele_servi", "commande.modele_servi_absent", "commande.modele_demande_inconnu"):
            return {"genre": "a2", "code": code, "motif": f"statut « refus » : {(r.refus or {}).get('motif')}"}
        return {"genre": "refus_modele", "code": code, "motif": "refus du modèle (statut « refus » de la commande)"}
    if r.statut == "budget_depasse" or code == 4:
        return {"genre": "budget", "code": code, "motif": "refus de dépense : " + (erreur[:200] or "statut budget_depasse")}
    if code in CODES_DE_SORTIE:
        return {"genre": CODES_DE_SORTIE[code], "code": code, "motif": erreur[:200]}
    if _DELAI.search(erreur):
        return {"genre": "delai", "code": code, "motif": erreur[:200]}
    return {"genre": "autre", "code": code, "motif": (erreur or r.statut)[:200]}


def appeler(adaptateur, juge, entree, dossier_session, compteur, plafond_session, journal=None, contexte=None):
    """Un appel de juge par l'adaptateur injecté. Rend (texte ou None, informations) : le texte d'une réponse (lue ensuite par le
    protocole), ou None pour un refus du modèle (réponse du juge, inexploitable) ou une **perte d'infrastructure** (consignée dans
    `journal["pertes"]` avec sa cause, jamais comptée comme réponse du juge). Arrêts : A2 (modèle servi absent ou différent, y
    compris par le statut « refus » de la commande v56) ; refus de dépense (code 4, « budget_depasse ») sans coût fictif ; plafond,
    part ou durée. Relais injoignable (code 3 à coût plancher) : même appel repris après attente (15, 30, 60, 120 puis 300 s), au
    plus 30 minutes cumulées par appel, puis perte « relais »."""
    attente_cumulee, rang = 0.0, 0
    while True:
        compteur.verifier_duree()
        budget = compteur.budget_appel(plafond_session, juge["etiquette"])
        t0 = compteur.horloge()
        r = adaptateur.lancer("juge_ideation", entree, dossier_session, budget, 1, modele=juge["modele"])
        duree = compteur.horloge() - t0
        c = classer_resultat(r, juge["modele"])
        cout, inconnu = float(r.cout_declare_usd or 0.0), bool(getattr(r, "cout_inconnu", False))
        info = {"statut": r.statut, "cout_usd": cout, "cout_inconnu": inconnu, "duree_s": round(duree, 3), "modele_servi": r.modele_servi,
                "code_sortie": c["code"], "genre": c["genre"]}
        if c["genre"] == "a2":
            compteur.noter(juge["etiquette"], 0.0 if inconnu else cout, connu=not inconnu)
            raise ArretModeleServi(f"A2 : juge {juge['etiquette']} : {c['motif']} : arrêt, aucune bascule sans mot de Lazar")
        if c["genre"] == "budget":
            if not inconnu and r.statut == "budget_depasse":
                compteur.noter(juge["etiquette"], cout)  # l'appel a été fait et facturé ; la réponse n'est pas servie
            raise ArretDevis(f"refus de dépense du relais pour {juge['etiquette']} ({c['motif']}) : arrêt « dépense », aucun coût "
                             "fictif compté")
        compteur.noter(juge["etiquette"], cout, connu=not inconnu)
        if c["genre"] == "reponse":
            return (r.texte_brut or r.texte_final), info
        if c["genre"] == "refus_modele":
            return None, dict(info, motif=c["motif"])
        if c["genre"] == "relais" and cout <= COUT_PLANCHER_USD and not inconnu and attente_cumulee < ATTENTE_MAX_PAR_APPEL_S:
            attente = min(ATTENTES_RELAIS_S[min(rang, len(ATTENTES_RELAIS_S) - 1)], ATTENTE_MAX_PAR_APPEL_S - attente_cumulee)
            rang += 1
            attente_cumulee += attente
            if journal is not None:
                journal.setdefault("attentes", []).append(dict(info, attente_s=attente, **(contexte or {})))
            compteur.attendre(juge["etiquette"], attente)
            continue
        perte = dict(info, cause=c["genre"], motif=c["motif"], attente_cumulee_s=attente_cumulee, **(contexte or {}))
        if journal is not None:
            journal.setdefault("pertes", []).append(perte)
        return None, dict(info, perte=True, cause=c["genre"], motif=c["motif"])


def _garde_validite(journal, juge, protocole):
    """Sur les `VALIDITE_GARDE_APPELS` derniers appels d'un juge dans un protocole (toutes étapes confondues) : plus de
    `VALIDITE_GARDE_PART` de réponses inexploitables (illisibles, refus du modèle, ou comparaisons nulles) arrête la course.
    Les pertes d'infrastructure ne sont pas des réponses : elles n'entrent pas ici."""
    mien = [e for e in journal[protocole] if e["juge"] == juge]
    if len(mien) >= VALIDITE_GARDE_APPELS:
        fenetre = mien[-VALIDITE_GARDE_APPELS:]
        mauvais = sum(1 for e in fenetre if not e.get("valide"))
        if mauvais > VALIDITE_GARDE_PART * len(fenetre):
            raise ArretValidite(f"juge {juge}, protocole {protocole} : {mauvais} réponses inexploitables sur ses {len(fenetre)} derniers "
                                "appels : instrument défaillant, arrêt")


def _garde_pertes(journal, phase, juge, prevus):
    """Pertes d'infrastructure de la phase décisive de A au-delà de `PERTES_MAX_PART` des appels prévus : arrêt."""
    if phase != "decisive-a" or not prevus:
        return
    pertes = sum(1 for p in journal.get("pertes", []) if p.get("phase") == phase and p.get("juge") == juge)
    if pertes > PERTES_MAX_PART * prevus:
        raise ArretInfrastructure(f"phase {phase}, juge {juge} : {pertes} appels perdus par l'infrastructure sur {prevus} prévus "
                                  f"(> {PERTES_MAX_PART:.0%}) : arrêt « infrastructure »")


def _empreinte(texte):
    return hashlib.sha256(texte.encode("utf-8")).hexdigest() if isinstance(texte, str) else None


def jouer_etape(etape, *, lots, juges, adaptateurs, consignes, items, graines, compteur, plafond_session, interdites,
                dossier_appel, journal, prevus=None):
    """Joue une étape (une suite d'appels d'un juge) et range chaque appel dans `journal` au fil de l'eau (rien n'est perdu sur
    un arrêt) : réponses dans `journal["ancien"]` ou `journal["v2"]`, pertes d'infrastructure dans `journal["pertes"]`. `lots` :
    {nom: lot} ; `juges` : {étiquette: juge} ; `consignes` : {"ancien", "v2"} ; `prevus` : {phase/juge: appels prévus} (garde des
    pertes). Une étape ancienne avec `dossier: False` sert la fiche sans dossier (bras « sans dossier » : graines et identifiants
    propres)."""
    lot = lots[etape["lot"]]
    interdites, mode = lot.get("interdites", interdites), lot.get("mode_a4", "prefixe")
    juge = juges[etape["juge"]]
    adaptateur = adaptateurs[juge["fournisseur"]]
    fiches = {f["ident"]: f for f in lot["fiches"]}
    familles = _familles_lot(lot)
    sans_dossier = etape["protocole"] == "ancien" and etape.get("dossier") is False
    bras = "sans_dossier" if sans_dossier else "avec_dossier"
    if sans_dossier:
        servi = lambda i: identifiant_servi(graines, juge["etiquette"], f"sans-dossier", f"{lot['nom']}|{i}")  # noqa: E731
    else:
        servi = lambda i: identifiant_servi(graines, juge["etiquette"], etape["tirage"], f"{lot['nom']}|{i}")  # noqa: E731
    cle_prevus = f"{etape['phase']}/{juge['etiquette']}"
    n_prevus = (prevus or {}).get(cle_prevus, 0)
    contexte = {"phase": etape["phase"], "juge": juge["etiquette"], "lot": lot["nom"], "tirage": etape["tirage"], "protocole": etape["protocole"]}
    enregistrements = []
    if etape["protocole"] == "ancien":
        tache = (f"ordre-ancien-sans-dossier|{lot['nom']}|{juge['etiquette']}" if sans_dossier
                 else f"ordre-ancien|{lot['nom']}|{juge['etiquette']}|tirage-{etape['tirage']}")
        ordre = [etape["fiches"][k] for k in graines.permutation(tache, len(etape["fiches"]))]
        for i in ordre:
            if not juge_admissible(juge["famille"], familles[i]):
                raise ProtocoleRefuse(f"règle de famille : {juge['etiquette']} ({juge['famille']}) sur la fiche {i} de {sorted(familles[i])}")
            dossier = lot["dossier"] if (not sans_dossier and lot["nom"] != "reel") else None
            try:
                entree = entree_ancienne(consignes["ancien"], fiches[i], servi(i), interdites, dossier=dossier, mode=mode)
            except EtiquetteDansEntree as e:
                raise ArretJuges(f"{e} (lot {lot['nom']}, fiche {i})") from None
            texte, info = appeler(adaptateur, juge, entree, dossier_appel(juge["etiquette"], etape), compteur, plafond_session,
                                  journal=journal, contexte=dict(contexte, ident=i))
            if info.get("perte"):
                _garde_pertes(journal, etape["phase"], juge["etiquette"], n_prevus)
                continue
            v = lire_verdict_ancien(texte, list(items)) if texte is not None else None
            e = dict(info, lot=lot["nom"], juge=juge["etiquette"], tirage=etape["tirage"], phase=etape["phase"], bras=bras, ident=i,
                     ident_servi=servi(i), verdict=v, valide=v is not None, entree_sha256=_empreinte(entree),
                     reponse_sha256=_empreinte(texte), reponse=caviarder(texte)[0] if texte is not None else None)
            journal["ancien"].append(e)
            enregistrements.append(e)
            _garde_validite(journal, juge["etiquette"], "ancien")
    else:
        for premier, second in etape["appels"]:
            if not juge_admissible(juge["famille"], familles[premier], familles[second]):
                raise ProtocoleRefuse(f"règle de famille : {juge['etiquette']} sur la paire ({premier}, {second})")
            p, s = (servi(premier), fiches[premier]), (servi(second), fiches[second])
            try:
                entree = entree_paire(consignes["v2"], lot["dossier"], p, s, interdites, mode=mode)
            except EtiquetteDansEntree as e:
                raise ArretJuges(f"{e} (lot {lot['nom']}, paire {premier}, {second})") from None
            texte, info = appeler(adaptateur, juge, entree, dossier_appel(juge["etiquette"], etape), compteur, plafond_session,
                                  journal=journal, contexte=dict(contexte, paire=sorted((premier, second))))
            if info.get("perte"):
                _garde_pertes(journal, etape["phase"], juge["etiquette"], n_prevus)
                continue
            lu = lire_comparaison(texte, p, s, lot["dossier"]) if texte is not None else None
            valide = bool(lu and lu["valide"])
            gagnant = (premier if lu["premier_gagne"] else second) if valide else None
            e = dict(info, lot=lot["nom"], juge=juge["etiquette"], tirage=etape["tirage"], phase=etape["phase"],
                     paire=sorted((premier, second)), premier=premier, second=second, premier_servi=p[0], second_servi=s[0],
                     valide=valide, gagnant=gagnant, premier_gagne=(lu["premier_gagne"] if valide else None),
                     critere=(lu or {}).get("critere"), motif=(lu or {}).get("motif") if lu else info.get("motif", "aucun bloc lisible"),
                     entree_sha256=_empreinte(entree), reponse_sha256=_empreinte(texte),
                     reponse=caviarder(texte)[0] if texte is not None else None)
            journal["v2"].append(e)
            enregistrements.append(e)
            _garde_validite(journal, juge["etiquette"], "v2")
    return enregistrements


def appels_prevus(etapes):
    """{phase/juge: appels prévus} (garde des pertes, complétude)."""
    prevus = {}
    for e in etapes:
        cle = f"{e['phase']}/{e['juge']}"
        prevus[cle] = prevus.get(cle, 0) + nombre_appels(e)
    return prevus


def executer_validation(etapes, *, materiaux, juges, adaptateurs, consignes, items, graines, compteur, plafond_session,
                        interdites, dossier_appel, lot_reel=None):
    """Joue les phases dans l'ordre. Avant chaque étape projetée (phases décisives et bras sans dossier) : projection de la
    dépense des étapes projetées restantes au prix observé, contre le reste du plafond et de chaque part (arrêt `ArretDevis`
    sinon). Phase descriptive (lot réel) : jouée seulement si sa projection tient, sinon consignée « non jouée (budget) ». Tout
    arrêt porte le journal partiel."""
    lots = {l["nom"]: l for l in materiaux["lots"]}
    if lot_reel is not None:
        lots["reel"] = lot_reel
    journal = {"ancien": [], "v2": [], "pertes": [], "attentes": [], "phases": [], "projections": []}
    prevus = appels_prevus(etapes)
    try:
        for phase in PHASES_V1:
            siennes = [e for e in etapes if e["phase"] == phase]
            if not siennes:
                continue
            if phase not in PHASES_PROJETEES:
                besoin = {}
                for e in siennes:
                    besoin[e["juge"]] = besoin.get(e["juge"], 0) + nombre_appels(e)
                p = compteur.projection(besoin)
                tient = p <= compteur.reste() and all(n * compteur.prix(j) <= compteur.reste_part(j) for j, n in besoin.items())
                if not tient:
                    journal["phases"].append({"phase": phase, "jouee": False, "motif": f"budget : projection {p:.4f} USD au-delà du reste "
                                                                                       f"({compteur.reste():.4f} USD) ou d'une part"})
                    continue
            for k, e in enumerate(siennes):
                if phase in PHASES_PROJETEES:
                    restantes = [x for x in etapes[etapes.index(e):] if x["phase"] in PHASES_PROJETEES]
                    besoin = {}
                    for x in restantes:
                        besoin[x["juge"]] = besoin.get(x["juge"], 0) + nombre_appels(x)
                    journal["projections"].append({"avant": f"{phase}/{k}", "usd": round(compteur.exiger_projection(
                        besoin, "des étapes projetées restantes"), 4), "reste": round(compteur.reste(), 4)})
                jouer_etape(e, lots=lots, juges=juges, adaptateurs=adaptateurs, consignes=consignes, items=items, graines=graines,
                            compteur=compteur, plafond_session=plafond_session, interdites=interdites,
                            dossier_appel=dossier_appel, journal=journal, prevus=prevus)
            journal["phases"].append({"phase": phase, "jouee": True})
    except ArretJuges as erreur:
        erreur.partiel = journal
        raise
    except Exception as erreur:  # noqa: BLE001 — toute autre erreur (relais, adaptateur) arrête la course, journal gardé
        raise ArretJuges(f"erreur pendant la course : {type(erreur).__name__} : {str(erreur)[:500]}", journal) from erreur
    journal["compteur"] = compteur.bilan()
    return journal


