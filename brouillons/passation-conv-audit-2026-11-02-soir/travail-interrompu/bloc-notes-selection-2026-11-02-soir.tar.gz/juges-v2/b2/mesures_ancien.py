# --- mesures ----------------------------------------------------------------------------------------------------------------


def _temoins(materiaux):
    sortie = {}
    for lot in materiaux["lots"]:
        for f in lot["fiches"]:
            sortie[f["ident"]] = dict(f, lot=lot["nom"])
    return sortie


def _mesures_ancien(journal, juge, tirage, idents, bons, mauvais):
    recs = {e["ident"]: e for e in journal["ancien"] if e["juge"] == juge and e["tirage"] == tirage and e["ident"] in idents}
    lus = {i: e["verdict"] for i, e in recs.items() if e["verdict"] is not None}
    notables = {i: bool(v["notable"]) for i, v in lus.items()}
    x = {i: float(v["x"]) for i, v in lus.items()}
    part = sum(notables.values()) / len(notables) if notables else None
    test = test_mann_whitney([x[i] for i in bons if i in x], [x[i] for i in mauvais if i in x])
    faux = [notables[i] for i in mauvais if i in notables]
    vrais = [notables[i] for i in bons if i in notables]
    return {"joues": len(recs), "presents": len(lus), "absents": len(recs) - len(lus), "part_notables": part,
            "faux_notables": sum(faux) / len(faux) if faux else None, "vrais_notables": sum(vrais) / len(vrais) if vrais else None,
            "aire": test["aire"], "p_mann_whitney": test["p"], "methode": test["methode"], "notables": notables, "x": x,
            "au_plafond": part is not None and part >= SEUIL_PLAFOND}


def _mesures_v2(journal, juges, tirage, materiaux, bons, mauvais):
    juges = set(juges)
    recs = [e for e in journal["v2"] if e["juge"] in juges and e["tirage"] == tirage and e["lot"] != "reel"]
    forces, verdicts, statuts, positions, lots = {}, {}, {}, {}, {}
    for lot in materiaux["lots"]:
        ids = [f["ident"] for f in lot["fiches"]]
        siens = [e for e in recs if e["lot"] == lot["nom"]]
        if not siens:
            continue
        bt = ajuster_bt(ids, [(e["premier"], e["second"], e["premier_gagne"]) for e in siens if e["valide"]])
        ab = next(f["ident"] for f in lot["fiches"] if f["role"] == "ancre_bonne")
        am = next(f["ident"] for f in lot["fiches"] if f["role"] == "ancre_mauvaise")
        ev = [f["ident"] for f in lot["fiches"] if f["role"] == "evaluation"]
        v = verdicts_lot(bt["forces"], ev, ab, am)
        forces.update(bt["forces"])
        verdicts.update(v["verdicts"])
        statuts[lot["nom"]] = v["statut"]
        positions[lot["nom"]] = bt["position"]
        lots[lot["nom"]] = {"converge": bt["converge"], "sans_comparaison": bt["sans_comparaison"], "plancher": v["plancher"],
                            "k": v["k"], "ancre_bonne": bt["forces"][ab], "ancre_mauvaise": bt["forces"][am]}
    if not recs:
        return {"joues": 0}
    test = test_mann_whitney([forces[i] for i in bons if i in forces], [forces[i] for i in mauvais if i in forces])
    evaluees = [i for i in bons + mauvais if i in verdicts]
    faux = [verdicts[i] for i in mauvais if i in verdicts]
    vrais = [verdicts[i] for i in bons if i in verdicts]
    valides = sum(1 for e in recs if e["valide"])
    sortie = {"joues": len(recs), "valides": valides, "validite": valides / len(recs), "forces": forces, "verdicts": verdicts,
              "statuts_lots": statuts, "position_par_lot": positions, "lots": lots, "aire": test["aire"],
              "p_mann_whitney": test["p"], "methode": test["methode"],
              "part_notables": sum(verdicts[i] for i in evaluees) / len(evaluees) if evaluees else None,
              "faux_notables": sum(faux) / len(faux) if faux else None, "vrais_notables": sum(vrais) / len(vrais) if vrais else None,
              "motifs_invalides": _compte([e["motif"] for e in recs if not e["valide"]])}
    if len(juges) == 1:
        sortie["position"] = biais_position(recs)
    return sortie


def _compte(valeurs):
    d = {}
    for v in valeurs:
        d[str(v)] = d.get(str(v), 0) + 1
    return d


def _rangs_par_classe(forces, temoins):
    """Rang centile moyen (0 = dernier du lot, 1 = premier) des fiches d'évaluation, par classe."""
    par_lot = {}
    for i, f in temoins.items():
        if f["role"] == "evaluation" and i in forces:
            par_lot.setdefault(f["lot"], []).append(i)
    classes = {}
    for ids in par_lot.values():
        ordonnes = sorted(ids, key=lambda i: forces[i])
        for r, i in enumerate(ordonnes):
            classes.setdefault(temoins[i]["classe"], []).append(r / (len(ordonnes) - 1) if len(ordonnes) > 1 else 0.5)
    return {c: round(sum(v) / len(v), 4) for c, v in classes.items()}


def mesurer(journal, materiaux, juge_a, juge_b, etapes=None, lot_reel=None):
    """Toutes les mesures de la validation, depuis le journal (rien d'autre). Les témoins d'évaluation portent la décision ; le lot
    réel est décrit seulement."""
    temoins = _temoins(materiaux)
    evaluees = [i for i, f in temoins.items() if f["role"] == "evaluation"]
    bons = [i for i in evaluees if temoins[i]["qualite"] == 1]
    mauvais = [i for i in evaluees if temoins[i]["qualite"] == 0]
    a, b = juge_a["etiquette"], juge_b["etiquette"]
    m = {"version": VERSION, "juges": {"a": a, "b": b},
         "effectifs": {"evaluees": len(evaluees), "bons": len(bons), "mauvais": len(mauvais)}}
    m["ancien"] = {a: {"1": _mesures_ancien(journal, a, 1, set(evaluees), bons, mauvais)},
                   b: {"1": _mesures_ancien(journal, b, 1, set(evaluees), bons, mauvais)}}
    m["v2"] = {a: {str(t): _mesures_v2(journal, [a], t, materiaux, bons, mauvais) for t in TIRAGES_A_V1},
               b: {"1": _mesures_v2(journal, [b], 1, materiaux, bons, mauvais)},
               "deux_juges": {"1": _mesures_v2(journal, [a, b], 1, materiaux, bons, mauvais)}}
    va1, aa1 = m["v2"][a]["1"], m["ancien"][a]["1"]
    if va1.get("joues") and aa1["presents"]:
        communs = [i for i in evaluees if i in va1["forces"] and i in aa1["x"]]
        m["comparaison_a"] = delong_difference({i: va1["forces"][i] for i in communs}, {i: aa1["x"][i] for i in communs},
                                               [i for i in bons if i in communs], [i for i in mauvais if i in communs])
    else:
        m["comparaison_a"] = {"difference": None, "p": None, "statut": "non mesurée"}
    va2 = m["v2"][a]["2"]
    m["position_a"] = biais_position([e for e in journal["v2"] if e["juge"] == a and e["lot"] != "reel"])
    if va1.get("joues") and va2.get("joues"):
        communs = [i for i in evaluees if i in va1["forces"] and i in va2["forces"]]
        m["test_retest_a"] = {"spearman": spearman([va1["forces"][i] for i in communs], [va2["forces"][i] for i in communs]),
                              "plafond_binaire": plafond_spearman_binaire((len(bons), len(mauvais))),
                              "aire_tirage_2": va2.get("aire"), "p_tirage_2": va2.get("p_mann_whitney"),
                              "kappa_verdicts": kappa_cohen([va1["verdicts"][i] for i in communs],
                                                            [va2["verdicts"][i] for i in communs]), "n": len(communs)}
    else:
        m["test_retest_a"] = {"spearman": None, "plafond_binaire": None, "aire_tirage_2": None, "p_tirage_2": None,
                              "kappa_verdicts": None, "n": 0}
    ab1 = m["ancien"][b]["1"]
    communs = [i for i in evaluees if i in aa1["notables"] and i in ab1["notables"]]
    qualite = {i: f["qualite"] for i, f in temoins.items()}
    ea = [e for e in journal["v2"] if e["juge"] == a and e["tirage"] == 1 and e["lot"] != "reel"]
    eb = [e for e in journal["v2"] if e["juge"] == b and e["tirage"] == 1 and e["lot"] != "reel"]
    m["accord"] = {"kappa_ancien": kappa_cohen([aa1["notables"][i] for i in communs], [ab1["notables"][i] for i in communs]),
                   "kappa_paires_v2": kappa_paires(ea, eb, lambda p: qualite[p[0]] != qualite[p[1]]),
                   "kappa_paires_v2_meme_qualite": kappa_paires(ea, eb, lambda p: qualite[p[0]] == qualite[p[1]]),
                   "kappa_paires_v2_toutes": kappa_paires(ea, eb)}
    vb1 = m["v2"][b]["1"]
    if va1.get("joues") and vb1.get("joues"):
        cv = [i for i in evaluees if i in va1["verdicts"] and i in vb1["verdicts"]]
        m["accord"]["kappa_verdicts_v2"] = kappa_cohen([va1["verdicts"][i] for i in cv], [vb1["verdicts"][i] for i in cv])
    notables_par_classe = {}
    for i in evaluees:
        if i in aa1["notables"]:
            notables_par_classe.setdefault(temoins[i]["classe"], []).append(aa1["notables"][i])
    m["classes"] = {"rang_v2_a1": _rangs_par_classe(va1.get("forces", {}), temoins),
                    "notables_ancien_a1": {c: round(sum(v) / len(v), 4) for c, v in notables_par_classe.items()}}
    m["completude"] = _completude(journal, etapes) if etapes is not None else None
    if lot_reel is not None:
        m["reel"] = _mesures_reel(journal, lot_reel, juge_a, juge_b)
    return m


def _completude(journal, etapes):
    joues = {}
    for e in journal["ancien"] + journal["v2"]:
        joues[(e["phase"], e["juge"])] = joues.get((e["phase"], e["juge"]), 0) + 1
    prevus = {}
    for e in etapes:
        prevus[(e["phase"], e["juge"])] = prevus.get((e["phase"], e["juge"]), 0) + nombre_appels(e)
    return {f"{ph}/{j}": {"prevus": n, "joues": joues.get((ph, j), 0), "complet": joues.get((ph, j), 0) == n}
            for (ph, j), n in sorted(prevus.items())}


def _mesures_reel(journal, lot_reel, juge_a, juge_b):
    """Lot réel : descriptif seulement (aucun seuil ne s'y applique)."""
    sortie = {"fiches": len(lot_reel["fiches"])}
    ids = [f["ident"] for f in lot_reel["fiches"]]
    for j in (juge_a, juge_b):
        e = j["etiquette"]
        anc = [x for x in journal["ancien"] if x["lot"] == "reel" and x["juge"] == e]
        lus = {x["ident"]: x["verdict"] for x in anc if x["verdict"] is not None}
        v2 = [x for x in journal["v2"] if x["lot"] == "reel" and x["juge"] == e]
        d = {"ancien_joues": len(anc), "ancien_presents": len(lus),
             "ancien_part_notables": (sum(v["notable"] for v in lus.values()) / len(lus)) if lus else None,
             "ancien_x": {i: v["x"] for i, v in lus.items()}, "v2_joues": len(v2), "v2_valides": sum(1 for x in v2 if x["valide"])}
        if v2:
            admises = sorted({i for x in v2 for i in x["paire"]})
            bt = ajuster_bt(admises, [(x["premier"], x["second"], x["premier_gagne"]) for x in v2 if x["valide"]])
            vv = verdicts_lot(bt["forces"], admises)
            f = sorted(bt["forces"].values())
            d.update(v2_forces=bt["forces"], v2_position=bt["position"], v2_etendue=(f[-1] - f[0]) if f else None,
                     v2_verdicts=vv["verdicts"], v2_statut=vv["statut"], v2_position_mesures=biais_position(v2))
        sortie[e] = d
    lus_a = {x["ident"]: x["verdict"]["notable"] for x in journal["ancien"] if x["lot"] == "reel" and x["juge"] == juge_a["etiquette"]
             and x["verdict"] is not None}
    lus_b = {x["ident"]: x["verdict"]["notable"] for x in journal["ancien"] if x["lot"] == "reel" and x["juge"] == juge_b["etiquette"]
             and x["verdict"] is not None}
    communs = [i for i in ids if i in lus_a and i in lus_b]
    sortie["kappa_ancien_communes"] = kappa_cohen([lus_a[i] for i in communs], [lus_b[i] for i in communs])
    return sortie


# --- lecture gelée --------------------------------------------------------------------------------------------------------------
