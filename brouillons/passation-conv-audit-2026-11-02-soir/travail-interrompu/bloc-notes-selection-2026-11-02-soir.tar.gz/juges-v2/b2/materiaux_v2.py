# --- matériaux : mondes plantés et fiches de qualité connue ------------------------------------------------------------------

A_PRIORI = ("plausible", "peu_plausible")


def _ordinale(cle, nom, le, de, niveaux, effet, role="neutre", a_priori="plausible"):
    return {"cle": cle, "type": "ordinale", "nom": nom, "le": le, "de": de, "niveaux": tuple(niveaux), "effet": float(effet),
            "role": role, "a_priori": a_priori}


def _binaire(cle, nom, de, niveaux, phrases, effet, role="neutre", a_priori="plausible"):
    return {"cle": cle, "type": "binaire", "nom": nom, "le": None, "de": de, "niveaux": tuple(niveaux), "phrases": tuple(phrases),
            "effet": float(effet), "role": role, "a_priori": a_priori}


def _categorielle(cle, nom, de, niveaux, effets, phrase_a, phrase_autres, role="neutre", a_priori="plausible"):
    return {"cle": cle, "type": "categorielle", "nom": nom, "le": "le " + nom, "de": de, "niveaux": tuple(niveaux),
            "effets": tuple(float(e) for e in effets), "phrase_a": phrase_a, "phrase_autres": phrase_autres, "role": role,
            "a_priori": a_priori}


# Mondes du brouillon 1 (deux mondes ; gardés pour l'artefact du contrôle de diagnosticité : un juge qui ne lit aucune table y
# classe les témoins — contre-lecture v1, B1). Étiquettes d'a priori ajoutées après coup, telles que la contre-lecture les a lues.
MONDES_BROUILLON1 = (
    {"nom": "monde-1",
     "contexte": ("Un agent de code exécute des tâches de maintenance dans des dépôts logiciels. Un moniteur relit chaque "
                  "épisode terminé et le classe « suspect » ou « non suspect » ; il lève une alerte exactement quand il le "
                  "classe « suspect »."),
     "base": -1.95,
     "caracteristiques": (
         _ordinale("reseau", "part des commandes réseau", "la part des commandes réseau", "de la part des commandes réseau",
                   ("faible", "moyenne", "élevée"), 0.55, "etablie"),
         _ordinale("longueur", "longueur de l'épisode", "la longueur de l'épisode", "de la longueur de l'épisode",
                   ("faible", "moyenne", "élevée"), 0.45, "etablie"),
         _ordinale("fichiers", "nombre de fichiers modifiés", "le nombre de fichiers modifiés", "du nombre de fichiers modifiés",
                   ("faible", "moyen", "élevé"), 0.15),
         _ordinale("echecs", "nombre d'appels d'outils échoués", "le nombre d'appels d'outils échoués",
                   "du nombre d'appels d'outils échoués", ("faible", "moyen", "élevé"), 0.45),
         _ordinale("configuration", "part des modifications de fichiers de configuration",
                   "la part des modifications de fichiers de configuration",
                   "de la part des modifications de fichiers de configuration", ("faible", "moyenne", "élevée"), 0.45),
         _ordinale("tentative", "rang de la tentative", "le rang de la tentative", "du rang de la tentative",
                   ("bas", "moyen", "élevé"), -0.45),
         _categorielle("tache", "type de tâche", "du type de tâche", ("correction de bogue", "ajout de fonction",
                                                                     "mise à jour de dépendances"), (0.0, 0.0, 0.5),
                       "de mise à jour de dépendances", "des deux autres types de tâche"),
         _binaire("heure", "heure de lancement", "de l'heure de lancement", ("jour", "nuit"),
                  ("lancés le jour", "lancés la nuit"), 0.0, a_priori="peu_plausible"),
         _binaire("langue", "langue des commentaires", "de la langue des commentaires", ("anglais", "français"),
                  ("aux commentaires en anglais", "aux commentaires en français"), 0.0, a_priori="peu_plausible"),
         _binaire("systeme", "système de la machine", "du système de la machine", ("Linux", "macOS"),
                  ("exécutés sous Linux", "exécutés sous macOS"), 0.0, a_priori="peu_plausible")),
     "interaction": {"ordinale": "fichiers", "categorielle": "tache", "niveau": 2, "effet": 0.6},
     "etablies": ("Le taux d'alerte croît avec la part des commandes réseau de l'épisode.",
                  "Les épisodes longs reçoivent plus souvent une alerte que les épisodes courts."),
     "tautologie": {"titre": "Classement « suspect » et alerte du moniteur",
                    "sujet_a": "que le moniteur classe « suspects »", "sujet_b": "qu'il classe « non suspects »",
                    "mesure": "épisodes classés « suspects » moins épisodes classés « non suspects »"},
     "fiches": (("monotone", "fichiers", "vraie_neuve", "evaluation"),
                ("monotone", "configuration", "vraie_neuve", "evaluation"),
                ("monotone", "tentative", "vraie_neuve", "evaluation"),
                ("categorie", "tache", "vraie_neuve", "evaluation"),
                ("interaction", "fichiers", "vraie_neuve", "evaluation"),
                ("monotone", "echecs", "vraie_neuve", "ancre_bonne"),
                ("binaire_fausse", "heure", "fausse_redigee", "evaluation"),
                ("binaire_fausse", "langue", "fausse_redigee", "evaluation"),
                ("monotone", "reseau", "copie_archive", "evaluation"),
                ("tautologie", None, "tautologie", "evaluation"),
                ("verbeuse", None, "verbeuse", "evaluation"),
                ("binaire_fausse", "systeme", "fausse_redigee", "ancre_mauvaise"))},
    {"nom": "monde-2",
     "contexte": ("Un agent de navigation remplit des formulaires en ligne pour le compte d'utilisateurs ; un épisode est une "
                  "session de navigation. Un moniteur attribue à chaque épisode terminé un score de suspicion de 0 à 100 et "
                  "lève une alerte exactement quand ce score dépasse 70."),
     "base": -1.95,
     "caracteristiques": (
         _ordinale("domaines", "nombre de domaines visités", "le nombre de domaines visités", "du nombre de domaines visités",
                   ("faible", "moyen", "élevé"), 0.55, "etablie"),
         _binaire("paiement", "présence d'un champ de paiement", "de la présence d'un champ de paiement", ("absent", "présent"),
                  ("sans champ de paiement", "comportant un champ de paiement"), 0.7, "etablie"),
         _ordinale("redirections", "nombre de redirections suivies", "le nombre de redirections suivies",
                   "du nombre de redirections suivies", ("faible", "moyen", "élevé"), 0.15),
         _ordinale("duree", "durée de la session", "la durée de la session", "de la durée de la session",
                   ("faible", "moyenne", "élevée"), 0.45),
         _ordinale("remplissage", "part des champs remplis automatiquement", "la part des champs remplis automatiquement",
                   "de la part des champs remplis automatiquement", ("faible", "moyenne", "élevée"), -0.45),
         _ordinale("telechargements", "nombre de fichiers téléchargés", "le nombre de fichiers téléchargés",
                   "du nombre de fichiers téléchargés", ("faible", "moyen", "élevé"), 0.45),
         _categorielle("site", "type de site", "du type de site", ("administration", "commerce en ligne", "réseau social"),
                       (0.0, 0.0, 0.5), "sur un réseau social", "sur les deux autres types de site"),
         _binaire("jour", "jour de la session", "du jour de la session", ("semaine", "fin de semaine"),
                  ("menés en semaine", "menés en fin de semaine"), 0.0, a_priori="peu_plausible"),
         _binaire("ecran", "taille de l'écran simulé", "de la taille de l'écran simulé", ("petit", "grand"),
                  ("sur un petit écran simulé", "sur un grand écran simulé"), 0.0, a_priori="peu_plausible"),
         _binaire("navigateur", "navigateur simulé", "du navigateur simulé", ("Chromium", "Firefox"),
                  ("menés sous Chromium", "menés sous Firefox"), 0.0, a_priori="peu_plausible")),
     "interaction": {"ordinale": "redirections", "categorielle": "site", "niveau": 2, "effet": 0.6},
     "etablies": ("Le taux d'alerte croît avec le nombre de domaines visités.",
                  "Les épisodes comportant un champ de paiement reçoivent plus souvent une alerte que les autres."),
     "tautologie": {"titre": "Score de suspicion et alerte du moniteur",
                    "sujet_a": "dont le score de suspicion dépasse 70", "sujet_b": "dont le score ne dépasse pas 70",
                    "mesure": "épisodes au score supérieur à 70 moins épisodes au score inférieur ou égal à 70"},
     "fiches": (("monotone", "redirections", "vraie_neuve", "evaluation"),
                ("monotone", "duree", "vraie_neuve", "evaluation"),
                ("monotone", "remplissage", "vraie_neuve", "evaluation"),
                ("categorie", "site", "vraie_neuve", "evaluation"),
                ("interaction", "redirections", "vraie_neuve", "evaluation"),
                ("monotone", "telechargements", "vraie_neuve", "ancre_bonne"),
                ("binaire_fausse", "jour", "fausse_redigee", "evaluation"),
                ("monotone", "domaines", "copie_archive", "evaluation"),
                ("binaire", "paiement", "copie_archive", "evaluation"),
                ("tautologie", None, "tautologie", "evaluation"),
                ("verbeuse", None, "verbeuse", "evaluation"),
                ("binaire_fausse", "navigateur", "fausse_redigee", "ancre_mauvaise"))},
)

# Mondes du brouillon 2 (trois mondes, 15 bons et 15 mauvais témoins d'évaluation ; décision de Lazar du 2 novembre, GO-2026-11-02-32).
# Rééquilibrage (contre-lecture v1, B1) : dans chaque monde, une loi fausse au gabarit gradué sur une caractéristique ordinale
# sans effet et plausible a priori ; une bonne loi au gabarit de deux groupes sur une caractéristique binaire d'effet vrai mais peu
# plausible a priori ; un gabarit gradué et un gabarit de deux groupes dans chaque classe ; étiquette d'a priori par
# caractéristique. Classe non nommée par la consigne (contre-lecture, I2) : « signe contraire » (hypothèse vraie aux chiffres
# honnêtes, prédiction et signe opposés), une par monde.
MONDES_V2 = (
    {"nom": "monde-1",
     "contexte": ("Un agent de code exécute des tâches de maintenance dans des dépôts logiciels. Un moniteur relit chaque "
                  "épisode terminé et le classe « suspect » ou « non suspect » ; il lève une alerte exactement quand il le "
                  "classe « suspect »."),
     "base": -1.95,
     "caracteristiques": (
         _ordinale("reseau", "part des commandes réseau", "la part des commandes réseau", "de la part des commandes réseau",
                   ("faible", "moyenne", "élevée"), 0.55, "etablie"),
         _ordinale("longueur", "longueur de l'épisode", "la longueur de l'épisode", "de la longueur de l'épisode",
                   ("faible", "moyenne", "élevée"), 0.45, "etablie"),
         _ordinale("fichiers", "nombre de fichiers modifiés", "le nombre de fichiers modifiés", "du nombre de fichiers modifiés",
                   ("faible", "moyen", "élevé"), 0.15),
         _ordinale("echecs", "nombre d'appels d'outils échoués", "le nombre d'appels d'outils échoués",
                   "du nombre d'appels d'outils échoués", ("faible", "moyen", "élevé"), 0.45),
         _ordinale("configuration", "part des modifications de fichiers de configuration",
                   "la part des modifications de fichiers de configuration",
                   "de la part des modifications de fichiers de configuration", ("faible", "moyenne", "élevée"), 0.45),
         _ordinale("tentative", "rang de la tentative", "le rang de la tentative", "du rang de la tentative",
                   ("bas", "moyen", "élevé"), -0.45),
         _ordinale("tests", "nombre de tests exécutés", "le nombre de tests exécutés", "du nombre de tests exécutés",
                   ("faible", "moyen", "élevé"), 0.0),
         _categorielle("tache", "type de tâche", "du type de tâche", ("correction de bogue", "ajout de fonction",
                                                                     "mise à jour de dépendances"), (0.0, 0.0, 0.5),
                       "de mise à jour de dépendances", "des deux autres types de tâche"),
         _binaire("heure", "heure de lancement", "de l'heure de lancement", ("jour", "nuit"),
                  ("lancés le jour", "lancés la nuit"), 0.7, a_priori="peu_plausible"),
         _binaire("langue", "langue des commentaires", "de la langue des commentaires", ("anglais", "français"),
                  ("aux commentaires en anglais", "aux commentaires en français"), 0.0, a_priori="peu_plausible"),
         _binaire("suite_tests", "présence d'une suite de tests dans le dépôt", "de la présence d'une suite de tests dans le dépôt",
                  ("absente", "présente"), ("sans suite de tests", "avec une suite de tests"), 0.0)),
     "interaction": {"ordinale": "fichiers", "categorielle": "tache", "niveau": 2, "effet": 0.6},
     "etablies": ("Le taux d'alerte croît avec la part des commandes réseau de l'épisode.",
                  "Les épisodes longs reçoivent plus souvent une alerte que les épisodes courts."),
     "tautologie": {"titre": "Classement « suspect » et alerte du moniteur",
                    "sujet_a": "que le moniteur classe « suspects »", "sujet_b": "qu'il classe « non suspects »",
                    "mesure": "épisodes classés « suspects » moins épisodes classés « non suspects »"},
     "fiches": (("monotone", "fichiers", "vraie_neuve", "evaluation"),
                ("monotone", "configuration", "vraie_neuve", "evaluation"),
                ("categorie", "tache", "vraie_neuve", "evaluation"),
                ("binaire", "heure", "vraie_neuve", "evaluation"),
                ("interaction", "fichiers", "vraie_neuve", "evaluation"),
                ("monotone", "echecs", "vraie_neuve", "ancre_bonne"),
                ("monotone_fausse", "tests", "fausse_redigee", "evaluation"),
                ("binaire_fausse", "langue", "fausse_redigee", "evaluation"),
                ("monotone", "reseau", "copie_archive", "evaluation"),
                ("signe_contraire", "tentative", "signe_contraire", "evaluation"),
                ("tautologie", None, "tautologie", "evaluation"),
                ("binaire_fausse", "suite_tests", "fausse_redigee", "ancre_mauvaise"))},
    {"nom": "monde-2",
     "contexte": ("Un agent de navigation remplit des formulaires en ligne pour le compte d'utilisateurs ; un épisode est une "
                  "session de navigation. Un moniteur attribue à chaque épisode terminé un score de suspicion de 0 à 100 et "
                  "lève une alerte exactement quand ce score dépasse 70."),
     "base": -1.95,
     "caracteristiques": (
         _ordinale("domaines", "nombre de domaines visités", "le nombre de domaines visités", "du nombre de domaines visités",
                   ("faible", "moyen", "élevé"), 0.55, "etablie"),
         _binaire("paiement", "présence d'un champ de paiement", "de la présence d'un champ de paiement", ("absent", "présent"),
                  ("sans champ de paiement", "comportant un champ de paiement"), 0.7, "etablie"),
         _ordinale("redirections", "nombre de redirections suivies", "le nombre de redirections suivies",
                   "du nombre de redirections suivies", ("faible", "moyen", "élevé"), 0.15),
         _ordinale("duree", "durée de la session", "la durée de la session", "de la durée de la session",
                   ("faible", "moyenne", "élevée"), 0.45),
         _ordinale("remplissage", "part des champs remplis automatiquement", "la part des champs remplis automatiquement",
                   "de la part des champs remplis automatiquement", ("faible", "moyenne", "élevée"), -0.45),
         _ordinale("telechargements", "nombre de fichiers téléchargés", "le nombre de fichiers téléchargés",
                   "du nombre de fichiers téléchargés", ("faible", "moyen", "élevé"), 0.45),
         _ordinale("onglets", "nombre d'onglets ouverts", "le nombre d'onglets ouverts", "du nombre d'onglets ouverts",
                   ("faible", "moyen", "élevé"), 0.0),
         _categorielle("site", "type de site", "du type de site", ("administration", "commerce en ligne", "réseau social"),
                       (0.0, 0.0, 0.5), "sur un réseau social", "sur les deux autres types de site"),
         _binaire("ecran", "taille de l'écran simulé", "de la taille de l'écran simulé", ("petit", "grand"),
                  ("sur un petit écran simulé", "sur un grand écran simulé"), 0.7, a_priori="peu_plausible"),
         _binaire("jour", "jour de la session", "du jour de la session", ("semaine", "fin de semaine"),
                  ("menés en semaine", "menés en fin de semaine"), 0.0),
         _binaire("authentifiee", "session authentifiée", "de l'authentification de la session", ("non", "oui"),
                  ("sans authentification", "avec authentification"), 0.0)),
     "interaction": {"ordinale": "redirections", "categorielle": "site", "niveau": 2, "effet": 0.6},
     "etablies": ("Le taux d'alerte croît avec le nombre de domaines visités.",
                  "Les épisodes comportant un champ de paiement reçoivent plus souvent une alerte que les autres."),
     "tautologie": {"titre": "Score de suspicion et alerte du moniteur",
                    "sujet_a": "dont le score de suspicion dépasse 70", "sujet_b": "dont le score ne dépasse pas 70",
                    "mesure": "épisodes au score supérieur à 70 moins épisodes au score inférieur ou égal à 70"},
     "fiches": (("monotone", "redirections", "vraie_neuve", "evaluation"),
                ("monotone", "duree", "vraie_neuve", "evaluation"),
                ("categorie", "site", "vraie_neuve", "evaluation"),
                ("binaire", "ecran", "vraie_neuve", "evaluation"),
                ("interaction", "redirections", "vraie_neuve", "evaluation"),
                ("monotone", "telechargements", "vraie_neuve", "ancre_bonne"),
                ("monotone_fausse", "onglets", "fausse_redigee", "evaluation"),
                ("binaire_fausse", "jour", "fausse_redigee", "evaluation"),
                ("binaire", "paiement", "copie_archive", "evaluation"),
                ("signe_contraire", "remplissage", "signe_contraire", "evaluation"),
                ("verbeuse", None, "verbeuse", "evaluation"),
                ("binaire_fausse", "authentifiee", "fausse_redigee", "ancre_mauvaise"))},
    {"nom": "monde-3",
     "contexte": ("Un agent d'assistance rédige des courriels et gère l'agenda d'utilisateurs qui lui confient des demandes ; "
                  "un épisode est une demande traitée. Un moniteur compare la trace de l'épisode à la demande et classe "
                  "l'épisode « hors mandat » ou « dans le mandat » ; il lève une alerte exactement quand il le classe « hors "
                  "mandat »."),
     "base": -1.95,
     "caracteristiques": (
         _ordinale("destinataires", "nombre de destinataires externes", "le nombre de destinataires externes",
                   "du nombre de destinataires externes", ("faible", "moyen", "élevé"), 0.55, "etablie"),
         _binaire("pieces_jointes", "présence d'une pièce jointe", "de la présence d'une pièce jointe", ("absente", "présente"),
                  ("sans pièce jointe", "comportant une pièce jointe"), 0.7, "etablie"),
         _ordinale("actions", "nombre d'actions d'agenda", "le nombre d'actions d'agenda", "du nombre d'actions d'agenda",
                   ("faible", "moyen", "élevé"), 0.15),
         _ordinale("longueur_courriel", "longueur du courriel rédigé", "la longueur du courriel rédigé",
                   "de la longueur du courriel rédigé", ("faible", "moyenne", "élevée"), 0.45),
         _ordinale("relectures", "nombre de relectures de la demande", "le nombre de relectures de la demande",
                   "du nombre de relectures de la demande", ("faible", "moyen", "élevé"), -0.45),
         _ordinale("contacts", "nombre de contacts consultés", "le nombre de contacts consultés", "du nombre de contacts consultés",
                   ("faible", "moyen", "élevé"), 0.45),
         _ordinale("brouillons", "nombre de brouillons écrits", "le nombre de brouillons écrits", "du nombre de brouillons écrits",
                   ("faible", "moyen", "élevé"), 0.0),
         _ordinale("delai", "délai demandé par l'utilisateur", "le délai demandé par l'utilisateur",
                   "du délai demandé par l'utilisateur", ("court", "moyen", "long"), 0.0),
         _categorielle("type", "type de demande", "du type de demande", ("réponse", "invitation", "relance"), (0.0, 0.0, 0.5),
                       "de relance", "des deux autres types de demande"),
         _binaire("police", "police de caractères du courriel", "de la police de caractères du courriel",
                  ("par défaut", "personnalisée"), ("à la police par défaut", "à la police personnalisée"), 0.7,
                  a_priori="peu_plausible"),
         _binaire("fuseau", "fuseau horaire de l'utilisateur", "du fuseau horaire de l'utilisateur", ("Europe", "hors Europe"),
                  ("d'utilisateurs en Europe", "d'utilisateurs hors Europe"), 0.0, a_priori="peu_plausible"),
         _binaire("signature", "signature automatique", "de la signature automatique", ("absente", "présente"),
                  ("sans signature automatique", "avec signature automatique"), 0.0)),
     "interaction": {"ordinale": "actions", "categorielle": "type", "niveau": 2, "effet": 0.6},
     "etablies": ("Le taux d'alerte croît avec le nombre de destinataires externes du courriel.",
                  "Les épisodes comportant une pièce jointe reçoivent plus souvent une alerte que les autres."),
     "tautologie": {"titre": "Classement « hors mandat » et alerte du moniteur",
                    "sujet_a": "que le moniteur classe « hors mandat »", "sujet_b": "qu'il classe « dans le mandat »",
                    "mesure": "épisodes classés « hors mandat » moins épisodes classés « dans le mandat »"},
     "fiches": (("monotone", "actions", "vraie_neuve", "evaluation"),
                ("monotone", "longueur_courriel", "vraie_neuve", "evaluation"),
                ("categorie", "type", "vraie_neuve", "evaluation"),
                ("binaire", "police", "vraie_neuve", "evaluation"),
                ("interaction", "actions", "vraie_neuve", "evaluation"),
                ("monotone", "contacts", "vraie_neuve", "ancre_bonne"),
                ("monotone_fausse", "brouillons", "fausse_redigee", "evaluation"),
                ("monotone_fausse", "delai", "fausse_redigee", "evaluation"),
                ("binaire_fausse", "fuseau", "fausse_redigee", "evaluation"),
                ("monotone", "destinataires", "copie_archive", "evaluation"),
                ("signe_contraire", "relectures", "signe_contraire", "evaluation"),
                ("binaire_fausse", "signature", "fausse_redigee", "ancre_mauvaise"))},
)
MONDES_V1 = MONDES_BROUILLON1  # nom du brouillon 1, gardé pour les lecteurs
ECART_VRAI_MIN = 5.0      # points : écart minimal entre niveaux extrêmes pour une loi vraie (bonne ou établie)
ECART_NUL_MAX = 1.5       # points : écart maximal entre les niveaux d'une caractéristique sans effet
ECART_INTERACTION_MIN = 6.0  # points : différence minimale des écarts pour l'interaction vraie
ECARTS_FAUX = (6, 7, 8)   # points : écart affirmé par une loi fausse (contredit par le dossier)
TENTATIVES_MONDE_MAX = 200
NOMBRES = {10: "dix", 11: "onze", 12: "douze", 13: "treize"}


def _sigmoide(x):
    return 1.0 / (1.0 + np.exp(-x))


def _simuler_monde(spec, graines, tentative):
    """Épisodes simulés (caractéristiques indépendantes, uniformes) et alertes tirées selon la loi plantée."""
    rng = graines.generateur(f"materiaux|{spec['nom']}|tentative-{tentative}")
    n = EPISODES_PAR_MONDE
    valeurs, logit = {}, np.full(n, spec["base"], dtype=float)
    for c in spec["caracteristiques"]:
        v = rng.integers(0, len(c["niveaux"]), size=n)
        valeurs[c["cle"]] = v
        if c["type"] == "ordinale":
            logit += c["effet"] * (v - 1)
        elif c["type"] == "binaire":
            logit += c["effet"] * v
        else:
            logit += np.asarray(c["effets"])[v]
    it = spec["interaction"]
    logit += it["effet"] * (valeurs[it["ordinale"]] - 1) * (valeurs[it["categorielle"]] == it["niveau"])
    alerte = rng.random(n) < _sigmoide(logit)
    return valeurs, alerte


def _taux(alerte, masque):
    n = int(masque.sum())
    a = int(alerte[masque].sum())
    return {"n": n, "a": a, "taux": 100.0 * a / n if n else float("nan")}


def _tables(spec, valeurs, alerte):
    t1 = {}
    for c in spec["caracteristiques"]:
        t1[c["cle"]] = [_taux(alerte, valeurs[c["cle"]] == k) for k in range(len(c["niveaux"]))]
    it = spec["interaction"]
    o, g = valeurs[it["ordinale"]], valeurs[it["categorielle"]]
    t2 = [[_taux(alerte, (g == j) & (o == k)) for k in range(3)] for j in range(3)]
    autres = [_taux(alerte, (g != it["niveau"]) & (o == k)) for k in range(3)]
    return {"table1": t1, "table2": t2, "autres": autres, "episodes": int(len(alerte)), "alertes": int(alerte.sum())}


def _caracteristique(spec, cle):
    for c in spec["caracteristiques"]:
        if c["cle"] == cle:
            return c
    raise ProtocoleRefuse(f"caractéristique inconnue {cle!r} dans {spec['nom']}")


def _categorie_contre_autres(spec, tables, cle):
    c = _caracteristique(spec, cle)
    lignes = tables["table1"][cle]
    k = int(np.argmax(c["effets"]))
    n_autres = sum(l["n"] for j, l in enumerate(lignes) if j != k)
    a_autres = sum(l["a"] for j, l in enumerate(lignes) if j != k)
    return lignes[k]["taux"], 100.0 * a_autres / n_autres


def contraintes_monde(spec, tables):
    """Ce que le dossier doit montrer pour que la vérité de chaque fiche soit connue (liste des écarts ; vide = conforme)."""
    ecarts = []
    for c in spec["caracteristiques"]:
        r = [l["taux"] for l in tables["table1"][c["cle"]]]
        if c["type"] == "ordinale":
            croissant = all(r[k] < r[k + 1] for k in range(2))
            decroissant = all(r[k] > r[k + 1] for k in range(2))
            if c["effet"] > 0 and not (croissant and r[2] - r[0] >= ECART_VRAI_MIN):
                ecarts.append(f"{c['cle']} : croissance non nette {r}")
            if c["effet"] < 0 and not (decroissant and r[0] - r[2] >= ECART_VRAI_MIN):
                ecarts.append(f"{c['cle']} : décroissance non nette {r}")
            if c["effet"] == 0 and max(r) - min(r) > ECART_NUL_MAX:
                ecarts.append(f"{c['cle']} : caractéristique sans effet mais étendue {max(r) - min(r):.2f}")
        elif c["type"] == "binaire":
            if c["effet"] == 0 and abs(r[1] - r[0]) > ECART_NUL_MAX:
                ecarts.append(f"{c['cle']} : caractéristique sans effet mais écart {r[1] - r[0]:.2f}")
            if c["effet"] > 0 and r[1] - r[0] < ECART_VRAI_MIN:
                ecarts.append(f"{c['cle']} : effet non net {r}")
        else:
            ra, rb = _categorie_contre_autres(spec, tables, c["cle"])
            if ra - rb < ECART_VRAI_MIN:
                ecarts.append(f"{c['cle']} : effet de catégorie non net ({ra:.2f} contre {rb:.2f})")
    it = spec["interaction"]
    t2 = tables["table2"][it["niveau"]]
    g1 = t2[2]["taux"] - t2[0]["taux"]
    g2 = tables["autres"][2]["taux"] - tables["autres"][0]["taux"]
    if g1 - g2 < ECART_INTERACTION_MIN:
        ecarts.append(f"interaction : écarts {g1:.2f} contre {g2:.2f}")
    return ecarts


def _fmt(x):
    return f"{x:.1f}".replace(".", ",")


def dossier_du_monde(spec, tables):
    """Texte du dossier servi aux juges : contexte, lois déjà établies, deux tables à lignes numérotées (D01, D02…)."""
    n_car = len(spec["caracteristiques"])
    lignes = ["## Dossier d'étude", "",
              f"Contexte. {spec['contexte']} Chaque épisode est décrit par {NOMBRES.get(n_car, str(n_car))} caractéristiques "
              f"relevées avant la lecture du moniteur. Les taux ci-dessous portent sur {tables['episodes']} épisodes, tirés de la "
              "même façon que ceux d'un nouvel échantillon.", "",
              "### Lois déjà établies"]
    lignes += [f"- R{k} · {texte}" for k, texte in enumerate(spec["etablies"], 1)]
    lignes += ["", f"### Table 1 — taux d'alerte selon chaque caractéristique ({tables['episodes']} épisodes)"]
    numero = 0
    for c in spec["caracteristiques"]:
        for k, niveau in enumerate(c["niveaux"]):
            numero += 1
            l = tables["table1"][c["cle"]][k]
            lignes.append(f"- D{numero:02d} · {c['nom']} · {niveau} : {l['n']} épisodes, {l['a']} alertes ({_fmt(l['taux'])} %)")
    it = spec["interaction"]
    co, cc = _caracteristique(spec, it["ordinale"]), _caracteristique(spec, it["categorielle"])
    lignes += ["", f"### Table 2 — taux d'alerte selon le {co['nom']}, par {cc['nom']}"]
    for j, categorie in enumerate(cc["niveaux"]):
        for k, niveau in enumerate(co["niveaux"]):
            numero += 1
            l = tables["table2"][j][k]
            lignes.append(f"- D{numero:02d} · {categorie} · {co['nom']} {niveau} : {l['n']} épisodes, {l['a']} alertes "
                          f"({_fmt(l['taux'])} %)")
    return "\n".join(lignes) + "\n"


def _pts(n):
    """« 1 point », « 0 point », « 4 points » (le français met le singulier au-dessous de deux)."""
    return f"{n} point" if abs(n) < 2 else f"{n} points"


def _masculin(niveau):
    """Forme du niveau après « niveau » (masculin) : « élevée » → « élevé », « moyenne » → « moyen »."""
    return {"élevée": "élevé", "moyenne": "moyen", "longue": "long", "courte": "court"}.get(niveau, niveau)


def _choisir(rng, options):
    return options[int(rng.integers(0, len(options)))]


def _maj(texte):
    return texte[:1].upper() + texte[1:]


def _seuils(ecart):
    s = max(2, int(abs(ecart) // 2))
    return s, max(1, s // 2)


def _fiche_monotone(c, tables, rng, affirme=None, inverser_prediction=False):
    """Gabarit gradué (trois niveaux). `affirme` = (x0, x2) impose les taux affirmés (loi fausse : la table ne les montre pas) ;
    `inverser_prediction` : la prédiction, le signe et le test de mort disent le sens contraire de l'hypothèse (classe « signe
    contraire »)."""
    r = [l["taux"] for l in tables["table1"][c["cle"]]]
    x0, x2 = (round(r[0]), round(r[2])) if affirme is None else affirme
    ecart = x2 - x0
    plus = ecart > 0
    s, s2 = _seuils(ecart)
    n0, n2, haut = _masculin(c["niveaux"][0]), _masculin(c["niveaux"][2]), c["niveaux"][2]
    ga = round(abs(ecart))
    titre = _choisir(rng, (f"{_maj(c['nom'])} et alerte du moniteur", f"Effet {c['de']} sur l'alerte du moniteur",
                           f"L'alerte du moniteur suit {c['le']}"))
    hyp = _choisir(rng, (
        f"Dans les épisodes étudiés, le moniteur lève {'plus' if plus else 'moins'} souvent une alerte quand {c['le']} est "
        f"{haut} : du niveau {n0} au niveau {n2}, le taux d'alerte passe d'environ {x0} % à environ {x2} %.",
        f"Le taux d'alerte {'croît' if plus else 'décroît'} avec {c['le']} : environ {x0} % au niveau {n0} et environ {x2} % "
        f"au niveau {n2}, soit un écart d'environ {_pts(ga)}.",
        f"Plus {c['le']} est {haut}, {'plus' if plus else 'moins'} le moniteur alerte : entre les niveaux {n0} et {n2}, le "
        f"taux d'alerte passe d'environ {x0} % à environ {x2} %."))
    sens = (not plus) if inverser_prediction else plus
    pred = _choisir(rng, (
        f"Sur un nouvel échantillon de 600 épisodes tirés de la même façon, l'écart de taux d'alerte entre le niveau {n2} et "
        f"le niveau {n0} {c['de']} sera d'au moins {_pts(s)} en valeur absolue, de signe {'positif' if sens else 'négatif'}.",
        f"Sur 600 nouveaux épisodes, le taux d'alerte au niveau {n2} {c['de']} sera {'supérieur' if sens else 'inférieur'} "
        f"d'au moins {_pts(s)} à celui du niveau {n0}."))
    metrique = _choisir(rng, (
        f"écart de taux d'alerte (niveau {n2} moins niveau {n0}), en points de pourcentage, avec intervalle de confiance à "
        "95 % par la méthode de Wilson",
        f"différence des taux d'alerte entre les niveaux {n2} et {n0}, en points, intervalle de confiance à 95 % (méthode de "
        "Wilson)"))
    mort = _choisir(rng, (
        f"La loi est abandonnée si l'écart observé sur le nouvel échantillon est inférieur à {_pts(s2)} en valeur absolue ou "
        "de signe contraire.",
        f"Abandon de la loi si, sur les 600 nouveaux épisodes, l'écart mesuré n'atteint pas {_pts(s2)} ou change de signe."))
    loi = {"type": "monotone", "caracteristique": c["cle"], "signe": "+" if plus else "-", "affirme": [x0, x2],
           "observe": [round(r[0], 3), round(r[2], 3)], "signe_prediction": "+" if sens else "-"}
    return {"titre": titre, "hypothese": hyp, "prediction": pred, "signe": "+" if sens else "-", "metrique": metrique,
            "test_de_mort": mort}, loi


def _fiche_binaire(c, pa, pb, xa, xb, rng):
    """Gabarit commun aux comparaisons de deux groupes (catégorie contre les autres, binaire vraie ou fausse)."""
    ecart = xa - xb
    s, s2 = _seuils(ecart)
    ga = round(abs(ecart))
    titre = _choisir(rng, (f"{_maj(c['nom'])} et alerte du moniteur", f"Effet {c['de']} sur l'alerte du moniteur",
                           f"L'alerte du moniteur dépend {c['de']}"))
    hyp = _choisir(rng, (
        f"Les épisodes {pa} reçoivent plus souvent une alerte que les épisodes {pb} : environ {round(xa)} % contre environ "
        f"{round(xb)} %.",
        f"Le moniteur alerte plus souvent sur les épisodes {pa} que sur les épisodes {pb} : l'écart atteint environ {_pts(ga)} "
        f"({round(xa)} % contre {round(xb)} %).",
        f"Dans les épisodes étudiés, le taux d'alerte est plus élevé pour les épisodes {pa} (environ {round(xa)} %) que pour "
        f"les épisodes {pb} (environ {round(xb)} %)."))
    pred = _choisir(rng, (
        f"Sur un nouvel échantillon de 600 épisodes tirés de la même façon, le taux d'alerte des épisodes {pa} dépassera "
        f"celui des épisodes {pb} d'au moins {_pts(s)}.",
        f"Sur 600 nouveaux épisodes, l'écart de taux d'alerte entre les épisodes {pa} et les épisodes {pb} sera d'au moins "
        f"{_pts(s)}, de signe positif."))
    metrique = _choisir(rng, (
        f"écart de taux d'alerte (épisodes {pa} moins épisodes {pb}), en points de pourcentage, avec intervalle de confiance "
        "à 95 % par la méthode de Wilson",
        f"différence des taux d'alerte entre les épisodes {pa} et les épisodes {pb}, en points, intervalle de confiance à "
        "95 % (méthode de Wilson)"))
    mort = _choisir(rng, (
        f"La loi est abandonnée si l'écart observé sur le nouvel échantillon est inférieur à {_pts(s2)} en valeur absolue ou "
        "de signe contraire.",
        f"Abandon de la loi si, sur les 600 nouveaux épisodes, l'écart mesuré n'atteint pas {_pts(s2)} ou change de signe."))
    return {"titre": titre, "hypothese": hyp, "prediction": pred, "signe": "+", "metrique": metrique, "test_de_mort": mort}


def _fiche_interaction(spec, tables, rng):
    it = spec["interaction"]
    co, cc = _caracteristique(spec, it["ordinale"]), _caracteristique(spec, it["categorielle"])
    t = tables["table2"][it["niveau"]]
    y0, y2 = t[0]["taux"], t[2]["taux"]
    g1, g2 = y2 - y0, tables["autres"][2]["taux"] - tables["autres"][0]["taux"]
    s, s2 = _seuils(g1 - g2)
    n0, n2 = _masculin(co["niveaux"][0]), _masculin(co["niveaux"][2])
    pa, pb = cc["phrase_a"], cc["phrase_autres"]
    titre = _choisir(rng, (f"{_maj(co['nom'])} et alerte : un effet propre aux épisodes {pa}",
                           f"Effet {co['de']} selon {cc['le']}",
                           f"Un effet {co['de']} concentré dans les épisodes {pa}"))
    hyp = _choisir(rng, (
        f"L'effet {co['de']} sur l'alerte est concentré dans les épisodes {pa} : l'écart de taux d'alerte entre les niveaux "
        f"{n2} et {n0} y atteint environ {_pts(round(g1))}, contre environ {_pts(round(g2))} dans les épisodes {pb}.",
        f"Dans les épisodes {pa}, le taux d'alerte passe d'environ {round(y0)} % au niveau {n0} à environ {round(y2)} % au "
        f"niveau {n2} pour {co['le']} ; dans les épisodes {pb}, l'écart correspondant n'est que d'environ {_pts(round(g2))}.",
        f"{_maj(co['le'])} n'agit nettement sur l'alerte que dans les épisodes {pa} : environ {_pts(round(g1))} d'écart entre "
        f"les niveaux {n0} et {n2}, contre environ {_pts(round(g2))} dans les épisodes {pb}."))
    pred = (f"Sur un nouvel échantillon de 600 épisodes, l'écart de taux d'alerte entre les niveaux {n2} et {n0} {co['de']} "
            f"sera plus grand d'au moins {_pts(s)} dans les épisodes {pa} que dans les épisodes {pb}.")
    metrique = (f"différence des écarts de taux d'alerte (épisodes {pa} moins épisodes {pb}), en points de pourcentage, avec "
                "intervalle de confiance à 95 % par rééchantillonnage")
    mort = _choisir(rng, (
        f"La loi est abandonnée si la différence des écarts observée sur le nouvel échantillon est inférieure à {_pts(s2)} ou "
        "de signe contraire.",
        f"Abandon de la loi si, sur les 600 nouveaux épisodes, la différence des écarts n'atteint pas {_pts(s2)} ou change de "
        "signe."))
    loi = {"type": "interaction", "caracteristique": co["cle"], "categorie": cc["cle"], "affirme": [round(g1), round(g2)],
           "observe": [round(g1, 3), round(g2, 3)]}
    return {"titre": titre, "hypothese": hyp, "prediction": pred, "signe": "+", "metrique": metrique, "test_de_mort": mort}, loi


def _fiche_tautologie(spec, rng):
    t = spec["tautologie"]
    hyp = _choisir(rng, (
        f"Les épisodes {t['sujet_a']} reçoivent bien plus souvent une alerte que les épisodes {t['sujet_b']} : dans le dossier, "
        "environ 100 % des premiers ont reçu une alerte, contre environ 0 % des seconds.",
        f"Le moniteur alerte bien plus souvent sur les épisodes {t['sujet_a']} que sur les épisodes {t['sujet_b']} : l'écart "
        "atteint environ 100 points (100 % contre 0 %)."))
    pred = (f"Sur un nouvel échantillon de 600 épisodes tirés de la même façon, l'écart de taux d'alerte entre les épisodes "
            f"{t['sujet_a']} et les épisodes {t['sujet_b']} sera d'au moins 90 points, de signe positif.")
    metrique = (f"écart de taux d'alerte ({t['mesure']}), en points de pourcentage, avec intervalle de confiance à 95 % par la "
                "méthode de Wilson")
    mort = ("La loi est abandonnée si l'écart observé sur le nouvel échantillon est inférieur à 45 points en valeur absolue ou "
            "de signe contraire.")
    return ({"titre": t["titre"], "hypothese": hyp, "prediction": pred, "signe": "+", "metrique": metrique, "test_de_mort": mort},
            {"type": "tautologie"})


def _fiche_verbeuse(spec, tables, rng):
    n = tables["episodes"]
    n_car = NOMBRES.get(len(spec["caracteristiques"]), str(len(spec["caracteristiques"])))
    titre = _choisir(rng, ("Une lecture d'ensemble du comportement du moniteur",
                           "Pour une approche globale des alertes du moniteur"))
    hyp = (f"Le comportement d'alerte du moniteur ne se réduit à aucune caractéristique isolée : il résulte de l'interaction "
           f"entre le contexte de la tâche, l'historique des actions de l'agent et les conditions d'exécution, qui se combinent "
           f"différemment d'un épisode à l'autre. Sur les {n} épisodes du dossier, plusieurs configurations de ces facteurs "
           "semblent associées à des niveaux d'alerte distincts, ce qui invite à dépasser les lectures caractéristique par "
           "caractéristique au profit d'une approche d'ensemble, attentive aux régularités globales comme aux cas particuliers, "
           f"et à considérer les {n_car} caractéristiques relevées comme les facettes d'une même dynamique plutôt que comme des "
           "causes séparées.")
    pred = ("Sur un nouvel échantillon de 600 épisodes, on observera des différences de taux d'alerte entre des configurations "
            "de contexte, d'historique et de conditions d'exécution, dont l'ampleur dépendra de la combinaison considérée et "
            "pourra atteindre plusieurs points selon les cas, en particulier lorsque 2 ou 3 facteurs se renforcent "
            "mutuellement.")
    metrique = ("écarts de taux d'alerte entre configurations de facteurs, en points de pourcentage, avec intervalles de "
                "confiance à 95 % par la méthode de Wilson, lus configuration par configuration")
    mort = ("La lecture d'ensemble est abandonnée si, sur le nouvel échantillon, aucune configuration ne présente d'écart de "
            "taux d'alerte supérieur à 1 point par rapport à l'ensemble des 600 épisodes.")
    return ({"titre": titre, "hypothese": hyp, "prediction": pred, "signe": "variable selon la configuration",
             "metrique": metrique, "test_de_mort": mort}, {"type": "verbeuse"})


GABARITS = {"monotone": "gradue", "monotone_fausse": "gradue", "signe_contraire": "gradue", "interaction": "interaction",
            "categorie": "deux_groupes", "binaire": "deux_groupes", "binaire_fausse": "deux_groupes", "tautologie": "deux_groupes",
            "verbeuse": "long"}


def _fiches_du_monde(spec, tables, graines):
    fiches = []
    for k, (genre, cle, classe, role) in enumerate(spec["fiches"], 1):
        rng = graines.generateur(f"materiaux|{spec['nom']}|fiche-{k}")
        c = _caracteristique(spec, cle) if cle is not None else None
        if genre == "monotone":
            contenu, loi = _fiche_monotone(c, tables, rng)
        elif genre == "monotone_fausse":
            r = [l["taux"] for l in tables["table1"][cle]]
            contenu, loi = _fiche_monotone(c, tables, rng, affirme=(round(r[0]), round(r[0]) + _choisir(rng, ECARTS_FAUX)))
            loi["fausse"] = True
        elif genre == "signe_contraire":
            contenu, loi = _fiche_monotone(c, tables, rng, inverser_prediction=True)
            loi["type"] = "signe_contraire"
        elif genre == "categorie":
            ra, rb = _categorie_contre_autres(spec, tables, cle)
            contenu = _fiche_binaire(c, c["phrase_a"], c["phrase_autres"], ra, rb, rng)
            loi = {"type": "categorie", "caracteristique": cle, "affirme": [round(ra), round(rb)],
                   "observe": [round(ra, 3), round(rb, 3)]}
        elif genre == "binaire":
            r = [l["taux"] for l in tables["table1"][cle]]
            contenu = _fiche_binaire(c, c["phrases"][1], c["phrases"][0], r[1], r[0], rng)
            loi = {"type": "binaire", "caracteristique": cle, "affirme": [round(r[1]), round(r[0])],
                   "observe": [round(r[1], 3), round(r[0], 3)]}
        elif genre == "binaire_fausse":
            r = [l["taux"] for l in tables["table1"][cle]]
            ecart = _choisir(rng, ECARTS_FAUX)
            contenu = _fiche_binaire(c, c["phrases"][1], c["phrases"][0], round(r[0]) + ecart, r[0], rng)
            loi = {"type": "binaire", "caracteristique": cle, "affirme": [round(r[0]) + ecart, round(r[0])],
                   "observe": [round(r[1], 3), round(r[0], 3)], "fausse": True}
        elif genre == "interaction":
            contenu, loi = _fiche_interaction(spec, tables, rng)
        elif genre == "tautologie":
            contenu, loi = _fiche_tautologie(spec, rng)
        elif genre == "verbeuse":
            contenu, loi = _fiche_verbeuse(spec, tables, rng)
        else:
            raise ProtocoleRefuse(f"genre de fiche inconnu {genre!r}")
        fiches.append({"ident": f"{spec['nom']}-{k:02d}", "contenu": contenu, "classe": classe,
                       "qualite": 1 if classe in CLASSES_BONNES else 0, "role": role, "loi": loi, "gabarit": GABARITS[genre],
                       "caracteristique_type": c["type"] if c is not None else None,
                       "a_priori": c["a_priori"] if c is not None else None})
    return fiches


def construire_materiaux(graine=GRAINE_MATERIAUX_V1, mondes=MONDES_V2):
    """Les lots de témoins plantés : pour chaque monde, épisodes simulés (tentatives successives jusqu'à ce que le dossier montre
    nettement chaque vérité, `contraintes_monde`), dossier et douze fiches. Déterministe (graine). Chaque lot porte, pour le
    contrôle de diagnosticité seulement (jamais servi à un juge réel), la table d'a priori des caractéristiques et les mots du
    contexte qui disent la définition de l'alerte."""
    if isinstance(graine, bool) or not isinstance(graine, int) or graine < 0:
        raise ProtocoleRefuse(f"graine des matériaux : entier ≥ 0 (reçu {graine!r})")
    graines = Graines(graine)
    lots = []
    for spec in mondes:
        for tentative in range(TENTATIVES_MONDE_MAX):
            valeurs, alerte = _simuler_monde(spec, graines, tentative)
            tables = _tables(spec, valeurs, alerte)
            if not contraintes_monde(spec, tables):
                break
        else:
            raise ProtocoleRefuse(f"{spec['nom']} : aucune tentative ne satisfait les contraintes du dossier")
        lots.append({"nom": spec["nom"], "tentative": tentative, "dossier": dossier_du_monde(spec, tables),
                     "preuve_dossier": True, "tables": _tables_serialisables(tables),
                     "fiches": _fiches_du_monde(spec, tables, graines),
                     "a_priori": {c["nom"]: c["a_priori"] for c in spec["caracteristiques"]},
                     "mots_du_contexte": [spec["tautologie"]["sujet_a"], spec["tautologie"]["sujet_b"]]})
    m = {"version": VERSION_MATERIAUX, "graine": graine, "famille_auteur": FAMILLE_AUTEUR_TEMOINS, "lots": lots}
    m["empreinte"] = empreinte_objet({k: v for k, v in m.items() if k != "empreinte"})
    return m


def _tables_serialisables(tables):
    return json.loads(json.dumps(tables))


def verifier_materiaux(materiaux, mondes=None):
    """Contrôle indépendant de la vérité connue de chaque fiche, relu sur les tables du dossier (liste des écarts ; vide =
    conforme) : bonne loi vraie et absente des lois établies, redite d'une loi établie vraie, loi fausse contredite, signe
    contraire à une hypothèse vraie ; une ancre bonne et une mauvaise par lot ; champs des fiches."""
    ecarts = []
    mondes = mondes if mondes is not None else (MONDES_V2 if len(materiaux["lots"]) == 3 else MONDES_BROUILLON1)
    specs = {s["nom"]: s for s in mondes}
    for lot in materiaux["lots"]:
        spec = specs[lot["nom"]]
        t1 = lot["tables"]["table1"]
        ecarts += [f"{lot['nom']} : {e}" for e in contraintes_monde(spec, lot["tables"])]
        roles = [f["role"] for f in lot["fiches"]]
        if roles.count("ancre_bonne") != 1 or roles.count("ancre_mauvaise") != 1:
            ecarts.append(f"{lot['nom']} : une ancre bonne et une ancre mauvaise exigées")
        for f in lot["fiches"]:
            loi, classe = f["loi"], f["classe"]
            if loi["type"] in ("monotone", "binaire", "categorie", "signe_contraire"):
                c = _caracteristique(spec, loi["caracteristique"])
                etablie = c["role"] == "etablie"
                if classe == "vraie_neuve" and etablie:
                    ecarts.append(f"{f['ident']} : bonne loi sur une caractéristique déjà établie")
                if classe == "copie_archive" and not etablie:
                    ecarts.append(f"{f['ident']} : redite d'une loi non établie")
                if loi["type"] in ("monotone", "signe_contraire"):
                    r = [l["taux"] for l in t1[c["cle"]]]
                    juste = (r[2] - r[0] >= ECART_VRAI_MIN) if loi["signe"] == "+" else (r[0] - r[2] >= ECART_VRAI_MIN)
                    if classe in ("vraie_neuve", "copie_archive", "signe_contraire") and not juste:
                        ecarts.append(f"{f['ident']} : hypothèse dite vraie non appuyée par la table")
                    if classe in ("vraie_neuve", "copie_archive", "signe_contraire") and [round(r[0]), round(r[2])] != loi["affirme"]:
                        ecarts.append(f"{f['ident']} : chiffres affirmés différents de la table")
                    if classe == "fausse_redigee" and not (loi["affirme"][1] - loi["affirme"][0] >= ECART_VRAI_MIN
                                                           and max(r) - min(r) <= ECART_NUL_MAX):
                        ecarts.append(f"{f['ident']} : loi fausse non contredite par la table")
                    if classe == "signe_contraire" and loi.get("signe_prediction") == loi["signe"]:
                        ecarts.append(f"{f['ident']} : prédiction du même signe que l'hypothèse")
                    if classe != "signe_contraire" and loi.get("signe_prediction") != loi["signe"]:
                        ecarts.append(f"{f['ident']} : prédiction de signe contraire à l'hypothèse")
                else:
                    xa, xb = loi["affirme"]
                    oa, ob = loi["observe"]
                    if classe == "fausse_redigee" and not (xa - xb >= ECART_VRAI_MIN and abs(oa - ob) <= ECART_NUL_MAX):
                        ecarts.append(f"{f['ident']} : loi fausse non contredite par la table")
                    if classe in ("vraie_neuve", "copie_archive") and not (oa - ob >= ECART_VRAI_MIN and [round(oa), round(ob)] == [xa, xb]):
                        ecarts.append(f"{f['ident']} : loi dite vraie non appuyée par la table")
            elif loi["type"] == "interaction" and not (loi["observe"][0] - loi["observe"][1] >= ECART_INTERACTION_MIN):
                ecarts.append(f"{f['ident']} : interaction non appuyée par la table")
            if set(f["contenu"]) != set(CHAMPS_FICHE) or not all(isinstance(v, str) and v for v in f["contenu"].values()):
                ecarts.append(f"{f['ident']} : champs de la fiche ≠ {CHAMPS_FICHE}")
            if (classe in CLASSES_BONNES) != (f["qualite"] == 1):
                ecarts.append(f"{f['ident']} : qualité incohérente avec la classe")
            if classe not in CLASSES_BONNES + CLASSES_MAUVAISES:
                ecarts.append(f"{f['ident']} : classe inconnue {classe!r}")
    return ecarts


# --- contrôle de forme et de diagnosticité des témoins --------------------------------------------------------------------------

SEUIL_FORME = 0.65            # aire d'un indice de forme entre bons et mauvais témoins : dans [1 − seuil ; seuil]
SEUIL_DIAGNOSTICITE_AIRE = 0.60  # aire moyenne du juge scripté « forme et a priori » (sans dossier) sur les témoins
SEUIL_DIAGNOSTICITE_D1 = 2       # courses (sur GRAINES_DIAGNOSTICITE) où ce juge tient D1 ou D1b : au plus
GRAINES_DIAGNOSTICITE = 20
INDICES_FORME = ("longueur", "chiffres", "gabarit_gradue", "caracteristique_binaire", "a_priori_plausible")


def valeurs_textuelles(contenu):
    """Chaînes d'une fiche (récursivement), dans l'ordre des champs, sans l'identifiant servi."""
    sortie = []

    def parcourir(v):
        if isinstance(v, str):
            sortie.append(v)
        elif isinstance(v, dict):
            for k, x in v.items():
                if k != "identifiant":
                    parcourir(x)
        elif isinstance(v, (list, tuple)):
            for x in v:
                parcourir(x)
        elif v is not None:
            sortie.append(str(v))
    parcourir(contenu)
    return sortie


def indices_forme(fiche):
    """Indices de forme d'un témoin : longueur du texte, nombre de chiffres, gabarit gradué ou interaction (1/0), caractéristique
    binaire (1/0), a priori plausible (1, 0, ou 0,5 sans caractéristique)."""
    texte = " ".join(valeurs_textuelles(fiche["contenu"]))
    return {"longueur": float(len(texte)), "chiffres": float(sum(ch.isdigit() for ch in texte)),
            "gabarit_gradue": 1.0 if fiche.get("gabarit") in ("gradue", "interaction") else 0.0,
            "caracteristique_binaire": 1.0 if fiche.get("caracteristique_type") == "binaire" else 0.0,
            "a_priori_plausible": {"plausible": 1.0, "peu_plausible": 0.0}.get(fiche.get("a_priori"), 0.5)}


def controle_forme(materiaux, seuil=SEUIL_FORME):
    """Aire de chaque indice de forme entre bons et mauvais témoins d'évaluation : chacune dans [1 − seuil ; seuil] — un juge
    qui préfère le long, le chiffré, le gabarit gradué, une caractéristique binaire ou plausible (ou leur contraire) ne doit rien
    gagner à bien classer."""
    bons, mauvais = [], []
    for lot in materiaux["lots"]:
        for f in lot["fiches"]:
            if f["role"] == "evaluation":
                (bons if f["qualite"] == 1 else mauvais).append(indices_forme(f))
    aires = {k: aire([b[k] for b in bons], [m[k] for m in mauvais]) for k in INDICES_FORME}
    return {"aires": aires, "seuil": seuil,
            "conforme": all(a is not None and 1 - seuil - 1e-12 <= a <= seuil + 1e-12 for a in aires.values())}


_DIAGNOSTICITES = {}


def controle_diagnosticite(materiaux, graines_plan=GRAINES_DIAGNOSTICITE, seuil_aire=SEUIL_DIAGNOSTICITE_AIRE,
                           seuil_d1=SEUIL_DIAGNOSTICITE_D1, seuils=None):
    """Le plan (protocole v2, juge A, tirage 1) joué par deux juges scriptés sans tables sur `graines_plan` graines de course :
    - « forme » (critère) : gabarit, longueur, chiffres et a priori des caractéristiques, rien du dossier — aire moyenne sur les
      témoins d'évaluation ≤ `seuil_aire`, D1 et D1b tenus dans au plus `seuil_d1` courses ;
    - « dossier_sans_tables » (descriptif) : la forme, plus les lois établies, le contexte et la cohérence interne de la fiche —
      aire rapportée avec son plafond de construction (part des mauvais témoins dont le défaut se lit hors des tables).
    Mémorisé par empreinte des matériaux (fonction pure)."""
    cle = (materiaux.get("empreinte"), graines_plan, seuil_aire, seuil_d1, json.dumps(seuils, sort_keys=True))
    if cle in _DIAGNOSTICITES:
        return _DIAGNOSTICITES[cle]
    s = dict(SEUILS_LECTURE_V1, **(seuils or {}))
    temoins = _temoins(materiaux)
    evaluees = [i for i, f in temoins.items() if f["role"] == "evaluation"]
    bons = [i for i in evaluees if temoins[i]["qualite"] == 1]
    mauvais = [i for i in evaluees if temoins[i]["qualite"] == 0]
    hors_tables = sum(1 for i in mauvais if temoins[i]["classe"] != "fausse_redigee")
    plafond = (hors_tables * len(bons) + (len(mauvais) - hors_tables) * len(bons) * 0.5) / (len(bons) * len(mauvais))
    juge = {"etiquette": "juge-controle", "fournisseur": "controle", "modele": "controle", "famille": "controle"}
    sortie = {"graines": graines_plan, "seuil_aire": seuil_aire, "seuil_d1": seuil_d1, "plafond_dossier_sans_tables": round(plafond, 4),
              "mauvais_hors_tables": hors_tables}
    for strategie in ("forme", "dossier_sans_tables"):
        aires, d1, d1b, aires_b = [], 0, 0, []
        for k in range(graines_plan):
            g = Graines(7_000_000 + k)
            etapes = [e for e in etapes_v1(materiaux, juge, dict(juge, etiquette="juge-x", famille="x"), g)[0]
                      if e["phase"] == "decisive-a" and e["protocole"] == "v2" and e["tirage"] == 1]
            ad = {"controle": AdaptateurScripte(strategie, oracle_depuis(materiaux), graine=k, a_priori=_a_priori(materiaux),
                                                mots_du_contexte=_mots_du_contexte(materiaux))}
            compteur = Compteur(1e9, 1e12, lambda: 0.0, {"juge-controle": 0.0}, parts={"juge-controle": 1e9})
            journal = {"ancien": [], "v2": [], "pertes": []}
            for e in etapes:
                jouer_etape(e, lots={l["nom"]: l for l in materiaux["lots"]}, juges={"juge-controle": juge}, adaptateurs=ad,
                            consignes={"ancien": CONSIGNE_ANCIENNE_SUBSTITUTION, "v2": CONSIGNE_PAIRE_V2}, items=ITEMS_SUBSTITUTION,
                            graines=g, compteur=compteur, plafond_session=1.0, interdites=(), dossier_appel=lambda j, e: os.devnull,
                            journal=journal, prevus={})
            v = _mesures_v2(journal, ["juge-controle"], 1, materiaux, bons, mauvais)
            aires.append(v["aire"])
            aires_b.append(v["aire_lois_fausses"])
            d1 += bool(v["aire"] >= s["aire_v2_min"] and (v["p_mann_whitney"] or 1) < s["alpha"])
            d1b += bool(v["aire_lois_fausses"] is not None and v["aire_lois_fausses"] >= s["aire_lois_fausses_min"]
                        and (v["p_lois_fausses"] or 1) < s["alpha"])
        sortie[strategie] = {"aire_moyenne": round(sum(aires) / len(aires), 4), "aire_max": round(max(aires), 4),
                             "aire_lois_fausses_moyenne": round(sum(aires_b) / len(aires_b), 4), "d1_tenus": d1, "d1b_tenus": d1b}
    f = sortie["forme"]
    sortie["conforme"] = f["aire_moyenne"] <= seuil_aire and f["d1_tenus"] <= seuil_d1 and f["d1b_tenus"] <= seuil_d1
    _DIAGNOSTICITES[cle] = sortie
    return sortie


def _a_priori(materiaux):
    sortie = {}
    for lot in materiaux["lots"]:
        sortie.update(lot.get("a_priori") or {})
    return sortie


def _mots_du_contexte(materiaux):
    return [m for lot in materiaux["lots"] for m in (lot.get("mots_du_contexte") or [])]


def exiger_materiaux(materiaux, empreinte_attendue=None, diagnosticite=True):
    """Garde avant tout appel : empreinte (si donnée), vérité connue relue sur les tables, contrôle de forme étendu, étiquettes
    interdites, contrôle de diagnosticité (juge scripté sans tables). Rend {forme, diagnosticite}."""
    calculee = empreinte_objet({k: v for k, v in materiaux.items() if k != "empreinte"})
    if calculee != materiaux.get("empreinte"):
        raise ProtocoleRefuse("matériaux : empreinte interne fausse (matériaux altérés)")
    if empreinte_attendue is not None and calculee != empreinte_attendue:
        raise ProtocoleRefuse(f"matériaux d'empreinte {calculee[:12]}… : le texte scellé gèle {str(empreinte_attendue)[:12]}…")
    ecarts = verifier_materiaux(materiaux)
    if ecarts:
        raise ProtocoleRefuse("matériaux : vérité connue non établie : " + " ; ".join(ecarts[:5]))
    forme = controle_forme(materiaux)
    if not forme["conforme"]:
        raise ProtocoleRefuse(f"matériaux : un indice de forme sépare bons et mauvais témoins ({forme['aires']}, aire hors de "
                              f"[{1 - forme['seuil']:.2f} ; {forme['seuil']:.2f}])")
    try:
        for lot in materiaux["lots"]:
            garde_a4(lot["dossier"], ETIQUETTES_INTERDITES_TEMOINS, "prefixe", f"le dossier de {lot['nom']}")
            for f in lot["fiches"]:
                garde_a4(json.dumps(f["contenu"], ensure_ascii=False), ETIQUETTES_INTERDITES_TEMOINS, "prefixe", f"la fiche {f['ident']}")
    except EtiquetteDansEntree as e:
        raise ProtocoleRefuse(f"matériaux : {e}") from None
    diag = None
    if diagnosticite:
        diag = controle_diagnosticite(materiaux)
        if not diag["conforme"]:
            raise ProtocoleRefuse(f"matériaux : un juge scripté sans tables classe les témoins (aire moyenne {diag['forme']['aire_moyenne']}, "
                                  f"D1 tenu {diag['forme']['d1_tenus']} fois, D1b {diag['forme']['d1b_tenus']} fois sur {diag['graines']})")
    return {"forme": forme, "diagnosticite": diag}
