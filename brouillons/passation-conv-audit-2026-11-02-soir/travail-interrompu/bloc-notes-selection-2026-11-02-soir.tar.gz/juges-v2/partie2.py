

# --- contrôle de forme des témoins ------------------------------------------------------------------------------------------

SEUIL_FORME = 0.65


def valeurs_textuelles(contenu):
    """Chaînes d'une fiche (récursivement), dans l'ordre des champs, sans l'identifiant servi."""
    sortie = []

    def parcourir(v):
        if isinstance(v, str):
            sortie.append(v)
        elif isinstance(v, dict):
            for k, x in v.items():
                if k != "identifiant":
                    parcourir(x)
        elif isinstance(v, (list, tuple)):
            for x in v:
                parcourir(x)
        elif v is not None:
            sortie.append(str(v))
    parcourir(contenu)
    return sortie


def indices_forme(contenu):
    texte = " ".join(valeurs_textuelles(contenu))
    return {"longueur": len(texte), "chiffres": sum(ch.isdigit() for ch in texte)}


def controle_forme(materiaux, seuil=SEUIL_FORME):
    """Aire de chaque indice de forme simple (longueur, nombre de chiffres) entre bons et mauvais témoins d'évaluation : aucune
    ne doit dépasser `seuil` — un juge qui préfère le long ou le chiffré ne doit rien gagner à bien classer."""
    bons, mauvais = [], []
    for lot in materiaux["lots"]:
        for f in lot["fiches"]:
            if f["role"] == "evaluation":
                (bons if f["qualite"] == 1 else mauvais).append(indices_forme(f["contenu"]))
    aires = {k: aire([b[k] for b in bons], [m[k] for m in mauvais]) for k in ("longueur", "chiffres")}
    return {"aires": aires, "seuil": seuil, "conforme": all(a is not None and a <= seuil for a in aires.values())}


def exiger_materiaux(materiaux, empreinte_attendue=None):
    """Garde avant tout appel : empreinte (si donnée), vérité connue relue sur les tables, forme, étiquettes interdites."""
    calculee = empreinte_objet({k: v for k, v in materiaux.items() if k != "empreinte"})
    if calculee != materiaux.get("empreinte"):
        raise ProtocoleRefuse("matériaux : empreinte interne fausse (matériaux altérés)")
    if empreinte_attendue is not None and calculee != empreinte_attendue:
        raise ProtocoleRefuse(f"matériaux d'empreinte {calculee[:12]}… : le texte scellé gèle {str(empreinte_attendue)[:12]}…")
    ecarts = verifier_materiaux(materiaux)
    if ecarts:
        raise ProtocoleRefuse("matériaux : vérité connue non établie : " + " ; ".join(ecarts[:5]))
    forme = controle_forme(materiaux)
    if not forme["conforme"]:
        raise ProtocoleRefuse(f"matériaux : un indice de forme favorise les bons témoins ({forme['aires']}, seuil {forme['seuil']})")
    for lot in materiaux["lots"]:
        garde_a4(lot["dossier"], ETIQUETTES_INTERDITES_TEMOINS, "prefixe", f"le dossier de {lot['nom']}")
        for f in lot["fiches"]:
            garde_a4(json.dumps(f["contenu"], ensure_ascii=False), ETIQUETTES_INTERDITES_TEMOINS, "prefixe", f"la fiche {f['ident']}")
    return forme


# --- entrées servies -------------------------------------------------------------------------------------------------------


def vue_servie(fiche, identifiant_servi):
    """Ce que le juge reçoit d'une fiche : son contenu seul, plus l'identifiant opaque (ni classe, ni rôle, ni auteur)."""
    vue = json.loads(json.dumps(fiche["contenu"], ensure_ascii=False))
    if not isinstance(vue, dict) or "identifiant" in vue:
        raise ProtocoleRefuse(f"fiche {fiche.get('ident')!r} : contenu non dictionnaire ou champ « identifiant » réservé")
    return dict(vue, identifiant=identifiant_servi)


def corps_fiche(fiche, identifiant_servi):
    return json.dumps(vue_servie(fiche, identifiant_servi), ensure_ascii=False, indent=1)


def identifiant_servi(graines, juge, tirage, ident):
    """Identifiant opaque propre au juge et au tirage (`graines_v53.Graines.jeton_opaque`)."""
    return "F" + graines.jeton_opaque(f"anonymisation|{juge}|tirage-{tirage}|{ident}", 5)


def entree_ancienne(consigne, fiche, ident_servi, interdites, dossier=None):
    """Ancien protocole : consigne figée + (dossier) + une seule fiche anonyme — sans dossier, octet pour octet la forme de
    `fiches_v53.entree_une_fiche`. Garde A4 (préfixe) sur la fiche puis sur l'entrée complète."""
    corps = corps_fiche(fiche, ident_servi)
    garde_a4(corps, interdites, "prefixe", "la fiche servie")
    milieu = (dossier.rstrip() + "\n\n") if dossier else ""
    entree = consigne.rstrip() + "\n\n" + milieu + "## La fiche\n```json\n" + corps + "\n```\n"
    garde_a4(entree, interdites, "prefixe", "l'entrée complète")
    return entree


def entree_paire(consigne, dossier, premiere, seconde, interdites):
    """Protocole v2 : consigne figée + dossier + deux fiches anonymes dans l'ordre de présentation. `premiere`, `seconde` :
    (identifiant servi, fiche)."""
    morceaux = [consigne.rstrip(), "", dossier.rstrip(), ""]
    for (ident, f), rang in ((premiere, "présentée en premier"), (seconde, "présentée en second")):
        corps = corps_fiche(f, ident)
        garde_a4(corps, interdites, "prefixe", f"la fiche servie {ident}")
        morceaux += [f"## Fiche {ident} ({rang})", "```json", corps, "```", ""]
    entree = "\n".join(morceaux)
    garde_a4(entree, interdites, "prefixe", "l'entrée complète")
    return entree


# --- réponses ---------------------------------------------------------------------------------------------------------------

_TYPOGRAPHIE = {"’": "'", "‘": "'", "«": '"', "»": '"', "“": '"', "”": '"', "…": "..."}


def normaliser_citation(texte):
    """Forme comparée d'une citation et de sa source : NFKC (espaces insécables comprises), guillemets et apostrophes
    typographiques ramenés à une forme, blancs réduits, minuscules, ponctuation de bord (points, points de suspension,
    guillemets) retirée."""
    t = unicodedata.normalize("NFKC", texte)
    for a, b in _TYPOGRAPHIE.items():
        t = t.replace(a, b)
    t = re.sub(r"\s+", " ", t).strip().lower()
    return t.strip(" .\"'")


def verifier_citation(citation, sources, minimum, maximum, interdites_sources=()):
    """Rend (vrai, motif) : la citation, normalisée, est dans une des `sources` (normalisées), dans les bornes de longueur, et
    dans aucune des `interdites_sources` (citation commune aux deux fiches : elle ne fonde pas le choix)."""
    if not isinstance(citation, str):
        return False, "citation absente"
    c = normaliser_citation(citation)
    if len(c) < minimum:
        return False, f"citation trop courte ({len(c)} < {minimum} caractères)"
    if len(c) > maximum:
        return False, f"citation trop longue ({len(c)} > {maximum} caractères)"
    if not any(c in normaliser_citation(s) for s in sources):
        return False, "citation introuvable telle quelle"
    if any(c in normaliser_citation(s) for s in interdites_sources):
        return False, "citation commune aux deux fiches"
    return True, None


def dossier_a_preuves(dossier):
    """Vrai si le dossier porte des lignes de faits numérotées (« - D01 · … ») : la citation du dossier est alors exigée."""
    return re.search(r"(?m)^- D\d{2,} · ", dossier or "") is not None


def lire_comparaison(texte, premiere, seconde, dossier):
    """Lit la réponse d'un juge v2. Rend None (aucun bloc lisible) ou {valide, preferee (identifiant servi), premier_gagne,
    critere, motif}. Une réponse lisible mais non conforme est **non valide** (comptée, jamais lue comme une victoire)."""
    bloc = extraire_bloc_json(texte, "comparaison") if isinstance(texte, str) else None
    if not bloc or not isinstance(bloc.get("comparaison"), dict):
        return None
    c = bloc["comparaison"]
    servies = {premiere[0]: premiere[1], seconde[0]: seconde[1]}
    base = {"valide": False, "preferee": None, "premier_gagne": None, "critere": c.get("critere"), "motif": None}
    pref = c.get("preferee")
    if pref not in servies:
        return dict(base, motif="« preferee » n'est aucun des deux identifiants servis")
    if c.get("critere") not in CRITERES_V2:
        return dict(base, motif=f"critère hors de la liste {CRITERES_V2}")
    autre = seconde[1] if pref == premiere[0] else premiere[1]
    ok, motif = verifier_citation(c.get("citation_fiche"), valeurs_textuelles(servies[pref]["contenu"]), CITATION_FICHE_MIN,
                                  CITATION_FICHE_MAX, valeurs_textuelles(autre["contenu"]))
    if not ok:
        return dict(base, motif="citation de la fiche : " + motif)
    if dossier_a_preuves(dossier):
        ok, motif = verifier_citation(c.get("citation_dossier"), [dossier], CITATION_DOSSIER_MIN, CITATION_DOSSIER_MAX)
        if not ok:
            return dict(base, motif="citation du dossier : " + motif)
    return dict(base, valide=True, preferee=pref, premier_gagne=pref == premiere[0])


# --- plan des comparaisons ---------------------------------------------------------------------------------------------------


def graphe_circulant(idents, degre, rng):
    """Graphe `degre`-régulier sur les fiches d'un lot : permutation tirée au hasard, arêtes aux décalages 1 à ⌊d/2⌋ et, si d
    est impair, n/2 (n pair exigé). Rend {ordre, decalages, paires (triées), cycle (arêtes du décalage 1)}."""
    idents = list(idents)
    n = len(idents)
    if len(set(idents)) != n:
        raise ProtocoleRefuse("graphe : identifiants en double")
    if isinstance(degre, bool) or not isinstance(degre, int) or degre < 2 or degre >= n:
        raise ProtocoleRefuse(f"graphe : degré entier de 2 à n − 1 exigé (n = {n}, reçu {degre!r})")
    if degre % 2 == 1 and n % 2 == 1:
        raise ProtocoleRefuse(f"graphe : degré impair ({degre}) exige un nombre pair de fiches (n = {n})")
    ordre = [idents[i] for i in rng.permutation(n)]
    decalages = list(range(1, degre // 2 + 1)) + ([n // 2] if degre % 2 else [])
    paires = sorted({tuple(sorted((ordre[k], ordre[(k + d) % n]))) for k in range(n) for d in decalages})
    cycle = sorted({tuple(sorted((ordre[k], ordre[(k + 1) % n]))) for k in range(n)})
    return {"ordre": ordre, "decalages": decalages, "paires": paires, "cycle": cycle}


def degres(paires):
    d = {}
    for a, b in paires:
        d[a] = d.get(a, 0) + 1
        d[b] = d.get(b, 0) + 1
    return d


def appels_paires(paires, deux_ordres, rng):
    """[(premier, second)] : un ordre tiré au hasard par paire et, avec `deux_ordres`, aussi l'ordre inverse ; l'ordre des
    appels est mélangé (les deux présentations d'une paire ne se suivent pas forcément)."""
    appels = []
    for a, b in paires:
        premier, second = (a, b) if rng.random() < 0.5 else (b, a)
        appels.append((premier, second))
        if deux_ordres:
            appels.append((second, premier))
    return [appels[i] for i in rng.permutation(len(appels))]


def familles_auteurs(fiche, correspondance):
    """Familles des auteurs d'une fiche du lot réel : fournisseur de la fiche, plus, pour une fusion, les fournisseurs de ses
    parents s'ils sont dits, sinon **toutes** les familles de la correspondance (prudence : une fusion mêle des auteurs)."""
    meta = fiche.get("meta") or {}
    f = meta.get("fournisseur")
    if f not in correspondance:
        raise ProtocoleRefuse(f"fiche {fiche.get('ident')!r} : fournisseur {f!r} hors de la correspondance {sorted(correspondance)}")
    familles = {correspondance[f]}
    if meta.get("origine") == "fusion":
        parents = meta.get("parents_fournisseurs")
        if isinstance(parents, list) and parents and all(p in correspondance for p in parents):
            familles |= {correspondance[p] for p in parents}
        else:
            familles |= set(correspondance.values())
    return familles


def juge_admissible(famille_juge, *familles):
    """Règle de famille : le juge n'est admis que si sa famille n'est celle d'aucun auteur des fiches servies."""
    return all(famille_juge not in f for f in familles)


# --- statistiques -------------------------------------------------------------------------------------------------------------


def aire(positifs, negatifs):
    """Aire sous la courbe ROC = probabilité qu'un positif tiré au hasard ait une note plus haute qu'un négatif (égalités
    comptées pour moitié) ; None si une classe est vide."""
    positifs, negatifs = list(positifs), list(negatifs)
    if not positifs or not negatifs:
        return None
    gagne = sum(1.0 if p > q else (0.5 if p == q else 0.0) for p in positifs for q in negatifs)
    return gagne / (len(positifs) * len(negatifs))


def loi_u(m, n):
    """Effectifs exacts de la statistique U de Mann et Whitney (nombre de couples positif > négatif), sans égalité, pour m
    positifs et n négatifs : liste indexée par u = 0…m·n (entiers ; total = C(m + n, m))."""
    table = {}
    for i in range(m + 1):
        for j in range(n + 1):
            if i == 0 or j == 0:
                table[(i, j)] = [1] + [0] * (i * j)
                continue
            t = [0] * (i * j + 1)
            for u, c in enumerate(table[(i - 1, j)]):  # le plus grand élément est un positif : il dépasse les j négatifs
                t[u + j] += c
            for u, c in enumerate(table[(i, j - 1)]):  # le plus grand élément est un négatif
                t[u] += c
            table[(i, j)] = t
    return table[(m, n)]


def seuil_u(m, n, alpha):
    """Plus petite valeur critique u telle que P(U ≥ u) ≤ alpha sous l'hypothèse nulle (loi exacte)."""
    effectifs = loi_u(m, n)
    total = sum(effectifs)
    queue = 0
    for u in range(m * n, -1, -1):
        if (queue + effectifs[u]) / total > alpha:
            return u + 1
        queue += effectifs[u]
    return 0


def test_mann_whitney(positifs, negatifs):
    """p unilatéral pour « les positifs ont des notes plus hautes » : loi exacte sans égalité (effectifs ≤ 30), sinon
    approximation normale avec correction d'égalités et de continuité. Rend {aire, u, p, methode}."""
    positifs, negatifs = list(positifs), list(negatifs)
    m, n = len(positifs), len(negatifs)
    if not m or not n:
        return {"aire": None, "u": None, "p": None, "methode": "classe vide"}
    u = sum(1.0 if p > q else (0.5 if p == q else 0.0) for p in positifs for q in negatifs)
    tout = positifs + negatifs
    egalites = len(set(tout)) < len(tout)
    if not egalites and m <= 30 and n <= 30:
        effectifs = loi_u(m, n)
        total = sum(effectifs)
        p = sum(effectifs[int(round(u)):]) / total
        return {"aire": u / (m * n), "u": u, "p": p, "methode": "loi exacte"}
    groupes = {}
    for v in tout:
        groupes[v] = groupes.get(v, 0) + 1
    N = m + n
    variance = m * n / 12.0 * ((N + 1) - sum(t ** 3 - t for t in groupes.values()) / (N * (N - 1)))
    if variance <= 0:
        return {"aire": u / (m * n), "u": u, "p": 1.0, "methode": "variance nulle (toutes les notes égales)"}
    z = (u - m * n / 2.0 - 0.5) / math.sqrt(variance)
    return {"aire": u / (m * n), "u": u, "p": 1.0 - statistics.NormalDist().cdf(z), "methode": "approximation normale"}


def _composantes_delong(notes, positifs, negatifs):
    v10 = [sum(1.0 if notes[p] > notes[q] else (0.5 if notes[p] == notes[q] else 0.0) for q in negatifs) / len(negatifs)
           for p in positifs]
    v01 = [sum(1.0 if notes[p] > notes[q] else (0.5 if notes[p] == notes[q] else 0.0) for p in positifs) / len(positifs)
           for q in negatifs]
    return v10, v01


def delong_difference(notes_a, notes_b, positifs, negatifs):
    """Différence appariée des aires (a − b) sur les mêmes fiches, variance de DeLong ; p unilatéral pour « a > b ». Variance
    nulle (séparation parfaite ou égalités complètes) : p = 0 si la différence est positive, 1 sinon, dit dans `statut`."""
    positifs, negatifs = list(positifs), list(negatifs)
    if len(positifs) < 2 or len(negatifs) < 2:
        return {"difference": None, "variance": None, "p": None, "statut": "effectifs insuffisants"}
    a10, a01 = _composantes_delong(notes_a, positifs, negatifs)
    b10, b01 = _composantes_delong(notes_b, positifs, negatifs)
    aire_a, aire_b = sum(a10) / len(a10), sum(b10) / len(b10)
    s10 = np.cov(np.vstack([a10, b10]))
    s01 = np.cov(np.vstack([a01, b01]))
    variance = float((s10[0, 0] + s10[1, 1] - 2 * s10[0, 1]) / len(positifs) + (s01[0, 0] + s01[1, 1] - 2 * s01[0, 1]) / len(negatifs))
    d = aire_a - aire_b
    if variance <= 1e-15:
        return {"aire_a": aire_a, "aire_b": aire_b, "difference": d, "variance": 0.0, "p": 0.0 if d > 0 else 1.0,
                "statut": "variance nulle (séparation parfaite ou égalités complètes)"}
    z = d / math.sqrt(variance)
    return {"aire_a": aire_a, "aire_b": aire_b, "difference": d, "variance": variance, "z": z,
            "p": 1.0 - statistics.NormalDist().cdf(z), "statut": "défini"}


def _rangs_moyens(valeurs):
    ordre = sorted(range(len(valeurs)), key=lambda i: valeurs[i])
    rangs = [0.0] * len(valeurs)
    i = 0
    while i < len(ordre):
        j = i
        while j + 1 < len(ordre) and valeurs[ordre[j + 1]] == valeurs[ordre[i]]:
            j += 1
        for k in range(i, j + 1):
            rangs[ordre[k]] = (i + j) / 2.0 + 1.0
        i = j + 1
    return rangs


def spearman(x, y):
    """Corrélation de rangs de Spearman (rangs moyens pour les égalités) ; None si une série est constante ou trop courte."""
    if len(x) != len(y) or len(x) < 3:
        return None
    rx, ry = _rangs_moyens(list(x)), _rangs_moyens(list(y))
    mx, my = sum(rx) / len(rx), sum(ry) / len(ry)
    sxy = sum((a - mx) * (b - my) for a, b in zip(rx, ry))
    sxx = sum((a - mx) ** 2 for a in rx)
    syy = sum((b - my) ** 2 for b in ry)
    if sxx == 0 or syy == 0:
        return None
    return sxy / math.sqrt(sxx * syy)


def kappa_cohen(a, b):
    """Kappa de Cohen sur deux suites de booléens appariées, convention v54 : accord attendu égal à 1 (marges constantes) →
    **non défini** (jamais 1, ce que rendait `juges_croises_v53.kappa_cohen`). Rend {kappa, accord, attendu, statut, n}."""
    a, b = [bool(x) for x in a], [bool(x) for x in b]
    n = len(a)
    if n == 0 or len(b) != n:
        return {"kappa": None, "accord": None, "attendu": None, "statut": "vide", "n": n}
    po = sum(x == y for x, y in zip(a, b)) / n
    pa, pb = sum(a) / n, sum(b) / n
    pe = pa * pb + (1 - pa) * (1 - pb)
    if abs(1 - pe) < 1e-12:
        return {"kappa": None, "accord": po, "attendu": pe, "statut": "non défini (accord attendu égal à 1 : marges constantes)",
                "n": n}
    return {"kappa": (po - pe) / (1 - pe), "accord": po, "attendu": pe, "statut": "défini", "n": n}


def ajuster_bt(idents, comparaisons, ridge=RIDGE_FORCES, ridge_position=RIDGE_POSITION, iterations=200):
    """Bradley et Terry avec effet de position : P(la fiche présentée en premier gagne) = σ(θ_premier − θ_second + γ).
    Maximum de vraisemblance pénalisé (crête `ridge` sur θ, `ridge_position` sur γ), Newton avec recherche linéaire.
    `comparaisons` : [(premier, second, premier_gagne)] (valides seulement). Rend {forces (θ centrées), position (γ), erreurs,
    comparaisons_par_fiche, sans_comparaison, iterations, converge}."""
    idents = list(idents)
    n = len(idents)
    index = {i: k for k, i in enumerate(idents)}
    nb = {i: 0 for i in idents}
    for p, s, _ in comparaisons:
        if p not in index or s not in index or p == s:
            raise ProtocoleRefuse(f"Bradley et Terry : comparaison ({p!r}, {s!r}) hors du lot ou d'une fiche à elle-même")
        nb[p] += 1
        nb[s] += 1
    if not comparaisons:
        return {"forces": {i: 0.0 for i in idents}, "position": 0.0, "erreurs": {i: None for i in idents},
                "comparaisons_par_fiche": nb, "sans_comparaison": list(idents), "iterations": 0, "converge": True}
    P = np.array([index[p] for p, _, _ in comparaisons])
    S = np.array([index[s] for _, s, _ in comparaisons])
    Y = np.array([1.0 if g else 0.0 for _, _, g in comparaisons])
    x = np.zeros(n + 1)

    def objectif(v):
        eta = v[P] - v[S] + v[n]
        return float(np.sum(Y * eta - np.logaddexp(0.0, eta)) - ridge / 2 * np.sum(v[:n] ** 2) - ridge_position / 2 * v[n] ** 2)

    def matrice(v):
        eta = v[P] - v[S] + v[n]
        q = 1.0 / (1.0 + np.exp(-eta))
        w = q * (1 - q)
        r = Y - q
        g = np.zeros(n + 1)
        np.add.at(g, P, r)
        np.add.at(g, S, -r)
        g[n] = r.sum()
        g[:n] -= ridge * v[:n]
        g[n] -= ridge_position * v[n]
        M = np.zeros((n + 1, n + 1))
        for (i, j, signe) in ((P, P, 1), (S, S, 1), (P, S, -1), (S, P, -1)):
            np.add.at(M, (i, j), signe * w)
        np.add.at(M, (P, np.full(len(P), n)), w)
        np.add.at(M, (np.full(len(P), n), P), w)
        np.add.at(M, (S, np.full(len(S), n)), -w)
        np.add.at(M, (np.full(len(S), n), S), -w)
        M[n, n] += w.sum()
        M[np.arange(n), np.arange(n)] += ridge
        M[n, n] += ridge_position
        return g, M

    converge, it = False, 0
    for it in range(1, iterations + 1):
        g, M = matrice(x)
        pas = np.linalg.solve(M, g)
        f0, t = objectif(x), 1.0
        while objectif(x + t * pas) < f0 - 1e-12 and t > 1e-8:
            t /= 2
        x = x + t * pas
        if float(np.max(np.abs(t * pas))) < 1e-10:
            converge = True
            break
    _, M = matrice(x)
    cov = np.linalg.inv(M)
    theta = x[:n] - x[:n].mean()
    return {"forces": {i: float(theta[k]) for i, k in index.items()}, "position": float(x[n]),
            "erreurs": {i: float(math.sqrt(max(cov[k, k], 0.0))) for i, k in index.items()},
            "erreur_position": float(math.sqrt(max(cov[n, n], 0.0))), "comparaisons_par_fiche": nb,
            "sans_comparaison": [i for i in idents if nb[i] == 0], "iterations": it, "converge": converge}


def verdicts_lot(forces, evaluees, ancre_bonne=None, ancre_mauvaise=None, part=PART_BUDGET):
    """Verdict v2 d'un lot : « notable » = parmi les `part` premiers (arrondi au-dessus) des fiches évaluées **et** au-dessus
    du milieu des deux ancres (quand le lot en porte). Plafond, pas quota : moins de notables si moins de fiches passent le
    plancher. Ancres inversées (la bonne ne dépasse pas la mauvaise) : aucun notable, statut dit. Égalité à la limite du
    budget : aucune des fiches à égalité n'est retenue (pas de départage arbitraire)."""
    evaluees = list(evaluees)
    k = math.ceil(part * len(evaluees)) if evaluees else 0
    plancher, statut = None, "sans ancre (verdict relatif seulement)"
    if (ancre_bonne is None) != (ancre_mauvaise is None):
        raise ProtocoleRefuse("verdicts : deux ancres (une bonne, une mauvaise) ou aucune")
    if ancre_bonne is not None:
        tb, tm = forces[ancre_bonne], forces[ancre_mauvaise]
        if tb - tm <= EPSILON_EGALITE:
            return {"verdicts": {i: False for i in evaluees}, "k": k, "plancher": None, "statut": "ancres inversées"}
        plancher, statut = (tb + tm) / 2.0, "ancré"
    candidats = sorted((i for i in evaluees if plancher is None or forces[i] > plancher + EPSILON_EGALITE),
                       key=lambda i: (-forces[i], i))
    retenus = candidats[:k]
    if len(candidats) > k > 0 and abs(forces[candidats[k - 1]] - forces[candidats[k]]) <= EPSILON_EGALITE:
        limite = forces[candidats[k - 1]]
        retenus = [i for i in retenus if abs(forces[i] - limite) > EPSILON_EGALITE]
    return {"verdicts": {i: i in retenus for i in evaluees}, "k": k, "plancher": plancher, "statut": statut}


def biais_position(enregistrements):
    """Sur les comparaisons valides d'un juge : part gagnée par la fiche présentée en premier ; paires vues dans les deux
    ordres et taux de bascule (le gagnant change quand l'ordre s'inverse)."""
    valides = [e for e in enregistrements if e.get("valide")]
    n = len(valides)
    premier = sum(1 for e in valides if e["premier_gagne"])
    par_paire = {}
    for e in valides:
        par_paire.setdefault(tuple(e["paire"]), []).append(e)
    deux, bascules = 0, 0
    for es in par_paire.values():
        ordres = {e["premier"] for e in es}
        if len(es) == 2 and len(ordres) == 2:
            deux += 1
            bascules += es[0]["gagnant"] != es[1]["gagnant"]
    return {"comparaisons_valides": n, "part_premier": premier / n if n else None, "paires_deux_ordres": deux,
            "bascules": bascules, "taux_bascule": bascules / deux if deux else None}


def kappa_paires(enregistrements_a, enregistrements_b):
    """Accord entre deux juges sur les paires que les deux ont jugées : chaque jugement valide de A (un par ordre présenté)
    est mis en regard du jugement valide de B sur la même paire ; issue codée « la première fiche de la paire, dans l'ordre
    canonique, gagne ». Les ordres de B sont tirés indépendamment de ceux de A : deux juges pilotés par la position ne
    s'accordent qu'au hasard (kappa voisin de 0), au lieu de paraître d'accord."""
    b = {}
    for e in enregistrements_b:
        if e.get("valide"):
            b.setdefault(tuple(e["paire"]), []).append(e)
    xa, xb = [], []
    for e in enregistrements_a:
        if not e.get("valide"):
            continue
        cle = tuple(e["paire"])
        for f in b.get(cle, []):
            xa.append(e["gagnant"] == cle[0])
            xb.append(f["gagnant"] == cle[0])
    r = kappa_cohen(xa, xb)
    r["paires"] = len({tuple(e["paire"]) for e in enregistrements_a if e.get("valide")} & set(b))
    return r
