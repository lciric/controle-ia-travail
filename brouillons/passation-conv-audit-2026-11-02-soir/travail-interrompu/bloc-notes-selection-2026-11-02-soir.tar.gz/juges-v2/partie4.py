

# --- lecture gelée --------------------------------------------------------------------------------------------------------------

SEUILS_LECTURE_V1 = {
    "alpha": 0.05,
    "aire_v2_min": 0.75,          # D1 : aire v2 du juge A (tirage 1), avec Mann et Whitney unilatéral p < alpha
    "plafond_ancien_min": 0.80,   # D2 : part de notables de l'ancien protocole (juge A, tirage 1) : « l'ancien sature »
    "delta_aire_min": 0.15,       # D3 : aire v2 − aire ancien (juge A, tirage 1), DeLong unilatéral p < alpha
    "retest_min": 0.70,           # D4 : Spearman entre les forces des tirages 1 et 2 (juge A)
    "bascule_max": 0.25,          # D5 : taux de bascule quand l'ordre s'inverse (juge A, tirage 1)
    "kappa_paires_min": 0.40,     # D6 : kappa des choix par paire entre A et B (tirage 1)
    "validite_min": 0.85,         # instrument : part des comparaisons valides (A, chaque tirage ; B pour D6)
    "presents_ancien_min": 18,    # instrument : verdicts lisibles de l'ancien protocole, juge A, sur 20 fiches
}
AUDIT_V1 = {"aire_haute": 0.98, "aire_basse": 0.55, "retest_haut": 0.98, "retest_bas": 0.30, "kappa_haut": 0.90, "kappa_bas": 0.0,
            "plafond_haut": 1.0, "plafond_bas": 0.20, "bascule_haute": 0.75, "paires_min_bascule_nulle": 30}
ISSUES_V1 = {
    "I0": "non jugeable : l'instrument n'a pas tenu (phase décisive du juge A incomplète, réponses inexploitables, arrêt) ; "
          "aucune conclusion sur les protocoles",
    "I1": "le protocole v2 discrimine les témoins là où l'ancien sature, de façon stable et sans pilotage par la position",
    "I2": "le protocole v2 discrimine les témoins, mais l'ancien ne sature pas sur ces témoins servis avec leur dossier : le "
          "plafond du second tour ne se reproduit pas ici",
    "I3": "le protocole v2 ne fait pas mieux : il ne discrimine pas les témoins au seuil gelé",
    "I4": "le protocole v2 discrimine les témoins mais n'est pas fiable (fidélité test-retest, bascule de position ou accord "
          "entre juges sous le seuil)",
}


def _phase_complete(completude, phase, juge):
    d = (completude or {}).get(f"{phase}/{juge}")
    return bool(d and d["complet"])


def lire_validation(m, seuils=None, audit=None):
    """Lecture gelée de la validation : critères D1 à D6, issue I0 à I4 (avec sous-issue), audit de symétrie (mêmes
    vérifications pour un résultat trop beau et pour un résultat décevant), prédictions tenues ou non. Ne lit que `m`."""
    s = dict(SEUILS_LECTURE_V1, **(seuils or {}))
    au = dict(AUDIT_V1, **(audit or {}))
    a, b = m["juges"]["a"], m["juges"]["b"]
    va1, va2, aa1 = m["v2"][a]["1"], m["v2"][a]["2"], m["ancien"][a]["1"]
    vb1 = m["v2"][b]["1"]
    raisons_i0 = []
    if not (_phase_complete(m.get("completude"), "decisive-a", a)):
        raisons_i0.append("phase décisive du juge A incomplète")
    for nom, v in (("v2 tirage 1", va1), ("v2 tirage 2", va2)):
        if not v.get("joues") or v.get("validite", 0) < s["validite_min"]:
            raisons_i0.append(f"{nom} : part valide {v.get('validite')} < {s['validite_min']}")
    if aa1["presents"] < s["presents_ancien_min"]:
        raisons_i0.append(f"ancien : {aa1['presents']} verdicts lisibles < {s['presents_ancien_min']}")
    pos = va1.get("position") or {}
    crit = {
        "D1": {"valeur": va1.get("aire"), "p": va1.get("p_mann_whitney"),
               "tenu": va1.get("aire") is not None and va1["aire"] >= s["aire_v2_min"] and (va1.get("p_mann_whitney") or 1) < s["alpha"]},
        "D2": {"valeur": aa1.get("part_notables"),
               "tenu": aa1.get("part_notables") is not None and aa1["part_notables"] >= s["plafond_ancien_min"]},
        "D3": {"valeur": m["comparaison_a"].get("difference"), "p": m["comparaison_a"].get("p"),
               "tenu": m["comparaison_a"].get("difference") is not None and m["comparaison_a"]["difference"] >= s["delta_aire_min"]
               and (m["comparaison_a"].get("p") if m["comparaison_a"].get("p") is not None else 1) < s["alpha"]},
        "D4": {"valeur": m["test_retest_a"]["spearman"],
               "tenu": m["test_retest_a"]["spearman"] is not None and m["test_retest_a"]["spearman"] >= s["retest_min"]},
        "D5": {"valeur": pos.get("taux_bascule"), "part_premier": pos.get("part_premier"),
               "tenu": pos.get("taux_bascule") is not None and pos["taux_bascule"] <= s["bascule_max"]},
    }
    kp = m["accord"]["kappa_paires_v2"]
    b_mesurable = _phase_complete(m.get("completude"), "decisive-b", b) and vb1.get("joues") and vb1.get("validite", 0) >= s["validite_min"]
    crit["D6"] = {"valeur": kp.get("kappa"), "statut": kp.get("statut"),
                  "tenu": (kp.get("kappa") is not None and kp["kappa"] >= s["kappa_paires_min"]) if b_mesurable else None}
    if raisons_i0:
        issue, sous = "I0", "; ".join(raisons_i0)
    elif not crit["D1"]["tenu"]:
        issue, sous = "I3", ("I3a : l'ancien sature aussi (D2 tenu)" if crit["D2"]["tenu"] else "I3b : l'ancien ne sature pas (D2 non tenu)")
    elif not (crit["D4"]["tenu"] and crit["D5"]["tenu"] and crit["D6"]["tenu"] is not False):
        manquent = [k for k in ("D4", "D5", "D6") if crit[k]["tenu"] is False]
        issue, sous = "I4", "critères non tenus : " + ", ".join(manquent)
    elif crit["D2"]["tenu"]:
        issue, sous = "I1", ("I1a : gain mesuré sur l'ancien (D3 tenu)" if crit["D3"]["tenu"] else "I1b : gain non établi (D3 non tenu)")
    else:
        issue, sous = "I2", ("I2a : gain mesuré sur l'ancien (D3 tenu)" if crit["D3"]["tenu"] else "I2b : gain non établi (D3 non tenu)")
    reserves = []
    if crit["D6"]["tenu"] is None and issue in ("I1", "I2", "I4"):
        reserves.append("accord entre juges non mesuré (phase du juge B incomplète ou invalide)")
    return {"issue": issue, "libelle": ISSUES_V1[issue], "sous_issue": sous, "criteres": crit, "seuils": s, "reserves": reserves,
            "audit": audit_symetrie(m, au), "predictions": predictions_v1(m)}


def audit_symetrie(m, au=None):
    """Déclencheurs symétriques : un résultat « trop beau » et un résultat « décevant » déclenchent la même liste de
    vérifications (`VERIFICATIONS_AUDIT`), faite par un lecteur neuf avant toute lecture de l'issue."""
    au = dict(AUDIT_V1, **(au or {}))
    a = m["juges"]["a"]
    va1, aa1 = m["v2"][a]["1"], m["ancien"][a]["1"]
    pos = va1.get("position") or {}
    motifs = []
    x = va1.get("aire")
    if x is not None and x >= au["aire_haute"]:
        motifs.append(f"trop beau : aire v2 {x:.3f} ≥ {au['aire_haute']}")
    if x is not None and x <= au["aire_basse"]:
        motifs.append(f"décevant : aire v2 {x:.3f} ≤ {au['aire_basse']}")
    r = m["test_retest_a"]["spearman"]
    if r is not None and r >= au["retest_haut"]:
        motifs.append(f"trop beau : test-retest {r:.3f} ≥ {au['retest_haut']}")
    if r is not None and r <= au["retest_bas"]:
        motifs.append(f"décevant : test-retest {r:.3f} ≤ {au['retest_bas']}")
    k = m["accord"]["kappa_paires_v2"].get("kappa")
    if k is not None and k >= au["kappa_haut"]:
        motifs.append(f"trop beau : kappa des paires {k:.3f} ≥ {au['kappa_haut']}")
    if k is not None and k <= au["kappa_bas"]:
        motifs.append(f"décevant : kappa des paires {k:.3f} ≤ {au['kappa_bas']}")
    p = aa1.get("part_notables")
    if p is not None and p >= au["plafond_haut"]:
        motifs.append(f"trop propre : ancien protocole à {p:.2f} de notables")
    if p is not None and p <= au["plafond_bas"]:
        motifs.append(f"inattendu : ancien protocole à {p:.2f} de notables")
    t = pos.get("taux_bascule")
    if t is not None and t == 0 and pos.get("paires_deux_ordres", 0) >= au["paires_min_bascule_nulle"]:
        motifs.append("trop propre : aucune bascule de position")
    if t is not None and t >= au["bascule_haute"]:
        motifs.append(f"décevant : bascule de position {t:.2f} ≥ {au['bascule_haute']}")
    return {"declenche": bool(motifs), "motifs": motifs, "verifications": VERIFICATIONS_AUDIT if motifs else ()}


VERIFICATIONS_AUDIT = (
    "recalcul indépendant de toutes les mesures depuis le journal scellé (réponses brutes, entrées par empreinte)",
    "relecture de six réponses brutes tirées au hasard par juge et par protocole (citations, critère, cohérence du choix)",
    "aucune étiquette de classe, de rôle ou d'auteur dans les entrées servies (garde A4 rejouée sur chaque entrée)",
    "modèle servi égal au modèle demandé sur chaque appel ; nombre d'appels joués égal au plan",
    "empreinte des matériaux égale à celle du texte scellé ; contrôle de forme rejoué",
    "ordres de présentation conformes au plan (deux ordres pour chaque paire du juge A)",
    "témoins classés par classe : un résultat porté par une seule classe (par exemple les textes longs) est dit",
)


def predictions_v1(m):
    """Prédictions chiffrées et signées du texte (brouillon 1), évaluées ici ; elles ne décident pas l'issue."""
    a, b = m["juges"]["a"], m["juges"]["b"]
    va1, aa1, ab1 = m["v2"][a]["1"], m["ancien"][a]["1"], m["ancien"][b]["1"]
    pos = va1.get("position") or {}
    rangs = m["classes"]["rang_v2_a1"]
    nc = m["classes"]["notables_ancien_a1"]

    def p(valeur, test):
        return {"valeur": valeur, "tenue": None if valeur is None else bool(test(valeur))}

    kp = m["accord"]["kappa_paires_v2"].get("kappa")
    ka = m["accord"]["kappa_ancien"]
    return {
        "P1 ancien A : part de notables ≥ 0,80": p(aa1.get("part_notables"), lambda v: v >= 0.80),
        "P2 ancien A : aire ≤ 0,65": p(aa1.get("aire"), lambda v: v <= 0.65),
        "P3 v2 A : aire ≥ 0,80": p(va1.get("aire"), lambda v: v >= 0.80),
        "P4 v2 − ancien (A) : différence d'aire ≥ +0,15": p(m["comparaison_a"].get("difference"), lambda v: v >= 0.15),
        "P5 v2 A : faux notables ≤ 0,10 ; ancien A : faux notables ≥ 0,70": p(
            (va1.get("faux_notables"), aa1.get("faux_notables")) if va1.get("faux_notables") is not None and aa1.get("faux_notables") is not None else None,
            lambda v: v[0] <= 0.10 and v[1] >= 0.70),
        "P6 kappa des paires v2 ≥ 0,40 ; kappa ancien ≤ 0,20 ou non défini": p(
            (kp, ka.get("kappa")) if kp is not None and ka.get("n") else None,
            lambda v: v[0] >= 0.40 and (v[1] is None or v[1] <= 0.20)),
        "P7 test-retest v2 A ≥ 0,70": p(m["test_retest_a"]["spearman"], lambda v: v >= 0.70),
        "P8 bascule v2 A ≤ 0,25 et part du premier dans [0,40 ; 0,60]": p(
            (pos.get("taux_bascule"), pos.get("part_premier")) if pos.get("taux_bascule") is not None else None,
            lambda v: v[0] <= 0.25 and 0.40 <= v[1] <= 0.60),
        "P9 textes longs : rang moyen v2 A < 0,5 ; notables à l'ancien": p(
            (rangs.get("verbeuse"), nc.get("verbeuse")) if rangs.get("verbeuse") is not None and nc.get("verbeuse") is not None else None,
            lambda v: v[0] < 0.5 and v[1] >= 0.5),
        "P10 redites d'une loi établie : rang moyen v2 A < 0,5": p(rangs.get("copie_archive"), lambda v: v < 0.5),
        "P11 juge B, ancien : part de notables ≥ 0,80": p(ab1.get("part_notables"), lambda v: v >= 0.80),
    }


# --- puissance -------------------------------------------------------------------------------------------------------------------


def puissance_aire(n_bons, n_mauvais, aire_vraie, *, alpha=0.05, repetitions=20000, graine=0, seuil_point=0.75):
    """Modèle binormal (mauvais ~ N(0, 1), bons ~ N(d, 1), d = √2·Φ⁻¹(aire)) : part des tirages où le test de Mann et Whitney
    unilatéral (loi exacte) rejette « aire = 0,5 » au niveau `alpha`, part où l'aire estimée atteint `seuil_point`, et part
    où les deux tiennent (critère D1)."""
    d = math.sqrt(2.0) * statistics.NormalDist().inv_cdf(aire_vraie) if 0 < aire_vraie < 1 else None
    if d is None:
        raise ProtocoleRefuse("aire vraie dans ]0 ; 1[ exigée")
    ss = np.random.SeedSequence(graine, spawn_key=(cle_de_tache(f"puissance|{n_bons}|{n_mauvais}|{aire_vraie}|{alpha}"),))
    rng = np.random.default_rng(ss)
    uc = seuil_u(n_bons, n_mauvais, alpha)
    effectifs = loi_u(n_bons, n_mauvais)
    alpha_exact = sum(effectifs[uc:]) / sum(effectifs)
    rejets = point = deux = 0
    reste = repetitions
    while reste:
        k = min(reste, 5000)
        pos = rng.normal(d, 1.0, size=(k, n_bons))
        neg = rng.normal(0.0, 1.0, size=(k, n_mauvais))
        u = (pos[:, :, None] > neg[:, None, :]).sum(axis=(1, 2))
        r = u >= uc
        q = u >= seuil_point * n_bons * n_mauvais - 1e-9
        rejets, point, deux = rejets + int(r.sum()), point + int(q.sum()), deux + int((r & q).sum())
        reste -= k
    return {"n_bons": n_bons, "n_mauvais": n_mauvais, "aire_vraie": aire_vraie, "u_critique": uc, "alpha_exact": alpha_exact,
            "puissance_test": rejets / repetitions, "part_aire_au_seuil": point / repetitions, "critere_d1": deux / repetitions,
            "repetitions": repetitions}


# --- juges scriptés (essais et course à blanc ; aucun appel) -------------------------------------------------------------------

STRATEGIES = ("plafond", "position", "parfait", "indulgent", "bruite", "verbeux", "inverse", "illisible", "citations_fausses")
_BLOC_PAIRE = re.compile(r"## Fiche (\S+) \(présentée en (premier|second)\)\n```json\n(.*?)\n```", re.S)
_BLOC_SEUL = re.compile(r"## La fiche\n```json\n(.*?)\n```", re.S)


def oracle_depuis(materiaux, lot_reel=None, qualites_reel=None):
    """{empreinte du contenu: qualité} pour les juges scriptés (jamais servi à un juge réel)."""
    o = {empreinte_objet(f["contenu"]): f["qualite"] for l in materiaux["lots"] for f in l["fiches"]}
    if lot_reel is not None:
        for f in lot_reel["fiches"]:
            o[empreinte_objet(f["contenu"])] = (qualites_reel or {}).get(f["ident"], 0.5)
    return o


def _citation_propre(choisie, autre, longueur=60):
    autre_n = normaliser_citation(" ".join(valeurs_textuelles(autre)))
    for v in valeurs_textuelles(choisie):
        for debut in range(0, max(1, len(v) - 20), 7):
            morceau = v[debut:debut + longueur]
            n = normaliser_citation(morceau)
            if len(n) >= CITATION_FICHE_MIN and n not in autre_n:
                return morceau
    return valeurs_textuelles(choisie)[0][:longueur]


class AdaptateurScripte(Adaptateur):
    """Juge scripté (aucun appel) au contrat des adaptateurs du pôle : lit l'entrée servie (paire ou fiche seule), rend une
    réponse au format attendu. Stratégies : « plafond » (ancien : tout vrai ; v2 : toujours la première présentée),
    « position » (v2 : toujours la première), « parfait » (connaît la qualité par l'oracle), « indulgent » (ancien : tout vrai ;
    v2 : parfait), « bruite » (juste avec probabilité `p_juste`, penche vers la première avec `biais_premier`), « verbeux »
    (préfère la fiche la plus longue), « inverse » (préfère la moins bonne), « illisible » (aucun bloc), « citations_fausses »
    (choix parfait, citation inventée)."""

    nom = "juge-scripte-v2"

    def __init__(self, strategie, oracle, *, graine=0, cout_par_appel_usd=0.0, items=ITEMS_SUBSTITUTION, modele_servi=None,
                 p_juste=0.75, biais_premier=0.10, p_item_bon=0.97, p_item_mauvais=0.85):
        if strategie not in STRATEGIES:
            raise ProtocoleRefuse(f"stratégie de juge scripté inconnue {strategie!r} ({STRATEGIES})")
        self.strategie, self.oracle, self.graine = strategie, oracle, int(graine)
        self.cout, self.items, self.modele_servi = float(cout_par_appel_usd), list(items), modele_servi
        self.p_juste, self.biais_premier, self.p_item_bon, self.p_item_mauvais = p_juste, biais_premier, p_item_bon, p_item_mauvais
        self.appels = 0

    def description(self):
        return {"version": VERSION, "strategie": self.strategie, "cout_par_appel_usd": self.cout, "fictif": True}

    def _rng(self, consigne):
        h = hashlib.sha256(f"{self.graine}|{self.strategie}|{consigne}".encode("utf-8")).digest()
        return np.random.default_rng(int.from_bytes(h[:8], "big"))

    def _qualite(self, contenu):
        return self.oracle.get(empreinte_objet(contenu), 0.5)

    def _paire(self, consigne):
        blocs = _BLOC_PAIRE.findall(consigne)
        (i1, _, j1), (i2, _, j2) = blocs[0], blocs[1]
        c1, c2 = json.loads(j1), json.loads(j2)
        c1.pop("identifiant", None)
        c2.pop("identifiant", None)
        q1, q2 = self._qualite(c1), self._qualite(c2)
        rng = self._rng(consigne)
        st = self.strategie
        if st in ("plafond", "position"):
            premier = True
        elif st == "verbeux":
            premier = len(json.dumps(c1, ensure_ascii=False)) >= len(json.dumps(c2, ensure_ascii=False))
        elif st == "inverse":
            premier = q1 < q2 if q1 != q2 else empreinte_objet(c1) < empreinte_objet(c2)
        else:
            premier = q1 > q2 if q1 != q2 else empreinte_objet(c1) > empreinte_objet(c2)
            if st == "bruite":
                if q1 != q2 and rng.random() > self.p_juste:
                    premier = not premier
                elif q1 == q2:
                    premier = bool(rng.random() < 0.5)
                if rng.random() < self.biais_premier:
                    premier = True
        choisie, autre = (c1, c2) if premier else (c2, c1)
        citation = _citation_propre(choisie, autre)
        if st == "citations_fausses":
            citation = "une phrase qui ne figure dans aucune des deux fiches servies"
        m = re.search(r"(?m)^- (D\d{2,} · .+)$", consigne)
        corps = {"comparaison": {"preferee": i1 if premier else i2, "critere": "verite", "citation_fiche": citation,
                                 "citation_dossier": m.group(1) if m else ""}}
        return "Ma comparaison :\n```json\n" + json.dumps(corps, ensure_ascii=False) + "\n```"

    def _seule(self, consigne):
        c = json.loads(_BLOC_SEUL.search(consigne).group(1))
        c.pop("identifiant", None)
        q = self._qualite(c)
        rng = self._rng(consigne)
        st = self.strategie
        items = {k: True for k in self.items}
        h = int(empreinte_objet(c), 16)
        if st in ("parfait", "citations_fausses") and q < 0.5:
            items[self.items[h % len(self.items)]] = False
        elif st == "inverse" and q >= 0.5:
            items[self.items[h % len(self.items)]] = False
        elif st == "bruite":
            p = self.p_item_bon if q >= 0.5 else self.p_item_mauvais
            items = {k: bool(rng.random() < p) for k in self.items}
        return "```json\n" + json.dumps({"items": items, "note": sum(items.values())}) + "\n```"

    def lancer(self, role, consigne, dossier, budget_usd, max_tours, modele=None):
        self.appels += 1
        if self.strategie == "illisible":
            texte = "Je préfère ne pas trancher entre ces fiches."
        elif "(présentée en premier)" in consigne:
            texte = self._paire(consigne)
        elif "## La fiche" in consigne:
            texte = self._seule(consigne)
        else:
            texte = "aucune entrée reconnue"
        cout = min(self.cout, float(budget_usd))
        return Resultat(texte, [], cout, "ok", texte_brut=texte, modele_servi=self.modele_servi or modele)


QUESTION_SUBSTITUTION = ("Question de substitution pour la course sans appel réel (aucune valeur réelle) : proposer une "
                         "méthode de surveillance des agents de code qui détecte une menace diffuse sans lire les intentions "
                         "déclarées de l'agent ; chaque fiche nomme son hypothèse, sa prédiction et ce qui la réfuterait.")


def lot_reel_substitution(graine=0, n=12):
    """Lot « réel » de substitution pour la course sans appel réel : `n` fiches factices, auteurs alternés (kimi, argon), une
    fusion ; qualités tirées au hasard pour l'oracle des juges scriptés. Rend (objet du lot, qualités)."""
    rng = Graines(graine).generateur("lot-reel-substitution")
    fiches, qualites = [], {}
    for k in range(1, n + 1):
        ident = f"reel-{k:02d}"
        meta = {"fournisseur": "kimi" if k % 2 else "argon", "origine": "proposition"}
        if k == n:
            meta = {"fournisseur": "kimi", "origine": "fusion", "parents_fournisseurs": ["kimi", "argon"]}
        contenu = {"titre": f"Fiche factice numéro {k}", "hypothese": f"Hypothèse factice numéro {k} sur la surveillance des agents "
                   f"de code, variante {int(rng.integers(0, 1000))}.", "prediction": f"Prédiction factice numéro {k}.",
                   "signe": "+", "metrique": "mesure factice", "test_de_mort": f"Critère d'abandon factice numéro {k}."}
        fiches.append({"ident": ident, "contenu": contenu, "meta": meta})
        qualites[ident] = float(rng.random() < 0.5)
    return {"fiches": fiches}, qualites
