import pathlib
M = pathlib.Path('/home/claude/controle-ia-travail/brouillons/candidature-pivotal-v16/mentors')

# --- Ibrahim v25 : Q2 condensée (demande de Lazar, 18:58 UTC : « aller droit à l'essentiel », « marquer les esprits »)
s = (M / 'mentor-1-ibrahim-v24.md').read_text(encoding='utf-8')
i = s.index('## Q2')
q2_titre = s[i:].split('\n', 1)[0]
nouveau_q2 = q2_titre + '''

"Sycophancy as Attraction Toward a Fixed Point" (paper forthcoming; code + data: github.com/lciric/sycophancy-psychophysical-law).

Sycophancy is a shift by some amount, not a binary flip. We used psychophysical methods (quantified social pressure, an ordinal judge sealed before any data, permutation nulls, equal-length placebos). Under pressure, Llama-3.1-8B-Instruct travels about .7 of the distance towards a fixed point set by the social frame, one for criticism and one for praise, so praise can lower a highly rated answer (we predicted it). Fitted once, the law predicted a second campaign and 60 new items, written blind and posted before generation, with no new fitting (R² up to .73), and judges from another family recover it.

Then we turned the pressure up (preregistered, four model families), and our prediction failed: the law does not scale with the intensity of the pressure. Under the most insistent flattery, Llama resets its rating toward the middle of the scale or declines to evaluate; under the harshest criticism, it increasingly contradicts the user. We published the failure as such.

What drives the behaviour is not what reads it: a direction that tracks it (ρ = .68) carries under 1% of its causal effect, against 68% for the full residual state.

Every study was preregistered and hash-sealed before any data, engineered by AI coding agents under rules I wrote, and every number traces back to its file and hash.

Second public project: my automated research system with a judge that cannot be convinced: github.com/lciric/ideation-organism
'''
s = s[:i] + nouveau_q2
s = s.replace('— v24\n', '— v25\n', 1)
s = s.replace('2 November 2026. v24 = ', "2 November 2026. v25 = v24 with Q2 cut to the essentials at Lazar's request (18:58 UTC: « go straight to the essential, mark minds, do not drown the reader »): three findings, one figure each; his phrasings kept where they carry (« a shift by some amount, not a binary flip », « .7 of the distance towards a fixed point set by the social frame », « praise … lower in score (predicted) », « every number traces back to its file and hash »); cross-family detail dropped (and with it « So far only Llama-3.1-8B-Instruct has been observed to be attracted to 2 points », which R6 contradicts: Mistral-7B shows attraction at the mild and strong wordings, results/R6/R6_mistral_dose_output.txt); v24 = ", 1)
(M / 'mentor-1-ibrahim-v25.md').write_text(s, encoding='utf-8')

# --- Colognese et Ward v17 : deux phrases de Lazar (19:00 UTC) à la place de « That's the failure mode … »
c = (M / 'mentor-5-colognese-ward-v16.md').read_text(encoding='utf-8')
a = ("That's the failure mode I'm most concerned with: character training can filter out obvious bad reasoning while leaving subtle "
     "attacks intact, so CoT and action monitors become less effective exactly in the regions where the training seemed successful.")
assert c.count(a) == 1, 'passage C&W introuvable'
b = ("One of my biggest concerns about this type of training is that we can train away blatant forms of bad logic but more subtle attacks "
     "remain unaffected. Meaning CoT/action monitoring may be less useful in areas where character training works well.")
c = c.replace(a, b)
c = c.replace('— v16\n', '— v17\n', 1)
c = c.replace('2 November 2026. ', "2 November 2026. v17 = v16 with the concern sentence of Q2 in Lazar's wording (19:00 UTC), verbatim, no substance change; ", 1)
(M / 'mentor-5-colognese-ward-v17.md').write_text(c, encoding='utf-8')

# --- Heimersheim v23 : phrase R6 proposée dans « Things that would convince me » (Q1 longue), à reformuler par Lazar lui-même
h = (M / 'mentor-3-heimersheim-v22.md').read_text(encoding='utf-8')
a = "Things that would convince me: dose–response curves for the awareness vector against an otherwise norm-matched random control"
assert h.count(a) == 1
j = h.index(a)
k = h.index('\n', j)
paragraphe = h[j:k]
ajout = (" [DRAFT FOR LAZAR TO REWRITE IN HIS OWN WORDS — mentor's « 100% human-written » rule] I have measured the behavioural side of such a "
         "curve for sycophancy (preregistered, three intensities of the pressure sentence): under criticism the gain is already at its plateau "
         "with the mildest wording (0.66, 0.68, 0.63), and what moves with the dose is the destination, not the gain.")
h = h[:k] + ajout + h[k:]
h = h.replace('— v22\n', '— v23\n', 1)
h = h.replace('2 November 2026. v22 = ', "2 November 2026. v23 = v22 + one R6 sentence drafted at Lazar's request (19:00 UTC: « modifie heimersheim aussi et je le reformule tout de suite derrière »), marked as a draft to be rewritten by him (mentor's human-written rule); figures checked in results/R6/R6_llama_dose_output.txt (critical g 0.658, 0.678, 0.629; c(strong) − c(mild) = +0.50 [0.15, 0.80]); 150-word version and Q2 unchanged; v22 = ", 1)
(M / 'mentor-3-heimersheim-v23.md').write_text(h, encoding='utf-8')
print('ok')
