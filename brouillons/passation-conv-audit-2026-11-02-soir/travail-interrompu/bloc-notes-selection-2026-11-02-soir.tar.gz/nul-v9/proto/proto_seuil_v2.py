"""Prototype v2 : EM par lots avec élagage certifié des coupes (borne < meilleure valeur atteinte), départ = ajustement
sans coupure ; temps par instant de lecture."""
import random
import sys
import time

import numpy as np

sys.path.insert(0, "/home/claude/ideation-organism/orchestrator")
sys.path.insert(0, "/tmp/claude-0/-home-claude/03748db6-42ca-5241-871c-5399d39c1451/scratchpad/nul-v9/proto")
from proto_seuil_v1 import donnees  # noqa: E402


def em_global(L, y, K, w=None, iterations=5000, tol=1e-7):
    """Un seul morceau : max Σ log(a·L_i + r_{y_i}) ; rend (a, r)."""
    t, J = L.shape
    G = np.concatenate([L, np.eye(K)[y]], axis=1)
    w = np.full(J + K, 1.0 / (J + K)) if w is None else w
    for _ in range(iterations):
        m = G @ w
        g = G.T @ (1.0 / m)
        if g.max() - t < tol:
            break
        w = w * g / t
        w /= w.sum()
    return w[:J], w[J:]


def seuil_elague(L, y, z, K, tau=1e-3, it_max=3000, controle=5):
    t, J = L.shape
    ordre = np.argsort(z, kind="stable")
    Ls, ys, zs = L[ordre], y[ordre], z[ordre]
    coupes = np.array([0] + [c for c in range(1, t) if zs[c - 1] < zs[c]] + [t])
    a0, r0 = em_global(L, y, K)
    C = len(coupes)
    A_lo = np.tile(a0, (C, 1)); A_hi = np.tile(a0, (C, 1)); R = np.tile(r0, (C, 1))
    Y = np.eye(K)[ys]
    borne = np.zeros(C)
    actives = np.arange(C)
    meilleure = -np.inf
    iterations = 0
    while True:
        cc = coupes[actives]
        lo = (np.arange(t)[:, None] < cc[None, :]).astype(float)
        hi = 1.0 - lo
        al, ah, rr = A_lo[actives], A_hi[actives], R[actives]
        m = lo * (Ls @ al.T) + hi * (Ls @ ah.T) + rr[:, ys].T
        inv = 1.0 / m
        D_lo, D_hi, E = (Ls.T @ (lo * inv)).T, (Ls.T @ (hi * inv)).T, (Y.T @ inv).T
        if iterations % controle == 0 or iterations >= it_max:
            val = np.log(m).sum(axis=0)
            V = np.maximum(E.max(axis=1), D_lo.max(axis=1) + D_hi.max(axis=1))
            b = np.minimum(0.0, val + V - t)
            borne[actives] = np.minimum(borne[actives], b) if iterations else b
            meilleure = max(meilleure, float(val.max()))
            garde = borne[actives] >= meilleure
            haut = float(borne[actives].max())
            if haut - meilleure <= tau or iterations >= it_max:
                return {"valeur": haut, "atteinte": meilleure, "iterations": iterations, "coupes": C,
                        "actives": int(garde.sum()), "coupe": int(cc[int(np.argmax(borne[actives]))])}
            actives = actives[garde]
            if not garde.all():
                continue  # recalcule sur les coupes restantes
        Clo, Chi, Rk = al * D_lo, ah * D_hi, rr * E
        Slo, Shi = Clo.sum(axis=1), Chi.sum(axis=1)
        S = Slo + Shi
        R[actives] = Rk / t
        nlo = np.where(Slo[:, None] > 0, Clo / np.maximum(Slo, 1e-300)[:, None], al / np.maximum(al.sum(axis=1, keepdims=True), 1e-300))
        nhi = np.where(Shi[:, None] > 0, Chi / np.maximum(Shi, 1e-300)[:, None], ah / np.maximum(ah.sum(axis=1, keepdims=True), 1e-300))
        A_lo[actives] = nlo * (S / t)[:, None]
        A_hi[actives] = nhi * (S / t)[:, None]
        iterations += 1


if __name__ == "__main__":
    for monde in ("S1", "seuil", "sp"):
        for graine in (3, 4, 5):
            inst, y, P = donnees(graine, 200, monde)
            Lm = P[:, np.arange(200), y].T
            total = 0.0
            lignes = []
            for t in (25, 50, 75, 100, 125, 150, 175, 200):
                for j in (0, 1):
                    z = np.array([x["z"][j] for x in inst[:t]])
                    d = time.time()
                    r = seuil_elague(Lm[:t], y[:t], z, 3)
                    total += time.time() - d
                    if t == 200:
                        lignes.append((j, r))
            print(monde, graine, f"total 8 instants × 2 traits : {total*1000:.0f} ms", [(j, round(r['valeur'], 3), round(r['valeur'] - r['atteinte'], 4), r['iterations'], r['actives'], r['coupe']) for j, r in lignes])
