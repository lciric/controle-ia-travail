import sys
import numpy as np
sys.path.insert(0, ".")
from proto_seuil_v1 import donnees
from proto_seuil_v2 import em_global
inst, y, P = donnees(3, 200, "sp")
Lm = P[:, np.arange(200), y].T
t = 200; K = 3
z = np.array([x["z"][0] for x in inst[:t]])
ordre = np.argsort(z, kind="stable")
Ls, ys, zs = Lm[ordre], y[ordre], z[ordre]
coupes = np.array([0] + [c for c in range(1, t) if zs[c - 1] < zs[c]] + [t])
a0, r0 = em_global(Lm, y, K)
print("a0", a0, "r0", r0, "somme", a0.sum() + r0.sum())
C = len(coupes)
A_lo = np.tile(a0, (C, 1)); A_hi = np.tile(a0, (C, 1)); R = np.tile(r0, (C, 1))
Y = np.eye(K)[ys]
lo = (np.arange(t)[:, None] < coupes[None, :]).astype(float); hi = 1 - lo
pire = 0
for it in range(400):
    m = lo * (Ls @ A_lo.T) + hi * (Ls @ A_hi.T) + R[:, ys].T
    inv = 1 / m
    D_lo, D_hi, E = (Ls.T @ (lo * inv)).T, (Ls.T @ (hi * inv)).T, (Y.T @ inv).T
    val = np.log(m).sum(axis=0)
    V = np.maximum(E.max(axis=1), D_lo.max(axis=1) + D_hi.max(axis=1))
    b = val + np.maximum(0, V - t)
    s_lo = A_lo.sum(1) + R.sum(1); s_hi = A_hi.sum(1) + R.sum(1)
    pire = max(pire, np.abs(s_lo - 1).max(), np.abs(s_hi - 1).max())
    Clo, Chi, Rk = A_lo * D_lo, A_hi * D_hi, R * E
    Slo, Shi = Clo.sum(1), Chi.sum(1); S = Slo + Shi
    tot = S + Rk.sum(1)
    if it % 100 == 0:
        print(it, "max |S+R-t|", np.abs(tot - t).max(), "infaisabilité", pire, "val max", val.max(), "borne max", b.max())
    R = Rk / t
    nlo = np.where(Slo[:, None] > 0, Clo / np.maximum(Slo, 1e-300)[:, None], A_lo / np.maximum(A_lo.sum(1, keepdims=True), 1e-300))
    nhi = np.where(Shi[:, None] > 0, Chi / np.maximum(Shi, 1e-300)[:, None], A_hi / np.maximum(A_hi.sum(1, keepdims=True), 1e-300))
    A_lo = nlo * (S / t)[:, None]; A_hi = nhi * (S / t)[:, None]
