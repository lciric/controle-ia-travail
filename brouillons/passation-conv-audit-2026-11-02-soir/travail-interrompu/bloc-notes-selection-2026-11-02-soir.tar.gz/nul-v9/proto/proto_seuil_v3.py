"""Prototype v3 : EM par lots + élagage certifié + mise à zéro des poids de bord (ensemble actif) ; écart de FW ≥ 0."""
import sys
import time

import numpy as np

sys.path.insert(0, "/tmp/claude-0/-home-claude/03748db6-42ca-5241-871c-5399d39c1451/scratchpad/nul-v9/proto")
from proto_seuil_v1 import donnees  # noqa: E402
from proto_seuil_v2 import em_global  # noqa: E402


def seuil_v3(L, y, z, K, tau=1e-3, it_max=2000, controle=5, zero=1e-6):
    t, J = L.shape
    ordre = np.argsort(z, kind="stable")
    Ls, ys, zs = L[ordre], y[ordre], z[ordre]
    coupes = np.array([0] + [c for c in range(1, t) if zs[c - 1] < zs[c]] + [t])
    a0, r0 = em_global(L, y, K)
    C = len(coupes)
    A_lo = np.tile(a0, (C, 1)); A_hi = np.tile(a0, (C, 1)); R = np.tile(r0, (C, 1))
    Y = np.eye(K)[ys]
    borne = np.full(C, np.inf)
    actives = np.arange(C)
    meilleure = -np.inf
    it = 0
    while True:
        cc = coupes[actives]
        lo = (np.arange(t)[:, None] < cc[None, :]).astype(float)
        hi = 1.0 - lo
        al, ah, rr = A_lo[actives], A_hi[actives], R[actives]
        m = lo * (Ls @ al.T) + hi * (Ls @ ah.T) + rr[:, ys].T
        inv = 1.0 / m
        D_lo, D_hi, E = (Ls.T @ (lo * inv)).T, (Ls.T @ (hi * inv)).T, (Y.T @ inv).T
        if it % controle == 0 or it >= it_max:
            val = np.log(m).sum(axis=0)
            V = np.maximum(E.max(axis=1), D_lo.max(axis=1) + D_hi.max(axis=1))
            b = np.minimum(0.0, val + np.maximum(0.0, V - t))
            borne[actives] = np.minimum(borne[actives], b)
            meilleure = max(meilleure, float(val.max()))
            haut = float(borne[actives].max())
            if haut - meilleure <= tau or it >= it_max:
                return {"valeur": haut, "atteinte": meilleure, "iterations": it, "coupes": C,
                        "actives": len(actives), "coupe": int(cc[int(np.argmax(borne[actives]))])}
            garde = borne[actives] >= meilleure
            if not garde.all():
                actives = actives[garde]
                continue
            # ensemble actif : poids minuscules dont le gradient est sous le multiplicateur → exactement zéro
            if it and it % 20 == 0:
                Slo = (al * D_lo).sum(axis=1); Shi = (ah * D_hi).sum(axis=1)
                mu_lo = Slo / np.maximum(al.sum(axis=1), 1e-300); mu_hi = Shi / np.maximum(ah.sum(axis=1), 1e-300)
                al = np.where((al < zero) & (D_lo < 0.999 * mu_lo[:, None]), 0.0, al)
                ah = np.where((ah < zero) & (D_hi < 0.999 * mu_hi[:, None]), 0.0, ah)
                rr = np.where((rr < zero) & (E < 0.999 * t), 0.0, rr)
                # réactivation : coordonnée nulle dont le gradient dépasse nettement le multiplicateur
                al = np.where((al == 0) & (D_lo > 1.001 * mu_lo[:, None]), 1e-4, al)
                ah = np.where((ah == 0) & (D_hi > 1.001 * mu_hi[:, None]), 1e-4, ah)
                rr = np.where((rr == 0) & (E > 1.001 * t), 1e-4, rr)
                # renormalisation sur le polytope : Σa^P + Σr = 1 pour chaque morceau
                s_r = rr.sum(axis=1)
                al = al / np.maximum(al.sum(axis=1, keepdims=True), 1e-300) * (1 - s_r)[:, None]
                ah = ah / np.maximum(ah.sum(axis=1, keepdims=True), 1e-300) * (1 - s_r)[:, None]
                A_lo[actives], A_hi[actives], R[actives] = al, ah, rr
                m = lo * (Ls @ al.T) + hi * (Ls @ ah.T) + rr[:, ys].T
                inv = 1.0 / m
                D_lo, D_hi, E = (Ls.T @ (lo * inv)).T, (Ls.T @ (hi * inv)).T, (Y.T @ inv).T
        Clo, Chi, Rk = al * D_lo, ah * D_hi, rr * E
        Slo, Shi = Clo.sum(axis=1), Chi.sum(axis=1)
        S = Slo + Shi
        R[actives] = Rk / t
        nlo = np.where(Slo[:, None] > 0, Clo / np.maximum(Slo, 1e-300)[:, None], al / np.maximum(al.sum(axis=1, keepdims=True), 1e-300))
        nhi = np.where(Shi[:, None] > 0, Chi / np.maximum(Shi, 1e-300)[:, None], ah / np.maximum(ah.sum(axis=1, keepdims=True), 1e-300))
        A_lo[actives] = nlo * (S / t)[:, None]
        A_hi[actives] = nhi * (S / t)[:, None]
        it += 1


if __name__ == "__main__":
    for monde in ("S1", "seuil", "sp"):
        for graine in (3, 4, 5, 6, 7):
            inst, y, P = donnees(graine, 200, monde)
            Lm = P[:, np.arange(200), y].T
            total = 0.0
            lignes = []
            for t in (25, 50, 75, 100, 125, 150, 175, 200):
                for j in (0, 1):
                    z = np.array([x["z"][j] for x in inst[:t]])
                    d = time.time()
                    r = seuil_v3(Lm[:t], y[:t], z, 3)
                    total += time.time() - d
                    if t == 200:
                        lignes.append((j, r))
            print(monde, graine, f"{total*1000:.0f} ms", [(j, round(r['valeur'], 3), round(r['valeur'] - r['atteinte'], 4), r['iterations'], r['actives'], r['coupe']) for j, r in lignes])
