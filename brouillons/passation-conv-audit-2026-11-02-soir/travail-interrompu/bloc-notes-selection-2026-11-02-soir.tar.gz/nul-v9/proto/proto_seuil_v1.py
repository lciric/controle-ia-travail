"""Prototype : famille par morceaux à seuil (mélange de lois connues par morceau + bruit aveugle commun), EM par lots sur
toutes les coupes, certificat de Frank-Wolfe. Lecture seule du dépôt."""
import math
import random
import sys
import time

import numpy as np

sys.path.insert(0, "/home/claude/ideation-organism/orchestrator")
from pole import selection_pari as sp  # noqa: E402


def donnees(graine, t=200, monde="S1"):
    rng = random.Random(graine)
    S1, S2 = sp.loi_softmax_aleatoire(rng, 3, 2), sp.loi_softmax_aleatoire(rng, 3, 2)
    inst = sp.tirer_instances(rng, t, 2)
    if monde == "S1":
        loi = S1
    elif monde == "seuil":
        loi = {"type": "si_sinon", "condition": {"indice": 0, "seuil": 0.3}, "si": S1, "sinon": S2}
    else:
        loi = {"type": "par_sous_population", "lois": {"0": S1, "1": S2}}
    y = [sp.tirer_categorie(rng, sp.proba(loi, x, [], 0)) for x in inst]
    P = np.array([[sp.proba(L, x, [], 0) for x in inst] for L in (S1, S2)])  # (J, t, K)
    return inst, np.array(y), P


def em_lots(Ls, ys, K, iterations, A_lo=None, A_hi=None, R=None):
    t, J = Ls.shape
    C = t + 1
    lo = (np.arange(t)[:, None] < np.arange(C)[None, :]).astype(float)  # (t, C)
    hi = 1.0 - lo
    Y = np.zeros((t, K)); Y[np.arange(t), ys] = 1.0
    if A_lo is None:
        A_lo = np.full((C, J), 0.9 / J); A_hi = np.full((C, J), 0.9 / J); R = np.full((C, K), 0.1 / K)
    hist = []
    for it in range(iterations + 1):
        m = lo * (Ls @ A_lo.T) + hi * (Ls @ A_hi.T) + R[:, ys].T  # (t, C)
        inv = 1.0 / m
        D_lo = (Ls.T @ (lo * inv)).T  # (C, J)
        D_hi = (Ls.T @ (hi * inv)).T
        E = (Y.T @ inv).T  # (C, K)
        val = np.log(m).sum(axis=0)
        V = np.maximum(E.max(axis=1), D_lo.max(axis=1) + D_hi.max(axis=1))
        gap = V - t
        borne = np.minimum(0.0, val + gap)
        if it == iterations:
            break
        Clo, Chi, Rk = A_lo * D_lo, A_hi * D_hi, R * E
        Slo, Shi = Clo.sum(axis=1), Chi.sum(axis=1)
        S = Slo + Shi
        R = Rk / t
        with np.errstate(invalid="ignore", divide="ignore"):
            nlo = np.where(Slo[:, None] > 0, Clo / Slo[:, None], A_lo / np.maximum(A_lo.sum(axis=1, keepdims=True), 1e-300))
            nhi = np.where(Shi[:, None] > 0, Chi / Shi[:, None], A_hi / np.maximum(A_hi.sum(axis=1, keepdims=True), 1e-300))
        A_lo = nlo * (S / t)[:, None]
        A_hi = nhi * (S / t)[:, None]
        if it in (0, 5, 10, 20, 50, 100, 200, 400, 800):
            hist.append((it, float(val.max()), float(borne.max()), float(gap.max()), float(np.median(gap))))
    return val, gap, borne, hist


if __name__ == "__main__":
    for monde in ("S1", "seuil"):
        inst, y, P = donnees(3, 200, monde)
        z0 = np.array([x["z"][0] for x in inst])
        ordre = np.argsort(z0, kind="stable")
        Lm = P[:, np.arange(200), y].T  # (t, J)
        Ls, ys = Lm[ordre], y[ordre]
        for its in (50, 200, 800):
            d = time.time()
            val, gap, borne, hist = em_lots(Ls, ys, 3, its)
            dt = time.time() - d
            print(monde, its, f"{dt*1000:.1f} ms", "val max", round(float(val.max()), 4), "borne max", round(float(borne.max()), 4),
                  "écart max−max", round(float(borne.max() - val.max()), 4), "argmax", int(borne.argmax()), int(val.argmax()))
        for h in hist:
            print("   ", h)
        # référence : log-vraisemblance de la loi du monde, et du meilleur mélange global (coupe 0)
