"""Prototype : point intérieur par lots (Newton avec barrière, contraintes d'égalité couplées) pour la famille par morceaux
à bruit aveugle commun ; certificats de Frank-Wolfe ; élagage entre paliers ; comparaison à scipy (référence)."""
import sys
import time

import numpy as np

sys.path.insert(0, "/tmp/claude-0/-home-claude/03748db6-42ca-5241-871c-5399d39c1451/scratchpad/nul-v9/proto")
from proto_seuil_v1 import donnees  # noqa: E402
from proto_seuil_v2 import em_global  # noqa: E402


def evaluer(L, Y, M, x, J, K):
    P = M.shape[0]
    A = [x[:, p * J:(p + 1) * J] for p in range(P)]
    R = x[:, P * J:]
    m = sum(M[p] * (L @ A[p].T) for p in range(P)) + Y @ R.T  # (t, C)
    return m, A, R


def certificat(L, Y, M, x, J, K):
    m, A, R = evaluer(L, Y, M, x, J, K)
    t = L.shape[0]
    inv = 1.0 / m
    f = np.log(m).sum(axis=0)
    V = sum((L.T @ (M[p] * inv)).T.max(axis=1) for p in range(M.shape[0]))
    V = np.maximum(V, (Y.T @ inv).T.max(axis=1))
    return f, np.minimum(0.0, f + np.maximum(0.0, V - t))


def point_interieur(L, Y, M, x0, J, K, mus=(1.0, 1e-1, 1e-2, 1e-3, 1e-4, 1e-5, 1e-6, 1e-7), pas_max=25, elaguer=True):
    t = L.shape[0]
    P = M.shape[0]
    n = P * J + K
    C = x0.shape[1 - 1]
    x = x0.copy()
    B = np.zeros((P, n))
    for p in range(P):
        B[p, p * J:(p + 1) * J] = 1.0
        B[p, P * J:] = 1.0
    actives = np.arange(C)
    meilleure_borne = np.full(C, np.inf)
    meilleure_valeur = -np.inf
    pas_total = 0
    for mu in mus:
        for _ in range(pas_max):
            xa = x[actives]
            Ma = M[:, :, actives]
            m, A, R = evaluer(L, Y, Ma, xa, J, K)
            inv = 1.0 / m
            W2 = inv * inv
            Ca = len(actives)
            g = np.zeros((Ca, n))
            H = np.zeros((Ca, n, n))
            for p in range(P):
                sl = slice(p * J, (p + 1) * J)
                g[:, sl] = (L.T @ (Ma[p] * inv)).T
                H[:, sl, sl] = -np.einsum("ic,ij,il->cjl", Ma[p] * W2, L, L)
                H[:, sl, P * J:] = -np.einsum("ic,ij,ik->cjk", Ma[p] * W2, L, Y)
                H[:, P * J:, sl] = np.transpose(H[:, sl, P * J:], (0, 2, 1))
            g[:, P * J:] = (Y.T @ inv).T
            H[:, P * J:, P * J:] = -np.einsum("ic,ik->ck", W2, Y)[:, :, None] * np.eye(K)[None]
            g = g + mu / xa
            H = H - (mu / xa ** 2)[:, :, None] * np.eye(n)[None]
            KKT = np.zeros((Ca, n + P, n + P))
            KKT[:, :n, :n] = H
            KKT[:, :n, n:] = -B.T[None]
            KKT[:, n:, :n] = B[None]
            rhs = np.zeros((Ca, n + P))
            rhs[:, :n] = -g
            sol = np.linalg.solve(KKT, rhs[:, :, None])[:, :, 0]
            dx = sol[:, :n]
            dec = (g * dx).sum(axis=1)
            pas_total += 1
            if dec.max() < 1e-10:
                break
            neg = dx < 0
            amax = np.where(neg, -xa / np.where(neg, dx, -1.0), np.inf).min(axis=1)
            a = np.minimum(1.0, 0.99 * amax)
            F0 = np.log(m).sum(axis=0) + mu * np.log(xa).sum(axis=1)
            accepte = np.zeros(Ca, dtype=bool)
            pas = a.copy()
            for _ in range(30):
                xn = xa + pas[:, None] * dx
                mn, _, _ = evaluer(L, Y, Ma, xn, J, K)
                Fn = np.log(np.maximum(mn, 1e-300)).sum(axis=0) + mu * np.log(np.maximum(xn, 1e-300)).sum(axis=1)
                ok = (Fn >= F0 + 1e-4 * pas * dec) & (xn > 0).all(axis=1) & ~accepte
                xa = np.where(ok[:, None], xn, xa)
                accepte |= ok
                if accepte.all():
                    break
                pas = np.where(accepte, pas, pas * 0.5)
            x[actives] = xa
        if elaguer:
            f, b = certificat(L, Y, M[:, :, actives], x[actives], J, K)
            meilleure_borne[actives] = np.minimum(meilleure_borne[actives], b)
            meilleure_valeur = max(meilleure_valeur, float(f.max()))
            garde = meilleure_borne[actives] >= meilleure_valeur
            actives = actives[garde]
    f, b = certificat(L, Y, M[:, :, actives], x[actives], J, K)
    meilleure_borne[actives] = np.minimum(meilleure_borne[actives], b)
    meilleure_valeur = max(meilleure_valeur, float(f.max()))
    return {"valeur": float(meilleure_borne[actives].max()), "atteinte": meilleure_valeur, "pas": pas_total,
            "actives": len(actives), "coupe": int(actives[int(np.argmax(meilleure_borne[actives]))]), "x": x}


def seuil_pi(L, y, z, K):
    t, J = L.shape
    ordre = np.argsort(z, kind="stable")
    Ls, ys, zs = L[ordre], y[ordre], z[ordre]
    coupes = np.array([0] + [c for c in range(1, t) if zs[c - 1] < zs[c]] + [t])
    Y = np.eye(K)[ys]
    lo = (np.arange(t)[:, None] < coupes[None, :]).astype(float)
    M = np.stack([lo, 1.0 - lo])
    a0, r0 = em_global(L, y, K, iterations=300)
    s0 = 0.5
    centre = np.concatenate([np.full(J, (1 - s0) / J), np.full(J, (1 - s0) / J), np.full(K, s0 / K)])
    glob = np.concatenate([a0, a0, r0])
    x0 = np.tile(0.9 * glob + 0.1 * centre, (len(coupes), 1))
    r = point_interieur(Ls, Y, M, x0, J, K)
    r["coupe"] = int(coupes[r["coupe"]])
    return r


if __name__ == "__main__":
    for monde in ("S1", "seuil", "sp"):
        for graine in (3, 4, 5, 6, 7):
            inst, y, P = donnees(graine, 200, monde)
            Lm = P[:, np.arange(200), y].T
            total = 0.0
            lignes = []
            for t in (25, 50, 75, 100, 125, 150, 175, 200):
                for j in (0, 1):
                    z = np.array([x["z"][j] for x in inst[:t]])
                    d = time.time()
                    r = seuil_pi(Lm[:t], y[:t], z, 3)
                    total += time.time() - d
                    if t == 200:
                        lignes.append((j, r))
            print(monde, graine, f"{total*1000:.0f} ms", [(j, round(r['valeur'], 4), round(r['valeur'] - r['atteinte'], 5), r['pas'], r['actives'], r['coupe']) for j, r in lignes])
