"""Prototype v2 du point intérieur : hessiennes par produits matriciels, paliers de μ espacés, élagage après chaque palier,
mesure du nombre de coupes restantes."""
import sys, time
import numpy as np
sys.path.insert(0, ".")
from proto_seuil_v1 import donnees
from proto_seuil_v2 import em_global
from proto_pi_v1 import evaluer, certificat


def point_interieur(L, Y, M, x0, J, K, mus=(1e-1, 1e-2, 1e-4, 1e-6, 1e-8), pas_max=30, journal=None):
    t = L.shape[0]; P = M.shape[0]; n = P * J + K
    C = x0.shape[0]
    x = x0.copy()
    B = np.zeros((P, n))
    for p in range(P):
        B[p, p * J:(p + 1) * J] = 1.0; B[p, P * J:] = 1.0
    LL = (L[:, :, None] * L[:, None, :]).reshape(t, J * J)
    LY = (L[:, :, None] * Y[:, None, :]).reshape(t, J * K)
    actives = np.arange(C)
    borne = np.full(C, np.inf)
    meilleure = -np.inf
    pas_total = 0
    for mu in mus:
        for _ in range(pas_max):
            xa = x[actives]; Ma = M[:, :, actives]; Ca = len(actives)
            m, A, R = evaluer(L, Y, Ma, xa, J, K)
            inv = 1.0 / m; W2 = inv * inv
            g = np.empty((Ca, n)); H = np.zeros((Ca, n, n))
            for p in range(P):
                sl = slice(p * J, (p + 1) * J)
                g[:, sl] = (L.T @ (Ma[p] * inv)).T
                Wp = (Ma[p] * W2).T  # (Ca, t)
                H[:, sl, sl] = -(Wp @ LL).reshape(Ca, J, J)
                hr = -(Wp @ LY).reshape(Ca, J, K)
                H[:, sl, P * J:] = hr
                H[:, P * J:, sl] = np.transpose(hr, (0, 2, 1))
            g[:, P * J:] = (Y.T @ inv).T
            idx = np.arange(K)
            H[:, P * J + idx, P * J + idx] = -(W2.T @ Y)
            g += mu / xa
            H[:, np.arange(n), np.arange(n)] -= mu / xa ** 2
            KKT = np.zeros((Ca, n + P, n + P))
            KKT[:, :n, :n] = H; KKT[:, :n, n:] = -B.T[None]; KKT[:, n:, :n] = B[None]
            rhs = np.zeros((Ca, n + P)); rhs[:, :n] = -g
            dx = np.linalg.solve(KKT, rhs[:, :, None])[:, :n, 0]
            dec = (g * dx).sum(axis=1)
            pas_total += 1
            if dec.max() < 1e-9:
                break
            neg = dx < 0
            amax = np.where(neg, -xa / np.where(neg, dx, -1.0), np.inf).min(axis=1)
            pas = np.minimum(1.0, 0.99 * amax)
            F0 = np.log(m).sum(axis=0) + mu * np.log(xa).sum(axis=1)
            fait = np.zeros(Ca, dtype=bool)
            for _ in range(40):
                xn = xa + pas[:, None] * dx
                mn, _, _ = evaluer(L, Y, Ma, xn, J, K)
                with np.errstate(divide="ignore", invalid="ignore"):
                    Fn = np.log(mn).sum(axis=0) + mu * np.log(xn).sum(axis=1)
                ok = ~fait & (xn > 0).all(axis=1) & (mn > 0).all(axis=0) & (Fn >= F0 + 1e-4 * pas * dec)
                xa = np.where(ok[:, None], xn, xa); fait |= ok
                if fait.all():
                    break
                pas = np.where(fait, pas, 0.5 * pas)
            x[actives] = xa
        f, b = certificat(L, Y, M[:, :, actives], x[actives], J, K)
        borne[actives] = np.minimum(borne[actives], b)
        meilleure = max(meilleure, float(f.max()))
        actives = actives[borne[actives] >= meilleure]
        if journal is not None:
            journal.append((mu, len(actives), pas_total))
    return float(borne[actives].max()), meilleure, pas_total, actives


def seuil_pi(L, y, z, K, journal=None):
    t, J = L.shape
    ordre = np.argsort(z, kind="stable")
    Ls, ys, zs = L[ordre], y[ordre], z[ordre]
    coupes = np.array([0] + [c for c in range(1, t) if zs[c - 1] < zs[c]] + [t])
    Y = np.eye(K)[ys]
    lo = (np.arange(t)[:, None] < coupes[None, :]).astype(float)
    M = np.stack([lo, 1.0 - lo])
    a0, r0 = em_global(L, y, K, iterations=300)
    s0 = 0.5
    centre = np.concatenate([np.full(2 * J, (1 - s0) / J), np.full(K, s0 / K)])
    glob = np.concatenate([a0, a0, r0])
    x0 = np.tile(0.9 * glob + 0.1 * centre, (len(coupes), 1))
    v, at, pas, act = point_interieur(Ls, Y, M, x0, J, K, journal=journal)
    return v, at, pas, coupes[act]


if __name__ == "__main__":
    for monde in ("S1", "seuil", "sp"):
        for graine in (3, 4, 5):
            inst, y, P = donnees(graine, 200, monde)
            Lm = P[:, np.arange(200), y].T
            total = 0.0; lignes = []
            for t in (25, 50, 75, 100, 125, 150, 175, 200):
                for j in (0, 1):
                    z = np.array([x["z"][j] for x in inst[:t]])
                    jl = []
                    d = time.time()
                    v, at, pas, act = seuil_pi(Lm[:t], y[:t], z, 3, jl)
                    total += time.time() - d
                    if t == 200:
                        lignes.append((j, round(v, 4), round(v - at, 6), pas, [c for c in act][:3], jl))
            print(monde, graine, f"{total*1000:.0f} ms")
            for l in lignes:
                print("    ", l)
