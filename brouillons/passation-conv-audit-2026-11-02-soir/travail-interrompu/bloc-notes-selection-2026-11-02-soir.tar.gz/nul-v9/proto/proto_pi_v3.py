"""Prototype v3 : élagage à chaque pas de Newton (certificats gratuits), mesure du temps par évaluation."""
import sys, time
import numpy as np
sys.path.insert(0, ".")
from proto_seuil_v1 import donnees
from proto_seuil_v2 import em_global


def point_interieur(L, Y, M, x0, J, K, mus=(1e-1, 1e-2, 1e-4, 1e-6, 1e-8), pas_max=30):
    t = L.shape[0]; P = M.shape[0]; n = P * J + K
    C = x0.shape[0]
    x = x0.copy()
    B = np.zeros((P, n))
    for p in range(P):
        B[p, p * J:(p + 1) * J] = 1.0; B[p, P * J:] = 1.0
    LL = (L[:, :, None] * L[:, None, :]).reshape(t, J * J)
    LY = (L[:, :, None] * Y[:, None, :]).reshape(t, J * K)
    actives = np.arange(C)
    borne = np.full(C, np.inf)
    meilleure = -np.inf
    pas_total = 0
    idx = np.arange(K); dg = np.arange(n)
    for mu in mus:
        for _ in range(pas_max):
            xa = x[actives]; Ma = M[:, :, actives]; Ca = len(actives)
            m = sum(Ma[p] * (L @ xa[:, p * J:(p + 1) * J].T) for p in range(P)) + Y @ xa[:, P * J:].T
            inv = 1.0 / m; W2 = inv * inv
            f = np.log(m).sum(axis=0)
            g = np.empty((Ca, n)); H = np.zeros((Ca, n, n))
            V = np.zeros(Ca)
            for p in range(P):
                sl = slice(p * J, (p + 1) * J)
                g[:, sl] = (L.T @ (Ma[p] * inv)).T
                V += g[:, sl].max(axis=1)
                Wp = (Ma[p] * W2).T
                H[:, sl, sl] = -(Wp @ LL).reshape(Ca, J, J)
                hr = -(Wp @ LY).reshape(Ca, J, K)
                H[:, sl, P * J:] = hr; H[:, P * J:, sl] = np.transpose(hr, (0, 2, 1))
            g[:, P * J:] = (Y.T @ inv).T
            V = np.maximum(V, g[:, P * J:].max(axis=1))
            cert = np.minimum(0.0, f + np.maximum(0.0, V - t))
            borne[actives] = np.minimum(borne[actives], cert)
            meilleure = max(meilleure, float(f.max()))
            garde = borne[actives] >= meilleure
            if not garde.all():
                actives = actives[garde]
                xa, Ma, Ca = xa[garde], Ma[:, :, garde], int(garde.sum())
                m, f, g, H = m[:, garde], f[garde], g[garde], H[garde]
            H[:, P * J + idx, P * J + idx] = -(W2[:, garde] if not garde.all() else W2).T @ Y if False else H[:, P * J + idx, P * J + idx]
            Wr = (W2[:, garde]).T @ Y
            H[:, P * J + idx, P * J + idx] = -Wr
            g = g + mu / xa
            H[:, dg, dg] -= mu / xa ** 2
            KKT = np.zeros((Ca, n + P, n + P))
            KKT[:, :n, :n] = H; KKT[:, :n, n:] = -B.T[None]; KKT[:, n:, :n] = B[None]
            rhs = np.zeros((Ca, n + P)); rhs[:, :n] = -g
            dx = np.linalg.solve(KKT, rhs[:, :, None])[:, :n, 0]
            dec = (g * dx).sum(axis=1)
            pas_total += 1
            if dec.max() < 1e-9:
                break
            neg = dx < 0
            amax = np.where(neg, -xa / np.where(neg, dx, -1.0), np.inf).min(axis=1)
            pas = np.minimum(1.0, 0.99 * amax)
            F0 = f + mu * np.log(xa).sum(axis=1)
            fait = np.zeros(Ca, dtype=bool)
            for _ in range(40):
                xn = xa + pas[:, None] * dx
                mn = sum(Ma[p] * (L @ xn[:, p * J:(p + 1) * J].T) for p in range(P)) + Y @ xn[:, P * J:].T
                with np.errstate(divide="ignore", invalid="ignore"):
                    Fn = np.log(mn).sum(axis=0) + mu * np.log(xn).sum(axis=1)
                ok = ~fait & (xn > 0).all(axis=1) & (mn > 0).all(axis=0) & (Fn >= F0 + 1e-4 * pas * dec)
                xa = np.where(ok[:, None], xn, xa); fait |= ok
                if fait.all():
                    break
                pas = np.where(fait, pas, 0.5 * pas)
            x[actives] = xa
    # certificat final
    xa = x[actives]; Ma = M[:, :, actives]
    m = sum(Ma[p] * (L @ xa[:, p * J:(p + 1) * J].T) for p in range(P)) + Y @ xa[:, P * J:].T
    inv = 1.0 / m
    f = np.log(m).sum(axis=0)
    V = sum((L.T @ (Ma[p] * inv)).T.max(axis=1) for p in range(P))
    V = np.maximum(V, (Y.T @ inv).T.max(axis=1))
    borne[actives] = np.minimum(borne[actives], np.minimum(0.0, f + np.maximum(0.0, V - t)))
    meilleure = max(meilleure, float(f.max()))
    return float(borne[actives].max()), meilleure, pas_total, actives


def seuil_pi(L, y, z, K):
    t, J = L.shape
    ordre = np.argsort(z, kind="stable")
    Ls, ys, zs = L[ordre], y[ordre], z[ordre]
    coupes = np.array([0] + [c for c in range(1, t) if zs[c - 1] < zs[c]] + [t])
    Y = np.eye(K)[ys]
    lo = (np.arange(t)[:, None] < coupes[None, :]).astype(float)
    M = np.stack([lo, 1.0 - lo])
    a0, r0 = em_global(L, y, K, iterations=300)
    s0 = 0.5
    centre = np.concatenate([np.full(2 * J, (1 - s0) / J), np.full(K, s0 / K)])
    glob = np.concatenate([a0, a0, r0])
    x0 = np.tile(0.9 * glob + 0.1 * centre, (len(coupes), 1))
    v, at, pas, act = point_interieur(Ls, Y, M, x0, J, K)
    return v, at, pas, coupes[act]


if __name__ == "__main__":
    for monde in ("S1", "seuil", "sp"):
        for graine in (3, 4, 5):
            inst, y, P = donnees(graine, 200, monde)
            Lm = P[:, np.arange(200), y].T
            total = 0.0; lignes = []
            for t in (25, 50, 75, 100, 125, 150, 175, 200):
                for j in (0, 1):
                    z = np.array([x["z"][j] for x in inst[:t]])
                    d = time.time()
                    v, at, pas, act = seuil_pi(Lm[:t], y[:t], z, 3)
                    total += time.time() - d
                    if t == 200:
                        lignes.append((j, round(v, 4), round(v - at, 6), pas, list(map(int, act))[:3]))
            print(monde, graine, f"{total*1000:.0f} ms", lignes)
