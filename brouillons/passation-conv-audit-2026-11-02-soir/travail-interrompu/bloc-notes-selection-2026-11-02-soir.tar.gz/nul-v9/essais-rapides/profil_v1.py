import cProfile, pstats, random, sys, io
sys.argv = ["x"]
exec(open("essai_w2_v1.py").read().split("for g in range(6):")[0])
rng = random.Random(105); L = v7._monde_lois(rng)
pr = cProfile.Profile(); pr.enable()
for g in range(3):
    ev, dt, gele, tir = juger(L["N"], L["N"], L, "v9", 5007 + g)
pr.disable()
s = io.StringIO(); pstats.Stats(pr, stream=s).sort_stats("cumulative").print_stats(18); print(s.getvalue()[:4000])
