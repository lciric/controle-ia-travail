import random, sys, time
sys.argv = ["x"]
exec(open("essai_w2_v1.py").read().split("for g in range(6):")[0])
import numpy as np
from pole import nul_v9
cas = []
for g in range(6):
    rng = random.Random(100 + g); L = v7._monde_lois(rng)
    w2 = {"type": "par_sous_population", "lois": {"0": L["S1"], "1": L["S2"]}}
    cas += [(L["N"], L, 1000 * g + 7), (w2, L, 1000 * g + 7), (L["S1"], L, 1000 * g + 7)]
def lot(paliers, tol):
    nul_v9.PALIERS_MU, nul_v9.TOLERANCE_GROUPE = paliers, tol
    vals, temps = [], []
    for loi, L, gr in cas:
        ev, dt, gele, tir = juger(loi, loi, L, "v9", gr)
        vals.append(ev["trajectoire_log_w"]); temps.append(dt)
    return np.array(vals), np.array(temps)
ref, tref = lot((1e-1, 1e-2, 1e-4, 1e-6, 1e-8), 1e-6)
print("réf", round(tref.sum(), 1), "max", round(tref.max(), 2))
for p, tol in [((1e-2, 1e-4, 1e-6, 1e-8), 1e-3), ((1e-2, 1e-3, 1e-4, 1e-6, 1e-8), 1e-3), ((1e-1, 1e-2, 1e-4, 1e-6, 1e-8), 1e-3), ((1e-2, 1e-4, 1e-7), 1e-3)]:
    v, t = lot(p, tol)
    print(p, tol, "temps", round(t.sum(), 1), "max", round(t.max(), 2), "|Δ| max", float(np.abs(v - ref).max()), "v−réf max", float((v - ref).max()))
