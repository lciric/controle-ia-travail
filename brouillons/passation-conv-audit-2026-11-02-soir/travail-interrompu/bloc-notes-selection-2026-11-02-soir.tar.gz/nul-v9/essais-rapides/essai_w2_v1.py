import importlib.util, os, random, sys, time
RACINE = "/home/claude/ideation-organism/orchestrator"
sys.path.insert(0, RACINE)
import numpy as np
from pole import nul_v9, nul_v8, selection_pari as sp, nul_filles_v2 as nf
from pole.cycle import instants_reguliers
spec = importlib.util.spec_from_file_location("b8", os.path.join(RACINE, "demonstrations", "banc_tricheurs_v8.py"))
b8 = importlib.util.module_from_spec(spec); spec.loader.exec_module(b8)
v7 = b8.v7
K, DIM = 3, 2
def juger(loi, monde, L, nul, graine):
    rng = random.Random(graine)
    q_ent = v7._marginale_entrainement(rng, monde)
    standard = list(sp.BIBLIOTHEQUE_STANDARD) + [{"nom": "marginale_entrainement", "type": "fixe", "probas": q_ent}]
    surv = {"S1": L["S1"], "S2": L["S2"]}
    instances = sp.tirer_instances(rng, 200, DIM)
    if nul == "v9":
        biblio = standard + nul_v9.membres_archive_v9(surv, None, K, DIM)
    else:
        biblio = standard + nul_v8.membres_archive_v8(surv, None, K, DIM)
    gele = sp.geler_engagement(nf.construire_engagement_v2("fiche", loi, instances, K, 0.05, biblio, 0, None, instants_reguliers(200, 8)))
    tir = sp.tirer_frais(gele, monde, graine + 1, graine_noyau=graine + 2)
    d = time.time()
    ev = (nul_v9.evaluer_v9 if nul == "v9" else nf.evaluer_v2)(gele, tir, graine_noyau=graine + 2)
    return ev, time.time() - d, gele, tir
for g in range(6):
    rng = random.Random(100 + g)
    L = v7._monde_lois(rng)
    w2 = {"type": "par_sous_population", "lois": {"0": L["S1"], "1": L["S2"]}}
    seuil = {"type": "si_sinon", "condition": {"indice": g % 2, "seuil": round(rng.uniform(-1, 1), 3)}, "si": L["S1"], "sinon": L["S2"]}
    for nom, loi in (("W2", w2), ("seuil", seuil), ("neuve", L["N"])):
        r = {}
        for nul in ("v8", "v9"):
            ev, dt, gele, tir = juger(loi, loi, L, nul, 1000 * g + 7)
            r[nul] = (round(ev["log_richesse_max"], 3), ev["promue"], ev["membre_dominant_final"], round(dt, 3))
        print(g, nom, r)
