import random, sys, time
sys.argv = ["x"]
exec(open("essai_w2_v1.py").read().split("for g in range(6):")[0])
import numpy as np
from pole import nul_v9
orig = nul_v9.maximiser_par_lots
stats = []
def espion(L, Y, M, x0):
    d = time.time(); r = orig(L, Y, M, x0); stats.append((L.shape[0], M.shape[2], r[2]["pas"], r[2]["coupes_restantes"], time.time() - d)); return r
nul_v9.maximiser_par_lots = espion
for g in range(4):
    rng = random.Random(300 + g); L = v7._monde_lois(rng)
    for loi in (L["N"], L["S1"]):
        juger(loi, loi, L, "v9", 9000 + g)
s = np.array(stats)
print("appels", len(s), "temps total", s[:, 4].sum())
for t in (25, 100, 200):
    sel = s[s[:, 0] == t]
    print("t", t, "coupes moy", sel[:, 1].mean(), "pas moy", sel[:, 2].mean(), "temps moy ms", 1000 * sel[:, 4].mean())
sel = s[s[:, 1] == 1]
print("sous-population : temps moy ms", 1000 * sel[:, 4].mean(), "pas", sel[:, 2].mean())
