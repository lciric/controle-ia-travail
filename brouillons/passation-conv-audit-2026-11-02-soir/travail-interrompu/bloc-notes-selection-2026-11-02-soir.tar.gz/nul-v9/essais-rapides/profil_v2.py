import random, sys, time
sys.argv = ["x"]
exec(open("essai_w2_v1.py").read().split("for g in range(6):")[0])
import numpy as np
from pole import nul_v9
orig = nul_v9.maximiser_par_lots
def espion(L, Y, M, groupes, x0, **kw):
    d = time.time(); r = orig(L, Y, M, groupes, x0, **kw)
    print("  lot P", M.shape[0], "coupes", M.shape[2], "pas", r[2]["pas"], "restantes", r[2]["coupes_restantes"], f"{time.time()-d:.2f} s",
          "écart résiduel max", float((r[0] - r[1]).max()))
    return r
nul_v9.maximiser_par_lots = espion
for g in (4, 5):
    rng = random.Random(100 + g); L = v7._monde_lois(rng)
    for k in range(3):
        rng.random()
    ev, dt, gele, tir = juger(L["N"], L["N"], L, "v9", 1000 * g + 7)
    print(g, round(dt, 2), ev["log_richesse_max"])
