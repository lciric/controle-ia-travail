import random, sys, time
sys.argv = ["x"]
exec(open("essai_w2_v1.py").read().split("for g in range(6):")[0])
import numpy as np
from pole import nul_v9
def lot(paliers):
    nul_v9.PALIERS_MU = paliers
    vals, d = [], time.time()
    for g in range(8):
        rng = random.Random(300 + g); L = v7._monde_lois(rng)
        for loi in (L["N"], {"type": "par_sous_population", "lois": {"0": L["S1"], "1": L["S2"]}}, L["S1"]):
            ev, dt, gele, tir = juger(loi, loi, L, "v9", 9000 + g)
            vals.append(ev["trajectoire_log_w"])
    return np.array(vals), time.time() - d
ref, tref = lot((1e-1, 1e-2, 1e-4, 1e-6, 1e-8))
for p in [(1e-1, 1e-3, 1e-6, 1e-9), (1e-2, 1e-4, 1e-7), (1e-1, 1e-3, 1e-6)]:
    v, t = lot(p)
    print(p, f"{t:.1f} s contre {tref:.1f} s", "écart max |Δ log W|", float(np.abs(v - ref).max()), "v − ref max (positif = moins prudent)", float((v - ref).max()))
