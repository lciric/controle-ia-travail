"""Tables de la lecture gelée du brouillon 1 (lecture seule des fonctions du banc v8)."""
import importlib.util, math, os, sys
R = "/home/claude/ideation-organism/orchestrator"
sys.path.insert(0, R)
s = importlib.util.spec_from_file_location("b8", os.path.join(R, "demonstrations", "banc_tricheurs_v8.py"))
b8 = importlib.util.module_from_spec(s); s.loader.exec_module(b8)
n = 1000
print("Holm, 18 lignes fatales, promotions max « tenue » par rang :", b8.promotions_max_tenue(n, 18))
mins = []
for j in range(1, 19):
    a, x = 0.05 / (18 - j + 1), n
    while x > 0 and b8.binom_sf(x - 1, n, 0.05) <= a:
        x -= 1
    mins.append(x)
print("Holm, 18 lignes fatales, promotions min « non tenue » par rang :", mins)
print("artefact : promotions min pour « tenue » (borne basse CP 95 % > α) :", b8.promotions_min_artefact(n))
print("perte appariée, marge 0,05, Holm sur 5 lignes, pertes max « tenue » par rang :", b8.promotions_max_tenue(n, 5, seuil=0.05))
for marge in (0.05, 0.10):
    seuils = b8.promotions_max_tenue(n, 5, seuil=marge)
    print(f"marge {marge} : seuils {seuils}")
    for d in (0.0, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.08, 0.10, 0.15):
        p_rang1 = b8.binom_cdf(seuils[0], n, d) if d > 0 else 1.0
        p_rang5 = b8.binom_cdf(seuils[-1], n, d) if d > 0 else 1.0
        mn = n
        a = 0.05 / 5
        while mn > 0 and b8.binom_sf(mn - 1, n, marge) <= a:
            mn -= 1
        p_non = b8.binom_sf(mn, n, d) if d > 0 else 0.0
        print(f"   vraie perte {d:.2f} : P(tenue) entre {p_rang1:.3f} (rang 1) et {p_rang5:.3f} (rang 5) ; P(non tenue, rang 1, ≥ {mn}) {p_non:.3f}")
# T12a : vrai taux 0,01, 0,03, 0,05 → P(tenue au rang 1)
for p in (0.005, 0.01, 0.02, 0.03, 0.04, 0.05):
    print(f"ligne fatale de vrai taux {p} : P(≤ 32/1000) = {b8.binom_cdf(32, n, p):.4f} ; P(≤ 38) = {b8.binom_cdf(38, n, p):.4f}")
