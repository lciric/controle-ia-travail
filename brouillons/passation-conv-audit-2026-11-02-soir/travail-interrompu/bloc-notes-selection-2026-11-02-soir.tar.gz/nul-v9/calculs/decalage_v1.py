"""Lecture préalable L4 : décalage du dénominateur v9 − v8 sur les mêmes issues (Δ = log W v8 − log W v9, ≥ 0), et durée
par évaluation, sur des lignes du banc v9 (graine exploratoire 777, distincte de la graine décisive)."""
import importlib.util, json, os, random, sys, time
R = "/home/claude/ideation-organism/orchestrator"
sys.path.insert(0, R)
import numpy as np
s = importlib.util.spec_from_file_location("b9", os.path.join(R, "demonstrations", "banc_tricheurs_v9.py"))
b9 = importlib.util.module_from_spec(s); s.loader.exec_module(b9)
sortie = {}
for nom in ("T17s", "T04", "fraiche_neuve", "I01", "I02", "F03", "fille_neuve"):
    deltas_fin, deltas_max, durees = [], [], []
    for r in range(40):
        g_s, g_n, g_f = b9.graines(777, f"{nom}|v9", r)
        rng = random.Random(g_s)
        genre, loi, monde, L = b9.scenario_v9(nom, rng)
        d = time.time()
        ev9, ev8 = b9.juger_v9(genre, loi, monde, L, rng, g_n, g_f)
        durees.append(time.time() - d)
        a, b = np.array(ev8["trajectoire_log_w"]), np.array(ev9["trajectoire_log_w"])
        deltas_fin.append(float(a[-1] - b[-1])); deltas_max.append(float(ev8["log_richesse_max"] - ev9["log_richesse_max"]))
    q = lambda v, p: round(float(np.quantile(v, p)), 3)
    sortie[nom] = {"delta_final_quartiles": [q(deltas_fin, 0.25), q(deltas_fin, 0.5), q(deltas_fin, 0.75), q(deltas_fin, 0.95)],
                   "delta_max_quartiles": [q(deltas_max, 0.25), q(deltas_max, 0.5), q(deltas_max, 0.75), q(deltas_max, 0.95)],
                   "duree_moyenne_s": round(float(np.mean(durees)), 3), "duree_max_s": round(float(np.max(durees)), 3)}
    print(nom, sortie[nom], flush=True)
json.dump(sortie, open("decalage_v1.json", "w"), ensure_ascii=False, indent=1)
