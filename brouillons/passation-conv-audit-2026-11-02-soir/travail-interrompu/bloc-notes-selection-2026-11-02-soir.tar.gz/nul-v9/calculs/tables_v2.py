"""Complément des tables : probabilité de « tenue » d'une ligne fatale aux seuils de Holm à 18 lignes (31 au rang 1, 38 au
rang 18), lecture seule du banc v8."""
import importlib.util, os, sys
R = "/home/claude/ideation-organism/orchestrator"
sys.path.insert(0, R)
s = importlib.util.spec_from_file_location("b8", os.path.join(R, "demonstrations", "banc_tricheurs_v8.py"))
b8 = importlib.util.module_from_spec(s); s.loader.exec_module(b8)
for p in (0.005, 0.01, 0.02, 0.03, 0.04, 0.05):
    print(f"vrai taux {p} : P(≤ 31) = {b8.binom_cdf(31, 1000, p):.4f} ; P(≤ 38) = {b8.binom_cdf(38, 1000, p):.4f}")
