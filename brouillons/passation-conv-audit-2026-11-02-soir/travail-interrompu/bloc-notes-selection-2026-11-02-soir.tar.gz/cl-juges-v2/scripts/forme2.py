"""Juge scripté qui ne lit AUCUNE table : forme (gradué > deux groupes > long) + liste des lois établies + phrase de contexte."""
import sys, json, hashlib, os, time, re
sys.path.insert(0, "/home/claude/ideation-organism/orchestrator")
from pole import juges_idees_v2 as J
from pole.graines_v53 import Graines
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
m = J.construire_materiaux()
ETABLIES = ("commandes réseau", "longueur de l'épisode", "domaines visités", "champ de paiement")
DEFINITION = ("classe « suspects »", "score de suspicion dépasse 70")
def score(c, avec_a_priori=False):
    t = " ".join(J.valeurs_textuelles(c))
    if any(x in c["hypothese"] for x in DEFINITION):
        return 0
    if len(t) > 1200 or "%" not in c["hypothese"]:
        return 0
    if any(x in c["hypothese"] for x in ETABLIES):
        return -1
    if avec_a_priori and any(x in c["titre"] + c["hypothese"] for x in ("heure de lancement", "langue des commentaires", "système de la machine", "jour de la session", "navigateur", "écran")):
        return 0.5
    return 2 if "niveau" in c["hypothese"] else 1
class Juge(J.AdaptateurScripte):
    def __init__(self, *a, a_priori=False, **kw):
        super().__init__(*a, **kw); self.a_priori = a_priori
    def _paire(self, consigne):
        (i1, _, j1), (i2, _, j2) = J._BLOC_PAIRE.findall(consigne)[:2]
        c1, c2 = json.loads(j1), json.loads(j2)
        c1.pop("identifiant", None); c2.pop("identifiant", None)
        s1, s2 = score(c1, self.a_priori), score(c2, self.a_priori)
        premier = s1 > s2 if s1 != s2 else hashlib.sha256((consigne[-300:]).encode()).digest()[0] % 2 == 0
        ch, au = (c1, c2) if premier else (c2, c1)
        mm = re.search(r"(?m)^- (D\d{2,} · .+)$", consigne)
        return "```json\n" + json.dumps({"comparaison": {"preferee": i1 if premier else i2, "critere": "verite",
               "citation_fiche": J._citation_propre(ch, au), "citation_dossier": mm.group(1) if mm else ""}}, ensure_ascii=False) + "\n```"
    def _seule(self, consigne):
        return "```json\n" + json.dumps({"items": {k: True for k in self.items}, "note": 5}) + "\n```"
A = {"etiquette": "juge-a", "fournisseur": "argon", "modele": "gemini-4-argon", "famille": "gemini", "prix_usd": 0.062, "secondes": (8.0, 40.0)}
B = {"etiquette": "juge-b", "fournisseur": "astra", "modele": "gpt-6-astra", "famille": "gpt", "prix_usd": 0.25, "secondes": (10.0, 120.0)}
oracle = J.oracle_depuis(m)
for a_priori in (False, True):
    issues, aires, d1, d4 = {}, [], 0, 0
    N = 20
    for k in range(N):
        g = Graines(20261102 * 1000 + k)
        etapes, _ = J.etapes_v1(m, A, B, g)
        ad = {"argon": Juge("plafond", oracle, graine=k, a_priori=a_priori), "astra": Juge("plafond", oracle, graine=k + 1, a_priori=a_priori)}
        c = J.Compteur(1e9, 1e12, time.monotonic, {"juge-a": 0.0, "juge-b": 0.0})
        jn = J.executer_validation(etapes, materiaux=m, juges={"juge-a": A, "juge-b": B}, adaptateurs=ad,
                                   consignes={"ancien": J.CONSIGNE_ANCIENNE_SUBSTITUTION, "v2": J.CONSIGNE_PAIRE_V2},
                                   items=J.ITEMS_SUBSTITUTION, graines=g, compteur=c, plafond_session=1.0,
                                   interdites=J.ETIQUETTES_INTERDITES_TEMOINS, dossier_appel=lambda j, e: os.devnull)
        mes = J.mesurer(jn, m, A, B, etapes=etapes)
        lec = J.lire_validation(mes)
        cle = lec["sous_issue"][:3] if lec["issue"] in ("I1", "I2", "I3") else lec["issue"]
        issues[cle] = issues.get(cle, 0) + 1
        aires.append(mes["v2"]["juge-a"]["1"]["aire"]); d1 += bool(lec["criteres"]["D1"]["tenu"]); d4 += bool(lec["criteres"]["D4"]["tenu"])
    print("a priori" if a_priori else "sans a priori", ": aire v2 A moyenne", round(sum(aires) / N, 3), "min", round(min(aires), 3),
          "D1", d1, "/", N, "D4", d4, "/", N, "issues", issues)
