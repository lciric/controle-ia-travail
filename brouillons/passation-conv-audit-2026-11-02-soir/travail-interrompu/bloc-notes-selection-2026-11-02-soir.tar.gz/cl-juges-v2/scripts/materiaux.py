import sys, json
sys.path.insert(0, "/home/claude/ideation-organism/orchestrator")
from pole import juges_idees_v2 as J
m = J.construire_materiaux()
print("empreinte", m["empreinte"])
print("forme", J.controle_forme(m))
print("verif", J.verifier_materiaux(m))
for lot in m["lots"]:
    print("=" * 100)
    print(lot["nom"], "tentative", lot["tentative"])
    print(lot["dossier"])
    for f in lot["fiches"]:
        print("-" * 80)
        print(f["ident"], f["classe"], f["role"], json.dumps(f["loi"], ensure_ascii=False))
        for k, v in f["contenu"].items():
            print(f"  {k}: {v}")
