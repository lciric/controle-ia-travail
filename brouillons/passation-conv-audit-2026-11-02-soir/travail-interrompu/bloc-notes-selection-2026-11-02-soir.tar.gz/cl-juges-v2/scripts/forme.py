"""Contre-lecture : indices de forme hors du contrôle (gabarit, caractéristique binaire) et juge scripté « de forme » qui ne lit
ni les tables ni les lois établies. Aucun appel, aucun réseau."""
import sys, json, hashlib, os, time, re
sys.path.insert(0, "/home/claude/ideation-organism/orchestrator")
from pole import juges_idees_v2 as J
from pole.graines_v53 import Graines
from pole.outils import empreinte_objet
m = J.construire_materiaux()
specs = {s["nom"]: s for s in J.MONDES_V1}
bons, mauvais = [], []
lignes = []
for lot in m["lots"]:
    for f in lot["fiches"]:
        if f["role"] != "evaluation":
            continue
        t = f["loi"]["type"]
        gradue = t in ("monotone", "interaction")
        car = f["loi"].get("caracteristique")
        binaire = car is not None and J._caracteristique(specs[lot["nom"]], car)["type"] == "binaire"
        lignes.append((f["ident"], f["classe"], t, gradue, binaire))
        (bons if f["qualite"] == 1 else mauvais).append({"gradue": int(gradue), "binaire": int(binaire), "pas_binaire": int(not binaire)})
for l in lignes:
    print(l)
print("aire indice « gabarit gradué (monotone ou interaction) » :", J.aire([b["gradue"] for b in bons], [x["gradue"] for x in mauvais]))
print("aire indice « caractéristique non binaire » :", J.aire([b["pas_binaire"] for b in bons], [x["pas_binaire"] for x in mauvais]))

def score_forme(c):
    texte = " ".join(J.valeurs_textuelles(c))
    if len(texte) > 1200 or "%" not in c["hypothese"]:
        return 0  # long, sans chiffre dans l'hypothèse
    if "niveau" in c["hypothese"] or "niveaux" in c["hypothese"]:
        return 2  # loi graduée sur trois niveaux, ou interaction
    return 1      # comparaison de deux groupes

class JugeForme(J.AdaptateurScripte):
    """Ne lit ni les tables ni les lois établies : préfère la loi graduée, puis la comparaison de deux groupes, puis le texte long."""
    def _paire(self, consigne):
        blocs = J._BLOC_PAIRE.findall(consigne)
        (i1, _, j1), (i2, _, j2) = blocs[0], blocs[1]
        c1, c2 = json.loads(j1), json.loads(j2)
        c1.pop("identifiant", None); c2.pop("identifiant", None)
        s1, s2 = score_forme(c1), score_forme(c2)
        premier = s1 > s2 if s1 != s2 else hashlib.sha256((consigne[-200:]).encode()).digest()[0] % 2 == 0
        choisie, autre = (c1, c2) if premier else (c2, c1)
        cit = J._citation_propre(choisie, autre)
        mm = re.search(r"(?m)^- (D\d{2,} · .+)$", consigne)
        corps = {"comparaison": {"preferee": i1 if premier else i2, "critere": "verite", "citation_fiche": cit,
                                 "citation_dossier": mm.group(1) if mm else ""}}
        return "```json\n" + json.dumps(corps, ensure_ascii=False) + "\n```"
    def _seule(self, consigne):
        c = json.loads(J._BLOC_SEUL.search(consigne).group(1)); c.pop("identifiant", None)
        items = {k: True for k in self.items}
        return "```json\n" + json.dumps({"items": items, "note": 5}) + "\n```"

A = {"etiquette": "juge-a", "fournisseur": "argon", "modele": "gemini-4-argon", "famille": "gemini", "prix_usd": 0.062, "secondes": (8.0, 40.0)}
B = {"etiquette": "juge-b", "fournisseur": "astra", "modele": "gpt-6-astra", "famille": "gpt", "prix_usd": 0.25, "secondes": (10.0, 120.0)}
oracle = J.oracle_depuis(m)
issues, aires, d1 = {}, [], 0
N = int(sys.argv[1]) if len(sys.argv) > 1 else 20
for k in range(N):
    g = Graines(20261102 * 1000 + k)
    etapes, _ = J.etapes_v1(m, A, B, g)
    ad = {"argon": JugeForme("plafond", oracle, graine=k), "astra": JugeForme("plafond", oracle, graine=k + 1)}
    c = J.Compteur(1e9, 1e12, time.monotonic, {"juge-a": 0.0, "juge-b": 0.0})
    jn = J.executer_validation(etapes, materiaux=m, juges={"juge-a": A, "juge-b": B}, adaptateurs=ad,
                               consignes={"ancien": J.CONSIGNE_ANCIENNE_SUBSTITUTION, "v2": J.CONSIGNE_PAIRE_V2},
                               items=J.ITEMS_SUBSTITUTION, graines=g, compteur=c, plafond_session=1.0,
                               interdites=J.ETIQUETTES_INTERDITES_TEMOINS, dossier_appel=lambda j, e: os.devnull)
    mes = J.mesurer(jn, m, A, B, etapes=etapes)
    lec = J.lire_validation(mes)
    issues[lec["sous_issue"][:3] if lec["issue"] in ("I1", "I2", "I3") else lec["issue"]] = issues.get(lec["sous_issue"][:3] if lec["issue"] in ("I1", "I2", "I3") else lec["issue"], 0) + 1
    aires.append(mes["v2"]["juge-a"]["1"]["aire"])
    d1 += bool(lec["criteres"]["D1"]["tenu"])
    if k == 0:
        print("course 0 :", lec["issue"], lec["sous_issue"], {x: lec["criteres"][x]["valeur"] for x in lec["criteres"]},
              "p D1", lec["criteres"]["D1"]["p"], "rangs", mes["classes"]["rang_v2_a1"])
print("juge de forme, ", N, "courses : aire v2 A moyenne", round(sum(aires) / len(aires), 3), "min", round(min(aires), 3),
      "D1 tenu", d1, "/", N, "issues", issues)
