"""Mutations supplémentaires (contre-lecture) : gardes de la liste d'arrêt (section 8) que le banc ne vise pas. Mécanique du
banc du dépôt (recompilation en mémoire, aucun fichier modifié) ; essais visés : tout le module d'essais."""
import sys, os
R = "/home/claude/ideation-organism/orchestrator"
sys.path[:0] = [R, os.path.join(R, "essais")]
sys.dont_write_bytecode = True
from essais import mutations_juges_idees_v2 as M
J, L, P = M.J, M.L, M.P
TOUS = [P + c for c in ("Materiaux", "Entrees", "Citations", "Plan", "BradleyTerry", "Verdicts", "Statistiques", "Mesures", "Lecture",
                        "Compteur", "LanceurABlanc", "LanceurCheminReel", "Fermeture")]
EXTRA = [
    ("durée haute au-dessus de la durée maximale admise", L, "verifier_devis",
     'if d["duree_h"][1] * 3600.0 > plan["duree_max_s"] + 1e-9:', "if False:"),
    ("lot réel non soumis à la garde A4 de la configuration", L, "preparer_reel",
     'J.exiger_lot_reel(lot_reel, lot_reel["interdites"], lot_reel["mode_a4"])', "pass"),
    ("pièce de la configuration absente admise", L, "preparer_reel", "if plan[k] not in pieces:", "if False:"),
    ("texte au bon nom hors du dossier fixé admis", L, "lire_preenregistrement",
     "if os.path.dirname(reel) != dossier or not NOM_PREREG.match(os.path.basename(reel)):",
     "if not NOM_PREREG.match(os.path.basename(reel)):"),
    ("A2 : modèle servi absent admis", J, "appeler",
     'if r.statut == "ok" and not modele_conforme(juge["modele"], r.modele_servi):',
     'if r.statut == "ok" and r.modele_servi is not None and not modele_conforme(juge["modele"], r.modele_servi):'),
    ("plan : duree_max_h nulle admise", L, "lire_plan", "if not duree > 0:", "if False:"),
    ("plan : juges A et B sur le même relais admis", L, "lire_plan",
     'if a["etiquette"] == b["etiquette"] or a["famille"] == b["famille"] or a["fournisseur"] == b["fournisseur"]:', "if False:"),
    ("étiquette interdite pendant la course : arrêt retiré (entrée servie quand même)", J, "entree_paire",
     'garde_a4(entree, interdites, mode, "l\'entrée complète")', "pass"),
]
noms = sorted(set(TOUS))
temoin = M.jouer(noms)
print(f"témoin : {temoin[0]} essais, {len(temoin[1])} en échec")
for libelle, cible, nom, ancien, nouveau in EXTRA:
    try:
        restaurer = M.appliquer(cible, nom, ancien, nouveau)
    except Exception as e:
        print("NON APPLIQUÉE", libelle, e); continue
    try:
        n, echecs = M.jouer(noms)
    finally:
        restaurer()
    print(("SURVIVANTE" if not echecs else "tuée") + f"  {libelle} : {len(echecs)}/{n} essais en échec"
          + ("" if not echecs else " ; " + "; ".join(t.split(" ")[0] for t, _ in echecs[:3])))
apres = M.jouer(noms)
print(f"témoin après : {apres[0]} essais, {len(apres[1])} en échec")
