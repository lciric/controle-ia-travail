"""Recalcul indépendant (scipy, énumération) des statistiques d'une course à blanc, depuis le journal et les matériaux scellés."""
import json, sys, itertools, math, hashlib
import numpy as np
from scipy import optimize, stats
D = sys.argv[1]
jn = json.load(open(f"{D}/journal-juges-idees-v2.json"))
mat = json.load(open(f"{D}/materiaux-temoins-juges-idees-v2.json"))
mes = json.load(open(f"{D}/mesures-juges-idees-v2.json"))
fiches = {f["ident"]: dict(f, lot=l["nom"]) for l in mat["lots"] for f in l["fiches"]}
ev = [i for i, f in fiches.items() if f["role"] == "evaluation"]
bons = [i for i in ev if fiches[i]["qualite"] == 1]; mauvais = [i for i in ev if fiches[i]["qualite"] == 0]

def bt(ids, comps, lam=0.5, lamg=0.5):
    idx = {i: k for k, i in enumerate(ids)}; n = len(ids)
    P = np.array([idx[p] for p, s, y in comps]); S = np.array([idx[s] for p, s, y in comps]); Y = np.array([float(y) for p, s, y in comps])
    def f(v):
        eta = v[P] - v[S] + v[n]
        return -(np.sum(Y * eta - np.logaddexp(0, eta)) - lam / 2 * np.sum(v[:n] ** 2) - lamg / 2 * v[n] ** 2)
    def g(v):
        eta = v[P] - v[S] + v[n]; r = Y - 1 / (1 + np.exp(-eta))
        gr = np.zeros(n + 1); np.add.at(gr, P, r); np.add.at(gr, S, -r); gr[n] = r.sum()
        gr[:n] -= lam * v[:n]; gr[n] -= lamg * v[n]
        return -gr
    o = optimize.minimize(f, np.zeros(n + 1), jac=g, method="L-BFGS-B", options={"gtol": 1e-12, "ftol": 1e-15, "maxiter": 10000})
    th = o.x[:n] - o.x[:n].mean()
    return {i: th[k] for i, k in idx.items()}, o.x[n]

ecart_max = 0.0
forces = {}
for t in (1, 2):
    for lot in mat["lots"]:
        ids = [f["ident"] for f in lot["fiches"]]
        comps = [(e["premier"], e["second"], e["premier_gagne"]) for e in jn["v2"] if e["juge"] == "juge-a" and e["tirage"] == t and e["lot"] == lot["nom"] and e["valide"]]
        th, gam = bt(ids, comps)
        if t == 1:
            forces.update(th)
            gm = mes["v2"]["juge-a"]["1"]["position_par_lot"][lot["nom"]]
            print(f"BT {lot['nom']} tirage 1 : {len(comps)} comparaisons valides ; gamma scipy {gam:.6f} module {gm:.6f}")
        mod = mes["v2"]["juge-a"][str(t)]["forces"]
        ecart_max = max(ecart_max, max(abs(th[i] - mod[i]) for i in ids))
print("écart maximal |theta scipy − theta module| (deux tirages, deux lots) :", f"{ecart_max:.2e}")
x = [forces[i] for i in bons]; y = [forces[i] for i in mauvais]
U = sum((a > b) + 0.5 * (a == b) for a in x for b in y)
print("aire recalculée", U / 100, "module", mes["v2"]["juge-a"]["1"]["aire"])
# loi exacte par énumération des C(20, 10) partitions des rangs (aucune égalité)
assert len(set(x + y)) == 20
rangs = stats.rankdata(x + y)
r_obs = sum(rangs[:10])
cnt = tot = 0
for comb in itertools.combinations(range(1, 21), 10):
    tot += 1
    cnt += sum(comb) >= r_obs - 1e-9
print("p exact (énumération de", tot, "partitions)", cnt / tot, "module", mes["v2"]["juge-a"]["1"]["p_mann_whitney"],
      "scipy", stats.mannwhitneyu(x, y, alternative="greater", method="exact").pvalue)
# ancien protocole : approximation normale avec égalités
xo = mes["ancien"]["juge-a"]["1"]["x"]
xb = [xo[i] for i in bons]; xm = [xo[i] for i in mauvais]
r = stats.mannwhitneyu(xb, xm, alternative="greater", method="asymptotic", use_continuity=True)
print("ancien : aire", sum((a > b) + 0.5 * (a == b) for a in xb for b in xm) / 100, "p scipy (normale, égalités, continuité)", r.pvalue,
      "module", mes["ancien"]["juge-a"]["1"]["p_mann_whitney"])
# DeLong (formule des composantes structurelles, réécrite)
def comp(sc):
    v10 = np.array([np.mean([(sc[p] > sc[q]) + 0.5 * (sc[p] == sc[q]) for q in mauvais]) for p in bons])
    v01 = np.array([np.mean([(sc[p] > sc[q]) + 0.5 * (sc[p] == sc[q]) for p in bons]) for q in mauvais])
    return v10, v01
a10, a01 = comp(forces); b10, b01 = comp(xo)
d10, d01 = a10 - b10, a01 - b01
var = d10.var(ddof=1) / len(d10) + d01.var(ddof=1) / len(d01)
z = (a10.mean() - b10.mean()) / math.sqrt(var)
print("DeLong : différence", a10.mean() - b10.mean(), "variance", var, "p", 1 - stats.norm.cdf(z), "module", mes["comparaison_a"])
f2 = mes["v2"]["juge-a"]["2"]["forces"]
print("Spearman scipy", stats.spearmanr([forces[i] for i in ev], [f2[i] for i in ev]).statistic, "module", mes["test_retest_a"]["spearman"])
# position : part du premier ; bascule groupée par (tirage, paire) au lieu de la seule paire
va = [e for e in jn["v2"] if e["juge"] == "juge-a" and e["lot"] != "reel" and e["valide"]]
print("part du premier", sum(e["premier_gagne"] for e in va) / len(va), "sur", len(va))
for cle_nom, cle in (("paire seule (module)", lambda e: tuple(e["paire"])), ("(tirage, paire)", lambda e: (e["tirage"], tuple(e["paire"])))):
    g = {}
    for e in va:
        g.setdefault(cle(e), []).append(e)
    deux = [es for es in g.values() if len(es) == 2 and len({e["premier"] for e in es}) == 2]
    print("bascule groupée par", cle_nom, ":", sum(es[0]["gagnant"] != es[1]["gagnant"] for es in deux), "/", len(deux))
communes = set()
gr = {}
for e in jn["v2"]:
    if e["juge"] == "juge-a" and e["lot"] != "reel":
        gr.setdefault(tuple(e["paire"]), set()).add(e["tirage"])
print("paires présentes aux deux tirages :", sum(1 for v in gr.values() if v == {1, 2}))
# kappa des paires mélangées
q = {i: f["qualite"] for i, f in fiches.items()}
eb = {}
for e in jn["v2"]:
    if e["juge"] == "juge-b" and e["valide"] and e["lot"] != "reel" and q[e["paire"][0]] != q[e["paire"][1]]:
        eb.setdefault(tuple(e["paire"]), []).append(e)
xa, xb2 = [], []
for e in jn["v2"]:
    c = tuple(e["paire"])
    if e["juge"] == "juge-a" and e["tirage"] == 1 and e["valide"] and e["lot"] != "reel" and c in eb:
        ref = min(c, key=lambda i: hashlib.sha256(i.encode()).hexdigest())
        for f in eb[c]:
            xa.append(e["gagnant"] == ref); xb2.append(f["gagnant"] == ref)
po = np.mean([a == b for a, b in zip(xa, xb2)]); pa, pb = np.mean(xa), np.mean(xb2)
pe = pa * pb + (1 - pa) * (1 - pb)
print("kappa paires mélangées recalculé", (po - pe) / (1 - pe), "n", len(xa), "module", mes["accord"]["kappa_paires_v2"]["kappa"])
