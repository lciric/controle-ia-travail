import sys, os, importlib.util
R = "/home/claude/ideation-organism/orchestrator"
sys.path.insert(0, R)
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location("lanceur_cl", os.path.join(R, "demonstrations", "validation_juges_idees_v2.py"))
L = importlib.util.module_from_spec(spec); spec.loader.exec_module(L)
t = open(sys.argv[1], encoding="utf-8").read()
t = t.replace("<<MATERIAUX_SHA256>>", L.J.construire_materiaux()["empreinte"]).replace("<<CONFIGURATION_SHA256>>", "a" * 64)
try:
    p = L.lire_plan(t)
    print("plan lu :", {k: p[k] for k in ("plafond_usd", "plafond_juge_a_usd", "plafond_juge_b_usd", "duree_max_s", "go")})
except Exception as e:
    print("refus du code actuel :", type(e).__name__, e)
