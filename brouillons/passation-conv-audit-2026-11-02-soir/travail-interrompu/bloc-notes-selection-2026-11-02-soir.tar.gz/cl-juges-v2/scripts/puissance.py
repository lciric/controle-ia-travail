import sys, json
sys.path.insert(0, "/home/claude/ideation-organism/orchestrator")
from pole import juges_idees_v2 as J
# reproduction de cases du brouillon (graine 20261102, 20000 répétitions)
for n in (10,):
    for a in (0.5, 0.8, 0.9):
        r = J.puissance_aire(n, n, a, repetitions=20000, graine=20261102)
        print("repro", n, a, r["u_critique"], round(r["alpha_exact"], 4), r["puissance_test"], r["part_aire_au_seuil"], r["critere_d1"])
# tailles candidates
for n in (12, 14, 15, 16, 18, 20):
    for a in (0.5, 0.8, 0.85, 0.9):
        r75 = J.puissance_aire(n, n, a, repetitions=20000, graine=20261102)
        r70 = J.puissance_aire(n, n, a, repetitions=20000, graine=20261102, seuil_point=0.70)
        print("n", n, "aire", a, "Uc", r75["u_critique"], "alpha", round(r75["alpha_exact"], 4), "test", r75["puissance_test"],
              "D1(0.75)", r75["critere_d1"], "D1(0.70)", r70["critere_d1"])
