"""Chemin réel avec commandes factices locales (aucun réseau) : (1) le relais d'Argon rend un autre modèle servi ;
(2) le relais d'Argon refuse (code 4, sans ligne JSON : refus de dépense avant envoi). Quel arrêt, quel motif, quelle dépense ?"""
import sys, os, json, io, unittest.mock
R = "/home/claude/ideation-organism/orchestrator"
sys.path[:0] = [R, os.path.join(R, "essais")]
sys.dont_write_bytecode = True
from essais import test_juges_idees_v2 as T
import aides_v56 as A56
from pole.outils import ecrire_scelle, sha256_fichier
for cas in ("autre modèle servi", "refus de dépense (code 4)"):
    t = T.LanceurCheminReel("test_cas_sain_verifier_seulement_aucune_ecriture")
    t.setUp()
    try:
        items = {"texte": "```json\n" + json.dumps({"items": {k: True for k in t.conf["items_juge"]}}) + "\n```", "cout_usd": 0.001}
        if cas == "autre modèle servi":
            cmd = A56.commande_factice(t.tmp, "argon2", dict(items, modele_servi="gemini-4-argon-lite"))
        else:
            chemin = os.path.join(t.tmp, "argon_refus.py")
            open(chemin, "w").write("import sys\nsys.stdin.read()\nsys.stderr.write('plafond de l etape atteint')\nsys.exit(4)\n")
            cmd = [sys.executable, "-I", "-B", chemin]
        t.conf["fournisseurs"]["argon"]["commande"] = cmd + ["--registre", "{REGISTRE}", "--plafond-cumule-usd", "1"]
        json.dump(t.conf, open(t.chemin_conf, "w"), ensure_ascii=False)
        os.remove(t.prereg); os.remove(t.prereg + ".sha256")
        ecrire_scelle(t.prereg, T.texte_preenregistrement(conf_sha=sha256_fichier(t.chemin_conf)))
        err = io.StringIO()
        with unittest.mock.patch("sys.stderr", err):
            code = T.lanceur.principal(t.argv())
        j = json.load(open(os.path.join(t.sortie, T.lanceur.SORTIES["journal"])))
        l = json.load(open(os.path.join(t.sortie, T.lanceur.SORTIES["lecture"])))
        e0 = j["ancien"][0] if j["ancien"] else {}
        print(f"[{cas}] code {code} ; arrêt : {j.get('arret')!r}")
        print(f"   appels ancien {len(j['ancien'])}, v2 {len(j['v2'])} ; premier appel : statut {e0.get('statut')!r}, coût {e0.get('cout_usd')}, "
              f"valide {e0.get('valide')} ; dépense comptée {j.get('depense_usd')} USD ; issue {l['issue']} ({l['sous_issue'][:60]})")
        m = json.load(open(os.path.join(t.sortie, T.lanceur.SORTIES["manifeste"])))
        __import__("shutil").rmtree(m["dossier_des_sessions"], True)
    finally:
        for f in reversed(t._cleanups):
            pass
        t.doCleanups()
