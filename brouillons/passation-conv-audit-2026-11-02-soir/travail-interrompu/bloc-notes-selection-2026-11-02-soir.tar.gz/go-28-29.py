import sys, pathlib
p = pathlib.Path('/home/claude/controle-ia-travail/registres/go.md')
s = p.read_text(encoding='utf-8')
for n in (28, 29):
    assert f'GO-2026-11-02-{n:02d}' not in s
src = ("mots de Lazar dans la session conv-audit, 2 novembre 2026 : 18:35 UTC « et sur le programme contrôle ia ? » et « je veux le même prompt » (demande de courses nouvelles sur le contrôle) ; 18:27 UTC « prends des budgets et plafonds très larges » ; 18:26 UTC « go finir, arrête de mettre des budgets temps et de les couper » et « je ne veux pas de blocage, de résultats non concluants par défaut de conception, de plafond ou que sais-je » ; 18:29 UTC « je veux de NOUVEAUX runs qui avancent sur notre programme »")
lignes = [
f"| GO-2026-11-02-28 | 2026-11-02 | calcul | **Contrôle, T0.6 organisme v0 et test croisé d'étiologie (critères 2 et 3 de G0)** : premier organisme saboteur par adaptateur de rang faible à dose réglable (dose 0 = base au bit près), distillé sur les actions du saboteur instruit de P3 ; activations enregistrées ; sondes de T0.7 entraînées sur une étiologie (consigne cachée) et testées sur l'autre (adaptateur), et réciproquement ; courbe dose–réponse ; plancher aléatoire apparié ; puissance calculée avant le lancement ; sous les préenregistrements de T0.6 et T0.7 contre-lus (règle R2), scellés, committés et poussés avant la course ; instance H200 ou A100 chez Vast.ai, **aucun budget de temps qui coupe une étape** ; sortie scellée avant lecture ; verdict par lecteur neuf ; attendu ≈ 60 USD ; **plafond exactement 200 USD** | 200 USD | 2026-11-16 | Lazar | {src} |",
f"| GO-2026-11-02-29 | 2026-11-02 | calcul | **Contrôle, P3-bis : témoin positif planté** (saboteur dont le signal est certainement dans les activations : consigne de sabotage visible dans le contexte, mêmes tâches, même modèle `meta-llama/Llama-3.1-8B-Instruct` à la révision de P3, témoin honnête de même longueur), pour prouver que la chaîne sonde-calibrage détecte un signal présent ; sous un préenregistrement contre-lu, scellé, committé et poussé avant la course ; instance A100 chez Vast.ai, aucun budget de temps qui coupe une étape ; sortie scellée avant lecture ; verdict par lecteur neuf ; attendu ≈ 25 USD ; **plafond exactement 80 USD** | 80 USD | 2026-11-16 | Lazar | {src} |",
]
i = s.index('| GO-2026-11-02-27 |')
j = s.index('\n', i)
s = s[:j+1] + '\n'.join(lignes) + '\n' + s[j+1:]
p.write_text(s, encoding='utf-8')
print('ok')
