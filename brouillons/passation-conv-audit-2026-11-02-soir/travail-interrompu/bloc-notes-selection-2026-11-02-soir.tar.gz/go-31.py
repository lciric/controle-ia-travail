import pathlib
p = pathlib.Path('/home/claude/controle-ia-travail/registres/go.md')
s = p.read_text(encoding='utf-8')
assert 'GO-2026-11-02-31' not in s
src = ("mot de Lazar dans la session conv-audit, 2 novembre 2026, 18:47 UTC, verbatim : « envoie ce prompt au collisionneur : » (pièce jointe `PROMPT_brainstorm_instance_neuve_2026-11-02 (1).md`, sha256 6a12dc71…) ; 18:27 UTC « prends des budgets et plafonds très larges »")
ligne = (f"| GO-2026-11-02-31 | 2026-11-02 | calcul | **Collisionneur, un tour sur le prompt de brainstorm de Lazar** (`brouillons/canal-reprise-releve-v1/envois/conv-audit/PROMPT_brainstorm_instance_neuve_2026-11-02_v1.md`, 6a12dc71…) : version neuve du collisionneur à nom neuf chez session-depot, espèces A Fable 5.1, B `claude-opus-5-5` (modèle servi vérifié à chaque appel), C Argon, D Kimi, E Astra ; faits joints déclarés (fichiers publics des deux dépôts, aucun texte privé ; « pas de web, pas d'exécution de code ; nouveauté : non cherché » en tête) ; course à blanc puis devis avant l'appel ; sortie scellée avant lecture, copiée sur le canal ; attendu 15 à 26 USD (tours v8) ; **plafond exactement 40 USD** | 40 USD | 2026-11-16 | Lazar | {src} |")
i = s.index('| GO-2026-11-02-30 |')
j = s.index('\n', i)
s = s[:j+1] + ligne + '\n' + s[j+1:]
p.write_text(s, encoding='utf-8')
print('ok')
