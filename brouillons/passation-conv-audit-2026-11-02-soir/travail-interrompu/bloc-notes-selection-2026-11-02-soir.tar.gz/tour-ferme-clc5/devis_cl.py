"""Devis du brouillon 5 refait indépendamment (pas `jouer_devis`) sur le `Compteur` gelé de `pole/tour_ferme_v63.py`.
Usage : python3 -I -B devis_cl.py ORCHESTRATOR"""
import sys

sys.path.insert(0, sys.argv[1])
sys.dont_write_bytecode = True
from pole import tour_ferme_v63 as T  # noqa: E402

BORNE, VERIF_BORNE = T.BUDGET_EXPERIMENTATEUR_PAR_CARTE_USD, T.BUDGET_VERIFICATEUR_PAR_CARTE_USD


def course(cout_carte, kimi=44.0, argon=6.0, plafond=50.0, verif=0.02, plus_g1=0.0, reel=(4, 2, 2), alea=1.5, tem=2.4, prop=0.024):
    c = T.Compteur(plafond, 1e9, {"kimi": kimi, "argon": argon})
    marge, testes = None, 0.0
    try:
        for g in (1, 2, 3):
            c.ajouter(prop, "proposeur", "kimi")
            c.ajouter(prop, "proposeur", "argon")
            etages = [reel[g - 1] + (plus_g1 if g == 1 else 0), tem]  # bras réel : cartes puis témoins
            if g > 1:
                etages += [0.0, tem]  # recopie-mélange : aucune carte promue (L2), témoins
            etages += [alea, tem]  # aléatoire
            for n in etages:
                if n <= 0:
                    continue
                marge = c.parts["kimi"] - c.par_relais["kimi"] - n * BORNE
                c.verifier_parts_avant_etage({"kimi": n * BORNE, "argon": n * VERIF_BORNE})
                c.ajouter(n * min(cout_carte, BORNE), "tests_de_mort", "kimi")
                c.ajouter(n * verif, "tests_de_mort", "argon")
                testes += n
    except T.ArretTour as e:
        return "arrêt : " + str(e)[:70], marge, c, testes
    return None, marge, c, testes


print("borne", BORNE, "vérificateur", VERIF_BORNE, "tours max", T.v5.TOURS_MAX_PAR_FICHE)
for tours, prix in ((2, 0.04), (4, 0.06), (6, 0.06), (8, 0.06), (12, 0.06), (100, 0.06)):
    a, m, c, n = course(tours * prix)
    print(f"{tours:>3} tours à {prix} : arrêt {a} ; testés {n:.1f} ; Kimi {c.par_relais['kimi']:.2f} ; Argon {c.par_relais['argon']:.2f} ; "
          f"total {c.usd:.2f} ; marge dernier étage {m:.2f}")


def limite(cout_carte, verif=0.02, **kw):
    x = 0.0
    while course(cout_carte, verif=verif, plus_g1=round(x + 0.1, 1), **kw)[0] is None:
        x = round(x + 0.1, 1)
    return x


for verif in (0.02, 0.1):
    print(f"cartes de plus en génération 1 qui tiennent, toutes à leur borne, vérificateur {verif} : +{limite(BORNE, verif)}")
print(f"à 12 tours au prix du devis : +{limite(0.72)}")
for k, a in ((44, 6), (40, 10), (45, 5), (43, 7)):
    print(f"parts {k}/{a} : à la borne +{limite(BORNE, 0.02, kimi=k, argon=a)} (vérificateur 0,02) ; +{limite(BORNE, 0.1, kimi=k, argon=a)} (vérificateur 0,1)")
# borne relevée (prix d'un relèvement, point 5)
for b in (1.0, 1.2):
    T.BUDGET_EXPERIMENTATEUR_PAR_CARTE_USD = b
    BORNE = b
    a, m, c, n = course(b)
    print(f"borne {b} USD : devis toutes cartes à leur borne : arrêt {a} ; Kimi {c.par_relais['kimi']:.2f} ; +{limite(b)} cartes de plus")
T.BUDGET_EXPERIMENTATEUR_PAR_CARTE_USD = BORNE = 0.80
# durée : seuil de la session moyenne au-delà duquel 24 h mordent avant l'arrêt par la dépense
for nom, cartes, tours in (("devis, 12 tours", 31.7, 12), ("54,9 à la borne, 12 tours", 54.9, 12), ("60,7 à 12 tours (prix du devis)", 60.7, 12),
                           ("devis, 3 tours", 31.7, 3), ("144 (maximum théorique), 12 tours", 144, 12)):
    sessions = cartes * (tours + 1) + 6
    execs = cartes * 3 * 120
    print(f"durée, {nom} : {sessions:.0f} sessions, exécutions {execs / 3600:.2f} h ; seuil de session moyenne {(86400 - execs) / sessions:.0f} s")
