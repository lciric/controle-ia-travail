"""Passage `--verifier-seulement` du chemin réel v63 sur le brouillon 5 (copie scellée, case remplie par l'empreinte d'une
configuration v3 simulée : la v2 du 1er novembre, pièces remplacées par des fichiers factices à leur empreinte, plafond 50 USD),
registre de GO réel (lecture seule), bac remplacé par l'exécuteur factice (aucune identité dédiée utilisée), aucun appel.
Usage : env -i PATH=… HOME=… TMPDIR=… POLE_MACHINE_JETABLE_V56=1 python3 -I -B verifier_seulement_b5.py ORCH TRAVAIL CONF_V2 REGISTRE [kimi_protocole]"""
import contextlib
import hashlib
import io
import json
import os
import sys

ORCH, TRAVAIL, CONF_V2, REG = sys.argv[1:5]
VARIANTE = sys.argv[5] if len(sys.argv) > 5 else "commande_externe"
sys.path.insert(0, ORCH)
sys.dont_write_bytecode = True
import importlib.util  # noqa: E402

spec = importlib.util.spec_from_file_location("lanceur_v63_cl5", os.path.join(ORCH, "demonstrations", "tour_ferme_v63.py"))
L = importlib.util.module_from_spec(spec)
spec.loader.exec_module(L)
from pole import a_blanc_v59 as A  # noqa: E402
from pole.outils import ecrire_scelle  # noqa: E402

os.makedirs(TRAVAIL)
conf = json.load(open(CONF_V2, encoding="utf-8"))
os.makedirs(os.path.join(TRAVAIL, "pieces"))
for nom, p in conf["pieces"].items():
    contenu = f"pièce factice {nom}\n".encode()
    with open(os.path.join(TRAVAIL, p["chemin"]), "wb") as f:
        f.write(contenu)
    p["sha256"] = hashlib.sha256(contenu).hexdigest()
conf["budget"]["plafond_usd"] = 50.0
if VARIANTE == "kimi_protocole":
    conf["fournisseurs"]["kimi"] = {"type": "kimi_protocole", "url_relais": "http://127.0.0.1:8804", "modele": "kimi-k3.1-pro",
                                    "prix_entree": 0.6, "prix_sortie": 2.5, "max_sortie_jetons": 4000, "sortie_min_jetons": 16,
                                    "delai_s": 60.0, "porte_plafond": {"type": "commande", "commande": ["/bin/true"], "delai_s": 10.0}}
chemin_conf = os.path.join(TRAVAIL, "conf-v3-simulee.json")
with open(chemin_conf, "w", encoding="utf-8") as f:
    json.dump(conf, f, ensure_ascii=False, indent=1)
sha_conf = hashlib.sha256(open(chemin_conf, "rb").read()).hexdigest()
dp = os.path.join(TRAVAIL, "prereg")
os.makedirs(dp)
t5 = open(os.path.join(ORCH, "prereg", "preenregistrement-tour-ferme-v1-brouillon5.md"), encoding="utf-8").read()
pr = os.path.join(dp, "preenregistrement-tour-ferme-v1-v1.md")
ecrire_scelle(pr, t5.replace("<<CASE_CONFIGURATION_V3>>", sha_conf))
L.DOSSIER_PREREG = dp
A.choisir_executeur = lambda bac, **kw: (A.v5.ExecuteurFactice(delai_s=60.0), {"nom": "factice (contre-lecture)"})
argv = [os.path.join(TRAVAIL, "sortie"), "--etage", "1", "--preenregistrement", pr, "--configuration", chemin_conf, "--moteur", "reel",
        "--confirmer-moteur-reel", "--registre-go", REG, "--go", "GO-2026-11-02-23", "--bac", "reel", "--utilisateur-bac", "64097",
        "--verifier-seulement"]
out, err = io.StringIO(), io.StringIO()
with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
    code = L.principal(argv)
print("variante", VARIANTE, "code", code)
print("sortie écrite :", os.path.exists(argv[0]))
o = out.getvalue()
if o:
    r = json.loads(o)
    print({k: r[k] for k in ("verification", "ecriture", "appel", "portes")}, "plan :", {k: r["plan"][k] for k in ("plafond_usd", "parts", "duree_max_s")})
    print("budget par appel (plafonds_session.proposeur) :", r["configuration"]["budget_appel_usd"], "; substitutions :",
          [(s["fournisseur"], s["apres"]) for s in r["configuration"]["substitutions_dans_les_commandes"] if s["apres"] in ("50",)])
print("stderr :", err.getvalue()[-400:])
