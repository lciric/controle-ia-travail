"""Assemble la contre-lecture : partie écrite à la main + section 7 tirée du JSON des couples (même texte, à l'octet).
Usage : python3 -I -B assembler_cl.py PARTIE1 COUPLES_JSON BROUILLON5 SORTIE_MD"""
import json
import os
import sys

partie1, chemin_json, b5, sortie = sys.argv[1:5]
if os.path.exists(sortie):
    raise SystemExit(f"refus : {sortie} existe (on n'écrase jamais)")
couples = json.load(open(chemin_json, encoding="utf-8"))
lignes = open(b5, encoding="utf-8").read().splitlines()
blocs = []
for c in couples:
    ligne = next(k for k, l in enumerate(lignes, 1) if c["ancien"].split("\n")[0] in l)
    blocs.append(f"**{c['id']}** — {c['constat']} ; brouillon 5, l. {ligne}\n\nremplacer :\n\n~~~~text\n{c['ancien']}\n~~~~\n\n"
                 f"par :\n\n~~~~text\n{c['nouveau']}\n~~~~\n")
texte = open(partie1, encoding="utf-8").read().rstrip("\n") + "\n\n" + "\n".join(blocs)
with open(sortie, "w", encoding="utf-8") as f:
    f.write(texte)
print("écrit", sortie, len(texte.splitlines()), "lignes")
