"""Couples T101 à T112 de la contre-lecture courte du brouillon 5 : écriture du JSON, puis contrôles (chaque « ancien » une fois
dans le brouillon 5 et une fois à son application, dans l'ordre ; zones, marqueurs, plan, bloc d'empreintes et garde 6 complète sur
le texte obtenu). Usage : python3 -I -B couples_clc5.py ORCHESTRATOR SORTIE_JSON TRAVAIL"""
import datetime
import hashlib
import json
import os
import re
import sys
import tempfile

ORCH, SORTIE, TRAVAIL = sys.argv[1:4]
CL = "`prereg/contre-lecture-courte-preenregistrement-tour-ferme-v5.md`"
CP = "`prereg/couples-contre-lecture-tour-ferme-v5.json`"

COUPLES = [
    ("T101", "mineur 44 (en-tête : commit des fichiers `_v63`)",
     "cinq d'entre eux modifiés dans l'arbre de travail, non commités)",
     "cinq d'entre eux modifiés dans l'arbre de travail, non commités à l'écriture du texte, commités depuis au commit `a12713a`)"),
    ("T102", "mineur 39 (section 0, point 1 : la borne au prix du devis)",
     "aucune carte n'est jugée sur une exécution tronquée par la borne (sections 4.1 et 12).",
     "à ce prix, aucune carte n'est jugée sur une exécution tronquée par la borne ; au-delà de 0,067 USD par tour en moyenne (prix "
     "réel d'un tour inconnu, C7), ce que la borne coûte est écrit en section 12 (sections 4.1 et 12)."),
    ("T103", "mineur 40 (section 0, point 3 : ce que la durée coupe)",
     "3. **Durée de l'étage 1 : 24 heures** (4 au brouillon 4) : garde contre une boucle folle, jamais un couperet (section 12).",
     "3. **Durée de l'étage 1 : 24 heures** (4 au brouillon 4) : garde contre une boucle folle, qui ne coupe jamais une carte ni un "
     "étage en cours ; si elle mordait, la course s'arrêterait sans issue (code 3) : seuils en section 12."),
    ("T104", "mineur 40 (section 7, garde 13)",
     "durée > plafond (24 h étage 1, garde contre une boucle folle, jamais un couperet ; 2 h étage 2)",
     "durée > plafond (24 h étage 1, garde contre une boucle folle, qui ne coupe jamais une carte ni un étage en cours, seuils en "
     "section 12 ; 2 h étage 2)"),
    ("T105", "mineur 44 (section 10 bis : contre-lecture courte faite)",
     "**Contre-lecture R2 courte et neuve à faire, sur ce texte, le diff v62 → v63 (code v63 du brouillon 5) et les essais neufs.**",
     "Contre-lecture R2 courte et neuve, sur ce texte, le diff v62 → v63 (code v63 du brouillon 5) et les essais neufs : " + CL
     + " (2 novembre 2026, sous-agent neuf), verdict « scellable après couples » (aucun bloquant ; important I32 ; mineurs 39 à 44) ; "
     "ses couples T101 à T112 (" + CP + ") sont appliqués à ce texte ; empreintes des deux fichiers dans leurs compagnons `.sha256`."),
    ("T106", "mineur 39 (section 12 : prix de la borne, s'il était dépassé)",
     "(12 × 0,06 = 0,72 USD ; la borne ne mord qu'au-delà de 0,067 USD par tour en moyenne) : aucune carte n'est jugée sur une "
     "exécution tronquée par la borne.",
     "(12 × 0,06 = 0,72 USD ; la borne ne mord qu'au-delà de 0,067 USD par tour en moyenne, prix réel d'un tour de Kimi inconnu, C7) : "
     "à ce prix, aucune carte n'est jugée sur une exécution tronquée par la borne. Prix de la borne, si ce prix était dépassé : une "
     "carte qui voudrait ses 12 tours finirait ses tours à la borne (champ `fin_des_tours` de son `resultat.json` scellé : « plafond "
     "de la fiche … atteint » ou « budget_depasse ») et serait jugée sur ce qu'elle a exécuté — « non concluant » sans exécution "
     "réussie, compté par T4 —, jamais un arrêt du fait du code (pour les commandes des relais : annexe A, A.6 bis)."),
    ("T107", "mineur 41 (section 12 : où mord le plafond, asymétrie R4)",
     "il faudrait que le juge promeuve presque tout, témoins faux compris, ce que L1, L2 et L2b excluent ; si cela arrivait, la course "
     "s'arrêterait avant un étage (arrêt de la liste, code 3, aucune issue lue), jamais sur une carte tronquée.",
     "il faudrait que le juge promeuve presque tout, témoins faux compris, ce que L1, L2 et L2b excluent. L'arrêt viendrait bien avant "
     "ce maximum : dès ≈ 55 cartes et témoins testés si chacun dépense sa borne (≈ 61 à 12 tours au prix du devis ; davantage si les "
     "tours coûtent moins), soit ≈ 1,7 fois le devis — par exemple un bras réel promu presque entier à chaque génération, ou un juge "
     "laxiste ; la course s'arrêterait alors avant un étage (arrêt de la liste, code 3, aucune issue lue, chiffres partiels rapportés), "
     "jamais sur une carte tronquée. Asymétrie dite (R4) : seul un excès de cartes testées, c'est-à-dire de promotions, peut faire "
     "mordre ce plafond, et l'arrêt "
     "prendrait alors la place de l'issue qu'il aurait fallu lire (« ne tient pas (T3, T5) » d'un juge laxiste, ou l'issue A4 d'un "
     "bras réel très fécond)."),
    ("T108", "mineur 40 (section 12 : seuils de la durée)",
     "il ne peut mordre avant le plafond de dépense que si la session moyenne dépasse ≈ 93 s avec 54,9 cartes testées à 12 tours "
     "(≈ 179 s aux tailles du devis), plus du double de la latence du devis ; une course saine ne l'atteint pas,",
     "il mord avant le plafond de dépense si la durée moyenne d'une session dépasse (24 h − durée des exécutions du bac) / nombre de "
     "sessions : à 12 tours par carte, ≈ 179 s aux tailles du devis (31,7 testés), ≈ 93 s à 54,9 testés (tous à leur borne), ≈ 81 s "
     "à 60,7 testés (12 tours au prix du devis), moins encore si des tours moins chers laissaient tester plus de cartes ; à 3 tours "
     "par carte aux tailles du devis, ≈ 565 s (exécutions comptées à 3 × 120 s par carte) ; la latence réelle d'une session de Kimi "
     "expérimentateur n'est pas mesurée (devis : 10 à 40 s par appel) ; une course aux tailles du devis ne l'atteint pas,"),
    ("T109", "mineur 44 (section 13 : bloc d'empreintes revérifié après commit)",
     "modifiés au brouillon 5, non commités : à revérifier après commit ;",
     "modifiés au brouillon 5, non commités à l'écriture, commités depuis au commit `a12713a` ; revérifiées par la contre-lecture "
     "courte du 2 novembre 2026 : les 91 empreintes égales à l'arbre de travail, à `a12713a` et à la tête `08b1f17` ;"),
    ("T110", "mineur 44 (section 14, point (2))",
     "(2) la contre-lecture R2 courte et neuve de ce brouillon 5, du diff v62 → v63 et des essais neufs, par un sous-agent neuf ;",
     "(2) fait : la contre-lecture R2 courte et neuve de ce brouillon 5, du diff v62 → v63 et des essais neufs, par un sous-agent "
     "neuf (" + CL + "), ses couples appliqués ;"),
    ("T111", "I32 (section 14, point (4) : le constat de la session-depot)",
     "liste exacte de ce que le code lit : annexe A ; son empreinte va à la clé `configuration_sha256` du plan gelé)",
     "liste exacte de ce que le code lit : annexe A ; son empreinte va à la clé `configuration_sha256` du plan gelé ; avant d'écrire "
     "ce fichier, le constat de l'annexe A, A.6 bis : rôles et plafonds de session acceptés par ses deux commandes)"),
    ("T112", "I32 (annexe A, A.6 bis neuve : ce que les commandes des relais doivent accepter)",
     "**A.7 — Vérificateur et expérimentateur : modèle, port, effort.**",
     "**A.6 bis — Ce que les commandes des relais doivent accepter (contre-lecture courte, I32).** Le code ne voit d'une commande "
     "que son code de sortie et sa dernière ligne : il ne peut savoir ni si elle joue le rôle qu'il lui donne (`ROLE_POLE`), ni si "
     "elle refuse une session dont `PLAFOND_SESSION_USD` est sous sa propre réservation de pire cas (sortie maximale de son rôle, "
     "plancher de sortie). Une commande qui refuse — code de sortie non nul, ou coût absent ou nul — rend « erreur » : session en "
     "échec, **arrêt de la course** (code 3, aucune issue), même pour le vérificateur, qui n'est jamais décisif ; la configuration "
     "étant gelée par son empreinte, la corriger exige un texte nouveau (la reprise de la section 7 ne vaut que pour une panne "
     "d'infrastructure). Le passage `--verifier-seulement` n'appelle rien et ne le voit pas ; aucune course à blanc ne l'a joué "
     "(doublures) ; l'étage des tests de mort n'a jamais tourné pour de vrai avec ces relais (section 1). Avant d'écrire le fichier "
     "définitif et son empreinte (A.2), la session-depot vérifie par lecture du code de "
     "ses deux commandes (aucun appel) : Kimi accepte `proposeur_ideation` et `experimentateur_test`, Argon `proposeur_ideation` et "
     "`lecteur_test` ; aucune ne refuse avant dépense une session dont le plafond vaut, pour l'expérimentateur, le reste de la borne "
     "de 0,80 USD de la carte (0,80 USD au premier tour, parfois quelques centimes au dernier), pour le vérificateur 0,1 USD à chaque "
     "session (le plus bas des plafonds fixes de la course), pour un proposeur `plafonds_session.proposeur` ; au besoin, elle règle les options "
     "de ses commandes dans la configuration, gelées ensuite par son empreinte. Elle écrit ce constat avec l'empreinte qu'elle "
     "remet.\n\n**A.7 — Vérificateur et expérimentateur : modèle, port, effort.**"),
]

sys.path.insert(0, ORCH)
sys.dont_write_bytecode = True
import importlib.util  # noqa: E402

spec = importlib.util.spec_from_file_location("lanceur_v63_clc5", os.path.join(ORCH, "demonstrations", "tour_ferme_v63.py"))
L = importlib.util.module_from_spec(spec)
spec.loader.exec_module(L)
from pole.outils import ecrire_scelle  # noqa: E402

B5 = os.path.join(ORCH, "prereg", "preenregistrement-tour-ferme-v1-brouillon5.md")
t5 = open(B5, encoding="utf-8").read()
assert hashlib.sha256(t5.encode()).hexdigest() == "c81aa6ef72255adab76abcffc8e06cc0c570069cf09aa2035c285a54212fc3d3"
lignes = t5.splitlines()
t = t5
for ident, constat, ancien, nouveau in COUPLES:
    n5, nt = t5.count(ancien), t.count(ancien)
    ligne = next(k for k, l in enumerate(lignes, 1) if ancien.split("\n")[0] in l)
    print(f"{ident} l. {ligne} : ancien ×{n5} dans le brouillon 5, ×{nt} à l'application ; nouveau ×{t5.count(nouveau)} avant")
    assert n5 == 1 and nt == 1, ident
    assert not L.MARQUEUR.search(nouveau) and "<!--" not in nouveau and "-->" not in nouveau, ident
    t = t.replace(ancien, nouveau)


def zones(x):
    out, pos = [], 0
    while (i := x.find(L.DEBUT_ZONE_2, pos)) >= 0:
        j = x.find(L.FIN_ZONE_2, i)
        out.append(x[i:j + len(L.FIN_ZONE_2)])
        pos = j + len(L.FIN_ZONE_2)
    return out


hz5, hz = L.texte_hors_etage_2(t5), L.texte_hors_etage_2(t)
print("zones identiques au brouillon 5 :", zones(t) == zones(t5), len(zones(t)))
print("marqueurs hors zone :", sorted(set(L.MARQUEUR.findall(hz))), "; tous :", sorted(set(L.MARQUEUR.findall(t))) == sorted(set(L.MARQUEUR.findall(t5))))
blocs = [L._bloc(x, L.DEBUT_EMPREINTES, L.FIN_EMPREINTES, "e") for x in (hz5, hz)]
plans = [L._bloc(x, L.DEBUT_PLAN, L.FIN_PLAN, "p") for x in (hz5, hz)]
print("bloc d'empreintes inchangé :", blocs[0] == blocs[1], "; plan inchangé :", plans[0] == plans[1])
p = L.lire_plan(hz.replace("<<CASE_CONFIGURATION_V3>>", "cd" * 32))
print("plan relu :", p["plafond_etage_1_usd"], p["plafond_kimi_usd"], p["plafond_argon_usd"], p["duree_etage_1_h"], p["go"])
d = tempfile.mkdtemp(prefix="clc5-garde6-", dir=TRAVAIL)
copie = os.path.join(d, "preenregistrement-tour-ferme-v1-v1.md")
ecrire_scelle(copie, t.replace("<<CASE_CONFIGURATION_V3>>", "cd" * 32))
e, emp, gel, pl = L.lire_preenregistrement(copie, dossier_prereg=d)
print("garde 6 complète sur le texte obtenu (copie scellée, case d'essai) : acceptée ;", len(gel), "empreintes ; E ≥ 2^64 :", e >= 2 ** 64)
print("texte obtenu :", len(t.splitlines()), "lignes, sha256", hashlib.sha256(t.encode()).hexdigest())
with open(os.path.join(TRAVAIL, "brouillon5-apres-couples.md"), "w", encoding="utf-8") as f:
    f.write(t)
if SORTIE != "-":
    if os.path.exists(SORTIE):
        raise SystemExit(f"refus : {SORTIE} existe (on n'écrase jamais)")
    with open(SORTIE, "w", encoding="utf-8") as f:
        json.dump([{"id": i, "constat": c, "ancien": a, "nouveau": n} for i, c, a, n in COUPLES], f, ensure_ascii=False, indent=1)
        f.write("\n")
    print("écrit :", SORTIE, hashlib.sha256(open(SORTIE, "rb").read()).hexdigest())
print("heure", datetime.datetime.now(datetime.timezone.utc).strftime("%H:%M:%S UTC"))
