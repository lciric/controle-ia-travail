"""Contre-lecture courte du brouillon 5 (tour fermé, étage 1) : contrôles mécaniques, lecture seule du dépôt.
Usage : python3 -I -B verifier_b5.py ORCHESTRATOR SCRATCH REGISTRE_GO"""
import hashlib
import os
import re
import subprocess
import sys
import tempfile

ORCH, SCRATCH, REG = sys.argv[1], sys.argv[2], sys.argv[3]
sys.path.insert(0, ORCH)
sys.dont_write_bytecode = True
import importlib.util  # noqa: E402

spec = importlib.util.spec_from_file_location("lanceur_v63_cl", os.path.join(ORCH, "demonstrations", "tour_ferme_v63.py"))
L = importlib.util.module_from_spec(spec)
spec.loader.exec_module(L)
from pole import configuration_v56 as cfg  # noqa: E402
from pole.outils import ecrire_scelle  # noqa: E402

B4 = os.path.join(ORCH, "prereg", "preenregistrement-tour-ferme-v1-brouillon4.md")
B5 = os.path.join(ORCH, "prereg", "preenregistrement-tour-ferme-v1-brouillon5.md")
t4, t5 = open(B4, encoding="utf-8").read(), open(B5, encoding="utf-8").read()
print("sha256 b4", hashlib.sha256(t4.encode()).hexdigest())
print("sha256 b5", hashlib.sha256(t5.encode()).hexdigest(), "lignes", t5.count("\n"))


def zones(t):
    out, pos = [], 0
    while True:
        i = t.find(L.DEBUT_ZONE_2, pos)
        if i < 0:
            return out
        j = t.find(L.FIN_ZONE_2, i)
        out.append(t[i:j + len(L.FIN_ZONE_2)])
        pos = j + len(L.FIN_ZONE_2)


z4, z5 = zones(t4), zones(t5)
print("zones b4", len(z4), "zones b5", len(z5), "identiques à l'octet :", z4 == z5)
for k, (a, b) in enumerate(zip(z4, z5), 1):
    print(f"  zone {k}: {len(a.encode())} octets, sha256 {hashlib.sha256(b.encode()).hexdigest()[:16]}, égale {a == b}")
print("ouvertures", t5.count(L.DEBUT_ZONE_2), "fermetures", t5.count(L.FIN_ZONE_2))
hz = L.texte_hors_etage_2(t5)
m_hors = L.MARQUEUR.findall(hz)
m_tout = L.MARQUEUR.findall(t5)
print("marqueurs hors zone :", sorted(set(m_hors)), "occurrences", len(m_hors))
print("marqueurs dans les zones :", sorted(set(m_tout) - set(m_hors)) if not set(m_hors) & (set(m_tout) - set(m_hors)) else "?",
      "occurrences totales", len(m_tout))
for go in ("GO-2026-11-02-19", "GO-2026-11-02-23", "GO-2026-11-02-18"):
    print(go, "occurrences b5 :", t5.count(go), "hors zone :", hz.count(go))
for mot in ("15 USD", "0,30 USD", "4 heures", "4 h", "0,5 USD"):
    lignes = [n for n, l in enumerate(t5.splitlines(), 1) if mot in l]
    print(f"« {mot} » lignes : {lignes}")
try:
    L.lire_plan(hz)
    print("ERREUR : plan à case vide accepté")
except Exception as x:  # noqa: BLE001
    print("plan tel quel (case vide) refusé par lire_plan :", type(x).__name__, str(x)[:90])
plan = L.lire_plan(hz.replace("<<CASE_CONFIGURATION_V3>>", "ab" * 32))
print("plan lu :", {k: plan[k] for k in ("plafond_etage_1_usd", "plafond_kimi_usd", "plafond_argon_usd", "duree_etage_1_h", "go",
                                         "generations_etage_1", "m_e_bh_etage_1", "cartes_par_proposeur", "cartes_reference")},
      plan["decisions"])
print("44 + 6 = 50 au centime :", round(plan["plafond_kimi_usd"] * 100) + round(plan["plafond_argon_usd"] * 100) == round(plan["plafond_etage_1_usd"] * 100))
# bloc d'empreintes
bloc = L._bloc(hz, L.DEBUT_EMPREINTES, L.FIN_EMPREINTES, "empreintes-du-code")
gelees = re.findall(r"^([0-9a-f]{64})  (\S+)$", bloc, re.M)
noms = [r for _, r in gelees]
print("bloc :", len(gelees), "lignes ; FICHIERS_GELES :", len(L.FICHIERS_GELES), "; même ordre :", tuple(noms) == L.FICHIERS_GELES,
      "; même ensemble :", sorted(noms) == sorted(L.FICHIERS_GELES))
ecarts_disque, ecarts_commit, ecarts_tete = [], [], []
for h, r in gelees:
    d = hashlib.sha256(open(os.path.join(ORCH, r), "rb").read()).hexdigest()
    if d != h:
        ecarts_disque.append(r)
    for ref, liste in (("a12713a", ecarts_commit), ("HEAD", ecarts_tete)):
        o = subprocess.run(["git", "-C", ORCH, "show", f"{ref}:orchestrator/{r}"], capture_output=True).stdout
        if hashlib.sha256(o).hexdigest() != h:
            liste.append(r)
print("écarts au disque :", ecarts_disque, "; à a12713a :", ecarts_commit, "; à HEAD :", ecarts_tete)
# af92034 : quels fichiers du bloc ont changé depuis le brouillon 4
chg = []
for h, r in gelees:
    o = subprocess.run(["git", "-C", ORCH, "show", f"af92034:orchestrator/{r}"], capture_output=True).stdout
    if hashlib.sha256(o).hexdigest() != h:
        chg.append(r)
print("fichiers du bloc différents de af92034 :", chg)
# bloc du brouillon 4 contre brouillon 5
g4 = dict((r, h) for h, r in re.findall(r"^([0-9a-f]{64})  (\S+)$", L._bloc(L.texte_hors_etage_2(t4), L.DEBUT_EMPREINTES, L.FIN_EMPREINTES, "e"), re.M))
print("lignes du bloc changées b4 → b5 :", sorted(r for h, r in gelees if g4.get(r) != h))
# garde 6 complète sur une copie scellée, case remplie d'une valeur d'essai
d = tempfile.mkdtemp(prefix="cl-b5-garde6-", dir=SCRATCH)
copie = os.path.join(d, "preenregistrement-tour-ferme-v1-v1.md")
ecrire_scelle(copie, t5.replace("<<CASE_CONFIGURATION_V3>>", "ab" * 32))
e, emp, gel, p = L.lire_preenregistrement(copie, dossier_prereg=d)
print("garde 6 complète (copie scellée, case d'essai) : acceptée ; E ≥ 2^64 :", e >= 2 ** 64, "; plafond", p["plafond_etage_1_usd"], "; go", p["go"])
try:
    L.lire_preenregistrement(os.path.join(d, "x"), dossier_prereg=d)
except Exception as x:  # noqa: BLE001
    print("  artefact chemin :", type(x).__name__)
copie2 = os.path.join(d, "preenregistrement-tour-ferme-v1-v2.md")
ecrire_scelle(copie2, t5)
try:
    L.lire_preenregistrement(copie2, dossier_prereg=d)
    print("  ERREUR : texte à case vide accepté")
except Exception as x:  # noqa: BLE001
    print("  texte à case vide (brouillon 5 tel quel, scellé) refusé :", type(x).__name__, str(x)[:120])
# registre de GO réel (lecture seule) : GO-2026-11-02-23
try:
    go = cfg.verifier_go_v56("GO-2026-11-02-23", REG, 50.0)
    print("GO-2026-11-02-23 au registre (50 USD) : accepté ;", {k: go[k] for k in go if k in ("identifiant", "type", "plafond_usd", "echeance", "accorde_par")} if isinstance(go, dict) else go)
except Exception as x:  # noqa: BLE001
    print("GO-2026-11-02-23 au registre (50 USD) : REFUSÉ :", type(x).__name__, x)
for montant in (49.0, 15.0):
    try:
        cfg.verifier_go_v56("GO-2026-11-02-23", REG, montant)
        print(f"  ERREUR : GO accepté à {montant}")
    except Exception as x:  # noqa: BLE001
        print(f"  GO-23 contre un plafond de {montant} : refusé ({type(x).__name__})")
try:
    cfg.verifier_go_v56("GO-2026-11-02-19", REG, 50.0)
    print("  ERREUR : GO-19 accepté à 50")
except Exception as x:  # noqa: BLE001
    print("  GO-19 contre 50 : refusé (", type(x).__name__, ")")
