"""Tableaux du rapport v8, lus dans les sorties des passages (aucun chiffre recopié à la main). Écrit `tableaux-v8.md` (tableaux en markdown, avec la source
de chaque tableau) et `tableaux-v8-sortie.json` (mêmes nombres, non arrondis).

Mesures (toutes à k = 8, τ = 0,01, δ = 0,05, α_c = 0,05, K_s = 10, lecture (A) m = 2, 2 000 répétitions) :
- seuil 40 : « fiche » = `ebh_A.retenues_fiches_du_sujet` (la fiche du mode 1 est retenue par l'e-BH de la famille de 2 fiches : lecture (A), m = 2) ;
- seuil 160 : « fiche » = `160.0.fiche_entiere.part` (le minimum des 16 processus, 8 gardes et 8 contrastes, du mode 1 atteint 160) ; la retenue e-BH
  à m = 8 (famille de 8 fiches) n'est pas simulée (M = 2) : l'atteinte du seuil est une borne basse de la retenue ;
- n80 : plus petite taille pour laquelle la mesure atteint 0,8 (dichotomie, `n_pour_puissance_0_8_fiche`), même graine.

Usage : python3 -I -B tableaux-v8.py DOSSIER_V8 SORTIE.md SORTIE.json
"""
import hashlib
import json
import math
import os
import re
import sys

DOSSIER, SORTIE_MD, SORTIE_JSON = sys.argv[1:4]
PREF = "simulation-puissance-garde-delta-v8-sortie-"
PASSAGES = ["rho0", "meme-rho0.05", "moitie-rho0.05", "meme-rho0.10", "moitie-rho0.10", "meme-rho0.17", "moitie-rho0.17",
            "A-seul-rho0.05", "A-seul-rho0.10", "A-seul-rho0.17"]
TAILLES = (288, 400, 500, 650)
BIAIS = (0.0, 0.0125)
S, EMP = {}, {}
for p in PASSAGES:
    chemin = os.path.join(DOSSIER, PREF + p + ".json")
    EMP[p] = hashlib.sha256(open(chemin, "rb").read()).hexdigest()
    S[p] = json.load(open(chemin, encoding="utf-8"))
    r = S[p]["reglages"]
    assert r["repetitions"] == 2000 and r["graine"] == 20261029 and S[p]["version"] == "simulation-puissance-garde-delta-v8"


def f2(x):
    return f"{x:.2f}".replace(".", ",")


def f3(x):
    return f"{x:.3f}".replace(".", ",")


def f4(x):
    return f"{x:.4f}".replace(".", ",")


def rho_de(p):
    r = S[p]["reglages"]
    return r["effet_unite_beta"], r["rho_comparateurs"]


def libelle(p):
    a, b = rho_de(p)
    if p == "rho0":
        return "ρ_A = 0, ρ_B = 0"
    return f"ρ_A = {f2(a)}, ρ_B = {f3(b).rstrip('0').rstrip(',') if b else '0'}"


def cle_cellule(p, K_h, n, b):
    for et in S[p]["cellules"]:
        m = re.search(r"Kh(\d+)_Ks(\d+)_", et)
        if int(m.group(1)) == K_h and f"|n={n}|" in et and f"biais={b}|" in et:
            assert int(m.group(2)) == 10
            return et
    raise KeyError((p, K_h, n, b))


def cell(p, K_h, n, b):
    return S[p]["cellules"][cle_cellule(p, K_h, n, b)]


def nom_loi(p, K_h):
    return next(nm for nm in S[p]["lois"] if f"Kh{K_h}_" in nm)


def n80(p, K_h, b, mesure):
    if "n_pour_puissance_0_8_fiche" not in S[p]["lois"][nom_loi(p, K_h)]:
        return None
    v = S[p]["lois"][nom_loi(p, K_h)]["n_pour_puissance_0_8_fiche"][f"delta=0.05|biais={b}|k=8"]["n80"][mesure]
    return v


def fiche40(c):
    return c["ebh_A"]["retenues_fiches_du_sujet"]


def fiche160(c):
    return c["160.0"]["fiche_entiere"]["part"]


def txt_n80(v):
    if v is None:
        return "—"
    if v["n_approx"] is None:
        return f"> {v['au_dela_de']}"
    return str(v["n_approx"])


PAIRES_PILOTE = [p for p in PASSAGES if not p.startswith("A-seul")]
res = {"empreintes_sorties_v8": EMP, "fiche": {}, "n80": {}, "gardes_contrastes_288": {}, "pilote": {}, "moments": {}, "artefacts": {}}
md = []

# --- T1a, T1b
for nom_t, seuil, mesure_n80, fn in (("T1a", "40", "retenue_ebh", fiche40), ("T1b", "160", "atteinte_160", fiche160)):
    titre = ("seuil 40 : fiche retenue par l'e-BH (lecture (A), m = 2)" if seuil == "40" else "seuil 160 : le minimum des 16 processus du mode 1 atteint 160")
    md.append(f"#### {nom_t}. Puissance de la fiche, {titre}, par taille (unités honnêtes = unités sabotées), K_s = 10, et n80\n")
    md.append(f"Source : sorties `{PREF}*.json` ({', '.join(PASSAGES)}) ; {'`ebh_A.retenues_fiches_du_sujet`' if seuil == '40' else '`160.0.fiche_entiere.part`'} ; "
              f"n80 : `n_pour_puissance_0_8_fiche.n80.{mesure_n80}` ; 2000 répétitions, erreur type ≤ 0,011\n")
    md.append("| dispersion | K_h | biais | " + " | ".join(f"{n} unités" for n in TAILLES) + " | n80 |")
    md.append("| --- | --- | --- | " + " | ".join("---" for _ in TAILLES) + " | --- |")
    for p in PASSAGES:
        for K_h in (10, 5):
            for b in BIAIS:
                vals = [fn(cell(p, K_h, n, b)) for n in TAILLES]
                v80 = n80(p, K_h, b, mesure_n80)
                md.append(f"| {libelle(p)}{' (A seul)' if p.startswith('A-seul') else ''} | {K_h} | {f4(b) if b else '0'} | " + " | ".join(f3(x) for x in vals)
                          + f" | {txt_n80(v80)} |")
                res["fiche"][f"{nom_t}|{p}|K_h={K_h}|biais={b}"] = dict(zip(map(str, TAILLES), vals))
                if v80 is not None:
                    res["n80"][f"{mesure_n80}|{p}|K_h={K_h}|biais={b}"] = v80
    md.append("")

# --- T3 gardes et contrastes à 288 unités
md.append("#### T3. Minimum des 8 gardes et des 8 contrastes à 288 unités (part des répétitions où le minimum des 8 atteint le seuil), K_s = 10\n")
md.append(f"Source : `k_gardes.part` et `k_contrastes.part` des blocs `40.0` et `160.0`, cellules à 288 unités ; 2000 répétitions\n")
md.append("| dispersion | K_h | biais | gardes, seuil 40 | gardes, seuil 160 | contrastes, seuil 40 | contrastes, seuil 160 |")
md.append("| --- | --- | --- | --- | --- | --- | --- |")
for p in PASSAGES:
    for K_h in (10, 5):
        for b in BIAIS:
            c = cell(p, K_h, 288, b)
            g40, g160, c40, c160 = c["40.0"]["k_gardes"]["part"], c["160.0"]["k_gardes"]["part"], c["40.0"]["k_contrastes"]["part"], c["160.0"]["k_contrastes"]["part"]
            md.append(f"| {libelle(p)}{' (A seul)' if p.startswith('A-seul') else ''} | {K_h} | {f4(b) if b else '0'} | {f3(g40)} | {f3(g160)} | {f3(c40)} | {f3(c160)} |")
            res["gardes_contrastes_288"][f"{p}|K_h={K_h}|biais={b}"] = {"garde40": g40, "garde160": g160, "contraste40": c40, "contraste160": c160}
md.append("")


# --- T4 : table de lecture du pilote
def pire(p_liste, K_h, mesure):
    """n80 le plus grand sur les biais et les dispersions de la liste (None si une valeur est au-delà de la borne)."""
    pires, details = 0, {}
    for p in p_liste:
        for b in BIAIS:
            v = n80(p, K_h, b, mesure)
            details[f"{p}|biais={b}"] = v
            if v["n_approx"] is None:
                return None, details
            pires = max(pires, v["n_approx"])
    return pires, details


GRILLE = [("0", ["rho0"]), ("0,05", ["meme-rho0.05", "moitie-rho0.05"]), ("0,10", ["meme-rho0.10", "moitie-rho0.10"]), ("0,17", ["meme-rho0.17", "moitie-rho0.17"])]
md.append("#### T4. Table de lecture pour le pilote : taille n_h à écrire au préenregistrement = max(288 ; n80), par ρ mesuré\n")
md.append("Source : T1a et T1b (n80 de la fiche), au pire des deux biais (0 ; δ/4) et des deux dispersions (« A et B à ρ » ; « A à ρ, B à ρ/2 ») ; "
          "K_s = 10 ; k = 8, τ = 0,01, δ = 0,05, α_c = 0,05 ; 2000 répétitions ; incertitude de graine : voir le rapport\n")
md.append("| ρ mesuré (grille) | seuil | K_h = 10 : n80 | K_h = 10 : n_h | K_h = 5 : n80 | K_h = 5 : n_h | n_h pour K_h = 10 ou 5 |")
md.append("| --- | --- | --- | --- | --- | --- | --- |")
cumul = {("40"): 0, ("160"): 0}
enveloppe_appliquee = []
for lib, plist in GRILLE:
    for seuil, mesure in (("40", "retenue_ebh"), ("160", "atteinte_160")):
        ligne = {}
        for K_h in (10, 5):
            v, det = pire(plist, K_h, mesure)
            ligne[K_h] = {"n80_pire": v, "details": det}
        pire_K = None if any(ligne[K]["n80_pire"] is None for K in (10, 5)) else max(ligne[10]["n80_pire"], ligne[5]["n80_pire"])
        # enveloppe croissante en ρ : une valeur ne descend jamais quand ρ monte
        brut = pire_K
        if brut is not None:
            if brut < cumul[seuil]:
                enveloppe_appliquee.append({"rho": lib, "seuil": seuil, "n80_brut": brut, "enveloppe": cumul[seuil]})
            cumul[seuil] = max(cumul[seuil], brut)
        res["pilote"][f"rho={lib}|seuil={seuil}"] = {"K_h=10": ligne[10], "K_h=5": ligne[5], "n80_pire_des_deux_K_h": pire_K,
                                                    "n_h": None if pire_K is None else max(288, cumul[seuil])}
        def nh(x):
            return "—" if x["n80_pire"] is None else str(max(288, x["n80_pire"]))
        md.append(f"| {lib} | {seuil} | {'—' if ligne[10]['n80_pire'] is None else ligne[10]['n80_pire']} | {nh(ligne[10])} | "
                  f"{'—' if ligne[5]['n80_pire'] is None else ligne[5]['n80_pire']} | {nh(ligne[5])} | "
                  f"{'—' if pire_K is None else max(288, cumul[seuil])} |")
res["pilote_enveloppe_croissante_appliquee"] = enveloppe_appliquee
md.append("")
md.append(f"Enveloppe croissante en ρ appliquée à la dernière colonne (une valeur ne descend pas quand ρ monte) : "
          f"{'aucune valeur corrigée' if not enveloppe_appliquee else json.dumps(enveloppe_appliquee, ensure_ascii=False)}.\n")

# --- T5 moments : variance observée des scores et ρ
md.append("#### T5. Variance inter-unités des scores observés et corrélation intra-unité ρ : attendu et tiré (288 unités, biais 0)\n")
md.append("Source : `moments_tires` des cellules à 288 unités ; attendu : Var(f̂) = p(1 − p)[1/K + ρ(1 − 1/K)] avec p = espérance du côté lu ; "
          "écart-type tiré de f̂ (A honnêtes) et de r̂ (A sabotés) sur toutes les unités et répétitions\n")
md.append("| dispersion | K_h | écart-type f̂_A attendu | tiré | écart-type r̂_A attendu | tiré | écart-type p_B honnêtes attendu | tiré | écart-type p_B sabotés attendu | tiré |")
md.append("| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |")
for p in PASSAGES:
    if p == "rho0":
        continue
    a, b = rho_de(p)
    for K_h in (10, 5):
        m = cell(p, K_h, 288, 0.0)["moments_tires"]
        att_f = math.sqrt(0.01 * 0.99 * (1 / K_h + a * (1 - 1 / K_h)))
        att_r = math.sqrt(0.5 * 0.5 * (1 / 10 + a * (1 - 1 / 10)))
        att_bf, att_br = math.sqrt(b * 0.01 * 0.99), math.sqrt(b * 0.4 * 0.6)
        tir = (m["ecart_type_fA"], m["ecart_type_rA"], m.get("ecart_type_pB_honnetes"), m.get("ecart_type_pB_sabotes"))
        res["moments"][f"{p}|K_h={K_h}"] = {"attendu": [att_f, att_r, att_bf, att_br], "tire": list(tir)}
        md.append(f"| {libelle(p)}{' (A seul)' if p.startswith('A-seul') else ''} | {K_h} | {f4(att_f)} | {f4(tir[0])} | {f4(att_r)} | {f4(tir[1])} | "
                  + (f"{f4(att_bf)} | {f4(tir[2])} | {f4(att_br)} | {f4(tir[3])} |" if b else "— | — | — | — |"))
md.append("")

# --- T6 artefacts de la garde (R5)
md.append("#### T6. Artefacts de la garde (R5), toutes cellules de tous les passages\n")
md.append("Source : blocs `40.0` et `160.0`, `frontiere_part`, `frontiere_borne_ville` (= 1/seuil), `tricheur_part`\n")
md.append("| passage | cellules | frontière, seuil 40 (max) | borne de Ville 1/40 | frontière, seuil 160 (max) | borne de Ville 1/160 | tricheur (max, deux seuils) |")
md.append("| --- | --- | --- | --- | --- | --- | --- |")
for p in PASSAGES:
    cs = list(S[p]["cellules"].values())
    f40, f160 = max(c["40.0"]["frontiere_part"] for c in cs), max(c["160.0"]["frontiere_part"] for c in cs)
    tr = max(max(c["40.0"]["tricheur_part"], c["160.0"]["tricheur_part"]) for c in cs)
    res["artefacts"][p] = {"cellules": len(cs), "frontiere40_max": f40, "frontiere160_max": f160, "tricheur_max": tr,
                           "frontiere40_sur_borne": f40 / (1 / 40), "frontiere160_sur_borne": f160 / (1 / 160)}
    md.append(f"| `{p}` | {len(cs)} | {f4(f40)} | {f4(1 / 40)} | {f4(f160)} | {f4(1 / 160)} | {f4(tr)} |")
md.append("")

# --- T7 durée, commit déclaré
md.append("#### T7. Passages : répétitions, durée, graine, commit déclaré, empreinte de la sortie\n")
md.append("Source : sorties et manifestes par passage\n")
md.append("| passage | répétitions | durée (s) | graine | commit déclaré | sortie |")
md.append("| --- | --- | --- | --- | --- | --- |")
for p in PASSAGES:
    man = json.load(open(os.path.join(DOSSIER, "manifeste-" + PREF + p + ".json"), encoding="utf-8"))
    assert man["script"]["commit"] == S[p]["commit"]
    md.append(f"| `{p}` | {S[p]['reglages']['repetitions']} | {man['duree_s']} | {man['graines']['graine_maitresse']} | « {man['script']['commit'][:60]}… » | `{EMP[p][:8]}…` |")
res["durees_s"] = {p: json.load(open(os.path.join(DOSSIER, "manifeste-" + PREF + p + ".json"), encoding="utf-8"))["duree_s"] for p in PASSAGES}
md.append("")
open(SORTIE_MD, "x", encoding="utf-8").write("\n".join(md) + "\n")
with open(SORTIE_JSON, "x", encoding="utf-8") as f:
    json.dump(res, f, indent=1, ensure_ascii=False)
    f.write("\n")
print("écrit", SORTIE_MD, SORTIE_JSON)
