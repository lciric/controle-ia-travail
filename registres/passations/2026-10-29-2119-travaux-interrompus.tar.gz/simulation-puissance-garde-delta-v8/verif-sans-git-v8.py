"""GD7-09 : le script v8 n'exécute aucun sous-processus ni aucune commande git ; le commit est celui que l'appelant déclare.

Trois contrôles, sans lancer aucune commande git (ni ici ni dans le script) :
1. analyse syntaxique (ast) du script : modules importés limités à la bibliothèque standard listée et à numpy ; aucun import de `subprocess`, `pty`,
   `socket`, `ctypes` ; aucun appel `os.system`, `os.popen`, `os.exec*`, `os.spawn*`, `os.posix_spawn*`, `os.fork*` ; aucune chaîne égale à « git » ;
2. garde (R5) : un piège remplace `subprocess.Popen`, `os.system`, `os.posix_spawn`, `os.fork`, `os.execv` par des fonctions qui comptent et lèvent une erreur ;
   cas sain : un passage complet du script (avec `--sortie`, journal, manifeste) s'exécute avec 0 appel au piège ; cas artefact : un appel direct
   `subprocess.run(["true"])` déclenche bien le piège (la garde voit ce qu'elle doit voir) ;
3. `--sortie` sans `--commit-declare` est refusé ; avec lui, le texte est recopié tel quel dans la sortie et le manifeste, avec « non lu ».

Usage : python3 -I -B verif-sans-git-v8.py SCRIPT_V8 DOSSIER_DE_TRAVAIL_NEUF SORTIE.json
"""
import ast
import hashlib
import importlib.util
import json
import os
import subprocess
import sys

CHEMIN, TRAVAIL, SORTIE = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2]), sys.argv[3]
if not sys.flags.dont_write_bytecode:
    raise SystemExit("lancer avec -B")
os.makedirs(TRAVAIL)
source = open(CHEMIN, encoding="utf-8").read()
arbre = ast.parse(source)
ADMIS = {"argparse", "csv", "hashlib", "json", "math", "os", "platform", "re", "shlex", "sys", "time", "datetime", "numpy"}
importes, appels, chaines_git = set(), [], []
for noeud in ast.walk(arbre):
    if isinstance(noeud, ast.Import):
        importes |= {a.name.split(".")[0] for a in noeud.names}
    elif isinstance(noeud, ast.ImportFrom):
        importes.add((noeud.module or "").split(".")[0])
    elif isinstance(noeud, ast.Call) and isinstance(noeud.func, ast.Attribute) and isinstance(noeud.func.value, ast.Name) and noeud.func.value.id == "os":
        if noeud.func.attr in ("system", "popen", "fork", "forkpty") or noeud.func.attr.startswith(("exec", "spawn", "posix_spawn")):
            appels.append((noeud.func.attr, noeud.lineno))
    elif isinstance(noeud, ast.Constant) and isinstance(noeud.value, str) and noeud.value.strip().lower() == "git":
        chaines_git.append(noeud.lineno)
controle1 = {"modules_importes": sorted(importes), "hors_liste": sorted(importes - ADMIS), "appels_os_de_sous_processus": appels,
             "chaines_egales_a_git": chaines_git,
             "conforme": not (importes - ADMIS) and not appels and not chaines_git and "subprocess" not in importes}

# 2. piège
appels_piege = []


def piege(nom):
    def f(*a, **k):
        appels_piege.append(nom)
        raise RuntimeError("sous-processus interdit : " + nom)
    return f


originaux = {(subprocess, "Popen"): subprocess.Popen, (os, "system"): os.system, (os, "posix_spawn"): os.posix_spawn,
             (os, "fork"): os.fork, (os, "execv"): os.execv}
for (mod, attr) in originaux:
    setattr(mod, attr, piege(f"{mod.__name__}.{attr}"))
try:
    spec = importlib.util.spec_from_file_location("v8", CHEMIN)
    v8 = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(v8)
    declare = "texte de commit déclaré (essai) 0123abcd"
    sortie_json = os.path.join(TRAVAIL, "passage.json")
    base = ["x", "--repetitions", "100", "--tailles", "20", "--deltas", "0.05", "--K", "3", "--taux", "0.01", "--biais", "0",
            "--comparateurs", "2", "--m", "2", "--sans-n80", "--lecture-ebh", "A"]
    sys.argv = base + ["--sortie", sortie_json, "--commit-declare", declare]
    sain_erreur = None
    try:
        v8.principal()
    except BaseException as e:  # noqa: BLE001
        sain_erreur = repr(e)
    appels_sain = list(appels_piege)
    # --sortie sans --commit-declare : refus
    sys.argv = base + ["--sortie", os.path.join(TRAVAIL, "autre.json")]
    refus = None
    try:
        v8.principal()
    except v8.Refus as e:
        refus = str(e)
    # artefact : le piège doit voir un appel direct
    artefact_vu = False
    try:
        subprocess.run(["true"])
    except RuntimeError:
        artefact_vu = True
finally:
    for (mod, attr), orig in originaux.items():
        setattr(mod, attr, orig)

sortie = json.load(open(sortie_json, encoding="utf-8"))
manifeste = json.load(open(os.path.join(TRAVAIL, "manifeste-passage.json"), encoding="utf-8"))
controle2 = {"erreur_du_passage_sain": sain_erreur, "appels_au_piege_pendant_le_passage_sain": appels_sain, "artefact_vu_par_le_piege": artefact_vu,
             "appels_au_piege_apres_artefact": list(appels_piege),
             "conforme": sain_erreur is None and not appels_sain and artefact_vu and appels_piege == ["subprocess.Popen"]}
controle3 = {"refus_sans_commit_declare": refus, "commit_de_la_sortie": sortie["commit"], "commit_du_manifeste": manifeste["script"]["commit"],
             "etat_de_la_sortie": sortie["etat_du_script"], "autre_fichier_ecrit": os.path.exists(os.path.join(TRAVAIL, "autre.json")),
             "conforme": (refus is not None and "commit-declare" in refus and sortie["commit"] == declare and manifeste["script"]["commit"] == declare
                          and sortie["etat_du_script"].startswith("non lu") and not os.path.exists(os.path.join(TRAVAIL, "autre.json")))}
bilan = {"script": CHEMIN, "script_sha256": hashlib.sha256(source.encode()).hexdigest(), "controle_1_analyse_syntaxique": controle1,
         "controle_2_piege_a_sous_processus": controle2, "controle_3_commit_declare": controle3,
         "conforme": controle1["conforme"] and controle2["conforme"] and controle3["conforme"]}
with open(SORTIE, "x", encoding="utf-8") as f:
    json.dump(bilan, f, indent=1, ensure_ascii=False)
    f.write("\n")
print("conforme" if bilan["conforme"] else "NON CONFORME", controle1["conforme"], controle2["conforme"], controle3["conforme"])
