#!/bin/sh
# Lance les passages de la v8 (R12 : aucune sortie existante n'est écrasée, le script refuse). Deux voies, une par processeur :
#   sh lancer-passages-v8.sh voie1     sh lancer-passages-v8.sh voie2
# À lancer depuis le dossier du script. Chaque passage écrit lui-même sa sortie, son journal et son manifeste (GD4-05).
# Durée maximale par passage : 1 500 s (25 minutes) ; au-delà, relancer avec --repetitions 1000 sous un autre nom et le dire.
# GD7-09 : aucune commande git, ni ici ni dans le script ; le commit est déclaré sur la ligne de commande (texte ci-dessous).
set -u
S=simulation-puissance-garde-delta-v8
PY="python3 -I -B $S.py"
LIM="timeout 1500"
COMMIT="non lu : aucune commande git permise à la lignée conv-audit pour cette tâche, dépôt non interrogé (GD7-09)"
# paramètres décidés et périmètre de la v8 : k = 8, τ = 0,01, δ = 0,05, lecture (A) m = 2 (seuil 40), seuil 160 en référence, α_c = 0,05,
# biais 0 et δ/4 = 0,0125, K_h ∈ {10, 5}, K_s = 10, tailles 288, 400, 500, 650, n80 de la fiche ; 2 000 répétitions
BASE="--repetitions 2000 --comparateurs 8 --K 10,5 --K-s 10 --taux 0.01 --deltas 0.05 --biais 0,0.0125 --tailles 288,400,500,650 --lecture-ebh A --m 8,2 --sans-n80 --commit-declare"
passage() {  # passage NOM OPTIONS...
  nom=$1; shift
  $LIM $PY $BASE "$COMMIT" "$@" --sortie $S-sortie-$nom.json
  echo "$nom : code $?"
}
COMB="--echelle-dispersion beta --combiner-dispersion-a-et-comparateurs"
case "$1" in
voie1)
  passage rho0 --n80-fiche
  passage meme-rho0.10 --n80-fiche $COMB --effet-unite-beta 0.10 --rho-comparateurs 0.10
  passage moitie-rho0.10 --n80-fiche $COMB --effet-unite-beta 0.10 --rho-comparateurs 0.05
  passage A-seul-rho0.05 --effet-unite-beta 0.05
  passage A-seul-rho0.10 --effet-unite-beta 0.10
  ;;
voie2)
  passage meme-rho0.05 --n80-fiche $COMB --effet-unite-beta 0.05 --rho-comparateurs 0.05
  passage moitie-rho0.05 --n80-fiche $COMB --effet-unite-beta 0.05 --rho-comparateurs 0.025
  passage meme-rho0.17 --n80-fiche $COMB --effet-unite-beta 0.17 --rho-comparateurs 0.17
  passage moitie-rho0.17 --n80-fiche $COMB --effet-unite-beta 0.17 --rho-comparateurs 0.085
  passage A-seul-rho0.17 --effet-unite-beta 0.17
  ;;
*) echo "usage : sh lancer-passages-v8.sh voie1|voie2"; exit 2;;
esac
