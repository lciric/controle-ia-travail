#!/bin/sh
# Compléments de la v8 (hors grille demandée), lancés après `lancer-passages-v8.sh` (R12 : aucune sortie existante n'est écrasée) :
#   voie3 : extension de la table de lecture à ρ = 0,25 et 0,35 (A et B à ρ, un passage par K_h pour tenir sous 25 minutes) ;
#   voie4 : incertitude de graine de n80 (graines 1, 2, 3 contre 20261029) sur deux lignes de la table (K_h = 5, biais δ/4, A et B à ρ = 0,05 et 0,17).
# À lancer depuis le dossier du script. GD7-09 : aucune commande git ; le commit est déclaré sur la ligne de commande.
set -u
S=simulation-puissance-garde-delta-v8
PY="python3 -I -B $S.py"
LIM="timeout 1500"
COMMIT="non lu : aucune commande git permise à la lignée conv-audit pour cette tâche, dépôt non interrogé (GD7-09)"
BASE="--repetitions 2000 --comparateurs 8 --K-s 10 --taux 0.01 --deltas 0.05 --lecture-ebh A --m 8,2 --sans-n80 --commit-declare"
COMB="--echelle-dispersion beta --combiner-dispersion-a-et-comparateurs"
passage() {  # passage NOM OPTIONS...
  nom=$1; shift
  $LIM $PY $BASE "$COMMIT" "$@" --sortie $S-sortie-$nom.json
  echo "$nom : code $?"
}
case "$1" in
voie3)
  for rho in 0.25 0.35; do
    for K in 10 5; do
      passage ext-meme-rho$rho-Kh$K --K $K --biais 0,0.0125 --tailles 288,400,500,650 --n80-fiche $COMB --effet-unite-beta $rho --rho-comparateurs $rho
    done
  done
  ;;
voie4)
  for g in 1 2 3; do
    passage graine-$g-meme-rho0.17-Kh5 --graine $g --K 5 --biais 0.0125 --tailles 288 --n80-fiche $COMB --effet-unite-beta 0.17 --rho-comparateurs 0.17
    passage graine-$g-meme-rho0.05-Kh5 --graine $g --K 5 --biais 0.0125 --tailles 288 --n80-fiche $COMB --effet-unite-beta 0.05 --rho-comparateurs 0.05
  done
  ;;
*) echo "usage : sh lancer-complements-v8.sh voie3|voie4"; exit 2;;
esac
