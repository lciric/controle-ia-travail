import importlib.util, json, sys, tempfile
sys_path_ok = __import__("sys").path.insert(0, "/home/user/controle-ia-travail/src")
from pathlib import Path
sys.dont_write_bytecode = True
def charge(nom, chemin):
    s = importlib.util.spec_from_file_location(nom, chemin); m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
R = Path(sys.argv[1])
a = charge("ca", R / "candidat-a/complements_p3_v1.py")
b = charge("cb", R / "candidat-b/complements_p3_v1.py")
# 1. valeur non finie dans la sortie
print("b _vers_json(nan) ->", b._vers_json({"x": float("nan")}))
try:
    a._propre({"x": float("nan")}); print("a _propre(nan) -> accepté")
except Exception as e:
    print("a _propre(nan) ->", type(e).__name__, e)
# 2. manifeste illisible dans la garde du second passage
with tempfile.TemporaryDirectory(dir=Path(sys.argv[2])) as d:
    (Path(d) / "runs" / "x").mkdir(parents=True)
    (Path(d) / "runs" / "x" / "manifeste.json").write_text("{illisible", encoding="utf-8")
    try:
        b.exiger_premier_passage(Path(d), "run"); print("b second passage, manifeste illisible -> sauté sans motif")
    except Exception as e:
        print("b ->", e)
    try:
        a.exiger_premier_passage(Path(d), "run", "lec"); print("a -> sauté")
    except Exception as e:
        print("a second passage, manifeste illisible ->", type(e).__name__)
    # 3. second passage, même run source, autre lecture
    (Path(d) / "runs" / "x" / "manifeste.json").write_text(json.dumps({"commande": a.COMMANDE, "config": {"objet": a.OBJET, "run_source": "run", "lecture": "lec1"}}), encoding="utf-8")
    try:
        a.exiger_premier_passage(Path(d), "run", "lec2"); print("a second passage, même run source, autre lecture -> accepté")
    except Exception as e:
        print("a ->", e)
    try:
        b.exiger_premier_passage(Path(d), "run"); print("b -> accepté")
    except Exception as e:
        print("b second passage, même run source ->", type(e).__name__)
# 4. nom de la réserve « non lue »
import inspect
print("a nom :", "reserve_{self.analyse}_non_lu\"" in inspect.getsource(a._Entree.juger) and "reserve_<A>_non_lu", "| b nom :", "_non_lue" in inspect.getsource(b._non_lue) and "reserve_<A>_non_lue")
