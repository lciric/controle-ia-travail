import sys, copy, json
sys.dont_write_bytecode = True
sys.path[:0] = ["/home/user/controle-ia-travail/src", "/home/user/controle-ia-travail/tests", sys.argv[1] + "/candidat-a"]
import complements_p3_v1 as A
import test_complements_p3_v1 as TA
from controle_ia.premier_test_ia import lecture as lp
from controle_ia.manifeste import graines
for m, k, v in ((A, "TIRAGES_AIRE", 50), (A, "TIRAGES_COUT", 200), (lp, "TIRAGES_AIRE", 50), (lp, "TIRAGES_COUT", 200)):
    setattr(m, k, v)
src = TA._completer(TA._source(0))
lec = json.loads(json.dumps(lp.lire(src, TA._graines())))
G = graines(A.cles_addendum(TA.P), A.ENTROPIE_P3)
# 1. clé « aire » absente d'un jeu de la lecture
x = copy.deepcopy(lec); del x["jeux"][TA.P[0]]["saboteur-temoin"]["aire"]
try:
    A.analyser_addendum(src, x, G); print("a : accepté")
except Exception as e:
    print("a, aire absente d'un jeu :", type(e).__name__, str(e)[:80])
# 2. booléen non booléen dans la lecture
x = copy.deepcopy(lec); x["intention"][TA.P[0]]["T2"]["etabli"] = "oui"
s = A.analyser_addendum(src, x, G)
print("a, T2 etabli = 'oui' : lu comme", s["conclusions_de_la_lecture"][f"T2 ({TA.P[0]})"], "(aucun arrêt)")
# 3. A8 : population
print("a, A8 actions comptées :", s["analyses"]["A8"][TA.P[0]]["descriptif"]["actions"], "sur", int(s["actions_notees"]), "notées")
