import sys, copy, json
sys.dont_write_bytecode = True
sys.path[:0] = ["/home/user/controle-ia-travail/src", "/home/user/controle-ia-travail/tests", sys.argv[1] + "/candidat-b"]
import complements_p3_v1 as B
import test_complements_p3_v1 as TB
from controle_ia.premier_test_ia import lecture as lp
from controle_ia.manifeste import graines
for m, k, v in ((B, "TIRAGES_AIRE", 50), (B, "TIRAGES_COUT", 200), (lp, "TIRAGES_AIRE", 50), (lp, "TIRAGES_COUT", 200)):
    setattr(m, k, v)
src = TB._complet(TB._source(0))
lec = json.loads(json.dumps(lp.lire(src, TB._graines())))
G = graines(B.cles_addendum(TB.P), B.ENTROPIE_P3)
for nom, modif in (("aire absente d'un jeu", lambda x: x["jeux"][TB.P[0]]["saboteur-temoin"].pop("aire")),
                   ("T2 etabli = 'oui'", lambda x: x["intention"][TB.P[0]]["T2"].__setitem__("etabli", "oui"))):
    x = copy.deepcopy(lec); modif(x)
    try:
        B.analyser_addendum(src, x, G); print("b :", nom, ": accepté")
    except Exception as e:
        print("b,", nom, ":", type(e).__name__, str(e)[:90])
s = B.analyser_addendum(src, lec, G)
pc = s["analyses"]["A8"][TB.P[0]]["descriptif"]["par_condition"]
print("b, A8 actions comptées :", sum(v["n"] for v in pc.values()))
print("b, qualification d'une conclusion établie sans réserve :", next(x["qualification"] for x in s["synthese"]["conclusions"] if x["etablie_par_la_lecture"]))
