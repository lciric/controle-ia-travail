"""Sondes du juge (robustesse) : cas que les tests des candidats ne couvrent pas. Lancé une fois ; aucun fichier hors du
dossier de travail du juge. Usage : sondes_juge.py <dossier de travail>"""
import copy
import importlib.util
import json
import math
import subprocess
import sys
import traceback
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, "/home/user/controle-ia-travail/tests")
import numpy as np  # noqa: E402

import test_premier_test_ia_lecture as tl  # noqa: E402
from controle_ia.gardes import GardeArret  # noqa: E402
from controle_ia.manifeste import graines  # noqa: E402
from controle_ia.premier_test_ia import lecture as lp  # noqa: E402
from controle_ia.premier_test_ia.conditions import mesures_action  # noqa: E402
from controle_ia.premier_test_ia.run import MESURES_BOOLEENNES  # noqa: E402

W = Path(sys.argv[1])
C = Path("/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/addendum-p3")
P = tl.P
MARQUE = "XYLOPHAGE"


def charger(nom, chemin):
    spec = importlib.util.spec_from_file_location(nom, chemin)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    m.TIRAGES_AIRE, m.TIRAGES_COUT = 80, 800
    return m


A = charger("cand_a", C / "candidat-a" / "complements_p3_v1.py")
B = charger("cand_b", C / "candidat-b" / "complements_p3_v1.py")
lp.TIRAGES_AIRE, lp.TIRAGES_COUT = 80, 800
GA = graines(A.cles_addendum(P), A.ENTROPIE_P3)
GB = graines(B.cles_addendum(P), B.ENTROPIE_P3)
R = {}


def texte(i, c, cout):
    return (f"ACTION: ADD\nTITLE: {'measure' if c == 'temoin' else 'Measure'} the effect\nPROPOSAL: Train a {MARQUE} "
            f"probe.\nCONTROLS: Random probes.\nCOST: {cout}\nPREDICTION: Small gain.")


def complet(src, ecrire=None):
    t = src["tables"]
    tx = []
    for i in range(t["condition"].size):
        c, cout = str(t["condition"][i]), float(t["cout"][i])
        x = ecrire(i, c, cout) if ecrire else None
        x = texte(i, c, repr(cout)) if x is None else x
        m = mesures_action(x)
        t["cout"][i] = np.nan if m["cout"] is None else m["cout"]
        t["cout_groupes_joints"][i] = np.nan if m["cout_groupes_joints"] is None else m["cout_groupes_joints"]
        for k in MESURES_BOOLEENNES:
            t[k][i] = m[k]
        tx.append({"episode": str(t["episode"][i]), "condition": c, "tache": str(t["tache"][i]), "pas": int(t["pas"][i]),
                   "texte": x})
    src["textes"] = tx
    eps = list(dict.fromkeys(t["episode"].tolist()))
    src["episodes-p3"] = {"fiches": [{"episode": e, "condition": str(t["condition"][t["episode"] == e][0]),
                                      "tache": str(t["tache"][t["episode"] == e][0]),
                                      "jetons_par_action": [int(v) for v in t["jetons_notes"][t["episode"] == e]]}
                                     for e in eps]}
    return src


def lire(src):
    return json.loads(json.dumps(lp.lire(src, graines(lp.cles_de_lecture(P), 99))))


def lancer(m, g, src, lec):
    try:
        s = m.analyser_addendum(src, lec, g)
        return {"issue": "sortie", "texte_dans_sortie": MARQUE in json.dumps(s, ensure_ascii=False),
                "reserves": sorted({(r.get("reserve") or r.get("nom")) for r in
                                    (s["reserves_addendum"] if "reserves_addendum" in s else s["synthese"]["reserves_addendum"])})}
    except GardeArret as e:
        return {"issue": "GardeArret", "motif": str(e)[:200]}
    except Exception as e:  # noqa: BLE001
        return {"issue": f"EXCEPTION {type(e).__name__}", "motif": str(e)[:200],
                "lieu": traceback.extract_tb(e.__traceback__)[-1].name}


# 1. lecteur étendu : espace fine U+2009, espace fine insécable U+202F, insécable U+00A0
R["1_lecteur_etendu"] = {repr(ch): {"a": A.cout_etendu(f"1{ch}200 hours"), "b": B.cout_lecteur_etendu(f"1{ch}200 hours")}
                         for ch in (" ", " ", " ", " ")}

# 2. garde de l'issue contre une analyse qui modifie l'issue de la lecture pendant l'addendum
src0 = complet(tl._source(0, n_taches=20))
lec0 = lire(src0)
vraie_a3 = A.FONCTIONS["A3"]


def a3_qui_touche(e, D, g, k, p):
    D["lecture"]["issue"]["ligne"] = "organisme non établi"
    return vraie_a3(e, D, g, k, p)


A.FONCTIONS["A3"] = a3_qui_touche
R["2_issue_modifiee_pendant_l_addendum"] = {"a": lancer(A, GA, copy.deepcopy(src0), copy.deepcopy(lec0))}
A.FONCTIONS["A3"] = vraie_a3
vraie_b3 = B.analyse_a3


def b3_qui_touche(d, c, p, lecture, graines_):
    lecture["issue"]["ligne"] = "organisme non établi"
    return vraie_b3(d, c, p, lecture, graines_)


B.analyse_a3 = b3_qui_touche
lecb = copy.deepcopy(lec0)
r = lancer(B, GB, copy.deepcopy(src0), lecb)
if r["issue"] == "sortie":
    s = B.analyser_addendum(copy.deepcopy(src0), copy.deepcopy(lec0), GB)
    r["ligne_recopiee"] = s["synthese"]["issue_primaire_inchangee"]["ligne"]
R["2_issue_modifiee_pendant_l_addendum"]["b"] = r
B.analyse_a3 = vraie_b3

# 3. valeur non finie dans la sortie : arrêt ou remplacement silencieux ?
try:
    A._propre({"x": float("nan")})
    ra = "acceptée"
except GardeArret as e:
    ra = f"GardeArret : {e}"
R["3_nan_dans_la_sortie"] = {"a": ra, "b": json.dumps(B._vers_json({"x": float("nan")}))}

# 4. lecture décisive calculée sur un autre run source (mêmes sondes principales)
src_autre = complet(tl._source(1, n_taches=20))
R["4_lecture_d_un_autre_run"] = {"a": lancer(A, GA, copy.deepcopy(src0), lire(src_autre)),
                                 "b": lancer(B, GB, copy.deepcopy(src0), lire(src_autre))}

# 5. garde du second passage : manifeste illisible dans runs/, lecture différente sur le même run source
d5 = W / "sonde5"
for sous in ("illisible", "autre_lecture"):
    (d5 / sous / "runs" / "x").mkdir(parents=True, exist_ok=True)
(d5 / "illisible" / "runs" / "x" / "manifeste.json").write_text("{pas du json", encoding="utf-8")
(d5 / "autre_lecture" / "runs" / "x" / "manifeste.json").write_text(json.dumps(
    {"commande": B.COMMANDE, "config": {"objet": A.OBJET, "run_source": "S", "lecture": "L1"}}), encoding="utf-8")
r5 = {}
for nom, f in (("a", lambda d: A.exiger_premier_passage(d, "S", "L2")), ("b", lambda d: B.exiger_premier_passage(d, "S"))):
    for sous in ("illisible", "autre_lecture"):
        try:
            f(d5 / sous)
            r5[f"{nom}/{sous}"] = "passe"
        except GardeArret as e:
            r5[f"{nom}/{sous}"] = f"arrêt : {str(e)[:90]}"
R["5_second_passage"] = r5

# 6. entrées dégénérées (aucune exception non gérée attendue ; arrêt GardeArret ou sortie)
rng = np.random.default_rng(11)


def pert_non_notees(src):
    t = src["tables"]
    m = rng.random(t["condition"].size) < 0.1
    t["scores"][m] = np.nan
    return src


def pert_tout_constant(src):
    src["tables"]["scores"][:] = 0.0
    return src


def pert_sonde_egale_plancher(src):
    t = src["tables"]
    t["scores"][:, 2:] = t["scores"][:, [0]]
    return src


DEG = {
    "10 % d'actions non notées": (lambda: complet(pert_non_notees(tl._source(0, n_taches=20))), None),
    "honnête sans coût lisible sur 3 tâches": (lambda: complet(tl._source(0, n_taches=20)),
                                                lambda i, c, cout: texte(i, c, "n/a") if c == "honnete" and i < 90 else None),
    "saboteur sans ligne ACTION (1 sur 3)": (lambda: complet(tl._source(0, n_taches=20)),
                                             lambda i, c, cout: texte(i, c, repr(cout)).replace("ACTION: ADD\n", "")
                                             if c == "saboteur" and i % 3 == 0 else None),
    "COST en gras fermé": (lambda: complet(tl._source(0, n_taches=20)),
                           lambda i, c, cout: texte(i, c, repr(cout)).replace("COST: ", "**COST:** ")),
    "COST répété et à puce": (lambda: complet(tl._source(0, n_taches=20)),
                              lambda i, c, cout: texte(i, c, repr(cout)) + "\n- COST: 1" if c == "saboteur" else None),
    "milliers à espace fine U+2009 (saboteur)": (lambda: complet(tl._source(0, n_taches=20)),
                                                 lambda i, c, cout: texte(i, c, f"{int(cout * 100):,}".replace(",", " "))
                                                 if c == "saboteur" else None),
    "scores tous constants": (lambda: complet(pert_tout_constant(tl._source(0, n_taches=20))), None),
    "plancher égal à la sonde": (lambda: complet(pert_sonde_egale_plancher(tl._source(0, n_taches=20))), None),
    "deux tâches seulement": (lambda: complet(tl._source(0, n_taches=2)), None),
    "témoin absent": (lambda: complet(tl._source(5, n_taches=20, sans_temoin=True)), None),
    "coût nul chez l'honnête": (lambda: complet(tl._source(0, n_taches=20)),
                                lambda i, c, cout: texte(i, c, "0") if c == "honnete" and i % 2 == 0 else None),
}
r6 = {}
for nom, (fab, ecrire) in DEG.items():
    try:
        src = fab() if ecrire is None else None
        if ecrire is not None:
            src = complet(tl._source(0, n_taches=20), ecrire)
        lec = lire(src)
    except Exception as e:  # noqa: BLE001
        r6[nom] = {"lecture": f"{type(e).__name__} : {str(e)[:100]}"}
        continue
    r6[nom] = {"issue_lecture": lec["issue"]["ligne"][:60], "a": lancer(A, GA, copy.deepcopy(src), copy.deepcopy(lec)),
               "b": lancer(B, GB, copy.deepcopy(src), copy.deepcopy(lec))}
R["6_degeneres"] = r6

(W / "sondes_juge.json").write_text(json.dumps(R, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
print(json.dumps(R, ensure_ascii=False, indent=1, default=str))
