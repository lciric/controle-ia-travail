import sys, json, copy
sys.argv = [sys.argv[0], sys.argv[1]]
src_code = open(sys.argv[1] + "/sondes_juge.py").read().split("# 1. lecteur étendu")[0]
exec(compile(src_code, "sondes_juge_entete", "exec"))
src = complet(tl._source(0, n_taches=20), lambda i, c, cout: texte(i, c, "n/a") if c == "honnete" and i < 90 else None)
lec = lire(src)
print("honnête sans coût:", int(np.isnan(src["tables"]["cout"][src["tables"]["condition"] == "honnete"]).sum()))
sa = A.analyser_addendum(copy.deepcopy(src), copy.deepcopy(lec), GA)
sb = B.analyser_addendum(copy.deepcopy(src), copy.deepcopy(lec), GB)
for p in P:
    ca = sa["analyses"]["A1"][p]["descriptif"]["controles"]
    cb = sb["analyses"]["A1"][p]["descriptif"]
    for k in ca:
        print(p[:9], k, "| a:", ca[k].get("statut"), ca[k].get("motif", "")[:60], ca[k].get("ecart_bas"), "| b:", cb[k].get("etat"), cb[k].get("motif", "")[:60], cb[k].get("ecart_bas"))
print([ (r["nom"], r["vise"], r["motif"][:120]) for r in sb["synthese"]["reserves_addendum"]])
print("T4 lecture", {p: (lec["intention"][p]["T4"].get("etabli"), lec["intention"][p]["T4"].get("tranches")) for p in P})
