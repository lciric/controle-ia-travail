"""Candidat a : un arrêt après la création du manifeste laisse-t-il un résultat écrit avec son motif ?"""
import sys
from pathlib import Path
sys.dont_write_bytecode = True
sys.path.insert(0, "/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/addendum-p3/candidat-a")
import test_complements_p3_v1 as T
from controle_ia.gardes import GardeArret
T.lp.TIRAGES_AIRE, T.lp.TIRAGES_COUT = 50, 500
A = T.A
src = T._completer(T._source(0, n_taches=12))
z = T._depot_jetable(Path(sys.argv[1]), src)
A.exiger_code_importe_sous = lambda racine: None
def en_arret(*a, **k):
    raise GardeArret("arrêt simulé après le manifeste")
A.analyser_addendum = en_arret
run = "20261020-140000-addendum-p3"
try:
    A.executer(z["depot"], z["run_source"], z["run_lecture"], run, z["prereg"], A.ENTROPIE_P3, autoriser_depot_sale=True)
except GardeArret as e:
    print("GardeArret :", e)
d = z["depot"]
print("manifeste écrit :", (d / "runs" / run / "manifeste.json").exists())
print("fichiers dans diag/<run> :", sorted(p.name for p in (d / "diag" / run).glob("*")) if (d / "diag" / run).exists() else "dossier absent")
