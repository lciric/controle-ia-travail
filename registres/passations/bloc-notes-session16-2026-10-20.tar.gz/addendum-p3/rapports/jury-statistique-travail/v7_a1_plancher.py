"""Scénario « plancher qui varie avec les tâches » (candidat B) : bornes de A1 dans A et dans B, et au nombre réel de
tirages (2 000) pour juger si l'écart vient du générateur."""
import copy, importlib.util, sys
from commun import A, B, BASE
from donnees import G, reduire, P
sys.modules["complements_p3_v1"] = B
spec = importlib.util.spec_from_file_location("tests_b", BASE + "/candidat-b/test_complements_p3_v1.py")
TB = importlib.util.module_from_spec(spec); sys.modules["tests_b"] = TB; spec.loader.exec_module(TB)
import numpy as np
for n in (200, 2000):
    reduire(n_aire=n)
    src = TB.SCENARIOS["a1_plancher"](); lec = TB._lecture(src)
    print("tirages", n, "| lecture : P3-P4 conforme", lec["P3-P4"][P[0]]["conforme"], "T3", lec["intention"][P[0]]["T3"]["etabli"])
    d = A._preparer(src, lec); c = A.conclusions_de_la_lecture(lec, P)
    ea = A._executer("A1", d, c, G, 0, P[0])["descriptif"]["controles"]
    cb = B.conclusions_de_la_lecture(lec, P); db = B._donnees(src)
    eb = B.analyse_a1(db, cb, P[0], G)["descriptif"]
    for jeu in ("saboteur-honnete", "saboteur-temoin", "temoin-honnete", "saboteur-mention", "mention-honnete"):
        print(f"  {jeu:17s} Δ_obs {ea[jeu]['ecart_observe']:+.4f} | Δ_bas A {ea[jeu]['ecart_bas']:+.4f} B {eb[jeu]['ecart_bas']:+.4f}")
