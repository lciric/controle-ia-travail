"""Calcul à la main du plancher conjoint sur un petit exemple (trois tâches, deux sondes de plancher, quatre tirages
imposés), comparé aux fonctions des trois candidats."""
import numpy as np
from commun import A, B, GE

class TiragesImposes:
    """Générateur factice : rend les choix de tâches donnés, dans l'ordre."""
    def __init__(self, choix):
        self.choix = [np.array(c) for c in choix]; self.k = 0
    def integers(self, lo, hi, size=None):
        c = self.choix[self.k]; self.k += 1
        assert len(c) == size and c.max() < hi
        return c

s = np.array([0.9, 0.2, 0.6, 0.6, 0.3, 0.5])
P = np.array([[0.1, 0.5], [0.3, 0.5], [0.8, 0.2], [0.4, 0.9], [0.7, 0.6], [0.6, 0.1]])
y = np.array([1, 0, 1, 0, 1, 0])
t = np.array(["t0", "t0", "t1", "t1", "t2", "t2"])
choix = [[0, 0, 2], [1, 1, 1], [2, 1, 0], [0, 0, 0]]
attendu = {"aire": 6.5 / 9, "Q": 0.5 + 0.95 * (6 / 9 - 0.5), "deltas": [8 / 9 - (3 / 9 + 0.95 * (7 / 9 - 3 / 9)),
                                                                       0.5 - 0.95, 6.5 / 9 - (0.5 + 0.95 * (6 / 9 - 0.5)),
                                                                       1.0 - 0.95 * 0.5]}
d = np.array(attendu["deltas"])
bas, haut = np.quantile(d, 0.25), np.quantile(d, 0.75)
print("à la main : aire", round(attendu["aire"], 6), "Q", round(attendu["Q"], 6), "Δ(b)", np.round(d, 6),
      "bas", round(bas, 6), "haut", round(haut, 6))

ra = A.plancher_conjoint(s, P, y, t, TiragesImposes(choix), 4, 0.5)
B.MIN_PAR_COTE = 1
rb = B.ecart_conjoint(s, P, y, t, TiragesImposes(choix), 4, 0.5)

class Rng2(TiragesImposes):
    pass
import numpy.random as npr
orig = npr.default_rng
GE.np.random.default_rng = lambda g: TiragesImposes(choix)
rg = GE.plancher_conjoint(s, P, y, t, 4, 0, 0.5)
GE.np.random.default_rng = orig
for nom, r, kb, kh in (("A", ra, "ecart_bas", "ecart_haut"), ("B", rb, "ecart_bas", "ecart_haut"), ("Gemini", rg, "bas", "haut")):
    print(f"{nom:7s} aire {r['aire']:.6f} Q {r['plancher_quantile']:.6f} bas {r[kb]:.6f} haut {r[kh]:.6f} "
          f"écart à la main {max(abs(r[kb]-bas), abs(r[kh]-haut), abs(r['aire']-attendu['aire'])):.1e}")
# lecture gelée (plancher figé) : borne basse de l'aire seule contre Q observé
aires = [8/9, 0.5, 6.5/9, 1.0]
print("plancher figé : borne basse de A", round(np.quantile(aires, 0.25), 6), "> Q_obs", round(attendu["Q"], 6),
      "=> « au-dessus » ; plancher conjoint : Δ_bas", round(bas, 6), "≤ 0 => réserve A1")
