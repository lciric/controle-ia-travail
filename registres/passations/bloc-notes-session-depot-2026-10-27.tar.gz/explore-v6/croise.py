"""Exploration jetable : signatures croisées négatives avec le générateur des tests v6 (fabriquer), analyse v6."""
import importlib.util, json, pathlib, sys, tempfile
ARBRE = pathlib.Path("/tmp/claude-0/-home-user/1cc16375-a2bd-54b9-a03f-27d43b6f26a6/scratchpad/wt-echelle-v1/echelle-v6")
spec = importlib.util.spec_from_file_location("t", ARBRE / "tests" / "test_analyser_echelle_v6.py")
T = importlib.util.module_from_spec(spec); spec.loader.exec_module(T)
AN = T.AN
AN.N_BOOT = 300
AN.ATTENDUS = T.PETITS
AN.etat_scripts = lambda: (T.COMMIT_ESSAI, True)
STIM = pathlib.Path(sys.argv[1])
ordre, g0, n, tau = sys.argv[2], int(sys.argv[3]), int(sys.argv[4]), float(sys.argv[5])
for g in range(g0, g0 + 2 * n, 2):
    with tempfile.TemporaryDirectory(dir="/tmp/claude-0/-home-user/1cc16375-a2bd-54b9-a03f-27d43b6f26a6/scratchpad/explore-v6") as tmp:
        tmp = pathlib.Path(tmp)
        op, og = ({"signature": -2.0}, {"signature_b": -2.0}) if ordre == "8a70b" else ({"signature_b": -2.0}, {"signature": -2.0})
        p = T.fabriquer(tmp / "p", STIM, 0.0, g, tau=tau, **op)
        gr = T.fabriquer(tmp / "g", STIM, 0.0, g + 1, nom="grand", tau=tau, **og)
        code = AN.principal([str(STIM), str(p), str(gr), "12345", str(tmp / "s"), "--repetition"])
        r = json.loads((tmp / "s" / "analyse-echelle-v6.json").read_text())
        print(ordre, g, r["lecture"], r["issues_tenues_par_sens"], r["reserves"], flush=True)
