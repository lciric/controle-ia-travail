"""Tableau de la simulation v6 pour le brouillon v7, tiré de la sortie scellée (aucune transcription à la main)."""
import collections
import json
import re
import sys

sim = json.load(open(sys.argv[1], encoding="utf-8"))
AFFICHAGE = [  # (nom dans la simulation, nom affiché)
    ("H0 (0,5 et 0,5)", "H_0 (0,5 et 0,5)"),
    ("pas de fuite (0 et 0)", "pas de fuite (0 et 0)"),
    ("H1 (1,0 et 0,2)", "H_A (1,0 et 0,2)"),
    ("H1 faible (0,6 et 0,2)", "H_A faible (0,6 et 0,2)"),
    ("inverse (0,2 et 1,0)", "inverse (0,2 et 1,0)"),
    ("signe inverse (−0,6 et 0)", "signe inverse (−0,6 et 0)"),
    ("signature du jeu a au petit (0 et 0)", "signature du jeu a au 8B (+2), α = 0 (CLY-01)"),
    ("contexte faible aux deux", "contexte faible aux deux tailles"),
    ("contexte faible au petit", "contexte faible au 8B"),
    ("signature négative du jeu a au petit (0 et 0)", "signature du jeu a au 8B, négative (−2), α = 0 (CLZ-01)"),
    ("signature du jeu a au grand (0 et 0)", "signature du jeu a au 70B (+2), α = 0"),
    ("signature du jeu b au petit (0 et 0)", "signature du jeu b au 8B (+2), α = 0"),
    ("signatures des deux jeux au petit (0 et 0)", "signatures des deux jeux au 8B (+2 et +2), α = 0 (CLZ-08)"),
    ("H1 masqué par une signature négative du jeu a (1,0 et 0,2)",
     "H_A masqué par une signature négative du jeu a (1,0 et 0,2 ; −3)"),
    ("fuite masquée par une signature négative du jeu a (0,6 et 0)",
     "fuite masquée par une signature négative du jeu a (0,6 et 0 ; −1,4)"),
    ("contexte faible au grand", "contexte faible au 70B"),
    ("fuite faible égale (0,2 et 0,2)", "fuite faible et égale (0,2 et 0,2) (CLW-01)"),
    ("fuite faible égale, contexte du jeu b plus faible (0,15 et 0,15 ; × 0,6)",
     "fuite faible et égale, contexte du jeu b plus faible (0,15 et 0,15 ; jeu b × 0,6) (CLW-01)"),
    ("signature négative du jeu a au grand (0 et 0)", "signature du jeu a au 70B, négative (−2), α = 0 (CLW-09)"),
    ("signatures des deux jeux, négatives, au petit (0 et 0)",
     "signatures des deux jeux au 8B, négatives (−2 et −2), α = 0 (CLW-02)"),
    ("signatures des deux jeux au grand (0 et 0)", "signatures des deux jeux au 70B (+2 et +2), α = 0 (CLW-02)"),
    ("signatures croisées négatives, jeu a au petit, jeu b au grand (0 et 0)",
     "**signatures croisées négatives : jeu a au 8B, jeu b au 70B (−2 et −2), α = 0** (CLV-01)"),
    ("signatures croisées négatives, jeu b au petit, jeu a au grand (0 et 0)",
     "**signatures croisées négatives : jeu b au 8B, jeu a au 70B (−2 et −2), α = 0** (CLV-01)"),
    ("signatures croisées positives, jeu a au petit, jeu b au grand (0 et 0)",
     "**signatures croisées positives : jeu a au 8B, jeu b au 70B (+2 et +2), α = 0** (CLV-01)"),
    ("signatures croisées positives, jeu b au petit, jeu a au grand (0 et 0)",
     "**signatures croisées positives : jeu b au 8B, jeu a au 70B (+2 et +2), α = 0** (CLV-01)"),
    ("signature négative du jeu b au petit (0 et 0)", "**signature du jeu b au 8B, négative (−2), α = 0** (CLV-04)"),
    ("signature du jeu b au grand (0 et 0)", "**signature du jeu b au 70B (+2), α = 0** (CLV-04)"),
    ("signature négative du jeu b au grand (0 et 0)", "**signature du jeu b au 70B, négative (−2), α = 0** (CLV-04)"),
    ("H1 sous les signatures négatives des deux jeux au petit (1,0 et 0,2)",
     "**H_A sous les signatures des deux jeux au 8B, négatives (1,0 et 0,2 ; −2 et −2)** (CLV-04)"),
    ("H1 sous des signatures croisées de signes opposés (1,0 et 0,2 ; a négatif au petit, b positif au grand)",
     "**H_A sous des signatures croisées de signes opposés (1,0 et 0,2 ; jeu a −2 au 8B, jeu b +2 au 70B)** (CLV-04)"),
]
noms = {nom for nom, _ in AFFICHAGE}
cases = {}
for e in sim["detail"]:
    nom, tau = e["cas"].rsplit(" ; tau ", 1)
    assert nom in noms, nom
    lu = e["lecture"]
    m = re.match(r"(.*) \((\d+) réserve\(s\)\)$", lu)
    base, res = (m.group(1), int(m.group(2))) if m else (lu, 0)
    base = base.replace("(sens a→b)", "(a→b)").replace("(sens b→a)", "(b→a)")
    c = cases.setdefault((nom, tau), collections.OrderedDict())
    n, r = c.get(base, (0, 0))
    c[base] = (n + 1, r + (1 if res else 0))
assert sum(sum(n for n, _ in c.values()) for c in cases.values()) == len(sim["detail"])
print("| vérité (α au 8B et au 70B) | tau 0,15 | tau 0,4 | tau 0,8 |")
print("|---|---|---|---|")
for nom, aff in AFFICHAGE:
    cellules = []
    for tau in ("0.15", "0.4", "0.8"):
        c = cases.get((nom, tau))
        if not c:
            cellules.append("—")
            continue
        items = sorted(c.items(), key=lambda kv: -kv[1][0])
        cellules.append(", ".join(f"{b} {n}" + (f" ({r})" if r else "") for b, (n, r) in items))
    print(f"| {aff} | " + " | ".join(cellules) + " |")
print(f"\n{len(sim['detail'])} analyses ; {len(cases)} cases")
