| vérité (α au 8B et au 70B) | tau 0,15 | tau 0,4 | tau 0,8 |
|---|---|---|---|
| H_0 (0,5 et 0,5) | nul 4 | nul 4 | indécis 3, nul non confirmé (a→b) 1 |
| pas de fuite (0 et 0) | pas de fuite 4 | pas de fuite 4 | pas de fuite 3, pas de fuite non confirmé (b→a) 1 |
| H_A (1,0 et 0,2) | positif 4 | positif 4 | positif 3, positif non confirmé (b→a) 1 |
| H_A faible (0,6 et 0,2) | positif 4 | positif non confirmé (a→b) 2, positif 2 | indécis 2, positif non confirmé (a→b) 2 |
| inverse (0,2 et 1,0) | — | inverse 4 | — |
| signe inverse (−0,6 et 0) | — | fuite de signe inverse (petit) 4 | — |
| signature du jeu a au 8B (+2), α = 0 (CLY-01) | — | positif non confirmé (b→a) 4 | — |
| contexte faible aux deux tailles | — | non certifiable 4 | — |
| contexte faible au 8B | — | certification asymétrique (grand seulement) 4 | — |
| signature du jeu a au 8B, négative (−2), α = 0 (CLZ-01) | — | fuite de signe inverse (petit) non confirmé (b→a) 2, fuite de signe inverse (petit) 1, positif non confirmé (a→b) 1 | — |
| signature du jeu a au 70B (+2), α = 0 | — | désaccord des deux sens 3, inverse non confirmé (b→a) 1 | — |
| signature du jeu b au 8B (+2), α = 0 | — | positif non confirmé (a→b) 4 | — |
| signatures des deux jeux au 8B (+2 et +2), α = 0 (CLZ-08) | — | positif 3 (2), indécis 1 | — |
| H_A masqué par une signature négative du jeu a (1,0 et 0,2 ; −3) | positif 2 (1), désaccord des deux sens 1, positif non confirmé (a→b) 1 | positif non confirmé (a→b) 2, désaccord des deux sens 1, fuite de signe inverse (petit) non confirmé (b→a) 1 | — |
| fuite masquée par une signature négative du jeu a (0,6 et 0 ; −1,4) | positif 3, positif non confirmé (a→b) 1 | — | — |
| contexte faible au 70B | — | certification asymétrique (petit seulement) 4 | — |
| fuite faible et égale (0,2 et 0,2) (CLW-01) | nul 4 (1) | — | — |
| fuite faible et égale, contexte du jeu b plus faible (0,15 et 0,15 ; jeu b × 0,6) (CLW-01) | nul 4 (2) | — | — |
| signature du jeu a au 70B, négative (−2), α = 0 (CLW-09) | — | fuite de signe inverse (grand) non confirmé (b→a) 4 | — |
| signatures des deux jeux au 8B, négatives (−2 et −2), α = 0 (CLW-02) | — | fuite de signe inverse (petit) 2 (2), fuite de signe inverse (petit) non confirmé (b→a) 1, indécis 1 | — |
| signatures des deux jeux au 70B (+2 et +2), α = 0 (CLW-02) | — | inverse 4 | — |
| **signatures croisées négatives : jeu a au 8B, jeu b au 70B (−2 et −2), α = 0** (CLV-01) | désaccord des deux sens 2, indécis 2 | désaccord des deux sens 4 | — |
| **signatures croisées négatives : jeu b au 8B, jeu a au 70B (−2 et −2), α = 0** (CLV-01) | indécis 3, désaccord des deux sens 1 | désaccord des deux sens 4 | — |
| **signatures croisées positives : jeu a au 8B, jeu b au 70B (+2 et +2), α = 0** (CLV-01) | — | inverse non confirmé (a→b) 1, indécis 1, fuite de signe inverse (petit) non confirmé (a→b) 1, désaccord des deux sens 1 | — |
| **signatures croisées positives : jeu b au 8B, jeu a au 70B (+2 et +2), α = 0** (CLV-01) | — | indécis 2, fuite de signe inverse (petit) non confirmé (b→a) 1, inverse non confirmé (b→a) 1 | — |
| **signature du jeu b au 8B, négative (−2), α = 0** (CLV-04) | — | fuite de signe inverse (petit) non confirmé (a→b) 2, positif non confirmé (b→a) 1, désaccord des deux sens 1 | — |
| **signature du jeu b au 70B (+2), α = 0** (CLV-04) | — | inverse non confirmé (a→b) 3, désaccord des deux sens 1 | — |
| **signature du jeu b au 70B, négative (−2), α = 0** (CLV-04) | — | désaccord des deux sens 2, fuite de signe inverse (grand) non confirmé (a→b) 2 | — |
| **H_A sous les signatures des deux jeux au 8B, négatives (1,0 et 0,2 ; −2 et −2)** (CLV-04) | — | indécis 3, fuite de signe inverse (petit) non confirmé (a→b) 1 | — |
| **H_A sous des signatures croisées de signes opposés (1,0 et 0,2 ; jeu a −2 au 8B, jeu b +2 au 70B)** (CLV-04) | — | inverse non confirmé (a→b) 2, indécis 2 | — |

164 analyses ; 41 cases
