Limites de la lecture :

- une famille, deux tailles, une manipulation de contexte (« l'auteur connaît la réponse ») ;
- aucune généralisation ;
- ĉ mêle une intention déclarée et une polarité possession/absence (CLX-16) ;
- des asymétries de mots courts subsistent entre eval et reel, comptées dans la trace lexicale (CLY-12) ;
- **une poussée du format alignée à la fois sur les signatures des deux jeux de cadrages, chez un même modèle, passe les deux sens, et fabrique « positif », « inverse » ou une fuite de signe inverse selon son signe et la taille qu'elle touche** (CLZ-08, CLW-02, CLV-04) :
  - avec deux jeux de cadrages seulement, elle ne se distingue pas d'une fuite du concept, puisque le concept est estimé par ce qui est commun aux deux jeux ; un troisième jeu tenu à part le permettrait ;
  - la réserve « fuite non spécifique » ne la signale qu'en partie : «LIMITE_DOUBLE_CHIFFRES» ;
  - il faut, pour qu'elle joue, que le format pousse ensemble deux particularités indépendantes, chez le même modèle ;
  - toute issue prononcée se lit donc sous cette limite ;
- **sous H_A, les signatures peuvent faire perdre l'écart vrai** (perte de puissance, CLV-04) : «LIMITE_PUISSANCE» ;
- **les signatures d'un seul jeu à deux tailles différentes** (« croisées ») ne déplacent chacune qu'un sens, chez un modèle différent ; la règle du même modèle les écarte (CLV-01) : «LIMITE_CROISEES» ;
- rien ne relie ici ĉ à une conscience d'évaluation implicite ;
- une sonde linéaire qui lit un texte mesure la représentation du lecteur (R-525).
