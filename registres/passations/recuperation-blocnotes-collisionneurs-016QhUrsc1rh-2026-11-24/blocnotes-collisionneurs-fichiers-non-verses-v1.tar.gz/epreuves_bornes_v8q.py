"""Épreuves du contre-lecteur, sans réseau, à lancer sous `env -i` avec des valeurs FACTICES seulement.

(a) --nom-espace-anthropic peut-il nommer une variable de Google, dont la valeur partirait vers Anthropic ?
(b) --cle-gemini donnée au v8m (ou au v8p) : quel code rend l'analyse des arguments ?
"""
import importlib.util
import os
import sys
import urllib.request
from pathlib import Path

RACINE = Path("/home/user/controle-ia-travail")
assert "GEMINI_API_KEY" not in os.environ and "GEMINI_API_KEY_2" in os.environ, "lancer sous env -i, valeurs factices"
assert os.environ["GEMINI_API_KEY_2"] == "valeur-google-factice"


def interdit(*a, **k):
    raise ConnectionRefusedError("réseau coupé par le contre-lecteur")


urllib.request.urlopen = interdit
urllib.request.OpenerDirector.open = interdit


def charger(nom):
    spec = importlib.util.spec_from_file_location(f"m_{nom}", RACINE / f"docs/notes/collisionneur-v9/collisionneur_v9_{nom}.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


class Capture(Exception):
    pass


v8q = charger("v8q")
captures = []


def transport(requete, delai, locale=False):
    captures.append((urllib.parse.urlsplit(requete.full_url).hostname, dict(requete.header_items())))
    raise Capture()


v8q.TRANSPORT = v8q.TRANSPORT_COMPTE = transport
try:
    v8q.fixer_composition(["fable", "argon"], nom_cle_anthropic="ANTHROPIC_FACTICE",
                          nom_espace_anthropic="GEMINI_API_KEY_2", nom_cle_gemini="GEMINI_API_KEY_2")
    print("(a) composition acceptée avec --nom-espace-anthropic GEMINI_API_KEY_2")
    try:
        v8q.appeler_anthropic(v8q.MODELES["A"], "bonjour", 100)
    except Capture:
        pass
    hote, entetes = captures[-1]
    entetes = {k.lower(): v for k, v in entetes.items()}
    print(f"(a) requête vers {hote} ; en-tête anthropic-workspace-id = valeur de Google factice : "
          f"{entetes.get('anthropic-workspace-id') == 'valeur-google-factice'}")
except v8q.Arret as e:
    print(f"(a) refusé : code {e.code} : {e}")

for nom in ("v8m",):
    mod = charger(nom)
    try:
        mod.principal(["etage3", "--argon", "--carbon", "--sortie", "/nonexistent/aucun", "--cle-gemini",
                       "GEMINI_API_KEY_2"])
        print(f"(b) {nom} : aucune erreur d'analyse")
    except SystemExit as e:
        print(f"(b) {nom} : SystemExit code {e.code} (analyse des arguments, avant tout lancement)")
