#!/bin/bash
q=$(python3 -c 'import sys,urllib.parse;print(urllib.parse.quote(sys.argv[1]))' "$1[ti]")
ids=$(curl -s "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pmc&term=$q&retmode=json" | jq -r '.esearchresult.idlist[]' | head -2)
for id in $ids; do sleep 0.4; curl -s "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pmc&id=$id" -o y.xml; echo "  $id $(stat -c %s y.xml) refus=$(grep -c 'does not allow' y.xml) $(grep -o '<article-title>[^<]*' y.xml | head -1 | cut -c15-90)"; done
