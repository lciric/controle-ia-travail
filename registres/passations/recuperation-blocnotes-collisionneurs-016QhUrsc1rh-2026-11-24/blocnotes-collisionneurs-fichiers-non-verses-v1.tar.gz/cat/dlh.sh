#!/bin/bash
# usage: dlh.sh fichier.html url motcle
D=/home/user/controle-ia-travail/docs/notes/conscience-emergence-v1/revue-experiences/sources
cd $D
curl -s -L -A "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36" --max-time 90 -o "$1" "$2"
h=$(date -u +%H:%M:%SZ)
if [ $(grep -ci "$3" "$1") -gt 0 ] && [ $(stat -c %s "$1") -gt 30000 ]; then
 sha256sum "$1" > "$1.sha256"; echo "OK|$1|$(cut -d' ' -f1 $1.sha256)|$2|$h|html"; echo "OK|$1|$(cut -d' ' -f1 $1.sha256)|$2|$h|html" >> /tmp/claude-0/-home-user-controle-ia-travail/12f6e278-4ba7-598c-9d00-941c25a1615c/scratchpad/cat/journal.txt
else echo "ECHEC|$1|$2"; rm -f "$1"; fi
