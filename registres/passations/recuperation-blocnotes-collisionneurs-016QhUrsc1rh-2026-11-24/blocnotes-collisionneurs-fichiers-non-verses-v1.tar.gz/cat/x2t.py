import sys,re,html
for f in sys.argv[1:]:
    t=open(f,encoding='utf-8',errors='replace').read()
    t=re.sub(r'(?s)<script.*?</script>|<style.*?</style>','',t)
    t=re.sub(r'</(p|title|sec|h[1-6]|div|li|tr)>','\n',t)
    t=re.sub(r'<[^>]+>',' ',t); t=html.unescape(t); t=re.sub(r'[ \t]+',' ',t)
    out=sys.argv[0].rsplit('/',1)[0]+'/txt/'+f.rsplit('/',1)[1].rsplit('.',1)[0]+'.txt'
    open(out,'w').write(t)
