#!/bin/bash
# usage: epmc.sh "query"
q=$(python3 -c 'import sys,urllib.parse;print(urllib.parse.quote(sys.argv[1]))' "$1")
curl -s "https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=$q&format=json&pageSize=${2:-4}&resultType=lite" | jq -r '.resultList.result[] | [.pmcid, .isOpenAccess, .pubYear, .journalTitle, .doi, .title] | @tsv'
