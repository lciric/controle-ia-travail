#!/bin/bash
for d in "$@"; do echo "$d $(curl -s "https://api.unpaywall.org/v2/$d?email=contact@example.org" | jq -r '[.oa_status, (.oa_locations|map(.url_for_pdf // .url)|join(" ; "))]|@tsv')"; done
