#!/bin/bash
# usage: dl.sh fichier url
D=/home/user/controle-ia-travail/docs/notes/conscience-emergence-v1/revue-experiences/sources
cd $D
curl -s -L -A "Mozilla/5.0 (X11; Linux x86_64)" --max-time 90 -o "$1" "$2"
t=$(file -b "$1" | cut -c1-30)
h=$(date -u +%H:%M:%SZ)
if [[ "$t" == PDF* ]] || [[ "$t" == XML* ]] || [[ "$1" == *.xml && $(head -c 200 "$1" | grep -c "<?xml") -gt 0 ]]; then
  sha256sum "$1" > "$1.sha256"
  n=$( [[ "$t" == PDF* ]] && pdfinfo "$1" 2>/dev/null | awk '/^Pages/{print $2}' )
  echo "OK|$1|$(cut -d' ' -f1 $1.sha256)|$2|$h|${n}p|$(stat -c %s $1)"
  echo "OK|$1|$(cut -d' ' -f1 $1.sha256)|$2|$h|${n}p" >> /tmp/claude-0/-home-user-controle-ia-travail/12f6e278-4ba7-598c-9d00-941c25a1615c/scratchpad/cat/journal.txt
else
  echo "ECHEC|$1|$t|$2"; rm -f "$1"
fi
