import sys,re
f,pat=sys.argv[1],sys.argv[2]; w=int(sys.argv[3]) if len(sys.argv)>3 else 220
t=open(f,errors='replace').read()
pages=t.split('\f')
for i,p in enumerate(pages,1):
    q=re.sub(r'\s+',' ',p)
    for m in re.finditer(pat,q,flags=re.I):
        print(f"p.{i}: ...{q[max(0,m.start()-w):m.end()+w]}...\n")
