import sys, importlib.util
p = "docs/notes/collisionneur-v9/collisionneur_v9_v8m.py"
spec = importlib.util.spec_from_file_location("c", p); c = importlib.util.module_from_spec(spec); spec.loader.exec_module(c)
c.fixer_composition(["fable","opus","argon","astra","carbon","neon"], sortie_max=True, effort_max=False)
q = "docs/notes/conscience-emergence-v1/test-neutralite-v1/texte-servi-question-neutre-v2.txt"
nf = len(c.lire_entree(q)); nq = nf
tot = {"base":0,"relance_vraie":0,"relance_base":0}
for tour in c.ORDRE_ETAGE[3]:
    for l in c.LETTRES:
        m = c.MODELES[l]
        if m["fournisseur"] == "anthropic": continue
        pieces = len(c.entrees(tour, l, [c.id_cellule("E1-T2", x) for x in c.LETTRES]))
        car = nf + 6000 + nq + pieces * c.TOURS[tour]["mots"] * 7
        b = c.cout_pire_cas(m, car, m["max"]); r = c.cout_pire_cas(m, car, m["max_relance"]); n = c.nombre_relances(m)
        tot["base"] += b; tot["relance_vraie"] += b + n*r; tot["relance_base"] += b + n*b
        print(tour, m["espece"], round(b,4), round(r,4), n)
print({k: round(v,4) for k,v in tot.items()})
