# Passation — session des collisionneurs, soir du 24 novembre 2026 (conscience et émergence, idées intéressantes, option de clé de Google)

Écrite vers 2026-11-24T__:__Z. Classe C. Session `session_016QhUrsc1rhjmmiLEmqPygF` (compte neuf), branche `claude/upbeat-edison-t3wegg`, tête au moment d'écrire : `________` puis ce commit. Suit `2026-11-24-1630-collisionneurs-conscience-emergence.md`, qui reste en vigueur pour ce qu'elle ne remplace pas. Mère : `session_016QhUrvi45g3jX5saFefVED`.

## Fait depuis 16:30Z

### Dossier « idées intéressantes »
`runs/collisionneur-protocole-x-idees-interessantes-abonnement-v1-20261123-135306`, GO-2026-11-23-21 et -22, plafond 30 USD.
- **Tour 2 (critique croisée) complet** :
  - Fable et Opus étaient déjà recueillis ;
  - Argon valide au quatrième essai ;
  - Carbon valide au troisième essai ;
  - Neon valide au premier essai.
- **Tour 3 (réponse)** :
  - Opus : session `session_016QhUrvMkCBbjUzQD6qyWA6`, effort high, recueillie vers 22:25Z (`e5b5252f…`, 19 072 caractères, toutes les lignes du kit couvertes) ;
  - Fable : kit `cbf1e7eb` poussé sur `kits-abonnement/idees-interessantes-E3-T3-reponse-A-v1`, session non créée (limite hebdomadaire de Fable atteinte sur ce compte) ;
  - Argon : refusé par Google à 21:48Z, HTTP 402 « crédit prépayé épuisé », non compté ;
  - Carbon et Neon : non lancés, en attente derrière Argon.
- **Compteur : 14,63 USD sur 30**, compté au pire. Les coupures et les erreurs 503 sont comptées au pire ; le refus 402 ne l'est pas.

### Dossier « conscience et émergence »
`runs/collisionneur-protocole-x-conscience-emergence-abonnement-v1-20261123-134849`, GO-2026-11-23-19, plafond 40 USD.
- **Tour 2** :
  - Argon valide ;
  - Carbon valide au deuxième essai ;
  - Neon interrompu deux fois (erreurs 503 de forte demande, comptées au pire) ;
  - Fable : kit `746c9315` poussé sur `kits-abonnement/conscience-emergence-E3-T2-critique-croisee-A-v1`, en attente du quota.
- **Compteur : 8,95 USD sur 40**, compté au pire.

### Refus de crédit de Google et clé
- Pièce : `docs/notes/collisionneur-v9/reprise-v8d-v1/pannes-abonnement-v1/refus-de-credit-google-2026-11-24-v1.md` (`6807a3e9…`).
- Le changement de clé dans l'environnement a été refusé par le classifieur du mode automatique. Il n'a été ni rejoué ni contourné. Côté Google, tout est suspendu (choix d de la mère).

### Option `--cle-gemini` du moteur (rien n'est lancé avec)
Objet : nommer la clé de Google par son nom, comme `--cle-openai`, si Lazar autorise une autre clé.
- **Version v8q**, gardée intacte, non admise par la voie v8 :
  - moteur `collisionneur_v9_v8q.py` (`047489b8…`), voie abonnement v7 (`fd1c37b7…`), vague v3 (`51c27240…`) ;
  - rapport du développeur (`605bb63c…`) ;
  - contre-lecture par Opus, agent neuf (`contre-lecture-collisionneur-v9-v8q-opus-v1.md`, `c22da939…`).
- **Corrections en v8r**, sous `docs/notes/collisionneur-v9/` :
  - moteur `collisionneur_v9_v8r.py` (`1656351a…`), voie abonnement v8 (`98f1a1d6…`), vague v4 (`7819b2aa…`) ;
  - rapport du développeur (`75b59995…`).
- **Gardes de la v8r** :
  - `GEMINI_API_KEY_3` est refusée à la composition et à chaque envoi ;
  - `GEMINI_API_KEY_FREE` n'est admise que pour Carbon et Neon (R-5294) ;
  - un nom d'un autre fournisseur est refusé pour l'espace d'Anthropic, pour qu'une clé de Google ne parte jamais vers Anthropic (mot de la mère : « garde la correction ») ;
  - le nom de la clé, jamais sa valeur, est journalisé au premier lancement hors défaut et à chaque changement ;
  - la voie v8 n'admet `--cle-gemini` qu'avec le moteur v8r.
- **Essais** :
  - 22 essais du moteur, en processus, transport coupé, environnement vidé (`test_collisionneur_v9_v8r.py`, `47049da4…`) ;
  - 5 essais de la voie (`test_voie_abonnement_v8.py`, `966c553e…`) ;
  - 16 mutations sur 16 tuées (`mutations_collisionneur_v9_v8r.py`, `4f0edcf3…`).
- **Vérification des corrections par le même contre-lecteur** : ____ (`verification-corrections-collisionneur-v9-v8r-opus-v1.md`, `________…`).
- **Écart déclaré** (consigné par la mère, sans coût ni vraie clé) : les essais de la v8q n'étaient pas coupés du réseau. Une requête de comptage portant une clé factice est probablement partie vers Google pendant les mutations. Les essais de la v8r corrigent ce défaut.

## Reste
1. **Rien ne part avant le 28 novembre ou le mot de Lazar sur la clé de Google** (consigne de la mère, 22:26Z).
2. **Mot de Lazar sur la clé de Google**, deux voies :
   - (a) il recharge le crédit de `GEMINI_API_KEY` sur AI Studio : on relance avec la vague v2 ou v4 et le moteur v8m, sans option de clé ;
   - (b) il autorise une autre clé : on relance avec la vague v4, le moteur v8r, `--cle-gemini <NOM>` et `--reprise`.
   - Dans les deux cas : jamais `GEMINI_API_KEY_3` ; `GEMINI_API_KEY_FREE` seulement pour Carbon et Neon.
   - Cellules à finir : aux idées intéressantes, Argon, Carbon et Neon du tour 3 ; en conscience et émergence, Neon du tour 2, puis tout le tour 3.
3. **Après le 28 vers 04:00Z (quota de Fable)** :
   - créer les deux sessions Fable en effort high, puis recueillir par `recueil_session_v6.py` :
     - conscience et émergence, tour 2, kit `746c9315` ;
     - idées intéressantes, tour 3, kit `cbf1e7eb` ;
   - en conscience et émergence, le tour 3 ne s'ouvre qu'une fois le tour 2 complet, Fable comprise (ce dossier ne part pas sans Fable).
4. **Notes de sortie** des deux dossiers, en Markdown et en PDF (GO-2026-11-22-74). Elles déclarent :
   - l'écart d'effort (« max » sur les fiches, « high » servi) ;
   - les absences ;
   - les réponses hors dossier (Opus pour la conscience ; la cellule non conforme).
5. **Décisions en attente de Lazar** :
   - brainstorm d'Opus : D1 à D4 ;
   - Fable : D1 à D5 ;
   - données humaines : huit décisions ;
   - candidature d'OpenAI : quatre points ;
   - clé de Google.

## Réserves
- Toute la dépense est comptée au pire, au-dessus de la dépense réelle. À relever sur la facture de Google.
- `registres/etat.md` est tenu par la mère et n'est pas touché ici. Elle reporte cette passation.
- Quota de Fable : limite hebdomadaire atteinte sur ce compte, remise à zéro le 28 vers 04:00Z.
- Les tests du dépôt n'ont pas été lancés (environnement sans torch). Seuls les essais propres aux scripts ont tourné, avec la bibliothèque standard.

## Prochaine action
Rien jusqu'au 28 novembre ou jusqu'au mot de Lazar sur la clé. Le 28 au réveil, ou au mot de Lazar : reprendre le point 2 ou le point 3 du « Reste ».

## Instances actives
Aucune instance de calcul lancée par cette session (ni Vast ni Hetzner). Aucun processus de vague en cours. Appels d'interface seulement, sous les plafonds des GO cités.
