"""Espion du contre-lecteur : un mutant lancé par les essais de ligne de commande tente-t-il un envoi ?

`ouvrir` du mutant écrit l'hôte et les NOMS d'en-têtes (jamais leurs valeurs) dans un fichier, puis refuse la connexion.
Usage : PYTHONPATH=src python3 -B espion_cli_v8q.py
"""
import importlib.util
import sys
import urllib.request
from pathlib import Path

ICI = Path(__file__).resolve().parent
sys.path.insert(0, str(ICI))
import mutations_v8q as mu  # noqa: E402  (coupe aussi le réseau de ce processus)

ESPION = ICI / "espion-tentatives.txt"
COUPURE_ESPION = [
    ('    ca = os.environ.get("SSL_CERT_FILE")\n',
     '    with open(' + repr(str(ESPION)) + ', "a", encoding="utf-8") as _f:\n'
     '        _f.write(f"{urllib.parse.urlsplit(requete.full_url).hostname} {urllib.parse.urlsplit(requete.full_url).path} '
     'en-têtes {sorted(k for k, _ in requete.header_items())}\\n")\n'
     '    raise ConnectionRefusedError("réseau coupé par le contre-lecteur")\n'
     '    ca = os.environ.get("SSL_CERT_FILE")\n'),
    mu.COUPURE[1],
]

for nom in ("D1 refus de la clé GEMINI_API_KEY_3 retiré", "C8 option lue mais non transmise à la composition"):
    ESPION.unlink(missing_ok=True)
    base = mu.appliquer(mu.SOURCE.read_text(encoding="utf-8"), COUPURE_ESPION)
    chemin = mu.DOSSIER / "collisionneur_v9_v8q_espion.py"
    chemin.write_text(mu.appliquer(base, mu.MUTATIONS[nom]), encoding="utf-8")
    t = mu.charger_essais()
    t.MOTEUR = chemin
    for essai in ("test_ligne_de_commande_refuse_la_cle_epuisee_sans_reseau",
                  "test_ligne_de_commande_refuse_une_cle_nommee_absente_sans_reseau"):
        ESPION.unlink(missing_ok=True)
        try:
            getattr(t, essai)()
            issue = "passe"
        except AssertionError as e:
            issue = f"tombe ({str(e)[:160]})"
        tentatives = ESPION.read_text(encoding="utf-8").splitlines() if ESPION.exists() else []
        print(f"{nom} / {essai} : {issue} ; tentatives d'envoi : {tentatives or 'aucune'}")
