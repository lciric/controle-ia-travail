"""Les textes servis des kits écrits sous v8m sont-ils reconstruits à l'identique par le v8r ? Sans réseau, sur COPIES.

N'affiche que des égalités d'empreintes ; aucun texte de cellule ni de kit n'est affiché.
Usage : PYTHONPATH=src python3 -B epreuve_kits_v8m_v8r.py COPIE [COPIE...]
"""
import importlib.util
import json
import sys
import urllib.request
from pathlib import Path

RACINE = Path("/home/user/controle-ia-travail")


def interdit(*a, **k):
    raise ConnectionRefusedError("réseau coupé par le contre-lecteur")


urllib.request.urlopen = interdit
urllib.request.OpenerDirector.open = interdit


def charger(nom):
    spec = importlib.util.spec_from_file_location(f"k_{nom}", RACINE / f"docs/notes/collisionneur-v9/collisionneur_v9_{nom}.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    mod.TRANSPORT = mod.TRANSPORT_COMPTE = interdit
    return mod


v8m, v8r = charger("v8m"), charger("v8r")
for copie in sys.argv[1:]:
    d = Path(copie)
    for mod in (v8m, v8r):
        mod.lire_composition(d)
    kits = sorted(p for p in (d / "abonnement" / "kits").iterdir() if p.is_dir())
    for k in kits:
        fiche = json.loads((k / "fiche.json").read_text(encoding="utf-8"))
        cid = fiche["cellule"]
        tour = next(t for t in v8r.TOURS if cid.startswith(t + "-"))
        lettre = cid[-1]
        pm, _ = v8m.construire_prompt(d, tour, lettre, [], set())
        pq, _ = v8r.construire_prompt(d, tour, lettre, [], set())
        print(f"{d.name[:48]} {cid:28s} v8m = v8r : {v8m.empreinte(pm) == v8r.empreinte(pq)} ; "
              f"v8r = fiche du kit : {v8r.empreinte(pq) == fiche['sha256_texte_servi']}")
