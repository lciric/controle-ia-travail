"""Espion du contre-lecteur : note puis refuse toute connexion ou résolution de nom hors de la boucle locale."""
import os
import socket

_JOURNAL = "/tmp/claude-0/-home-user-controle-ia-travail/12f6e278-4ba7-598c-9d00-941c25a1615c/scratchpad/espion-v8r/tentatives.txt"
_LOCAUX = (None,)  # rien n'est local : le mandataire de la session écoute en local


def _noter(quoi):
    with open(_JOURNAL, "a", encoding="utf-8") as f:
        f.write(f"{os.getpid()} {quoi}\n")


_connect, _connect_ex, _gai = socket.socket.connect, socket.socket.connect_ex, socket.getaddrinfo


def connect(self, adresse):
    if self.family in (socket.AF_INET, socket.AF_INET6) :
        _noter(f"TENTATIVE connect {adresse[0]!r}")
        raise ConnectionRefusedError("espion du contre-lecteur : réseau coupé")
    return _connect(self, adresse)


def connect_ex(self, adresse):
    if self.family in (socket.AF_INET, socket.AF_INET6) :
        _noter(f"TENTATIVE connect_ex {adresse[0]!r}")
        return 111
    return _connect_ex(self, adresse)


def getaddrinfo(hote, *a, **k):
    if hote not in _LOCAUX:
        _noter(f"TENTATIVE getaddrinfo {hote!r}")
        raise socket.gaierror("espion du contre-lecteur : résolution coupée")
    return _gai(hote, *a, **k)


socket.socket.connect, socket.socket.connect_ex, socket.getaddrinfo = connect, connect_ex, getaddrinfo
_noter("espion chargé")
