"""Épreuve du contre-lecteur, sans réseau : reprise par le v8r d'une COPIE d'un dossier commencé sous v8m.

Aucune valeur de clé n'est lue ni posée ; tout transport HTTP de ce processus lève une erreur.
Usage : PYTHONPATH=src python3 -B epreuve_reprise_v8m_v8r.py COPIE [COPIE...]
"""
import argparse
import contextlib
import importlib.util
import io
import json
import sys
import urllib.request
from pathlib import Path

RACINE = Path("/home/user/controle-ia-travail")
DOSSIER_MOTEURS = RACINE / "docs/notes/collisionneur-v9"


class ReseauInterdit(AssertionError):
    pass


def interdit(*a, **k):
    raise ReseauInterdit("RÉSEAU INTERDIT dans l'épreuve du contre-lecteur")


urllib.request.urlopen = interdit
urllib.request.OpenerDirector.open = interdit


def charger(nom):
    spec = importlib.util.spec_from_file_location(f"moteur_{nom}_epreuve", DOSSIER_MOTEURS / f"collisionneur_v9_{nom}.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    mod.TRANSPORT = interdit
    mod.TRANSPORT_COMPTE = interdit
    return mod


def resume_journal(mod, d):
    j = mod.lire_journal(d)
    genres = {}
    for e in j:
        cle = next((k for k in ("essai", "changement_script", "options_appel_v8k", "nom_cle_gemini", "kit_abonnement",
                                "voie_abonnement", "ligne_ouverte", "ligne_reprise", "refus_avant_envoi", "decision",
                                "refus_motifs", "rejugement", "audit_jev") if k in e), "autre:" + ",".join(sorted(e))[:60])
        genres[cle] = genres.get(cle, 0) + 1
    scripts = sorted({e.get("sha256_script", "")[:12] for e in j if "essai" in e})
    return len(j), genres, scripts


def devis_sortie(mod, d, ligne):
    tampon = io.StringIO()
    with contextlib.redirect_stdout(tampon):
        try:
            res = mod.devis_reprise(d, ligne)
            code = "retenu=" + str(res["retenu"])
        except mod.Arret as e:
            code = f"Arret {e.code} : {e}"
    lignes = tampon.getvalue().splitlines()
    return code, lignes


def main():
    v8m, v8r = charger("v8m"), charger("v8r")
    for copie in sys.argv[1:]:
        d = Path(copie)
        print(f"\n===== {d.name}")
        compo = json.loads(v8r.lire_sceau(d / "especes.json")[0])
        print("composition :", compo.get("especes"), "options :", compo.get("options"))
        n, genres, scripts = resume_journal(v8r, d)
        print(f"journal avant : {n} entrées ; genres {genres} ; empreintes de script des essais {scripts}")
        avant_m, avant_q = v8m.verifier(d), v8r.verifier(d)
        print(f"verifier avant : v8m {len(avant_m)} problème(s), v8r {len(avant_q)} problème(s) ; égaux {avant_m == avant_q}")
        for x in avant_q[:5]:
            print("   ", x[:200])
        dep_avant, ess_avant = v8r.depense(d), len(v8r.essais_journal(d))
        ligne = (v8r.ligne_ouverte(d) or {}).get("ligne_ouverte")
        dm = devis_sortie(v8m, d, ligne) if ligne else None
        # lancement simulé du v8r, dans l'ordre de principal (sans envoi)
        opts = compo.get("options") or {}
        v8r.fixer_composition(compo["especes"], "ABONNEMENT_CLE_FACTICE", "ANTHROPIC_WORKSPACE_ID", "OPENAI_API_KEY_2",
                              sortie_max=bool(opts.get("sortie_max")), effort_max=bool(opts.get("effort_max")),
                              nom_cle_gemini="GEMINI_API_KEY_2")
        try:
            v8r.declarer_script(d, False)
            print("declarer_script sans --reprise : AUCUN arrêt")
        except v8r.Arret as e:
            print(f"declarer_script sans --reprise : arrêt code {e.code}")
        v8r.declarer_script(d, True)
        a = argparse.Namespace(kimi_direct=False, sortie_max=bool(opts.get("sortie_max")),
                               effort_max=bool(opts.get("effort_max")))
        n1 = len(v8r.lire_journal(d))
        tampon = io.StringIO()
        with contextlib.redirect_stdout(tampon):
            v8r.declarer_options(d, a)
            n2 = len(v8r.lire_journal(d))
            v8r.declarer_cle_gemini(d)
        n3 = len(v8r.lire_journal(d))
        print(f"declarer_options : {n2 - n1} entrée(s) neuve(s) ; declarer_cle_gemini : {n3 - n2} entrée(s) neuve(s)")
        print("écran :", [l for l in tampon.getvalue().splitlines() if "Google" in l])
        n, genres, scripts = resume_journal(v8r, d)
        print(f"journal après : {n} entrées ; genres {genres}")
        apres_m, apres_q = v8m.verifier(d), v8r.verifier(d)
        print(f"verifier après : v8m {len(apres_m)}, v8r {len(apres_q)} ; v8r inchangé {apres_q == avant_q} ; "
              f"v8m inchangé {apres_m == avant_m}")
        for x in sorted(set(apres_q) - set(avant_q))[:5]:
            print("   NOUVEAU :", x[:200])
        print(f"suivre_scripts : courant {str(v8r.suivre_scripts(v8r.lire_journal(d))[0])[:12]} ; "
              f"problèmes {v8r.suivre_scripts(v8r.lire_journal(d))[1]}")
        print(f"dépense {dep_avant} -> {v8r.depense(d)} ; essais {ess_avant} -> {len(v8r.essais_journal(d))}")
        if ligne:
            dq = devis_sortie(v8r, d, ligne)
            corps_m = [l for l in dm[1] if not l.startswith("Devis de reprise,")]
            corps_q = [l for l in dq[1] if not l.startswith("Devis de reprise,")]
            print(f"devis-reprise : v8m {dm[0]} ; v8r {dq[0]} ; corps identique hors ligne de version : {corps_m == corps_q}")
        else:
            print("devis-reprise : pas de ligne du run au journal, non éprouvé")


if __name__ == "__main__":
    main()
