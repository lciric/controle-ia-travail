"""Mutations du contre-lecteur sur le v8r et la voie v8, rejouées contre les essais livrés, sans réseau.

Lancer depuis la racine du dépôt, sous `env -i`, avec l'espion du contre-lecteur en tête de PYTHONPATH :
  env -i PATH=... PYTHONPATH=ESPION:src ESSAIS_V8R_ENVIRONNEMENT_VIDE=1 python3 -B ce_fichier.py DOSSIER_TEMPORAIRE
Chaque mutant du moteur a en plus son transport coupé (`ouvrir` lève ConnectionRefusedError).
"""
import contextlib
import importlib.util
import io
import os
import sys
from pathlib import Path

RACINE = Path("/home/user/controle-ia-travail")
D = RACINE / "docs/notes/collisionneur-v9"
S = Path(sys.argv[1])
assert not any(k.endswith("_API_KEY") or "_API_KEY_" in k for k in os.environ), "environnement non vidé"

COUPURE = [
    ('    ca = os.environ.get("SSL_CERT_FILE")\n',
     '    raise ConnectionRefusedError("réseau coupé par le contre-lecteur")\n    ca = os.environ.get("SSL_CERT_FILE")\n'),
]
COMPTAGE = ('    cle, motif = cle_gemini(m)  # v9-v8r (1) : nom de la composition seulement, sans repli\n'
            '    if motif:\n        raise RefusCompte("COMPTE_IMPOSSIBLE", motif)\n')
CREATION = ('                                     data=json.dumps(corps, ensure_ascii=False).encode("utf-8"), method="POST",\n'
            '                                     headers={"Content-Type": "application/json", "x-goog-api-key": cle})\n'
            '    debut = HORLOGE()\n    try:\n        op = lire_json(requete, DELAI_RELEVE_S, cle)\n')
JOURNAL = '        ajouter_journal(dossier, {"nom_cle_gemini": nom, "quand": maintenant(), "script": VERSION})\n'
MOTEUR = {
    "C1 nom hors du contrôle de forme": [(
        '    for nom in (nom_cle_anthropic, nom_espace_anthropic, nom_cle_openai, nom_cle_mistral, nom_cle_kimi,\n'
        '                nom_cle_gemini):  # v9-v8q\n',
        '    for nom in (nom_cle_anthropic, nom_espace_anthropic, nom_cle_openai, nom_cle_mistral, nom_cle_kimi):  # mutant\n')],
    "C2 comptage : repli sur NOMS_CLES[\"gemini\"]": [(COMPTAGE,
        '    cle, motif = cle_gemini(m)  # mutant\n    cle = cle or os.environ.get(NOMS_CLES["gemini"])\n'
        '    if not cle:\n        raise RefusCompte("COMPTE_IMPOSSIBLE", motif)\n')],
    "C2b comptage : repli par PREFIXE_CLE_GEMINI (hors de la lecture syntaxique)": [(COMPTAGE,
        '    cle, motif = cle_gemini(m)  # mutant\n    cle = cle or os.environ.get(PREFIXE_CLE_GEMINI)\n'
        '    if not cle:\n        raise RefusCompte("COMPTE_IMPOSSIBLE", motif)\n')],
    "C3 relevé : os.environ[\"GEMINI_API_KEY\"]": [(
        '    releve = urllib.request.Request(f"{URL_GEMINI_BASE}/{nom}", method="GET", headers={"x-goog-api-key": cle})\n',
        '    releve = urllib.request.Request(f"{URL_GEMINI_BASE}/{nom}", method="GET", '
        'headers={"x-goog-api-key": os.environ["GEMINI_API_KEY"]})  # mutant\n')],
    "C4 création : NOMS_CLES[\"gemini\"] dans l'en-tête": [(CREATION, CREATION.replace(
        '"x-goog-api-key": cle})', '"x-goog-api-key": os.environ.get(NOMS_CLES["gemini"]) or cle})  # mutant'))],
    "C4b création : PREFIXE_CLE_GEMINI (hors de la lecture syntaxique)": [(CREATION, CREATION.replace(
        '"x-goog-api-key": cle})', '"x-goog-api-key": os.environ.get(PREFIXE_CLE_GEMINI) or cle})  # mutant'))],
    "C10 annulation : os.environ[\"GEMINI_API_KEY\"]": [(
        '                                     headers={"Content-Type": "application/json", "x-goog-api-key": cle})\n'
        '    try:\n        lire_json(requete, DELAI_RELEVE_S, cle)\n        return "annulation demandée"\n',
        '                                     headers={"Content-Type": "application/json", '
        '"x-goog-api-key": os.environ["GEMINI_API_KEY"]})  # mutant\n'
        '    try:\n        lire_json(requete, DELAI_RELEVE_S, cle)\n        return "annulation demandée"\n')],
    "C5 valeur au journal": [(JOURNAL, JOURNAL.replace('{"nom_cle_gemini": nom,', '{"nom_cle_gemini": nom, "valeur": os.environ.get(nom),'))],
    "C6 valeur à l'écran": [(
        '    print(f"Clé de Google : variable {nom} (nom seulement ; journalisé s\'il change)", flush=True)\n',
        '    print(f"Clé de Google : variable {nom} = {os.environ.get(nom)} (nom seulement)", flush=True)  # mutant\n')],
    "C7 défaut de la ligne de commande changé": [(
        '        s.add_argument("--cle-gemini", default=NOMS_CLES["gemini"],  # v9-v8q\n',
        '        s.add_argument("--cle-gemini", default="GEMINI_API_KEY_2",  # mutant\n')],
    "C8 option lue mais non transmise": [(
        '                          nom_cle_gemini=a.cle_gemini)  # v9-v8q\n', '                          )  # mutant\n')],
    "C9 nom journalisé avant --reprise": [(
        '        declarer_script(dossier, a.reprise)  # v9-v3\n        declarer_options(dossier, a)  # v9-v8k\n'
        '        declarer_cle_gemini(dossier)  # v9-v8q\n',
        '        declarer_cle_gemini(dossier)  # mutant\n        declarer_script(dossier, a.reprise)  # v9-v3\n'
        '        declarer_options(dossier, a)  # v9-v8k\n')],
    "N3 préfixe non contrôlé au moment de l'envoi": [(
        '    return cle_par_son_nom(m, "--cle-gemini", PREFIXE_CLE_GEMINI)\n',
        '    return cle_par_son_nom(m, "--cle-gemini", "")  # mutant : tout nom admis à l\'envoi\n')],
    "N8 espace d'Anthropic : refus limité aux noms de Google": [(
        '    if nom_espace_anthropic is not None and nom_espace_anthropic.startswith(PREFIXES_AUTRES_FOURNISSEURS):  # v9-v8r (5)\n',
        '    if nom_espace_anthropic is not None and nom_espace_anthropic.startswith("GEMINI_API_KEY"):  # mutant\n')],
}
GARDE_VOIE = ('        if a.commande != "v8r" and any(x == "--cle-gemini" or x.startswith("--cle-gemini=") for x in reste):  # v8\n')
VOIE = {
    "V1 voie : --cle-gemini refusée même avec le v8r": [(GARDE_VOIE, GARDE_VOIE.replace('a.commande != "v8r" and ', ''))],
    "V2 voie : v8m, v8p et essaim refusés même sans --cle-gemini": [(GARDE_VOIE, '        if a.commande != "v8r":  # mutant\n')],
    "V3 voie : forme --cle-gemini=NOM non vue": [(GARDE_VOIE, GARDE_VOIE.replace(' or x.startswith("--cle-gemini=")', ''))],
}


def appliquer(texte, remplacements):
    for ancien, neuf in remplacements:
        n = texte.count(ancien)
        if n != 1:
            raise SystemExit(f"motif trouvé {n} fois : {ancien[:90]!r}")
        texte = texte.replace(ancien, neuf)
    return texte


def module(nom, chemin):
    spec = importlib.util.spec_from_file_location(nom, chemin)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def jouer(t):
    tombes = []
    for n in sorted(x for x in vars(t) if x.startswith("test_")):
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                getattr(t, n)()
        except Exception as e:  # noqa: BLE001
            tombes.append(f"{n} ({type(e).__name__})")
    return tombes


S.mkdir(parents=True, exist_ok=True)
T = module("essais_v8r_cl", D / "test_collisionneur_v9_v8r.py")
base = appliquer((D / "collisionneur_v9_v8r.py").read_text(encoding="utf-8"), COUPURE)
temoin = S / "v8r_temoin.py"
temoin.write_text(base, encoding="utf-8")
T.MOTEUR = temoin
print("TÉMOIN MOTEUR (transport coupé) :", jouer(T) or "aucun échec")
for i, (nom, r) in enumerate(MOTEUR.items()):
    p = S / f"v8r_mutant_{i:02d}.py"
    p.write_text(appliquer(base, r), encoding="utf-8")
    T.MOTEUR = p
    tombes = jouer(T)
    print(f"{'TUÉE  ' if tombes else 'SURVIT'} {nom} : {', '.join(tombes[:3]) if tombes else 'aucun essai ne tombe'}")

TV = module("essais_voie_v8_cl", D / "abonnement-v1" / "test_voie_abonnement_v8.py")
miroir = S / "miroir"
(miroir / "abonnement-v1").mkdir(parents=True, exist_ok=True)
for nom in ("collisionneur_v9_v8r.py", "collisionneur_v9_v8m.py"):
    lien = miroir / nom
    if not lien.exists():
        lien.symlink_to(D / nom)
original = TV.charger_voie
voie_src = (D / "abonnement-v1" / "voie_abonnement_v8.py").read_text(encoding="utf-8")
cible = miroir / "abonnement-v1" / "voie_abonnement_v8.py"
for nom, r in [("TÉMOIN VOIE (copie non mutée)", [])] + list(VOIE.items()):
    cible.write_text(appliquer(voie_src, r), encoding="utf-8")
    compteur = [0]

    def charger_voie(version, _c=compteur):
        if version != "v8":
            return original(version)
        _c[0] += 1
        return module(f"voie_v8_mutante_{_c[0]}", cible)
    TV.charger_voie = charger_voie
    tombes = jouer(TV)
    etiquette = "" if not r else ("TUÉE   " if tombes else "SURVIT ")
    print(f"{etiquette}{nom} : {', '.join(tombes[:3]) if tombes else 'aucun essai ne tombe'}")
