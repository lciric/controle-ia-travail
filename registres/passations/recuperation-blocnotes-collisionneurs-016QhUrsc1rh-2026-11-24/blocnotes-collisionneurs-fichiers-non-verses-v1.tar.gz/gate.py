import importlib.util
p="docs/notes/collisionneur-v9/collisionneur_v9_v8m.py"
s=importlib.util.spec_from_file_location("c",p);c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
c.fixer_composition(["fable","opus","argon","astra","carbon","neon"])
q="docs/notes/conscience-emergence-v1/test-neutralite-v1/texte-servi-question-neutre-v2.txt"
n=len(c.lire_entree(q))
for tour in c.ORDRE_ETAGE[3]:
  for l in c.LETTRES:
    m=c.MODELES[l]
    if m["fournisseur"]!="anthropic":continue
    pieces=len(c.entrees(tour,l,[c.id_cellule("E1-T2",x) for x in c.LETTRES]))
    car=n+6000+n+pieces*c.TOURS[tour]["mots"]*7
    print(tour,m["espece"],round(c.cout_pire_cas(m,car,m["max"]),2),round(max(c.cout_pire_cas(m,car,t) for t in (m["max"],m["max_relance"])),2))
