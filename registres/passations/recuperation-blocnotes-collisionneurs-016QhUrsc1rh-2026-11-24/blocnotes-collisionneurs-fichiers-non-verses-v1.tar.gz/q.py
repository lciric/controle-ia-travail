import re,sys
t=open(sys.argv[1]).read()
for e in re.findall(r'<entry>(.*?)</entry>',t,re.S):
  i=re.search(r'<id>(.*?)</id>',e).group(1); ti=re.sub(r'\s+',' ',re.search(r'<title>(.*?)</title>',e,re.S).group(1)); d=re.search(r'<published>(.*?)</published>',e).group(1)[:10]
  ab=re.sub(r'\s+',' ',re.search(r'<summary>(.*?)</summary>',e,re.S).group(1))
  print(d,i.split('/')[-1],ti[:150]); 
  if len(sys.argv)>2: print('   ',ab[:int(sys.argv[2])])
