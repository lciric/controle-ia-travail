"""Épreuve du contre-lecteur, sans réseau : reprise par le v8q d'une COPIE d'un dossier commencé sous v8m.

Aucune valeur de clé n'est lue ni posée ; tout transport HTTP de ce processus lève une erreur.
Usage : PYTHONPATH=src python3 -B epreuve_reprise_v8m_v8q.py COPIE [COPIE...]
"""
import argparse
import contextlib
import importlib.util
import io
import json
import sys
import urllib.request
from pathlib import Path

RACINE = Path("/home/user/controle-ia-travail")
DOSSIER_MOTEURS = RACINE / "docs/notes/collisionneur-v9"


class ReseauInterdit(AssertionError):
    pass


def interdit(*a, **k):
    raise ReseauInterdit("RÉSEAU INTERDIT dans l'épreuve du contre-lecteur")


urllib.request.urlopen = interdit
urllib.request.OpenerDirector.open = interdit


def charger(nom):
    spec = importlib.util.spec_from_file_location(f"moteur_{nom}_epreuve", DOSSIER_MOTEURS / f"collisionneur_v9_{nom}.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    mod.TRANSPORT = interdit
    mod.TRANSPORT_COMPTE = interdit
    return mod


def resume_journal(mod, d):
    j = mod.lire_journal(d)
    genres = {}
    for e in j:
        cle = next((k for k in ("essai", "changement_script", "options_appel_v8k", "nom_cle_gemini", "kit_abonnement",
                                "voie_abonnement", "ligne_ouverte", "ligne_reprise", "refus_avant_envoi", "decision",
                                "refus_motifs", "rejugement", "audit_jev") if k in e), "autre:" + ",".join(sorted(e))[:60])
        genres[cle] = genres.get(cle, 0) + 1
    scripts = sorted({e.get("sha256_script", "")[:12] for e in j if "essai" in e})
    return len(j), genres, scripts


def devis_sortie(mod, d, ligne):
    tampon = io.StringIO()
    with contextlib.redirect_stdout(tampon):
        try:
            res = mod.devis_reprise(d, ligne)
            code = "retenu=" + str(res["retenu"])
        except mod.Arret as e:
            code = f"Arret {e.code} : {e}"
    lignes = tampon.getvalue().splitlines()
    return code, lignes


def main():
    v8m, v8q = charger("v8m"), charger("v8q")
    for copie in sys.argv[1:]:
        d = Path(copie)
        print(f"\n===== {d.name}")
        compo = json.loads(v8q.lire_sceau(d / "especes.json")[0])
        print("composition :", compo.get("especes"), "options :", compo.get("options"))
        n, genres, scripts = resume_journal(v8q, d)
        print(f"journal avant : {n} entrées ; genres {genres} ; empreintes de script des essais {scripts}")
        avant_m, avant_q = v8m.verifier(d), v8q.verifier(d)
        print(f"verifier avant : v8m {len(avant_m)} problème(s), v8q {len(avant_q)} problème(s) ; égaux {avant_m == avant_q}")
        for x in avant_q[:5]:
            print("   ", x[:200])
        dep_avant, ess_avant = v8q.depense(d), len(v8q.essais_journal(d))
        ligne = (v8q.ligne_ouverte(d) or {}).get("ligne_ouverte")
        dm = devis_sortie(v8m, d, ligne) if ligne else None
        # lancement simulé du v8q, dans l'ordre de principal (sans envoi)
        opts = compo.get("options") or {}
        v8q.fixer_composition(compo["especes"], "ABONNEMENT_CLE_FACTICE", "ANTHROPIC_WORKSPACE_ID", "OPENAI_API_KEY_2",
                              sortie_max=bool(opts.get("sortie_max")), effort_max=bool(opts.get("effort_max")),
                              nom_cle_gemini="GEMINI_API_KEY_2")
        try:
            v8q.declarer_script(d, False)
            print("declarer_script sans --reprise : AUCUN arrêt")
        except v8q.Arret as e:
            print(f"declarer_script sans --reprise : arrêt code {e.code}")
        v8q.declarer_script(d, True)
        a = argparse.Namespace(kimi_direct=False, sortie_max=bool(opts.get("sortie_max")),
                               effort_max=bool(opts.get("effort_max")))
        n1 = len(v8q.lire_journal(d))
        tampon = io.StringIO()
        with contextlib.redirect_stdout(tampon):
            v8q.declarer_options(d, a)
            n2 = len(v8q.lire_journal(d))
            v8q.declarer_cle_gemini(d)
        n3 = len(v8q.lire_journal(d))
        print(f"declarer_options : {n2 - n1} entrée(s) neuve(s) ; declarer_cle_gemini : {n3 - n2} entrée(s) neuve(s)")
        print("écran :", [l for l in tampon.getvalue().splitlines() if "Google" in l])
        n, genres, scripts = resume_journal(v8q, d)
        print(f"journal après : {n} entrées ; genres {genres}")
        apres_m, apres_q = v8m.verifier(d), v8q.verifier(d)
        print(f"verifier après : v8m {len(apres_m)}, v8q {len(apres_q)} ; v8q inchangé {apres_q == avant_q} ; "
              f"v8m inchangé {apres_m == avant_m}")
        for x in sorted(set(apres_q) - set(avant_q))[:5]:
            print("   NOUVEAU :", x[:200])
        print(f"suivre_scripts : courant {str(v8q.suivre_scripts(v8q.lire_journal(d))[0])[:12]} ; "
              f"problèmes {v8q.suivre_scripts(v8q.lire_journal(d))[1]}")
        print(f"dépense {dep_avant} -> {v8q.depense(d)} ; essais {ess_avant} -> {len(v8q.essais_journal(d))}")
        if ligne:
            dq = devis_sortie(v8q, d, ligne)
            corps_m = [l for l in dm[1] if not l.startswith("Devis de reprise,")]
            corps_q = [l for l in dq[1] if not l.startswith("Devis de reprise,")]
            print(f"devis-reprise : v8m {dm[0]} ; v8q {dq[0]} ; corps identique hors ligne de version : {corps_m == corps_q}")
        else:
            print("devis-reprise : pas de ligne du run au journal, non éprouvé")


if __name__ == "__main__":
    main()
