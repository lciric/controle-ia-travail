#!/bin/bash
# usage: dl.sh nomfichier url
S=/home/user/controle-ia-travail/docs/notes/conscience-emergence-v1/revue-theories/sources
cd "$S" || exit 1
curl -sSL -A "Mozilla/5.0 (X11; Linux x86_64) research-reader" --max-time 90 -o "$1" "$2"
t=$(date -u +%Y-%m-%dT%H:%M:%SZ)
ty=$(file -b "$1" | cut -c1-40)
sz=$(stat -c %s "$1")
echo "$1|$2|$t|$ty|$sz" >> /tmp/claude-0/-home-user-controle-ia-travail/12f6e278-4ba7-598c-9d00-941c25a1615c/scratchpad/rt/log.txt
echo "$1 $ty $sz $t"
