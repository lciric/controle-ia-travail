import sys,re
f=sys.argv[1]; pat=re.compile(sys.argv[2],re.I); ctx=int(sys.argv[3]) if len(sys.argv)>3 else 0
t=open(f,encoding='utf-8',errors='replace').read().split('\f')
for i,p in enumerate(t,1):
    L=p.split('\n')
    for j,l in enumerate(L):
        if pat.search(l):
            print(f"p{i}: "+' / '.join(x.strip() for x in L[max(0,j-ctx):j+ctx+1]))
