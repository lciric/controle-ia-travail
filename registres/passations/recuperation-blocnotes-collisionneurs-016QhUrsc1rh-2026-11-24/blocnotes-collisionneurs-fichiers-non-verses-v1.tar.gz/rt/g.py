import sys,re
t=open(sys.argv[1],encoding='utf-8',errors='replace').read().split('\f')
pat=re.compile(sys.argv[2],re.I); w=int(sys.argv[3]) if len(sys.argv)>3 else 160; mx=int(sys.argv[4]) if len(sys.argv)>4 else 12
n=0; last=(-1,-10**9)
for i,p in enumerate(t,1):
  for m in pat.finditer(p):
    if last[0]==i and m.start()-last[1]<w: continue
    last=(i,m.start())
    print(f'p{i}:',p[max(0,m.start()-w):m.end()+w].replace('\n',' ')); n+=1
    if n>=mx: sys.exit()
