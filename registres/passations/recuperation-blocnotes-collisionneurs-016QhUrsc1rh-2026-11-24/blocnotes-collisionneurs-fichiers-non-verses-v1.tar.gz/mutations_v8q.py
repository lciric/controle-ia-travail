"""Mutations du contre-lecteur sur le moteur v8q, sans réseau.

Chaque mutant est une copie du v8q, dans le bloc-notes, avec (1) une seule mutation et (2) le transport coupé :
`ouvrir` lève ConnectionRefusedError et OpenerDirector.open aussi, pour qu'aucun mutant ne joigne un fournisseur, même
lancé en sous-processus par les essais de la ligne de commande. Les essais livrés sont importés tels quels ; seul leur
global MOTEUR est pointé vers le mutant. Aucune valeur de clé réelle n'est lue : les essais retirent les variables de
Google de l'environnement et posent des valeurs factices.
Usage : PYTHONPATH=src python3 -B mutations_v8q.py
"""
import importlib.util
import sys
import traceback
import urllib.request
from pathlib import Path

ICI = Path(__file__).resolve().parent
RACINE = Path("/home/user/controle-ia-travail")
SOURCE = RACINE / "docs/notes/collisionneur-v9/collisionneur_v9_v8q.py"
ESSAIS = RACINE / "docs/notes/collisionneur-v9/test_collisionneur_v9_v8q.py"
DOSSIER = ICI / "mutants"


def interdit(*a, **k):
    raise ConnectionRefusedError("réseau coupé par le contre-lecteur")


urllib.request.urlopen = interdit
urllib.request.OpenerDirector.open = interdit

COUPURE = [
    ('    ca = os.environ.get("SSL_CERT_FILE")\n',
     '    raise ConnectionRefusedError("réseau coupé par le contre-lecteur")\n    ca = os.environ.get("SSL_CERT_FILE")\n'),
    ("import urllib.request\n",
     "import urllib.request\nurllib.request.OpenerDirector.open = lambda *a, **k: (_ for _ in ()).throw("
     "ConnectionRefusedError('réseau coupé par le contre-lecteur'))\n"),
]

MUTATIONS = {
    # --- les quatre du développeur ---
    "D1 refus de la clé GEMINI_API_KEY_3 retiré": [(
        '    if nom_cle_gemini in NOMS_CLE_GEMINI_REFUSES:  # v9-v8q : clé épuisée, jamais employée\n'
        '        raise Arret(CODE_USAGE, f"--cle-gemini : {nom_cle_gemini} est refusée (clé épuisée) ; rien n\'est envoyé")\n',
        '')],
    "D2 contrôle du préfixe GEMINI_API_KEY retiré": [(
        '    if not nom_cle_gemini.startswith(PREFIXE_CLE_GEMINI):  # v9-v8q : même règle que pour OpenAI\n',
        '    if False:  # mutant\n')],
    "D3 envoi en flux à nom fixe": [(
        '    nom_cle = m.get("nom_cle") or NOMS_CLES["gemini"]  # v9-v8q : variable nommée par --cle-gemini\n'
        '    cle = os.environ.get(nom_cle)\n    if not cle:\n'
        '        return Reponse(echec=f"{nom_cle} absente (variable nommée par --cle-gemini)")\n    try:\n'
        '        corps = demande_gemini(m, prompt, max_tokens)  # v9-v8 : niveau',
        '    nom_cle = NOMS_CLES["gemini"]  # mutant\n'
        '    cle = os.environ.get(nom_cle)\n    if not cle:\n'
        '        return Reponse(echec=f"{nom_cle} absente (variable nommée par --cle-gemini)")\n    try:\n'
        '        corps = demande_gemini(m, prompt, max_tokens)  # v9-v8 : niveau')],
    "D4 journal du nom muet": [(
        '        ajouter_journal(dossier, {"nom_cle_gemini": nom, "quand": maintenant(), "script": VERSION})\n',
        '        pass  # mutant\n')],
    # --- celles du contre-lecteur ---
    "C1 nom de --cle-gemini hors du contrôle de forme": [(
        '    for nom in (nom_cle_anthropic, nom_espace_anthropic, nom_cle_openai, nom_cle_mistral, nom_cle_kimi,\n'
        '                nom_cle_gemini):  # v9-v8q\n',
        '    for nom in (nom_cle_anthropic, nom_espace_anthropic, nom_cle_openai, nom_cle_mistral, nom_cle_kimi):  # mutant\n')],
    "C2 comptage : repli silencieux sur GEMINI_API_KEY si la variable nommée manque": [(
        '    cle = os.environ.get(nom_cle)\n    if not cle:\n'
        '        raise RefusCompte("COMPTE_IMPOSSIBLE", f"{nom_cle} absente (variable nommée par --cle-gemini)")\n',
        '    cle = os.environ.get(nom_cle) or os.environ.get(NOMS_CLES["gemini"])  # mutant\n    if not cle:\n'
        '        raise RefusCompte("COMPTE_IMPOSSIBLE", f"{nom_cle} absente (variable nommée par --cle-gemini)")\n')],
    "C3 relevé du lot à nom fixe": [(
        '    releve = urllib.request.Request(f"{URL_GEMINI_BASE}/{nom}", method="GET", headers={"x-goog-api-key": cle})\n',
        '    releve = urllib.request.Request(f"{URL_GEMINI_BASE}/{nom}", method="GET", '
        'headers={"x-goog-api-key": os.environ["GEMINI_API_KEY"]})  # mutant\n')],
    "C4 création du lot : en-tête porte la clé par défaut": [(
        '                                     data=json.dumps(corps, ensure_ascii=False).encode("utf-8"), method="POST",\n'
        '                                     headers={"Content-Type": "application/json", "x-goog-api-key": cle})\n'
        '    debut = HORLOGE()\n    try:\n        op = lire_json(requete, DELAI_RELEVE_S, cle)\n',
        '                                     data=json.dumps(corps, ensure_ascii=False).encode("utf-8"), method="POST",\n'
        '                                     headers={"Content-Type": "application/json", '
        '"x-goog-api-key": os.environ.get(NOMS_CLES["gemini"]) or cle})  # mutant\n'
        '    debut = HORLOGE()\n    try:\n        op = lire_json(requete, DELAI_RELEVE_S, cle)\n')],
    "C5 la valeur de la clé écrite au journal": [(
        '        ajouter_journal(dossier, {"nom_cle_gemini": nom, "quand": maintenant(), "script": VERSION})\n',
        '        ajouter_journal(dossier, {"nom_cle_gemini": nom, "valeur": os.environ.get(nom), "quand": maintenant(), '
        '"script": VERSION})  # mutant\n')],
    "C6 la valeur de la clé affichée à l'écran": [(
        '    print(f"Clé de Google : variable {nom} (nom seulement ; journalisé s\'il change)", flush=True)\n',
        '    print(f"Clé de Google : variable {nom} = {os.environ.get(nom)} (nom seulement ; journalisé s\'il change)", '
        'flush=True)  # mutant\n')],
    "C7 défaut de la ligne de commande changé (GEMINI_API_KEY_2)": [(
        '        s.add_argument("--cle-gemini", default=NOMS_CLES["gemini"],  # v9-v8q\n',
        '        s.add_argument("--cle-gemini", default="GEMINI_API_KEY_2",  # mutant\n')],
    "C8 option lue mais non transmise à la composition": [(
        '                          nom_cle_gemini=a.cle_gemini)  # v9-v8q\n',
        '                          )  # mutant\n')],
    "C9 nom journalisé avant le contrôle de --reprise": [(
        '        declarer_script(dossier, a.reprise)  # v9-v3\n        declarer_options(dossier, a)  # v9-v8k\n'
        '        declarer_cle_gemini(dossier)  # v9-v8q\n',
        '        declarer_cle_gemini(dossier)  # mutant\n        declarer_script(dossier, a.reprise)  # v9-v3\n'
        '        declarer_options(dossier, a)  # v9-v8k\n')],
    "C10 annulation du lot à nom fixe": [(
        '                                     headers={"Content-Type": "application/json", "x-goog-api-key": cle})\n'
        '    try:\n        lire_json(requete, DELAI_RELEVE_S, cle)\n        return "annulation demandée"\n',
        '                                     headers={"Content-Type": "application/json", '
        '"x-goog-api-key": os.environ["GEMINI_API_KEY"]})  # mutant\n'
        '    try:\n        lire_json(requete, DELAI_RELEVE_S, cle)\n        return "annulation demandée"\n')],
}


def appliquer(texte, remplacements):
    for ancien, neuf in remplacements:
        n = texte.count(ancien)
        if n != 1:
            raise SystemExit(f"motif trouvé {n} fois : {ancien[:80]!r}")
        texte = texte.replace(ancien, neuf)
    return texte


def charger_essais():
    spec = importlib.util.spec_from_file_location("essais_v8q_mutation", ESSAIS)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def lancer_essais(chemin):
    t = charger_essais()
    t.MOTEUR = chemin
    echecs = []
    for nom in sorted(n for n in dir(t) if n.startswith("test_")):
        try:
            getattr(t, nom)()
        except Exception as e:  # noqa: BLE001
            echecs.append(f"{nom} ({type(e).__name__})")
    return echecs


def main():
    DOSSIER.mkdir(exist_ok=True)
    base = appliquer(SOURCE.read_text(encoding="utf-8"), COUPURE)
    temoin = DOSSIER / "collisionneur_v9_v8q_temoin.py"
    temoin.write_text(base, encoding="utf-8")
    print("TÉMOIN (transport coupé, aucune mutation) :", lancer_essais(temoin) or "aucun échec")
    for i, (nom, remplacements) in enumerate(MUTATIONS.items()):
        chemin = DOSSIER / f"collisionneur_v9_v8q_mutant_{i:02d}.py"
        chemin.write_text(appliquer(base, remplacements), encoding="utf-8")
        echecs = lancer_essais(chemin)
        print(f"{'TUÉE    ' if echecs else 'SURVIT  '} {nom} : {echecs if echecs else 'aucun essai ne tombe'}")


if __name__ == "__main__":
    main()
