import csv,hashlib,os,sys
D='/home/user/controle-ia-travail/docs/notes/conscience-emergence-v1/revue-lentilles/sources'
rows=[l.rstrip('\n').split('\t') for l in open(sys.argv[1]) if l.strip()]
ref={
'arxiv-2608.25347.pdf':('SH','Lv et al.? — « Short Horizons and Sparse Concepts: a Mathematical View of the Readout in the J-lens », arXiv 2608.25347 v1, 26 août 2026'),
}
ref={}
for line in open(sys.argv[2]):
    k,f,r=line.rstrip('\n').split('\t'); ref[f]=(k,r)
out=[]
for f,u,t,*rest in rows:
    p=os.path.join(D,f)
    if not os.path.exists(p): continue
    h=hashlib.sha256(open(p,'rb').read()).hexdigest()
    k,r=ref.get(f,('—',''))
    out.append(f'| {k} | `{f}` | `{h}` | {u} | {t[11:]} | {r} |')
print('\n'.join(out))
