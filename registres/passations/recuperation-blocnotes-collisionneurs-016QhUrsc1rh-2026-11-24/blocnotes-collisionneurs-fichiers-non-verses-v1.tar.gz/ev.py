import json,sys
d=json.loads(open(sys.argv[1]).read())["ccr"]
print("first",d["first_id"],"more",d["has_more"])
for e in d["data"]:
    u=e.get("user",{}); t=json.dumps(u,ensure_ascii=False)
    if '"agent_id"' in t or "isSynthetic" in t: continue
    if any(k in t for k in ["plafond 40","signature math","forceemt","openai","vérifie sur la page"]):
        print(e["created_at"], u.get("uuid"), t[:300].replace("\n"," "))
