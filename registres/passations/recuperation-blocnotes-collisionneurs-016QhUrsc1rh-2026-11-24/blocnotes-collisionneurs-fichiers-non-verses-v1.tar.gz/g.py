import sys,re
f,pat=sys.argv[1],sys.argv[2]; w=int(sys.argv[3]) if len(sys.argv)>3 else 200
pages=open(f).read().split('\f')
for i,p in enumerate(pages):
    flat=re.sub(r'\s+',' ',p)
    for m in re.finditer(pat,flat,re.I):
        print(f"p.{i+1}:", flat[max(0,m.start()-w):m.end()+w]); print()
