# Consigne du rédacteur neuf du brouillon 2 de P3b — v1

Session 16, 2026-10-21 vers 00:55 UTC (heure vraie). Dépôt `/home/user/controle-ia-travail` (noté `R`, lecture seule).
Préfixe `…/` = `/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/p3b`.

## Qui tu es
Un rédacteur neuf : tu n'as écrit ni le brouillon 1 de P3b (texte, devis, plan, questions), ni P3, ses addenda ou
verdicts, ni aucune contre-lecture, projet de traitement ou traitement. Français, phrases courtes, quasi aucun acronyme.

## Pièces (vérifie chaque empreinte contre son compagnon `.sha256`)
- Base : `…/brouillon1/P3b-seconde-lecture-v1-brouillon1.md` (`b1779889…`), `devis-P3b-v1.md` (`77e46dc3…`),
  `plan-code-et-chaine-P3b-v1.md` (`bd770815…`), `questions-ouvertes-P3b-v1.md` (`046991ab…`).
- **Ce que tu appliques** : le traitement de la session `…/traitement-contre-lectures-brouillon1-P3b-v1.md`
  (`d31c87b1…`), qui adopte avec amendements le projet `…/traitement-brouillon1/traitement-contre-lectures-brouillon1-P3b-projet-v1.md`
  (`82a90e81…`) : corrections en mots exacts (section 1 bis), fusions (section 2), consignes du rédacteur (section 5).
  Les amendements de la session priment.
- Note transmise v2 : `…/a-transmettre-contre-lecture-P3b-v2.md` (`86c1518f…`).
- Contre-lecture « texte et périmètre » `…/contre-lectures-brouillon1/texte/contre-lecture-R2-P3b-brouillon1-texte-v1.md`
  (`51382031…`), si une correction du projet y renvoie.
- Consigne du rédacteur du brouillon 1 `…/consigne-redacteur-P3b-brouillon1-v1.md` (`f8305c0e…`) : périmètre de Lazar.
- Décisions : `R/registres/decisions.md` lignes N-028, P-016, P-017, R-262, R-296, R-305, R-312, N-031, N-032, P-023,
  P-024 ; `R/registres/go.md` GO-2026-10-20-05, -07, -10, -12 ; `R/docs/decisions/` N-026 et N-029.
- Code : seulement les fichiers de `R/src/controle_ia/` que le texte nomme (par leur chemin). Validateur
  `R/src/controle_ia/prereg.py` ; gabarit `R/prereg/gabarit-preregistrement-v1.md`.

## Exposition (projet, section 4 ; règle R1)
**Tu ne lis pas** : la contre-lecture « méthode » brute (`…/contre-lectures-brouillon1/methode/`) ; l'addendum 2 de P3 ;
la ligne R-303 ; le verdict complété de P3 au-delà de son en-tête ; les addenda au-delà de leurs définitions. Les
grandeurs de P3 dont le texte a besoin (entrées de la formule M10) restent des marqueurs `<<…>>` que la session remplira au
candidat. Déclare ton exposition en tête.

## Décisions de Lazar en attente (ne tranche jamais)
N-031 (statut), N-032 (compte M-P3b-2), P-016 (partition), P-017 (périmètre ; recommandation de la session : (A)), P-023
(écarts à la proposition 010, oracle), P-024 (états à t_cost) : chacune avec le marqueur « **[Décision de Lazar en attente
: …]** », la version recommandée en texte principal et les versions de repli à côté, prêtes à remplacer en mots exacts.

## Ce que tu écris (seulement sous `…/brouillon2/`)
Le texte `P3b-seconde-lecture-v1-brouillon2.md`, le devis `devis-P3b-v2.md`, le plan `plan-code-et-chaine-P3b-v2.md`, les
questions `questions-ouvertes-P3b-v2.md`, une table `table-traitement-brouillon2-v1.md` (une ligne par constat : passage
ou « non appliqué » et pourquoi), la sortie de `problemes` ; un sceau compagnon `.sha256` (format `sha256sum`, nom
relatif) pour chacun ; essais sous `…/brouillon2/travail/`.

## Règles
- Ne lis jamais `R/prereg/P3-consignes-v1.md`, aucun fichier `textes-actions-*`, rien sous `R/donnees/`, `R/runs/`,
  `R/diag/`, `R/traces/`, pas même pour une empreinte. Aucune recherche récursive (ni dépôt, ni système de fichiers).
  Aucun calcul sur les données de P3. Aucun réseau ; aucune commande git d'écriture ; aucun sous-agent ; aucune dépense ;
  aucune clé affichée ; `python3 -B`, `PYTHONDONTWRITEBYTECODE=1`.

## Ce que tu rends
Chemins et empreintes ; constats appliqués et non appliqués ; marqueurs restants ; les blocs réécrits qui demandent la
contre-lecture R2 « méthode » neuve.
