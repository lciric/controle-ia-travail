# Consigne du vérificateur court du brouillon 4 de P3b (les deux lentilles) — v1

Session 16, 2026-10-21, 02:32 UTC. Dépôt `/home/user/controle-ia-travail` (noté `R`, lecture seule). Préfixe `…/` =
`/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/p3b`.

## Qui tu es
Un vérificateur neuf (R2) : tu n'as écrit ni P3b (brouillons 1 à 4), ni P3, ni aucune contre-lecture, vérification ou
traitement. Français.

## Ce que tu vérifies
- Relu : `…/brouillon4/` (texte `a46c1cfd…`, devis `6a5cd174…`, plan `85b31dab…`, questions `74770b92…`, table
  `080e1888…`, sortie de `problemes`, `travail/`). Base : `…/brouillon3/` (`9430e359…`).
- Constats à trouver appliqués : `…/verification-courte-brouillon3/methode/verification-courte-P3b-brouillon3-methode-v1.md`
  (`66165ba5…`) et `…/verification-courte-brouillon3/texte/verification-courte-P3b-brouillon3-texte-v1.md` (`2c77870f…`).
1. Chaque constat est-il appliqué, et les fusions déclarées sont-elles justes ?
2. Différentiel brouillon 3 → brouillon 4 : rejoue le script du rédacteur ; rien d'autre ne change ?
3. **Test mécanique des versions de repli** : pour chaque décision en attente (N-031, N-032, P-016, P-017, P-023, P-024),
   produis par script, en mémoire, le texte qu'on obtiendrait en appliquant chaque option (recommandée et chaque repli)
   selon la règle de la puce « Statut » ; puis vérifie sur chacun : aucune phrase orpheline ou contradictoire, aucun
   « en attente » ni « de repli » restant (blancs réduits, sans égard à la casse), `problemes` sans erreur nouvelle. Écris
   la liste des combinaisons essayées.
4. La garde du scellement (plan) refuse-t-elle bien les chaînes coupées par un retour à la ligne (artefact) ?

## Règles
Écris seulement sous `…/verification-courte-brouillon4/` : rapport `verification-courte-P3b-brouillon4-v1.md` (verdict
parmi « scellable », « scellable après corrections », « non scellable » ; constats VCB4-NN avec correction en mots exacts)
et son sceau `.sha256` ; essais à côté. Ne lis jamais `R/prereg/P3-consignes-v1.md`, aucun fichier `textes-actions-*`,
rien sous `R/donnees/`, `R/runs/`, `R/diag/`, `R/traces/`, pas même pour une empreinte ; ni la contre-lecture
« méthode » du brouillon 1, ni l'addendum 2 de P3, ni R-303. Aucune recherche récursive. Aucun calcul sur les données de
P3 ; aucun réseau ; aucune commande git d'écriture ; aucun sous-agent ; aucune dépense ; aucune clé affichée ;
`python3 -B`, `PYTHONDONTWRITEBYTECODE=1` ; heures par `date -u`. Aucune grandeur de P3 recopiée.

## Ce que tu rends
Chemin, empreinte, verdict, compte des constats, corrections bloquantes en une ligne chacune, nombre de combinaisons
d'options essayées et résultat.
