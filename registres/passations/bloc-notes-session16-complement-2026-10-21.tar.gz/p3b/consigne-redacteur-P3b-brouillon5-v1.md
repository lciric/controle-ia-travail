# Consigne du rédacteur neuf du brouillon 5 de P3b — v1

Session 16, 2026-10-21, 03:02 UTC. Dépôt `/home/user/controle-ia-travail` (noté `R`, lecture seule). Préfixe `…/` =
`/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/p3b`.

## Qui tu es
Un rédacteur neuf : tu n'as écrit ni les brouillons 1 à 4 de P3b, ni P3, ni aucune contre-lecture ou vérification.

## Décision de la session (routine : forme du document)
Les versions de repli écrites dans le texte produisent des textes contradictoires selon les combinaisons (vérification
`…/verification-courte-brouillon4/verification-courte-P3b-brouillon4-v1.md`, `dffab4ed…` : aucune des 972 combinaisons
n'est propre). **Le brouillon 5 ne porte plus que la version recommandée** de chaque décision de Lazar en attente (N-031,
N-032, P-016, P-017, P-023, P-024), précédée de son marqueur « [Décision de Lazar en attente : …] ». Chaque autre option
est sortie du texte et écrite dans un fichier à part, `…/brouillon5/options-non-recommandees-P3b-v1.md` : pour chaque
option, la liste exacte des remplacements (ancien texte du brouillon 5, trouvé une seule fois → nouveau texte) qui
donnent le texte complet sous cette option seule, avec la règle d'ordre de VCB4-01 si deux options sont retenues
ensemble. Ces remplacements ne seront appliqués, puis vérifiés par un sous-agent neuf, que si Lazar retient l'option.
Le scellement reste refusé tant qu'un marqueur reste (garde du plan, blancs réduits, sans égard à la casse ; VCB4-09 :
tabulation, retour chariot et espace insécable compris).

## Ce que tu fais
- Base : `…/brouillon4/` (texte `a46c1cfd…`, devis `6a5cd174…`, plan `85b31dab…`, questions `74770b92…`, table `080e1888…`).
- Applique la décision ci-dessus, puis les constats du rapport `dffab4ed…` qui touchent la version recommandée ou la
  garde (VCB4-04 : partition écrite une seule fois ; VCB4-09) ; ceux qui ne touchent que les replis passent dans le
  fichier des options (VCB4-01 à -03, -05 à -08), corrigés comme le rapport le dit.
- Par script, par remplacements exacts. Vérifie toi-même, en mémoire, chaque option du fichier appliquée seule au brouillon
  5 : aucun « en attente » ni « de repli » restant hors du marqueur de la décision concernée, `problemes` sans erreur neuve.
- Écris sous `…/brouillon5/` : `P3b-seconde-lecture-v1-brouillon5.md`, `devis-P3b-v5.md`, `plan-code-et-chaine-P3b-v5.md`,
  `questions-ouvertes-P3b-v5.md`, `options-non-recommandees-P3b-v1.md`, `table-traitement-brouillon5-v1.md`, sortie de
  `problemes` ; sceau compagnon `.sha256` pour chacun ; essais sous `…/brouillon5/travail/`.

## Exposition et règles
Comme pour les brouillons précédents : tu ne lis ni la contre-lecture « méthode » du brouillon 1, ni l'addendum 2 de P3,
ni R-303, ni le verdict complété au-delà de son en-tête. Ne lis jamais `R/prereg/P3-consignes-v1.md`, aucun fichier
`textes-actions-*`, rien sous `R/donnees/`, `R/runs/`, `R/diag/`, `R/traces/`, pas même pour une empreinte. Aucune
recherche récursive (pas de `find`, pas de `grep -r`, même dans ton dossier). Aucun calcul sur les données de P3 ; aucun
réseau ; aucune commande git ; aucun sous-agent ; aucune dépense ; aucune clé affichée ; `python3 -B`,
`PYTHONDONTWRITEBYTECODE=1` ; heures par `date -u`.

## Ce que tu rends
Chemins et empreintes ; constats appliqués ; résultat de ta vérification des options.
