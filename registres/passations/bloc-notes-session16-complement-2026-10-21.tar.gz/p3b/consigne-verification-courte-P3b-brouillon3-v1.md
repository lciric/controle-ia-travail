# Consigne des deux vérificateurs courts du brouillon 3 de P3b — v1

Session 16, 2026-10-21, 01:35 UTC. Dépôt `/home/user/controle-ia-travail` (noté `R`, lecture seule). Préfixe `…/` =
`/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/p3b`.

## Qui tu es
Un vérificateur neuf (R2) : tu n'as écrit ni P3b (brouillons 1 à 3), ni P3, ni aucune contre-lecture ou traitement.

## Pièces (empreintes contre compagnons)
- Relu : `…/brouillon3/` (texte `9430e359…`, devis `3dc920f8…`, plan `d950e428…`, questions `aff0a7ed…`, table
  `89e67f7f…`, sortie de `problemes`, essais `travail/`). Base : `…/brouillon2/` (`64c5adad…`).
- Ce qu'il devait appliquer : `…/traitement-contre-lectures-brouillon2-P3b-v1.md` et les rapports
  `…/contre-lectures-brouillon2/methode/contre-lecture-R2-P3b-brouillon2-methode-v1.md` (`9c312900…`),
  `…/contre-lectures-brouillon2/texte/contre-lecture-R2-P3b-brouillon2-texte-v1.md` (`c2f68f5a…`).
- Décisions : `R/registres/decisions.md` N-028, N-031, N-032, P-016, P-017, P-023, P-024 ; validateur `R/src/controle_ia/prereg.py`.

## Lentilles
- **« méthode »** (dossier `…/verification-courte-brouillon3/methode/`) : chaque correction des constats « méthode » est-elle
  appliquée et juste ? En particulier CR2-01 (T4 résiduel ; refais l'essai du rapport si besoin, données inventées),
  CR2-03 (table D), CR2-04 (item (vi)), et le point d'interprétation de methode-11 dans le repli (B) de P-023. Les cinq
  réserves déclarées par le rédacteur (table) sont-elles bloquantes ?
- **« texte »** (dossier `…/verification-courte-brouillon3/texte/`) : chaque correction des constats « texte » est-elle
  appliquée en mots exacts ? Les versions de repli sont-elles complètes et remplaçables en mots exacts ? Le scellement
  refuse-t-il bien « de repli » et « en attente » (sans égard à la casse ni au nombre) ? Différentiel brouillon 2 →
  brouillon 3 : rien d'autre ne change ? Sortie de `problemes` rejouée.

## Règles
- Écris seulement dans ton dossier : rapport `verification-courte-P3b-brouillon3-<lentille>-v1.md` (verdict parmi
  « scellable », « scellable après corrections », « non scellable » ; constats VCP3b-<lentille>-NN avec correction en
  mots exacts) et son sceau `.sha256`.
- Ne lis jamais `R/prereg/P3-consignes-v1.md`, aucun fichier `textes-actions-*`, rien sous `R/donnees/`, `R/runs/`,
  `R/diag/`, `R/traces/`, pas même pour une empreinte. Ni la contre-lecture « méthode » du brouillon 1, ni l'addendum 2
  de P3, ni R-303. Aucune recherche récursive (ni `grep -r`, ni `find`). Aucun calcul sur les données de P3 ; aucun
  réseau ; aucune commande git d'écriture ; aucun sous-agent ; aucune dépense ; aucune clé affichée ; `python3 -B`,
  `PYTHONDONTWRITEBYTECODE=1` ; heures par `date -u`. Aucune grandeur de P3 recopiée.

## Ce que tu rends
Chemin, empreinte, verdict, compte des constats, corrections bloquantes en une ligne chacune.
