# Consigne du préparateur neuf du traitement des contre-lectures du brouillon 1 de P3b — v1

Session 16, 2026-10-21 vers 00:20 UTC. Dépôt `/home/user/controle-ia-travail` (noté `R`, lecture seule). Préfixe `…/` =
`/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/p3b`.

## Qui tu es
Un préparateur neuf : tu n'as écrit ni P3b (brouillon, devis, plan, questions), ni P3, ni ses addenda ou verdicts, ni
aucune contre-lecture. Tu prépares le **projet** de traitement ; la session le relit, le corrige et le scelle sous son
nom. Français, phrases courtes, quasi aucun acronyme.

## Pièces (vérifie chaque empreinte contre son compagnon `.sha256`)
- Contre-lectures à traiter : `…/contre-lectures-brouillon1/methode/contre-lecture-R2-P3b-brouillon1-methode-v1.md`
  (`a4f6a7d8…`, 20 constats) ; `…/contre-lectures-brouillon1/texte/contre-lecture-R2-P3b-brouillon1-texte-v1.md`
  (`51382031…`, 25 constats). Lis-les en entier.
- Relu : `…/brouillon1/P3b-seconde-lecture-v1-brouillon1.md` (`b1779889…`), `devis-P3b-v1.md` (`77e46dc3…`),
  `plan-code-et-chaine-P3b-v1.md` (`bd770815…`), `questions-ouvertes-P3b-v1.md` (`046991ab…`).
- Consigne du rédacteur (périmètre de Lazar) : `…/consigne-redacteur-P3b-brouillon1-v1.md` (`f8305c0e…`).
- Note transmise : `…/a-transmettre-contre-lecture-P3b-v1.md` (`23c742be…`) et la correction qu'en demande VV5-sens-09
  (`/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/revue-detection/verification-v5-sens/verification-v5-sens-v1.md`,
  constats VV5-sens-03 et VV5-sens-09 seulement).
- Décisions : `R/registres/decisions.md` lignes N-028, P-016, P-017, R-262, R-296, R-303, R-305 ; `R/registres/go.md`
  GO-2026-10-20-05, -07, -10, -12 ; `R/docs/decisions/` N-026 et N-029. Proposition 010 de Gemini si une contre-lecture
  la cite (chemin qu'elle donne).

## Ce que tu écris
`…/traitement-contre-lectures-brouillon1-P3b-projet-v1.md`, avec :
1. **Table** : une ligne par constat (CR-P3b-methode-NN, CR-P3b-texte-NN) : décision proposée parmi « accepté »,
   « accepté modifié » (dire la modification), « écarté » (raison vérifiée dans une pièce), « nœud de Lazar » ; où il
   s'applique (texte, devis, plan, questions) ; correction en mots exacts reprise du rapport, ou la tienne si tu modifies.
2. **Conflits** entre les deux lentilles (par exemple : Bonferroni, CR-methode-11 contre CR-texte-09 ; statut de P3b ;
   M-P3b-2) et ta proposition pour chacun.
3. **Nœuds de Lazar**, chacun au format : décision en une phrase ; enjeu ; 2 ou 3 options (avantage, inconvénient) ;
   recommandation et confiance ; défaut sous 48 heures ou « aucun » (nœud). Au moins : statut de P3b (CR-texte-01, N-028,
   R-262) ; M-P3b-2 et Q-03 (CR-texte-08, règle R1) ; P-016 (partition) ; Q-01, Q-02, Q-21 ; divergence avec P-017
   (VV5-sens-03 : options (A), (B), (C), (C′)) ; écart à la proposition 010 (CR-texte-02). Regroupe ce qui peut l'être.
4. **Exposition** : CR-texte-24 (signe de P3-P2) : le rédacteur du brouillon 2 doit-il le voir ? Propose, avec la raison
   (règle R1 : aucune grandeur neuve lue avant scellement ; les grandeurs de P3 déjà publiées dans son verdict).
5. **Ce que le rédacteur du brouillon 2 doit faire**, en liste ordonnée, et ce qui exige une contre-lecture R2 neuve du
   brouillon 2 (la lentille « méthode » le demande pour quatre blocs).
6. **Note transmise v2** : le texte exact d'une `a-transmettre-contre-lecture-P3b-v2.md` corrigée selon VV5-sens-09.

Un sceau compagnon `.sha256` (format `sha256sum`, nom relatif). Écris seulement sous `…/traitement-brouillon1/` (le projet,
son sceau, tes essais).

## Règles
- Ne lis jamais `R/prereg/P3-consignes-v1.md`, aucun fichier `textes-actions-*`, rien sous `R/donnees/`, `R/runs/`,
  `R/diag/`, `R/traces/`, pas même pour une empreinte. Aucune recherche récursive (ni dépôt, ni système de fichiers).
  Aucun calcul sur les données de P3 (R1). Aucune commande git d'écriture ; aucun sous-agent ; aucune dépense ; aucune
  clé affichée ; aucun réseau ; `python3 -B`, `PYTHONDONTWRITEBYTECODE=1`.
- Déclare en tête ton exposition (les grandeurs de P3 que tu as vues dans les pièces) sans en recopier aucune.

## Ce que tu rends
En réponse finale : chemin et empreinte du projet ; compte des décisions proposées (accepté, modifié, écarté, nœud) ; la
liste des nœuds de Lazar en une ligne chacun ; les conflits entre lentilles et ta proposition.
