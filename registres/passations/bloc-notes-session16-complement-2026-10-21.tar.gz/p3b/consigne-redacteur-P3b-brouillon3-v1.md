# Consigne du rédacteur neuf du brouillon 3 de P3b — v1

Session 16, 2026-10-21, 01:16 UTC. Dépôt `/home/user/controle-ia-travail` (noté `R`, lecture seule). Préfixe `…/` =
`/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/p3b`.

## Qui tu es
Un rédacteur neuf : tu n'as écrit ni les brouillons 1 et 2 de P3b, ni P3, ni aucune contre-lecture ou traitement. Français.

## Ce que tu fais
- Base : `…/brouillon2/` (texte `64c5adad…`, devis `7dd3cfee…`, plan `fd82f2f6…`, questions `417a111e…`, table).
- Applique `…/traitement-contre-lectures-brouillon2-P3b-v1.md` (sceau à côté) : tous les constats des deux rapports
  `…/contre-lectures-brouillon2/methode/contre-lecture-R2-P3b-brouillon2-methode-v1.md` (`9c312900…`) et
  `…/contre-lectures-brouillon2/texte/contre-lecture-R2-P3b-brouillon2-texte-v1.md` (`c2f68f5a…`), en mots exacts quand
  ils en donnent. Chaque changement par remplacement exact (ancien texte trouvé une seule fois, sinon arrêt), par script.
- Décisions de Lazar en attente (N-031, N-032, P-016, P-017, P-023, P-024) : jamais tranchées ; versions de repli
  complètes et remplaçables en mots exacts, comme les rapports le demandent.
- Écris sous `…/brouillon3/` : `P3b-seconde-lecture-v1-brouillon3.md`, `devis-P3b-v3.md`, `plan-code-et-chaine-P3b-v3.md`,
  `questions-ouvertes-P3b-v3.md`, `table-traitement-brouillon3-v1.md` (une ligne par constat), sortie de `problemes` ;
  sceau compagnon `.sha256` pour chacun ; essais sous `…/brouillon3/travail/`.

## Exposition et règles
Comme pour le brouillon 2 (`…/consigne-redacteur-P3b-brouillon2-v1.md`, section « Exposition ») : tu ne lis ni la
contre-lecture « méthode » brute du brouillon 1, ni l'addendum 2 de P3, ni R-303, ni le verdict complété au-delà de son
en-tête. Les rapports du brouillon 2 ne recopient aucune grandeur de P3 : tu peux les lire. Ne lis jamais
`R/prereg/P3-consignes-v1.md`, aucun fichier `textes-actions-*`, rien sous `R/donnees/`, `R/runs/`, `R/diag/`,
`R/traces/`, pas même pour une empreinte. Aucune recherche récursive (ni `grep -r`, ni `find`). Aucun calcul sur les
données de P3 ; aucun réseau ; aucune commande git d'écriture ; aucun sous-agent ; aucune dépense ; aucune clé affichée ;
`python3 -B`, `PYTHONDONTWRITEBYTECODE=1` ; heures lues par `date -u`.

## Ce que tu rends
Chemins et empreintes ; constats appliqués et non appliqués ; marqueurs restants.
