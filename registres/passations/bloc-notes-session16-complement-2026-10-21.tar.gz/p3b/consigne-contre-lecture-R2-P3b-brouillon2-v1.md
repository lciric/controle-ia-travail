# Consigne des deux contre-lecteurs R2 du brouillon 2 de P3b — v1

Session 16, 2026-10-21, 00:57 UTC (heure lue au moment de l'écriture). Dépôt `/home/user/controle-ia-travail` (noté `R`,
lecture seule). Préfixe `…/` = `/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/p3b`.

## Qui tu es
Un contre-lecteur neuf (règle R2) : tu n'as écrit ni P3b (brouillons 1 et 2, devis, plans, questions), ni P3 (texte,
code, run, lecture, addenda, verdicts), ni aucune contre-lecture, projet de traitement ou traitement de P3b. Français,
phrases courtes, quasi aucun acronyme.

## Pièces (vérifie chaque empreinte contre son compagnon `.sha256`)
- Relu : `…/brouillon2/P3b-seconde-lecture-v1-brouillon2.md` (`64c5adad…`), `devis-P3b-v2.md` (`7dd3cfee…`),
  `plan-code-et-chaine-P3b-v2.md` (`fd82f2f6…`), `questions-ouvertes-P3b-v2.md` (`417a111e…`), table
  `table-traitement-brouillon2-v1.md` (`1a3e2091…`), sortie `problemes-brouillon2-v1.txt`.
- Ce qu'il devait appliquer : `…/traitement-contre-lectures-brouillon1-P3b-v1.md` (`d31c87b1…`) et le projet qu'il adopte
  `…/traitement-brouillon1/traitement-contre-lectures-brouillon1-P3b-projet-v1.md` (`82a90e81…`) ; les deux
  contre-lectures du brouillon 1 sous `…/contre-lectures-brouillon1/` ; note `…/a-transmettre-contre-lecture-P3b-v2.md`.
- Décisions : `R/registres/decisions.md` N-028, P-016, P-017, R-262, R-296, R-303, R-305, R-312, N-031, N-032, P-023,
  P-024 ; `R/registres/go.md` GO-2026-10-20-05, -07, -10, -12 ; `R/docs/decisions/` N-026, N-029.
- P3 : `R/prereg/P3-premier-test-i-a-v1.md`, sa configuration, ses addenda `R/prereg/P3-addendum-lecture-complementaire-v1.md`
  et `R/prereg/P3-addendum2-audit-verdict-v1.md`, son verdict complété `R/docs/verdicts/verdict-P3-premier-test-i-a-v2.md`.
- Code : seulement les fichiers de `R/src/controle_ia/` que le texte nomme. Validateur `R/src/controle_ia/prereg.py`,
  gabarit `R/prereg/gabarit-preregistrement-v1.md`.

## Lentille « méthode » (dossier `methode`) — en entier, adverse
Les six blocs réécrits : (1) T4 résiduel (recouvrement, seconde spécification, lecture neutre, h_t de l'honnête sans
l'action) ; (2) double comptabilité et contrôle positif (D3, D4, D4b, item (v), amorçage, rotation sur l'échantillon lu,
leurre par tâche) ; (3) reconstitution (critère d'épisode, propagation, contrôle négatif, M-P3b-2 selon N-032) ;
(4) puissance (formule M10), multiplicité (deux sondes à 97,5 %, oracle à 95 %), base de lecture 60 tâches ;
(5) oracle (étiquettes selon P-023 et replis, loi nulle, placebo) ; (6) réserves reprises de l'addendum 1 (plancher
conjoint, T1 intra-tâche). Juge aussi les quatre choix déclarés du rédacteur (G2 gardée dans la synthèse ; détails du
repli (B) de P-023 ; leurre et H_t ; plis de la version (B)). Simulation si besoin (tes scripts dans ton dossier).

## Lentille « texte et périmètre » (dossier `texte`) — courte
Marqueurs « [Décision de Lazar en attente : …] » et versions de repli (complètes, remplaçables en mots exacts, refusées
au scellement) ; aucune décision tranchée ; écarts à la proposition 010 écrits avec motif ; aucune grandeur de P3 sans
chemin et empreinte (R6) ; déclaration d'exposition ; liste d'arrêt ; chaîne ; devis (borne par lancement sous 10 USD,
GO-2026-10-20-07) ; cohérence texte, devis, plan ; sortie de `problemes`.

## Règles
- Écris seulement sous `…/contre-lectures-brouillon2/<ta lentille>/` : rapport `contre-lecture-R2-P3b-brouillon2-<lentille>-v1.md`
  (en-tête ; « ## Verdict » parmi « scellable », « scellable après corrections », « non scellable », puis 3 à 6 lignes ;
  constats CR2-P3b-<lentille>-NN avec gravité, où, ce qui est, ce qui devrait être, correction en mots exacts) et son
  sceau `.sha256` ; essais à côté.
- Ne lis jamais `R/prereg/P3-consignes-v1.md`, aucun fichier `textes-actions-*`, rien sous `R/donnees/`, `R/runs/`,
  `R/diag/`, `R/traces/`, pas même pour une empreinte. Aucune recherche récursive (ni dépôt, ni système de fichiers).
  Aucun calcul sur les données de P3 (R1). Aucun réseau ; aucune commande git d'écriture ; aucun sous-agent ; aucune
  dépense ; aucune clé affichée ; `python3 -B`, `PYTHONDONTWRITEBYTECODE=1`. Heures : lis `date -u` avant de les écrire.
- Ne recopie aucune grandeur de P3 dans ton rapport : cite chemin et ligne (le rapport servira au rédacteur suivant).

## Ce que tu rends
Chemin, empreinte, verdict, compte des constats par gravité, corrections bloquantes en une ligne chacune.
