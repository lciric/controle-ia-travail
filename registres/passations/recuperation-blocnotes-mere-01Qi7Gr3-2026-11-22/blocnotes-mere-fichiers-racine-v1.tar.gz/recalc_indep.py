import math
# volumes depuis l'esquisse v1 : n=60, e=1, nf=20, relectures 3x20
n,e,nf,rel=60,1,20,60
A=B=2*n*e; C=nf*e
ens1=A+C+rel; ens2=B
assert (A+B+C, ens1+ens2)==(260,320)
assert 4*n*e+nf*e+rel==320
# prix par question
def q(pe,ps,ti,to,f): return (ti*pe+to*ps)*f/1e6
opus_a=q(4,20,4000,500,1.05); opus_p=q(4,20,6000,2000,1.15)
mis_a=q(.77,2.31,4000,3000,1.05); mis_rp=q(1.54,4.62,6000,9000,1.15); mis_p=q(.77,2.31,6000,9000,1.15)
print('par question', round(opus_a,4),round(opus_p,4),round(mis_a,4),round(mis_rp,4), round(opus_a+mis_a,4), round(opus_p+mis_rp,4))
P=opus_p+mis_rp; Att=opus_a+mis_a
L1=math.ceil(ens1*8*P); L2=math.ceil(ens2*8*P); E=math.ceil(12*8*P)
def lanc(N):
    h=N*42.8/3600+1; hb=N*40.2/3600+1
    return hb*1.1833+1, h*1.38+2, h*4*1.38+4, h
l1=lanc(140); l2=lanc(120)
carte=math.ceil(l1[2])+math.ceil(l2[2])
print('carte', [round(x,2) for x in l1], [round(x,2) for x in l2], carte)
print('lectures', L1, L2, 'essai', E, 'total plafond', carte+L1+L2+E)
centre=(l1[0]+l1[1]+l2[0]+l2[1])/2 + 320*6*Att + 12*6*Att
print('attendu centre', round(centre,2), 'rapport', round((carte+L1+L2+E)/centre,2))
# plafonds par file et par étape (absents du devis)
for nom,c in (('opus',opus_p),('mistral repli',mis_rp)):
    print(nom,'étape1',round(ens1*8*c,2),'étape2',round(ens2*8*c,2),'essai',round(12*8*c,2))
# variante 100 par dose
A2=B2=200; ens1b=A2+C+rel; ens2b=B2
print('variante', A2+B2+C, ens1b+ens2b, math.ceil(lanc(220)[2])+math.ceil(lanc(200)[2]), math.ceil(ens1b*8*P)+math.ceil(ens2b*8*P))
# marge de change 5 % sur la part Mistral au plafond
mis_share=(ens1+ens2+12)*8*mis_rp
print('part Mistral au plafond', round(mis_share,2), '5 %', round(.05*mis_share,2))
print('garde envoi opus', (24000*4+8192*20)/1e6, 'mistral', (24000*1.54+16384*4.62)/1e6)
print('opus effort haut (sortie x4 de l attendu, S)', round(q(4,20,4000,2000,1.05),4))
