import json
E = json.load(open("edits.json", encoding="utf-8"))
notes = {
"1": "Portée. Le texte de la correction remplace la délimitation entière : la suite de l'ancienne phrase, « jusqu'à la balise suivante ou la fin de section », est retirée avec « délimité par la balise du script », car le texte neuf dit où finit le duel (« au duel suivant ou à la fin de la section ») ; la phrase « Les pistes finales… » est gardée. Restent à l'identique, hors de la lettre de la correction : « la balise des duels y est trouvée » (article 3), « Balise introuvable » (article 12), « Découpage par balise » et « pour les balises » (sections 2 et 3) — à trancher par Fable.",
"2": "Portée.",
"3": "Portée, ajoutée à la fin de la définition des mots pleins. L'annexe des mots vides n'existe pas encore dans la pièce : à joindre avant le scellement.",
"4": "Portée, en puce nouvelle à la fin de l'article 6.",
"5": "Portée, en puce nouvelle après « Gain de références » à l'article 8 ; expression copiée à l'identique.",
"6a": "Portée (seuil de révision calé sur l'épreuve d'identité perturbée, proposition du contre-lecteur).",
"6b": "Portée : l'épreuve d'identité perturbée est ajoutée à l'article 9, avant « Si l'une échoue, arrêt. ».",
"6c": "Portée (seuil de nouveauté calé sur l'épreuve d'identité perturbée).",
"7a": "Portée. « (pièce 2) » reste accolé à « liste scellée » ; « cellules d'Argon exclues » suit, mot pour mot.",
"7b": "Portée, en puce nouvelle à la fin de l'article 10.",
"8": "Portée, en phrase sous le tableau de l'article 11 ; guillemets rendus en « ».",
"9": "Portée, à la suite de « Ses données sont exclues. ».",
"10": "Portée (combinaison de M1 selon la proposition du contre-lecteur), en puce nouvelle sous M1.",
"11": "Portée.",
"12": "Portée : « à titre indicatif » supprimé. La phrase « Les taux de reprise sont des prévisions scellées. » de la remarque est lue comme sa justification, non comme un texte à ajouter (elle n'est pas entre guillemets, à la différence des ajouts) ; la ligne figure déjà sous « Prévisions scellées ».",
"13": "Portée, à la fin de la ligne du plan qui décrit les vingt exécutions.",
"14": "Portée ; majuscule initiale mise pour l'accord avec les autres puces de la liste d'arrêt.",
"15": "Portée au point 5 de la pièce 2b (restriction aux textes écrits par le programme et garde de motifs, propositions du contre-lecteur), en remplacement et en puce nouvelle. Non touchée : la ligne de la liste d'arrêt de la pièce 2a, « Élément de la liste scellée retrouvé dans une invite. », que le constat 5 cite mais qu'aucune correction ne vise par sa lettre — à trancher par Fable.",
"16": "Portée, en puce nouvelle à la fin du point 5.",
"17": "Portée (contre-exemple de la rampe, proposition du contre-lecteur). Vérification de calcul : aire = 0,01 (triangle sur [0 ; 0,02]) + 0,98 = 0,99 ; valeur à 0,01 : 0,5.",
"18": "Portée (lieu d'injection dans la section qui vise le destinataire, proposition du contre-lecteur) ; les guillemets intérieurs de la remarque sont rendus en « ».",
"19": "Portée, après la phrase sur la vérification d'absence. La phrase « Elles ne désignent personne. », que la remarque sur les références inventées dit non garantie, reste à l'identique faute de correction qui la vise — à trancher par Fable.",
"20": "Portée : « liste scellée » remplacée par « liste ci-dessous » ; l'ajout est mis en sous-puce après la règle de reprise, en minuscule et terminé par « ; » comme ses voisines.",
"21": "Portée (normalisation des nombres, proposition du contre-lecteur), en sous-puce finale de la règle du chiffre ; guillemets des marqueurs rendus en « ».",
"22": "Portée (déclaration du délai mode contre délai, proposition du contre-lecteur), à la fin du paragraphe « Asymétrie ».",
}
out = ["# Table des corrections de la réponse 10 (pièces de la comparaison essaim contre isolé)", "",
"22 novembre 2026, Opus 5.5. Remarques : `docs/notes/demandes-fable-api-2026-11-22-v1/contre-lecture-reponse-10-v1.md` (sha256 a19a6c62bbfd48806bc660a2aa14a73771836cdab99146a8a14e9f8090dae30d). Source : `reponse-10/relecture-fable-api.md` (sha256 f41a63d5400cd4b99241049c887eff4f181e4635aefced3f20f5cbfb8c8ad067). Résultat : `pieces-comparaison-essaim-v2.md`.", "",
"Bilan : 22 corrections portées sur 22, en 25 remplacements (la 6 en trois, la 7 en deux) ; aucune non portée. Quatre points restés à l'identique hors de la lettre des corrections sont signalés pour Fable (corrections 1, 15, 19, et 12 pour la lecture de sa seconde phrase).", ""]
for num, avant, apres in E:
    n = str(num)
    out += [f"## Correction {n}", "", "Avant :", "", "~~~", avant.rstrip("\n"), "~~~", "", "Après :", "", "~~~", apres.rstrip("\n"), "~~~", "", notes[n], ""]
open("/home/user/controle-ia-travail/docs/notes/demandes-fable-api-2026-11-22-v1/table-corrections-reponse-10-v1.md", "w", encoding="utf-8").write("\n".join(out))
