import json, sys
from datetime import datetime
def t(s):
    try: return datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ")
    except Exception: return None
tot = 0.0
for l in sys.stdin:
    l = l.strip()
    if not l: continue
    e = json.loads(l)
    if "essai" in e:
        u = e.get("usage") or {}
        d = (t(e.get("fin_utc")) - t(e.get("debut"))).total_seconds() if t(e.get("fin_utc")) and t(e.get("debut")) else None
        tot += e.get("cout_usd", 0.0)
        print(f"{e['cellule']:<34} e{e['essai']} {e['statut']:<24} fin={e.get('fin')} max={e.get('max_tokens')} prov={e.get('provision_reflexion')} "
              f"in={u.get('entree')} refl={u.get('reflexion')} vis={u.get('sortie_visible')} sortie={u.get('sortie')} ecart={u.get('ecart_total')} "
              f"car={e.get('caracteres')} marq={e.get('marqueur_fin')} cout={e.get('cout_usd')} pire={e.get('cout_pire_usd')} dur={d} "
              f"deb={e.get('debut')} scr={e.get('sha256_script','')[:8]} {e.get('script')} echec={(e.get('echec') or '')[:160]}")
    else:
        if "cout_usd" in e: tot += e.get("cout_usd", 0.0)
        ee = {k: v for k, v in e.items() if k not in ("notes", "texte")}
        print("  ##", json.dumps(ee, ensure_ascii=False)[:400])
print(f"TOTAL cout_usd = {tot:.4f}")
