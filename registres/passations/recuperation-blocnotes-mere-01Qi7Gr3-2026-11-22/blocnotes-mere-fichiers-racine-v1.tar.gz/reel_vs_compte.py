import json, sys, collections
reel = {"claude-fable-5-2": (8.0, 40.0), "claude-opus-5-5": (4.0, 20.0), "gemini-4-argon": (2.0, 10.0),
        "gemini-4-carbon": (2.0, 10.0), "gpt-6.2-astra": (10.0, 50.0)}
for chemin in sys.argv[1:]:
    par = collections.defaultdict(lambda: [0.0, 0.0, 0])
    for l in open(chemin, encoding="utf-8"):
        if not l.strip(): continue
        e = json.loads(l)
        if "essai" not in e: continue
        u = e.get("usage") or {}
        m = e["modele_demande"]
        if e["statut"] == "INTERROMPU" and not (u.get("sortie") or u.get("entree")):
            r = 0.0  # refus de crédit dans le flux : rien de facturé (à confirmer à la console)
        else:
            pin, pout = reel[m]
            r = (u.get("entree", 0) or 0) / 1e6 * pin + (u.get("sortie", 0) or 0) / 1e6 * pout
        par[m][0] += e.get("cout_usd", 0); par[m][1] += r; par[m][2] += 1
    tc = sum(v[0] for v in par.values()); tr = sum(v[1] for v in par.values())
    print(chemin.split('/')[-2][:55], f"compté={tc:.2f} réel≈{tr:.2f}", {k.split('-')[1] if 'claude' in k else k.split('-')[-1]: (round(v[0],2), round(v[1],2), v[2]) for k, v in par.items()})
