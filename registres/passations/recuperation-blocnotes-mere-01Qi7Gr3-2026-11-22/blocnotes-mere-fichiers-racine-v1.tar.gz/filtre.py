import sys,re
MOTIFS=re.compile(r"consigne-privee|conception-ii-b|ii-b-saboteur|compte-4-v1|R-2059|archives-reponses-modeles|\b7a\b|\b7b\b|T0\.6|[ée]tape B\b|B bis|P3-bis|barreau 5|v[ée]rit[ée]|rendu|scores", re.I)
fichier=sys.argv[1]; lignes=open(fichier,encoding='utf-8').read().split('\n')
mots=sys.argv[3].split('|') if len(sys.argv)>3 else []
for spec in sys.argv[2].split(','):
    a,_,b=spec.partition('-'); a=int(a); b=int(b) if b else a
    for n in range(a,b+1):
        t=lignes[n-1]
        if not MOTIFS.search(t): print(f"{n}: {t}")
        else:
            out=[]
            for m in mots:
                for mm in re.finditer(re.escape(m),t):
                    w=t[max(0,mm.start()-int(sys.argv[4] if len(sys.argv)>4 else 160)):mm.end()+int(sys.argv[4] if len(sys.argv)>4 else 160)]
                    out.append(w if not MOTIFS.search(w) else "[fenêtre masquée]")
            print(f"{n}: [LIGNE MASQUÉE, {len(t)} signes] "+" || ".join(out))
