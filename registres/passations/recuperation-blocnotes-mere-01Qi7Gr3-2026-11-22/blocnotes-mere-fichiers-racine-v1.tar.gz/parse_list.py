import re,sys,html
seen={}
for f in sys.argv[2:]:
    t=open(f,encoding='utf-8',errors='replace').read()
    for m in re.finditer(r'arXiv:(\d{4}\.\d{5})\s*</a>.*?<div class=.list-title mathjax.>\s*<span class=.descriptor.>Title:</span>\s*(.*?)\s*</div>',t,re.S):
        seen[m.group(1)]=html.unescape(re.sub(r'\s+',' ',m.group(2)))
known=set(open(sys.argv[1]).read().split())
print(len(seen),file=sys.stderr)
kw=re.compile(r'(idea|ideation|novel|scientist|discover|research agent|autoresearch|auto-research|hypothes|peer review|reviewer|review|creativ|diversit|homogen|open-ended|self-improv|self-evol|evolv|memory|swarm|society|multi-agent|collective|lineage|generation)',re.I)
for i,ti in sorted(seen.items()):
    if kw.search(ti):
        print(('K ' if i in known else 'N ')+i+' '+ti)
