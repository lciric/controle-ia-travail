"""Vérification, sur processeur, des formules de report de l'additif (aucune donnée du programme)."""
import math

def effectif(n, p):
    """Nombre d'actions du sous-échantillon : rangs multiples de p dans 0..n-1, plus la dernière."""
    rangs = set(range(0, n, p)) | {n - 1}
    return len(rangs)

def pire_cas(n, j, k, directions=2409, sondes=9, largeur=4096):
    p15, p7 = 16 * k, 128 * k
    n15, n7 = effectif(n, p15), effectif(n, p7)
    par_action = directions * n * 2 * 8
    par_jeton = sondes * n * j * 8
    brut15 = n15 * j * largeur * 4
    brut7 = 2 * n7 * j * largeur * 4
    return dict(p15=p15, p7=p7, n15=n15, n7=n7, par_action=par_action, par_jeton=par_jeton,
                brut15=brut15, brut7=brut7, total=par_action + par_jeton + brut15 + brut7)

def regle_k(n, j, borne=2_000_000_000, reserve=4_000_000, index_par_action=1000, forfait=1_000_000, k_max=10**6):
    plafond = borne - reserve - index_par_action * n - forfait
    scores = 2409 * n * 16 + 72 * n * j
    for k in range(1, k_max):
        w = pire_cas(n, j, k)
        if w["total"] <= plafond:
            return k, w, plafond
        if w["n15"] <= 2 and w["n7"] <= 2:   # plus rien à réduire
            return None, w, plafond
    return None, None, plafond

def place_libre(w, j, borne=2_000_000_000):
    plus_grosse = max(w["par_action"], w["par_jeton"], w["brut15"], w["brut7"] // 2)
    return borne + math.ceil(plus_grosse / 100_000_000) * 100_000_000

def morceaux(w):
    t = [w["par_action"], w["par_jeton"], w["brut15"], w["brut7"] // 2, w["brut7"] // 2]
    return [math.ceil(x / 50_000_000) for x in t]

def budget_heures(t, e, a, m):
    return max(12, math.ceil(12 * (t * e * a * m) / 1280))

# 1. Identité aux valeurs de la version 6
w = pire_cas(2560, 400, 1)
print("v6 :", w)
assert w["par_action"] == 98_672_640 and w["par_jeton"] == 73_728_000
assert w["brut15"] == 1_055_129_600 and w["brut7"] == 275_251_200
assert w["total"] == 1_502_781_440 and (w["n15"], w["n7"]) == (161, 21)
k, w, plafond = regle_k(2560, 400)
print("v6 : k =", k, "plafond =", plafond, "marge =", plafond - w["total"])
assert k == 1
assert place_libre(w, 400) == 3_100_000_000
assert morceaux(w) == [2, 2, 22, 3, 3] and sum(morceaux(w)) == 32
assert budget_heures(64, 1, 10, 2) == 12
assert 4 * (2 + 1) + 1 == 13      # nombre d'états de l'extrait pour m = 2
assert 64 * 4 * 1 * 10 == 2560 and 64 * 1 * 10 == 640
assert 2409 * 2 * 8 == 38544 and 9 * 8 == 72 and 4096 * 4 == 16384

# 2. Quelques formes hypothétiques (aucune n'est connue du rédacteur)
for (t, kc, e, a, j) in [(64, 4, 1, 20, 400), (64, 4, 1, 30, 400), (64, 4, 2, 10, 400), (64, 4, 1, 10, 800),
                         (64, 5, 1, 40, 400), (64, 4, 1, 100, 400), (32, 3, 1, 10, 400), (64, 4, 1, 10, 200),
                         (64, 4, 4, 30, 800), (64, 4, 1, 3, 400)]:
    n = t * kc * e * a
    k, w, plafond = regle_k(n, j)
    if k is None:
        print(f"T={t} K={kc} E={e} A={a} J={j} N={n} : aucune valeur de k ne tient la borne (noeud)")
        continue
    print(f"T={t} K={kc} E={e} A={a} J={j} N={n} : k={k} p15={w['p15']} p7={w['p7']} n15={w['n15']} n7={w['n7']} "
          f"total={w['total']} marge={plafond - w['total']} place={place_libre(w, j)} morceaux={sum(morceaux(w))}")

# 3. Étiquetage de l'essai de la chaîne : part d'entier de A/2
for a in (2, 3, 10, 11, 30):
    print("A =", a, "-> étiquette 1 :", a // 2, "; étiquette 0 :", a - a // 2)
