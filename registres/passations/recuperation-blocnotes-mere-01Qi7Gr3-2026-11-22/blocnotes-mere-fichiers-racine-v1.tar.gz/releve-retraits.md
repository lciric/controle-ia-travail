| retrait | fichier | essais | mord |
|---|---|---|---|
| poser : nom final pris | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 22 passed in 102.28s (0:01:42) |
| poser : compagnon seul d'un autre fichier | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 22 passed in 76.81s (0:01:16) |
| poser : provisoire non scellé | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 22 passed in 98.70s (0:01:38) |
| registre : format de ligne | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 24 passed in 92.85s (0:01:32) |
| registre : clé unique | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 24 passed in 38.01s |
| configuration : clés fermées | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 17 passed in 108.76s (0:01:48) |
| configuration : valeurs nulles | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 17 passed in 95.45s (0:01:35) |
| configuration : version et mode | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 17 passed in 102.79s (0:01:42) |
| configuration : texte scellé | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 17 passed in 153.35s (0:02:33) |
| configuration : ligne d'accord | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 17 passed in 117.27s (0:01:57) |
| configuration : commit du registre figé | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 17 passed in 118.58s (0:01:58) |
| configuration : modules fermés | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 17 passed in 198.08s (0:03:18) |
| configuration : échange par paire | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 17 passed in 137.94s (0:02:17) |
| configuration : forme rang | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 17 passed in 89.72s (0:01:29) |
| configuration : statistique | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 17 passed in 82.35s (0:01:22) |
| configuration : entiers | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 17 passed in 57.10s |
| configuration : 2 000 en mode réel | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 17 passed in 33.51s |
| configuration : dossiers | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 17 passed in 29.53s |
| configuration : chemin relatif | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 17 passed in 30.97s |
| configuration : chargement | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 17 passed in 32.79s |
| configuration : jetons de fin | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 17 passed in 31.54s |
| dossiers disjoints | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 19 passed in 32.27s |
| modules : empreinte | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 7 passed in 24.11s |
| modules : absent | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 20 passed in 29.62s |
| modules : importé ailleurs | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 20 passed in 29.91s |
| modules : entrée importée ailleurs | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 20 passed in 30.06s |
| extraire : ligne CONFIG déjà là | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 26 passed in 28.56s |
| extraire : sorties déjà là | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 14 passed in 27.57s |
| base : code de sortie | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 25 passed in 31.47s |
| aucune reprise après une ouverture | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed in 6.31s |
| comptes de positions | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 21 passed in 29.49s |
| table : entropie admise | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 14 passed in 30.18s |
| table : une ligne d'engagement | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 14 passed in 30.38s |
| table : ligne d'un autre fichier | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 15 passed in 29.81s |
| préparation : bilan et demandes | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 14 passed in 30.08s |
| production : déjà inscrite | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 13 passed in 27.25s |
| production : ordre des identifiants | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 13 passed in 27.21s |
| production : morceau d'un autre lot | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 13 passed in 28.37s |
| production : garde avant le premier appel | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 12 passed in 27.35s |
| morceaux : fichier inattendu | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 23 passed in 30.22s |
| morceaux : compagnon | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 23 passed in 30.76s |
| discrétion : dossiers peuplés | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 14 passed in 30.28s |
| discrétion : extraction et bras | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 14 passed in 30.33s |
| discrétion : garde de production à l'étape 1 | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed in 3.63s |
| discrétion : appel de la garde d'ouverture | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed in 8.21s |
| tâches : identifiant en double | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 8 passed in 36.48s |
| tâches : énoncé absent | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 8 passed in 28.42s |
| tâches : fichier à l'empreinte de la configuration | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 8 passed in 27.62s |
| registre absent | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 9 passed in 24.80s |
| fichier scellé : empreinte attendue | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 6 passed in 29.86s |
| reprise : table à l'empreinte engagée | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 10 passed in 26.68s |
| reprise : demandes et bilan scellés | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 10 passed in 26.08s |
| reprise : manifeste inscrit à son empreinte | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 10 passed in 28.53s |
| discrétion : configuration du bras à son empreinte | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 9 passed in 28.14s |
| discrétion : textes scellés | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 9 passed in 24.35s |
| production : forme de la ligne produite | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 11 passed in 26.54s |
| C3 : pièce source à l'étape 1 | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 5 passed in 26.94s |
| C4 : ligne de configuration de la base | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 6 passed in 25.17s |
| C4 : configuration à l'empreinte de la ligne | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 6 passed in 32.49s |
| C7 : énoncé bordé de blancs | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 8 passed in 31.32s |
| C11 : fichiers vérifiés avant l'import | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 7 passed in 23.91s |
| C6 : relevé seul admet des jetons de fin nuls | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 18 passed in 30.15s |
| registres : trois fichiers distincts | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 17 passed in 30.76s |
| lecture complète : champs fermés | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 11 passed in 27.20s |
| lecture complète : identifiants générés | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 11 passed in 27.68s |
| lecture complète : nombres finis | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 11 passed in 28.72s |
| reprise : lecture complète d'un autre lot | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 13 passed in 41.99s |
| reprise : lecture complète scellée | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 13 passed in 40.30s |
| reprise : relevé inscrit à chaque relance | lanceur_discretion_v2.py | test_bras_a_v2_habilite_lanceur_discretion_v2.py | oui — 1 failed, 1 passed in 10.81s |
| préparation v3 : bilan à cinq comptes | preparation_des_lectures_v3.py | test_bras_a_v2_habilite_preparation_des_lectures_v3.py | oui — 1 failed, 3 passed in 4.69s |

70 retraits mordent sur 70 listés ; fichiers remis à l'identique : lanceur_discretion_v2.py c3840745ccaad9b889b676ff7ac2450397f60192b72391e2c42ec37eb5e5ca7e ; preparation_des_lectures_v3.py c0021298c21d027a713b1947d2668ac928f2a856b1a696686dd35b83a9515c45
