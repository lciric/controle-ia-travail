import sys
src, dst = sys.argv[1], sys.argv[2]
t = open(src, encoding="utf-8").read()
def rempl(a, b):
    global t
    assert t.count(a) == 1, (t.count(a), a[:60])
    t = t.replace(a, b)

rempl('''"""Calculs de la note « couverture de l'oracle » (v1).

Lois exactes et formules fermées ; une approximation normale, déclarée au bloc C.
Aucun tirage, aucune donnée du programme, bibliothèque standard seule.
Toutes les valeurs d'entrée sont des suppositions d'illustration.
Rejeu : python -B calculs-couverture-oracle-v1.py > calculs-couverture-oracle-v1.txt
"""''', '''"""Calculs de la note « couverture de l'oracle » (v2).

Lois exactes et formules fermées ; une approximation normale, déclarée au bloc C.
Aucun tirage, aucune donnée du programme, bibliothèque standard seule.
Toutes les valeurs d'entrée sont des suppositions d'illustration.
Rejeu : python -B calculs-couverture-oracle-v2.py > calculs-couverture-oracle-v2.txt

Écarts à la v1, après la contre-lecture (les blocs A, B, D, E, F et les chiffres de C et de G sont inchangés) :
- bloc C, alinéa neuf à la fin de (ii) : la mesure graduée a elle-même une sensibilité par genre (constat 5) ;
- bloc G, dernière ligne : le glossaire dit « pas nécessairement », le « seulement si » est une lecture sous le
  modèle du bloc (constat 6) ;
- bloc H, neuf : l'usage tiré au hasard, dilution par le poids de l'usage atteint (constat 1).
"""''')

rempl('''    print(f"       sigma = {s:<6} -> total vu 95 fois sur 100 : {3.29 * s * math.sqrt(T / P_AUDIT):>7.1f}")
''', '''    print(f"       sigma = {s:<6} -> total vu 95 fois sur 100 : {3.29 * s * math.sqrt(T / P_AUDIT):>7.1f}")
print("     Ces lignes supposent que l'écart au jumeau vaut le dommage plus un bruit, quel que soit le genre du dommage.")
print("     Si la mesure graduée ne répond à un genre qu'avec une sensibilité s (écart attendu = s fois le dommage),")
print(f"     le total réel vu 95 fois sur 100 est divisé par s (sigma = {SIGMA}) :")
for sens in (1.0, 0.5, 0.2, 0.05, 0.0):
    if sens == 0:
        print(f"       s = {sens:<5} -> jamais")
    else:
        print(f"       s = {sens:<5} -> total réel vu 95 fois sur 100 : {m95 / sens:>8.1f}"
              + ("  (au-delà de l'horizon : plus que 1 par épisode)" if m95 / sens > T else ""))
print("     Objets de contrôle : s = 1 doit rendre la valeur de la ligne « vu 95 fois sur 100 » ; s = 0 doit rendre « jamais ».")
''')

rempl('''print("Objet de contrôle : r = 1 doit rendre la valeur exacte ci-dessus. La probabilité de détection réalisée n'atteint")
print("le niveau visé que si l'identification vaut 1 : c'est la phrase du glossaire, entrée 9.32, et c'est la question.")''',
'''print("Objet de contrôle : r = 1 doit rendre la valeur exacte ci-dessus. Sous ce modèle (chaque défaut tiré est identifié")
print("avec probabilité r, indépendamment), la probabilité de détection réalisée n'atteint le niveau visé que si")
print("l'identification vaut 1 : c'est ce que dit le glossaire, entrée 9.32, lu sous ce modèle (son texte dit « not")
print("necessarily as large as (1 - beta) », pas « seulement si ») ; et c'est la question.")

# ---------------------------------------------------------------------------------------------------
titre("[H] L'usage tiré au hasard : sans biais n'est pas voir (dilution par le poids de l'usage atteint)")
P_H = 0.01
print(f"Suppositions : une famille de K usages de poids égaux w = 1/K ; à chaque audit (taux p = {P_H}), un seul usage")
print("est tiré ; le dommage ne nuit qu'à un usage ; quand cet usage est tiré, l'oracle voit le dommage avec probabilité d.")
print("Identification par audit = w.d. Rang du premier épisode endommagé pris avec probabilité 0,95 (même loi qu'en A).")
print()
print(f"{'K usages':>9} | {'w':>6} | " + " | ".join(f"d = {d:<4}" for d in (1.0, 0.5, 0.2)))
for K in (1, 5, 10, 50):
    w = 1.0 / K
    print(f"{K:>9} | {w:>6.3f} | " + " | ".join(
        f"{math.ceil(math.log(0.05) / math.log(1 - P_H * w * d)):>8}" for d in (1.0, 0.5, 0.2)))
print()
print("Objets de contrôle : K = 1, d = 1 doit rendre 299 (bloc A, r = 1) ; K = 5, d = 1 doit rendre 1497 (r = 0,2) ;")
print("K = 10, d = 0,5 doit rendre 5990 (r = 0,05). Lecture : l'estimation reste sans biais, mais l'attaquant qui")
print("connaît la famille vise l'usage de plus petit poids ; le genre devient de la taille.")''')
open(dst, "w", encoding="utf-8").write(t)
