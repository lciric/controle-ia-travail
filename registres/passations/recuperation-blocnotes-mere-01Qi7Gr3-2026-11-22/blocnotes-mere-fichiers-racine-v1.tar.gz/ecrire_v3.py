import json, sys
from pathlib import Path
R = Path("/home/user/controle-ia-travail")
src = R / "prereg/configuration-generation-calage-g1-v2.json"
dst = R / "prereg/configuration-generation-calage-g1-v3.json"
if dst.exists():
    sys.exit("existe déjà (R12)")
t = src.read_text(encoding="utf-8")
d = json.loads(t)
ANCIENNE = ("Une entrée « repris d'une pièce scellée » ou « lu dans le code » dont la valeur est un nombre, une chaîne "
            "courte (40 caractères au plus) ou une liste porte sa valeur, sérialisée, dans l'extrait d'au moins une de "
            "ses sources ; une source JSON est lue à sa clé, et sa valeur doit être celle de l'entrée. La révision est "
            "celle de T0.7, l. 1057. Le programme de validation le contrôle.")
assert d["regles_de_lecture"][4] == ANCIENNE
d["regles_de_lecture"][4] = (
    "Une entrée « repris d'une pièce scellée » ou « lu dans le code » dont la valeur est un nombre, une chaîne courte "
    "(40 caractères au plus) ou une liste porte sa valeur, sérialisée, dans l'extrait d'au moins une de ses sources ; "
    "une source JSON est lue à sa clé, et sa valeur doit être celle de l'entrée. Deux entrées, qui disent une absence "
    "qu'aucun extrait ne peut porter, en sont dispensées : `echantillonnage.troncature` (« aucune ») et "
    "`outils.outils_exposes` (liste vide) ; une garde du programme de validation fixe chacune. Pour "
    "`garde_d_equivalence.quantile`, la source `prereg/P3-premier-test-config-v1.json:48` porte « q99 », lu comme "
    "0,99. La révision est celle de T0.7, l. 1057. Le programme de validation le contrôle.")
assert d["version"] == "v2"
d["version"] = "v3"
d["remplace"] = {"chemin": "prereg/configuration-generation-calage-g1-v2.json",
                 "sha256": "9bc08d00613ac9f55e098e264df6ec9045d63f5252c44e88dde0dd4aa768f368",
                 "etat": "archivée telle quelle (R12)"}
anciennes = d["corrections"]
d["corrections"] = {
    "relecture": "docs/notes/relecture-fable-api-v1/relectures/4-configuration-calage-g1/relecture-fable-api.md",
    "sha256": "381053520a1487585912487790af594aa1d3a467daefc8724961572718fa3287",
    "portees": "correction 1 de la relecture de Fable 5.2 (cinquième règle de lecture : dispense des deux entrées d'absence, lecture du quantile) ; la correction 2 ne touche que la note ; table de la note v3",
    "corrections_de_la_v2": anciennes}
d["statut"] = ("version 3 du 21 novembre 2026 : correction 1 de la relecture de Fable 5.2 portée, sans autre changement ; "
               "à faire vérifier par le relecteur, puis sceller avant la course du banc fermé (GO-2026-11-21-77, "
               "GO-2026-11-21-84). Son empreinte compagnon ne vaut pas scellement.")
d["auteur"] = d["auteur"] + (" ; correction de la v3 portée par Claude Opus 5.5 (claude-opus-5-5), sous-agent de la même "
                             "session, d'après la relecture de Fable 5.2 du 21 novembre")
d["date_utc"] = sys.argv[1]
dst.write_text(json.dumps(d, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
print("écrit", dst)
