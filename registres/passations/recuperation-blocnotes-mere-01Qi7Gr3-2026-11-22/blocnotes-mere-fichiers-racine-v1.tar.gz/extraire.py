import ast,sys
rel,noms=sys.argv[1],sys.argv[2:]
src=open('src/'+rel,encoding='utf-8').read()
arbre=ast.parse(src)
pile=[(arbre,'')]
while pile:
    n0,p=pile.pop()
    for n in ast.iter_child_nodes(n0):
        if isinstance(n,ast.ClassDef): pile.append((n,p+n.name+'.'))
        elif isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):
            q=p+n.name
            if q in noms: print(f'### {rel}::{q} (l. {n.lineno})'); print(ast.get_source_segment(src,n))
            pile.append((n,q+'.'))
