import json, os, glob
E = "docs/notes/relecture-fable-api-v1/envois"
VERBATIM = ("Tu es Claude Fable 5.2, relecteur. La pièce corrigée a été écrite par Claude Opus 5.5, qui ne devait porter que "
 "les remarques de la contre-lecture jointe, mot pour mot, sans rien concevoir de neuf, et laisser en nœuds ouverts ce qui "
 "demande un choix. Dis, remarque par remarque, si elle est portée exactement ; relève tout ajout hors des remarques ; pour "
 "chaque nœud ouvert, donne ta recommandation et ta confiance sans trancher ; vérifie les calculs que tu peux refaire. "
 "Verdict final sur la première ligne : « conforme » ou « à corriger », et pour chaque correction le texte de remplacement exact.")
PIECES = {
 "1-generations-collisionneur": ("la conception des générations du collisionneur jusqu'au plateau",
   [("correction", "conception-generations-jusqu-au-plateau-v3.md"), ("correction", "calculs-devis-et-seuils-generations-v3.py"),
    ("correction", "calculs-devis-et-seuils-generations-v3-sortie.txt"),
    ("remarques", "verification-corrections-conception-generations-opus-v1.md"),
    ("avant", "conception-generations-jusqu-au-plateau-v2.md")],
   "Les remarques sont ici celles de la vérification des corrections de la v2 (même contre-lecteur, Opus 5.5) ; la v3 devait les porter."),
 "2-sparks-exp7-nul": ("le préenregistrement de l'expérience 7 de Sparks (nul), version 2, brouillon 2",
   [("correction", "SPARKS-EXP7-NUL-preenregistrement-v2-brouillon2.md"), ("correction", "calculs-preenregistrement-v2-brouillon2-v1.py"),
    ("correction", "calculs-preenregistrement-v2-brouillon2-v1.txt"),
    ("remarques", "contre-lecture-sparks-v2-brouillon1-opus-v1.md"),
    ("avant", "SPARKS-EXP7-NUL-preenregistrement-v2-brouillon1.md")], ""),
 "3-additif-sondes-barreau8": ("l'additif « organisme changé » à la lecture des sondes du barreau 8, brouillon 2",
   [("correction", "lecture-sondes-barreau8-v1-addendum-organisme-change-v1-brouillon2.md"),
    ("remarques", "contre-lecture-additif-1-opus-v1.md"),
    ("avant", "lecture-sondes-barreau8-v1-addendum-organisme-change-v1-brouillon1.md")], ""),
 "5-prevision-reference-honnete": ("la prévision scellée de la référence honnête (brouillon 1, v2)",
   [("correction", "brouillon-1-v2.md"), ("correction", "calculs-brouillon-1-v2.py"), ("correction", "calculs-brouillon-1-v2.txt"),
    ("remarques", "contre-lecture-brouillon-1-opus-v1.md"), ("avant", "brouillon-1-v1.md")], ""),
}
for d, (titre, fichiers, note) in PIECES.items():
    l = ["# Consigne de relecture — " + titre, "", VERBATIM, "", "## Ce qui est joint", "",
         "Les pièces jointes sont des copies nettoyées des fichiers du dépôt (programme `nettoyer_v1`). Les seuls changements : "
         "le nom du directeur du programme est remplacé par « le directeur » (« du directeur », « au directeur ») ; un nom de "
         "famille par « [nom] » ; un identifiant de session par « [session] » ; un courriel par « [courriel] » ; un chemin, ou le "
         "nom d'une pièce réservée que le relecteur ne doit pas voir (y compris quand ce nom est écrit dans la prose), par "
         "« [chemin réservé] ». Ces marques ne sont pas des défauts de la pièce : ne les relève pas. Rien d'autre n'est changé.", ""]
    if note:
        l += [note, ""]
    l += ["| rôle | copie jointe | fichier d'origine | sha256 d'origine | remplacements |", "|---|---|---|---|---|"]
    for role, nom in fichiers:
        t = json.load(open(f"{E}/{d}/{nom}.table-remplacement-v1.json", encoding="utf-8"))
        l.append(f"| {role} | `{nom}` | `{t['source']}` | {t['sha256_source']} | {t['nombre_de_remplacements']} |")
    l += ["", "Les fichiers de rôle « correction » forment ensemble la pièce corrigée ; « remarques » est la contre-lecture "
          "dont la pièce devait porter les remarques ; « avant » est la version précédente, pour comparer.", ""]
    p = f"{E}/{d}/consigne-relecture-v1.md"
    with open(p, "x", encoding="utf-8") as f:
        f.write("\n".join(l))
    print(p)
