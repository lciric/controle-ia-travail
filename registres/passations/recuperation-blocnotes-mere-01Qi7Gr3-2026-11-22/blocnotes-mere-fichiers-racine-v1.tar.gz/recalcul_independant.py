import math
c=math.ceil
def q(pi,po,ei,eo,f): return (ei*pi+eo*po)/1e6*f
O=(4,20);M=(0.77,2.31);MR=(1.54,4.62);N=(3,15);So=(2,10)
oa=q(*O,4000,500,1.05);op=q(*O,6000,2000,1.15)
ma=q(*M,4000,3000,1.05);mp=q(*MR,6000,9000,1.15);mps=q(*M,6000,9000,1.15)
na=q(*N,4000,1500,1.05);np_=q(*N,6000,6000,1.15)
print("q",round(oa,4),round(op,4),round(ma,4),round(mp,4),round(na,4),round(np_,4))
E1,E2,ES=200,120,12;K=8;X=1.05
f={}
for nom,ens in (("essai",ES),("e1",E1),("e2",E2)):
    f[nom]=(ens*K*op, ens*K*mp, ens*K*mp*X)
    print(nom, [round(v,2) for v in f[nom]], c(f[nom][0]+f[nom][2]))
cpt=sum(v[0]+v[1] for v in f.values()); eng=sum(v[0]+v[2] for v in f.values()); print("somme files",round(cpt,2),round(eng,2))
print("Claude",round(sum(v[0] for v in f.values()),2),"Mistral",round(sum(v[1] for v in f.values()),2),round(sum(v[2] for v in f.values()),2))
def lanc(n):
    h=n*42.8/3600+1; hb=n*40.2/3600+1
    return hb*1.1843+1, h*1.38+2, h*4*1.38+4, h
L1=lanc(140);L2=lanc(120);print("L1",[round(x,3) for x in L1],"L2",[round(x,3) for x in L2])
carte=c(L1[2])+c(L2[2]);print("carte",carte)
pl=carte+sum(c(v[0]+v[2]) for v in f.values());print("plafond",pl)
lc=1920*(oa+ma);es=72*(oa+ma);cc=(L1[0]+L1[1]+L2[0]+L2[1])/2
print("centre",round(cc,4),round(lc,3),round(es,3),repr(cc+lc+es))
# minuterie L2 recalculée
d=42.8;h=2*(1+120*1.5*d/3600);print("L2 recalc",round(1.38*h+4,2),round(h,3));print("d seuil",((18-4)/1.38/2-1)*3600/180)
# groupée
def g(p,k,refl,fe,fs,fr):
    return q(*p,(4000+150*k)*fe,(150*k+refl)*fs,fr)
ga=g(O,8,300,1,1,1.05)+g(M,8,3000,1,1,1.05);gp_o=g(O,8,300,1.5,4,1.15);gp_m=g(MR,8,3000,1.5,3,1.15)
print("groupee k8 att",round(320*ga,2),"pess ens",round(gp_o+gp_m,4),round(gp_o+gp_m*X,4),[c(n*(gp_o+gp_m*X)) for n in (200,120,12)])
bas=320*(g(So,3,300,1,1,1.05)+g(M,3,3000,1,1,1.05));print("bas lect",round(bas,2),"total bas",round(bas+L1[0]+L2[0]+12*(g(So,3,300,1,1,1.05)+g(M,3,3000,1,1,1.05)),2))
print("haut",round(2560*(oa+ma)+96*(oa+ma)+L1[1]+L2[1],2))
# repli Neon
rp=(np_+mp)*X;print("repli",round(na+ma,4),round(np_+mp,4),[c(n*8*rp) for n in (200,120,12)],37+sum(c(n*8*rp) for n in (200,120,12)),round(cc+1920*(na+ma)+72*(na+ma),2))
print("ancre",round(38*na,2),round(38*np_,2),round(38*np_*X,2))
# effort
for s in (500,1000,2000,8192):
    qq=q(*O,4000,s,1.05);print("effort",s,round(qq,4),round(1992*qq,2),round(2656*qq,2))
print("8192 pire",round(2656*q(*O,6000,8192,1.15),2))
print("envoi",round(q(*O,24000,8192,1),4),round(q(*MR,24000,16384,1),4),round(q(5,20,24000,8192,1),4))
print("cache",round(q(5,20,6000,2000,1.15),4),round(2656*(q(5,20,6000,2000,1.15)-op),2))
# devise Claude euros
pe=carte+sum(c(v[0]*X+v[2]) for v in f.values());pt=c(L1[2]*X)+c(L2[2]*X)+sum(c(v[0]*X+v[2]) for v in f.values());print("euros",pe,pt)
# essai deux reglages
print("essai2",c(f['essai'][0]*2+f['essai'][2]), pl-13+c(f['essai'][0]*2+f['essai'][2]))
# variantes
for ne in (100,200):
    A=2*ne;B=2*ne;C=20;e1=A+C+60;e2=B
    l1=lanc(A+C);l2=lanc(B);cp=c(l1[2])+c(l2[2]);pq=op+mp*X
    print("var",ne,A+B+C,e1+e2,round(l1[0]+l2[0],2),round(l1[1]+l2[1],2),cp,round((e1+e2)*6*(oa+ma),2),c(e1*8*pq)+c(e2*8*pq),cp+c(e1*8*pq)+c(e2*8*pq)+13)
print("mistral scelle",round(2560*(op+mps),2),round(2560*(op+mps*X),2))
print("couverture sortie",(op/1.05/1.0*1-0.016)/20e-6 if False else ((117.76/1600)/1.05-0.016)/20e-6)
