import re, sys, hashlib
D = "/home/user/controle-ia-travail/docs/notes/demandes-fable-api-2026-11-22-v1/"
rel = open(D + "relecture-pieces-essaim-v2/relecture-fable-api.md", encoding="utf-8").read()
v2 = open(D + "pieces-comparaison-essaim-v2.md", encoding="utf-8").read()
sec = rel.split("## 3. Corrections mot à mot", 1)[1].split("## 4. Sans changement", 1)[0]
blocs = re.findall(r"\*\*(\d+)\. ([^*]+)\*\*(.*?)```\n(.*?)```", sec, re.S)
corr = {}
for num, titre, apres_titre, corps in blocs:
    corr[int(num)] = (titre, apres_titre, corps)
assert sorted(corr) == list(range(23, 43)), sorted(corr)
texte = v2
journal = []
for n in range(23, 43):
    titre, apres, corps = corr[n]
    if n == 36:
        ancre = "**Pourquoi pas mieux [HYPOTHÈSE].**"
        c = texte.count(ancre)
        if c != 1:
            sys.exit(f"ÉCHEC correction 36 : ancre trouvée {c} fois")
        bloc = corps.rstrip("\n")
        texte = texte.replace(ancre, bloc + "\n\n" + ancre)
        journal.append((n, "insertion", 1))
        continue
    lignes = corps.rstrip("\n").split("\n")
    assert lignes[0].startswith("ANCIEN  "), (n, lignes[0])
    i = next(k for k, l in enumerate(lignes) if l.startswith("NOUVEAU "))
    assert i == 1, (n, "ANCIEN sur plusieurs lignes")
    ancien = lignes[0][len("ANCIEN  "):]
    nouv = [lignes[1][len("NOUVEAU "):]]
    for l in lignes[2:]:
        assert l.startswith(" " * 8), (n, l)
        nouv.append(l[8:])
    nouveau = "\n".join(nouv)
    c = texte.count(ancien)
    if c != 1:
        sys.exit(f"ÉCHEC correction {n} : ANCIEN trouvé {c} fois : {ancien!r}")
    texte = texte.replace(ancien, nouveau)
    journal.append((n, "remplacement", 1))
h_rel = hashlib.sha256(rel.encode()).hexdigest()
h_v2 = hashlib.sha256(v2.encode()).hexdigest()
entete = (f"Version 3 : corrections 23 à 42 de la relecture de Fable ({h_rel[:8]}…) portées par Opus 5.5\n\n"
          f"- Base : `docs/notes/demandes-fable-api-2026-11-22-v1/pieces-comparaison-essaim-v2.md`, sha256 {h_v2}.\n"
          f"- Remarques : `docs/notes/demandes-fable-api-2026-11-22-v1/relecture-pieces-essaim-v2/relecture-fable-api.md`, sha256 {h_rel}.\n"
          f"- Table des corrections : `docs/notes/demandes-fable-api-2026-11-22-v1/table-corrections-pieces-essaim-v3.md`.\n"
          f"- Épreuve des motifs (correction 28) : `docs/notes/demandes-fable-api-2026-11-22-v1/epreuve-motifs-correction-28-v1.md`.\n"
          f"- En-tête de la version 2, gardé tel quel ci-dessous.\n\n")
open(D + "pieces-comparaison-essaim-v3.md", "w", encoding="utf-8").write(entete + texte)
for j in journal: print(*j)
