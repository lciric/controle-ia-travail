import sys
src = "/home/user/controle-ia-travail/docs/notes/collisionneur-v9/generations-v1/conception-generations-jusqu-au-plateau-v3.md"
dst = src.replace("-v3.md", "-v4.md")
t = open(src, encoding="utf-8").read()
def rep(old, new, count=1):
    global t
    n = t.count(old)
    assert n == count, (old[:60], n)
    t = t.replace(old, new)

# 1. correction de Fable (section 10, nœud 2)
rep("Enjeu : ils décident de ce que le rapport prononce et de l'arrêt sur alerte ; posés par Fable, qui est dans la course, ils ne sont « fixés par un tiers » que si tu les gèles. Options : (a) les geler tels quels pour le pilote : simples, mais sans étalonnage ; (b) en changer avant la première génération 2.",
    "Enjeu : les neuf constantes décident de ce que le rapport prononce et de l'arrêt sur alerte ; posées par Fable, qui est dans la course, elles ne sont « fixées par un tiers » que si tu les gèles. Options : (a) geler les neuf telles quelles pour le pilote : simples, mais sans étalonnage ; (b) en changer avant la première génération 2.")

# 2. recommandations de Fable recopiées dans les nœuds ouverts (non tranchés)
n1_old = "tant qu'il n'est pas tranché, la garde reste celle de la version 2 et les deux formes sont des faux positifs connus.\n"
n1_new = n1_old.rstrip("\n") + """
   - Recommandation de Fable, relecture du 21 novembre : ne pas ancrer pour le pilote. Confiance : 70 %. Un faux positif coûte une lecture et un `--admettre`, inscrits à la filiation. Un ancrage laisserait passer sans bruit une auto-désignation en milieu de phrase (« Speaking as Claude, I… ») : avec un nom nu, ni refus ni signalement. La section 3.3 dit déjà que la branche (a) penche du côté du refus. Le pilote donnera le nombre de refus d'identité admis. S'il est élevé, une exclusion étroite (« such as », « tu as ») serait à préférer à l'ancrage. À verser au même nœud, lu dans le code et non exécuté : la même formule prend aussi « selon moi, [un modèle] » et « pour moi, [un modèle] », plus probables en français que « tu as ». Cette forme n'est ni dans la vérification ni dans les faux positifs connus. Ce n'est pas un défaut de la v3, mais la liste reste incomplète. (Le nœud reste ouvert.)
"""
rep(n1_old, n1_new)
n2_old = "Choix de conception, ou mot de Lazar ; la version 3 ne le tranche pas.\n"
n2_new = n2_old.rstrip("\n") + """
   - Recommandation de Fable, relecture du 21 novembre : oui, avec les neuf, dans le même accord, nommés à part comme seuils de réserve. Confiance : 75 %. Ils sont posés par Fable comme les autres : la raison du gel vaut pour eux. Lazar peut arrêter une chaîne à deux sur le rapport ; les réserves font partie de ce qu'il lit. Le coût est nul : ce sont déjà des constantes de la note, et `plateau` refuse si un recalcul diffère. La décision devrait dire aussi si le 0,90 des « énoncés presque identiques » (section 5.5, hors décision) suit. C'est le mot de Lazar qui tranche, puisqu'il s'agit de l'étendue de son accord. (Le nœud reste ouvert.)
"""
rep(n2_old, n2_new)

# 3. tenue de version : titre, en-tête neuf, ancien en-tête en historique
rep("# Générations du collisionneur jusqu'au plateau : conception, v3\n\n21 novembre 2026 ; heure prise par `date -u` au début de cette correction : 20:43Z. Version 3,",
    "# Générations du collisionneur jusqu'au plateau : conception, v4\n\n" + open(sys.argv[1], encoding="utf-8").read() + "\n## Historique : version 3\n\n21 novembre 2026 ; heure prise par `date -u` au début de cette correction : 20:43Z. Version 3,")
rep("## Table des corrections de la version 3\n", "### Table des corrections de la version 3, inchangée\n")
rep("### Nœuds ouverts de la version 3 (non tranchés par le correcteur)\n", "### Nœuds ouverts de la version 3 (non tranchés par le correcteur ; toujours ouverts en version 4, recommandations de Fable recopiées)\n")
open(dst, "w", encoding="utf-8").write(t)
print("écrit", dst)
