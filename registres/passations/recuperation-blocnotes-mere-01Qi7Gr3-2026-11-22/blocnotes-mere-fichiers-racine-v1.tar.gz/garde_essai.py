import importlib.util, sys
spec = importlib.util.spec_from_file_location("c", "/home/user/controle-ia-travail/docs/notes/collisionneur-v9/collisionneur_v9_v3.py")
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
base = "/home/user/controle-ia-travail/docs/notes/couverture-de-l-oracle-v1/"
for f in ("collisionneur-v1/faits-couverture-oracle-v1.md", "collisionneur-v1/question-couverture-oracle-v1.md"):
    print(f, [t[0] for t in m.motifs_trouves(open(base+f).read())])
txt = open(base+"reponse-fable-couverture-oracle-v1.md").read()
i = txt.index("> Sous-question"); sq = "\n".join(l[2:] for l in txt[i:].split("\n")[:10] if l.startswith(">"))
print("sous-question", [t[0] for t in m.motifs_trouves(sq)])
