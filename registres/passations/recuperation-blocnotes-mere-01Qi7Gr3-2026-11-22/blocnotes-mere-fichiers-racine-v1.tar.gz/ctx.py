import sys, re, collections, unicodedata
sys.path.insert(0, "/home/user/controle-ia-travail/src")
from controle_ia.relecture_fable_api_v2 import garde_motifs_ligne, sans_accents
formes = collections.Counter()
for f in sys.argv[1:]:
    t = open(f, encoding="utf-8").read()
    for m in re.finditer(r"\S*(?:[Ll][Aa][Zz][Aa][Rr]|[Cc][Ii][Rr][Ii][Cc]|Ćirić)\S*", t):
        formes[m.group(0)] += 1
    for i, l in enumerate(t.split("\n"), 1):
        ms = [m for m in garde_motifs_ligne(l) if "lazar" not in m]
        if ms:
            print(f"--- {f}:{i} {ms}")
            # show segments around match
            n = sans_accents(l)
            for pat in [r"consigne[\s_\-]*privee", r"conception[\s_\-.()]*ii[\s_\-.()]*b", r"donnees\s*[/\\]", r"session[_\-][0-9A-Za-z]{20,}", r"ciric", r"[0-9a-f]{8}-[0-9a-f]{4}-"]:
                for mm in re.finditer(pat, n, re.I):
                    a,b = max(0,mm.start()-120), mm.end()+80
                    print("     ", repr(l[a:b]))
print("FORMES:")
for k,v in formes.most_common(): print(v, repr(k))
