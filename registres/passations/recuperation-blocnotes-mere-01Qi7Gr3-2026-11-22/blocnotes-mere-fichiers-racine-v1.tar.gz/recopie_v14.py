import hashlib, sys, subprocess
SRC = "/home/user/controle-ia-travail/registres/qui-a-lu-quoi-v13.md"
DST = "/home/user/controle-ia-travail/registres/qui-a-lu-quoi-v14.md"
H13 = "ffc4420e378c5e0931757d4da1c6bdae96e1257527221262539d0cd42d000595"
HEURE = sys.argv[1]
b = open(SRC, "rb").read()
assert hashlib.sha256(b).hexdigest() == H13
t = b.decode("utf-8")
lines = t.split("\n")

def une(old, new):
    global t
    assert t.count(old) == 1, old
    t = t.replace(old, new)

LIGNE = ("| 313 | sous-agent de session_01Qi7Gr3eYmAhDEJzqLgWcv1 (**lecteur autorisé neuf des deux verdicts scellés de l'épreuve des sondes**, "
 "étape B du 17 novembre et étape B bis, l'apprentissage des sondes sur la tâche, du 19 novembre, pour écrire les deux sections du billet "
 "« Linear probes on an instructed saboteur » ; désigné par la session mère qui l'a lancé, par message, sans mandat versé cité ; inscrit avant "
 "toute lecture des deux verdicts, à " + HEURE + ", heure unique relevée par `date -u`) "
 "| celui de la session qui l'a lancé, non écrit au registre | Opus 5.5, selon ce que son environnement lui déclare ; non confirmé par Lazar "
 "| inscrit avant sa lecture, il déclare ce qu'il ouvre pour son travail : les consignes permanentes du dépôt (`CLAUDE.md`), données en contexte ; "
 "**le verdict de l'étape B** (`docs/verdicts/verdict-T0.7-etape-B-v1.md`, `077ab789…`, sceau vérifié) **et son issue** "
 "(`docs/verdicts/verdict-T0.7-etape-B-v1-issue.json`, `2717d63f…`, sceau vérifié), et les pièces voisines du même dossier si ce verdict y renvoie ; "
 "**le verdict de l'étape B bis** (`docs/verdicts/verdict-T0.7-etape-B-bis-v1.md`, `1561399a…`, sceau vérifié) **et son erratum 1, versions 1 et 2** "
 "(`d1b94f11…`, `1f3da53c…`) ; le billet en anglais v2 (`b69fd6dc…`), la fiche de faits v2 (`1be265b4…`), le gabarit des billets v2 (`5eee79b3…`) et sa "
 "vérification (`7a303aca…`) ; des lignes du registre des décisions (R-3042, R-3559, R-3754 à R-3770, et des extraits trouvés par recherche du mot « verdict », "
 "qui citent des phrases du verdict de l'étape B bis rapportées par R-3756), des lignes de `registres/go.md` (GO-2026-11-16-15, GO-2026-11-19-44) et de "
 "`registres/scellements-v1.md` ; cette liste en partie (lignes de fichier 1 à 40, 75 à 76, 304 à 312 du tableau par extraits, 388, la fin) ; des noms "
 "de fichiers ; aucun refus à l'heure de cette version "
 "| rédacteur des sections des étapes B et B bis du billet (`docs/notes/billet-nul-avec-controle-positif-v1/sections-etapes-b-v1/`) et de leur table des "
 "nombres ; rédacteur de cette version 14 (recopie de la version 13 par programme, cette ligne, réserve 25) "
 "| message de la session mère (tâche calculée relayée) ; cette pièce (puce de la version 14, réserve 25) "
 "| par la règle de Lazar (lecture du verdict de l'épreuve des sondes) : tout rôle de lecteur du témoin positif (P3-bis) ; tout rôle de lecteur ou de juge "
 "de l'étape B, de l'étape B bis et de la table conjointe des deux étapes (issues lues) ; contre-lecteur et vérificateur de cette liste (auteur de la "
 "version 14, R2) et des sections qu'il écrit ; à trancher par la mère : tout rôle de verdict de G0 et, par la règle du LISEZ-MOI du dossier du barreau 5, "
 "toute conception ou tout réglage de l'agent, du saboteur ou des sondes d'un cycle à venir ; à confirmer par la mère : tout rôle côté sondes du barreau 8 |")

PUCE = ("- **Version 14** (ce fichier) : la version 13 (`registres/qui-a-lu-quoi-v13.md`, `" + H13 + "`, gardée telle quelle, R12) recopiée à l'octet "
 "par programme, sauf les changements énumérés ici, **tous**, vérifiés par programme contre la différence entre les deux fichiers (`diff`). " + HEURE +
 ", heure unique relevée par `date -u` à l'écriture du fichier. **Rédacteur** : le sous-agent de la ligne 313, qui n'a écrit aucune version antérieure de "
 "cette liste ni aucune de ses contre-lectures ; il s'inscrit lui-même, sur la tâche donnée par la mère (« Inscris-toi d'abord dans la dernière liste »), "
 "comme lecteur des deux verdicts, avant de les ouvrir. **Motif** : la version 13 interdit de changer une cellule existante et d'écraser un fichier ; "
 "une ligne neuve demande donc une version neuve. **Changements** : (1) le titre : « version 13 » devient « version 14 » ; (2) cette puce, ajoutée en tête ; "
 "(3) puce de la version 13 : « (ce fichier) » devient « (version précédente) » ; (4) **ligne 313 ajoutée au tableau**, à la suite de la ligne 312, ajout "
 "seulement ; (5) réserve 25 ajoutée, à la suite de la réserve 24, précédée d'une ligne vide ; (6) ligne de fin de la version 14 ajoutée. **Aucune autre "
 "ligne du tableau, aucune réserve existante, aucune ligne de fin existante ne change ; rien d'autre ne change.** **Classe et vigueur** : registre de classe C "
 "(GO-2026-11-19-26 et -27) ; mise en vigueur et exclusions « à trancher » ou « à confirmer » : à la mère. **Diffusion** : comme la version 13 (réserve 23 (a)) ; "
 "aucun chiffre de résultat, aucune issue de verdict n'est recopié dans cette version.")

RES = ("25. **Version 14 — inscription d'un lecteur avant sa lecture** : écrite par le lecteur de la ligne 313, sous-agent de la session "
 "`session_01Qi7Gr3eYmAhDEJzqLgWcv1`, avant d'ouvrir les deux verdicts. (a) Sa colonne « a lu » déclare d'avance les pièces qu'il ouvrira ; s'il en ouvre "
 "d'autres, il les déclare à la mère par leur chemin dans son rendu, et une version suivante les porte (R12). (b) La session qui l'a lancé n'a pas de "
 "ligne dans cette liste sous cet identifiant ; son lien avec les sessions mères des lignes 262 et 263 n'est pas écrit au registre lu : à porter par la mère. "
 "(c) Les exclusions de la ligne 313 sont tirées de la règle de Lazar (puce « Règle de Lazar ») pour le témoin positif, et, par analogie avec la ligne 312, "
 "pour le reste ; elles ne sont pas des décisions. (d) Aucun chiffre ni aucune issue des étapes B et B bis n'est écrit ici ; la version 14 ne sert pas "
 "de canal vers la mère.")

une("# Liste « qui a lu quoi » du programme — version 13\n", "# Liste « qui a lu quoi » du programme — version 14\n")
une("- **Version 13** (ce fichier) :", PUCE + "\n- **Version 13** (version précédente) :")
L312 = [l for l in t.split("\n") if l.startswith("| 312 |")]
assert len(L312) == 1
une(L312[0] + "\n", L312[0] + "\n" + LIGNE + "\n")
R24 = [l for l in t.split("\n") if l.startswith("24. **Version 13")]
assert len(R24) == 1
une(R24[0] + "\n", R24[0] + "\n\n" + RES + "\n")
FIN13 = "Version 13 : 2026-11-19T21:36:51Z, heure unique relevée par `date -u` à l'écriture du fichier."
assert t.count(FIN13) == 1
t = t.replace(FIN13, FIN13 + "\nVersion 14 : " + HEURE + ", heure unique relevée par `date -u` à l'écriture du fichier.")
open(DST, "x", encoding="utf-8").write(t)
print("écrit", hashlib.sha256(t.encode()).hexdigest())
