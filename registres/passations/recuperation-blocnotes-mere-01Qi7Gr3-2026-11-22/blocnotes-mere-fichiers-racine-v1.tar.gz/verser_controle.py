import sys,hashlib,pathlib,subprocess
def h(p): return hashlib.sha256(p.read_bytes()).hexdigest()
bad=[];ok=[]
for arg in sys.argv[1:]:
    P=pathlib.Path(arg)
    files=[P] if P.is_file() else sorted(x for x in P.rglob('*') if x.is_file())
    for f in files:
        if f.suffix=='.sha256': continue
        tracked=subprocess.run(['git','ls-files','--error-unmatch',str(f)],capture_output=True).returncode==0
        c=f.with_name(f.name+'.sha256')
        if not c.exists(): bad.append((str(f),'SANS COMPAGNON',tracked)); continue
        exp=c.read_text().split()[0]
        if exp!=h(f): bad.append((str(f),'EMPREINTE FAUSSE',tracked)); continue
        ok.append((str(f),exp[:12],tracked))
for x in ok: print('OK ',x)
for x in bad: print('KO ',x)
