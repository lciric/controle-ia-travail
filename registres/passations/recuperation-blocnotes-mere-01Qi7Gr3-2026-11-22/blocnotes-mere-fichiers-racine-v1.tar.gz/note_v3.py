import sys
from pathlib import Path
R = Path("/home/user/controle-ia-travail/docs/notes/configuration-calage-g1-v1")
src, dst = R / "note-configuration-calage-g1-v2.md", R / "note-configuration-calage-g1-v3.md"
if dst.exists():
    sys.exit("existe déjà (R12)")
t = src.read_text(encoding="utf-8")
REC = "recommandation de Fable, relecture du 21 novembre"
def rep(old, new):
    global t
    n = t.count(old)
    assert n == 1, (n, old[:80])
    t = t.replace(old, new)

# --- titre et en-tête (tenue de version)
rep("note d'accompagnement (v2)\n", "note d'accompagnement (v3)\n")
rep("- **Qui** : la v1 est de Claude Fable 5.2 (`claude-fable-5-2`), agent neuf de la session mère (`session_01Qi7Gr3eYmAhDEJzqLgWcv1`). Les corrections de la v2 sont portées",
    "- **Qui** : la v1 est de Claude Fable 5.2 (`claude-fable-5-2`), agent neuf de la session mère (`session_01Qi7Gr3eYmAhDEJzqLgWcv1`). Les corrections de la v3 sont portées par Claude Opus 5.5 (`claude-opus-5-5`), en effort maximal, sous-agent correcteur de la même session, d'après la relecture de Fable 5.2 (règle de Lazar, GO-2026-11-21-84 : Opus écrit seulement les corrections, mot pour mot ; Fable relit par l'interface de programmation ; puis scellement). Les corrections de la v2 sont portées")
rep("ni le préenregistrement du banc fermé, ni celui de G1, ni la contre-lecture.",
    "ni le préenregistrement du banc fermé, ni celui de G1, ni la contre-lecture, ni la relecture de Fable.")
rep("- **Quand** : 21 novembre 2026, de 20:40 à 21:00 UTC environ (relevés `date -u`).",
    "- **Quand** : v3 le 21 novembre 2026, de 22:38 à 23:00 UTC environ ; v2 le même jour, de 20:40 à 21:00 UTC environ (relevés `date -u`).")
rep("- **Ce qui est corrigé** : chaque remarque",
    "- **Ce qui est corrigé en v3** : les deux corrections demandées par la relecture de Fable 5.2 (`docs/notes/relecture-fable-api-v1/relectures/4-configuration-calage-g1/relecture-fable-api.md`, `381053520a1487585912487790af594aa1d3a467daefc8724961572718fa3287`, verdict « à corriger », 22:28 UTC), et rien d'autre (table ci-dessous). Fable a relu des copies nettoyées (« le directeur », « du_directeur », « [session] », « [chemin réservé] ») ; ses corrections sont portées dans les pièces d'origine, noms d'origine gardés. Ses recommandations sur les nœuds ouverts sont recopiées sans trancher, marquées « " + REC + " ».\n- **Ce qui a été corrigé en v2** : chaque remarque")
rep("- **Remplace** : la note v1",
    "- **Remplace** : la note v2 (`2b8ef38c1823c57909d47d40c6b3c3d6c1ee765c0a38043f253cda0230877436`), archivée telle quelle (R12). La v2 remplaçait la note v1")
rep("- **État** : corrigée, non scellée. La suite est celle du mot de Lazar : relecture par Fable 5.2, appelé par l'interface de programmation, puis scellement avant la course du banc fermé.",
    "- **État** : corrigée, non scellée. La suite est celle du mot de Lazar : relecture par Fable 5.2, appelé par l'interface de programmation, puis scellement avant la course du banc fermé ; pour la v3, la relecture de Fable a eu lieu, ses corrections sont portées et restent à vérifier.")

# --- table des corrections de Fable (en tête)
TABLE = """## Table des corrections de la relecture de Fable (v3)

| Correction de Fable | Lieu | Fait |
|---|---|---|
| **1.** Configuration, `regles_de_lecture`, cinquième règle (C1, point 1) : texte de remplacement, qui écrit la dispense des deux entrées d'absence (`echantillonnage.troncature`, `outils.outils_exposes`) | `prereg/configuration-generation-calage-g1-v3.json`, `regles_de_lecture`, cinquième règle | Porté mot pour mot. |
| **1**, point voisin : « S'il traite ce couple à part », ajouter après la phrase des dispenses : « Pour `garde_d_equivalence.quantile`, la source `prereg/P3-premier-test-config-v1.json:48` porte « q99 », lu comme 0,99. » | même règle, après la phrase des dispenses | Vérifié sur le programme avant d'écrire : `valider_configuration_calage_v2.py` lit pour cette entrée la clé `statistique_equivalence` et la convertit par `STATISTIQUES` (`{"max": None, "q99": 0.99}`, l. 59 ; `CLES_JSON`, l. 118). La condition tient : phrase ajoutée mot pour mot. Vues aussi, avant d'écrire la dispense, les deux gardes qui la fondent : `FIXEES_PAR_UNE_GARDE` (l. 124-127), garde de la troncature (l. 405-406), garde des outils (l. 601-603). |
| **2.** Note, verdict : « Un nœud ouvert s'y ajoute, sur les fichiers des fonctions de montage (§ 9). » | Verdict, dernière phrase du quatrième paragraphe | Porté mot pour mot (« de classe B » retiré). |
| **2.** Note, titre : « ## 9. Nœud ouvert de la v2 (m4) » | titre du § 9 | Porté mot pour mot. |
| Rejeu, la correction 1 touchant le JSON | `rejeu-validation-configuration-v3-sortie.txt` ; `essai-validation-configuration-v3-sortie.txt` | Programme de validation v2 rejoué sur la v3 : cas sain et contrôle de lancement « configuration valide » ; `--essai` : 5 cas sains et 62 artefacts, tous réussis ; deux artefacts en ligne de commande, sur les deux entrées dispensées (troncature « top-p 0,9 », outil exposé `["lire_piece"]`), refusés par leur garde, code de sortie 1. Les sources citées ne changent pas : pas de nouvel assemblage. |

- **Tenue de version, hors correction.** Dans la v3 : `version`, `remplace`, `corrections` (celles de la v2 y restent, sous `corrections_de_la_v2`), `statut`, `auteur`, `date_utc`. Rien d'autre ne change : la différence avec la v2 (`diff`) ne montre que ces champs et la cinquième règle. Dans la note : titre, en-tête, cette table, pièces livrées, épreuves, § 7 (ce que le correcteur de la v3 a lu) et les recommandations recopiées.
- **Non porté, hors des deux pièces.** « Une conséquence de C2 n'est dite nulle part. Les champs n° 1 et 2 du banc citent l'empreinte du relevé de référence, qui n'existe qu'une fois le poste de calage choisi (nœud 4) et le programme de l'opérateur joué en réel, ce qui n'a jamais été fait. Ce n'est pas un défaut de la correction ; c'est à porter au texte du banc. » La relecture la renvoie au texte du banc fermé : rien n'est écrit ici.
- **Choix relevés « à faire valider avec les entrées », sans correction.** Le seuil de 40 caractères ; `unicite` ; `conversion` ; `comparaison` (commande d'un programme de classe B, sans chemin ni empreinte) ; le nom du relevé de référence ; le douzième artefact et « source JSON sans clé désignée = défaut » ; les deux « conséquences à noter » du § 9. Rien n'est changé : ils restent sous la mention « choix, à faire valider ».
- **La dispense de la correction 1** est écrite ; son acceptation reste à valider. """ + REC.capitalize() + """ : « l'accepter et l'écrire, confiance 0,8, une fois les deux gardes vues dans le programme ». Les deux gardes ont été vues (ligne 1 bis de la table).
- **Recommandations recopiées** aux nœuds : nœuds 1 à 4 (§ 8), m4 (§ 9), type conservé (§ 3, point 9).
- **Réserves du correcteur, à revoir, non tranchées.** (i) La v3 garde, mot pour mot, les noms internes de la v2 : la commande du programme de l'opérateur (`gabarit_de_conversation.empreinte.methode.commande`, `--configuration prereg/configuration-generation-calage-g1-v2.json`), les noms des relevés (`prereg/configuration-generation-calage-g1-v2-releve-operateur-<poste>-v1.json`, et celui du relevé de référence), la commande de `comparaison`, et « (nœud ouvert de la note v2) » dans `ce_qui_reste_ouvert`. Aucune correction ne demande de les changer ; jouée telle qu'écrite, la commande de l'opérateur lirait la v2. Le chemin par défaut du programme de validation v2 est aussi la v2 : passer `--configuration`. (ii) Le programme donne, sur la v3 comme aujourd'hui sur la v2, un avis : `requirements-cpu.txt` a changé dans l'arbre de travail depuis le commit de lecture `4814dc47…` (quatre lignes ajoutées, commits `5e4a3868a` et `6d070e351`) ; il le relit à ce commit ; aucun défaut.

## Table des remarques portées
"""
rep("## Table des remarques portées\n", TABLE)
rep("La contre-lecture ne demande aucun cinquième nœud ; ce texte n'en ajoute pas, hors du nœud ouvert de m4.",
    "La contre-lecture ne demande aucun cinquième nœud ; ce texte n'en ajoute pas, hors du nœud ouvert de m4. (Table de la v2, gardée telle quelle.)")

# --- correction 2 (verdict)
rep("Un nœud ouvert s'y ajoute, de classe B, sur les fichiers des fonctions de montage (§ 9).",
    "Un nœud ouvert s'y ajoute, sur les fichiers des fonctions de montage (§ 9).")

# --- pièces livrées (tenue de version)
rep("| la configuration v2 (classe A) | `prereg/configuration-generation-calage-g1-v2.json` | `9bc08d00613ac9f55e098e264df6ec9045d63f5252c44e88dde0dd4aa768f368` |",
    "| la configuration v3 (classe A) | `prereg/configuration-generation-calage-g1-v3.json` | `__SHA_V3__` |")
rep("| rejeu du programme de validation v2 : cas sain, contrôle de lancement, un artefact | `docs/notes/configuration-calage-g1-v1/rejeu-validation-v2-sortie.txt` | `5d8a7d42d6f8996c30aff5ba7964a191b031b1a7467d0ff50828559b653067bd` |",
    "| rejeu du programme de validation v2 : cas sain, contrôle de lancement, un artefact | `docs/notes/configuration-calage-g1-v1/rejeu-validation-v2-sortie.txt` | `5d8a7d42d6f8996c30aff5ba7964a191b031b1a7467d0ff50828559b653067bd` |\n"
    "| épreuves du programme de validation v2 sur la configuration v3 | `docs/notes/configuration-calage-g1-v1/essai-validation-configuration-v3-sortie.txt` | `__SHA_ESSAI__` |\n"
    "| rejeu du programme de validation v2 sur la configuration v3 : cas sain, contrôle de lancement, deux artefacts | `docs/notes/configuration-calage-g1-v1/rejeu-validation-configuration-v3-sortie.txt` | `__SHA_REJEU__` |")
rep("Restent tels quels (R12) : la configuration v1 (`4bfdd98d…`),",
    "Restent tels quels (R12) : la configuration v2 (`9bc08d00…`) et la note v2 (`2b8ef38c…`) ; la configuration v1 (`4bfdd98d…`),")
rep("**Épreuves rejouées (R5).**\n\n",
    "**Épreuves rejouées (R5).**\n\n- v3 : programme de validation v2 sur la configuration v3 (`--configuration prereg/configuration-generation-calage-g1-v3.json`) : cas sain et contrôle de lancement « configuration valide » ; `--essai` : 5 cas sains et 62 artefacts, tous réussis ; deux artefacts en ligne de commande, rangés dans le bloc-notes hors du dépôt, sur les deux entrées dispensées (troncature « top-p 0,9 », outil exposé `[\"lire_piece\"]`) : « configuration refusée : 1 défaut(s) », code de sortie 1, chacun par sa garde. Le programme de l'opérateur n'a pas été rejoué sur la v3.\n")

# --- § 3, point 9 : recommandation recopiée
rep("9. **Le type des activations conservées.** Égal des deux côtés ; si le texte du banc garde le float32 et que G1 veut le type de T0.7 (float16), c'est un nœud ; pas avant (contre-lecture, C3).",
    "9. **Le type des activations conservées.** Égal des deux côtés ; si le texte du banc garde le float32 et que G1 veut le type de T0.7 (float16), c'est un nœud ; pas avant (contre-lecture, C3). " + REC.capitalize() + " : « pas de nœud aujourd'hui. S'il naît, conserver le float32 des deux côtés et appliquer en aval la même conversion gelée le dissoudrait sans doute ; confiance 0,6. »")

# --- § 7 : lu par le correcteur de la v3
rep("Non vérifié par le correcteur : le chemin réel du programme de l'opérateur ; les essais du dépôt (`pytest`) ; la vérification de l'arbre.\n",
    "Non vérifié par le correcteur : le chemin réel du programme de l'opérateur ; les essais du dépôt (`pytest`) ; la vérification de l'arbre.\n\n"
    "**Par le correcteur de la v3.** Lu, par morceaux de 150 lignes au plus : la relecture de Fable en entier et ses compteurs ; la note v2 en entier ; de la configuration v2, l'en-tête, les règles de lecture, `ce_qui_reste_ouvert`, l'entrée du quantile et la méthode de l'empreinte du gabarit ; du programme de validation v2, l'en-tête (l. 1 à 48), les tables (l. 100 à 130), le contrôle des valeurs à leur source (l. 436 à 470), les épreuves et l'entrée (l. 776 à 840, 1022 à 1090), et la recherche des lignes citées ; de l'outil d'assemblage v2, la recherche de ses noms. Rien du banc, de G1 ni des résultats. Non vérifié par le correcteur : le programme de l'opérateur sur la v3 ; les essais du dépôt (`pytest`) ; la vérification de l'arbre.\n")

# --- § 8 : recommandations recopiées
rep("   - Recommandation de l'auteur : (a), confiance 0,7.\n   - Réserve de la contre-lecture (§ 7)",
    "   - Recommandation de l'auteur : (a), confiance 0,7.\n   - " + REC.capitalize() + " : (a), confiance 0,7.\n   - Réserve de la contre-lecture (§ 7)")
rep("   - Recommandation de l'auteur : (a), confiance 0,7.\n   - La contre-lecture (§ 7)",
    "   - Recommandation de l'auteur : (a), confiance 0,7.\n   - " + REC.capitalize() + " : « (a), sous la condition de mesure que pose la contre-lecture, que j'accepte ; confiance 0,7 si l'effet mesuré reste dans le repère, pas de recommandation ferme avant. »\n   - La contre-lecture (§ 7)")
rep("   - Recommandation de l'auteur : (a), confiance 0,85 ; la contre-lecture la partage.",
    "   - Recommandation de l'auteur : (a), confiance 0,85 ; la contre-lecture la partage.\n   - " + REC.capitalize() + " : (a), confiance 0,85.")
rep("   - Recommandation de l'auteur : (a), confiance 0,8.\n",
    "   - Recommandation de l'auteur : (a), confiance 0,8.\n   - " + REC.capitalize() + " : (a), confiance 0,8.\n")

# --- correction 2 (titre du § 9) et recommandation sur m4
rep("## 9. Nœud ouvert de la v2 (m4, classe B)\n", "## 9. Nœud ouvert de la v2 (m4)\n")
rep("- À trancher à la relecture de la v2 (ou par Lazar, si la relecture y voit une décision) ; la configuration v2 porte la question dans « ce_qui_reste_ouvert », sans choix.\n",
    "- À trancher à la relecture de la v2 (ou par Lazar, si la relecture y voit une décision) ; la configuration v2 porte la question dans « ce_qui_reste_ouvert », sans choix.\n"
    "- " + REC.capitalize() + " (le nœud reste ouvert ; la v3 porte la question comme la v2) : option 2, ne pas geler, confiance 0,6.\n"
    "  - « Geler ne garde rien si le lanceur reproduit les fonctions au lieu de les importer.\n"
    "  - Cela lierait des fichiers entiers de lanceurs passés. `manifeste.py` devra vraisemblablement changer pour déclarer le type conservé (C3) ; je n'ai pas vu ce fichier.\n"
    "  - `pieces_citees` porte déjà l'empreinte des cinq fichiers : la contre-lecture du lanceur a une cible exacte.\n"
    "  - L'argument du coût d'une version nouvelle tombe si la correction 1 en impose une de toute façon.\n"
    "  - Si les lanceurs importent ces fonctions, je pencherais pour l'option 1. »\n")
dst.write_text(t, encoding="utf-8")
print("écrit", dst)
