import sys
heure = sys.argv[1]
src = "/home/user/controle-ia-travail/prereg/lecture-sondes-barreau8-v1-addendum-organisme-change-v1-brouillon2.md"
dst = src.replace("brouillon2.md", "brouillon3.md")
t = open(src, encoding="utf-8").read()
def rep(old, new):
    global t
    n = t.count(old)
    assert n == 1, (old[:80], n)
    t = t.replace(old, new)
REC = "*Recommandation de Fable, relecture du 21 novembre* : "

# A
rep("Tant que l'état de l'un d'eux porte le marqueur, le validateur refuse le scellement.\n",
    "Tant que l'état de l'un d'eux porte le marqueur, le validateur refuse le scellement. Fermer un nœud change ce texte hors des lieux permis par la règle du scellement : les deux nœuds sont fermés dans un brouillon, avant la contre-lecture finale, qui relit ce brouillon-là.\n")
rep("**Statut : brouillon 2, texte soumis à la vérification des corrections et à la contre-lecture finale, puis au scellement s'il y est dit prêt (statut écrit sous sa forme définitive : il ne change pas au scellement). C'est un écart",
    "**Statut : brouillon 3, texte soumis à la vérification des corrections ; nœuds NO-1 et NO-2 ouverts : ce brouillon n'est pas celui de la contre-lecture finale, et le statut définitif s'écrit au brouillon qui les ferme.** **C'est un écart")
rep("; statut écrit sous sa forme définitive ;", "; statut définitif renvoyé au brouillon qui ferme NO-1 et NO-2 ;")
# B
rep("| D-1, D-2, D-11 ; « Code, registre et contrôle de conformité » : six clés ; bordereaux du code à sept et six clés | une clé de plus au registre ; deux de plus à chaque bordereau ; nouvelle conformité ; lignes comptées après celle de l'additif | « Codes, registre propre et nouvelle conformité » |\n",
    "| D-1, D-2, D-11 ; « Code, registre et contrôle de conformité » : six clés ; bordereaux du code à sept et six clés ; liste d'arrêt, ligne 5 | une clé de plus au registre ; deux de plus à chaque bordereau ; nouvelle conformité ; lignes comptées après celle de l'additif ; la ligne 5 se lit avec la ligne 23 | « Codes, registre propre et nouvelle conformité » ; « Liste d'arrêt », ligne 23 |\n")
rep("et la ligne de la remarque 8) ;", "et la ligne de la remarque 8) ; liste d'arrêt, ligne 5, ajoutée à la ligne des codes et du registre ;")
# C
rep("NL-3 porte les deux clés neuves | table de la fiche des champs ; NL-3, option (a) |",
    "NL-3 porte les deux clés neuves et, parmi les nœuds, les types des identifiants | table de la fiche des champs ; NL-3, option (a) |")
rep("| sans remarque | en-tête : titre, date et correcteur du brouillon 2 (provenance) ; D-15 : une réponse à la question E-1 absente au départ de l'étalonnage vaut « oui » pour la clé neuve, par la règle de l'additif déjà écrite ; usage de D-15 : « non » à la clé neuve est un écart (ligne 22), conséquence de la remarque 3 | en-tête ; D-15 |\n",
    "| sans remarque | en-tête : titre, date et correcteur du brouillon 2 (provenance) ; D-15 : une réponse à la question E-1 absente au départ de l'étalonnage vaut « oui » pour la clé neuve, par la règle de l'additif déjà écrite ; usage de D-15 : « non » à la clé neuve est un écart (ligne 22), conséquence de la remarque 3 ; « Rien n'a été réglé » : « l'empreinte de ce brouillon » devient « l'empreinte du brouillon 1 » | en-tête ; D-15 ; « Rien n'a été réglé » |\n")
# D
rep("**Règle** : le texte scellé ne diffère du texte relu par cette contre-lecture qu'aux lieux permis",
    "**Règle** : le texte soumis au scellement ne diffère du texte relu par cette contre-lecture qu'aux lieux permis")
# E
rep("Restent attestés seulement : `contexte.texte_prive` (tenu en outre par la garde P8), `modes_de_sabotage`, `oracle.entree_d_un_moniteur`, `lectures`, `taches.reserve_jouee_par_l_evaluation`, `livraison.passe_conduite_par`.",
    "Restent attestés seulement : `contexte.texte_prive` (tenu en outre par la garde P8), `contexte.recette_egale_a_la_version_6`, `adaptateurs.pose_egale_a_la_version_6`, `modes_de_sabotage`, `oracle.entree_d_un_moniteur`, `lectures`, `taches.reserve_jouee_par_l_evaluation`, `livraison.passe_conduite_par`.")
# F
rep("puisque la règle qui la fait était scellée avant toute sortie (règles R1 et R3)",
    "puisque la règle qui la fait était scellée avant la première sortie qui borne l'additif (règles R1 et R3)")
# G
import re
lignes = [l for l in t.split("\n") if l.startswith("| 6 — mots qui font écho à la note de couverture |")]
assert len(lignes) == 1
rep(lignes[0] + "\n",
    "| 6 — formulation de trois passages ; ce que le rédacteur connaissait | passages reformulés comme la contre-lecture l'écrit ; déclaration dans « Rien n'a été réglé » ; « son rédacteur ne les connaît pas » nuancé en tête | NL-8 ; RP-6 ; NL-3, option (c) ; « Rien n'a été réglé » ; « Statut » |\n")
# I
rep("- **Contre-lecture 2 (finale, texte rempli)** — À REMPLIR :",
    "- **Relecture des corrections** — Claude Fable 5.2, appelé par l'API, autre agent que le rédacteur, même modèle ; pièces lues, en copies nettoyées seulement : le brouillon 2 (empreinte d'origine `b64e89042e1852b3f1ce630b638cbf7b0c47d088298a6b728f31c27c9be3eec2`), la contre-lecture 1 et le brouillon 1. Rapport : `docs/notes/relecture-fable-api-v1/relectures/3-additif-sondes-barreau8/relecture-fable-api.md`, empreinte `06a751c6b835bf4359d871b08912067a959c1c4157d14f5064238a1af04d8285`. Conclusion : « à corriger ». Traitement de chaque correction : table « Corrections de la relecture de Fable (brouillon 2 → brouillon 3) » en tête de ce texte.\n- **Contre-lecture 2 (finale, texte rempli)** — À REMPLIR :")
# Recommandations sur NO-1, NO-2
rep("du programme de comparaison est à relire. État : À REMPLIR.",
    "du programme de comparaison est à relire. " + REC + "(a), le déclarer ; confiance 0,7. Avec k = 1, le taux du sous-échantillon est celui du texte scellé (une action sur 16, une sur 128). Le plancher de 81 et 11 a été écrit pour le cas où l'additif élargit lui-même le pas, donc baisse ce taux. L'option (b) ajouterait un seuil que le texte scellé n'a pas ; toute course de 1 265 actions ou moins deviendrait un nœud. Sous (a), la déclaration devrait nommer le plancher qui reste (« au moins 10 », gardes P7 et P10). Ce qui me ferait changer : que la limite déclarée de la garde r6, dans le texte scellé, raisonne sur le nombre (161, 21) et non sur le taux. (Le nœud reste ouvert.) État : À REMPLIR.")
rep("change. État : À REMPLIR.",
    "change. " + REC + "(a), le dire ; confiance 0,6. La lecture reste protégée mécaniquement : la commande de lecture refuse sans la pièce « conforme » (ligne 16). Une passe partie à tort coûte du calcul et fait un écart, pas une lecture fausse. L'option (b) lie le bordereau de la passe à une pièce qui existe en deux versions. Une version nouvelle après la ligne de code demanderait une seconde ligne `CODE-PASSE-IIB`, contre « exactement une ligne ». Elle touche aussi NL-5, le compte des clés, RP-12 et les essais, avant un étalonnage visé les 23 et 24 novembre. Sous (a), il faut rendre vraie la phrase de tête des conditions de départ (« chacune est refusée mécaniquement si elle manque ») : pour la passe, D-6 est tenue par le contrôle de la session mère. Ce qui me ferait changer : un devis de passe élevé aux tailles de la version 7 (NL-8), ou Lazar qui refuse un contrôle porté par la seule session mère. (Le nœud reste ouvert.) État : À REMPLIR.")
# Tenue de version
rep("(barreau 8) : la course lue est celle de l'organisme changé — v1 — brouillon 2\n",
    "(barreau 8) : la course lue est celle de l'organisme changé — v1 — brouillon 3\n")
rep("il n'a vu aucune consigne privée, aucune conception, aucun ordre, aucune sortie.\n",
    "il n'a vu aucune consigne privée, aucune conception, aucun ordre, aucune sortie. **Correcteur du brouillon 3** : Claude Opus 5.5, effort maximal, sous-agent du côté des moniteurs, même règle (GO-2026-11-21-84) ; il n'a écrit ni le texte scellé, ni les brouillons 1 et 2, ni la contre-lecture 1, ni la relecture, ni aucun code, ni la note de couverture ; il n'a porté que les corrections de la relecture de Fable 5.2 (section « Contre-lecture », entrée « Relecture des corrections »), au texte exact qu'elle donne, dans la pièce d'origine et avec ses noms d'origine (Fable a relu des copies nettoyées), et a recopié ses recommandations dans les nœuds ouverts sans les trancher. Il a lu le brouillon 2 (empreinte vérifiée) et la relecture (empreinte vérifiée), rien d'autre de ce dossier ; il n'a ouvert ni le texte scellé, ni la note de couverture, ni le validateur ; il n'a vu aucune consigne privée, aucune conception, aucun ordre, aucune sortie.\n")
rep("brouillon 2 écrit le 2026-11-21 entre 20:43Z et 20:46Z (temps universel, `date -u`).",
    "brouillon 2 écrit le 2026-11-21 entre 20:43Z et 20:46Z ; brouillon 3 écrit le 2026-11-21 à partir de " + heure + " (temps universel, `date -u`).")
table = """## Corrections de la relecture de Fable (brouillon 2 → brouillon 3)

Relecture : `docs/notes/relecture-fable-api-v1/relectures/3-additif-sondes-barreau8/relecture-fable-api.md`, empreinte `06a751c6b835bf4359d871b08912067a959c1c4157d14f5064238a1af04d8285`, verdict « à corriger », sur le brouillon 2 (`b64e89042e1852b3f1ce630b638cbf7b0c47d088298a6b728f31c27c9be3eec2`). Correcteur : Claude Opus 5.5 (en-tête, « Auteur »). Chaque correction est portée au texte exact que la relecture donne, et rien d'autre ; les nœuds ouverts restent ouverts.

| correction de Fable | lieu | fait |
|---|---|---|
| A — « Nœuds ouverts » : phrase sur la fermeture des nœuds hors des lieux permis ajoutée à « Tant que l'état… refuse le scellement. » | « Nœuds ouverts » ci-dessous | fait |
| A — statut, branche « s'il les laisse ouverts » (le correcteur ne ferme aucun nœud) : première phrase remplacée ; table des corrections de la contre-lecture 1, ligne 2 : « statut écrit sous sa forme définitive » devient « statut définitif renvoyé au brouillon qui ferme NO-1 et NO-2 » | « Statut » ; ligne 2 de la table ci-dessous | fait ; « brouillon 2 » devient « brouillon 3 » au titre et à la date |
| B — ligne 5 de la liste d'arrêt : ligne « D-1, D-2, D-11… » de la table des passages touchés remplacée ; ligne 4 de la table des corrections complétée après « et la ligne de la remarque 8) » | « Passages du texte scellé touchés » ; ligne 4 de la table ci-dessous | fait ; le couple « ligne 5, ligne 23 » reste à vérifier sur le texte scellé, comme la relecture le dit (non ouvert par le correcteur) |
| C — changements à déclarer : fin de la cellule « correction » de la ligne 5 ; ligne « sans remarque » remplacée | table ci-dessous, lignes 5 et « sans remarque » | fait |
| D — entrée « Contre-lecture 2 », règle : « le texte scellé » devient « le texte soumis au scellement » | « Contre-lecture », entrée « Contre-lecture 2 » | fait |
| E — « Ce qui n'est pas cru sur parole » : liste « Restent attestés seulement » remplacée (deux clés neuves ajoutées) | « Note d'interface version 7… », « Ce qui n'est pas cru sur parole » | fait ; le rang de `identifiants.types` (garde P3 ?) est laissé au contre-lecteur, comme la relecture le dit |
| F — NL-4, option (a) : « puisque la règle qui la fait était scellée avant toute sortie (règles R1 et R3) » remplacé | « Nœuds pour Lazar », NL-4, option (a) | fait |
| G — table des corrections, ligne 6, remplacée | ligne 6 de la table ci-dessous | fait ; le signalement de Fable (tenir le brouillon 1 et le rapport de la contre-lecture 1 hors des pièces du lecteur, du juge et de l'auditeur) est pour la session mère, non écrit dans l'additif |
| H — en-tête, ce que le correcteur du brouillon 2 a lu : texte de remplacement donné pour le seul cas où la note de couverture n'a pas été lue | en-tête, « Correcteur du brouillon 2 » | **non portée, à revoir** : la condition n'est pas établie par le correcteur du brouillon 3 (aucun rapport du correcteur du brouillon 2 sur disque ; la phrase actuelle se lit des deux façons) ; à trancher par la session mère, qui a lancé ce correcteur : si la note n'a pas été lue, porter le texte de Fable ; si elle l'a été, l'écrire et porter le correcteur à la table des expositions |
| I — entrée « Relecture des corrections » insérée avant « Contre-lecture 2 », chemin et empreinte du rapport remplis | « Contre-lecture » | fait ; le report du correcteur et du relecteur à la table des expositions (par AD-2) est laissé à la session mère, comme la relecture le dit |
| Recommandations de Fable sur NO-1 ((a), confiance 0,7) et NO-2 ((a), confiance 0,6) | « Nœuds ouverts », NO-1 et NO-2 | recopiées, marquées « recommandation de Fable, relecture du 21 novembre », devant « État : À REMPLIR » ; nœuds non tranchés |

"""
rep("## Corrections de la contre-lecture 1 (brouillon 1 → brouillon 2)\n", table + "## Corrections de la contre-lecture 1 (brouillon 1 → brouillon 2)\n")
open(dst, "w", encoding="utf-8").write(t)
print("écrit", dst)
