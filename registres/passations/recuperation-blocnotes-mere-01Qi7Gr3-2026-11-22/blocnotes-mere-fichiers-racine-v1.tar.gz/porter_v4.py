import re, sys, hashlib, pathlib
D = pathlib.Path("/home/user/controle-ia-travail/docs/notes/demandes-fable-api-2026-11-22-v1")
rel = (D/"relecture-pieces-essaim-v3/relecture-fable-api.md").read_text(encoding="utf-8")
v3 = (D/"pieces-comparaison-essaim-v3.md").read_text(encoding="utf-8")
corps = rel.split("\n---\n",1)[1]
paras = re.split(r"\n\s*\n", corps)
blocs = []
for i,p in enumerate(paras):
    if p.strip().startswith("**ANCIEN**"):
        assert paras[i+2].strip() == "**NOUVEAU**", paras[i+2]
        blocs.append((p.strip(), paras[i+1].strip(), paras[i+3].strip()))
if len(blocs) != 2: sys.exit(f"ARRÊT : {len(blocs)} blocs ANCIEN/NOUVEAU au lieu de 2")
out = v3
for tete, a, n in blocs:
    c = out.count(a)
    if c != 1: sys.exit(f"ARRÊT : ANCIEN trouvé {c} fois : {a[:80]}")
    out = out.replace(a, n)
    print("PORTÉ", tete, "|", a[:60], "->", n[:60])
h = lambda s: hashlib.sha256(s.encode()).hexdigest()
entete = f"""Version 4 : corrections de la relecture 44b7d86e… portées par Opus 5.5

- Base : `docs/notes/demandes-fable-api-2026-11-22-v1/pieces-comparaison-essaim-v3.md`, sha256 {h(v3)}.
- Remarques : `docs/notes/demandes-fable-api-2026-11-22-v1/relecture-pieces-essaim-v3/relecture-fable-api.md`, sha256 {h(rel)}.
- Table des corrections : `docs/notes/demandes-fable-api-2026-11-22-v1/table-corrections-pieces-essaim-v4.md`.
- Épreuve des motifs rejouée (correction 43) : `docs/notes/demandes-fable-api-2026-11-22-v1/epreuve-motifs-correction-28-v2.md`.
- En-tête de la version 3, gardé tel quel ci-dessous.

"""
(D/"pieces-comparaison-essaim-v4.md").write_text(entete+out, encoding="utf-8")
