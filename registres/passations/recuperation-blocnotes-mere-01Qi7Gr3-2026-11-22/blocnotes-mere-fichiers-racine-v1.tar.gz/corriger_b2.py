"""Porte les remarques de la contre-lecture d'Opus v1 dans le brouillon 2 (remplacements exacts, chacun unique)."""
import sys
from pathlib import Path

src = Path(sys.argv[1])
dst = Path(sys.argv[2])
t = src.read_text(encoding="utf-8")

B1 = "ff6fac2bd7f54143d4b009d944c83aaca7c78ef9bda32282b181a5db6000b6ac"
CL = "e29fee75dac0dfe05391818925cece69523c1577961c24e7fb54b5192ce2ba0f"
PY2 = "6abcbed85fb278637b23fb85685d1d015b7b0aeb518c88fff634c85581a28b21"
TX2 = "28884adb2e3f2edc8ee1f55925233726223f56e3e98742957056820024ba9244"
CHEMIN_CL = "docs/notes/sparks-exp7-nul-relance-v1/contre-lecture-sparks-v2-brouillon1-opus-v1.md"
MARQ = "<<RELANCES_ET_DENOMINATEUR_DE_LA_LIGNE_DES_10_POURCENT>>"

R = []  # (ancien, nouveau)

# Titre et statut
R.append(("sous paires nulles et aveuglement — v2, brouillon 1\n",
          "sous paires nulles et aveuglement — v2, brouillon 2\n"))
R.append(("**Statut : brouillon 1 du texte neuf, non contre-lu, non scellable en l'état** (huit marqueurs ouverts, douze nœuds pour Lazar).",
          "**Statut : brouillon 2 du texte neuf, contre-lu une fois (« à corriger »), corrections portées, non relues, non scellable en l'état** (huit marqueurs ouverts du brouillon 1, un marqueur neuf pour un nœud ouvert par la correction, douze nœuds pour Lazar). Le brouillon 1 reste intact (R12)."))

# En-tête : correcteur
R.append(("- Date (UTC) : 21 novembre 2026, rédaction ouverte à 19:09, close à 19:47 (`date -u`).\n",
          "- Date (UTC) : 21 novembre 2026, rédaction ouverte à 19:09, close à 19:47 (`date -u`).\n"
          "- **Correcteur du brouillon 2** : Claude Opus 5.5, effort maximal, sur la règle de GO-2026-11-21-84 (« Opus 5.5, en effort maximal, écrit seulement les corrections, mot pour mot d'après les remarques déjà reçues », puis relecture par Fable 5.2 appelé par l'API, puis scellement). Corrections écrites le 21 novembre 2026 vers 20:44 UTC (`date -u`), dépôt à `ca192f165`. Brouillon relu : `prereg/SPARKS-EXP7-NUL-preenregistrement-v2-brouillon1.md`, `" + B1 + "`. Contre-lecture portée : `" + CHEMIN_CL + "`, `" + CL + "`. Rien n'est changé hors de la table « Corrections du brouillon 2 » ; les choix que la contre-lecture laisse ouverts sont écrits en nœuds ouverts, non tranchés.\n"))

# En-tête : calculs du brouillon 2
R.append(("(citée « calc, X » pour son bloc X ; lois binomiales exactes, rejouée à l'identique sous deux Python) ;",
          "(lois binomiales exactes, rejouée à l'identique sous deux Python) ; au brouillon 2, `calculs-preenregistrement-v2-brouillon2-v1.py`, `" + PY2 + "`, et sa sortie `.txt`, `" + TX2 + "` : le même script, avec deux ajouts seulement (bloc H : taux d'erreur des seuils du contrôle causal, remarque I-5 ; bloc I : règle de trois de la variante sans carte, remarque m-8), rejoué sous le Python du système et sous `.venv` (Python 3.13.18), sorties identiques à l'octet ; ses autres lignes sont identiques à celles du brouillon 1 ; « calc, X » cite désormais cette version, pour son bloc X ;"))

# Marqueurs ouverts
R.append(("`<<TETE_DES_JOURNAUX>>`, `<<CAUSE_DE_L_ECHEC_SUR_LA_CARTE>>`.\n",
          "`<<TETE_DES_JOURNAUX>>`, `<<CAUSE_DE_L_ECHEC_SUR_LA_CARTE>>` ; et, neuf au brouillon 2, `" + MARQ + "` (nœud ouvert par la remarque I-4, point iv).\n"))

# m-12
R.append(("Les quatre décisions prises sur l'addendum sont gardées :",
          "Les quatre décisions prises par conv-audit, et non par Lazar, sur les options de la contre-lecture de l'addendum (ad1, l. 17) sont gardées :"))

# m-4 (C-4)
R.append(("| C-4 | Niveau d'effort des lecteurs non écrit → **écrit** : celui du billet pour l'expérience 7 |",
          "| C-4 | Niveau d'effort des lecteurs non écrit → **écrit** : celui du billet pour l'expérience 7 (même nom de niveau que le billet ; équivalence non établie) |"))

# m-5
R.append(("La base boîte noire et la base scriptée y sont aussi. Régime : très petits réseaux, un réseau à la fois |",
          "La base boîte noire et la base scriptée y sont aussi. Régime : très petits réseaux |"))

# m-6
R.append(("| La désignation entre deux modèles voisins est une forme publiée en 2025 |",
          "| La désignation entre deux modèles voisins est une forme publiée en 2025. Régime : réseaux convolutifs (« We experiment using CNNs », p. 1) |"))

# m-13 (réemploi)
R.append(("| repris à l'octet | « écrits avant tout entraînement » reste vrai : aucun entraînement n'a eu lieu |",
          "| repris à l'octet | « écrits avant tout entraînement » reste vrai : aucun entraînement n'a eu lieu ; tirés de gabarits de faits absents de tous les partages (v1, l. 70) : c'est leur raison d'être |"))

# m-4 (Lecteurs)
R.append(("« xhigh » [S : p3, l. 23], si le client l'admet pour le modèle lecteur ;",
          "« xhigh » [S : p3, l. 23, nom d'un niveau du client des auteurs pour Astra], si le client l'admet pour le modèle lecteur : même nom de niveau que le billet ; équivalence non établie ;"))

# I-4
R.append(("sinon elle est relancée **une** fois à neuf [P : le moins possible], les deux traces gardées et rapportées. La règle est appliquée par script, sans regarder le contenu.\n",
          "sinon elle est relancée **une** fois à neuf [P : le moins possible], les deux traces gardées et rapportées. La règle est appliquée par script, sans regarder le contenu.\n"
          "  - (i) **Signaux de transport.** La liste des signaux de transport qui classent une fin en « refus ou coupure du fournisseur » ou en « panne » (codes d'erreur, quota, réseau, redémarrage) est figée à l'ordre de course, avant toute conversation, et appliquée par script.\n"
          "  - (ii) **Seule la réponse de la conversation relancée compte.** La trace interrompue est gardée, ne compte pour rien, et n'est pas lue avant l'ouverture du coffre.\n"
          "  - (iii) **Une seconde interruption du même cas vaut « coupée »**, donc un échec.\n"
          "  - (iv) **Nœud ouvert** (remarque I-4, point iv ; non tranché au brouillon 2) : si les conversations relancées comptent dans la ligne d'arrêt des 10 % (section « Liste d'arrêt »), et quel est le dénominateur de cette ligne : 51 avec l'ancre, ou 48. `" + MARQ + "`.\n"))

# m-13 (B1)
R.append(("Sur les mêmes 16 textes : pour chaque tête,",
          "Sur les mêmes 16 textes, tirés de gabarits de faits **absents de tous les partages** (v1, l. 70) : pour chaque tête,"))

# I-1 (d)
R.append(("atteint 0,75 sur 8 paires contre 4 dans 53 tirages sur 495, soit 0,107 (calc, F) ;",
          "atteint 0,75 sur 8 paires contre 4 dans 53 tirages sur 495, soit 0,107 (calc, F) ; les 12 paires de l'étalonnage partagent leurs modèles, 4 par groupe : elles ne sont pas indépendantes, et ce 0,107 est un ordre de grandeur, non un risque exact ;"))

# I-2
R.append(("θ_0 est le modèle de départ à la révision consignée ; θ_m les tenseurs tels que servis ; calcul en double précision.",
          "θ_0 est le modèle de départ à la révision consignée ; θ_m les tenseurs **tels que servis** (bf16 lus exactement en float32 ; sur l'étalonnage, les couches bf16 stockées par la recette, `recette.py` : l. 231, mêmes valeurs que des copies servies) ; θ_0 arrondi en bf16 de la même façon (sans effet s'il est publié en bf16, à consigner) ; calcul en float64, double précision [S : ad1, § Bases et plafond]."))

# I-3
R.append(("Ce qu'il ne montre pas : B4 ainsi orientée n'est pas une règle qu'un lecteur aurait pu appliquer.\n",
          "Ce qu'il ne montre pas : B4 ainsi orientée n'est pas une règle qu'un lecteur aurait pu appliquer. Seuil : celui qui maximise l'exactitude équilibrée de o₄ · n sur l'étalonnage (`bases.seuil_exactitude_equilibree`), calculé avec o₄ ; l'orientation que donnerait l'étalonnage seul (+1 si l'aire de n sur 4 contre 4 vaut 0,5 ou plus, sinon −1) est rapportée, descriptive [S : ad1, § Bases et plafond].\n"))

# m-10
R.append(("et, neuves : `dispersion-reechantillonnage`, `contraste-reechantillonnage`, `pilotes`.\n",
          "et, neuves : `dispersion-reechantillonnage`, `contraste-reechantillonnage`, `pilotes`.\n"
          "- **Ordre d'emploi pour les secondaires de l'incrément** [S : ad1, l. 712] : les générateurs du principal (`increment-<b>-reechantillonnage`, `increment-<b>-permutation`) sont repris **après** le calcul principal, dans cet ordre : par lecteur (ici le second lecteur, s'il est accordé), cas complets, puis exactitude d'ordre, discrimination entre paires nulles et aire du lecteur moins aire de la base (rééchantillonnage seul) ; aucune clé de tâche de plus.\n"
          "- **Intervalle de la marque « types de paires séparables par l'ampleur »** : celui de l'aire « vraie contre nulle » de la dispersion entre graines, tiré par `dispersion-reechantillonnage`.\n"))

# m-11
R.append(("Aucune étape ne commence avant la fin de la précédente. Aucune lecture de résultat avant le scellement de ce texte (R1).\n",
          "Aucune étape ne commence avant la fin de la précédente. Aucune lecture de résultat avant le scellement de ce texte (R1). Graines, clés de tâche et ordre d'emploi des générateurs : section « Graines et manifeste ».\n"))

# I-5
R.append(("entre les deux, de 3 à 5 : non concluant (v1, l. 119 ; calc, H).\n",
          "entre les deux, de 3 à 5 : non concluant (v1, l. 119 ; calc, H). Taux d'erreur de ces seuils, par loi binomiale exacte, unités supposées indépendantes (calc, H) :\n"
          "\n"
          "| Part vraie d'unités porteuses | P(6 ou plus sur 24) | P(2 ou moins sur 24) |\n"
          "|---|---|---|\n"
          "| 0,05 | 0,001 | 0,884 |\n"
          "| 0,10 | 0,028 | 0,564 |\n"
          "| 0,25 | 0,578 | 0,040 |\n"
          "| 0,35 | 0,896 | 0,003 |\n"
          "\n"
          "  Lecture : les deux seuils gardent un risque faible de mauvaise classe aux deux bouts. Mais avec une part vraie de 0,25, « porteurs » n'est déclaré qu'une fois sur deux environ. Avec 0,10, « non porteurs » ne l'est qu'un peu plus d'une fois sur deux.\n"))

# I-1 (a)
R.append(("| **La détection tient sous nul, au-delà de la distance au départ** (Q1 : oui) |",
          "| **La détection tient sous nul, au-delà de la distance au départ** (Q1 : oui) ; si la marque « types de paires séparables par l'ampleur » est posée : **La détection tient sous nul, au-delà de la distance au départ — types de paires séparables par l'ampleur, scission non probante** (Q1 : oui ; types de paires séparables par l'ampleur, scission non probante) |"))
R.append(("| **Détection sous nul, non distinguée de la distance au départ** (Q1 : non établi au-delà des bases), qualifiée",
          "| **Détection sous nul, non distinguée de la distance au départ** (Q1 : non établi au-delà des bases) ; si la marque « types de paires séparables par l'ampleur » est posée : **Détection sous nul, non distinguée de la distance au départ — types de paires séparables par l'ampleur, scission non probante** (Q1 : non établi au-delà des bases ; types de paires séparables par l'ampleur, scission non probante) ; dans les deux cas, qualifiée"))

# m-9
R.append(("| Nom ou forme d'un tenseur absent au portage ; distance au départ ou normes incalculables sur l'étalonnage ou sur un cas servi |",
          "| Nom ou forme d'un tenseur absent au portage ; distance au départ, normes ou ampleur de l'écart incalculables sur l'étalonnage ou sur un cas servi |"))
R.append(("| Candidat de l'étape 0 inaccessible |",
          "| Révision de Gemma plus servie (section « Modèles ») | Arrêt ; nœud de Lazar |\n| Candidat de l'étape 0 inaccessible |"))

# I-1 (c)
R.append(("| **Pas d'arrêt** (C-6) ; rapporté avant tout lecteur |",
          "| **Pas d'arrêt** (C-6) ; rapporté à Lazar, pour information, avant tout lecteur, sans rien suspendre |"))

# m-8
R.append(("| de l'ordre de 75 h pour 122 modèles et 2 016 mesures causales |",
          "| de l'ordre de 75 h pour 122 modèles et 2 016 mesures causales, dont 26 h de contrôle causal (v1, l. 190) ; le plan en a 1 632 : environ 21 h de contrôle causal par la même règle de trois (calc, I) |"))

# m-7
R.append(("| Jetons de sortie et de réflexion du lecteur | non chiffrés par conversation dans les sources | à mesurer sur les pilotes | — |",
          "| Jetons de sortie et de réflexion du lecteur | non chiffrés par conversation dans les sources ; repère agrégé : environ 1,1 million de jetons de sortie pour les 15 conversations de l'expérience 7, dont 12 sans l'outil d'attention | à mesurer sur les pilotes | p3, l. 108 ; p3, l. 42 (4 tentatives sur 3 paires sans l'outil) |"))

# m-2, m-1
R.append(("le second d'un autre modèle Claude hors Fable (Claude Sonnet 5.5), en lecture secondaire",
          "le second d'un autre modèle Claude hors Fable, à nommer par Lazar, identifiant vérifié avant le devis, en lecture secondaire"))
R.append(("(d) Deux lecteurs, Opus 5.5 et Fable 5.1, comme le texte v1 : entame un quota rare.",
          "(d) Deux lecteurs, Opus 5.5 et Fable 5.1, comme le texte v1 : quota de Fable 5.1 : à dire par Lazar."))

# I-1 (b)
R.append(("(c) L'arrêt gardé, avec un jeu d'étalonnage plus grand : des modèles de plus. Recommandation : (a) ; confiance 0,75.",
          "(c) L'arrêt gardé, avec un jeu d'étalonnage plus grand : des modèles de plus. (d) L'option écrite d'avance par le texte v1 (l. 71) : paires nulles à données permutées, même graine et même ordre que la paire vraie ; coût : des modèles de plus, une fabrication autre. Recommandation : (a) ; confiance 0,75."))

# m-3
R.append(("l'environnement à processeur est celui où les 361 essais passent ;",
          "un environnement à processeur comme celui de la session ; suite à rejouer sur la machine ;"))

# Section Contre-lecture : inscription de la contre-lecture 1
R.append(("## Contre-lecture\n\nPas encore faite (brouillon 1). À faire par",
          "## Contre-lecture\n\n"
          "- **Contre-lecture 1** : Claude Opus 5.5, agent neuf (R2), sur le brouillon 1, `prereg/SPARKS-EXP7-NUL-preenregistrement-v2-brouillon1.md`, sha256 `" + B1 + "` ; rapport `" + CHEMIN_CL + "`, sha256 `" + CL + "` ; verdict « à corriger » : cinq corrections importantes (I-1 à I-5) et treize mineures (m-1 à m-13), toutes portées dans ce brouillon 2 par Claude Opus 5.5, correcteur (table « Corrections du brouillon 2 »), sauf les choix laissés en nœuds ouverts. Relecture des corrections : par Fable 5.2 appelé par l'API, à faire (GO-2026-11-21-84) ; la contre-lecture dit que la vérification des corrections revient au même contre-lecteur.\n\n"
          "Au brouillon 1 : pas encore faite. Consigne du rédacteur, gardée telle quelle : à faire par"))

# Pied
R.append(("non conforme au validateur du dépôt tant que la contre-lecture n'y est pas inscrite et que les huit marqueurs restent ouverts : c'est voulu.",
          "non conforme au validateur du dépôt tant que la contre-lecture n'y est pas inscrite et que les huit marqueurs restent ouverts : c'est voulu.\n"
          "Brouillon 2 (21 novembre 2026) : corrections de la contre-lecture d'Opus v1 (`e29fee75…`) portées par Claude Opus 5.5, correcteur (GO-2026-11-21-84), sans autre changement ; scellé par son compagnon d'empreinte comme brouillon ; non conforme au validateur tant que des marqueurs restent ouverts : c'est voulu."))

for ancien, nouveau in R:
    n = t.count(ancien)
    if n != 1:
        sys.exit(f"ancre trouvée {n} fois : {ancien[:90]!r}")
    t = t.replace(ancien, nouveau)

# Table des corrections, en tête (avant « Ce que ce texte change »)
TABLE = Path(sys.argv[3]).read_text(encoding="utf-8")
ancre = "---\n\n## Ce que ce texte change\n"
assert t.count(ancre) == 1
t = t.replace(ancre, "---\n\n" + TABLE + "\n---\n\n## Ce que ce texte change\n")
dst.write_text(t, encoding="utf-8")
print("ok", len(R), "remplacements")
