import sys
from pathlib import Path
R = Path("/home/user/controle-ia-travail/docs/notes/pieces-manquantes-classe-a-v1/correction-opus-v1")
src, dst = R / "brouillon-1-v2.md", R / "brouillon-1-v3.md"
if dst.exists():
    sys.exit("existe déjà (R12)")
t = src.read_text(encoding="utf-8")
def rep(old, new):
    global t
    n = t.count(old)
    assert n == 1, (n, old[:90])
    t = t.replace(old, new)
REC = "Recommandation de Fable, relecture du 21 novembre"
FAB = "`docs/notes/relecture-fable-api-v1/relectures/5-prevision-reference-honnete-v2/relecture-fable-api.md`, `44e19a13…37a5`"

# ---------------- en-tête (tenue de version)
rep("les deux courbes du rappel selon l'horizon — v2\n", "les deux courbes du rappel selon l'horizon — v3\n")
rep("**Statut : brouillon de travail, version 2 ;", "**Statut : brouillon de travail, version 3 ;")
rep("La version 1 reste intacte (`docs/notes/pieces-manquantes-classe-a-v1/brouillon-1-v1.md`, `08158ab8…9a0c`). Cette version porte les remarques de la contre-lecture d'Opus (`docs/notes/pieces-manquantes-classe-a-v1/contre-lecture-brouillon-1-opus-v1.md`, `7b11cbfe…4f20`, verdict « à corriger »), et rien d'autre. Reste à faire, selon la règle de Lazar (GO-2026-11-21-84) : relecture par Fable 5.2, puis scellement.",
    "La version 1 reste intacte (`docs/notes/pieces-manquantes-classe-a-v1/brouillon-1-v1.md`, `08158ab8…9a0c`), et la version 2 aussi (`docs/notes/pieces-manquantes-classe-a-v1/correction-opus-v1/brouillon-1-v2.md`, `7b5526e3…12a2`). La version 2 porte les remarques de la contre-lecture d'Opus (`docs/notes/pieces-manquantes-classe-a-v1/contre-lecture-brouillon-1-opus-v1.md`, `7b11cbfe…4f20`, verdict « à corriger »), et rien d'autre. La version 3 porte les six corrections de la relecture de Fable 5.2 (" + FAB + ", verdict « à corriger »), et rien d'autre ; Fable a relu une copie nettoyée (« le directeur », « [session] », « [chemin réservé] ») : ses corrections sont portées ici, noms d'origine gardés. Reste à faire, selon la règle de Lazar (GO-2026-11-21-84) : la relecture par Fable 5.2 est faite ; vérification des corrections de la version 3, puis scellement.")
rep("Le « je » du texte reste celui de l'auteur de la version 1 ; chaque ajout du correcteur est marqué « (correction, constat k) ».",
    "Le « je » du texte reste celui de l'auteur de la version 1 ; chaque ajout du correcteur est marqué « (correction, constat k) ». **Correcteur de la version 3** : Claude Opus 5.5 (`claude-opus-5-5`), effort maximal, qui n'écrit que les corrections de la relecture de Fable 5.2 (GO-2026-11-21-84), au texte exact donné, sans marque dans le corps : la table de tête dit leur lieu. Les recommandations de Fable sur les points ouverts sont recopiées à chaque point, marquées « " + REC.lower().replace("fable", "Fable") + " », sans rien trancher.")
rep("version 2, le même jour, de 20:41 à 21:00.", "version 2, le même jour, de 20:41 à 21:00 ; version 3, le même jour, de 22:38 à 23:15.")
rep("à `f07e34854` pour la version 2 (correction, constat 12 c), branche",
    "à `f07e34854` pour la version 2 (correction, constat 12 c), à `d0e6c97a3` pour la version 3, branche")
rep("qui rejoue aussi les blocs A à L à l'identique.",
    "qui rejoue aussi les blocs A à L à l'identique. La version 3 ne change aucun calcul de ce programme : les chiffres neufs de sa correction 1 sont ceux de la relecture, écrits « à rejouer ».")

# ---------------- table de tête
TETE = """## Table des corrections de la relecture de Fable (version 3)

Relecture : """ + FAB + """, verdict « à corriger », 21 novembre, 22:36 UTC ; six corrections, portées au texte exact donné.

| correction de Fable | lieu | fait |
|---|---|---|
| 1. Étape 0, phrase « Risque » : « 28 contrôles supposés indépendants » devient « 28 contrôles supposés indépendants et normaux » ; ajouter après « (bloc R6). » le paragraphe des minorants | « Plan d'analyse », *Lois, tailles d'effet, configurations et tolérances*, phrase « Risque » | Porté mot pour mot. Le paragraphe est inséré après « presque à coup sûr (bloc R6). », seule occurrence de « (bloc R6). ». Ses chiffres (3 et 1,4 fois sur cent ; 10 % et 3 %) sont le « calcul de la relecture, à rejouer » : non rejoués ici, aucun calcul du programme ne change. |
| 2. L15 : remplacer la phrase « Recommandation : au concepteur. À fixer par … avant le scellement : pas de défaut. » | point L15 | Porté mot pour mot, le nom de la copie nettoyée rendu par « Lazar » (nom d'origine). Les choix du correcteur que Fable demande de mettre au nœud y sont mis, sans être tranchés. |
| 3. Ligne « jumeau faussé » : « (1,41 point, dont 1,33 de la dérive du vivier) » | table de l'étape 0, ligne « jumeau faussé » | Porté mot pour mot. Le 1,33 n'est pas une ligne de la sortie du programme (qui donne 1,407 point d'erreur type, bloc R6) : aucun calcul ne change. |
| 4. Table des remarques, constat 4 | table des remarques portées, ligne 4 | Porté mot pour mot. |
| 5. Pas 14, dernière phrase | « Relevé de méthode », pas 14 | Porté mot pour mot. |
| 6. Marqueurs manquants : « **statut au point L16** » ; « Effet de ce tirage sur le taux réalisé du rang : point L18. » | table de l'étape 0, ligne « témoins à taux p » ; « Plan d'analyse », *Tirages* | Portés mot pour mot. |

- **Recommandations de Fable recopiées, sans trancher** : L3, L12, L13, L14, L15, L16, L17, L18, chacune à son point, marquée « recommandation de Fable, relecture du 21 novembre ». « Le directeur » y est rendu par « Lazar ».
- **Constat 5, divergence.** Fable retrouve, par sa re-dérivation, les deux formes du pas 14 et rattache le bloc L à la lecture principale ; il écrit : « je suis le même modèle que l'auteur de la version 1 : mon accord ne remplace pas la vérification par le contre-lecteur ». La divergence reste soumise à cette vérification (point L14) ; rien n'est changé.
- **Relevés par Fable sans correction écrite, non portés, à revoir** : la garde neuve de l'arrêt 7 (« n_max supérieur à W − m ») « doit être éprouvée sur cas sain et artefact comme les autres (R5) » ; ses calculs à la main (minorants, risque d'ensemble, W ≥ 173 m sous L14 = (b)) sont « à rejouer dans le programme » ; ses deux autres conséquences (la tolérance du jumeau faussé contient le taux d'un jumeau exact, portée par la correction 3 ; c₁(m/4) dépasse 100 % environ une fois sur onze) ne sont portées que là où une correction les écrit.

"""

# ---------------- correction 4
rep("Chiffres de la contre-lecture rejoués (99,6 % et 3,3 %, bloc R4).",
    "Chiffres de la contre-lecture rejoués : 99,6 % et 3,3 % (bloc R4), là où elle écrivait 99,5 % et 3,4 %.")
# ---------------- correction 1
rep("28 contrôles supposés indépendants", "28 contrôles supposés indépendants et normaux")
rep("presque à coup sûr (bloc R6).",
    "presque à coup sûr (bloc R6). Ces deux chiffres sont des minorants : pour les taux du rang, l'erreur type est linéarisée, alors que la loi du taux entre viviers est dissymétrique (médiane 0,80 % pour une moyenne de 1 % à n_max, bloc R4). Par la forme non linéaire, le seul taux à n_max sort par le haut environ 3 fois sur cent à trois erreurs types et 1,4 fois sur cent à quatre, pour chacun des deux objets qui le lisent ; le risque d'ensemble est de l'ordre de 10 % et de 3 % (calcul de la relecture, à rejouer). La borne basse de ces tolérances est négative dès n = m, donc sans effet.")
# ---------------- correction 3
rep("(1,41 point, dont 1,33 de la dérive du vivier)",
    "(1,41 point, dont 1,32 de la dérive du vivier ; cette tolérance contient le taux d'un jumeau exact, 1 % : seule la garde sépare alors les deux objets)")
# ---------------- correction 6
rep("**statut au point L16**", "**statut au point L16, À REMPLIR**")
rep("Effet de ce tirage sur le taux réalisé du rang : point L18.", "Effet de ce tirage sur le taux réalisé du rang : point L18, À REMPLIR.")
# ---------------- correction 5
rep("La même forme, écrite de façon indépendante, figure dans le fichier interrompu de l'auteur (bloc P1 de sa sortie) ; ce n'est pas une contre-lecture.",
    "La même forme figure dans le fichier interrompu de l'auteur (bloc P1 de sa sortie), que le correcteur a lu comme matière : l'accord des deux formes ne vaut ni dérivation indépendante ni contre-lecture.")
# ---------------- correction 2 (L15) et recommandation de Fable sur L15
rep("Recommandation : au concepteur. À fixer par Lazar avant le scellement : pas de défaut.",
    "Entrent aussi dans ce nœud, choisis par le correcteur pour porter le constat 6 : la taille d'effet plantée (c₁(m) = 0,60, qui met c₁(m/4) à 0,95 et c₂(m/4) à 1,03, au bord et hors de la plage), la loi commune, le vivier partagé, la règle « tolérance de la version 1 si elle est plus large », et la façon de borner les taux du rang (multiple d'une erreur type linéarisée, ou bornes sur le rang centré moyen du vivier). Les risques ci-dessus sont des minorants (voir l'étape 0). Recommandation : au concepteur. À fixer par Lazar avant le scellement : pas de défaut. "
    + REC + " : « 20 000 configurations, quatre erreurs types, un seul rejeu rapporté avec le premier. Borner les taux du rang sur le rang centré moyen du vivier, dont la loi est normale, plutôt que par une erreur type linéarisée. Confiance 0,5. »")

# ---------------- recommandations recopiées aux autres points
rep("Cette recommandation reposait sur le chiffre du bloc L ; elle est à revoir par le concepteur sur les chiffres du bloc R5 et selon le choix du point L14 (correction, constat 5). À fixer par Lazar : pas de défaut.",
    "Cette recommandation reposait sur le chiffre du bloc L ; elle est à revoir par le concepteur sur les chiffres du bloc R5 et selon le choix du point L14 (correction, constat 5). À fixer par Lazar : pas de défaut. "
    + REC + " : « (A) tient si L14 = (a), les chances passant de 91 à 89-90. Confiance 0,55. Sous (b), W/60 ne suffit pas : attester la validité jusqu'à 4m neuf fois sur dix demande environ W ≥ 173 m (mon calcul, même forme que R5). »")
rep("Nœud (l'énoncé est fixé par une décision de Lazar) : pas de défaut.",
    "Nœud (l'énoncé est fixé par une décision de Lazar) : pas de défaut. "
    + REC + " : « (a), lecture déclarée et soumise à Lazar ; (b) serait plus propre si l'énoncé doit être cité dehors. Confiance 0,65. »")
rep("Recommandation : (a), la lecture de la version 1. Confiance : au concepteur. Nœud (lecture d'une décision) : pas de défaut.",
    "Recommandation : (a), la lecture de la version 1. Confiance : au concepteur. Nœud (lecture d'une décision) : pas de défaut. "
    + REC + " : « (c). La clause de la lettre ne coûte rien à garder, et sous (a) un écart du jumeau détecté entre m et n_max ne donne que « non concluante ». Confiance 0,55. Aucune valeur recommandée pour la dose visée ; l'objet « organisme au repos » reste inconstructible tant qu'elle manque. »")
rep("divergence soumise à la vérification. Recommandation : au concepteur. Nœud : pas de défaut.",
    "divergence soumise à la vérification. Recommandation : au concepteur. Nœud : pas de défaut. "
    + REC + " : « (a), la lecture principale, avec la qualification « attestée » ou « tenue par construction ». Sous (b), le verdict dépendrait d'une attestation obtenue 53 fois sur cent avec un jumeau exact. Confiance 0,6, sous réserve de la vérification de la divergence. »")
rep("(c) les deux. Recommandation : au concepteur. Pas de défaut.",
    "(c) les deux. Recommandation : au concepteur. Pas de défaut. "
    + REC + " : « (c), tailles propres et objet rapporté, non éliminatoire. Il sert une lecture hors verdict, et sa tolérance (± 1,62 sur 10,05) sépare peu. Confiance 0,65. »")
rep("Recommandation : (a), le choix de la version 1. Confiance : au concepteur. Pas de défaut.",
    "Recommandation : (a), le choix de la version 1. Confiance : au concepteur. Pas de défaut. "
    + REC + " : « (a), rangs simples. Sous supposition normale ils sont plus efficaces (0,798 contre 0,757) et leur loi nulle est exacte. Confiance 0,75. »")
rep("(c) garder et rapporter l'écart. Recommandation : au concepteur. Pas de défaut.",
    "(c) garder et rapporter l'écart. Recommandation : au concepteur. Pas de défaut. "
    + REC + " : « (a), avec le taux par configurations rapporté à côté. C'est la forme qui a dimensionné les seuils de 2 % et 3 %. Les croisements à 50 % ne bougent pas au premier ordre, donc ρ et κ ne sont pas touchés. Confiance 0,6. »")
rep("## Table des remarques portées\n", TETE + "## Table des remarques portées\n")
dst.write_text(t, encoding="utf-8")
print("écrit", dst)
