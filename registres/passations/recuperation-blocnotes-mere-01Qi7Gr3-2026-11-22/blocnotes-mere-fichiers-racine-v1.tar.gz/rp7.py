import math
def n(N, pas): 
    m = (N-1)//pas + 1
    return m + (0 if (N-1) % pas == 0 else 1)
def rp7(N, J):
    for k in range(1, 10000):
        n15, n7 = n(N, 16*k), n(N, 128*k)
        W = 38544*N + 72*N*J + 16384*J*(n15+2*n7)
        if W + 1000*N + 1_000_000 <= 1_996_000_000:
            big = max(38544*N, 72*N*J, 16384*J*n15, 16384*J*n7)
            libre = math.ceil((2_000_000_000+big)/100_000_000)*100_000_000
            ok = k == 1 or (n15 >= 81 and n7 >= 11)
            return k, n15, n7, W, libre, ok
    return None
print(rp7(2560, 400))
for N, J in [(5120,400),(10240,400),(2560,800),(1280,400),(20000,400)]:
    print(N, J, rp7(N, J))
print(4*(2+1)+1, 12*max(1, math.ceil(64*1*10*2/1280)))
