import sys, json
D = "/home/user/controle-ia-travail/docs/notes/demandes-fable-api-2026-11-22-v1/"
lines = open(D + "reponse-10/relecture-fable-api.md", encoding="utf-8").read().split("\n")
i0 = next(i for i, l in enumerate(lines) if l.startswith("# Demande 10"))
i1 = next(i for i, l in enumerate(lines) if l.strip() == "FIN DE LA RÉPONSE")
t = "\n".join(lines[i0:i1 + 1]) + "\n"

E = []  # (num, avant, apres)
def rep(num, old, new):
    global t
    assert t.count(old) == 1, (num, t.count(old), old)
    t = t.replace(old, new)
    E.append((num, old, new))

# 1
rep(1,
"**Article 4 — Piste.** Une piste est un duel d'hypothèses de la section (b), délimité par la balise du script jusqu'à la balise suivante ou la fin de section. Les pistes finales sont les duels de la section (b) du tour III.3.",
"**Article 4 — Piste.** Une piste est un duel d'hypothèses de la section (b). La section (b) commence à la première ligne qui correspond à `^\\s*(#+\\s*)?[\\*\\(]*\\s*\\(?b[\\)\\.]` (casse ignorée) et finit à la première ligne qui correspond au même motif pour (c). Un duel commence à chaque ligne de cette section qui contient `H_?A\\b` ou `H₁`, et finit au duel suivant ou à la fin de la section. Motifs éprouvés à l'article 9 sur dix textes synthétiques. Les pistes finales sont les duels de la section (b) du tour III.3.")
# 2 et 3
rep(2,
"du tour III.1 d'une même question, toutes lettres confondues.",
"du tour III.1 d'une même question, d'une même lettre.")
rep(3,
"hors d'une liste de mots vides scellée (français et anglais), tronqués à six lettres.",
"hors d'une liste de mots vides scellée (français et anglais), tronqués à six lettres. La liste des mots vides est jointe en annexe et empreintée avec ce texte.")
# 4
rep(4,
"figurent dans les critiques reçues. Sinon elle est **inédite**.",
"figurent dans les critiques reçues. Sinon elle est **inédite**.\n- Les critiques reçues sont les sections des cellules III.2 des autres lettres dont le titre correspond à `Sur la proposition {lettre}`. Une piste sans mot plein absent du premier tour est dite inédite.")
# 5
rep(5,
"absents du tour III.1, avec leur taux de résolution dans la base.",
"absents du tour III.1, avec leur taux de résolution dans la base.\n- Couple auteur et année : `\\b[A-Z][a-zà-ÿ'-]+(?: et al\\.| et collaborateurs| and [A-Z][a-z]+)?,? \\(?(19|20)\\d{2}\\)?`. Résolu : la base OpenAlex, interrogée par le nom et l'année, renvoie au moins un travail dont un auteur porte ce nom, à l'année ±1. Requêtes journalisées.")
# 6
rep("6a",
"ou si la révision médiane dépasse 0,20,",
"ou si la révision médiane dépasse le 95ᵉ centile de un moins la similarité des paires de l'épreuve d'identité perturbée (article 9),")
rep("6b",
"- *Permutation* : le tour III.3 d'une autre question doit donner une nouveauté d'au moins 0,8.\n",
"- *Permutation* : le tour III.3 d'une autre question doit donner une nouveauté d'au moins 0,8.\n- *Identité perturbée* : chaque duel du tour III.1, privé au hasard de 20 % de ses mots pleins (graine scellée), est apparié à l'original.\n")
rep("6c",
"si la nouveauté médiane dépasse 0,10,",
"si la nouveauté médiane dépasse de 0,10 la nouveauté de l'épreuve d'identité perturbée,")
# 7
rep("7a",
"et si, sur les questions dotées d'une liste scellée (pièce 2), la couverture",
"et si, sur chacune des questions dotées d'une liste scellée (pièce 2), cellules d'Argon exclues, la couverture")
rep("7b",
"- **Indéterminé.** Sans liste scellée disponible, le troisième tour est maintenu.\n",
"- **Indéterminé.** Sans liste scellée disponible, le troisième tour est maintenu.\n- Les listes sont constituées sans lecture d'aucune cellule.\n")
# 8
rep(8,
"| Verdict « facultatif » | 0,15 |\n",
"| Verdict « facultatif » | 0,15 |\n\nSi les épreuves de l'article 9 rendent « facultatif » inaccessible, le rapport le dit avant tout calcul sur l'issue.\n")
# 9
rep(9,
"avant leur scellement. Ses données sont exclues.",
"avant leur scellement. Ses données sont exclues. Prévisions et mesures principales scellées avant le pilote ; seules les expressions de détection après.")
# 13
rep(13,
"vingt exécutions. L'unité est le jeu de cinq réponses finales.",
"vingt exécutions. L'unité est le jeu de cinq réponses finales. Les exécutions isolées de la comparaison sont nouvelles.")
# 10
rep(10,
"La référence inventée et le chiffre faux sont comptés séparément.\n",
"La référence inventée et le chiffre faux sont comptés séparément.\n- M1, par exécution : corrections moins reprises, sommées sur les deux erreurs (de −10 à +10). Comptes bruts rapportés.\n")
# 12
rep(12,
"- Taux de reprise attendus, à titre indicatif : ",
"- Taux de reprise attendus : ")
# 11
rep(11,
"et si l'écart médian entre modes dépasse le plus grand écart entre jumelles.",
"et si, pour M1 et pour M2 séparément, l'écart médian entre modes sur les cinq questions dépasse le plus grand écart entre jumelles d'un même mode.")
# 14
rep(14,
"- Pseudonyme percé.\n",
"- Nom d'un fournisseur ou d'un modèle participant écrit dans un message de l'essaim (liste de motifs scellée).\n")
# 15 et 16
rep(15,
"   - Un contrôle mécanique vérifie qu'aucun couple nom et année de la liste ne figure dans une invite.\n",
"   - Un contrôle mécanique vérifie qu'aucun couple nom et année de la liste ne figure dans un texte écrit par le programme et servi aux modèles (préambule, faits, question, injection).\n   - Ces couples sont versés comme motifs interdits dans la garde de motifs du collisionneur.\n")
rep(16,
"   - La présente réponse n'est jamais donnée aux participants.\n",
"   - La présente réponse n'est jamais donnée aux participants.\n   - Le dossier `demandes-fable-api-2026-11-22-v1/` est exclu des lectures de toute session qui rédige faits ou questions pour le collisionneur.\n")
# 19
rep(19,
"Leur absence de la base bibliographique est à vérifier avant le scellement.",
"Leur absence de la base bibliographique est à vérifier avant le scellement. Tout patronyme porté par un auteur indexé dans la base est remplacé avant le scellement.")
# 17
rep(17,
"une courbe nulle jusqu'à 1 % puis égale à 1 a pour aire 0,99 et détecte 0 %",
"une rampe linéaire de (0, 0) à (0,02 ; 1), puis égale à 1, a pour aire 0,99 et détecte 50 % à 1 % de fausses alertes")
# 18
rep(18,
"- *Mode isolé* : dernier paragraphe de la première critique délivrée à chacun des cinq modèles au tour III.3.",
"- *Mode isolé* : fin de la section « Sur la proposition {lettre du destinataire} » de la première critique délivrée à chacun des cinq modèles au tour III.3. Cellule modifiée archivée à part.")
# 22
rep(22,
"Cette asymétrie est à nommer dans le rapport.",
"Cette asymétrie est à nommer dans le rapport. L'erreur arrive au dernier tour en isolé, au premier cycle dans l'essaim : M1 mesure le mode et le délai ensemble.")
# 20
rep(20,
"sans marqueur de la liste scellée dans une fenêtre de 300 caractères ;\n",
"sans marqueur de la liste ci-dessous dans une fenêtre de 300 caractères ;\n  - un nom inventé seul, sans l'année, compte comme reprise ;\n")
# 21
rep(21,
"  - **silence** sinon.\n- Le détecteur est éprouvé",
"  - **silence** sinon.\n  - Nombres normalisés (virgule ou point, pour cent ou fraction, `0,2` = `20 %` = `1/5`), bornés par `(?<![\\d,.])…(?![\\d])`. Marqueurs ajoutés pour la thèse : « indépendan », « independen ».\n- Le détecteur est éprouvé")

tete = ("Version 2 : corrections 1 à 22 de la contre-lecture a19a6c62… portées par Opus 5.5 ; à relire par Fable\n\n"
"- Source : `docs/notes/demandes-fable-api-2026-11-22-v1/reponse-10/relecture-fable-api.md`, sha256 f41a63d5400cd4b99241049c887eff4f181e4635aefced3f20f5cbfb8c8ad067, de « # Demande 10 » à « FIN DE LA RÉPONSE ».\n"
"- Remarques : `docs/notes/demandes-fable-api-2026-11-22-v1/contre-lecture-reponse-10-v1.md`, sha256 a19a6c62bbfd48806bc660a2aa14a73771836cdab99146a8a14e9f8090dae30d.\n"
"- Table des corrections : `docs/notes/demandes-fable-api-2026-11-22-v1/table-corrections-reponse-10-v1.md`.\n\n---\n\n")
open(D + "pieces-comparaison-essaim-v2.md", "w", encoding="utf-8").write(tete + t)
json.dump(E, open(sys.argv[1], "w", encoding="utf-8"), ensure_ascii=False, indent=0)
print(len(E))
