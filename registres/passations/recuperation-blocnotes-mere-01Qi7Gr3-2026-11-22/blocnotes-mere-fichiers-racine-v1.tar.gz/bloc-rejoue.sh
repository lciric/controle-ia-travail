python3 - <<'EOF'
import math
from statistics import NormalDist as N
P = N().cdf; q = N().inv_cdf; z = q(.99)
b = lambda x: round(100*(1-P(z-1.645/math.sqrt(x))),1)
print("A", round(z,4), round(math.sqrt(5/8),4), round(math.sqrt(.5),4), round(math.sqrt(1/4),4))
print("B", round(math.sqrt(.75),4), round(4**-.6,4), round(4**-.4,4))
print("C", round(math.sqrt(6/4)/math.sqrt(2),4), round(math.sqrt(6/4)/math.sqrt(5),4), round(2/4,2))
print("D", [round(100*P(z*(math.sqrt(r/(1+r))-1)),1) for r in (.5,1,2,4)], [round(100*P(z*(math.sqrt(r*4/6)-1)),1) for r in (.5,1,2,4)])
print("E", round(100*P(z*(1/.75-1)),1), round(100*P(z*(1/math.sqrt(6/4/5)-1)),1))
print("F", [round(100*(1-P(z/math.sqrt(1+r))),1) for r in (.25,1,4)])
print("G", [round((1.645/(z-q(1-.01*f)))**2,1) for f in (2,3,5)])
print("H", [b(x) for x in (60,15,24,6,6,1.5)])
print("I", round(1+1.645/math.sqrt(24)/(z/2),3), round(1+1.645/math.sqrt(60)/(z/2),3))
print("J", [round(z*math.sqrt(math.pi/3)*math.sqrt(2)/math.sqrt(m),2) for m in (40,100,400)])
print("K", round(math.sqrt(101)/math.sqrt(math.pi*6/12),2), round(math.sqrt(101)/math.sqrt(math.pi*5/9),2), round(100*z/(0.5*math.sqrt(400)),1))
print("L", [round(math.sqrt(x)/z,3) for x in (160/2400,400/2400,1600/2400)], [round(100*P((.75/math.sqrt(6/4/5)-1)/(math.sqrt(x)/z)-1.96)) for x in (160/2400,400/2400,1600/2400)])
EOF
