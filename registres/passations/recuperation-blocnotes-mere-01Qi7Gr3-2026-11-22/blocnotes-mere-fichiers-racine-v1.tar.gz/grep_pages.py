import re,sys
f=sys.argv[1]; kws=sys.argv[2:]
pages=open(f).read().split('\f')
for kw in kws:
    c=0
    for n,p in enumerate(pages,1):
        for m in re.finditer(kw,p,re.I):
            s=p[max(0,m.start()-220):m.end()+260]
            print(f'p{n} [{kw}]',re.sub(r'\s+',' ',s)); c+=1
            break
        if c>=3: break
