#!/bin/bash
# Épreuve par retrait des essais v11 sur une copie de l'arbre.
set -u
SRC=$1
for k in 1 2 3 4 5; do
  D=$(mktemp -d -p "$(dirname "$SRC")" mut$k.XXXX)
  cp -r "$SRC"/src "$SRC"/tests "$SRC"/scripts "$SRC"/pyproject.toml "$D"/
  F="$D/src/controle_ia/organismes_discrets/bras_a_v2_habilite/autres_moniteurs_v11.py"
  case $k in
    1) python3 - "$F" <<'PY'
import sys;p=sys.argv[1];s=open(p,encoding='utf-8').read()
s=s.replace('"preparation_des_lectures_v3.py",\n                                 "c0021298c21d027a713b1947d2668ac928f2a856b1a696686dd35b83a9515c45"','"preparation_des_lectures_v2.py",\n                                 "6dfd2bfc6989bd8a90ec40648bda653f5f8383e157c3c521e6d9a488f582debd"',1);open(p,'w',encoding='utf-8').write(s)
PY
;;
    2) sed -i 's/c0021298c21d027a713b1947d2668ac928f2a856b1a696686dd35b83a9515c45/c0021298c21d027a713b1947d2668ac928f2a856b1a696686dd35b83a9515c46/' "$F";;
    3) python3 - "$F" <<'PY'
import sys;p=sys.argv[1];s=open(p,encoding='utf-8').read()
a='    if not isinstance(programmes, dict) or programmes != {n: s for n, (_, s) in PROGRAMMES_DE_PRODUCTION.items()}:\n        raise'
assert a in s; s=s.replace(a,'    if False:\n        raise',1);open(p,'w',encoding='utf-8').write(s)
PY
;;
    4) sed -i 's/^N_PERMUTATIONS, N_TIRAGES, TAILLE_FAMILLE, NIVEAU = 2000, 2000/N_PERMUTATIONS, N_TIRAGES, TAILLE_FAMILLE, NIVEAU = 1999, 2000/' "$F";;
    5) python3 - "$F" <<'PY'
import sys;p=sys.argv[1];s=open(p,encoding='utf-8').read()
a='        if vue != inscrite:\n            raise GardeArret(f"programme de production {nom} : empreinte'
assert a in s; s=s.replace(a,'        if False:\n            raise GardeArret(f"programme de production {nom} : empreinte',1);open(p,'w',encoding='utf-8').write(s)
PY
;;
  esac
  cmp -s "$F" "$SRC/src/controle_ia/organismes_discrets/bras_a_v2_habilite/autres_moniteurs_v11.py" && echo "mutation $k : NON APPLIQUEE"
  r=$(cd "$D" && PYTHONPATH=src timeout 110 /home/user/controle-ia-travail/.venv/bin/python -B -m pytest -q -p no:cacheprovider tests/test_bras_a_v2_habilite_autres_moniteurs_v11.py 2>&1 | tail -1)
  echo "mutation $k : $r"
done
