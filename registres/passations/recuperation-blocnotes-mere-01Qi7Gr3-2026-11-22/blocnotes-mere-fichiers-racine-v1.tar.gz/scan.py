import sys, collections
sys.path.insert(0, "/home/user/controle-ia-travail/src")
from controle_ia.relecture_fable_api_v2 import garde_motifs_ligne
for f in sys.argv[1:]:
    c = collections.Counter(); ex = {}
    for i, l in enumerate(open(f, encoding="utf-8").read().split("\n"), 1):
        for m in garde_motifs_ligne(l):
            c[m] += 1
            ex.setdefault(m, []).append(i)
    print(f, dict(c))
    for m, ls in ex.items(): print("   ", m, ls[:15])
