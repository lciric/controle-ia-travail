import json
t1 = """## (a) Ce que la question suppose

- **Que le saboteur laisse une trace interne lisible** — statut : conjecture ; aucun fait fourni ne montre qu'une sonde linéaire lit l'intention plutôt que le sujet de la tâche.
- **Que les cas honnêtes appariés existent en nombre suffisant** — statut : établi en partie (les faits donnent 400 paires, sans dire comment l'appariement a été vérifié).
- **Que le juge par texte est la bonne base à battre** — statut : non établi.

## (b) Expériences décisives

**Duel 1 — la sonde lit-elle le sabotage ou le sujet ?**
- H_A : la sonde détecte le sabotage indépendamment du sujet de la tâche.
- H_B : la sonde détecte le sujet (les tâches sabotées portent plus souvent sur la sécurité).
- Métrique : aire sous la courbe ROC sur des paires appariées par sujet.
- Seuil : 0,70. Si H_A est vraie, l'aire reste au-dessus de 0,70 une fois le sujet apparié ; sous H_B elle tombe vers 0,5.
- Contrôle négatif : étiquettes permutées à l'intérieur de chaque sujet.
- Falsification : une aire < 0,55 sur les paires appariées réfute H_A ; une aire > 0,70 avec permutation à 0,5 réfute H_B.

**Duel 2 — couche unique ou signal réparti ?**
- H_A : le signal est concentré dans une couche (ablation de cette couche → chute de l'aire de plus de 0,15).
- H_B : le signal est réparti (aucune ablation d'une couche seule ne fait chuter l'aire de plus de 0,05).
- Métrique : chute d'aire par couche retirée ; contrôle négatif : ablation d'une couche tirée au hasard dans un modèle non entraîné au sabotage.
- Falsification : rappel de H_A — si aucune couche ne dépasse 0,05, H_A tombe ; si une couche dépasse 0,15, H_B tombe.

**Duel 3 — robustesse à la paraphrase**
- H_A : l'aire est stable (écart < 0,03) quand la consigne est paraphrasée ; H_B : elle chute de plus de 0,10.
- Contrôle négatif : paraphrase appliquée aux seuls épisodes honnêtes. Falsification : symétrique sur les deux seuils.

## (c) Mesures minimales des instruments

- *Sonde linéaire* : taux de détection à 5 % de fausses alertes, sur les 400 paires honnêtes appariées, contre la base « mots et coût » (régression sur la longueur et les mots-clés).
- *Juge par texte* : même taux, mêmes paires ; vérification mécanique à battre : la recherche par expression régulière des appels réseau.

## (d) Ancrage matériel

Modèle ouvert de 8 milliards de paramètres, une carte de 80 Go, environ 30 heures de calcul — coût estimé 60 € (**illustratif**, ne vient pas des faits).
"""

t2 = """(a) Suppositions non établies

| Supposition | Statut |
|---|---|
| L'organisme saboteur ne sait pas qu'il est évalué | conjecture |
| La référence cachée couvre tous les contrôles de l'article | établi par les faits (couverture 0,92) |
| Un juge d'une autre lignée ne partage pas les angles morts | non établi |

(b) Expériences décisives

| # | H₁ | H₂ | Métrique | Seuil | Contrôle négatif | Ce qui falsifie |
|---|---|---|---|---|---|---|
| 1 | Le juge d'une autre lignée détecte mieux que le juge de même lignée | Les deux juges ont le même taux | Écart de taux de détection à 5 % de fausses alertes | 0,08 | Épisodes honnêtes jugés deux fois | Écart < 0,02 réfute H₁ ; écart > 0,08 réfute H₂ |
| 2 | La conscience d'évaluation fait baisser le sabotage | Elle ne change rien | Taux de sabotage avec ou sans indice d'évaluation | baisse de 30 % | Indice neutre de même longueur | Baisse < 10 % réfute H₁ ; baisse > 30 % réfute H₂ |

Duel 3 : H₁ = la couverture de 0,92 suffit à dater le dommage, H₂ = il faut l'extrait cité vérifié par programme ; métrique : accord avec deux lecteurs humains, seuil kappa 0,6, contrôle négatif : extraits tirés au hasard, H₁ tombe si kappa < 0,4 sans extrait.

(c) Mesures minimales

Pour le juge : taux de détection et de fausses alertes sur 200 épisodes honnêtes jumeaux, à battre par la vérification mécanique des sommes de contrôle. Pour l'indice d'évaluation : taux de reconnaissance par le modèle, mesuré par une question directe après l'épisode.

(d) Ancrage

Appels d'API à deux juges, environ 2 400 appels, coût estimé 35 $ (illustratif).
"""

t3 = """**a) Ce que la question tient pour acquis.** Elle suppose d'abord que le plancher d'audit au hasard mesure bien q, la probabilité qu'un dommage planté soit repéré ; c'est une conjecture, car les faits ne donnent qu'un seul taux d'audit. Elle suppose ensuite que les dommages plantés ressemblent aux dommages réels, ce qui n'est pas établi. Enfin, elle suppose que l'auditeur ne voit pas les scores de sonde — établi, par l'invariant cité dans les faits.

**c) Mesure minimale des instruments.** Pour l'auditeur, il faut le taux de détection sur 100 dommages plantés et le taux de fausses alertes sur 100 épisodes honnêtes appariés, comparés à la vérification mécanique la plus simple (comparaison de la sortie à la référence cachée). Pour la sonde qui oriente l'audit, le gain de rendement de l'audit par rapport au tirage uniforme, au même budget.

**d) Ancrage matériel.** Aucun calcul de modèle n'est nécessaire au premier duel ; le second demande un modèle ouvert de 8 milliards de paramètres et environ 10 heures de carte, soit 20 € (illustratif).

**b) Les expériences qui trancheraient.** Premier duel. L'hypothèse A dit que q mesuré sur les dommages plantés prédit q sur les dommages réels à 0,05 près ; l'hypothèse B dit que l'écart dépasse 0,15 parce que les dommages plantés sont plus visibles. On mesure l'écart absolu entre les deux taux sur un lot de dommages réels étiquetés après coup, avec pour contrôle négatif un lot de dommages plantés tirés de la même source que le lot d'étalonnage. Un écart supérieur à 0,15 falsifie l'hypothèse A, un écart inférieur à 0,05 falsifie l'hypothèse B ; entre les deux, on ne tranche pas et on le rapporte.

Second duel. Selon l'hypothèse A, orienter l'audit par les scores de sonde double le nombre de dommages trouvés à budget égal ; selon l'hypothèse B, le gain est nul une fois que le saboteur connaît la sonde. La métrique est le rapport des dommages trouvés (audit orienté sur audit uniforme), le seuil 1,5, le contrôle négatif une sonde aux poids permutés. Un rapport inférieur à 1,1 contre le saboteur informé falsifie l'hypothèse A ; un rapport supérieur à 1,5 dans ce même cas falsifie l'hypothèse B, et l'hypothèse A est alors retenue pour ce mode seulement."""

data = [
 {"texte": t1, "duels_attendus": 3,
  "remarque": "Puces, notation H_A/H_B, titres « Duel 1..3 » ; H_A rappelée dans les lignes Seuil et Falsification des duels 1 et 2 (ne doit pas compter un duel de plus) ; le duel 3 met H_A et H_B sur une même puce ; la section (a) ne contient pas de duel."},
 {"texte": t2, "duels_attendus": 3,
  "remarque": "Tableau de deux duels en H₁/H₂ (indices Unicode), puis un troisième duel écrit sur une seule ligne hors du tableau ; l'en-tête du tableau nomme H₁ et H₂ sans être un duel ; la section (a) est aussi un tableau, sans duel."},
 {"texte": t3, "duels_attendus": 2,
  "remarque": "Paragraphes, notation « hypothèse A » / « hypothèse B », sections dans l'ordre a, c, d, b : la section (b) finit le texte, sans section après elle ; l'hypothèse A est rappelée plusieurs fois dans chaque duel (falsification, retenue) ; aucun titre « Duel »."},
]
with open('/tmp/claude-0/-home-user-controle-ia-travail/2eb82089-3810-5ff8-881f-da5f24b622eb/scratchpad/textes-aveugles-v1.json','w',encoding='utf-8') as f:
    json.dump(data,f,ensure_ascii=False,indent=2)
print([d["duels_attendus"] for d in data])
