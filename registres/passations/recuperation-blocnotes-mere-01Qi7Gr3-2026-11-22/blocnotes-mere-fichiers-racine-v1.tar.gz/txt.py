import sys,re,html
t=open(sys.argv[1],encoding='utf-8',errors='replace').read()
t=re.sub(r'(?is)<(script|style)[^>]*>.*?</\1>',' ',t)
t=re.sub(r'(?s)<[^>]+>',' ',t); t=html.unescape(t)
w=re.sub(r'\s+',' ',t)
print(w)
