import sys, os, shutil, subprocess, hashlib
from pathlib import Path
M=Path(sys.argv[1]); R=Path("/home/user/controle-ia-travail"); PY=str(R/".venv/bin/python")
# copie saine du code
d0=M/"c0-code-sain"
if not d0.exists():
    (d0/"tests").mkdir(parents=True)
    for f in ("test_cibles_invisibles_v3.py","test_cibles_invisibles_v4.py","liste_cibles_invisibles_v4.json","liste_cibles_invisibles_v4.json.sha256","conftest.py"):
        shutil.copy(R/"tests"/f, d0/"tests"/f)
    shutil.copytree(R/"src", d0/"src", ignore=shutil.ignore_patterns("__pycache__"))
for nom in ("c0-code-sain","c1-fuite-debut-episode","c2-tache-entiere-evaluer","c3-fuite-tirage-saboteur","c4-fuite-dans-tache_de-exempte"):
    d=M/nom
    if not (d/"docs").exists(): (d/"docs").symlink_to(R/"docs")
    bt=M/("bt2-"+nom); bt.mkdir()
    r=subprocess.run([PY,"-m","pytest","-q","-p","no:cacheprovider","tests/test_cibles_invisibles_v4.py",f"--basetemp={bt}"],cwd=d,
        env={**os.environ,"PYTHONPATH":f"{d/'src'}:{d/'tests'}"},capture_output=True,text=True,timeout=600)
    print("==",nom); print("\n".join(x[:200] for x in r.stdout.splitlines() if x.startswith("FAILED") or " passed" in x or " failed" in x))
