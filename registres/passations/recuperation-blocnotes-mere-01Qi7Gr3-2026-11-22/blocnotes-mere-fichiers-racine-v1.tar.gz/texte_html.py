#!/usr/bin/env python3
"""Lit une page HTML sur l'entrée standard, en retire les balises, et affiche des fenêtres autour d'une expression."""
import html
import re
import sys

brut = sys.stdin.read()
brut = re.sub(r"(?is)<(script|style)\b.*?</\1>", " ", brut)
texte = html.unescape(re.sub(r"(?s)<[^>]+>", " ", brut))
texte = re.sub(r"\s+", " ", texte)
expr, fen = sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 200
limite = int(sys.argv[3]) if len(sys.argv) > 3 else 12
n = 0
dernier = -10**9
for m in re.finditer(expr, texte, re.IGNORECASE):
    if m.start() - dernier < fen:
        continue
    dernier = m.start()
    n += 1
    if n <= limite:
        print(f"[{m.start()}] …{texte[max(0, m.start() - fen):m.end() + fen]}…\n")
print(f"[{n} fenêtres ; texte de {len(texte)} signes]")
