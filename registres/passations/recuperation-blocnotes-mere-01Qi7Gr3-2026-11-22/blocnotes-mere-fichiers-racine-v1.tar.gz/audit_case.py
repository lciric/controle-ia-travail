from math import sqrt
import numpy as np
from scipy.stats import norm
Z = norm.ppf(0.99)
def taux(n, m, reps, graine, loi):
    rng = np.random.default_rng(np.random.SeedSequence(graine))
    sd = sqrt((n + m + 1) / (12.0 * n * m))
    a = 0
    for _ in range(reps):
        if loi == "t3":
            ref = np.sort(rng.standard_t(3, size=m)); x = rng.standard_t(3, size=n)
        else:
            ref = np.sort(rng.standard_normal(m)); x = rng.standard_normal(n)
        w = np.searchsorted(ref, x).mean() / m
        a += (w - 0.5) / sd > Z
    return a / reps
for g in ([7, 1], [7, 2], [7, 3]):
    print("t3 n=m=400, 40000 reps, graine", g, taux(400, 400, 40000, g, "t3"))
print("normale n=m=400, 40000 reps", taux(400, 400, 40000, [7, 9], "norm"))
# la case d'origine, même graine, pour confirmer la valeur
print("case d'origine (graine [2026112118, 2, 1], 4000 reps)", taux(400, 400, 4000, [2026112118, 2, 1], "t3"))
