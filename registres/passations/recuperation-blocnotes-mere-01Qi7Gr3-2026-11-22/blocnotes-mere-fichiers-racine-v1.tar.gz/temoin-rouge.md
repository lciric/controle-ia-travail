Texte témoin : Lazar a dit GO-2026-11-21-66 ; voir docs/notes et la session_01Qi ; Opus 5.5 ; N-076 ; G1.
