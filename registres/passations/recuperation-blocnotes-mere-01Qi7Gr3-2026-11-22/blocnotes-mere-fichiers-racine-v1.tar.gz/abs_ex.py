import re,sys,html
for f in sys.argv[1:]:
    t=open(f,encoding='utf-8',errors='replace').read()
    g=lambda p: html.unescape(re.sub(r'\s+',' ',re.sub('<[^>]+>','',(re.search(p,t,re.S) or [None,''])[1] if re.search(p,t,re.S) else ''))).strip()
    ti=g(r'<h1 class="title mathjax">(.*?)</h1>')
    au=g(r'<div class="authors">(.*?)</div>')
    da=g(r'<div class="dateline">(.*?)</div>')
    ab=g(r'<blockquote class="abstract mathjax">(.*?)</blockquote>')
    print('###',f.split('/')[-1][:-5],ti,'|',au[:200],'|',da);print(ab[:1600]);print()
