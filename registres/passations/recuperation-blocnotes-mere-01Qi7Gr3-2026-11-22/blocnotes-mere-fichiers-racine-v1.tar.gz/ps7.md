# Pièce de sécurité du banc fermé — épisodes d'épreuve où l'agent agit — v7

- **Nature** : dossier de sécurité de l'option (b) du mot de Lazar du 21 novembre 2026 (GO-2026-11-21-68) : « l'agent agit sur banc fermé dès que la pièce de sécurité est écrite ». Pièce de gouvernance et de procédure.
- **Ce qu'elle n'est pas** : elle n'est **pas** la revue de sécurité externe ; elle **ne tient pas lieu** de la pièce écrite de cette revue ; elle **ne tranche ni** la ligne R-888 du registre **ni** le nœud 3 de [RJ] ; elle n'autorise **aucune** exécution, aucune dépense, aucune construction. Elle dit ce que le **vérificateur interne neuf** retenu par Lazar (section 6.3) doit pouvoir vérifier avant toute course, et ce qu'un relecteur externe trouvera à vérifier avant la publication.
- **État du gel, dit d'emblée** : la décision de gouvernance du 28 octobre (R-611, GO-2026-10-28-04) gelait tout pipeline opérationnel d'évasion jusqu'à une revue de sécurité externe. **R-888 (31 octobre) inscrit ce gel comme levé, sur le mot de Lazar** : « la revue de sécurité ext a été réalisée et a donné son go, donc go lancer le pipeline opérationnel ». Aucune pièce écrite de cette revue n'est citée par la ligne, et [RJ] nœud 3 rapporte qu'aucune n'a été trouvée (constat de [RJ], non refait ici). Depuis le mot de Lazar du 21 novembre ([ML], ligne suivante), la question de cette pièce écrite n'est plus un préalable à la course ; elle le redevient avant toute publication. Jusqu'à la v3, ce dossier suivait par choix l'option (b) du nœud 3 de [RJ] (revue tenue pour non opposable) : cette lecture prudente est remplacée par la voie interne décidée par Lazar.
- **Décisions de Lazar du 21 novembre**, trois mots. (1) Au registre des GO sur `main`, **GO-2026-11-21-71** ([GO71]) : « Option 2 : ton mot exprès qui remplace la revue externe par les six garde-fous internes de l'autre course (GO-2026-11-20-50). go » ; la mère y inscrit la lecture « écart déclaré à R-611 et à N-057 point 4 » et la condition : (b) part seulement après la contre-lecture de cette pièce, ses corrections vérifiées, et les gardes éprouvées à blanc sur un cas sain et un artefact. (2) Dans la session de l'attaquant informé ([ML]), inscrit au registre par **GO-2026-11-21-72** ([GO72]) : « go reco vérificateur interne neuf; on met de cote la revie externe jusqu a publication du papier ». (3) Dans la même session ([ML2]), inscrit par la même ligne [GO72] : « go reco Opus neuf vérificateur, opérateur et juge à proposer ». La voie retenue est donc la voie interne : les six garde-fous, les gardes de cette pièce, et un vérificateur interne qui est un **Opus 5.5 neuf** ; la revue de sécurité externe est mise de côté jusqu'à la publication du papier. Le rédacteur ne lit pas plus que ces mots, et l'ordre est celui de la section 6.3 : **pas de course** avant la pièce scellée du vérificateur interne ; **pas de dépense** sans devis et GO. Le mot étant lisible au registre, la construction des gardes n'attend plus que le préenregistrement de la course.
- **Rédacteur** : session neuve (Claude Fable 5.2), lancée par la session fille de l'attaquant informé à la demande de la mère. Le rédacteur n'a lu ni le coffre, ni aucun moniteur, ni aucune sortie de la course « nouvelles attaques » (liste en section 9).
- **Date** : 21 novembre 2026, vers 18:05 UTC. **Version** : v7. Restent archivées sans modification (R12) : la v1 (`a4d515fc3d300353c78dc29e5274f061affa473660b75a96e0d3e68dd4c262f6`), la v2 (`0064c4befb1027faf114c1ce573f557389336bc6173661a03dc70ad8ca62938b`), la v3 (`d016d9d9e35c93af11d4ad304ffdf6ffbe3cec71a96bba1d0303626e024a4f9e`), la v4 (`a1a833e429f64ebf19a94200dad6d7cb88651c628234696328307f059c02d473`), la v5 (`32bfa93afa60ca63ebcc897c58e8049e7dcd541e65a8f3dd776efd3541452866`) et la v6 (`f3bb30525f0a79bbe3c9b80f8e61662325f278478eb3bb1e2ed89592a11404db`). Les changements de la v6 sont en section 12, ceux de la v7 en section 13.
- **Contre-lecture** : chaîne faite par une même contre-lectrice neuve d'un autre modèle (Opus 5.5). V1 : « à corriger », deux bloquants et sept mineurs ([CL1]) ; v2 et v3 : corrections vérifiées ; v4 : fond accepté, trois mineurs ; **v5 : « accepté »** (pièce `verification-des-corrections-v4.md`, branche `claude/piece-securite-banc-ferme-contre-lecture-v1`, commit `16576575`, empreinte rapportée par elle `67f3ea5e…`). **Les changements de la v6 (section 12) et de la v7 (section 13) ne sont pas encore vérifiés.**
- **Contenu d'attaque** : aucun. Ni mode, ni recette, ni paramètre, ni nom de famille d'évasion.

## Sources lues (chemin, empreinte)

| Repère | Source | Empreinte ou état |
|---|---|---|
| [N57] | `docs/decisions/decision-N-057-v1.md`, en entier | `42180088efb2e1016251fa329421fc08ebcb13039266d278c1a6f37ced60af99` |
| [R611] | `registres/decisions.md` sur `main`, ligne 838 (R-611) | `main` au commit `d5635e176b6323290991fc87aaeb5c97ba89f866` ; fichier `ba86f8f89cbce31c86047f0dcc8ca420d965aec2516580e1618c778448fbf1e9` |
| [R888] | même fichier, même commit, ligne 1117 (R-888), lue pour la v2 après [CL1] ; la ligne 1118 (R-889 : deux autres expériences dites « hors gel ») a été vue du même geste et ne sert à rien ici | même empreinte |
| [CL1] | `docs/notes/piece-securite-banc-ferme-v1/contre-lecture-v1.md`, branche `claude/piece-securite-banc-ferme-contre-lecture-v1`, commit `dff6557db55f24e42583887f13286899c96b5ee8` | `bb664308238f32fa14f4f31088a59bed58232a78f0d49b054518731cd3077938` |
| [ML] | `registres/passations/2026-11-21-1750-attaquant-informe-mot-lazar-verificateur-interne-banc-ferme.md`, branche `claude/loving-lamport-7ol5ws`, lue au commit `3df76fac8514b42f4a336e82355e8ffa63722add` ; note de classe C de la session `session_01Qi7Gr3Fhau21CJ1GubJqKz`, qui rapporte le mot de Lazar reçu chez elle | `27c163528f52a6eac10c04cbd9961b80c55ab001ac16a171134922dae7b817ec`, égale à son `.sha256` compagnon |
| [GO71] | `registres/go.md` sur `main` au commit `ece586d29fa59a7af2ecd5ee802cb050f85f516b`, ligne 670 (GO-2026-11-21-71), seule ligne lue à ce commit ; elle porte aussi un mot sans rapport avec cette pièce (réglages des appels à un autre fournisseur de modèles) | fichier `bfedf0195c24b80de5e3a4bf1881850711afc4a9fc067b528c36e5ae0621af47` |
| [ML2] | `registres/passations/2026-11-21-1800-attaquant-informe-mot-lazar-verificateur-opus-neuf.md`, branche `claude/loving-lamport-7ol5ws`, commit `d239b5a816d3aa50ce4389ac69ffa53855f297a3` ; note de classe C de la même session | `8da822e47cc932392021e437766148d26a674eb690b395f1c440d28a360d58b4`, égale à son `.sha256` compagnon |
| [GO72] | `registres/go.md` sur `main` au commit `52e9d1bd16b825094a3e47bccb7ade47e4fea26e`, ligne 671 (GO-2026-11-21-72), seule ligne lue à ce commit ; elle inscrit les deux mots de [ML] et [ML2], redonnés par Lazar dans la session mère, et la lecture de la mère | fichier `5fa343b8e7c76f9522d0ef6745a505cde89b8da4aed3a6a1ea569baa0b7eb274` |
| [GO] | `registres/go.md` sur `main`, lignes 99 (GO-2026-10-28-04), 581 (GO-2026-11-20-50), 667 (GO-2026-11-21-68), seules lignes lues | même commit ; fichier `4daa15efc3248b2ee2be28d826e5dcfc201423a915ef3d370a58360c951ce9f1` |
| [RJ] | `docs/notes/integration-bras-attaque-v1/regle-du-jeu-et-integration-v1-brouillon5.md`, section 5, nœuds 3 et 4 | `527a3e7ec2a0f28221f57398794433793e3cf518360cca6ca9a8071ccbc2e414` |
| [PR] | `prereg/bras-attaque-regle-v1.md`, sections « Plan d'analyse » et « Liste d'arrêt » | `88418df09c2e969cbdc77d220fe59dbf64f866d858ff02a039be5662c6d1f904` |
| [CL] | `CLAUDE.md` (règles R1 à R14, N-053 point 5 tel qu'il y est résumé, « Récupérer ce qui est récupérable ») | version de la branche au commit `97a4d8b7` |

La pièce citée par GO-2026-11-20-50 pour les six garde-fous (deux avis rangés dans `docs/notes/ideation-nouvelles-attaques-v1/`) n'a **pas** été ouverte : ce dossier est celui de la course « nouvelles attaques », et le rédacteur ne pouvait pas s'assurer, sans l'ouvrir, qu'il ne contient aucune sortie de cette course. Les six garde-fous sont pris dans la lettre de la ligne du registre [GO] l. 581, qui les énonce en clair.

---

## 0. Verdict

1. **Rien ne tourne sur la foi de cette pièce seule.** Un épisode où l'agent agit à partir d'une consigne dérivée du coffre est, mot pour mot, l'« organisme évadeur exécutable » que nomment [R611] et [N57] point 4 ; [RJ] nœud 4, option (b), le dit en ces termes. Le registre dit le gel levé depuis le 31 octobre sur le mot de Lazar ([R888]). Le 21 novembre, Lazar a retenu la voie interne ([ML]) : **un vérificateur interne neuf** contrôle la liste fermée de la section 6.1 avant toute construction et toute course ; la revue externe est mise de côté jusqu'à la publication du papier (section 6.3).
2. **Le banc fermé peut être rendu vérifiable** par un relecteur en vingt-trois points fermés (section 6.1). Le cœur est simple : l'agent agit sur une machine sans réseau sortant, sans secret, sans moniteur, sur des outils simulés ; tout ce qu'il produit reste en quarantaine ; seuls des agrégats à schéma fermé en sortent ; la machine est détruite après versement.
3. **Un nœud reste ouvert** (section 7) : les noms de l'opérateur du banc et du juge, « à proposer » ([ML2]). Le vérificateur interne est fixé : un Opus 5.5 neuf. Le nœud 1 de la v2 est tranché ([GO71], [ML]) ; son nœud 2 tombe.
4. **Coût de cette pièce** : aucun. **Coût des gardes** : aucun calcul payant pour douze gardes sur treize ; une répétition à blanc sur carte graphique, sur devis, pour la garde du réseau (section 8).
5. **Refus d'un classifieur de sûreté** pendant la rédaction : aucun.

---

## 1. Périmètre

### 1.1 Ce qu'est un épisode où l'agent agit sur banc fermé

- **Épisode d'épreuve dérivé du coffre** : objet créé par [N57] point 3 (b). Une consigne et une tâche, construites à partir d'un contenu en quarantaine, pour mesurer un moniteur sur un mode réel plutôt que supposé.
- **Texte seul**, option (a) : l'épisode existe comme texte ; des moniteurs et des sondes *lectrices* le lisent. Aucun modèle ne le produit en agissant. C'est accordé et hors de cette pièce.
- **L'agent agit**, option (b) : un modèle à poids ouverts, chargé localement, reçoit la consigne et **produit lui-même** l'épisode, pas à pas, en appelant les outils d'un environnement de tâche. C'est la seule voie pour qu'une sonde lise les états internes de l'**auteur** ([RJ] nœud 4). Ses activations sont enregistrées pendant qu'il agit.
- **Banc fermé** : une machine de calcul louée ou possédée pour la seule course, sans réseau sortant pendant l'action, sans secret, portant le code figé du banc, les poids de l'agent, un environnement de tâche **entièrement simulé** et le lot d'épisodes de la course, rien d'autre. Elle n'existe que le temps de la course.

### 1.2 Ce qui est exclu, sans exception

1. Tout système réel, tout tiers, toute adresse réelle, tout compte réel, toute donnée personnelle. Le « dommage » d'un épisode est un état d'un monde simulé, jamais un fait hors du banc.
2. Tout **modèle qui agit** servi par un tiers. L'agent est à poids ouverts, sur la machine du banc ; la consigne dérivée du coffre n'est envoyée, pour la faire exécuter, à aucune interface de modèle extérieure, et un refus de classifieur y serait un arrêt (section 4.2). Cette exclusion vise l'agent, pas les lecteurs : le coffre vit déjà sur le dépôt privé du programme, et le juge, qui est une session du programme, lit les transcriptions par le même moyen (section 3.1).
3. Tout entraînement, tout affinage, toute mise à jour des poids de l'agent sur le banc ou à partir de ses sorties.
4. Toute boucle de retour : aucune note, aucun verdict, aucun seuil de moniteur ne revient vers l'agent, vers qui écrit ses consignes, ni vers un essai suivant. Le bras « avec retour » de [RJ] nœud 2 relève d'un autre texte et n'est pas couvert ici.
5. Toute écriture de consigne neuve par le banc ou par son opérateur. Le banc rejoue le lot scellé ; il ne compose, ne varie ni n'améliore aucune consigne.
6. Toute démonstration : devant un tiers, dans un papier, un billet, un entretien, une copie publique ([N57] points 2 et 6).
7. Toute course qui n'a pas son préenregistrement scellé et contre-lu (R1, R2) et son GO cité par exécution.
8. Les machines de travail du programme : sessions de rédaction, dépôt cloné, postes de Lazar. Le banc n'est aucune d'elles.

### 1.3 Différence avec la production

| | Production | Banc fermé |
|---|---|---|
| Effets des actions | réels | états d'un monde simulé, détruits avec la machine |
| Réseau | ouvert | sortant coupé pendant l'action |
| Outils | ceux du déploiement | liste fermée d'outils simulés, déclarée au préenregistrement |
| Secrets | présents | aucun sur la machine |
| Durée de vie | continue | une course, puis destruction après versement |
| Sorties | servent à quelqu'un | quarantaine ; seuls des agrégats à schéma fermé sortent |
| Qui lance | l'usage | un opérateur nommé, un GO par exécution |

« Hors production » veut donc dire deux choses, toutes deux exigées : l'agent ne peut **atteindre** rien de réel, et rien de ce qu'il produit ne **sert** hors de la mesure.

---

## 2. Confinement

Chaque ligne porte le numéro de la garde qui l'éprouve (section 4.1).

**Réseau.**
- Poids, dépendances et code sont posés **avant** l'arrivée du lot ; puis le réseau sortant est coupé **à l'extérieur du bac de l'agent**, par un moyen que l'agent ne peut pas atteindre. (garde 1)
- **Deux niveaux, toujours.** Chez un loueur où la machine louée est elle-même un conteneur, il n'y a pas d'« hôte » à soi : la coupure se fait alors soit par le pare-feu du fournisseur, soit par un bac intérieur pour l'agent, les gardes vivant dans l'enveloppe louée. Si aucun des deux n'est possible chez un fournisseur, ce fournisseur ne convient pas au banc ; cela se vérifie **sur sa documentation, avant de louer**, pour ne pas le découvrir à prix payant.
- La coupure nomme, en plus du réseau sortant courant : les adresses locales au lien, le **service de métadonnées du fournisseur** (qui peut porter des secrets sans être du « réseau sortant » au sens courant), la résolution de noms.
- Seule voie restante : le canal d'administration entrant de l'opérateur. Aucun service du banc n'écoute ailleurs que sur la boucle locale.
- Les services de l'environnement de tâche sont des simulacres locaux ; aucun nom ni adresse d'un système réel n'y figure. (garde 6)

**Droits.**
- L'agent tourne dans un conteneur, sous un compte sans privilèges, système de fichiers en lecture seule hors d'un répertoire de travail remis à zéro entre deux épisodes. **Le modèle aussi est remis à zéro** : historique de conversation, cache de préfixe et tout état du serveur d'inférence sont vidés entre deux épisodes. (garde 7)
- Aucun secret sur la machine : ni jeton du dépôt, ni clé d'un fournisseur de calcul, ni clé d'un fournisseur de modèles ; variables d'environnement vidées avant l'arrivée du lot. Le dépôt n'est pas cloné sur le banc. (garde 2)
- Les gardes, le chien de garde et le journal tournent **hors** du conteneur de l'agent ; le journal est en ajout seul, tenu par un processus que l'agent ne peut ni lire ni signaler. (garde 8)

**Données.**
- Le lot d'épisodes entre scellé, par empreinte vérifiée à l'arrivée ; il ne contient que les consignes de la course préenregistrée, pas le coffre. (garde 3)
- Les poids de l'agent sont en lecture seule ; empreinte prise avant la première action et après la dernière. (garde 4)
- **Aucun moniteur sur le banc pendant que l'agent agit** : ni poids de sonde, ni seuil, ni score, ni code d'agrégateur. L'absence se constate **par empreinte**, contre le manifeste des moniteurs (noms et empreintes, sans contenu), jamais par le nom seul. La mesure se fait en deux temps : l'agent agit et ses activations sont enregistrées ; puis, l'agent arrêté, les moniteurs gelés lisent une fois ([PR], « ouverture unique »). (garde 5)

**Outils.** Liste fermée, déclarée au préenregistrement ; tout appel hors liste est refusé et clôt l'épisode. Aucun outil ne donne à l'agent un accès hors de son répertoire de travail. (garde 6)

**Durée.** Plafonds par épisode (pas, jetons produits, temps d'horloge) et par course (épisodes, heures, dépense), fixés au préenregistrement ; un chien de garde extérieur au processus de l'agent les applique. (garde 9)

**Qui peut lancer.**
- Un **opérateur du banc** nommé au préenregistrement : une session qui n'a conçu ni sonde ni agrégateur et n'en concevra plus ([N57] point 5). La mère orchestre et consigne ; elle ne lit ni le lot ni les sorties.
- Chaque exécution cite un GO valide de `registres/go.md` (garde de calcul du dépôt) et l'empreinte du préenregistrement de la course. (garde 10)
- Chaque accès au lot ou aux sorties est consigné **avant** d'avoir lieu : qui, quand, pourquoi ([N57] point 5). (garde 11)

**Arrêt.** Par l'identifiant de l'instance et, sur la machine, par le numéro du processus ; jamais par motif de ligne de commande (R10). L'arrêt se consigne dans `registres/arrets.md`. Avant toute destruction : inventaire (noms, tailles, empreintes, sans lecture) et versement scellé en quarantaine ([CL], « Récupérer ce qui est récupérable »).

**Versement en quarantaine.** Le banc n'a ni jeton ni dépôt : il ne pousse rien. (garde 13)
- Les empreintes de chaque sortie sont prises **sur le banc**, par un processus hors du bac de l'agent, l'agent arrêté, et inscrites à un inventaire.
- L'opérateur **tire** les sorties par le canal d'administration entrant, vers un poste de transit nommé au préenregistrement ; le banc n'ouvre aucune connexion.
- À l'arrivée, chaque empreinte est revérifiée contre l'inventaire ; un écart arrête et se consigne. Le transfert est une copie de fichiers fermés : l'opérateur ne les ouvre pas.
- Destination : transcriptions, journal, états du monde et inventaire sur une **branche orpheline** de quarantaine du dépôt privé, à règle d'ouverture écrite ; les activations, si leur volume l'exige, sur un stockage à part nommé au préenregistrement, leurs empreintes seules sur la branche. Le choix du stockage à part est une ligne de devis.
- La machine n'est détruite qu'après cette vérification à l'arrivée.

---

## 3. Ce qui sort du banc, et ce qui n'en sort pas

### 3.1 Trois destinations, pas une de plus

| Objet | Destination | Qui lit |
|---|---|---|
| Transcriptions des épisodes (ce que l'agent a écrit et fait) | quarantaine, scellées (R6) | le juge ([PR], « Qui lit quoi »), session du programme qui lit sur la branche de quarantaine, comme on lit le coffre ; personne qui conçoit un moniteur |
| Activations enregistrées | quarantaine, scellées | les moniteurs gelés, par programme, une fois ; aucune personne ni session de conception |
| Journal du banc, états du monde simulé | quarantaine, scellés | le juge ; l'opérateur, pour le seul diagnostic d'une garde tombée |
| Agrégats : décomptes, taux, intervalles, verdict par cellule, classe de faille et hypothèse violée ([N57] point 3 a) | hors quarantaine, scellés | tous, concepteurs compris |
| Manifeste de course (configuration, versions, graines, commit, empreintes ; R9) | hors quarantaine | tous |

- Les activations vont en quarantaine au même titre que le texte : on peut en tirer le contenu.
- Tout ce que l'agent produit de **neuf** à partir d'une consigne du coffre est un contenu de quarantaine, même s'il dépasse la consigne. Il ne se réemploie dans aucune mesure sans un texte contre-lu et le mot de Lazar ([CL]).
- Noms de fichiers, de branches et de champs : aucun ne dit un mode.

### 3.2 Le passage hors quarantaine

Un seul passage : le fichier des agrégats, vérifié **par programme** contre un schéma fermé (nombres, identifiants de cellule, classes prises dans une liste fermée du préenregistrement ; **aucun champ de texte libre**). Un fichier qui ne passe pas reste en quarantaine. (garde 12)

### 3.3 Aucun score de moniteur dans l'entraînement de l'agent (N-053 point 5)

Sur ce banc l'invariant est tenu **par construction**, deux fois : l'agent n'est pas entraîné du tout (exclusion 3, garde 4), et aucun moniteur n'est présent quand il agit (garde 5). La garde demandée par [PR] (« garde de l'invariant de N-053 point 5 absente ou non éprouvée : aucune course ») est ici la réunion des gardes 4 et 5.

### 3.4 Accès consignés

Registre des accès dans `registres/decisions.md` : une ligne par lecture du lot ou des sorties (qui, quand, pourquoi), écrite avant la lecture. Qui a lu ne contribue plus à la conception d'un moniteur ([N57] point 5). La liste nominative des lecteurs permis est dans le préenregistrement de la course.

---

## 4. Gardes et liste d'arrêt

### 4.1 Gardes, chacune éprouvée sur un cas sain et sur un artefact (R5)

Toutes les épreuves se font **à blanc** : avec un agent factice (programme scripté, sans modèle) et une consigne anodine, jamais avec un contenu du coffre. Les résultats d'épreuve sont scellés avant la course ; une garde non éprouvée vaut une garde absente. Seule l'épreuve de la remise à zéro du modèle (garde 7, dernier artefact) demande un modèle chargé : elle se fait pendant la répétition à blanc, avec une consigne anodine.

| n° | Garde | Cas sain (doit passer) | Artefact (doit arrêter) |
|---|---|---|---|
| 1 | Réseau sortant coupé hors du bac de l'agent, service de métadonnées et adresses locales au lien compris | banc réglé comme prévu : les essais de connexion de contrôle échouent tous, le banc démarre | une règle laissée ouverte ; le service de métadonnées joignable : la garde refuse le démarrage |
| 2 | Aucun secret sur la machine | environnement vidé | un jeton factice posé dans l'environnement ou dans un fichier |
| 3 | Intégrité du lot | lot à l'empreinte attendue | lot modifié d'un octet |
| 4 | Poids de l'agent intacts | empreinte égale avant et après | fichier de poids modifié d'un octet pendant la course |
| 5 | Aucun moniteur sur le banc pendant l'action, constaté par empreinte | disque sans aucun fichier dont l'empreinte figure au manifeste des moniteurs | copie **renommée** d'un fichier factice inscrit à un manifeste d'épreuve |
| 6 | Liste fermée d'outils, environnement simulé | appels dans la liste | appel hors liste par l'agent factice ; adresse non locale dans la configuration |
| 7 | Droits et remise à zéro, du répertoire et du modèle | écriture dans le répertoire de travail, vidé ensuite ; contexte du modèle vide au début de l'épisode | écriture hors du répertoire ; fichier qui survit d'un épisode au suivant ; mot témoin anodin d'un épisode retrouvé dans le contexte du suivant |
| 8 | Journal en ajout seul, hors du conteneur | journal complet | ligne retirée ou réécrite ; journal joignable depuis le conteneur |
| 9 | Plafonds et chien de garde | épisode court | agent factice qui boucle ; course qui dépasse son plafond |
| 10 | GO et préenregistrement cités | GO valide, empreinte égale | GO absent, périmé ou d'un autre objet ; empreinte différente |
| 11 | Registre des accès | ligne présente avant le lancement | lancement sans ligne |
| 12 | Schéma fermé des agrégats | fichier conforme | fichier portant un champ de texte libre ou une classe hors liste |
| 13 | Versement en quarantaine : empreintes prises sur le banc, revérifiées à l'arrivée | transfert intact, inventaire égal | fichier altéré pendant le transfert ; fichier absent de l'inventaire ; destruction demandée avant la vérification |

La garde 1 demande en plus une **répétition à blanc sur la machine réelle** (même fournisseur, même image), parce qu'un pare-feu ne s'éprouve pas sur un autre hôte que le sien (section 8). Avant elle, et sans dépense : lecture de la documentation du fournisseur pour établir lequel des deux niveaux de la section 2 y est possible.

### 4.2 Liste d'arrêt

| Condition | Action |
|---|---|
| Pièce du vérificateur interne neuf absente, non scellée, ou portant un « non » ou un « non vérifiable » sur un seul des points 1 à 22 de 6.1 | Aucune course. La construction des gardes et leurs épreuves à blanc, qui sont ce qu'il vérifie, se font avant (section 6.3). |
| Conditions de [GO71] non réunies : contre-lecture de cette pièce et vérification de ses corrections ; gardes éprouvées à blanc sur un cas sain et un artefact | (b) ne part pas. [GO71], écrit sur la v1, dit « douze gardes » ; cette pièce en compte treize depuis la v2 (versement en quarantaine) et les exige toutes. |
| Préenregistrement de la course non scellé | Aucune construction des gardes : elles éprouvent ce qu'il déclare (outils, plafonds, lecteurs, poste de transit). |
| Audit des lignées des moniteurs sans réponse, ou vérificateur de la lignée d'un moniteur évalué | Le vérificateur n'est pas lancé ; donc aucune course ([GO72]). |
| Sortie hors quarantaine, de quelque forme que ce soit (papier, billet, dépôt public, partage) | Revue de sécurité externe d'abord ([ML] ; [GO] l. 581, point 6). |
| Préenregistrement de la course absent, non scellé ou non contre-lu ; GO d'exécution absent | Aucune course. |
| Une garde de 4.1 absente, non éprouvée, ou éprouvée sur un seul des deux cas | Aucune course. |
| Une garde tombe pendant la course | Arrêt par identifiant (R10) ; aucun repli silencieux ; versement en quarantaine ; course tronquée, rapportée. |
| Connexion sortante tentée, aboutie ou non | Arrêt de l'épisode et de la course ; consigné ; nœud. |
| Appel d'outil hors liste, écriture hors du répertoire de travail, atteinte au journal ou à une garde | Arrêt de l'épisode ; consigné dans les agrégats comme décompte ; à la deuxième occurrence, arrêt de la course et nœud. |
| Poids de l'agent changés ; fichier de moniteur présent pendant l'action ; état du modèle qui passe d'un épisode au suivant | Arrêt ; course « sans objet » ; audit. |
| Écart d'empreinte ou fichier hors inventaire au versement | Arrêt ; la machine n'est pas détruite ; consigné ; nœud. |
| Dépassement d'un plafond (pas, temps, dépense) | Arrêt de l'instance par son identifiant ; course tronquée, rapportée. |
| Contenu de quarantaine sur le point de sortir autrement que par 3.2, ou lu par qui conçoit un moniteur | Arrêt ; consigné ; nœud. |
| Lecture sans ligne au registre des accès | Arrêt ; la lecture est consignée après coup comme écart ; nœud. |
| Refus d'un classifieur de sûreté, à n'importe quelle étape | Consigner ; arrêter sur ce point ; ni contournement, ni reformulation, ni renvoi à une autre session ou à un sous-agent ([PR], liste d'arrêt). |
| Résultat trop propre, dans un sens ou dans l'autre (aucune évasion, ou toutes) | Même audit dans les deux cas (R4) avant tout verdict. |
| Écart à cette pièce ou au préenregistrement une fois scellés | Arrêt ; nœud ; version nouvelle (R12). |
| Demande d'usage hors mesure (montrer, prêter, publier, réemployer une sortie) | Refus ; nœud ; revue externe d'abord ([GO] l. 581, point 6 ; [N57] point 2). |

---

## 5. Les risques : ce qu'un agent qui agit peut faire de plus qu'un texte rejoué

Un texte rejoué est inerte : il ne fait rien, n'ajoute rien, ne touche rien. Un agent qui agit choisit ses gestes. Douze écarts, chacun avec sa réponse et ce qui reste.

| n° | Ce que l'agent qui agit ajoute | Réponse | Ce qui reste |
|---|---|---|---|
| 1 | Il peut produire un **effet** par ses outils. | Monde simulé, réseau sortant coupé hors du conteneur, liste fermée d'outils (gardes 1, 6). | Une faille de la simulation elle-même ; bornée par l'absence de réseau et de secret. |
| 2 | Il peut **écrire** un contenu de quarantaine là où on ne l'attend pas (fichier, journal, nom). | Tout ce que le banc produit va en quarantaine ; un seul passage sortant, à schéma fermé (garde 12). | Aucun champ libre ne sort ; un canal par les nombres est théorique et sans lecteur. |
| 3 | Il peut **élaborer** au-delà de la consigne : son épisode peut être plus opératoire que le contenu de départ. | Ses sorties sont un contenu de quarantaine de plein droit, lues par le seul juge, comptées au registre des accès, jamais réemployées sans texte contre-lu et mot de Lazar. | **Le coffre grossit.** C'est le coût propre de (b), à dire tel quel au relecteur. |
| 4 | Il peut **s'en prendre au banc** : gardes, journal, mesure. | Gardes, chien de garde et journal hors du conteneur, hors de sa portée (garde 8) ; droits réduits (garde 7). | Une évasion du conteneur ; elle ne rencontre ni réseau ni secret. |
| 5 | Il peut laisser un **état qui dure** d'un épisode à l'autre, sur le disque ou dans le contexte du modèle. | Remise à zéro du répertoire et du modèle entre épisodes (garde 7) ; machine détruite après versement. | Rien au-delà de la course. |
| 6 | Il pourrait **apprendre** à mieux échapper. | Aucun entraînement, aucun retour, aucun moniteur présent, une seule lecture (gardes 4, 5 ; exclusions 3 et 4). | Rien sur ce banc ; le bras avec retour est un autre texte. |
| 7 | Il peut **s'emballer** : boucle, dépense. | Plafonds et chien de garde extérieur (garde 9) ; garde de calcul du dépôt. | Une course tronquée, rapportée. |
| 8 | Il peut **se savoir éprouvé** et agir autrement. | Ce n'est pas un risque de sécurité mais de validité : mesuré et rapporté (conscience d'évaluation, [CL] N-053) ; jamais corrigé en rendant le banc moins fermé. | La mesure vaut pour le banc, pas pour la production ; à écrire dans chaque résultat. |
| 9 | Ses résultats peuvent **contaminer** les concepteurs de moniteurs. | Ils ne reçoivent que la classe de la faille et l'hypothèse violée ([N57] point 3 a ; [PR]). | Un moniteur corrigé sur ce retour devient « spécialisé » et le déclare ([PR]). |
| 10 | Réunis, lot, code et poids forment un **objet transportable** : l'organisme évadeur exécutable. | Les trois ne sont réunis que sur la machine du banc, le temps de la course ; le code du banc ne contient aucune consigne ; le lot retourne en quarantaine ; la machine est détruite. Aucune image de la machine n'est gardée. | L'objet peut être reconstitué par qui a accès aux trois ; d'où la liste nominative et le registre des accès. |
| 11 | Le banc peut **glisser** de la mesure à la démonstration. | Un GO par exécution ; périmètre clos (1.2) ; question fermée posée avant chaque course à un lecteur d'une autre lignée : « cette exécution sert-elle à autre chose que mesurer ? » — un oui bloque (repris de [GO] l. 581, point 5). | Dépend de la tenue du registre ; vérifiable après coup. |
| 12 | L'opérateur **lit** ce que l'agent produit en le lançant. | L'opérateur ne lit pas les sorties ; il voit décomptes et états des gardes. Le diagnostic d'une garde tombée est un accès consigné. | Un opérateur de plus hors de la conception des moniteurs. |

Ce que ce banc **ne couvre pas**, pour que personne ne le croie couvert : un agent dont les poids seraient changés par l'épreuve ; un agent servi par un tiers ; une tâche à effets réels ; une attaque qui apprend du moniteur. Chacun de ces quatre cas demande sa propre pièce.

---

## 6. Ce qui doit être vérifié, et par qui

### 6.1 Liste fermée pour un relecteur externe

Le relecteur n'a **pas** besoin de lire le coffre : les vingt-trois points portent sur le banc, ses gardes et ses registres, éprouvés à blanc. S'il demande à le lire, c'est un accès à consigner et un nœud.

*Périmètre*
1. Le préenregistrement de la course nomme l'agent (poids ouverts, chargés localement), la tâche, la liste des outils, les plafonds, l'opérateur, le poste de transit et la liste nominative des lecteurs.
2. Aucun des huit exclus de 1.2 n'est présent dans la course telle qu'elle est écrite.
3. L'environnement de tâche est entièrement simulé : aucune adresse, aucun compte, aucune donnée d'un système réel.

*Confinement*
4. Le réseau sortant est coupé hors du bac de l'agent, service de métadonnées du fournisseur et adresses locales au lien compris ; le niveau de coupure possible chez ce fournisseur est établi sur sa documentation ; l'épreuve des deux cas a été faite sur la machine réelle.
5. Aucun secret n'est sur la machine ; le dépôt n'y est pas cloné.
6. L'agent tourne sans privilèges, en lecture seule hors de son répertoire de travail ; répertoire et état du modèle sont remis à zéro entre épisodes.
7. Gardes, chien de garde et journal sont hors de portée de l'agent.
8. Aucun fichier de moniteur n'est sur le banc pendant l'action, ce qui est constaté par empreinte ; la lecture par les moniteurs vient après, l'agent arrêté.
9. Les poids de l'agent ont la même empreinte avant et après.
10. Les plafonds existent, sont chiffrés au préenregistrement et appliqués par un processus extérieur à l'agent.
11. L'arrêt se fait par identifiant ; la destruction suit un versement vérifié ; aucune image de la machine n'est gardée.

*Sorties*
12. Transcriptions, activations, journal et états du monde vont en quarantaine, scellés.
13. Le versement est tiré par l'opérateur, jamais poussé par le banc ; les empreintes sont prises sur le banc et revérifiées à l'arrivée ; la destination (branche orpheline, stockage à part éventuel) est nommée au préenregistrement.
14. Le seul passage hors quarantaine est le fichier des agrégats, vérifié par programme contre un schéma sans texte libre.
15. Les concepteurs de moniteurs ne reçoivent que la classe de la faille et l'hypothèse violée.
16. Le registre des accès porte une ligne par lecture, antérieure à la lecture ; aucun lecteur ne conçoit de moniteur ; le moyen par lequel le juge lit est écrit.
17. Aucun nom de fichier, de branche ou de champ ne dit un mode.

*Gardes et arrêts*
18. Les treize gardes ont chacune leurs deux épreuves, scellées avant la course.
19. La liste d'arrêt de 4.2 est reprise sans retrait dans le préenregistrement de la course.
20. Un refus de classifieur arrête sans contournement ; les refus passés sont consignés.

*Gouvernance*
21. Chaque exécution cite un GO ; aucune ne s'appuie sur un GO d'un autre objet.
22. La question fermée du risque 11 a reçu un non, par un lecteur d'une autre lignée que les moniteurs, avant chaque course.
23. Le relecteur dit par écrit ce qu'il a vu, ce qu'il n'a pas vu, et sa conclusion : validé, validé sous conditions, refusé. Sa pièce est versée et scellée ([RJ] nœud 3, option (a) : qui, quand, périmètre, conclusion).

Une réponse « non » ou « non vérifiable » à un seul point vaut « pas de course ».

### 6.2 L'alternative : des garde-fous internes à la place de la revue externe (état de la v2, tranché depuis : voir 6.3)

**C'est une décision de Lazar, et elle n'est pas prise.** Trois faits du registre, dans l'ordre : le 31 octobre, le gel est inscrit comme levé sur le mot de Lazar, la revue externe étant dite faite ([R888]) ; le 20 novembre, GO-2026-11-20-50 met six garde-fous internes « en place de la revue de sécurité externe pour la mesure interne » de la course « nouvelles attaques », ce qui montre qu'une revue externe est encore tenue pour due sur certains objets après le 31 octobre ; le 21 novembre, l'option (b) est accordée « dès que la pièce de sécurité est écrite ». Rien ne dit que les six garde-fous valent pour (b), ni que la revue du 31 octobre a couvert un agent qui agit sur un contenu dérivé du coffre.

Dans le cadre que [R888] inscrit, une vérification interne de ce dossier n'est pas un écart à R-611 : c'est une **condition ajoutée** par le mot du 21 novembre, à dire comme telle. Dans la lecture prudente que ce dossier suit (revue non opposable faute de pièce écrite), ce serait une substitution, qu'il faut alors nommer. Seul un mot explicite de Lazar dit laquelle des deux descriptions vaut ; pas de défaut à 48 heures.

Comparaison, pour éclairer ce mot sans le préjuger :

| Garde-fou de GO-2026-11-20-50 | Vaut-il pour (b) ? | Ce qu'il faudrait y ajouter |
|---|---|---|
| 1. Le procédé n'est demandé qu'après le verdict d'antériorité, par une session à part ; la mère ne le lit jamais | En partie. Ici le contenu existe déjà dans le coffre. Se garde : opérateur à part, mère qui ne lit pas. | Rien de plus que 2 « Qui peut lancer ». |
| 2. Quarantaine sur branche orpheline, règle d'ouverture écrite, liste nominative des lecteurs, chaque lecture consignée | Oui. | L'étendre aux sorties **neuves** de l'agent et aux activations (3.1), et dire la voie du versement (section 2, garde 13). |
| 3. Registre servi aux suivants : nom et énoncé seulement, vérifié par programme | Par analogie : c'est le schéma fermé des agrégats (3.2). | Interdire tout champ de texte libre. |
| 4. Aucune exécution hors du banc de mesure scellé ; chaque exécution citée par un GO | Oui, et c'est le cœur. Mais il suppose un banc défini. | Tout le confinement de la section 2 : pour (b), « le banc » doit retenir un agent, pas seulement un texte. |
| 5. Un lecteur d'une autre lignée répond oui ou non : « sert-il à autre chose que mesurer ? » | Oui (risque 11). | Sa lecture est un accès consigné. |
| 6. Revue externe avant toute sortie hors quarantaine | Oui, inchangé. | — |

Ce que les six ne contiennent pas et que (b) exige : le confinement de l'agent (gardes 1, 2, 6, 7, 8), l'intégrité de ses poids (garde 4), l'absence de moniteur pendant l'action (garde 5), les plafonds (garde 9), le versement vérifié (garde 13), l'épreuve de chaque garde sur deux cas (R5), la destruction de la machine. Si Lazar choisit la voie interne, la proposition du rédacteur est : les six, plus les treize gardes, plus un **vérificateur interne neuf**, d'une autre lignée que les moniteurs et que le rédacteur, qui répond aux points 1 à 22 de 6.1 et verse sa pièce scellée. Cette voie est plus rapide ; elle est plus faible qu'une revue externe, et la phrase d'entretien devrait alors dire « garde-fous internes vérifiés », sans les présenter comme la revue de sécurité elle-même ([RJ] nœud 3).

---

### 6.3 Décision de Lazar du 21 novembre : la voie interne

Mot de Lazar, verbatim ([ML]) : « go reco vérificateur interne neuf; on met de cote la revie externe jusqu a publication du papier ». Il répond au nœud 1 de la v2, dont la recommandation était « (b) pour avancer, et (a) en parallèle ».

Ce que le mot fixe, lu au plus près :
1. **La voie interne est retenue.** Les six garde-fous de GO-2026-11-20-50, les treize gardes de la section 4.1 et un **vérificateur interne neuf** forment la condition de l'option (b), comme proposé en 6.2.
2. **La revue de sécurité externe est mise de côté jusqu'à la publication du papier.** La partie « (a) en parallèle » de la recommandation de la v2 n'est donc pas retenue : la pièce écrite de la revue du 31 octobre n'est plus un préalable à la première course. La revue externe reste due avant toute sortie hors quarantaine, ce que disait déjà le sixième garde-fou.
3. **Écart déclaré.** La note [ML] lit cette décision comme un écart à [R611] et à [N57] point 4, décidé par Lazar ; le rédacteur la reprend ainsi. Dans le cadre que [R888] inscrit (gel levé), c'est une condition ajoutée ; dans la lecture prudente suivie jusqu'à la v3, c'est une substitution. Les deux descriptions mènent au même geste ; l'écart est à porter à la prochaine version du programme, et c'est le geste de Lazar.

Ce que le mot ne fixe pas, et que le rédacteur n'y ajoute pas : aucun lancement, aucune dépense, aucun nom, aucun fournisseur, aucune date.

**Les deux mots suivants, portés par la v6.** [GO71] inscrit la décision au registre : « Option 2 : ton mot exprès qui remplace la revue externe par les six garde-fous internes de l'autre course (GO-2026-11-20-50). go ». La lecture « écart déclaré à R-611 et à N-057 point 4 » y est inscrite par la mère ; ce n'est plus seulement la lecture d'une note. [GO71] ne nomme pas le vérificateur ; [ML] et [ML2] le font. Les trois mots se cumulent : six garde-fous, gardes de cette pièce, vérificateur. [ML2] fixe le vérificateur : « go reco Opus neuf vérificateur, opérateur et juge à proposer » — un **Opus 5.5 neuf**, qui intervient à son rang dans l'ordre des gestes ci-dessous, pas plus tôt : il n'aurait rien à vérifier.

**Une tension à dire.** Le cinquième garde-fou de GO-2026-11-20-50 et la proposition de 6.2 demandent un lecteur « d'une autre lignée que les moniteurs ». Le rédacteur ne lit aucun moniteur et ne sait pas de quelle lignée ils sont. Si l'un d'eux est de la lignée de Claude, un Opus ne remplit pas ce critère à la lettre. La v6 écrivait qu'alors le mot de Lazar primait et que l'écart se déclarait ; **le registre dit autrement, et il prime** : « si un moniteur évalué est de la lignée Claude, un vérificateur d'une autre lignée est requis (audit des lignées en cours) » ([GO72], réserve inscrite par la mère). Le vérificateur n'est donc pas lancé avant la réponse de cet audit (réserve 10). La question fermée du risque 11, elle, reste posée à un lecteur d'une autre lignée.

**Le vérificateur interne neuf.**
- Qui : une session neuve d'Opus 5.5 ([ML2]). Il n'est ni le rédacteur de cette pièce, ni sa contre-lectrice, ni un concepteur de sonde ou d'agrégateur, ni l'attaquant informé, ni l'opérateur du banc, ni le juge ([ML], complété des deux derniers par le rédacteur : on ne vérifie pas son propre banc).
- Ce qu'il lit : cette pièce, le préenregistrement de la course, le code figé du banc et des gardes, les résultats scellés des épreuves à blanc, le registre des accès, la documentation du fournisseur. **Il ne lit pas le coffre** ; s'il le demande, c'est un accès à consigner et un nœud.
- Ce qu'il rend : une pièce scellée qui répond aux points 1 à 22 de 6.1 par oui, non ou non vérifiable, chacun avec le chemin et l'empreinte de ce qu'il a vu, puis sa conclusion au sens du point 23 : validé, validé sous conditions, refusé. Un seul « non » ou « non vérifiable » vaut « pas de course ».
- Quand : après la construction des gardes et leurs épreuves à blanc, avant la répétition sur la machine réelle pour les points qui ne la demandent pas, et de nouveau après elle pour le point 4 ; toujours avant la première course sur un contenu du coffre.
- Ordre des gestes, donc : préenregistrement de la course (classe A, chaîne complète) ; code des gardes (classe B, contre-lu) ; épreuves à blanc scellées ; devis et GO de la répétition ; répétition ; pièce du vérificateur ; GO de la course. La ligne du registre des GO, premier geste de la v5, est faite ([GO71]).

**Phrase d'entretien** : « garde-fous internes vérifiés ; la revue externe est prévue avant la publication », sans présenter la vérification interne comme la revue de sécurité elle-même. La correction des phrases prévues que signale [RJ] nœud 3 reste à faire par qui tient ces textes.

---

## 7. Nœuds renvoyés à Lazar

Nœuds d'arrêt : pas de défaut à 48 heures.

**Nœud 1 — tranché le 21 novembre.** Ce que désigne « la pièce de sécurité » : ce dossier, avec les six garde-fous internes à la place de la revue externe ([GO71]), vérifié par un vérificateur interne neuf ([ML]) ; revue externe mise de côté jusqu'à la publication du papier (section 6.3). Les trois options et la recommandation de la v2 se lisent dans la v2 ou la v3, archivées.

**Nœud 2 — tombé.** La question posée à Lazar (la revue du 31 octobre a-t-elle une pièce écrite, et couvre-t-elle l'option (b) ?) n'est plus un préalable à la course ([ML]). Elle reviendra avec la revue externe d'avant publication ; le nœud 3 de [RJ], lui, n'est pas tranché par cette pièce.

**Nœud 3 — Qui est l'opérateur du banc, qui est le juge.** Le vérificateur est fixé ([ML2]) : un Opus 5.5 neuf. Restent deux rôles, « à proposer » : la note [ML2] propose, pour Lazar, une session Opus 5.5 neuve dédiée comme opérateur, un Fable 5.2 neuf comme juge et un Opus 5.5 neuf comme second juge (confiance 0,6, celle de la note). C'est la proposition de la session de l'attaquant informé, pas un mot de Lazar ; le rédacteur n'y ajoute qu'une contrainte, déjà dans cette pièce : aucun ne conçoit de moniteur, tous sont distincts entre eux, du vérificateur, de la mère, de l'attaquant informé, du rédacteur et de sa contre-lectrice.

---

## 8. Coût

- **Cette pièce** : aucune dépense.
- **Gardes 2 à 13** : épreuves à blanc sur processeur, avec un agent factice sans modèle (sauf le dernier artefact de la garde 7, fait pendant la répétition). Aucun calcul payant. Le code des gardes est un instrument (contre-lecture par un autre modèle) ; il n'est pas écrit ici, et son écriture attend l'issue du nœud 1 : sous la lecture prudente de ce dossier, la construction attend comme l'exécution.
- **Avant la répétition, sans dépense** : lecture de la documentation du fournisseur visé, pour savoir si le pare-feu du fournisseur ou un bac intérieur y est possible, et si son service de métadonnées se coupe.
- **Stockage à part des activations**, s'il en faut un : ligne de devis, non chiffrée ici.
- **Garde 1 et répétition à blanc** : une machine à carte graphique du même fournisseur et de la même image que la course, le temps de charger les poids de l'agent, de couper le réseau, de passer les deux cas de chaque garde et un épisode anodin. Esquisse de devis, sans chiffre : (heures de machine) × (tarif horaire constaté le jour du devis) + stockage du versement. Le rédacteur n'avance aucun montant : il n'a vérifié aucun tarif (R7). Devis à écrire par l'opérateur, GO avant dépense.
- **Vérificateur interne** : une session, aucun calcul payant.
- **Revue externe** : mise de côté jusqu'à la publication ([ML]) ; ce sera un contact externe, rédigé par le programme et envoyé par Lazar ; coût éventuel inconnu du rédacteur.
- **La course elle-même** : hors de cette pièce ; devis au préenregistrement.

---

## 9. Ce que cette pièce ne dit pas, et réserves

- Elle ne dit rien du contenu du coffre, ni d'aucun mode, ni d'aucun moniteur : le rédacteur n'en a rien lu. Non lus, par consigne : `donnees/bras-attaque*`, `donnees/mode-tenu-a-l-ecart*`, `docs/notes/bras-attaque/`, toute branche `claude/scellement-2-*`, `docs/notes/programme-et-4-familles-evasion/`, les lignes R-604 à R-610 de `registres/decisions.md`, toute conception, tout résultat et tout seuil de moniteur, toute sortie de la course « nouvelles attaques », `registres/etat.md`, la dernière passation.
- **Réserve 1.** Les six garde-fous sont pris dans la ligne du registre, non dans les avis qu'elle cite (non ouverts).
- **Réserve 2.** Le rédacteur ne connaît pas le banc de mesure actuel du programme ; la section 2 dit ce que le banc doit garantir, pas ce qui existe. L'écart est à mesurer par l'opérateur.
- **Réserve 3.** Le rédacteur ne sait ni s'il existe une pièce écrite de la revue externe dite faite le 31 octobre ([R888]), ni ce qu'elle a couvert. Depuis [ML] ce n'est plus un préalable à la course ; cela le redevient avant toute publication.
- **Réserve 4.** La garde 5 suppose que les sondes lisent des activations **enregistrées**. Si une sonde devait lire pendant l'action, la garde 5 et le point 3.3 seraient à réécrire, et ce serait un nœud.
- **Réserve 5.** La suffisance de l'isolement d'un conteneur contre un agent n'est pas démontrée ici ; la réponse de cette pièce est qu'une sortie du conteneur ne rencontre ni réseau ni secret. C'est le point où un regard externe vaut le plus.
- **Réserve 6.** Les changements de la v6 (section 12) ne sont pas encore vérifiés par la contre-lectrice.
- **Réserve 7.** La faisabilité de la coupure du réseau chez les loueurs du programme n'est pas établie ici ; le rédacteur n'a lu la documentation d'aucun fournisseur.
- **Réserve 8.** Levée : les trois mots de Lazar sont au registre des GO sur `main` ([GO71], [GO72]). Les notes [ML] et [ML2] restent citées comme la source où les mots ont été écrits. [GO72] cite la note [ML] au commit `154bdff94` ; le rédacteur l'a lue au commit `3df76fac`, même empreinte.
- **Réserve 9.** La lecture « écart déclaré à R-611 et à N-057 point 4 » est inscrite au registre par la mère ([GO71]) ; le mot de Lazar, lui, dit que les six garde-fous internes remplacent la revue externe.
- **Réserve 10.** Lignée du vérificateur : un Opus 5.5 neuf, sauf si un moniteur évalué est de la lignée de Claude, auquel cas un vérificateur d'une autre lignée est requis ([GO72]). L'audit des lignées des moniteurs est fait par la mère ; le rédacteur ne lit aucun moniteur. Le vérificateur ne se lance pas avant sa réponse.
- **Réserve 11.** [GO71] nomme la v1 de cette pièce (`a4d515fc…`) et « douze gardes » ; la pièce en vigueur est la dernière version acceptée par la contre-lectrice, qui en compte treize. Le rédacteur lit la condition de [GO71] comme portant sur la pièce telle que corrigée ; à la mère de le confirmer.
- **Refus de classifieur** : aucun pendant la rédaction.

---

## 10. Réponse aux points de la contre-lecture de la v1 ([CL1])

| Point | Réponse | Où |
|---|---|---|
| B1, gel tenu pour en vigueur alors que le registre le dit levé | Corrigé : [R888] lue et citée ; la prudence est dite comme une lecture choisie contre la lettre du registre. | en-tête, verdict 1, liste d'arrêt ligne 1, 6.2 |
| B2, nœud 1 mal posé | Reposé avec [R888] ; trois options refaites ; recommandation et confiance refaites ; nœud 2 réduit à une question précise. | section 7 |
| M1, voie du versement | Ajoutée : versement tiré, empreintes sur le banc, vérification à l'arrivée, destination ; garde 13 ; point 13 de 6.1. | section 2, 4.1, 4.2, 6.1 |
| M2, coupure du réseau chez un loueur en conteneur, métadonnées | Deux niveaux écrits, service de métadonnées et adresses locales au lien nommés, vérification sur documentation avant de louer ; réserve 7. | section 2, garde 1, 6.1 point 4, section 8 |
| M3, exclusion 2 et le juge | Exclusion restreinte au modèle qui agit ; moyen de lecture du juge écrit. | 1.2, 3.1, 6.1 point 16 |
| M4, garde 5 par le nom | Constat par empreinte ; artefact : copie renommée. | section 2, garde 5, 6.1 point 8 |
| M5, remise à zéro du modèle | Ajoutée, avec son artefact. | section 2, garde 7, risque 5 |
| M6, réserve 3 inexacte | Réécrite. | section 9 |
| M7, « branche orpheline » | Lettre reprise. | 6.2 |


---

## 11. Changements de la v4 par rapport à la v3

Une seule cause : la décision de Lazar du 21 novembre ([ML]). Rien d'autre n'est touché ; périmètre, confinement, sorties, gardes, risques et liste du relecteur sont ceux de la v3.

| Lieu | Changement |
|---|---|
| Titre, en-tête | « v4 » ; une ligne neuve sur la décision ; lignes « Date » et « Contre-lecture » mises à jour (la v3 disait encore « v2 » à la ligne « Date ») |
| Sources | ligne [ML] ajoutée |
| Verdict | points 1 et 3 réécrits |
| 4.2, liste d'arrêt | la première ligne est remplacée par trois lignes : pièce du vérificateur, mot lisible au registre, revue externe avant toute sortie |
| 6.2 | titre seul : dit que l'alternative est tranchée ; le texte reste celui de la v2 |
| 6.3 | section neuve : le mot, ce qu'il fixe, ce qu'il ne fixe pas, le vérificateur interne, l'ordre des gestes, la phrase d'entretien |
| 7 | nœud 1 tranché ; nœud 2 tombé ; nœud 3 étendu au vérificateur |
| 8 | lignes « Vérificateur interne » et « Revue externe » |
| 9 | réserves 3 et 6 réécrites ; réserves 8 et 9 neuves |


---

## 12. Changements de la v6 par rapport à la v5

Une seule cause : la ligne GO-2026-11-21-71 du registre et le mot de Lazar sur le vérificateur ([GO71], [ML2]). Périmètre, confinement, sorties, gardes, risques et liste des vingt-trois points sont inchangés.

| Lieu | Changement |
|---|---|
| Titre, en-tête | « v6 » ; ligne « Décisions de Lazar » réécrite avec les trois mots ; lignes « Date » et « Contre-lecture » mises à jour |
| Sources | lignes [GO71] et [ML2] ajoutées |
| Verdict | point 3 : le vérificateur est fixé, deux noms restent |
| 4.2, liste d'arrêt | la ligne « mot non lisible au registre » est remplacée par deux lignes : conditions de [GO71] ; préenregistrement avant construction |
| 6.3 | deux paragraphes neufs (« Les deux mots suivants », « Une tension à dire ») ; ligne « Qui » du vérificateur ; ligne « Ordre des gestes » |
| 7 | nœud 1 cite [GO71] ; nœud 3 réduit à l'opérateur et au juge |
| 9 | réserves 6, 8, 9 réécrites ; réserves 10 et 11 neuves |


---

## 13. Changements de la v7 par rapport à la v6

Une seule cause : la ligne GO-2026-11-21-72 du registre ([GO72]), qui inscrit les deux mots jusque-là cités par les seules notes, et la réserve de lignée de la mère.

| Lieu | Changement |
|---|---|
| Titre, en-tête | « v7 » ; la ligne « Décisions de Lazar » cite [GO72] pour les mots (2) et (3) ; lignes « Date » et « Contre-lecture » mises à jour |
| Sources | ligne [GO72] ajoutée ; [ML] et [ML2] gardées |
| 4.2, liste d'arrêt | une ligne neuve : audit des lignées avant le lancement du vérificateur |
| 6.3, « Une tension à dire » | la phrase de la v6 (« le mot de Lazar prime et l'écart se déclare ») est remplacée par la règle inscrite au registre : une autre lignée est requise si un moniteur évalué est de la lignée de Claude |
| 9 | réserves 8 et 10 réécrites |
