import re, subprocess, sys
from pathlib import Path
R = Path("/home/user/controle-ia-travail")
devis = (R / "docs/notes/devis-famille-reserve-cycle-2-v1/devis-banque-d-episodes-famille-reserve-cycle-2-v1.md").read_text(encoding="utf-8")
def git(branche, chemin):
    return subprocess.run(["git", "-C", str(R), "show", f"origin/{branche}:{chemin}"], capture_output=True, text=True, check=True).stdout.split("\n")
def disque(chemin):
    return (R / chemin).read_text(encoding="utf-8").split("\n")
SOURCES = {
    "devis-bras-a-v2.md": lambda: git("claude/pensive-bardeen-1fv7hw", "docs/notes/relance-organismes-discrets-v1/devis-bras-a-v2.md"),
    "devis-essai-de-mesure": lambda: git("claude/pensive-bardeen-1fv7hw", "docs/notes/relance-organismes-discrets-v1/devis-essai-de-mesure-lecteurs-bras-a-v1-brouillon3.md"),
    "piece-6-esquisse-de-devis-banque-v3.md": lambda: git("claude/scellement-2-familles-aveugles-v1", "docs/notes/scellement-2-familles-aveugles-v1/piece-6-esquisse-de-devis-banque-v3.md"),
    "registres/depenses.md": lambda: disque("registres/depenses.md"),
    "registres/go.md": lambda: disque("registres/go.md"),
    "registres/decisions.md": lambda: disque("registres/decisions.md"),
    "relais_reel.py": lambda: disque("docs/notes/ideation-organisme-v1/orchestrateur-v52b/pole/relais_reel.py"),
    "collisionneur_v9_v3.py": lambda: disque("docs/notes/collisionneur-v9/collisionneur_v9_v3.py"),
    "choix-mistral-deepseek-v1.md": lambda: disque("docs/notes/relance-organismes-discrets-v1/lecteur-remplacant-carbon-v1/choix-mistral-deepseek-v1.md"),
    "devis-episodes-reels-t05-nuit-v1.md": lambda: disque("docs/notes/devis-episodes-reels-t05-nuit-v1/devis-episodes-reels-t05-nuit-v1.md"),
    "devis-couche-2-banque-deux-modes-v1.md": lambda: disque("docs/notes/devis-couche-2-banque-deux-modes-v1.md"),
    "decision-N-049-v1.md": lambda: disque("docs/decisions/decision-N-049-v1.md"),
    "T0.5-selection-papiers-v1.md": lambda: disque("docs/procedures/T0.5-selection-papiers-v1.md"),
    "propositions.py": lambda: disque("src/controle_ia/environnements/propositions.py"),
}
cache = {}
INTERDIT = re.compile(r"R-2059|ii-b|consigne-privee|compte-4|archives-reponses-modeles|B bis|étape B|(^|[^0-9a-f])7[ab]([^0-9a-f]|$)|T0\.6|P3-bis|[Bb]arreau 5")
# citations : `chemin:ligne[-ligne]` puis éventuelles suites « et `:ligne` », « , `:ligne` »
motif = re.compile(r"`([^`\s]*?(?:\.md|\.py|…))?:(\d+)(?:-(\d+))?`")
dernier = None
vus = set()
for ligne_devis in devis.split("\n"):
    dernier = None
    for m in motif.finditer(ligne_devis):
        nom = m.group(1) or dernier
        dernier = nom
        if nom is None:
            print("?? citation sans fichier :", m.group(0)); continue
        cle = next((k for k in SOURCES if k in nom or nom.rstrip("…") and k.startswith(nom.rstrip("…").split("/")[-1])), None)
        if cle is None:
            print("?? source inconnue :", nom); continue
        if cle not in cache:
            cache[cle] = SOURCES[cle]()
        a = int(m.group(2)); b = int(m.group(3) or a)
        if (cle, a, b) in vus: continue
        vus.add((cle, a, b))
        for n in range(a, b + 1):
            if n > len(cache[cle]):
                print(f"!! {cle}:{n} hors du fichier ({len(cache[cle])} lignes)"); continue
            t = cache[cle][n - 1]
            if cle.startswith("registres/") and INTERDIT.search(t):
                t = "[ligne à filtre : extrait de prix seul] " + " … ".join(re.findall(r".{0,40}1,1833.{0,40}", t))
            print(f"{cle}:{n} | {t[:175]}")
print(len(vus), "citations distinctes")
