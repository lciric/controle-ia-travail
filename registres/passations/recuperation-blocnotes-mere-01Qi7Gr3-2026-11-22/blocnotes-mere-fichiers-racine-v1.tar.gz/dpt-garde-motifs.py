#!/usr/bin/env python3
"""Garde de motifs de fortune pour des textes neutres (ce n'est pas la garde du collisionneur)."""
import re, sys
MOTIFS = {
 "chemin interne": r"docs/|registres/|prereg/|src/|/home/|scratchpad|\.md\b|\.py\b|\.sha256|\.txt\b",
 "identifiant de registre ou d'accord": r"\bGO-\d|\bR-\d{3,}|\bN-0\d\d|\bP-0\d\d|\bT0\.\d|\bD-\d|\bE\d\.\d|\bPA-\d",
 "sigle du programme": r"\bG[0-2]\b|\bH\d\b|\bHC\d|\bbras A\b|\bC[1-3]\b|\bM3\b",
 "nom de personne ou de modèle": r"Lazar|Claude|Fable|Opus|Sonnet|Haiku|Mythos|Carbon|Neon|Astra|Gemini|GPT|OpenAI|Anthropic|Llama|Qwen",
 "mot du programme": r"collisionneur|adjudant|organisme d.idéation|session_|\blot/|session mère|protocole X|dopamine|barreau|\bpince\b|\bétau\b|compte-4",
}
def garde(texte):
    return sorted({nom for nom, m in MOTIFS.items() if re.search(m, texte)})
if __name__ == "__main__":
    for f in sys.argv[1:]:
        print(f.split('/')[-1], "->", garde(open(f, encoding="utf-8").read()))
