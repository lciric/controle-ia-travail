src = "/home/user/controle-ia-travail/prereg/SPARKS-EXP7-NUL-preenregistrement-v2-brouillon2.md"
dst = src.replace("brouillon2.md", "brouillon3.md")
t = open(src, encoding="utf-8").read()
def rep(old, new):
    global t
    n = t.count(old)
    assert n == 1, (old[:70], n)
    t = t.replace(old, new)
REC = "*Recommandation de Fable, relecture du 21 novembre* : "

# Correction 1 : « Seuil », marque
rep("Elle ne change aucun verdict ; elle borne ce que la scission montre (section « Critères de lecture gelés »).",
    "Elle ne fait passer aucun verdict d'une ligne à une autre ; posée, elle entre dans le nom du verdict des lignes 1 et 2 et dans leur parenthèse de Q1, avec « scission non probante » ; elle borne ce que la scission montre (section « Critères de lecture gelés »).")
rep("| « Critères de lecture gelés », table de la lecture principale, lignes 1 et 2 |",
    "| « Critères de lecture gelés », table de la lecture principale, lignes 1 et 2 ; « Seuil », marque |")

# Correction 2, m-12
rep("Les quatre décisions prises par conv-audit, et non par Lazar, sur les options de la contre-lecture de l'addendum (ad1, l. 17) sont gardées : la base",
    "Les quatre décisions prises sur l'addendum, par conv-audit et non par Lazar (ad1, l. 17), sont gardées : la base")
# Correction 2, m-13 (trois lieux)
rep("Sur les mêmes 16 textes, tirés de gabarits de faits **absents de tous les partages** (v1, l. 70) : pour chaque tête,",
    "Sur les mêmes 16 textes, tirés de faits **absents de tous les partages** (v1, l. 70) : pour chaque tête,")
rep("aucun entraînement n'a eu lieu ; tirés de gabarits de faits absents de tous les partages (v1, l. 70) : c'est leur raison d'être",
    "aucun entraînement n'a eu lieu ; tirés de faits absents de tous les partages (v1, l. 70) : c'est leur raison d'être")
rep("| Les seize textes sont dits tirés de gabarits de faits absents de tous les partages (v1, l. 70) |",
    "| Les seize textes sont dits tirés de faits absents de tous les partages (v1, l. 70) |")
# Correction 2, m-7 (deux lieux)
rep("| à mesurer sur les pilotes | p3, l. 108 ; p3, l. 42 (4 tentatives sur 3 paires sans l'outil) |",
    "| à mesurer sur les pilotes | p3, l. 108 |")
rep("dont 12 sans l'outil d'attention (p3, l. 108 et l. 42) |",
    "dont 12 sans l'outil d'attention (p3, l. 108) |")

# Correction 3 : trois lignes sous « Nœuds ouverts par la correction », avec les recommandations de Fable
old_nr = "Choix de conception, au rédacteur ou à Lazar.\n"
new_nr = old_nr + (
"  - " + REC + "les relances ne comptent pas ; elles sont comptées et rapportées à part. Confiance 0,7. La ligne vise les conversations dont l'issue est un échec imputé. Une relance qui aboutit donne une réponse valide ; une seconde interruption devient « coupée » par (iii) et compte déjà. Je changerais d'avis si la liste des signaux (i), une fois écrite, ne séparait pas nettement panne et coupure du fournisseur. (Le nœud reste ouvert.)\n"
"  - " + REC + "dénominateur 48, numérateur et dénominateur sur le bras principal, l'ancre comptée à part. Confiance 0,6. La ligne marque « non concluant » la lecture principale, qui porte sur ces 48 cas ; l'ancre est lue après, sous une autre consigne. Avec 48, la ligne sonne à la cinquième conversation comptée (5/48 = 0,104) ; avec 51, à la sixième (5/51 = 0,098). À vérifier avant de choisir : ce que compte la source (v1, l. 172). (Le nœud reste ouvert.)\n")
rep(old_nr, new_nr)
old_l63 = "- Les huit marqueurs du brouillon 1 restent ouverts : aucune remarque ne les ferme.\n"
new_l63 = old_l63 + (
"- **C-3 et la raison « économie de Fable »** (m-1). La remarque nomme C-3 et ne donne de texte que pour le nœud 1, option (d). La raison de C-3 reste telle quelle. Au rédacteur.\n"
"  - " + REC + "borner la raison à ce que dit la règle, qui réserve Fable 5.2. Confiance 0,7. (Le nœud reste ouvert.)\n"
"- **« Par lecteur » et générateur de la marque** (m-10). L'addendum avait deux lecteurs, ce texte un : « par lecteur » est rendu par le second lecteur, s'il est accordé ; c'est une lecture du correcteur. La remarque donne `dispersion-reechantillonnage` avec un point d'interrogation ; il est nommé ici. Les deux sont à confirmer par le rédacteur.\n"
"  - " + REC + "« par lecteur » : garder la lecture du correcteur. Confiance 0,7. Générateur de la marque : garder `dispersion-reechantillonnage` ; c'est le même intervalle que celui de la dispersion entre graines. Confiance 0,85. (Le nœud reste ouvert.)\n"
"- **Qui vérifie les corrections.** C-2 et l'étape (1) de l'ordre de scellement disent : le même contre-lecteur. GO-2026-11-21-84 dit : Fable 5.2 par l'API. Aucune remarque ne vise ces lignes ; elles restent telles quelles. Au rédacteur ou à Lazar.\n"
"  - " + REC + "garder la vérification par le contre-lecteur, au moins pour ce que je n'ai pas pu confronter aux sources. Confiance 0,75. (Le nœud reste ouvert.)\n")
rep(old_l63, new_l63)

# Recommandations de Fable sur les nœuds pour Lazar 1, 5, 7 (nœuds laissés ouverts)
rep("Recommandation : (a), et (b) si tu veux que la mesure tranche ; confiance 0,6. Pas de défaut.\n",
    "Recommandation : (a), et (b) si tu veux que la mesure tranche ; confiance 0,6. Pas de défaut. " + REC + "celle du rédacteur, (a) par défaut, (b) si Lazar veut un verdict qui tranche. Confiance 0,6. Les corrections m-1 et m-2 ne changent pas la balance : (c) ne se chiffre pas tant que le modèle n'est pas nommé, (d) attend le mot de Lazar sur le quota, et aucune des deux n'ajoute de puissance. (Le nœud reste ouvert.)\n")
rep("Recommandation : (a) ; confiance 0,75. Défaut sous 48 heures : (a).\n6. **Modèle de secours.**",
    "Recommandation : (a) ; confiance 0,75. Défaut sous 48 heures : (a). " + REC + "(a). Confiance 0,65, contre 0,75 pour le rédacteur. Je baisse parce que le rédacteur donne 0,6 à la marque posée (P13). Dans ce monde, (a) rend un verdict « scission non probante » : elle nomme le défaut, elle ne l'ôte pas. L'option (d) est la seule qui vise la cause. Mais rien ici ne montre que des paires nulles à données permutées égalisent l'ampleur, et elle change la fabrication. Je ne l'examinerais que si l'étalonnage montre une séparation et si Lazar veut une scission probante. Pour le rédacteur : la marque ne lit que l'aire « vraie contre nulle ». Si les types se rangent « deux sycophantes, puis vraie, puis deux honnêtes », cette aire reste près de 0,5 alors que les types se séparent. C'est possible si les sycophantes bougent peu du départ, comme P8 le prédit. (Le nœud reste ouvert.)\n6. **Modèle de secours.**")
rep("Recommandation : (c), si un entraînement jouet chronométré, sans dépense, confirme ce repère ; confiance 0,6. Pas de défaut.\n",
    "Recommandation : (c), si un entraînement jouet chronométré, sans dépense, confirme ce repère ; confiance 0,6. Pas de défaut. " + REC + "option (c), touchée par m-3 : la correction lui retire un appui : la suite n'est pas montrée verte sur une telle machine. La recommandation (c) tient encore, un peu moins fort. Confiance 0,55. (Le nœud reste ouvert.)\n")

# Tenue de version
rep("# Préenregistrement — SPARKS-EXP7-NUL — l'expérience 7 du billet « Sparks » sous paires nulles et aveuglement — v2, brouillon 2\n",
    "# Préenregistrement — SPARKS-EXP7-NUL — l'expérience 7 du billet « Sparks » sous paires nulles et aveuglement — v2, brouillon 3\n")
rep("**Statut : brouillon 2 du texte neuf, contre-lu une fois (« à corriger »), corrections portées, non relues, non scellable en l'état** (huit marqueurs ouverts du brouillon 1, un marqueur neuf pour un nœud ouvert par la correction, douze nœuds pour Lazar). Le brouillon 1 reste intact (R12).",
    "**Statut : brouillon 3 du texte neuf, contre-lu une fois (« à corriger »), corrections portées, relues par Fable 5.2 appelé par l'API (« à corriger »), corrections de la relecture portées, non revues, non scellable en l'état** (huit marqueurs ouverts du brouillon 1, un marqueur neuf pour un nœud ouvert par la correction, douze nœuds pour Lazar, trois nœuds ouverts de plus inscrits sur la relecture). Les brouillons 1 et 2 restent intacts (R12).")
rep("les choix que la contre-lecture laisse ouverts sont écrits en nœuds ouverts, non tranchés.\n",
    "les choix que la contre-lecture laisse ouverts sont écrits en nœuds ouverts, non tranchés.\n"
    "- **Correcteur du brouillon 3** : Claude Opus 5.5, effort maximal, même règle (GO-2026-11-21-84). Corrections écrites le 21 novembre 2026 vers 22:13 UTC (`date -u`), dépôt à `e17987e11`. Brouillon relu : `prereg/SPARKS-EXP7-NUL-preenregistrement-v2-brouillon2.md`, `6b09ce3852a8abc12a269d12b18b641c4e92c47d1b443d7a7a0eb8d34b0851d7` (empreinte vérifiée). Relecture portée : Claude Fable 5.2 par appel direct à l'interface d'Anthropic, `docs/notes/relecture-fable-api-v1/relectures/2-sparks-exp7-nul/relecture-fable-api.md`, `5d8e0ab391a213144750a94609eb0e1d399399e873290fc24b0351a8b08e127c` (empreinte vérifiée ; message `msg_011ChGngLtXXHgVnRNu1PZR3`), verdict « à corriger ». Fable a relu une copie nettoyée du brouillon 2 (`35e432ce…`) ; ses corrections sont portées dans la pièce d'origine, avec ses noms d'origine. Rien n'est changé hors de la table « Corrections du brouillon 3 » ; les recommandations de Fable sur les nœuds ouverts sont recopiées dans ces nœuds, qui restent ouverts.\n")
table3 = """## Corrections du brouillon 3

Chaque correction de la relecture de Fable 5.2 (`5d8e0ab3…`, section « Corrections, avec leur texte »), au texte exact qu'elle donne, et rien d'autre. Correcteur : Claude Opus 5.5 (GO-2026-11-21-84).

| correction de Fable | lieu | fait |
|---|---|---|
| 1. « Seuil », marque (suite de I-1 a) : remplacer « Elle ne change aucun verdict ; elle borne ce que la scission montre (section « Critères de lecture gelés »). » par « Elle ne fait passer aucun verdict d'une ligne à une autre ; posée, elle entre dans le nom du verdict des lignes 1 et 2 et dans leur parenthèse de Q1, avec « scission non probante » ; elle borne ce que la scission montre (section « Critères de lecture gelés »). » | « Seuil », marque « types de paires séparables par l'ampleur » | fait |
| 1 (suite). Table des corrections, ligne I-1 (a), colonne « Lieu » : ajouter « ; « Seuil », marque » | « Corrections du brouillon 2 », ligne I-1 (a) | fait |
| 2. m-12, ramené à la lettre de la remarque : « Les quatre décisions prises sur l'addendum, par conv-audit et non par Lazar (ad1, l. 17), sont gardées : la base … » | « Ce que ce texte change », en tête | fait (« le directeur » de la copie nettoyée rendu par « Lazar ») ; la clause de Fable « si le contre-lecteur les confirme sur la source, les garder » n'est pas exercée : aucune confirmation reçue |
| 2. m-13, « gabarits de » retiré, trois lieux | « Bases mécaniques et plafond », base d'attention scriptée ; « Plan expérimental », table du réemploi ; « Corrections du brouillon 2 », ligne m-13 | fait, aux trois lieux ; même réserve sur la clause de confirmation |
| 2. m-7, source ramenée à « p3, l. 108 » : colonne « Source » ; table des corrections « … dont 12 sans l'outil d'attention (p3, l. 108) » | « Esquisse de devis », jetons de sortie ; « Corrections du brouillon 2 », ligne m-7 | fait, aux deux lieux ; même réserve sur la clause de confirmation |
| 3. Trois lignes sous « Nœuds ouverts par la correction, non tranchés par le correcteur » : C-3 et la raison « économie de Fable » ; « par lecteur » et générateur de la marque ; qui vérifie les corrections | « Corrections du brouillon 2 », nœuds ouverts par la correction | fait (« au directeur » de la copie nettoyée rendu par « à Lazar ») ; nœuds laissés ouverts |
| 4. Facultatif : sous « mes calculs », dire qui a écrit la version 2 du script | en-tête, « mes calculs » | non porté : facultatif, et le texte donné s'arrête sur « … » ; laissé au choix de la mère |
| Recommandations de Fable sur les nœuds ouverts : relances et ligne des 10 % (deux points), nœud 1, nœud 5, nœud 7 option (c), et les trois nœuds de la correction 3 | à chaque nœud | recopiées, marquées « recommandation de Fable, relecture du 21 novembre », confiance comprise ; aucun nœud tranché |
| (inscription) Relecture de Fable inscrite | en-tête ; « Contre-lecture » ; pied | fait, tenue de version |

Non porté, hors des corrections : la section « Vu en passant, hors de la correction » de la relecture (ordre d'emploi des intervalles de `dispersion-reechantillonnage` ; page de Goworek et al., 14 ou 13 ; deux « [P] » de la contre-lecture, § 5, point 3), au rédacteur.

"""
rep("## Corrections du brouillon 2\n\nChaque remarque", table3 + "## Corrections du brouillon 2\n\nChaque remarque")
rep("la contre-lecture dit que la vérification des corrections revient au même contre-lecteur.\n",
    "la contre-lecture dit que la vérification des corrections revient au même contre-lecteur.\n"
    "- **Relecture des corrections 1** : Claude Fable 5.2 appelé par l'API (GO-2026-11-21-84), sur une copie nettoyée du brouillon 2 ; rapport `docs/notes/relecture-fable-api-v1/relectures/2-sparks-exp7-nul/relecture-fable-api.md`, sha256 `5d8e0ab391a213144750a94609eb0e1d399399e873290fc24b0351a8b08e127c` ; verdict « à corriger » : trois corrections et une facultative ; corrections portées dans ce brouillon 3 par Claude Opus 5.5, correcteur (table « Corrections du brouillon 3 »), la facultative exceptée.\n")
assert t.endswith("c'est voulu.\n") or t.endswith("c'est voulu.")
t = t.rstrip("\n") + "\nBrouillon 3 (21 novembre 2026) : corrections de la relecture de Fable 5.2 par l'API (`5d8e0ab3…`) portées par Claude Opus 5.5, correcteur (GO-2026-11-21-84), sans autre changement ; recommandations de Fable recopiées dans les nœuds, aucun tranché ; scellé par son compagnon d'empreinte comme brouillon ; non conforme au validateur tant que des marqueurs restent ouverts : c'est voulu.\n"
open(dst, "w", encoding="utf-8").write(t)
print("écrit", dst)
