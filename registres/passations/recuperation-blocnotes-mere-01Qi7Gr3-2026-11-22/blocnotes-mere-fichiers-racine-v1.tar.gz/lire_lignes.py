#!/usr/bin/env python3
"""Affiche des lignes nommées d'un fichier, en masquant toute ligne qui porte un motif interdit par le mandat.
Usage : lire_lignes.py FICHIER 664 667 670-671   (lecture sur disque)
        ... | lire_lignes.py - 12 40-45           (lecture sur l'entrée standard)
Option --mot MOT : pour une ligne masquée, n'afficher qu'une fenêtre de 160 signes autour de MOT, si la fenêtre est propre.
Option --max N : tronque l'affichage de chaque ligne à N signes."""
import re
import sys

INTERDIT = re.compile(
    r"consigne[- ]priv|conception-ii-b|ii-b|saboteur-budget|saboteur à budget|lot/compte-4|R-2059|archives-reponses-modeles"
    r"|\b7a\b|\b7b\b|T0\.6|étape B\b|\bB bis\b|B-bis|P3-bis|P3 bis|barreau[ -]?5",
    re.IGNORECASE,
)


def main():
    args = sys.argv[1:]
    mot, maxi = None, None
    while "--mot" in args:
        i = args.index("--mot")
        mot = args[i + 1]
        del args[i:i + 2]
    while "--max" in args:
        i = args.index("--max")
        maxi = int(args[i + 1])
        del args[i:i + 2]
    chemin, specs = args[0], args[1:]
    if chemin == "-":
        lignes = sys.stdin.read().split("\n")
    else:
        with open(chemin, encoding="utf-8") as f:
            lignes = f.read().split("\n")
    voulues = []
    for s in specs:
        if "-" in s:
            a, b = s.split("-")
            voulues.extend(range(int(a), int(b) + 1))
        else:
            voulues.append(int(s))
    for n in voulues:
        if n < 1 or n > len(lignes):
            print(f"{n}: [hors du fichier, {len(lignes)} lignes]")
            continue
        t = lignes[n - 1]
        if INTERDIT.search(t):
            if mot:
                sorties = []
                for m in re.finditer(re.escape(mot), t, re.IGNORECASE):
                    fen = t[max(0, m.start() - 80):m.end() + 80]
                    if not INTERDIT.search(fen):
                        sorties.append("…" + fen + "…")
                if sorties:
                    print(f"{n}: [ligne masquée, fenêtres propres autour de « {mot} »] " + " || ".join(sorties))
                    continue
            print(f"{n}: [ligne masquée : motif interdit par le mandat, {len(t)} signes]")
            continue
        if maxi and len(t) > maxi:
            t = t[:maxi] + f" […tronquée, {len(t)} signes]"
        print(f"{n}: {t}")


if __name__ == "__main__":
    main()
