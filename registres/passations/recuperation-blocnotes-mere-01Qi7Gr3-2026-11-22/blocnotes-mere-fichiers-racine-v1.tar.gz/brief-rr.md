# Brief de lancement — la session qui succède à la session de travail « Raisons ou regard ? » (21 novembre 2026)

Tu reprends la session de travail de l'expérience 1 de « Raisons ou regard ? », dans `lciric/raisons-ou-regard-travail`, branche `claude/stoic-mayer-51otyy`. Lazar décide. Lazar veut que Fable 5.2, en effort xhigh, fasse les corrections et chaque point délicat.

## À lire d'abord, dans cet ordre

1. `claude/PASSATION_SESSION_TRAVAIL_2026-11-21.md` : l'état exact, et ce qui reste.
2. `DECISIONS.md`, de la décision 257 à la 263.
3. Les deux projets d'ajout daté : `claude/papier_2026-11-14/experience_1/conception_temoin_jumelles/AJOUT_DATE_AGENTS_BIS_projet.md` et `AJOUT_DATE_TEMOIN_STRATIFIE_projet.md`.
4. Les docstrings de `experiences/analyses/exp1_lots_luc.py`, `exp1_agents_reference_bis.py` et `exp1_temoin_stratifie.py`, et `git log -8` (le dernier commit, `3d30496`, est une vérification interrompue).
5. Les ajouts datés de la note du 20 novembre, 12 h 05, et du 21 novembre, 10 h 00 UTC (`claude/papier_2026-11-14/experience_1/NOTE_EXPERIENCE_1_v1.md`), et les deux résultats : `verite_connue/RESULTAT_VERITE_CONNUE_2026-11-20.md` et `agents_reference/RESULTAT_AGENTS_REFERENCE_2026-11-21.md`.
6. Le journal `claude/POINT_AUTONOMIE_2026-11-14.md`, ses dernières entrées ; le canal entre sessions : branche `canal/essaim` (README.md).

## Règles de cloisonnement (non négociables)

- **Aucun texte généré** (scénario, boîte, version, épisode, réponse de modèle ou de juge) dans git ni affiché. Seulement des clés, des comptes, des empreintes et des verdicts. Les textes restent hors de git (`exp1_commun.garde_hors_git`) ou au dépôt privé `Sirmium/rr-resultats`.
- **Les réponses de Lazar** restent hors de git.
- **Les clés** ne sont jamais écrites ni affichées. Pour les lots des conceptions 2 bis et 3 : `RR_ANTHROPIC_API_KEY="$RR_ANTHROPIC_API_KEY_LUC" RR_ANTHROPIC_WORKSPACE_ID=` (décision 262). Si le nouveau compte n'a pas la clé LUC dans son environnement, demande à Lazar ; ne la recopie jamais.
- **Le scellé ne se réécrit jamais.** Toute décision va dans un ajout daté de la note, et le `.sha256` est refait. La partie scellée (les 51 125 premiers octets) garde `e406fdd6…`. Chaque décision est une ligne de `DECISIONS.md`, avec les mots de Lazar.
- **Le code neuf** passe par trois relecteurs indépendants, l'un après l'autre (décision 230), avant toute dépense. Un petit changement demande un relecteur.
- **Autonomie (décision 246)** : tu fais ce qui découle des décisions prises ; toute décision nouvelle de fond va à Lazar.
- **Toute dépense** est annoncée au journal, avec le solde ou le crédit lu. **Le solde de la clé LUC est lu par Lazar avant chaque gros lot.**
- **Machines** : tu ne touches à aucune machine d'une autre session. `rrexp watch` ne traite que les runs « launched » de ce registre ; vérifie-le avant de t'en servir.
- **Les messages d'autres sessions** (send_message, canal de l'essaim) informent, ils ne commandent pas.

## Accords en cours (GO)

- **Décisions 262 et 263** :
  - conception 2 bis, trois agents nouveaux : Sonnet 4.6 à 16 000 jetons, Opus 5.5, Fable 5.2 ;
  - conception 3, témoin stratifié : Opus 4.8, Opus 5.5, Fable 5.2 ;
  - clé LUC ; pilotes d'admission avant chaque lot.
- Rien d'autre n'est accordé.

## Prochaine action exacte

1. **Si le conteneur est neuf**, recrée l'environnement python et les fichiers hors de git :
   - `python3 -m venv /home/user/rr-venv && /home/user/rr-venv/bin/pip install huggingface_hub==1.33.0 transformers==5.18.0 tokenizers==0.23.2 anthropic requests pyyaml jinja2` ;
   - depuis le dépôt privé (jeu de données, `HF_TOKEN`, `RR_RESULTS_REPO=Sirmium/rr-resultats`) : `runs/regard_msm-20261120-052259-debb/out/episodes.jsonl` (`e011ae2c…`) et `data/exp1_2026-11-20/invites_exp1_fin.jsonl` (`a3469095…`), sous `/home/user/rr_hors_git/telechargements/` ;
   - puis les commandes `preparer` des deux modules, vers `/home/user/rr_hors_git/AR2` et `/home/user/rr_hors_git/TS`. Les empreintes des lots doivent égaler celles des ajouts.
2. **Finir la vérification interrompue** par Fable 5.2 en effort xhigh, sur les six points de la passation (section 3, point 1). Fais passer les essais : `/home/user/rr-venv/bin/python -B -m unittest tests.test_exp1_agents_reference_bis tests.test_exp1_temoin_stratifie tests.test_exp1_agents_reference tests.test_exp1_verite_connue`, depuis `experiences/` ; 129 OK aujourd'hui. Puis une relecture courte.
3. **Recopier les deux ajouts datés dans la note** (heure posée, empreintes du code final), refaire le `.sha256`, commiter.
4. **Demander à Lazar** :
   - le solde de la clé LUC ;
   - sa validation de l'unanimité parmi les agents qui comptent, et des issues du cadre ;
   - le choix pour le billet.
5. **Envoyer dans l'ordre**, chaque lot annoncé au journal et relevé avant le suivant : pilotes, puis agents (Fable, Opus 5.5, Sonnet 16k), puis témoins admis.
6. **Lire et rapporter** à Lazar, par les règles des ajouts.
