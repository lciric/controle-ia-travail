import sys,re
txt=open(sys.argv[1],encoding='utf-8',errors='replace').read()
pages=txt.split('\f')
for pat in sys.argv[2:]:
    rx=re.compile(pat, re.I|re.S)
    hits=[]
    for i,p in enumerate(pages,1):
        q=re.sub(r'\s+',' ',p)
        for m in rx.finditer(q):
            hits.append((i,q[max(0,m.start()-150):m.end()+150]))
    print('==',pat,'->',len(hits))
    for i,s in hits[:4]: print('  p',i,':',s)
