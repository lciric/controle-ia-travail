import json, sys
seuil = sys.argv[1]
reel = {"gemini-4-argon": (2.0, 10.0), "gemini-4-carbon": (2.0, 10.0)}
tot_c = tot_r = 0.0
for chemin in sys.argv[2:]:
    for l in open(chemin, encoding="utf-8"):
        l = l.strip()
        if not l: continue
        e = json.loads(l)
        if "essai" not in e or e.get("modele_demande") not in reel: continue
        if e.get("debut", "") < seuil: continue
        u = e.get("usage") or {}
        pin, pout = reel[e["modele_demande"]]
        r = (u.get("entree", 0) or 0) / 1e6 * pin + (u.get("sortie", 0) or 0) / 1e6 * pout
        tot_c += e.get("cout_usd", 0); tot_r += r
        print(f"{chemin.split('/')[-2][:40]:<40} {e['cellule']:<28} {e['modele_demande']:<16} {e['statut']:<24} compte={e.get('cout_usd'):.3f} reel_std={r:.3f}")
print(f"TOTAL depuis {seuil}: compté={tot_c:.2f} USD, réel au barème standard 2/10={tot_r:.2f} USD")
