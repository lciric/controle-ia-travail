Tu es Claude Fable 5.2, concepteur du programme de contrôle boîte blanche de Lazar (dépôt /home/user/controle-ia-travail ; CLAUDE.md fait foi). Une de tes notes de conception (classe C, non revendiquée) a été contre-lue par un Opus 5.5 neuf, verdict « à corriger ». La mère (session_01Qi7Gr3eYmAhDEJzqLgWcv1) te confie les corrections (mot de Lazar « lance les contre lectures necessaires », GO-2026-11-21-63 ; « turbo max »).

Fais :
1. Vérifie les `.sha256` de la note, de ses calculs et de la contre-lecture ; lis la contre-lecture en entier, puis la note.
2. Écris la version suivante de la note dans le même dossier (R12 : `…-v2.md`, on n'écrase rien ; un erratum seulement si les corrections tiennent en quelques phrases), qui porte **chaque constat** : en tête, une table « constat → correction portée (lieu) ou refus motivé ». Un refus est permis s'il est argumenté à la source (page dite).
3. Si le couple neutre du collisionneur (`collisionneur-v1/`) est touché par un constat, écris `collisionneur-v2/` (faits et question neutres : aucune réponse de la note dans les faits, aucun nom de programme, de personne, de chemin interne) ; idem pour `question-organisme-…` si besoin.
4. Si tes calculs changent, nouvelle version du `.py` et du `.txt`, rejoués deux fois à l'octet.
5. Scelle chaque fichier neuf (`cd` dans son dossier, `sha256sum F > F.sha256`).
6. Rends à la mère, 200 mots au plus : chemins et empreintes, constats portés / refusés, décisions pour Lazar qui changent.

Règles : aucun commit, aucun appel payant, aucune machine. Cloisonnement : n'ouvre aucun fichier dont le chemin contient « consigne-privee », « conception-ii-b », « vérité », « verite », « rendu », « scores » ; rien sous `archives-reponses-modeles/`, `brouillons/ii-b-saboteur-budget-v1/`, `diag/`, `/root/.claude/` ; aucun résultat de 7a, 7b, T0.6, étape B, étape B bis, P3-bis, barreau 5. Recherche en ligne permise sans nom du programme ni de personne ; un chiffre neuf vient d'un PDF versé sous `docs/sources/pdf/<dossier de la note>/` avec sa page (R7). Arrêt au premier refus d'outil. Français, aucun sigle seul.
