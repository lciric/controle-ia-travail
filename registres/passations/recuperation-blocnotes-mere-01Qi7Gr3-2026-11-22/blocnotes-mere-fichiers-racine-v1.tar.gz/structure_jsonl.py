"""Affiche la seule structure d'un fichier de lignes JSON : nombre de lignes, noms des champs, types et longueurs.
Aucune valeur n'est affichée."""
import json, sys, collections

def decrire(v, prof=0):
    if isinstance(v, dict):
        return "objet{" + ",".join(sorted(v.keys())) + "}" if prof == 0 else "objet(%d champs)" % len(v)
    if isinstance(v, list):
        t = collections.Counter(type(x).__name__ for x in v)
        return "liste(%d ; %s)" % (len(v), ",".join("%s×%d" % kv for kv in sorted(t.items())))
    if isinstance(v, str):
        return "texte(%d signes)" % len(v)
    return type(v).__name__

for chemin in sys.argv[1:]:
    n = 0
    champs = collections.OrderedDict()
    with open(chemin, encoding="utf-8") as f:
        for ligne in f:
            ligne = ligne.strip()
            if not ligne:
                continue
            n += 1
            d = json.loads(ligne)
            if not isinstance(d, dict):
                champs.setdefault("(ligne non objet)", []).append(type(d).__name__)
                continue
            for k, v in d.items():
                champs.setdefault(k, []).append(decrire(v))
    print("==", chemin, ":", n, "lignes")
    for k, vs in champs.items():
        ex = collections.Counter(vs).most_common(3)
        print("   champ", repr(k), "présent", len(vs), "fois ; formes :", "; ".join("%s ×%d" % e for e in ex))
