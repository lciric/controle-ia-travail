#!/usr/bin/env python3
"""Cherche une expression dans un fichier nommé et n'affiche, par occurrence, qu'une fenêtre autour d'elle,
seulement si la fenêtre ne porte aucun motif interdit par le mandat.
Usage : chercher.py FICHIER EXPRESSION [--fenetre N] [--depuis LIGNE] [--jusqu LIGNE] [--limite N]"""
import re
import sys

INTERDIT = re.compile(
    r"consigne[- ]priv|conception-ii-b|ii-b|saboteur-budget|saboteur à budget|lot/compte-4|R-2059|archives-reponses-modeles"
    r"|\b7a\b|\b7b\b|T0\.6|étape B\b|\bB bis\b|B-bis|P3-bis|P3 bis|barreau[ -]?5",
    re.IGNORECASE,
)


def main():
    args = sys.argv[1:]
    opts = {"--fenetre": 140, "--depuis": 1, "--jusqu": 10**9, "--limite": 60}
    for o in list(opts):
        while o in args:
            i = args.index(o)
            opts[o] = int(args[i + 1])
            del args[i:i + 2]
    chemin, expr = args[0], args[1]
    if chemin == "-":
        lignes = sys.stdin.read().split("\n")
    else:
        with open(chemin, encoding="utf-8") as f:
            lignes = f.read().split("\n")
    motif = re.compile(expr, re.IGNORECASE)
    vus = masques = 0
    for n, t in enumerate(lignes, 1):
        if n < opts["--depuis"] or n > opts["--jusqu"]:
            continue
        for m in motif.finditer(t):
            fen = t[max(0, m.start() - opts["--fenetre"]):m.end() + opts["--fenetre"]]
            if INTERDIT.search(fen):
                masques += 1
                continue
            vus += 1
            if vus <= opts["--limite"]:
                print(f"{n}: …{fen}…")
    print(f"[{vus} fenêtres propres, {masques} masquées ; {len(lignes)} lignes au fichier]")


if __name__ == "__main__":
    main()
