N=docs/notes/organisme-noeuds-2026-11-21-v1/reponses-fable-noeuds-organisme-v2.md
D=/tmp/claude-0/-home-user-controle-ia-travail/2eb82089-3810-5ff8-881f-da5f24b622eb/scratchpad/essai-scellement-17
( cd docs/notes/organisme-noeuds-2026-11-21-v1 && sha256sum -c reponses-fable-noeuds-organisme-v2.md.sha256 )
H=$(date -u +%Y-%m-%dT%H:%M:%SZ) ; E=$(sha256sum "$N" | cut -d' ' -f1)
sed -n '138,176p' "$N" | sed "s/@HEURE@/$H/; s/@EMPREINTE-DE-LA-NOTE@/$E/" > "$D/controle-lancement-palier-0b-par-la-mere-v1-complement-1-v3.md"
sed -n '188,235p' "$N" | sed "s/@HEURE@/$H/; s/@EMPREINTE-DE-LA-NOTE@/$E/" > "$D/controle-lancement-palier-0b-par-la-mere-v1-complement-1-v4.md"
sed -n '241,288p' "$N" | sed "s/@HEURE@/$H/; s/@EMPREINTE-DE-LA-NOTE@/$E/" > "$D/controle-lancement-palier-0b-par-la-mere-v1-complement-1-v5.md"
grep -c '@' "$D"/controle-lancement-palier-0b-par-la-mere-v1-complement-1-v[345].md
( cd "$D" && for f in controle-lancement-palier-0b-par-la-mere-v1-complement-1-v[345].md ; do sha256sum "$f" > "$f.sha256" ; done )
