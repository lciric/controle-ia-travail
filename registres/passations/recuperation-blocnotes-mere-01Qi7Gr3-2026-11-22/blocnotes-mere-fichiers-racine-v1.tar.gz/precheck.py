import sys, json
sys.path.insert(0, "src")
from controle_ia.relecture_fable_api_v2 import lire_entree, composer_invite, garde_motifs
E = "docs/notes/relecture-fable-api-v1/envois"
for d in ["1-generations-collisionneur","2-sparks-exp7-nul","3-additif-sondes-barreau8","5-prevision-reference-honnete"]:
    lignes = open(f"{E}/{d}/consigne-relecture-v1.md", encoding="utf-8").read().split("\n")
    rows = [l.split("|") for l in lignes if l.startswith("| correction") or l.startswith("| remarques") or l.startswith("| avant")]
    order = {"correction":0,"remarques":1,"avant":2}
    rows.sort(key=lambda r: order[r[1].strip()])
    c = lire_entree("consigne", f"{E}/{d}/consigne-relecture-v1.md")
    ps = [lire_entree(r[1].strip(), f"{E}/{d}/{r[2].strip().strip('`')}") for r in rows]
    seg = composer_invite(c, ps)
    print(d, "garde:", garde_motifs(seg), "chars:", sum(len(t) for _,t in seg), [ (p.role,p.compagnon) for p in ps])
