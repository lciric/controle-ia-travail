import sys, shutil, subprocess, os
R = "/home/user/controle-ia-travail"; SP = sys.argv[1]
src = open(f"{R}/src/controle_ia/relecture_fable_api_v1.py", encoding="utf-8").read()
MUT = {
 "M0_temoin_sans_mutation": ('MODELE = "claude-fable-5-2"', 'MODELE = "claude-fable-5-2"'),
 "M1_nom_ciric_retire": ('NOMS_INTERDITS = ("lazar", "ciric")', 'NOMS_INTERDITS = ("lazar",)'),
 "M2_autre_raison_arret_admise": ('    elif res.raison_arret != "end_turn":\n        defaut = f"raison d\'arrêt inattendue : {res.raison_arret}"\n', ''),
 "M3_journal_apres_relecture": ('    ecrire_journal(journal, ligne)  # la dépense est consignée avant toute écriture de sortie\n    if ecrire_neuf(os.path.join(args.sortie, NOM_RELECTURE), contenu) != h_rel:\n',
                                '    _h = ecrire_neuf(os.path.join(args.sortie, NOM_RELECTURE), contenu)\n    ecrire_journal(journal, ligne)\n    if _h != h_rel:\n'),
 "M4_relances_2": ('api_key=cle, max_retries=0,', 'api_key=cle, max_retries=2,'),
 "M5_5xx_compte_zero": ('base = "pire" if (e.status_code >= 500 or etape == "flux") else "zero"', 'base = "zero"'),
 "M6_reflexion_resumee": ('REFLEXION = {"type": "adaptive", "display": "omitted"}', 'REFLEXION = {"type": "adaptive", "display": "summarized"}'),
 "M7_compagnon_ecrase_w": ('    with open(chemin + ".sha256", "w", encoding="utf-8") as f:', '    with open(chemin + ".sha256", "w", encoding="utf-8") as f:  # inchangé'),
}
for nom, (a, b) in MUT.items():
    assert src.count(a) == 1, nom
    d = f"{SP}/mut/{nom}"; shutil.rmtree(d, ignore_errors=True); os.makedirs(f"{d}/src/controle_ia")
    open(f"{d}/src/controle_ia/__init__.py", "w").close()
    open(f"{d}/src/controle_ia/relecture_fable_api_v1.py", "w", encoding="utf-8").write(src.replace(a, b))
    bt = f"{d}/bt"; os.makedirs(bt); os.makedirs(f"{d}/tests")
    shutil.copy(f"{R}/tests/test_relecture_fable_api_v1.py", f"{d}/tests/")
    open(f"{d}/pytest.ini","w").write("[pytest]\n")
    p = subprocess.run([f"{R}/.venv/bin/python", "-m", "pytest", "-q", f"{d}/tests/test_relecture_fable_api_v1.py", "--rootdir", d, "-c", f"{d}/pytest.ini",
                        "-p", "no:cacheprovider", f"--basetemp={bt}", "-q"], cwd=d,
                       env={"PYTHONPATH": f"{d}/src", "PATH": "/usr/bin:/bin", "HOME": d}, capture_output=True, text=True, timeout=300)
    last = [l for l in p.stdout.splitlines() if l.strip()][-1:]
    failed = [l for l in p.stdout.splitlines() if l.startswith("FAILED")]
    shutil.rmtree(bt, ignore_errors=True)
    print(nom, "TUÉE" if p.returncode else "SURVIT", last, failed[:2])
