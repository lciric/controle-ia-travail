## Corrections du brouillon 2

Chaque remarque de la contre-lecture d'Opus v1 (`e29fee75…`, sections 3 et 4 ; section 7 pour les nœuds 1 et 5), et rien d'autre. Correcteur : Claude Opus 5.5 (GO-2026-11-21-84). Lieu : section du présent texte.

| Remarque | Correction | Lieu |
|---|---|---|
| I-1 (a) | Marque « types de paires séparables par l'ampleur » posée : la phrase entre dans le nom du verdict des lignes 1 et 2, avec « scission non probante », et dans leur parenthèse de Q1 | « Critères de lecture gelés », table de la lecture principale, lignes 1 et 2 |
| I-1 (b) | Option (d) du texte v1 (l. 71) ajoutée au nœud 5 : paires nulles à données permutées, même graine et même ordre que la paire vraie, avec son coût ; recommandation inchangée | « Nœuds pour Lazar », nœud 5 |
| I-1 (c) | Résultat de l'étalonnage de l'ampleur « rapporté à Lazar, pour information, avant tout lecteur, sans rien suspendre » | « Liste d'arrêt », ligne de l'ampleur de l'écart |
| I-1 (d) | Réserve de calc, F reprise : les 12 paires de l'étalonnage partagent leurs modèles, 4 par groupe ; non indépendantes ; 0,107 est un ordre de grandeur, non un risque exact | « Bases mécaniques et plafond », ampleur de l'écart dans la paire |
| I-2 | Conventions numériques de la distance au départ reprises à la lettre de l'addendum (l. 650) : bf16 lus exactement en float32 ; couches bf16 de la recette sur l'étalonnage ; θ_0 arrondi en bf16 de la même façon, à consigner ; float64 | « Bases mécaniques et plafond », distance au départ |
| I-3 | Seuil de la base « normes sans départ » repris de l'addendum (l. 651), calculé avec o₄ ; orientation de l'étalonnage seul rapportée, descriptive | « Bases mécaniques et plafond », normes sans départ |
| I-4 (i) à (iii) | Liste des signaux de transport figée à l'ordre de course, appliquée par script ; seule la réponse relancée compte, trace interrompue gardée, comptée pour rien, non lue avant l'ouverture du coffre ; seconde interruption du même cas : « coupée », échec | « Lecteurs », conversation coupée |
| I-4 (iv) | **Nœud ouvert**, non tranché : les relances comptent-elles dans la ligne d'arrêt des 10 %, et dénominateur 51 ou 48 ; marqueur neuf | « Lecteurs », conversation coupée ; en-tête, marqueurs ouverts |
| I-5 | Taux d'erreur des seuils du contrôle causal à 24 unités (loi binomiale exacte, unités supposées indépendantes), table et lecture de la contre-lecture ; versés au bloc H du script, rejoué | « Seuil », contrôle causal ; `calculs-preenregistrement-v2-brouillon2-v1.py` et `.txt` |
| m-1 | Nœud 1, option (d) : « quota de Fable 5.1 : à dire par Lazar » | « Nœuds pour Lazar », nœud 1 |
| m-2 | Nœud 1, option (c) : « un autre modèle Claude hors Fable, à nommer par Lazar, identifiant vérifié avant le devis » | « Nœuds pour Lazar », nœud 1 |
| m-3 | Nœud 7, option (c) : « un environnement à processeur comme celui de la session ; suite à rejouer sur la machine » | « Nœuds pour Lazar », nœud 7 |
| m-4 | « xhigh » : nom d'un niveau du client des auteurs pour Astra ; « même nom de niveau que le billet ; équivalence non établie » | « Lecteurs », niveau d'effort ; « Ce que ce texte change », C-4 |
| m-5 | « Un réseau à la fois » retiré (option « retirer » de la remarque : aucune autre page lue par le correcteur) | « Hypothèse », voisins, Liu et Yang |
| m-6 | « Régime : réseaux convolutifs » ajouté, avec la citation de la page 1 | « Hypothèse », voisins, Balappanawar et al. |
| m-7 | Repère agrégé cité : environ 1,1 million de jetons de sortie pour les 15 conversations de l'expérience 7, dont 12 sans l'outil d'attention (p3, l. 108 et l. 42) | « Esquisse de devis », jetons de sortie |
| m-8 | Dit : les 75 h portent sur 2 016 mesures causales, dont 26 h de contrôle causal ; le plan en a 1 632 ; règle de trois, environ 21 h (calc, I, rejoué) | « Esquisse de devis », variante sans carte ; bloc I du script |
| m-9 | Lignes ajoutées : « révision de Gemma plus servie » (arrêt, nœud) ; « ampleur de l'écart » incalculable sur un cas servi | « Liste d'arrêt » |
| m-10 | Ordre d'emploi des générateurs des secondaires de l'incrément repris de l'addendum (l. 712), « par lecteur » rendu par le second lecteur s'il est accordé ; générateur de l'intervalle de la marque nommé : `dispersion-reechantillonnage` | « Graines et manifeste » |
| m-11 | Renvoi d'une ligne aux graines | « Plan d'analyse », en tête |
| m-12 | Les quatre décisions sur l'addendum sont dites de conv-audit, non de Lazar (ad1, l. 17) | « Ce que ce texte change », en tête |
| m-13 | Les seize textes sont dits tirés de gabarits de faits absents de tous les partages (v1, l. 70) | « Bases mécaniques et plafond », base d'attention scriptée ; « Plan expérimental », table du réemploi |
| (inscription) | Contre-lecture 1 inscrite, avec les deux empreintes ; brouillon 2 et correcteur dits en tête et au pied ; calculs du brouillon 2 cités | « Contre-lecture » ; en-tête ; pied |

**Nœuds ouverts par la correction, non tranchés par le correcteur.**
- **Relances et ligne d'arrêt des 10 %** (I-4, point iv ; `<<RELANCES_ET_DENOMINATEUR_DE_LA_LIGNE_DES_10_POURCENT>>`). Options que donne la contre-lecture : les conversations relancées comptent dans la ligne d'arrêt, ou non ; le dénominateur de cette ligne est 51 (avec l'ancre) ou 48 (bras principal). Choix de conception, au rédacteur ou à Lazar.
- **Nœud 5** et **nœud 1, option (d)** : complétés comme la contre-lecture le demande (section 7) ; ils restent à trancher par Lazar, recommandations du rédacteur inchangées.
- Les huit marqueurs du brouillon 1 restent ouverts : aucune remarque ne les ferme.
