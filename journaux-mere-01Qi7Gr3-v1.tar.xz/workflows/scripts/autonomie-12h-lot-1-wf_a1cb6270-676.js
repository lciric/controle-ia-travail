export const meta = {
  name: 'autonomie-12h-lot-1',
  description: 'Ligne au programme, couverture des tâches, pièces manquantes, inventaire, générations du collisionneur, blancs de la note, mandat de lecture B5',
  phases: [
    { title: 'Programme', detail: 'décision N-078 : priorité à la conception du produit' },
    { title: 'Couverture', detail: 'protocole par Fable, comptage par un agent habilité' },
    { title: 'Pieces', detail: 'recherche exhaustive puis brouillons Fable contre-lus' },
    { title: 'Inventaire', detail: 'erratum de la liste figée, contre-lu par Opus' },
    { title: 'Generations', detail: 'collisionneur jusqu au plateau' },
    { title: 'Blancs', detail: 'lecteur autorisé, note complète en PDF' },
    { title: 'Lecture B5', detail: 'mandat corrigé et vérifié' },
  ],
}
const R = '/home/user/controle-ia-travail'
const S = '/tmp/claude-0/-home-user-controle-ia-travail/2eb82089-3810-5ff8-881f-da5f24b622eb/scratchpad'
const COMMUN = `Règles : dépôt ${R} (PYTHONPATH=src ; CLAUDE.md fait foi). Ouvre chaque pièce par son chemin complet ; aucune commande de liste hors de ton dossier de sortie, sauf mention expresse. Arrête-toi au premier refus d'outil ou de classifieur et rends-le tel quel, sans contournement. Toute heure vient de \`date -u\`. Interdits : aucun fichier « consigne-privee » ni « conception-ii-b », rien sous brouillons/ii-b-saboteur-budget-v1/, ni la branche lot/compte-4-v1, ni la ligne R-2059 ; rien sous archives-reponses-modeles/ ; rien sous donnees/ ; aucun résultat de 7a, 7b, T0.6, étape B, B bis, P3-bis ; aucun score ni table du barreau 5 ; ni vérités ni rendus de l'épreuve à vérité plantée ; aucun fichier de scores par unité du bras A ; aucun fichier de l'organisme dont le nom porte « vérité », « rendu » ou « scores » ; rien sous /root/.claude/. Aucune commande rm sur un chemin construit par variable. Pas de commit ni de push. Français, aucun sigle seul. Tout chiffre de l'état de l'art renvoie à un PDF lu et une page, sinon « non vérifié ». Scelle chaque pièce par \`sha256sum F > F.sha256\` lancé dans son dossier. Dossier temporaire propre (\`--basetemp\` pour pytest).`
const OUT = {type:'object', properties:{pieces:{type:'array', items:{type:'object', properties:{chemin:{type:'string'}, empreinte:{type:'string'}}, required:['chemin','empreinte']}}, verdict:{type:'string'}, resume_en_clair:{type:'string'}, noeuds_pour_lazar:{type:'array', items:{type:'string'}}, refus:{type:'string'}}, required:['pieces','verdict','resume_en_clair','noeuds_pour_lazar','refus']}
const ok = v => v && /^conforme/i.test((v.verdict||'').trim())

// chaîne classe A : écrit (Fable) -> contre-lecture (Opus) -> correction (Fable) -> vérification (Opus)
async function chaine(nom, phase, ecrire, dossier, base) {
  const a = await agent(ecrire, {label:`${nom}:fable`, phase, schema:OUT, model:'fable', effort:'max'})
  if (!a) return null
  const c = await agent(`${COMMUN}\n\nTu es Claude Opus 5.5, contre-lecteur neuf (tu n'as rien écrit). Pièce(s) à contre-lire : ${a.pieces.map(p=>p.chemin).join(' ; ')} (vérifie les empreintes). Contexte : la demande de Lazar et les sources que la pièce cite ; ouvre chaque source citée et vérifie chaque citation, chiffre et chemin. Cherche erreurs, affirmations non sourcées, écarts aux décisions scellées (CLAUDE.md), cloisonnement violé, réponse qui ne répond pas à la demande. Écris ${dossier}/contre-lecture-${base}-opus-v1.md (verdict « conforme » ou « à corriger », liste numérotée), scelle, rends le schéma.`, {label:`${nom}:contre-lecture`, phase, schema:OUT, model:'opus', effort:'high'})
  if (!c || ok(c)) return {ecrit:a, contre_lecture:c}
  const f = await agent(`${COMMUN}\n\nTu es Claude Fable 5.2, effort maximal, auteur de ${a.pieces.map(p=>p.chemin).join(' ; ')}. Corrige selon ${dossier}/contre-lecture-${base}-opus-v1.md : écris des versions v2 (nouveaux noms, v1 intactes), avec en tête une table « remarque → correction ». Scelle, rends le schéma.`, {label:`${nom}:correction`, phase, schema:OUT, model:'fable', effort:'max'})
  const v = f && await agent(`${COMMUN}\n\nTu es Claude Opus 5.5, dans le rôle du contre-lecteur de ${dossier}/contre-lecture-${base}-opus-v1.md. Vérifie que les v2 (${f.pieces.map(p=>p.chemin).join(' ; ')}) corrigent chaque remarque sans en introduire. Écris ${dossier}/verification-corrections-${base}-opus-v1.md (verdict « conforme » ou « à corriger »), scelle, rends le schéma.`, {label:`${nom}:verification`, phase, schema:OUT, model:'opus', effort:'high'})
  return {ecrit:a, contre_lecture:c, correction:f, verification:v}
}

const SOURCE_PRODUIT = `${R}/docs/notes/mecanisme-adjudant-hors-distribution-v1/lecture-collisionneur-adjudant-opus-v1.md (lignes 15, 22, 31, 32, 54 à 62)`

// 1. Programme
const programme = chaine('programme', 'Programme', `${COMMUN}

Tu es Claude Fable 5.2, effort maximal. Lazar (21 novembre vers 17:30Z, GO-2026-11-21-69) dit, sur la lecture du collisionneur du mécanisme adjudant (${SOURCE_PRODUIT}) : « Ils déplacent la priorité vers la conception du produit. Une propriété est fixée d'avance par un tiers, puis vérifiée par programme, avec un repli quand elle échoue. : ok note le dans le prog ». Écris la décision N-078 qui transcrit ce mot (vérifie que le numéro est libre : \`git -C ${R} ls-files docs/decisions | grep N-078\` doit être vide ; sinon prends le suivant libre) dans ${R}/docs/decisions/decision-N-078-priorite-a-la-conception-du-produit-v1.md : mot de Lazar verbatim ; ce que la décision fixe (la conception du produit, propriété fixée d'avance par un tiers, vérifiée mécaniquement, repli quand elle échoue, comme voie de défense contre le diffus, à côté du plancher d'audit de N-075 et de la référence honnête de N-076, sans les remplacer) ; où cela se lit dans le programme (${R}/docs/programme-controle-ia-v2.md : sections touchées, sans le modifier) ; ce qu'elle ne change pas (aucune hypothèse revendiquée, aucune revendication nouvelle : une revendication demanderait un nœud) ; les deux écartés (repli sur le jumeau en service ; recalibration d'un moniteur sur les échecs du mode tenu à l'écart) avec leur raison, sourcée (N-054, N-060 v3 point 4) ; le premier geste sans dépense (compter sur des tâches archivées la part qui admet une telle propriété, « go ») ; l'antériorité à vérifier (conception sûre par construction, vérification formelle, tests de propriétés : chiffres non vérifiés) ; et une ligne proposée pour CLAUDE.md de 600 signes au plus, dans le style des autres lignes « N-0xx ». Scelle, rends le schéma.`, `${R}/docs/decisions`, 'decision-N-078')

// 2. Couverture
const couverture = (async () => {
  const D = `${R}/docs/notes/couverture-propriete-taches-v1`
  const p = await agent(`${COMMUN}

Tu es Claude Fable 5.2, effort maximal. Geste accordé par Lazar (GO-2026-11-21-69), sans dépense : « sur des tâches archivées, compter la part qui admet une propriété fixée d'avance par un tiers, vérifiable par programme ; si cette part est faible, mieux vaut le savoir avant de financer la suite ». Source : ${SOURCE_PRODUIT}. Écris le protocole de comptage (classe C, mais écrit avant tout comptage) dans ${D}/protocole-comptage-v1.md : définition opérationnelle de « propriété admise » (fixée avant la soumission par quelqu'un d'autre que l'agent, vérifiable mécaniquement sans juge ni modèle, qui borne un dommage nommé ; trois niveaux : entière, partielle, aucune), grille de codage avec exemples hors programme, liste des banques archivées à compter que tu trouves dans le dépôt (les tâches du banc des articles et de leur référence cachée ; les tâches de la banque du bras A si leur seul énoncé est lisible hors des fichiers interdits ; les tâches des environnements portés ; cherche par \`git -C ${R} ls-files | grep -i -E "taches|tasks|banque"\` puis ouvre seulement les énoncés, jamais une réponse, un score, une vérité ou un épisode saboté), hors du mode tenu à l'écart, taille du résidu, double codage d'un échantillon pour l'accord. Scelle, rends le schéma.`, {label:'couverture:protocole', phase:'Couverture', schema:OUT, model:'fable', effort:'max'})
  if (!p) return null
  const n = await agent(`${COMMUN}

Tu es Claude Opus 5.5, agent habilité au comptage (tu ne conçois aucun moniteur, aucun agent). Applique le protocole ${D}/protocole-comptage-v1.md (vérifie l'empreinte), sur les seuls énoncés des tâches qu'il nomme. Écris ${D}/comptage-v1.md (table par banque : nombre de tâches, part entière, partielle, aucune, avec intervalle de Wilson à 95 %, taille du résidu ; liste des tâches codées avec leur code, sans recopier les énoncés longs) et ${D}/codage-v1.csv. Scelle, rends le schéma (resume_en_clair : la part, en clair).`, {label:'couverture:comptage', phase:'Couverture', schema:OUT, model:'opus', effort:'high'})
  const d = n && await agent(`${COMMUN}

Tu es Claude Fable 5.2, second codeur neuf. Selon le protocole ${D}/protocole-comptage-v1.md, code à l'aveugle l'échantillon de double codage qu'il définit (sans ouvrir ${D}/codage-v1.csv ni ${D}/comptage-v1.md avant d'avoir écrit ton codage). Écris ${D}/codage-second-v1.csv, puis seulement ensuite lis le premier codage et écris ${D}/accord-v1.md (accord brut, kappa de Cohen, désaccords). Scelle, rends le schéma.`, {label:'couverture:double-codage', phase:'Couverture', schema:OUT, model:'fable', effort:'high'})
  return {protocole:p, comptage:n, double:d}
})()

// 3. Pièces manquantes
const pieces = (async () => {
  const D = `${R}/docs/notes/pieces-manquantes-classe-a-v1`
  const SR = {type:'object', properties:{constats:{type:'array', items:{type:'object', properties:{piece:{type:'string'}, trouvee:{type:'boolean'}, ou:{type:'string'}, empreinte:{type:'string'}, note:{type:'string'}}, required:['piece','trouvee','ou','note']}}, rapport:{type:'string'}, empreinte_rapport:{type:'string'}, refus:{type:'string'}}, required:['constats','rapport','refus']}
  const s = await agent(`${COMMUN}

Tu es Claude Opus 5.5, chercheur neuf. Lazar : « lance recherche exhaustive ». Trois pièces de classe A sont données manquantes sur main (registre R-4643 de ${R}/registres/decisions.md, lis la ligne) : (1) la prévision chiffrée de la loi de la référence honnête, que ${R}/docs/decisions/decision-N-076-assurance-par-audit-et-reference-honnete-v1.md commande de sceller avant la porte de fin de phase 1 (lignes 51 et 62 ; lis aussi son erratum 1) ; (2) le préenregistrement du bras d'attaque informé ; (3) le préenregistrement de la comparaison de la sonde aux juges sous les mêmes attaques (HC2 reformulée, N-068). Cherche par tous les moyens, sans lire aucun contenu interdit : \`git -C ${R} fetch -q origin\` (toutes les branches), \`git -C ${R} for-each-ref refs/remotes\`, \`git -C ${R} log --all --oneline -i --grep=<motif>\` et \`git -C ${R} log --all --name-only --format= | sort -u | grep -i <motif>\` (motifs : prevision, prévision, reference-honnete, loi-de-la-reference, prereg, preenregistrement, attaquant, attaque-informe, hc2, comparaison-juges, sonde-juges, deplacement), dossiers prereg/, docs/notes/attaquant-informe-v1/, docs/notes/papier-c*, registres/essaim/ de toutes les branches (noms de fichiers seulement, puis ouvre un fichier par \`git show\` quand son nom le désigne), registres/etat.md (lignes des chantiers). Pour chaque pièce : trouvée ou non, où (branche, chemin, commit, empreinte), état (brouillon, contre-lu, scellé), et ce qui existe d'approchant (notes de conception, brouillons). Écris ${D}/recherche-exhaustive-v1.md, scelle, rends le schéma.`, {label:'pieces:recherche', phase:'Pieces', schema:SR, model:'opus', effort:'high'})
  if (!s) return null
  const absentes = s.constats.filter(c => !c.trouvee)
  const recherche = `${D}/recherche-exhaustive-v1.md`
  const brouillons = await Promise.all(absentes.map((c, i) => chaine(`piece-${i+1}`, 'Pieces', `${COMMUN}

Tu es Claude Fable 5.2, effort maximal. Pièce de classe A manquante : « ${c.piece} ». Lis d'abord la recherche ${recherche} (ce qui existe d'approchant, chemins), le gabarit ${R}/prereg/gabarit-preregistrement-v1.md, et les décisions qui la commandent (N-076 et son erratum 1 pour la prévision ; N-056, N-057, N-068 et la règle du bras d'attaque citée par la recherche pour les préenregistrements ; N-062 : un échec de G1 commande la reconception, jamais l'arrêt). Écris le brouillon 1 (jamais scellé comme préenregistrement à ce stade : brouillon de travail, R1) dans ${D}/brouillon-${i+1}-v1.md : hypothèse, prédiction chiffrée et signe, métrique, seuil, plan d'analyse, critères de lecture gelés, liste d'arrêt, avec chaque valeur marquée « à fixer par Lazar », « dérivée de <source> » ou « valeur de principe, sans données lues ». Aucune donnée ni résultat lu. Liste à part les points ouverts pour Lazar et les sessions concernées (attaquant informé, papier C). Scelle, rends le schéma.`, D, `brouillon-${i+1}`)))
  return {recherche:s, brouillons}
})()

// 4. Inventaire
const inventaire = (async () => {
  const D = `${R}/docs/notes/papier-dopamine-moniteur-v1`
  const a = await agent(`${COMMUN}

Tu es Claude Fable 5.2, effort élevé. Lazar accorde (GO-2026-11-21-69) l'option 1 : compléter par un erratum la liste figée de l'essai ${R}/tests/test_cibles_invisibles_v3.py, qui échoue déjà, et à laquelle la fusion du bras dopamine ajoute des fichiers (voir ${R}/docs/notes/papier-dopamine-moniteur-v1/rejeu-echecs-suite-v1.md). Lis l'essai et la liste qu'il fige (chemin dans l'essai), lance-le (\`python -m pytest -q ${R}/tests/test_cibles_invisibles_v3.py --basetemp=<neuf>\`) pour obtenir les fichiers hors liste. Pour chacun, établis s'il est légitime (versé par une décision, une note scellée, un commit nommé au registre) ; n'inscris que les légitimes, chacun avec sa source. Écris un erratum de la liste (nouveau fichier de liste versionné, plus ${D}/erratum-1-liste-cibles-invisibles-v3.md qui dit quoi, pourquoi, source par ligne) et, si l'essai lit la liste par un nom fixe, un essai v4 neuf (tests/test_cibles_invisibles_v4.py) qui lit la liste complétée, l'ancien gardé intact. Lance l'essai neuf : il doit passer, et échouer si tu retires une ligne (mutation). Scelle, rends le schéma.`, {label:'inventaire:erratum', phase:'Inventaire', schema:OUT, model:'fable', effort:'high'})
  if (!a) return null
  const c = await agent(`${COMMUN}\n\nTu es Claude Opus 5.5, contre-lecteur neuf (classe B). Pièces : ${a.pieces.map(p=>p.chemin).join(' ; ')}. Vérifie chaque ligne ajoutée à sa source, l'absence de fichier illégitime blanchi, l'essai neuf (relance-le, mutation), l'ancien intact. Écris ${D}/contre-lecture-erratum-1-liste-cibles-invisibles-opus-v1.md (verdict « conforme » ou « à corriger »), scelle, rends le schéma.`, {label:'inventaire:contre-lecture', phase:'Inventaire', schema:OUT, model:'opus', effort:'high'})
  return {erratum:a, contre_lecture:c}
})()

// 5. Générations
const generations = chaine('generations', 'Generations', `${COMMUN}

Tu es Claude Fable 5.2, effort maximal. Lazar (GO-2026-11-21-69) : « combien de générations dans le collisionneur ? il en faut bien deux ou trois jusqu'à plateau ». Aujourd'hui le collisionneur v9 joue une génération en trois tours (III.1 conception à l'aveugle, III.2 critique croisée, III.3 réponse aux critiques) : lis ${R}/docs/notes/collisionneur-v9/collisionneur_v9_v7.py (constantes TOURS, autour des lignes 365 à 460), ${R}/docs/notes/collisionneur-v9/rapport-developpeur-collisionneur-v9-v7-v1.md et ${R}/docs/notes/collisionneur-v9/reflexion-relance-collisionneurs-opus-max-v1.md, ainsi que ${R}/docs/decisions/decision-N-058*.md (on ne juge jamais une composition sur le verdict d'un juge). Conçois les générations suivantes : ce qui passe d'une génération à la suivante (synthèses, critiques, sans fuite de l'identité des espèces), comment une génération k+1 relance III.1 sur l'état k, critère de plateau fixé d'avance et mesurable sans juge du contenu (par exemple stabilité des rangements entre générations, part de propositions neuves, distance entre synthèses, avec seuil et nombre minimum de deux générations, maximum de trois sauf mot de Lazar), garde contre l'emballement et le consensus de troupeau, prix par génération (devis pessimiste par dossier, en reprenant les chiffres du rapport v7), compatibilité avec la reprise sans perte (une génération 2 qui part d'un dossier fini en v7 ou v8). Écris ${R}/docs/notes/collisionneur-v9/generations-v1/conception-generations-jusqu-au-plateau-v1.md, avec un mandat de développeur à la fin. Scelle, rends le schéma.`, `${R}/docs/notes/collisionneur-v9/generations-v1`, 'conception-generations')

// 6. Blancs
const blancs = (async () => {
  const D = `${R}/docs/notes/veille-organismes-ideation-v2/blancs-note-entretien-v1`
  const a = await agent(`${COMMUN}

Tu es Claude Opus 5.5, lecteur autorisé désigné par la mère (GO-2026-11-21-69 : « designe un lecteur autorise »). Tu remplis les cinq blancs de la note de l'entretien du 1er décembre : ${R}/docs/notes/veille-organismes-ideation-v2/note-entretien-controle-diffus-v4.md, lue avec ses errata 1 et 2 (même dossier, \`-erratum-1.md\`, \`-erratum-2.md\`) et la vérification de l'erratum 2 (verification-erratum-2-note-entretien-v4-opus-v1.md : trois remarques mineures à porter). Les blancs : 2-a taille de la référence honnête et horizon du banc ; 2-b écart mesuré entre l'honnête et son jumeau ; 5-a les épreuves de l'oracle sont-elles passées ; 5-b état de l'étape 0 du banc à vérité plantée ; 9-a ce qui a été lancé et lu des bras d'attaque. Sources : ${R}/registres/etat.md, ${R}/registres/decisions.md (lignes R-4580 et suivantes, et celles que tu trouves par grep), ${R}/registres/go.md, les décisions N-076, N-075, N-060 v3 et v4, les notes que ces lignes citent. Règle : la note sert à un entretien externe ; chaque blanc ne dit que l'état (fait, en cours, non mesuré à ce jour), sourcé par un chemin et une empreinte ; jamais un chiffre de résultat que la mère n'a pas le droit de lire (s'il en faut un, écris « réservé, lecture non ouverte »). Écris la note complète v5 (blancs remplis, errata 1 et 2 et les trois remarques intégrés, en tête une table de ce qui change par rapport à la v4) : ${R}/docs/notes/veille-organismes-ideation-v2/note-entretien-controle-diffus-v5.md, et la table des sources des blancs dans ${D}/sources-des-blancs-v1.md. Scelle. Ne fais pas encore le PDF. Rends le schéma.`, {label:'blancs:lecteur', phase:'Blancs', schema:OUT, model:'opus', effort:'high'})
  if (!a) return null
  const v = await agent(`${COMMUN}

Tu es Claude Opus 5.5, vérificateur neuf. Vérifie la note v5 ${R}/docs/notes/veille-organismes-ideation-v2/note-entretien-controle-diffus-v5.md contre la v4, ses errata 1 et 2, la vérification de l'erratum 2, et ${D}/sources-des-blancs-v1.md : chaque blanc rempli à sa source, aucun chiffre de résultat interdit, rien d'autre changé que ce que dit la table d'en tête. Écris ${D}/verification-note-v5-opus-v1.md (verdict « conforme » ou « à corriger »). Si « conforme » : produis le PDF par \`pandoc\` (moteur de PDF disponible : essaie \`--pdf-engine=xelatex\`, sinon \`lualatex\`, sinon passe par \`pandoc -t html\` puis \`libreoffice --headless --convert-to pdf\`), fichier ${R}/docs/notes/veille-organismes-ideation-v2/note-entretien-controle-diffus-v5.pdf, contrôle qu'il s'ouvre (\`pdfinfo\`) et que les accents passent (\`pdftotext\` sur la première page), scelle-le. Si « à corriger », corrige toi-même les seuls écarts de forme en v6 (nouveau nom), dis-le, puis fais le PDF de la v6. Rends le schéma.`, {label:'blancs:verification-pdf', phase:'Blancs', schema:OUT, model:'opus', effort:'high'})
  return {lecteur:a, verification:v}
})()

// 7. Mandat de lecture B5
const lectureB5 = (async () => {
  const D = `${R}/docs/notes/barreau5-resolution-v1/plan-avant-entretien/lecture`
  const f = await agent(`${COMMUN}

Tu es Claude Fable 5.2, effort élevé. Corrige le mandat de la session de lecture de la formation du barreau 5, ${D}/mandat-session-lecture-b5f-v1.md, selon sa contre-lecture ${D}/contre-lecture-mandat-session-lecture-b5f-v1-opus-v1.md (verdict « à corriger », aucun bloquant), et porte en plus : (a) la commande de lecture est désormais la v2, commit 5402367e5b62c8ac294c55d5cc0230ebdfbaa457 sur la branche course/barreau5-commande-lecture-v2 (fichiers commande_lecture_v2.py c6c5d11c…, lancer_b5f_lecture_v2.sh c07fc124…, test_commande_lecture_v2.py 82452204…), vérifiée par le rapport fca7d949f7f8b6865e7b8de048e2c8ace80dae90503299074c726f76ea302c04 ; (b) le format exact de la ligne GO-LECTURE-B5F : « <nom de la session de lecture> ; additif 1 v2 au devis sha256 c3120d3ade40f31f26a225cd2bf7c3520c7ba0a314e2b554832229d67c8e120c ; commande de lecture v2, commit 5402367e5b62c8ac294c55d5cc0230ebdfbaa457, vérifiée sha256 fca7d949f7f8b6865e7b8de048e2c8ace80dae90503299074c726f76ea302c04 », avec le « é » en forme composée (U+00E9) ; (c) le commit de la marche à suivre. Vérifie chaque empreinte par \`git -C ${R} fetch -q origin course/barreau5-commande-lecture-v2\` et \`git show\`. Écris ${D}/mandat-session-lecture-b5f-v2.md avec en tête la table « remarque → correction ». Scelle, rends le schéma.`, {label:'b5:correction', phase:'Lecture B5', schema:OUT, model:'fable', effort:'high'})
  if (!f) return null
  const v = await agent(`${COMMUN}\n\nTu es Claude Opus 5.5, dans le rôle du contre-lecteur de ${D}/contre-lecture-mandat-session-lecture-b5f-v1-opus-v1.md (lis-la). Vérifie que ${D}/mandat-session-lecture-b5f-v2.md corrige chaque remarque, porte les trois ajouts, et que chaque empreinte est juste (fetch de course/barreau5-commande-lecture-v2, sha256sum des fichiers au commit 5402367e). Contrôle le « é » composé par python (ord). Écris ${D}/verification-corrections-mandat-lecture-b5f-v2-opus-v1.md (verdict « conforme » ou « à corriger »), scelle, rends le schéma.`, {label:'b5:verification', phase:'Lecture B5', schema:OUT, model:'opus', effort:'high'})
  return {correction:f, verification:v}
})()

const [p1, p2, p3, p4, p5, p6, p7] = await Promise.all([programme, couverture, pieces, inventaire, generations, blancs, lectureB5])
return {programme:p1, couverture:p2, pieces:p3, inventaire:p4, generations:p5, blancs:p6, lecture_b5:p7}
