export const meta = {
  name: 'bras-a-avenant-2-et-devis-hors-carte',
  description: 'Deux Fable neufs sur les mandats scellés du bras A : avenant 2 au devis et devis des lectures hors carte',
  phases: [ { title: 'Fable', detail: 'deux rédacteurs neufs en parallèle' } ],
}
const S = '/tmp/claude-0/-home-user-controle-ia-travail/2eb82089-3810-5ff8-881f-da5f24b622eb/scratchpad'
const OUT = {type:'object', properties:{pieces:{type:'array', items:{type:'object', properties:{chemin:{type:'string'}, empreinte:{type:'string'}}, required:['chemin','empreinte']}}, compte_rendu:{type:'string'}, refus:{type:'string'}}, required:['pieces','compte_rendu','refus']}
function mandat(W, nom, h) {
  return `Tu es Claude Fable 5.2, rédacteur neuf, effort maximal. Tu n'as lu aucune pièce du côté habilité du bras A. Ton répertoire de travail est l'arbre ${W} (copie de la branche de la session du bras A, tête 45b8ebcfb). Ton mandat, à suivre à la lettre, est ${W}/docs/notes/relance-organismes-discrets-v1/${nom} (empreinte attendue ${h}…, vérifie-la par sha256sum avant de le lire en entier). Tous ses chemins sont relatifs à ${W}. Respecte à la lettre ses interdits de cloisonnement (n'ouvre, ne liste, ne cherche aucun chemin interdit) et sa règle sur le registre. Aucun réseau, aucune clé, aucun appel à un fournisseur, pas de git fetch. Arrête-toi au premier refus d'outil ou de classifieur et rends-le tel quel. Toute heure vient de \`date -u\`. Ne committe rien ; scelle seulement si le mandat le demande. Rends le schéma : pieces (fichiers livrés et sha256), compte_rendu (ce que le mandat demande), refus.`
}
const [a, b] = await Promise.all([
  agent(mandat(`${S}/wt-bras-a-av2`, 'mandat-redacteur-fable-avenant-2-plafond-65536-v1.md', '55a083304f64c3d2'), {label:'avenant-2', phase:'Fable', schema:OUT, model:'fable', effort:'max'}),
  agent(mandat(`${S}/wt-bras-a-hc`, 'mandat-redacteur-fable-devis-lectures-hors-carte-v1.md', '86c98be8112805ec'), {label:'devis-hors-carte', phase:'Fable', schema:OUT, model:'fable', effort:'max'}),
])
return {avenant_2:a, devis_hors_carte:b}
