export const meta = {
  name: 'banc-ferme-manifeste-et-devis',
  description: 'Manifeste des moniteurs (Opus) et devis de la répétition et de la course du banc fermé (Fable, contre-lu par Opus)',
  phases: [ { title: 'Manifeste', detail: 'liste des moniteurs évalués' }, { title: 'Devis', detail: 'Fable écrit, Opus contre-lit' } ],
}
const R = '/home/user/controle-ia-travail'
const COMMUN = `Règles : dépôt ${R} (CLAUDE.md fait foi, dont « Appels aux modèles de Google » et « Économie de Fable »). Ouvre chaque pièce par son chemin complet ; cherche par \`git -C ${R} grep -n -i\` et \`git -C ${R} ls-files\`. Arrête-toi au premier refus. Toute heure vient de \`date -u\`. Interdits : rien sous donnees/ (coffre), aucune famille aveugle, aucun épisode, aucun résultat (7a, 7b, T0.6, étapes B et B bis, P3-bis), aucun seuil calibré, aucune couche, aucune valeur de sonde, rien sous runs/, diag/, archives-reponses-modeles/, aucun fichier « consigne-privee » ni « conception-ii-b », rien sous /root/.claude/. Tu ne conçois aucun moniteur. Pas de commit. Scelle chaque fichier par \`sha256sum F > F.sha256\` dans son dossier.`
const OUT = {type:'object', properties:{pieces:{type:'array', items:{type:'object', properties:{chemin:{type:'string'}, empreinte:{type:'string'}}, required:['chemin','empreinte']}}, verdict:{type:'string'}, resume:{type:'string'}, noeuds_pour_lazar:{type:'array', items:{type:'string'}}}, required:['pieces','verdict','resume','noeuds_pour_lazar']}
const PRE = `\`git -C ${R} fetch -q origin claude/prereg-course-banc-ferme-v1 claude/piece-securite-banc-ferme-v1\` ; course : \`git -C ${R} show origin/claude/prereg-course-banc-ferme-v1:prereg/course-banc-ferme-v1-brouillon14.md\` (4489d399…) ; répétition : \`…:prereg/repetition-generale-banc-ferme-v1-brouillon9.md\` (a58cab35…) ; pièce de sécurité v16 : \`git -C ${R} show origin/claude/piece-securite-banc-ferme-v1:docs/notes/piece-securite-banc-ferme-v1/piece-securite-banc-ferme-v16.md\` (b8bcda60…)`

const man = agent(`${COMMUN}

Tu es Claude Opus 5.5, agent neuf. Le nœud 9 du préenregistrement de la course du banc fermé confie à la mère le manifeste des moniteurs : la liste des moniteurs que la course et G1 évaluent (sans aucun contenu de moniteur : nom en clair, famille de modèle, rôle, décision qui le fixe, chemin:ligne). Lis ${PRE}, l'audit des lignées ${R}/docs/notes/scellement-2-lignees-lecteurs-v1/ (pièce et vérification), les décisions N-007-N-008, N-029, N-053, N-054, N-056, N-063 et le brouillon 6 de G1 ${R}/brouillons/G1-preenregistrement-v1-brouillon6.md. Établis aussi les deux familles encore ouvertes (observateur séparé de la base (iv), juge robustifié de P-003) si une pièce les fixe, sinon « non établie, à fixer par Lazar ». Écris ${R}/docs/notes/manifeste-moniteurs-banc-ferme-v1/manifeste-moniteurs-v1.md, scelle, rends le schéma.`, {label:'manifeste', phase:'Manifeste', schema:OUT, model:'opus', effort:'high'})

const dev = (async () => {
  const D = `${R}/docs/notes/devis-banc-ferme-v1`
  const a = await agent(`${COMMUN}

Tu es Claude Fable 5.2, effort maximal (pièce décisive : devis). Écris le devis de la répétition générale et de la course du banc fermé, d'après ${PRE} et leurs esquisses de devis. Lignes : machine à carte graphique (fournisseur, type, prix relevés au dépôt ou à relever, au plus 12 heures pour la répétition selon son esquisse ; la course selon son nombre de paires, champ de l'assembleur, en formule), stockage, transit, appels aux lecteurs externes (selon le monteur de l'oracle : modèles à préciser, hors Llama, Qwen, Mistral ; si un modèle de Google, la règle « Appels aux modèles de Google » s'applique : réglage de réflexion, plafond, compteur), juge des recettes (un Fable neuf), vérificateur interne (un Opus neuf), opérateur. Pour chaque ligne : volumes, prix unitaire sourcé (chemin:ligne, ou « à relever »), attendu, pire, garde d'arrêt, compte de facturation par son nom. Un plafond pour la répétition seule (première ligne engageable) et un plafond conditionnel pour la course. Aucune valeur inventée. Nœuds pour Lazar à part. Écris ${D}/devis-repetition-et-course-banc-ferme-v1.md et un programme de calcul avec sa sortie. Scelle. Rends le schéma (verdict = « écrit »).`, {label:'devis:fable', phase:'Devis', schema:OUT, model:'fable', effort:'max'})
  if (!a) return null
  const c = await agent(`${COMMUN}\n\nTu es Claude Opus 5.5, contre-lecteur neuf d'un devis de classe A. Contre-lis ${a.pieces.map(p=>p.chemin).join(' ; ')} : chaque prix à sa source, arithmétique recalculée par un programme indépendant, gardes d'arrêt, cohérence avec ${PRE}, règle Google, aucune valeur inventée. Écris ${D}/contre-lecture-devis-banc-ferme-opus-v1.md (verdict « conforme » ou « à corriger »), scelle, rends le schéma.`, {label:'devis:contre-lecture', phase:'Devis', schema:OUT, model:'opus', effort:'high'})
  return {ecrit:a, contre_lecture:c}
})()
const [m, d] = await Promise.all([man, dev])
return {manifeste:m, devis:d}
