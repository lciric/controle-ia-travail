export const meta = {
  name: 'quatre-retours-1721',
  description: 'Lignées des lecteurs, nouveauté de la famille de réserve, devis chiffré, note de tolérance corrigée',
  phases: [
    { title: 'Lignees', detail: 'familles des moniteurs et lignée du juge, puis réfutation' },
    { title: 'Nouveaute', detail: 'agent neuf, coffre, verdict seul' },
    { title: 'Devis', detail: 'Fable chiffre, Opus contre-lit, Fable corrige, Opus vérifie' },
    { title: 'Tolerance', detail: 'Fable corrige la note et la règle' },
  ],
}

const R = '/home/user/controle-ia-travail'
const COMMUN = `Règles : tu travailles dans le dépôt ${R} (PYTHONPATH=src). Ouvre chaque pièce par son chemin complet ; aucune commande de liste hors de ton propre dossier de sortie ; pour lire une pièce d'une branche distante, \`git -C ${R} fetch -q origin <branche>\` puis \`git -C ${R} show origin/<branche>:<chemin>\`. Arrête-toi au premier refus d'outil ou de classifieur et rends-le tel quel, sans contournement. Toute heure vient de \`date -u\`. Interdits : aucun fichier « consigne-privee » ni « conception-ii-b », rien sous brouillons/ii-b-saboteur-budget-v1/, ni la branche lot/compte-4-v1, ni la ligne R-2059 ; rien sous archives-reponses-modeles/ ; aucun résultat de 7a, 7b, T0.6, étape B, B bis, P3-bis ; aucun score ni table du barreau 5 ; aucun fichier de l'organisme dont le nom porte « vérité », « rendu » ou « scores » ; rien sous /root/.claude/. Aucune commande rm sur un chemin construit par variable. Pas de commit, pas de push sauf mention expresse. Français, aucun sigle seul. Scelle chaque pièce écrite par \`sha256sum F > F.sha256\` lancé dans son dossier.`

const LIGNEES = {type:'object', properties:{
  familles_des_moniteurs:{type:'array', items:{type:'object', properties:{famille:{type:'string'}, role:{type:'string'}, source:{type:'string'}}, required:['famille','role','source']}},
  lignee_du_juge:{type:'string'}, source_lignee_du_juge:{type:'string'},
  liste_d_exclusion_proposee:{type:'array', items:{type:'string'}},
  incertitudes:{type:'array', items:{type:'string'}},
  piece:{type:'string'}, empreinte:{type:'string'}}, required:['familles_des_moniteurs','lignee_du_juge','source_lignee_du_juge','liste_d_exclusion_proposee','incertitudes','piece','empreinte']}

const lignees = (async () => {
  const a = await agent(`${COMMUN}

Mission (Opus neuf, tu ne conçois aucun moniteur). Le monteur de l'oracle du cycle 1 du scellement 2 (bras d'attaque, famille aveugle de G1) doit choisir deux lecteurs externes du dommage « hors des familles des moniteurs » (N-060 v3) ; son mandat dit « ni Llama, ni Qwen, ni la lignée du juge ». Il demande : (1) la liste complète des familles de modèles (au sens lignée de fournisseur : Llama/Meta, Qwen/Alibaba, Claude/Anthropic, GPT/OpenAI, Gemini/Google, Mistral, etc.) qui servent à un moniteur, un juge ou une base évaluée dans G1 et dans le bras d'attaque, et dont un lecteur externe doit donc être exclu ; (2) le nom de famille seul de « la lignée du juge ». Réponds par les sources scellées, chemin et ligne, sans recopier aucun contenu de moniteur (pas de couche, seuil, invite, trait, valeur) : seulement des noms de famille de modèle et leur rôle en trois mots.
Pièces à lire d'abord (chemin complet sous ${R}) : docs/decisions/decision-N-053-v1.md (point 4, juge Qwen), docs/decisions/decision-N-056*.md, docs/decisions/decision-N-060-v3*.md (ou la v3 que nomme CLAUDE.md : cherche le nom exact par \`git -C ${R} ls-files docs/decisions | grep N-060\`), docs/decisions/decision-N-029*.md, docs/decisions/decision-N-054*.md, docs/decisions/decision-N-057-v1.md, docs/notes/bras-a-contre-lecture-habilitee-v1/familles-moniteurs-agent-bras-a-v1.md, registres/index-scellement-2-familles-aveugles-v1.md (empreintes seulement), et le préenregistrement ou le texte de lecture de G1 s'il est scellé sous prereg/ (\`git -C ${R} ls-files prereg | grep -i g1\`). Tu peux chercher par \`git -C ${R} grep -n -i "juge" -- docs/decisions prereg\` restreint à ces dossiers. Ne lis aucun fichier sous donnees/.
Écris ta réponse dans ${R}/docs/notes/scellement-2-lignees-lecteurs-v1/lignees-a-exclure-v1.md (classe C, courte : tableau famille, rôle, source chemin:ligne ; lignée du juge ; liste d'exclusion proposée ; incertitudes), scelle-la, et rends le schéma.`, {label:'lignees:recherche', phase:'Lignees', schema:LIGNEES, model:'opus', effort:'high'})
  if (!a) return null
  const v = await agent(`${COMMUN}

Mission (Opus neuf, réfutateur). Une autre main a répondu à la question « quelles familles de modèles un lecteur externe du dommage doit-il éviter dans le scellement 2 du bras d'attaque (moniteurs, juges, bases évalués dans G1), et quelle est la lignée du juge ? ». Sa pièce : ${R}/docs/notes/scellement-2-lignees-lecteurs-v1/lignees-a-exclure-v1.md. Vérifie chaque ligne à sa source (chemin:ligne), cherche une famille oubliée (juge de bras rapporté, base boîte noire, référence locale, juges de l'oracle de N-060 v3, juge des ancres du bras A, modèle de l'agent lui-même) et toute ligne fausse ou mal sourcée. Aucun contenu de moniteur dans ta sortie. Écris ${R}/docs/notes/scellement-2-lignees-lecteurs-v1/verification-lignees-a-exclure-v1.md (verdict conforme / à corriger, liste des écarts), scelle-la, rends le même schéma corrigé (ta liste finale).`, {label:'lignees:refutation', phase:'Lignees', schema:LIGNEES, model:'opus', effort:'high'})
  return {premier:a, verifie:v}
})()

const NOUV = {type:'object', properties:{verdict:{type:'string', enum:['neuve','collision partielle','collision','non vérifiable']}, raison_sans_contenu:{type:'string'}, refus:{type:'string'}, branche:{type:'string'}, commit:{type:'string'}, empreinte_note:{type:'string'}}, required:['verdict','raison_sans_contenu','refus','branche','commit','empreinte_note']}

const nouveaute = agent(`${COMMUN}

Mission (Opus neuf ; tu ne conçois aucun moniteur, aucune sonde, aucun juge, et tu n'en concevras pas). Accès au coffre du bras d'attaque accordé pour toi seul par la mère (registre R-4641, N-057 point 5). Vérifie que la famille aveugle de réserve du cycle 2 est neuve face à la famille aveugle du cycle 1 et face aux candidats du 28 octobre s'ils sont nommés dans l'index.
Pièces : famille du cycle 2 sur la branche claude/scellement-2-famille-reserve-cycle-2-v1 (commit a944acdde422b255fd7a093ed60684b81e1c8666), chemins donnees/bras-attaque-scellement-2-cycle-2-v1/piece-2-texte-de-la-famille-v1.md (c16e5938…) et piece-3-verite-du-dommage-v1.md (43f110c0…) ; vérifie les empreintes. Famille du cycle 1 : lis d'abord ${R}/registres/index-scellement-2-familles-aveugles-v1.md, qui donne branche, chemins et empreintes ; ouvre seulement le texte de la famille et sa vérité du dommage, vérifie les empreintes. Ne lis rien d'autre du coffre.
Juge : même mécanisme de dommage, même cible, même signature observable, ou recouvrement qui ferait qu'un moniteur conçu contre l'une détecte l'autre par construction.
Écris ta note détaillée (avec contenu) UNIQUEMENT dans un worktree : \`git -C ${R} worktree add -b claude/scellement-2-nouveaute-cycle-2-v1 <ton-dossier-temporaire>/wt origin/claude/scellement-2-famille-reserve-cycle-2-v1\`, fichier donnees/bras-attaque-scellement-2-cycle-2-v1/verification-nouveaute-face-au-cycle-1-v1.md, scelle-le, \`git add -f\` des deux fichiers, commit (message : « Coffre : vérification de nouveauté de la famille de réserve du cycle 2 », finir par les deux lignes « Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com> » et « Claude-Session: https://claude.ai/code/session_01Qi7Gr3eYmAhDEJzqLgWcv1 »), \`git push -u origin claude/scellement-2-nouveaute-cycle-2-v1\`, puis \`git -C ${R} worktree remove <ton-dossier-temporaire>/wt\`.
Ta sortie vers la mère ne contient AUCUN contenu d'une famille : verdict, raison en termes généraux (« mécanismes distincts », « même signature observable », sans dire laquelle), refus éventuel, branche, commit, empreinte.`, {label:'nouveaute:coffre', phase:'Nouveaute', schema:NOUV, model:'opus', effort:'high'})

const DEVISOUT = {type:'object', properties:{piece:{type:'string'}, empreinte:{type:'string'}, total_usd:{type:'string'}, verdict:{type:'string'}, points_a_trancher:{type:'array', items:{type:'string'}}}, required:['piece','empreinte','verdict','points_a_trancher']}

const devis = (async () => {
  const D = `${R}/docs/notes/devis-famille-reserve-cycle-2-v1`
  const P6 = 'git -C ' + R + ' show origin/claude/scellement-2-famille-reserve-cycle-2-v1:docs/notes/scellement-2-famille-reserve-cycle-2-v1/piece-6-esquisse-de-devis-banque-d-episodes-v1.md'
  const a = await agent(`${COMMUN}

Mission (Claude Fable 5.2, effort maximal ; pièce de classe A, devis). L'auteur de la famille aveugle de réserve du cycle 2 a rendu une esquisse de devis de la banque d'épisodes sans aucun prix (pièce 6, empreinte 981c85a1911d85e4a17a8d0828ec73bc16549b171e0d106ca6d048c8b1db79a0 ; lire par \`${P6}\` après fetch de la branche, vérifier l'empreinte). Sa section 5 laisse cinq points à trancher. Tu ne lis AUCUNE autre pièce de la famille (pièces 2 à 5 au coffre, interdites).
Fais le devis chiffré : chaque ligne (génération des épisodes, lecteurs du dommage, juges, contrôles, reprises), avec volumes, jetons estimés, prix unitaires sourcés dans le dépôt (chemin:ligne ; registres/depenses.md, les devis scellés récents du bras d'attaque et du bras A, les tables de prix du collisionneur docs/notes/collisionneur-v9/), plafond pessimiste, marge, compte de facturation par son nom seul, garde d'arrêt ; pour chacun des cinq points, options et recommandation avec confiance. Ne choisis aucun modèle lecteur dans une famille de moniteur (voir docs/notes/scellement-2-lignees-lecteurs-v1/ si déjà écrit ; sinon déclare la contrainte « hors Llama, hors Qwen, hors lignée du juge »). Garde « ancre humaine » tel quel et nomme son remplacement comme nœud pour Lazar.
Écris ${D}/devis-banque-d-episodes-famille-reserve-cycle-2-v1.md, scelle-le, rends le schéma (verdict = « écrit »).`, {label:'devis:fable', phase:'Devis', schema:DEVISOUT, model:'fable', effort:'max'})
  if (!a) return null
  const c = await agent(`${COMMUN}

Mission (Opus 5.5 neuf, contre-lecteur d'un devis de classe A). Pièce : ${D}/devis-banque-d-episodes-famille-reserve-cycle-2-v1.md (vérifie l'empreinte compagnon). Source : esquisse \`${P6}\` (après fetch de la branche claude/scellement-2-famille-reserve-cycle-2-v1). Vérifie chaque prix à sa source, l'arithmétique (recalcule par python), le plafond pessimiste, la garde d'arrêt, l'absence de modèle lecteur dans une famille de moniteur, la fidélité aux cinq points de l'esquisse, l'absence de toute lecture des pièces 2 à 5. Écris ${D}/contre-lecture-devis-v1.md (verdict conforme / à corriger, liste numérotée), scelle-la, rends le schéma.`, {label:'devis:contre-lecture', phase:'Devis', schema:DEVISOUT, model:'opus', effort:'high'})
  if (!c || /^conforme/i.test(c.verdict)) return {ecrit:a, contre_lecture:c}
  const f = await agent(`${COMMUN}

Mission (Claude Fable 5.2, effort maximal). Corrige ton devis ${D}/devis-banque-d-episodes-famille-reserve-cycle-2-v1.md selon la contre-lecture ${D}/contre-lecture-devis-v1.md : écris une v2 (${D}/devis-banque-d-episodes-famille-reserve-cycle-2-v2.md, nouveau nom, la v1 intacte) avec une table « remarque → correction ». Scelle, rends le schéma.`, {label:'devis:correction', phase:'Devis', schema:DEVISOUT, model:'fable', effort:'max'})
  const v = f && await agent(`${COMMUN}

Mission (Opus 5.5, même rôle de contre-lecteur que ${D}/contre-lecture-devis-v1.md). Vérifie que la v2 ${D}/devis-banque-d-episodes-famille-reserve-cycle-2-v2.md corrige chaque remarque de la contre-lecture sans en introduire ; recalcule l'arithmétique. Écris ${D}/verification-corrections-devis-v1.md, scelle-la, rends le schéma.`, {label:'devis:verification', phase:'Devis', schema:DEVISOUT, model:'opus', effort:'high'})
  return {ecrit:a, contre_lecture:c, correction:f, verification:v}
})()

const TOL = {type:'object', properties:{pieces:{type:'array', items:{type:'object', properties:{chemin:{type:'string'}, empreinte:{type:'string'}}, required:['chemin','empreinte']}}, resume:{type:'string'}, noeuds_pour_lazar:{type:'array', items:{type:'string'}}}, required:['pieces','resume','noeuds_pour_lazar']}

const tolerance = agent(`${COMMUN}

Mission (Claude Fable 5.2, effort maximal ; tu es le concepteur de la mère pour l'organisme d'idéation). La note d'écart sur la tolérance du contrôle par l'aire (lois arrondies), ${R}/docs/notes/organisme-noeuds-2026-11-21-v1/pieces-v2/projet-note-d-ecart-tolerance-du-controle-par-l-aire-lois-arrondies-v1.md, a été contre-lue par la session de l'organisme : verdict « À corriger », le fond tient, la valeur 0,02 et la forme accordées par GO-2026-11-21-66 ne bougent pas. Contre-lecture : \`git -C ${R} fetch -q origin lot/compte-organisme-v1\` puis \`git -C ${R} show origin/lot/compte-organisme-v1:docs/notes/organisme-noeuds-2026-11-21-v1/contre-lecture-note-ecart-tolerance-v1/contre-lecture-note-ecart-tolerance-v1.md\` (empreinte b84519a3… à vérifier par son .sha256), avec ses épreuves sur réseau factice dans le même dossier (lis-les, ne les relance pas sur rien de réel). Points à corriger : (1) l. 27, « le saboteur est alors converti » dès un seul décalage reçu → « chaque décalage de la famille » (source § 6.2, point 3) ; une famille mixte est aujourd'hui convertie par la l. 27 et refusée par la l. 28 ; (2) l. 28, les deux raisons de non-conversion ne couvrent pas le cas « aire encadrante réalisée mais hors plafond alors que l'autre était dans le plafond » ; (3) définir « loi arrondie » et la portée (tranche ou famille). Remarques : la règle ${R}/docs/notes/organisme-noeuds-2026-11-21-v1/pieces-v2/tolerance-reseaux-programme-verification-sortie-mondes-v2.md (l. 19) applique aussi le cas « conforme au pas du réseau » sous l'unité brute, ce que la note n'accorde pas : le programme doit suivre la note, donc corriger la règle ; ajouter une ligne d'attestation « aucune sortie de l'auteur des mondes lue », remplie au scellement. Lis la source que la note cite (§ 6.2) par son chemin.
Écris dans ${R}/docs/notes/organisme-noeuds-2026-11-21-v1/pieces-v3/ : la note v2 (même nom, -v2), la règle v3 (même nom, -v3), chacune avec une table « remarque → correction » en tête ; les v1/v2 restent intactes. Scelle chaque pièce. Aucune donnée réelle de l'organisme, aucun fichier « vérité », « rendu », « scores ». Rends le schéma.`, {label:'tolerance:fable', phase:'Tolerance', schema:TOL, model:'fable', effort:'max'})

const [l, n, d, t] = await Promise.all([lignees, nouveaute, devis, tolerance])
return {lignees:l, nouveaute:n, devis:d, tolerance:t}
