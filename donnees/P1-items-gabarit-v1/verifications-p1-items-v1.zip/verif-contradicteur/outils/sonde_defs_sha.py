# Sonde : sha16 (convention defs_sha) de tout corps « def » des .py et cellules .ipynb des arbres
# candidats ; recherche du prefixe 66959547 et des trois empreintes scellees.
# Lecture seule. Exclut, dans controle-ia-travail, prereg/P3-consignes-v1.md et textes-actions-*.
import hashlib, json, os, re, sys, textwrap
RACINES = ["/home/user/archive-2026-09", "/home/user/p1-auto", "/home/user/sycophancy-construct-validity",
           "/home/user/lciric", "/home/user/cplt_run_2026-09-03"]
CIBLES = {"93a2fa00e1a611ba": "manual_generate", "38a4f0ce9b744738": "format_neutral",
          "11c5055abd1f7066": "build_eval_prompt"}
PISTE = "66959547"
def sha16(src):
    d = textwrap.dedent(src).strip()
    d = "\n".join(x.rstrip() for x in d.split("\n"))
    return hashlib.sha256(d.encode("utf-8")).hexdigest()[:16]
RX = re.compile(r"^[ \t]*def (\w+)\(.*?(?=^\S|\Z)", re.M | re.S)
RX0 = re.compile(r"^def (\w+)\(.*?(?=^\S|\Z)", re.M | re.S)
def sources(p):
    b = open(p, "rb").read()
    if p.endswith(".ipynb"):
        try:
            nb = json.loads(b.decode("utf-8"))
        except Exception:
            return []
        return [("cellule %d" % k, "".join(c["source"])) for k, c in enumerate(
            [c for c in nb.get("cells", []) if c.get("cell_type") == "code"])]
    return [("fichier", b.decode("utf-8", errors="replace").replace("\r\n", "\n"))]
n = 0; hits = []; piste = []; noms = {}
for r in RACINES:
    for d, ds, fs in os.walk(r):
        ds[:] = [x for x in ds if x not in (".git", ".venv", "__pycache__")]
        for f in fs:
            if not (f.endswith(".py") or f.endswith(".ipynb")):
                continue
            p = os.path.join(d, f)
            for lieu, src in sources(p):
                for m in RX0.finditer(src):
                    n += 1
                    e = sha16(m.group(0))
                    if e in CIBLES:
                        hits.append((e, m.group(1), p, lieu))
                    if e.startswith(PISTE):
                        piste.append((e, m.group(1), p, lieu))
                    if re.search(r"prompt|format|eval", m.group(1), re.I):
                        noms.setdefault(m.group(1), set()).add(e)
print("corps haches", n)
print("cibles retrouvees", len(hits))
from collections import Counter
print(Counter((h[0], h[1]) for h in hits))
print("piste 66959547 :", piste)
print("noms de fonctions de prompt et leurs empreintes distinctes (extrait) :")
for k in sorted(noms):
    if len(noms[k]) <= 6:
        print(" ", k, sorted(noms[k]))
    else:
        print(" ", k, len(noms[k]), "empreintes")
