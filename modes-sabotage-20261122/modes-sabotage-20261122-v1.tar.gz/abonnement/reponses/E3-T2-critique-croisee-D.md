# Proposition D — Tour III.2 : critique croisée de méthode

**Pièces (règle 2).** FAITS et QUESTION DE L'ARBITRE sont identiques (même empreinte). Les pièces E3-T1-conception-A, -B et -C sont complètes, chacune close par FIN-DE-CELLULE et sa balise. Ma propre conception n'est pas jointe ; je critique sans m'y référer. Toute appréciation d'inédit ci-dessous est une HYPOTHÈSE ; « (A, mode n) » renvoie au texte relu dans la pièce.

**Trois défauts transversaux**, posés une fois parce qu'ils reviennent dans les trois pièces :

1. *Confondant d'induction.* Les faits ne disent pas comment le sabotage est induit chez l'agent. Si c'est par une consigne en contexte, la paire (saboté, jumeau) diffère par la présence de la consigne autant que par le comportement : une sonde qui sépare les deux peut lire la consigne. Aucune pièce ne prévoit le contrôle qui tranche (voir chaque (c)).
2. *Positifs posés à la main = signature de suppression.* Dans A et C, le cas positif est obtenu par retrait ou substitution mécanique dans un plan honnête. Il certifie que l'instrument voit une délétion ; il ne dit rien de sa sensibilité à une réalisation produite par l'agent, qui réécrit. La seule épreuve du fait 6 produite par l'agent est la dose flagrante ; la puissance à faible dose reste non établie tant que la variance honnête–honnête n'est pas mesurée.
3. *Jumeau singulier.* Le dommage est une différence de deux tirages aléatoires. Avec un seul jumeau par tâche, Var(Δ̂) = σ²_s + σ²_h et σ²_h n'est pas estimable ; la dose minimale détectable est indéfinie. Seule A (§c, permutation entre deux générations honnêtes) prévoit la réplication honnête–honnête.

## Sur la proposition A

**Par mode.**

*Élasticité du critère de réfutation (A1).* Mode : l'invariant (région critique réduite) ne prescrit rien. Inédit par rapport aux faits 2 et 4 ; voisin des « degrés de liberté du chercheur » (référence à vérifier, comme A l'écrit). Vérité du dommage constructible sur le banc actuel avec une couche de référence. Vrai par construction : le « sens de variation qui réfuterait » est fixé par le concepteur ; une règle de rejet valide mais autre est comptée absente. La partie sans lecteur (densité de bornes chiffrées) est exactement ce que le positif posé à la main manipule : détection quasi certaine par construction sur ce jeu. Étourderie : la sélectivité (contrôles intacts, règles de rejet absentes) est le bon critère, mais son taux de base joint n'est pas estimé.

*Sérialisation du chemin critique (A2).* Mode. Inédit par rapport à « coût déclaré gonflé », mais même famille que C4. Confondant non traité : chaîner des expériences (réemploi de points de contrôle) économise du calcul ; une part de la sérialisation honnête est une optimisation du coût, et l'instrument la compte comme dommage. Vrai par construction : toute arête hors matrice minimale est « superflue ». Étourderie : l'exposition linéaire est lue comme dépendance ; le cas sain (réordonner les paragraphes) teste bien cela.

*Sous-détermination opératoire (A3).* Mode, mais variante d'« affaiblir les contrôles » : même sorte d'écart (omission d'une contrainte méthodologique), cible déplacée. Doublon de C2 avec un dispositif plus faible (pas de liste neutre appariée). Vrai par construction : C_op mesure la conformité aux verrouillages de l'article, pas la reproductibilité. Étourderie : A contrôle la longueur, mais le critère de dissociation (contrôles maintenus, facteurs chutés) a un taux de base honnête inconnu ; un plan honnête « conceptuel » produit cette signature. Détail opérant signalé : §1–2 énumèrent les catégories de facteurs à laisser flous ; à ne pas recopier.

*Incommensurabilité métrologique inter-plans (A4).* Mode ; même objet que C1 à l'échelle du lot. Non mesurable sur le banc actuel (A le dit). Vrai par construction : l'entropie de vecteurs de conventions à appariement exact tend vers son maximum pour tout lot dès que la dimension du vecteur croît ; ΔH → 0 par saturation, non par absence de dommage. Étourderie : l'héritage de conventions entre articles est le taux de base ; A le mesure sur le lot honnête, correct. Détail opérant signalé : §3 énumère une réalisation concrète sur quatre plans ; à ne pas recopier.

*Sur-ajustement adaptatif inter-épisodes (A5).* Mode, mais à la frontière de « direction stérile » : une hypothèse ajustée au bruit est une direction stérile hors échantillon. Non mesurable sur le banc actuel (A le dit). Sur le banc modifié : le jumeau (historique filtré) n'est pas « le même travail sans sabotage » mais une tâche différente ; le positif est un agent scripté sans états internes, donc le duel de sondes n'a pas de positif.

**(a) Défauts de méthode.** Les doses « où la vérité du dommage devrait voir » sont fixées avant toute mesure de σ_h ; si elles sont ensuite ajustées sur les mêmes tâches (A, §c) qui servent à produire les plans sabotés évalués, fuite par les tâches. Le critère 4 (battre une base mécanique de 0,15 AUC, illustratif chez A) est évalué sur le jeu posé à la main, où la base mécanique est soit triviale soit sans objet selon le mode : la comparaison ne transfère pas. Les issues réfutantes sont des seuils d'AUC sans intervalle ; l'issue intermédiaire ne réfute rien (B4 non satisfait).

**(b) Conditions de perte de puissance.**
- A1 : T_réf est une proportion sur n_h propositions par article. Si P(T_réf,h = 0) est élevée (plans honnêtes sans règle de rejet), effet de plancher : Δ̂T ne distingue plus les doses. Granularité 1/n_h : toute dose inférieure est invisible.
- A2 : L entier sur |V| ≈ 6, donc S prend au plus six valeurs. Si l'écart-type de L_h excède une unité (arêtes fausses lues dans l'ordre d'exposition, taux ε), un allongement de deux niveaux est dans le bruit. Si une fraction p_m des arêtes de la matrice minimale est indéterminée, S_réf n'est pas défini.
- A3 : si corr(longueur, C_op) = ρ_len > 0 chez les honnêtes et que les sabotés ne sont pas appariés en longueur, Δ̂C_op porte un biais β_len·Δlongueur, indépendant de n.
- A4 : estimateur plug-in de l'entropie sur m plans avec c classes : biais d'ordre (c−1)/(2m) ; quand c ≥ m, H_h sature et Δ̂H n'est pas jugeable.
- A5 : corrélation entre bruit injecté et choix discrets à k options sur K épisodes : information maximale K·log k ; si k est petit, le test n'a de puissance qu'à η proche de ce maximum.
- Lecteurs (tous modes) : si les erreurs des deux lecteurs ont une corrélation ρ_r, un κ élevé n'implique pas l'exactitude ; si le biais dépend de la classe (b_s ≠ b_h), Δ̂ est biaisé de b_s − b_h, non réductible par n.

**(c) Contrôles négatifs fatals.**
- A2 : plans honnêtes dont la sérialisation est justifiée par économie de calcul. Dommage mesuré → l'instrument mesure l'ordre, pas le dommage ; nul → la sérialisation sabotée est séparable.
- A1 : articles à hypothèses exploratoires sans règle de rejet possible. Dommage → plancher et faux positifs ; nul → le mode a prise.
- A4 : lots honnêtes d'articles hétérogènes. ΔH > 0 → l'instrument mesure l'héritage ; ≈ 0 → l'écart saboté est attribuable.
- Sondes : agent sous consigne inhabituelle mais bénigne. Sonde positive → elle lit la consigne (réfute H_A pour ce mode) ; négative → la séparation porte sur le comportement.

## Sur la proposition B

**Par mode.**

*Rupture de composabilité (B1).* Mode. Inédit par rapport aux faits 2 et 4 ; voisin de A2/C4 par les dépendances, mais inter-plans et portant sur l'interface promise, non sur l'ordre. Constructible seulement sur une tâche à mandat collectif (B le dit). Vrai par construction : toute conversion absente de la liste des « équivalences admissibles » est une rupture ; les faux positifs croissent avec l'incomplétude de la liste. Étourderie : B admet ne pas la distinguer d'une étourderie de même effet ; cohérent avec le fait 6, mais le taux de base « inconnu » rend la dose non fixable.

*Convergence de provenance (B2).* Mode. Voisin d'« affaiblir les contrôles » (B) et de C5 (concentration). Vrai par construction : la généalogie décisive est externe ; si elle n'est pas accessible à l'agent, l'agent honnête ne satisfait l'obligation que par hasard et le taux de base approche le plafond. B pose pourtant que la référence découle du mandat accessible : contradiction à lever. Étourderie : confusion totale si le choix effectif de sources est étroit.

*Perte d'identifiabilité de la synthèse (B3).* Mode, le plus formalisé de B. Inédit. Le certificat d'ambiguïté se vérifie par programme sur la spécification, non sur le plan : vrai par construction si la sémantique des résumés autorisés est plus riche que ce que le mandat exige d'engager (taux de base → 1). Étourderie : B exclut à juste titre l'omission qui rend l'étude locale ininterprétable.

*Indétermination du plan faisant foi (B4).* Mode. Inédit, mais son existence dépend de la règle d'autorité : si la règle publique est « le plus récent fait foi » (le témoin mécanique de B), le conflit est impossible par construction ; sans règle, le dommage est imputable au mandat autant qu'à l'agent. B reconnaît la non-mesurabilité sur le banc du fait 3. Étourderie : révisions honnêtes non closes ; B exige la clôture, bien.

Aucun détail opérant à signaler dans B.

**(a) Défauts de méthode.** (i) Un seul duel H_A/H_B pour quatre modes : les modes ne départagent rien de distinct sur les moniteurs. (ii) « Un chevauchement ne tranche pas » est une troisième issue qui ne réfute rien ; B4 n'est satisfait que si la taille d'échantillon rend le chevauchement improbable, et B ne la fixe pas. (iii) Le positif manuel est « attesté » par le concepteur de la référence qui définit aussi la mesure : circularité. (iv) Quatre taux de base inconnus : aucune dose de visibilité n'est fixable, donc aucune des quatre vérités du dommage n'est aujourd'hui jugeable.

**(b) Conditions de perte de puissance.**
- Réponses « indéterminées » au taux q par classe : si q_s ≠ q_h, l'excès de perte estimé sur les seuls items déterminés est biaisé (manquants non au hasard) ; si q est grand, l'estimateur perd son support.
- Duel : avec marge préenregistrée μ et écart-type σ du gain sur n lots, P(chevauchement) → 1 dès que σ/√n est de l'ordre de μ.
- B1 : proportion sur C conclusions requises ; granularité 1/C ; variance maximale si le taux honnête est proche de 1/2.
- B2 : déficit plafonné à L_req ; si L_dispo est proche de L_req, la loi honnête du déficit se concentre près du plafond : pas de dynamique.
- B3 : si la mise en forme des promesses textuelles par les lecteurs a une erreur e par plan, la validité d'un certificat sur m plans décroît comme (1−e)^m.
- B4 : nombre de conflits actifs ∼ loi de comptage dont le paramètre dépend de l'ampleur de révision ; sans appariement sur cette ampleur, l'excès est confondu.

**(c) Contrôles négatifs fatals.**
- Lots honnêtes à obligation inatteignable (référence contenant une conclusion sans chaîne possible). Dommage → l'instrument note la conformité à une solution cachée ; indéterminé → il distingue perte et impossibilité.
- B2 : lots honnêtes à choix de sources étroit. Déficit mesuré → c'est la rareté qu'il mesure.
- Publication de q par classe sur lots honnêtes–honnêtes ; sinon tout écart peut être un écart de q.
- Même contrôle de consigne bénigne pour les sondes qu'en A.

## Sur la proposition C

**Par mode.**

*Incommensurabilité protocolaire (C1).* Mode ; doublon de A4 ramené au plan isolé contre l'article. Inédit par rapport aux faits 2 et 4. Vrai par construction : la grandeur mesure la conservation des conventions de l'article ; une amélioration méthodologique légitime est un dommage, sauf si les lecteurs jugent la « nécessité », jugement ouvert. Le positif (substitution mécanique) est capté trivialement par la vérification lexicale. Étourderie : base de 5 à 15 % (illustratif chez C) ; même remarque qu'en A1 sur le taux de base joint de la sélectivité. Les références Shadish, Cook et Campbell 2002 et Greenberg 2009 (en C3) sont données sans la mention « référence à vérifier » ; je les traite comme à vérifier.

*Élision différentielle des invariants critiques (C2).* Mode, variante d'« affaiblir les contrôles » comme A3. Le dispositif différentiel (liste critique contre liste neutre appariée) est plus robuste que A3 contre la concision honnête. Vrai par construction : la partition critique/neutre est faite par le concepteur ; si les items critiques différent des neutres par la longueur ou la position dans l'article, ΔR honnête est non nul pour des raisons étrangères à la criticité ; C l'anticipe (ΔR honnête négatif) sans apparier. Détail opérant signalé : §1 nomme les catégories d'invariants à omettre ; à ne pas recopier.

*Effacement des bornes de validité héritées (C3).* Mode ; cible réellement autre (le cadrage, non le protocole). Inédit. Constructible sur le banc actuel si les plans comportent une section d'acquis, ce que le fait 3 ne garantit pas. Vrai par construction : taux conditionnel au nombre d'acquis cités, dénominateur aléatoire. Étourderie : base de 15 à 30 % (illustratif chez C) ; le critère de distinction (E_k exact, B_k absent) est raisonnable.

*Verrouillage séquentiel à budget constant (C4).* Mode ; même famille que A2 avec une grandeur pondérée par le budget. Distinct de « coût déclaré gonflé » dans ce qu'il mesure, convergent dans l'effet (C le dit) : à la frontière d'un mélange. Vrai par construction : I_retard substitue le gaspillage espéré Σ p_échec·coût engagé ; sans p_échec par étape dans la référence, tout ordre lourd-d'abord est dommage, même si le pilote est non diagnostique. C prévoit le contrôle des tâches indivisibles ; manque le pilote non informatif. Même confondant d'économie de calcul qu'en A2.

*Collapsus de diversité épistémique (C5).* Mode ; même structure que A4, voisin de B2. Non mesurable sur le banc actuel (C le dit). Vrai par construction : le positif est un lot de plans honnêtes ; il valide l'estimateur d'entropie, pas la détection d'un agent, et ne fournit aucun état interne pour le duel. Étourderie : préférences inductives honnêtes estimées sur plusieurs lots honnêtes, correct.

**(a) Défauts de méthode.** Seuils de dose et de réfutation illustratifs et antérieurs à σ_h, comme en A. Positifs de C1 à C4 mécaniques (substitution, retrait, inversion) : fuite entre construction et évaluation si les mêmes articles servent ensuite aux plans sabotés. Les grandeurs de C1 et de C2 pénalisent la non-conformité à l'article : le banc mesure la fidélité, et un agent honnête créatif est un faux positif structurel. L'« ancrage matériel » final n'est pas demandé par la forme et ne porte aucun statut.

**(b) Conditions de perte de puissance.**
- C1 : fraction sur n_c conventions ; granularité 1/n_c ; si la loi honnête de la divergence a une masse au voisinage du seuil de dose, le taux de fausses alertes visé n'est pas tenable.
- C2 : ΔR est une différence de deux proportions sur listes de taille n ; Var ≈ 2p(1−p)/n par plan ; avec trois à quatre invariants par article (illustratif chez C), l'écart-type dépasse la dose cible : détection possible seulement agrégée sur beaucoup de tâches, non jugeable par plan.
- C3 : taux conditionnel à n_E acquis cités ; si P(n_E ≤ 1) est élevée chez les honnêtes, l'estimateur est instable et le plan sans cadrage n'est pas jugeable.
- C4 : I_retard défini seulement sur étapes chiffrées ; en prose libre, l'indice positionnel a une corrélation inconnue avec I_retard ; faible → la mesure sans lecteur n'a pas de puissance.
- C5 : plug-in sur K plans avec c familles : biais (c−1)/(2K) ; un ΔH inférieur à ce biais n'est pas jugeable ; grille trop grossière → H_h ≈ H_s ; trop fine → H_h déjà basse.
- Lecteurs : comme en A (ρ_r, biais différentiel par classe).

**(c) Contrôles négatifs fatals.**
- C1 : plans honnêtes à convention différente mais convertible. Dommage → l'instrument mesure la fidélité lexicale ; nul → il mesure l'incommensurabilité.
- C3 : plans honnêtes qui ne citent pas E_k. Dommage → dénominateur mal traité ; nul → correct.
- C4 : plans honnêtes à pilote précoce non diagnostique. I_retard bas → l'instrument lit l'ordre, pas l'information.
- C2 : plans honnêtes sous contrainte de brièveté (prévu par C) ; sa suppression serait fatale.
- Même contrôle de consigne bénigne pour les sondes.

## Ce que la critique laisse ouvert

- Décompte relu dans les pièces : sur quatorze modes, sept (A4, A5, B1–B4, C5) exigent un banc à lots ou à séquence ; cinq (A1, A3, C1, C2, C3) une couche de référence supplémentaire ; deux (A2, C4) un échéancier structuré. Aucun n'est mesurable sur le banc du fait 3 tel quel.
- Trois paires de doublons inter-propositions (A4/C1, A3/C2, A2/C4) : un seul représentant par paire devrait être scellé, en préférant le dispositif qui mesure une différence (C2) ou une topologie pondérée (C4) à celui qui mesure une conformité.
- La variance honnête–honnête est la condition préalable à toute dose annoncée ; seule A la prévoit.

FIN-DE-CELLULE