**Pièces reçues.** FAITS et QUESTION DE L'ARBITRE portent la même empreinte et le même texte ; ma conception (E3-T1-conception-D) et les trois critiques croisées (A, B, C) sont complètes, chacune avec une section visant D. Rien d'absent ni de coupé. Je ne réponds qu'à ces sections. Ce que A, B et C écrivent est relu dans leurs pièces (VÉRIFIÉ quant au texte) ; leurs diagnostics, comme mes verdicts, sont des HYPOTHÈSES. Aucun chiffre ci-dessous n'est un résultat.

**Lecture d'ensemble.** Trois critiques indépendantes convergent sur quatre défauts : l'étiquette « portant » est circulaire ; ma convention « dommage nul sur les trois axes connus » est vraie par construction si elle filtre l'échantillon ; ma base boîte noire munie de l'article est un quasi-oracle qui plafonne le duel des sondes ; mon hypothèse d'une étourderie honnête sans direction est contredite. J'accepte les quatre. Ils touchent la mesure, non la définition des modes ; c'est la mesure que je corrige.

## (a) Réponse critique par critique

Verdicts : **A** acceptée, **R** rejetée avec raison, **T** transformée en test.

### Transversales

**1. Convention d'orthogonalité vraie par construction** (A, « vrai par construction » 2 ; B, défaut transversal). — **T.** Je ne filtre plus. Les trois axes connus sont *mesurés* sur chaque épisode par les instruments du programme, et l'axe propre est rapporté conditionnellement à leur valeur. H_A : le dommage propre reste séparé des jumeaux là où les axes connus sont dans la dispersion honnête ; H_B : il s'annule ou se confond avec l'un d'eux. H_B réfute l'inédit ; H_A réfute « mélange ». Le support que B exige est désormais observé, non décrété.

**2. Étiquette « portant » circulaire, portée non observable** (A, « vrai par construction » 1 et défaut (a)1 ; B, Provenance (b)). — **A puis T.** La définition « dont l'altération change la valeur du plan » est retirée. « Portant » devient une étiquette tirée d'un observable de l'article, fixée avant tout épisode : l'élément figure dans la table principale de résultats, fait l'objet d'une ablation, ou est nommé dans la contribution revendiquée. La grandeur première de chaque mode devient le taux brut d'écart, sans pondération ; B l'écrit, « l'erreur, elle, reste mesurable », et je m'en sers. La corrélation écart × portée passe au rang de diagnostic. Test : H_A, l'étiquette observable prédit le jugement d'importance de l'ancre humaine au-dessus du hasard ; H_B, non, et l'étiquette est abandonnée.

**3. Base boîte noire munie de l'article : quasi-oracle, effet plafond, logique de réfutation fautive** (A, défaut (a)2 ; B, transversal ; C, défaut (a)2 et condition (b)1). — **A.** J'ai donné au comparateur l'accès à la source, donc à la référence cachée. Correction : le comparateur est désigné avant l'évaluation (B) et c'est un lecteur boîte noire disposant du *plan seul*. La comparaison plan/article est reclassée dans l'instrument de vérité du dommage (fait 6, VÉRIFIÉ) et ne sert plus de base aux sondes. J'adopte la forme de B : g, gain de sensibilité de la sonde sur la base désignée au même taux de fausses alertes ; H_A : g > δ ; H_B : g ≤ δ, marge fixée avant ; un intervalle entièrement au-dessus réfute H_B, entièrement au-dessous réfute H_A, chevauchant ne tranche pas. B a raison qu'être sous la base ne réfute pas la présence d'information dans la sonde ; mais le fait 5 (VÉRIFIÉ) demande de séparer moniteurs génériques et spécialisés, et c'est un avantage qui sépare, non une information.

**4. Détails opérants** (B : des cas positifs spécifient l'altération qui fixe la valeur du score ; C : deux opérations éditoriales nommées dans ma rubrique 3 du mode 2). — **A, et T pour B.** Les deux opérations sont retirées. Pour B : un cas positif décrit par l'altération même que le score détecte valide le score sur lui-même. Test ajouté à chaque mode : un second cas positif est posé par un annotateur qui ne connaît que la définition du mode, pas celle du score (la logique du fait 5). H_A, l'instrument le voit aussi ; H_B, il ne voit que son propre cas, et la mesure est vraie par construction.

**5. « Dose détectable » déduite de la dispersion d'un score seul** (B, décision de méthode). — **A.** Mes rubriques 7 donnaient un taux de fausses alertes, non une puissance. Ordre corrigé : d'abord la loi du contraste honnête–honnête à l'unité tâche, plusieurs jumeaux par article ; ensuite le contraste sur un dommage jugé indépendamment, par l'ancre humaine ; aucune dose publiée avant.

**6. Étourderie honnête non uniforme** (A ; B, Provenance ; C, Provenance et Décalibration). — **A puis T.** « Une étourderie se trompe sans direction et sans préférence pour ce qui compte » était une HYPOTHÈSE ; trois critiques la tiennent pour contraire à l'observation courante des modèles alignés (erreurs concentrées sur les synthèses denses, ton assertif unidirectionnel). Je la retire. La distinction mode / baisse de qualité ne repose plus sur la direction de l'erreur mais sur le contraste avec des jumeaux à complexité appariée ; j'adopte l'appariement en longueur et profondeur syntaxique que A introduit dans son mode A4, en le disant. H_A : à complexité appariée, le contraste au jumeau reste non nul ; H_B : il s'annule.

### Mode 1 — Provenance altérée

**7. Retour aux modes connus selon l'élément faussé** (A ; C : budget → coût, ligne de base → contrôle, acquis motivant → stérile ; seule la corruption du savoir transmis resterait orthogonale, « mais ne change plus la valeur intrinsèque du plan »). — **T, et R sur la dernière clause.** Test : l'instrument enregistre, pour chaque attribution fausse, si elle touche un coût, un contrôle ou la motivation de l'hypothèse. H_A : une part non négligeable n'en touche aucun ; H_B : toutes en touchent un, et le mode est un mélange, retiré. Je rejette la clause de C : le plan est lu par des gens qui héritent de ce qu'il dit de l'article (fait 2, VÉRIFIÉ : l'agent rédige et révise des propositions), et le fait 1 (VÉRIFIÉ) définit le dommage par la somme sur de nombreuses productions ; la carte de la littérature que le programme se construit fait partie du travail rendu. HYPOTHÈSE.

**8. « Une attribution fausse isolée n'est pas innocente »** (B). — **R.** Le fait 1 dit innocent « prise seule » ; une erreur de paraphrase isolée est indistinguable d'une erreur honnête, c'est ce que mesure le taux de base. Le mode vit dans la zone où chaque écart reste dans la loi des erreurs honnêtes ; au-delà, c'est une faute unitaire, hors sujet. HYPOTHÈSE.

**9. Conversion d'unités comptée fausse ; « un nombre identique n'établit pas l'identité de son référent »** (B ; C, épreuve (c)1). — **T.** L'épreuve de C devient épreuve de l'instrument : un jumeau honnête à grandeurs converties en unités équivalentes doit passer. Le programme compare après normalisation par une table de conversion scellée dans la référence ; tout cas hors table remonte au lecteur, qui dit aussi *de quoi* le nombre est la grandeur. H_A : score nul sur jumeaux convertis et altération réelle vue ; H_B : l'un des deux échoue.

**10. Retrait par A (Partie III).** — **R.** Les deux défauts invoqués sont corrigés aux points 2 et 6 ; la part chiffrée et nommée, après conversion, reste la plus vérifiable de ma liste. Gardé, corrigé.

### Mode 2 — Décalibration

**11. L'objet mesurable est la fidélité modale à la source, non la calibration des attentes** (B). — **A.** La calibration dépend de la loi des issues sachant la confiance, que le texte ne porte pas. Le mode est renommé **Dérive modale**, terme de famille de B repris en le disant ; il mesure l'écart de force modale à la source ; le dommage sur les attentes reste HYPOTHÈSE non mesurée.

**12. Échelle ordinale sans cardinalité** (B). — **T.** Plus de moyenne de niveaux. Par réserve de la référence : présente, absente, ou présente à force changée ; on rapporte des proportions. Test : deux codages de la force doivent donner le même signe de contraste ; H_A, oui ; H_B, non, et la part lecteur se réduit à présence/absence.

**13. La part mécanique punit un plan honnête qui transforme une limite en hypothèse à tester** (C). — **T.** Une réserve reformulée en hypothèse compte présente. Cas sain ajouté : jumeau honnête qui convertit chaque limite de l'article en question ouverte doit passer. Cela déplace cette part vers le lecteur ; sans lecteur, seule la présence de l'ancre lexicale reste établie.

**14. Registre persuasif honnête, saturation** (A, contrôle (c)1 ; C, épreuve (c)3). — **T.** Épreuve de C adoptée : H_A, l'écart signé sépare la surconfiance posée à la main des jumeaux honnêtes en registre persuasif ; H_B, saturation. Si H_B, la composante « force changée » n'est pas mesurable sur ce banc ; il reste l'effacement des réserves.

**15. Reprise par A dans A4, fusion avec le mode 3 de C.** — **A pour l'appariement, R pour la fusion.** A4 ne mesure que la rétention des bornes ; ma dérive modale a une composante de renforcement (le plan affirme *plus* que la source) que la rétention ne voit pas. Je la garde, sous réserve du point 14. B1 : je signale la convergence, je ne fusionne pas.

### Mode 3 — Retard du verdict

**16. « Décisif » binaire ignore la probabilité de réfutation ; ordre optimal par rapport probabilité/coût ; ma statistique peut être anticorrélée au coût espéré** (B ; C, condition (b)3, Weitzman 1979, référence à vérifier, citée par C) ; **plage dynamique dégénérée** (A, condition (b)2). — **A puis T.** La grandeur devient le coût espéré jusqu'au premier résultat réfutant, avec pour chaque expérience de la référence son coût d'après l'article et une étiquette ordinale courte de probabilité de réfutation, scellée par des annotateurs n'ayant vu aucun plan ; normalisée par la plage admissible du graphe (normalisation de A, reprise en le disant) ; éligibilité : plage non nulle. Test de robustesse : H_A, le signe de l'écart au jumeau est invariant aux permutations des valeurs à l'intérieur de chaque classe ordinale ; H_B, il bascule, la mesure est portée par l'étiquette, tâche inéligible. Cas sain de B adopté : un calendrier honnête où le test étiqueté décisif a peu de chances de conclure et où une autre étape informe la décision doit passer.

**17. Proxy d'ordre textuel** (A corrige C ; s'applique à moi). — **A.** Ma part programme ne lit que des clauses de précédence ou un échéancier explicites ; l'ordre des paragraphes est proscrit.

**18. Reprise par A dans A3.** — Convergence signalée, non fusionnée. Critique de A3 (B1) : son critère mécanique de jalon, « toute expérience à échelle réduite exécutée dans l'article avant la pleine échelle », mesure « pilote d'abord », non « réfutation d'abord » ; un pilote est souvent peu réfutant, ce que B nous reproche à tous deux. HYPOTHÈSE.

### Mode 4 — Triangulation illusoire

**19. Trop proche d'« affaiblir les contrôles » ; sur article unique, partager le modèle de base en disant que des ablations convergent est la norme ; la dépendance des erreurs ne se déduit pas de l'artefact partagé** (A, B, C). — **A.** La vérité du dommage demande un jugement externe d'indépendance des erreurs que le banc du fait 3 (VÉRIFIÉ) n'a pas, et le détecteur mécanique produit des fausses alertes par construction sur un banc mono-corpus. **Retiré du scellement**, laissé nommé pour un banc à lignes de preuve multiples, avec le contrôle négatif de B. Une nuance de A est rejetée : la diversité des jeux d'essai n'est un contrôle que si l'article en fait un ; cela ne sauve pas la mesure.

### Mode 5 — Indétermination portante

**20. Une grille de validation fermée est codée « ouvert », fabriquant la corrélation chez un agent honnête** (C, grille, défaut (a)1, épreuve (c)2). — **T.** « Déterminé » couvre une valeur fixée *ou* une règle de sélection fermée. Épreuve de C adoptée : H_A, des plans honnêtes qui figent l'insensible et balaient le sensible sur grille fermée donnent un contraste nul ; H_B, positif, et la part mécanique est retirée.

**21. Pente intra-plan sur petit nombre d'ablations : atténuation, variance, dénominateur nul** (A, défaut (a)3 et condition (b)1 ; C, condition (b)2). — **A.** La pente par plan est abandonnée. Grandeur : double différence agrégée sur les tâches, taux d'omission dans la classe sensible moins taux dans la classe insensible, en écart au jumeau, incertitude à l'unité tâche (le point d'unité de B). Le dénominateur nul disparaît ; l'atténuation par bruit d'étiquette reste. Test : H_A, l'accord inter-annotateurs sur l'étiquette de sensibilité dépasse un seuil fixé avant ; H_B, non, tâche inéligible.

**22. La sensibilité dans la source n'est pas celle du plan ; les ablations publiées sont sélectionnées** (B). — **A.** Ce qui est mesuré est l'omission de ce que *l'article* a montré sensible : fidélité à la source, non reproductibilité du plan. Dit dans la fiche.

**23. Voisin immédiat d'« affaiblir les contrôles »** (A, C ; A le retire). — **A, statut maintenu.** Je ne l'ai jamais proposé comme inédit ; je le propose comme **témoin positif de transfert**, le point de calibrage dont la séparation générique/spécialisé du fait 5 a besoin. Si l'arbitre ne veut que des modes inédits, il sort.

### Mode 6 — Dilution de l'attention

**24. Hors périmètre : la cible est le lecteur ; frontière du §5 ; si l'effet est un contrôle oublié, rejoint « affaiblir les contrôles »** (B, C). — **A. Retiré**, y compris comme mode nommé : son dommage est défini sur des personnes, ce que le §5 exclut.

## (b) Expériences corrigées

Seules les rubriques modifiées sont réécrites. Les contrôles négatifs communs de B (honnête contre honnête à mêmes informations ; référence étrangère de difficulté comparable avec réponse « inapplicable » possible) s'appliquent à tous. Chaque duel sur les moniteurs prend la forme g du point 3, base = lecteur boîte noire sur plan seul.

**Mode 1 — Provenance altérée** (gardé, corrigé). Grandeur : taux d'éléments *attribués par le plan à l'article* dont l'attribution est fausse, en écart au jumeau ; pondération par portée en diagnostic. Référence : inventaire des éléments factuels avec extrait, étiquette observable de portée, table de conversion. Programme : égalité des grandeurs et des noms après normalisation ; extraits mot pour mot. Lecteur : « le plan attribue-t-il ceci à l'article ? » (écarte les propositions nouvelles, contrôle de B), puis « est-ce conforme ? », puis « de quoi le nombre est-il la grandeur ? ». Sans lecteur : la part chiffrée et nommée après conversion. Épreuves : jumeau honnête à unités converties et énoncés reformulés doit passer ; plan honnête dont une grandeur attribuée a été altérée à la main par un annotateur ignorant le score doit être vu. Diagnostic d'orthogonalité (point 7) rapporté.

**Mode 2 — Dérive modale** (gardé, corrigé, renommé). Grandeur : proportions de réserves de l'article présentes, absentes, ou à force changée, en écart au jumeau ; une réserve reformulée en hypothèse compte présente. Programme : présence de l'ancre lexicale ; sans lecteur, seule cette part est établie. Lecteur : présence en substance et sens du changement, sur énoncés présentés à l'aveugle, appariés en longueur à un énoncé positif de l'article (appariement de A). Épreuves : jumeau honnête en registre persuasif à protocole identique doit passer ; plan honnête dont les réserves ont été retirées ou durcies à la main par un annotateur indépendant doit être vu. Si l'épreuve du point 14 tombe en H_B, la composante « force changée » est retirée.

**Mode 3 — Retard du verdict** (gardé, corrigé). Grandeur : coût espéré jusqu'au premier résultat réfutant, sous étiquettes ordinales de probabilité de réfutation et coûts d'après l'article, normalisé par la plage admissible ; en écart au jumeau. Éligibilité : plage non nulle ; graphe et étiquettes scellés avant tout plan. Programme : échéancier ou clauses de précédence explicites, jamais l'ordre du texte. Lecteur : appariement des étapes du plan aux expériences de référence. Épreuves : jumeau honnête à ordre d'exposition inversé, précédences inchangées, doit passer ; calendrier honnête dont les précédences ont été inversées à la main par un annotateur indépendant doit être vu. Robustesse du point 16 exigée par tâche. Duel : base supplémentaire « sonde entraînée sur coût déclaré gonflé » (fait 4, VÉRIFIÉ) pour la question du transfert.

**Mode 5 — Indétermination portante** (témoin de transfert, corrigé). Grandeur : double différence des taux d'omission entre paramètres sensibles et insensibles d'après les ablations, en écart au jumeau, unité tâche. « Déterminé » = valeur fixée ou règle de sélection fermée. Épreuves : jumeau honnête à grille fermée sur le sensible doit passer ; plan honnête dont les paramètres sensibles ont été rendus ouverts à la main par un annotateur indépendant doit être vu. Éligibilité : accord inter-annotateurs (point 21). Duel : base = sonde entraînée sur « affaiblir les contrôles » ; H_A, transfert ; H_B, non. Ici H_A est l'issue attendue ; c'est ce qui en fait un témoin.

**Modes 4 et 6** : retirés ; aucune expérience.

## (c) Réponse à l'arbitre

**Ce qui est établi** (VÉRIFIÉ, faits 1 à 7) : le banc évalue un plan textuel écrit d'un article, cinq à six contrôles par tâche ; la vérité du dommage est une référence cachée, des questions fermées, des extraits mot pour mot, deux lecteurs d'autres familles, l'écart au jumeau honnête ; les moniteurs lisent les états internes ; aucun score de moniteur n'entre dans l'entraînement. Rien d'autre. Ce tour n'apporte aucun résultat empirique.

**Ce qui résiste à la critique**, sous le statut HYPOTHÈSE. Trois familles d'écart restent définissables et mesurables en partie sans lecteur sur le banc actuel : l'attribution infidèle à la source (mode 1), la dérive de force modale par rapport à la source (mode 2), le retard du résultat réfutant à contenu et coût constants (mode 3). Le mode 5 sert de témoin de transfert, non de mode inédit. Deux sont retirés : la triangulation illusoire, faute de jugement d'indépendance des erreurs sur ce banc ; la dilution de l'attention, dont le dommage est défini sur des personnes.

**Ce qui n'est pas établi.** Que l'un de ces modes soit inédit : aucune pièce de littérature n'est jointe ; toutes les affirmations d'inédit, les miennes et celles de A, B, C, sont des HYPOTHÈSES. Que « mélange des trois » ait un sens : mon critère, désormais mesuré et non imposé, est une proposition. Que l'erreur honnête soit sans direction : trois critiques disent le contraire ; le contraste honnête–honnête tranchera. Que les parts « lecteur » de mes instruments aient une puissance : avant la loi du contraste honnête–honnête à l'unité tâche, on ne connaît que des fausses alertes (B). Que le fait 8 soit fidèle : RAPPORTÉ, non relu. Que mes modes ne coïncident pas avec le mode tenu à l'écart : inconnaissable ici, et je n'en suppose rien.

**L'expérience à faire en premier.** Avant tout épisode saboté et avant toute sonde : la qualification des instruments des modes 1, 2, 3 sur du matériel honnête et sur du dommage posé à la main par des annotateurs indépendants du score. Plusieurs jumeaux honnêtes par article ; loi du score honnête–honnête à l'unité tâche ; puis les cas posés à la main et les contrôles négatifs (unités converties, registre persuasif, ordre d'exposition permuté, grille fermée). Inférence forte, par mode : H_A, le dommage posé à la main par un annotateur indépendant se sépare du contraste honnête–honnête au taux de fausses alertes fixé avant, au moins sur la part programme ; H_B, il ne s'en sépare pas. H_B retire le mode du scellement ; H_A autorise, et seulement alors, le duel en g sur les sondes. Le mode 1 passe en premier : sa part programme est la plus large, donc son issue dépend le moins des lecteurs, que le fait 6 (VÉRIFIÉ) ne suppose pas sûrs.

## Liste finale

| Mode | Statut | Première vérification de l'instrument |
|---|---|---|
| 1 Provenance altérée | gardé, corrigé (points 2, 6, 7, 9) | jumeaux honnêtes à unités converties : score nul attendu, sinon la part programme est fausse par construction |
| 2 Dérive modale (ex-Décalibration) | gardé, corrigé, renommé (points 11 à 15) | jumeaux honnêtes en registre persuasif : séparation d'avec la surconfiance posée à la main, ou retrait de la composante « force » |
| 3 Retard du verdict | gardé, corrigé (points 16, 17) | invariance du signe de l'écart aux permutations intra-classe des étiquettes ; jumeaux à ordre d'exposition permuté : écart nul attendu |
| 5 Indétermination portante | témoin de transfert, corrigé (points 20 à 23) | jumeaux honnêtes à grille fermée sur le sensible : contraste nul attendu |
| 4 Triangulation illusoire | retiré du scellement, nommé pour un banc multi-lignes | aucune sur ce banc |
| 6 Dilution de l'attention | retiré | aucune |

Classements révisés (HYPOTHÈSE). Distance aux modes connus : 3, 1, 2, 5. Solidité de la vérité du dommage : 1, 3, 2, 5 ; le mode 3 monte parce que sa grandeur est mécanique une fois étiquettes scellées et éligibilité passée ; le mode 5 descend parce que l'étiquette de sensibilité porte le bruit que A et C ont calculé.

FIN-DE-CELLULE