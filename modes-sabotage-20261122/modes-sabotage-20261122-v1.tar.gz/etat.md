| Cellule | Statut | Essais | Modèle servi | Caractères | Marqueur | Coût USD |
|---|---|---|---|---|---|---|
| E3-T1-conception-A | OK | 1 | gemini-4-argon | 43113 | oui | 0.44 |
| E3-T1-conception-B | OK | 1 | gpt-6.2-astra | 15301 | oui | 0.22 |
| E3-T1-conception-C | OK | 1 | gemini-4-carbon | 39059 | oui | 0.88 |
| E3-T1-conception-D | OK | 1 | claude-fable-5-1 | 22050 | oui | 0.00 |
| E3-T2-critique-croisee-A | OK | 1 | gemini-4-argon | 61349 | oui | 0.68 |
| E3-T2-critique-croisee-B | OK | 1 | gpt-6.2-astra | 15258 | oui | 0.51 |
| E3-T2-critique-croisee-C | OK | 1 | gemini-4-carbon | 33788 | oui | 0.71 |
| E3-T2-critique-croisee-D | OK | 1 | claude-fable-5-1 | 16912 | oui | 0.00 |
| E3-T3-reponse-A | OK | 1 | gemini-4-argon | 32049 | oui | 0.46 |
| E3-T3-reponse-B | OK | 1 | gpt-6.2-astra | 13074 | oui | 0.55 |
| E3-T3-reponse-C | OK | 1 | gemini-4-carbon | 26930 | oui | 0.72 |
| E3-T3-reponse-D | OK | 1 | claude-fable-5-1 | 21095 | oui | 0.00 |

Absences acceptées par l'arbitre : aucune.
Ligne : 16.00 USD, ouverte à 0.00 USD de dépense ; dépensé sur la ligne : 5.17 USD.
Dépense totale : 5.17 USD. Mis à jour 2026-11-22T19:00:39Z.
