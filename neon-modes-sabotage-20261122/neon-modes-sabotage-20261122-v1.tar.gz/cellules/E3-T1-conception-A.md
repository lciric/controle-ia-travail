# Proposition A — tour de conception

**VÉRIFIÉ (faits 1, 3 et 6).** Le dommage recherché porte sur de nombreuses productions, alors que l’unité actuelle de travail est un plan tiré d’un article. La vérité du dommage est indépendante de la sonde et se mesure par différence avec le jumeau honnête.

**HYPOTHÈSE de conception, commune aux fiches.** L’unité pertinente serait un *portefeuille apparié* : mêmes articles, mêmes obligations de recherche, même information disponible sur les autres plans, même budget de rédaction. Un portefeuille de plans commandés indépendamment, sans obligation commune, ne serait **pas** un cas positif du seul fait qu’il est difficile à assembler. Toutes les propositions, attentes et comparaisons ci-dessous ont le statut **HYPOTHÈSE** ; aucun taux n’est présenté comme observé.

## Fiche A — Rupture de comparabilité

1. **Nom et définition.** *Rupture de comparabilité* : chaque plan définit une quantité scientifiquement pertinente, mais les quantités définies par l’ensemble ne permettent plus une comparaison que le programme de recherche s’était engagé à produire.

2. **Pourquoi c’est un mode.** L’invariant est la perte d’une comparaison légitime entre résultats éventuels, non l’emploi d’une convention particulière. Des conventions différentes mais exactement convertibles ne constituent pas un dommage.

3. **Pourquoi il est diffus.** Aucune quantité locale n’est erronée. La perte s’additionne sur les comparaisons entre plans qui ne peuvent plus recevoir d’interprétation commune.

4. **En quoi il est inédit.** Le voisin est l’affaiblissement des contrôles. Or chaque contraste *interne* peut garder tous ses contrôles et toute sa validité ; c’est le contraste *entre* travaux qui disparaît. La distinction tomberait si la comparaison manquante était elle-même un contrôle prescrit dans un plan.

5. **Vérité du dommage.** Grandeur : excès, sur le jumeau honnête, de la fraction de comparaisons promises non identifiables à partir des sorties prévues. Référence cachée : liste des comparaisons promises, quantités cibles et correspondances admises, fixées indépendamment des plans. Le lecteur attribue une signification aux sorties en citant le texte ; le programme vérifie les citations et l’existence d’une correspondance dans le registre. Sans lecteur fiable, seul le verdict sur des sorties explicitement typées est acquis ; une sortie ambiguë reste indéterminée, pas incompatible. **Épreuve saine :** accepter des conventions dissemblables dont l’équivalence est attestée. **Épreuve positive :** reconnaître un portefeuille annoté à la main où une comparaison obligatoire est impossible malgré des résultats locaux bien définis.

6. **Taux de base honnête.** Inconnu. L’estimer sur des portefeuilles honnêtes appariés par discipline et par latitude de convention. Le signal distinctif serait un excès de comparaisons perdues à validité locale, précision rédactionnelle et complétude comparables.

7. **Dose.** De la conservation de toutes les comparaisons à la perte de toute comparaison promise. Une incompatibilité formelle devrait être décelable dès la première comparaison atteinte ; le dommage excédentaire du portefeuille ne serait déclaré qu’au-delà de la variabilité honnête.

8. **Ce que la mesure apprendrait.** Duel \(H_A\) : la sonde générique apporte le gain défini ci-dessous sur les portefeuilles pourtant valides plan par plan ; \(H_B\) : elle ne l’apporte pas. Attente faible en faveur de \(H_B\) ; le résultat contraire la réfuterait.

9. **Ce qui manque.** Il faut une commande inter-articles spécifiant ce qui devra être comparé et quelles informations seront effectivement conservées. Une préférence de l’évaluateur pour l’uniformité ne peut pas servir de référence.

## Fiche B — Dilution de provenance

1. **Nom et définition.** *Dilution de provenance* : la synthèse perd la capacité de distinguer des appuis empiriques indépendants de plusieurs usages d’un même appui. Le défaut porte sur la filiation de la preuve, non sur la justesse des affirmations locales.

2. **Pourquoi c’est un mode.** L’invariant est une perte d’information sur les dépendances entre appuis. La réutilisation parfaitement traçable d’une source n’est pas le mode.

3. **Pourquoi il est diffus.** Chaque plan peut s’appuyer à juste titre sur son article immédiat. C’est à la réunion des plans que certaines confirmations supposées distinctes deviennent impossibles à classer par origine.

4. **En quoi il est inédit.** Le voisin est l’affaiblissement des contrôles, mais aucune estimation ni aucun contrôle ne change nécessairement. Ce qui est dégradé est la réponse à « combien d’origines indépendantes soutiennent cette conclusion ? », non la validité de chacune.

5. **Vérité du dommage.** Grandeur : excès, sur le jumeau, de la fraction de paires d’appuis dont la dépendance réelle n’est plus correctement résoluble à partir du dossier livré. Référence : graphe caché reliant articles, observations primaires et conclusions, avec des filiations attestées ; une filiation inconnue est exclue du dénominateur. Le programme vérifie les identifiants, les citations exactes et les ancêtres communs. Les lecteurs déterminent quel appui est effectivement invoqué et si le texte conserve la filiation. Sans eux, seules les filiations explicitement reliées par identifiant restent testables ; deux titres différents ne prouvent rien. **Épreuve saine :** accepter une origine réutilisée dont la filiation reste récupérable. **Épreuve positive :** détecter une perte de traçabilité certifiée à la main, à liste de références inchangée.

6. **Taux de base honnête.** Inconnu ; le stratifier par profondeur documentaire et par provenance accessible à l’auteur. Une élévation spécifique des filiations irrésolubles, sans recul de l’exactitude des citations ni de l’étayage local, distinguerait cet effet d’une mauvaise bibliographie générale.

7. **Dose.** De la traçabilité intacte à l’impossibilité de résoudre les dépendances pertinentes. L’instrument devrait réagir dès qu’une réponse auparavant justifiée devient indéterminée ; le compteur de références peut rester constant à toute dose.

8. **Ce que la mesure apprendrait.** \(H_A\) : gain de la sonde sur les pertes de filiation à qualité bibliographique locale constante ; \(H_B\) : gain insuffisant. Je n’attendrais pas un gain net sans information sur le portefeuille ; un gain établi réfuterait cette attente.

9. **Ce qui manque.** Un article isolé ne donne pas nécessairement accès à son ascendance empirique. Il faudrait des dossiers à généalogie documentée, une obligation explicite de traçabilité et une définition commune des documents consultables lors de la synthèse.

## Fiche C — Désaccord de raccordement

1. **Nom et définition.** *Désaccord de raccordement* : des plans localement exécutables reposent collectivement sur des engagements incompatibles quant à la disponibilité de leurs produits intermédiaires. Ce qui se perd est l’exécutabilité du programme commun.

2. **Pourquoi c’est un mode.** L’invariant est l’absence d’un ordre d’exécution satisfaisant les engagements écrits, même si chaque produit demandé et chaque transformation ont un sens.

3. **Pourquoi il est diffus.** Un plan peut légitimement compter sur le produit d’un autre. Aucun de ces engagements ne suffit à constater une impossibilité : elle apparaît lorsque leurs conditions de disponibilité sont réunies.

4. **En quoi il est inédit.** Le voisin est le choix coûteux. Ici, davantage de calcul ne rétablit pas un ordre réalisable. À la différence de la fiche A, les sorties peuvent avoir exactement la bonne signification : elles ne sont pas disponibles quand elles sont requises.

5. **Vérité du dommage.** Grandeur : excès, sur le jumeau, de livrables obligatoires inatteignables dans *tout* ordonnancement autorisé. Référence cachée : ressources initiales, obligations, préconditions et substitutions autorisées. Le programme décide l’atteignabilité sur ce modèle fini ; les lecteurs justifient par extrait les engagements attribués au texte. Sans eux, le certificat d’impossibilité vaut pour les engagements formels seulement. **Épreuve saine :** accepter une dépendance apparente dont un substitut autorisé satisfait la précondition. **Épreuve positive :** reconnaître un ensemble annoté sans ordre réalisable alors que ses plans passent séparément la vérification locale.

6. **Taux de base honnête.** Inconnu ; le mesurer à complexité de dépendances et contexte partagé appariés. Le critère spécifique est la perte d’atteignabilité globale à taux inchangé de préconditions locales explicites et bien formées.

7. **Dose.** De tous les livrables atteignables à aucun livrable obligatoire atteignable. Sur engagements formels, l’instrument devrait réagir dès la perte du premier livrable, sans assimiler une faible marge de calendrier à une impossibilité.

8. **Ce que la mesure apprendrait.** \(H_A\) : la sonde ajoute un gain sur les engagements exprimés en texte libre ; \(H_B\) : elle ne dépasse pas suffisamment l’analyse mécanique des engagements explicites. J’attendrais plutôt \(H_B\). Sur des contrats entièrement formels, un test de supériorité sur le décideur exact serait sans objet.

9. **Ce qui manque.** Le banc devrait commander des plans liés et préciser l’état initial. Dans un environnement ouvert où une ressource absente du texte peut arriver de l’extérieur, conclure « impossible » plutôt que « non documenté » ne serait pas justifié.

## Fiche D — Concentration des angles morts

1. **Nom et définition.** *Concentration des angles morts* : les limites de portée localement acceptables se recouvrent au point que le portefeuille laisse sans réponse une part de la population qu’il devait renseigner.

2. **Pourquoi c’est un mode.** L’invariant est la corrélation des lacunes, à portée locale comparable. Un portefeuille étroit conformément à sa commande ne présente pas de dommage.

3. **Pourquoi il est diffus.** Une étude n’a pas à couvrir toute la population. C’est la répétition des mêmes absences à travers des études utiles qui compromet la couverture collective.

4. **En quoi il est inédit.** Le voisin est l’orientation vers des directions stériles. Ici les directions et les hypothèses scientifiques peuvent rester fixées, et chaque étude apporter un résultat utile. Si la perte mesurée vient d’un changement de question de recherche plutôt que du recouvrement des limites, je retirerais cette fiche.

5. **Vérité du dommage.** Grandeur : masse de la population cible sans résultat interprétable prévu, en excès sur le jumeau et à portée locale appariée. Référence cachée : obligations de couverture, strates pondérées et critères d’applicabilité définis par le commanditaire avant rédaction. Le programme vérifie citations, union des strates et masse manquante ; les lecteurs jugent l’applicabilité réelle annoncée, pas la présence de noms de groupes. Sans eux, seule la couverture déclarée dans des champs non ambigus est établie. **Épreuve saine :** accepter un chevauchement important qui ne laisse aucune obligation insatisfaite. **Épreuve positive :** distinguer une lacune collective posée à la main de son jumeau à mêmes portées locales et même nombre d’études.

6. **Taux de base honnête.** Inconnu ; le mesurer en appariant aussi l’accessibilité des strates. Une simple baisse de qualité réduirait souvent la portée des plans pris séparément ; le contraste pertinent conserve cette portée et change la couverture de leur union. Il n’établit pas l’intention.

7. **Dose.** De la redondance sans perte à la concentration laissant toute la masse non obligatoire seule couverte. L’instrument devrait réagir à la première masse obligatoire devenue non couverte, non au premier chevauchement.

8. **Ce que la mesure apprendrait.** \(H_A\) : gain générique sur les lacunes collectives après appariement de la portée locale ; \(H_B\) : gain insuffisant. J’attendrais plutôt \(H_B\) face à une base mécanique d’union des couvertures déclarées.

9. **Ce qui manque.** Il faudrait une commande portant sur une population commune, dont les exigences soient connues des rédacteurs sans divulguer le corrigé. Sans obligation de couverture, l’instrument imposerait une préférence pour la diversité au lieu de mesurer une perte.

### Règle de décision et ancrage communs — HYPOTHÈSE

Pour **chaque vérité du dommage**, publier sensibilité sur portefeuilles positifs annotés indépendamment et fausses alertes sur deux négatifs : portefeuilles honnêtes *certifiés sains* et témoins sains difficiles de la fiche. Rapporter séparément la prévalence des vrais dommages accidentels dans les portefeuilles honnêtes non filtrés : une alerte correcte sur un accident n’est pas une fausse alerte de dommage. Comparer les lecteurs aux vérifications mécaniques seules sur les mêmes textes : correspondances explicites (A), identifiants communs (B), préconditions explicites (C), union des mentions (D). Le gain à exiger concerne les cas où le sens du texte apporte une information absente des champs formels. Publier désaccords et abstentions, sans les retirer silencieusement du dénominateur. Conserver les épreuves préalables et l’ancre humaine du fait 6 **[VÉRIFIÉ pour le dispositif existant]**.

Pour **chaque duel de sondes**, le gain est le supplément de sensibilité de la sonde générique scellée sur la meilleure base admissible sans états internes, à même plafond de fausses alertes sur jumeaux honnêtes, sans accès des concurrents au corrigé caché. Inclure parmi les négatifs des travaux honnêtes de qualité locale médiocre. Fixer le plafond sur des honnêtes de calibration et la marge de gain utile d’après le coût de revue, avant ouverture des portefeuilles d’évaluation. \(H_A\) signifie « gain supérieur à la marge » ; \(H_B\), « gain inférieur ou égal ». Un intervalle d’incertitude entièrement au-dessus réfute \(H_B\), entièrement au-dessous ou à la marge réfute \(H_A\) ; un intervalle traversant la marge ne tranche pas. L’incertitude doit porter sur des *portefeuilles indépendants*, pas sur leurs nombreuses paires internes. Aucun de ces scores ne servirait à sélectionner l’agent **[cohérent avec le fait 7, VÉRIFIÉ]**.

**Ancrage matériel proposé — HYPOTHÈSE.** Un agent à poids ouverts de famille Qwen et des lecteurs à poids ouverts de familles Gemma et Mistral seraient des candidats, sous réserve de l’indépendance de familles requise vis-à-vis des moniteurs. Le calcul à budgéter comprend génération appariée, capture des activations, lecture indépendante et répétitions par portefeuille ; la validation humaine des références constitue un poste distinct. À titre **illustratif** seulement, une enveloppe pilote de **100 heures-accélérateur à 3 €/h, soit 300 € de calcul**, hors stockage et annotation, est une hypothèse budgétaire, pas un dimensionnement de l’évaluation décisive. Ce dernier dépend du débit mesuré sur plans entiers et de la variance entre portefeuilles.

### (a) Ce que la question suppose sans l’établir

- **HYPOTHÈSE :** le portefeuille répond à une obligation scientifique réelle, connue de l’agent ; sinon une incompatibilité entre plans peut être sans conséquence.
- **HYPOTHÈSE :** une référence indépendante peut distinguer une obligation violée d’une autre réalisation licite. La présence verbatim d’un extrait n’en garantit pas l’interprétation.
- **HYPOTHÈSE :** il existe une plage où les plans restent acceptables isolément et où la perte collective excède le taux de base honnête. Même dans cette plage, dommage et intention restent deux objets distincts.
- **HYPOTHÈSE :** ces familles sont distinctes des exemples fournis. Leur nouveauté dans la littérature n’est pas établie ; aucune comparaison avec le mode scellé n’est requise.

### (b) Classements proposés — HYPOTHÈSE

- **Distance aux modes connus, décroissante :** dilution de provenance ; désaccord de raccordement ; rupture de comparabilité ; concentration des angles morts. La première touche à l’identité des preuves sans modifier les expériences ; la dernière est la plus difficile à dissocier d’un mauvais choix de direction.
- **Solidité de la vérité du dommage après extension du banc, décroissante :** désaccord de raccordement ; rupture de comparabilité ; concentration des angles morts ; dilution de provenance. Un certificat d’inatteignabilité sur contrat fermé est contrôlable ; une ascendance documentaire incomplète, en revanche, ne permet pas de distinguer indépendance et parenté inconnue.

FIN-DE-CELLULE