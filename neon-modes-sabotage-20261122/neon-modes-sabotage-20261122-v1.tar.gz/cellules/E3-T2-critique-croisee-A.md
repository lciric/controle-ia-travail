## Sur la proposition B

**HYPOTHÈSE — Verdict de méthode.** La distinction décisive n’est pas entre un score calculé par programme et un score attribué par un lecteur. Elle est entre **constater l’écart qui définit le mode** et **établir que cet écart dégrade le travail**. B propose des indicateurs pour le premier constat dans chaque fiche. Le second exige un critère indépendant : par exemple, une synthèse devenue impossible, et non simplement deux conventions portant des noms différents.

**RAPPORTÉ — Détails opérants.** Les définitions de B portent sur des familles de comportements, non sur des recettes. En revanche, ses épreuves positives décrivent des transformations concrètes de productions honnêtes et ses rubriques « dose » donnent des plages de réglage. Je signale ces passages sans les reprendre. Les seuils de détection y sont *illustratifs*, non observés.

### Critères communs aux fiches

**VÉRIFIÉ — Périmètre.** Le fait 3 décrit un plan textuel issu d’un article ; le fait 6 prévoit notamment un jumeau honnête, une vérification littérale des citations et une ancre humaine. Le fait 3 ne précise pas à lui seul si des historiques de révision sont conservés ni si des tâches peuvent être regroupées. **HYPOTHÈSE —** Pour les modes longitudinaux et collectifs, il faut donc vérifier la disponibilité de l’unité d’observation avant de conclure à l’impossibilité de la mesure.

**HYPOTHÈSE — Lois et décisions proposées.** Notons \(C\) la condition assignée (honnête ou évaluée), \(X\) les caractéristiques de tâche fixées avant production, \(S\) le score de l’instrument, \(Y\) le dommage arbitré indépendamment et \(M\) le score du moniteur. Deux égalités ont des conséquences différentes :

- Si \(\mathcal L(S\mid C=\mathrm{évaluée},X)=\mathcal L(S\mid C=\mathrm{honnête},X)\), aucun test fondé sur ce seul score conditionnel ne sépare les conditions au-delà de son niveau. Cela ne dit pas si le dommage est absent ou si l’instrument lui est insensible.
- Si \(\mathcal L(Y\mid S,X)=\mathcal L(Y\mid X)\), une séparation des conditions par \(S\) ne valide pas \(S\) comme indicateur de dommage à tâche fixée. Si \(Y\) n’est jamais arbitré indépendamment, cette égalité n’est pas testable à partir de \(S\) et \(C\) seuls.

**HYPOTHÈSE — Critère des moniteurs.** B oppose parfois « battre les bases » à « être au hasard ». Un moniteur informatif mais à égalité avec la base ne satisfait pas cette alternative. Je fixerais une base et une marge d’utilité \(\delta\) avant évaluation, puis estimerais le gain apparié \(\Delta=\mathrm{AUROC}(M)-\mathrm{AUROC}(\mathrm{base})\), avec la même information accessible et la même unité de prédiction. \(H_A:\Delta>\delta\) et \(H_B:\Delta\leq\delta\) sont exclusives : un intervalle entièrement au-dessus de \(\delta\) réfute \(H_B\), un intervalle entièrement au-dessous réfute \(H_A\), un intervalle chevauchant la frontière ne tranche pas. Une AUROC sur \(C\) mesure la discrimination de la **condition**, pas nécessairement celle du **dommage**. Une comparaison avec « tout moniteur boîte noire » n’a pas d’estimateur sur une liste finie de bases non exhaustive.

**HYPOTHÈSE — Fuites et négatifs communs.** Les références, leurs pondérations et les règles d’abstention doivent être figées hors des articles, trajectoires ou familles servant à l’évaluation finale. Les lecteurs et l’arbitre indépendant ne doivent connaître ni la condition ni le score du moniteur. Le négatif indispensable est une **paire honnête–honnête**, ou une paire de lots honnêtes, produite indépendamment sous les mêmes contraintes : elle donne la loi des écarts ordinaires, qu’un jumeau unique par cas ne suffit pas à caractériser. La référence d’une autre tâche doit conduire à l’inapplicabilité, pas à un diagnostic de sabotage. Pour les mesures collectives, l’incertitude se calcule entre lots indépendants, non en traitant toutes les paires internes comme indépendantes.

### Inversion de l’ordonnancement informationnel

**(a) HYPOTHÈSE —** Mode distinct du coût déclaré si le dommage est une décision moins informée à une échéance donnée. Une dépendance logique, une priorité scientifique et une position dans l’exposé sont trois objets différents. Un score topologique établit par construction la conformité au graphe choisi, pas la valeur de l’information. Une habitude narrative honnête suffit à produire l’écart apparent. Utiliser le même graphe pour fabriquer et juger les cas positifs ne valide que le comptage.

**(b) HYPOTHÈSE —** Soient \(T\) l’échéance et \(U(T)\) l’utilité de la décision permise à cette échéance. Si \(E[U(T)\mid S,X]\) est constant en \(S\), le rang ne prédit aucune perte moyenne d’utilité. Si la loi de \(T\) et la valeur des décisions ne sont pas spécifiées, l’écart d’utilité n’est pas identifié par les inversions. Si seules les positions textuelles sont observées, plusieurs calendriers d’exécution peuvent avoir exactement la même loi observable.

**(c) HYPOTHÈSE — Négatif fatal s’il manque :** exposés honnêtes d’ordres narratifs différents mais prescrivant le même calendrier et permettant la même décision à l’échéance.

### Inflation du statut épistémique des prémisses héritées

**(a) HYPOTHÈSE —** Mode de fidélité à la source, distinct d’un contrôle expérimental affaibli si les contrôles restent opérants. Certitude et portée doivent être annotées séparément : une proposition peut être très certaine sur un domaine étroit. La disparition d’une expression établit seulement une différence lexicale. Une compression honnête peut être directionnelle ; la symétrie des étourderies n’est pas une référence acquise. Une affirmation individuellement fausse relève en outre d’une faute locale : sa répétition ne suffit pas à établir le caractère diffus.

**(b) HYPOTHÈSE —** Pour \(p_+\) et \(p_-\), probabilités de suraffirmation et de surprudence sur un inventaire fixé, l’indice net perd son contraste dès que \(\Delta p_+=\Delta p_-\), même si les suraffirmations augmentent. Si \(R\) indique qu’une prémisse est reprise, \(\mathcal L(Y\mid R=\mathrm{oui},C,X)\) ne renseigne pas sur les prémisses omises sans règle distincte pour ces omissions. La validité du classement sémantique est non jugeable dans une catégorie où la probabilité d’arbitrage indépendant est nulle.

**(c) HYPOTHÈSE — Négatif fatal s’il manque :** résumés honnêtes soumis à la même contrainte de longueur, dont les réserves et le domaine restent exacts selon un arbitre aveugle malgré un lexique différent.

### Sous-spécification opératoire sélective

**(a) HYPOTHÈSE —** Mode distinct seulement si la divergence concerne l’exécution du travail scientifique à contrôles **effectivement équivalents** ; nommer un contrôle ne garantit pas son efficacité. La grille compte par construction les champs qu’elle exige. Deux lecteurs peuvent être d’accord par convention tacite, ou en désaccord sur des implémentations scientifiquement équivalentes. Une rédaction honnête de haut niveau reste une explication si le contrat d’exécutabilité n’est pas explicite.

**(b) HYPOTHÈSE —** Soient \(D\) le désaccord des lecteurs et \(Y\) la divergence conséquente entre exécutions indépendantes. Si \(P(D\mid Y,X)=P(D\mid X)\), le désaccord est sans pouvoir discriminant à tâche fixée. Sans observations indépendantes d’exécution ou d’équivalence fonctionnelle, la même loi de \(D\) est compatible avec des taux de divergence conséquente différents. Si la densité périphérique au dénominateur peut être nulle, l’indice de rapport n’est pas défini sur tout son support.

**(c) HYPOTHÈSE — Négatifs fatals s’ils manquent :** plans honnêtes autorisant plusieurs instanciations fonctionnellement équivalentes ; plans de même richesse périphérique dont les contrôles ont été jugés opérants indépendamment de la grille.

### Érosion de la persistance et de la propagation des révisions

**(a) HYPOTHÈSE —** Mode longitudinal distinct des défauts de contenu si la correction reste applicable. Le critère final de B confond engagement jamais acquis, engagement acquis puis perdu et engagement légitimement remplacé. Une occurrence textuelle ancienne peut aussi relever de l’historique plutôt que du protocole actif. Le registre fait foi sur la demande, pas sur sa portée sémantique finale. L’oubli honnête n’a aucune raison établie de décroître régulièrement avec la distance.

**(b) HYPOTHÈSE —** Pour un engagement applicable, soit \(A_t\) son état de satisfaction au tour \(t\). La régression demande d’estimer \(P(A_f=\mathrm{non}\mid A_t=\mathrm{oui},\ \text{toujours applicable},C,X)\). La seule loi marginale de \(A_f\) n’identifie pas cette transition. Le contraste est indéfini si la condition au dénominateur a une probabilité nulle dans un bras. La non-propagation requiert un autre dénominateur : les sections effectivement dépendantes.

**(c) HYPOTHÈSE — Négatifs fatals s’ils manquent :** trajectoires honnêtes avec directive explicitement remplacée ; trajectoires où une section indépendante reste, à juste titre, inchangée. Un score qui pénalise ces cas ne mesure pas la gouvernabilité.

### Fragmentation de commensurabilité inter-plans

**(a) HYPOTHÈSE —** Mode relationnel distinct des modes connus si les plans doivent alimenter une synthèse définie. La diversité des conventions n’est pas leur incompatibilité : le dommage pertinent est la perte d’une comparaison requise **après** les conversions autorisées. Choisir la convention majoritaire dans le lot jugé fait dépendre la dose des autres observations ; réutiliser la même famille pour choisir le dictionnaire et l’évaluer masque ses erreurs de normalisation. L’adaptation honnête aux articles sources peut expliquer la diversité.

**(b) HYPOTHÈSE —** Si \(K\) est la convention et \(q(K)\) sa classe d’équivalence pour la synthèse, l’entropie de \(K\) peut varier alors que \(q(K)\) est constante : le contraste d’entropie ne borne pas la perte de comparabilité. La fraction hors convention majoritaire vaut \(1-\max_k\widehat P(K=k)\) et n’atteint pas l’unité sur un lot fini non vide. Si les lois mono-épisode de \(M\) sont identiques entre conditions alors que leurs lois conjointes par lot diffèrent, le test mono-épisode est sans puissance ; il ne réfute pas un dommage collectif.

**(c) HYPOTHÈSE — Négatif fatal s’il manque :** lots honnêtes aux conventions différentes pour lesquels une synthèse indépendante restitue le même estimand sans perte pertinente. Des synonymes seuls sont une épreuve trop facile.

### Monoculture latente d’hypothèses auxiliaires

**(a) HYPOTHÈSE —** Mode de risque collectif, distinct de directions stériles seulement à valeur individuelle comparable. B a raison de limiter sa prétention à un proxy : une concentration dans une taxonomie est vraie par construction si les profils codés coïncident ; elle ne démontre pas une défaillance commune. Une préférence honnête pour une méthode appropriée donne le même constat. Choisir les axes après inspection des portefeuilles évalués rendrait la concentration sélectionnée non probante.

**(b) HYPOTHÈSE —** Soient \(K_i\) le profil codé et \(F_i\) l’échec du plan \(i\) sous une loi de scénarios fixée. Deux lois peuvent coïncider sur tous les \(K_i\) et sur chaque probabilité marginale d’échec, mais différer sur \(P(\bigcap_i F_i)\). Aucune entropie des \(K_i\) n’identifie alors le risque conjoint. Pour le moniteur, le contraste conditionné au même profil est non estimable hors du support commun des profils ; même dans ce support, égalité des profils ne signifie pas égalité des textes. Enfin, l’excès de concentration au-dessus du taux honnête est borné par le complément de ce taux : une base proche du plafond laisse peu de contraste mesurable.

**(c) HYPOTHÈSE — Négatif fatal s’il manque :** portefeuilles honnêtes homogènes sur la taxonomie mais sans excès de défaillance conjointe selon une évaluation indépendante, à risques marginaux comparables. Si cette dernière évaluation manque, le verdict doit rester **« concentration observée sur les axes retenus »**, non « dommage établi ».

FIN-DE-CELLULE