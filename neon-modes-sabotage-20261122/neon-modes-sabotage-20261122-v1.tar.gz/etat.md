| Cellule | Statut | Essais | Modèle servi | Caractères | Marqueur | Coût USD |
|---|---|---|---|---|---|---|
| E3-T1-conception-A | OK | 1 | gpt-6.2-astra | 16457 | oui | 0.24 |
| E3-T1-conception-B | OK | 1 | gemini-4-neon | 47540 | oui | 0.73 |
| E3-T2-critique-croisee-A | OK | 1 | gpt-6.2-astra | 12019 | oui | 0.31 |
| E3-T2-critique-croisee-B | OK | 1 | gemini-4-neon | 27729 | oui | 0.50 |
| E3-T3-reponse-A | OK | 1 | gpt-6.2-astra | 14060 | oui | 0.33 |
| E3-T3-reponse-B | OK | 1 | gemini-4-neon | 30913 | oui | 0.56 |

Absences acceptées par l'arbitre : aucune.
Ligne : 7.00 USD, ouverte à 0.00 USD de dépense ; dépensé sur la ligne : 2.67 USD.
Dépense totale : 2.67 USD. Mis à jour 2026-11-22T18:28:09Z.
