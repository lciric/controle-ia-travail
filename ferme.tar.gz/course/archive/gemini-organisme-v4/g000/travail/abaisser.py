import os, sys
# Abandon des privilèges après `unshare` (qui exige root pour les espaces de noms) et juste avant l'organisme :
# groupes vidés, gid puis uid non privilégiés, puis exec du programme demandé. Écrit par le noyau, lecture seule.
uid, gid = int(sys.argv[1]), int(sys.argv[2])
os.setgroups([])
os.setgid(gid)
os.setuid(uid)
if os.getuid() != uid or os.geteuid() != uid:
    sys.exit("abaissement de privileges impossible")
os.execv(sys.argv[3], sys.argv[3:])
