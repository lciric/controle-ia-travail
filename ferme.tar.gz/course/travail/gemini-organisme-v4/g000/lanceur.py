import importlib, json, os, sys, traceback
racine = os.getcwd()
sys.path.insert(0, os.path.join(racine, "organisme"))
sys.path.insert(0, racine)
contexte = json.load(open(os.environ["ESSAIM_CONTEXTE"], encoding="utf-8"))
manifeste = json.load(open(os.path.join(racine, "organisme", "manifeste.json"), encoding="utf-8-sig"))
module, fonction = manifeste["entree"].split(":", 1)
statut = {"code": "OK", "erreur": None}
try:
    m = importlib.import_module(module)
    resultat = getattr(m, fonction)(contexte)
    statut["retour"] = str(resultat)[:2000] if resultat is not None else None
except BaseException as e:  # tout : l'organisme ne doit pas pouvoir faire taire le noyau
    statut = {"code": "EXCEPTION", "erreur": traceback.format_exc()[-4000:]}
with open("statut_execution.json", "w", encoding="utf-8") as fh:
    json.dump(statut, fh, ensure_ascii=False)
