"""noyau_client — fourni par le noyau dans le bac à sable ; seul accès aux espèces."""
import json, os, socket

_CHEMIN = os.environ["ESSAIM_SOCKET"]


def _echanger(requete):
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
        s.connect(_CHEMIN)
        s.sendall((json.dumps(requete, ensure_ascii=False) + "\n").encode("utf-8"))
        tampon = b""
        while not tampon.endswith(b"\n"):
            morceau = s.recv(65536)
            if not morceau:
                break
            tampon += morceau
    return json.loads(tampon.decode("utf-8"))


def appeler(espece, prompt, max_tokens=None, role=""):
    return _echanger({"op": "appeler", "espece": espece, "prompt": prompt, "max_tokens": max_tokens, "role": role})


def especes():
    return _echanger({"op": "especes"})["especes"]


def budget():
    return _echanger({"op": "budget"})


def rechercher(requete, n=5, role="", source="arxiv"):
    return _echanger({"op": "rechercher", "requete": requete, "n": n, "role": role, "source": source})


def telecharger(reference, role=""):
    return _echanger({"op": "telecharger", "reference": reference, "role": role})


def entrainer(spec, role=""):
    return _echanger({"op": "entrainer", "spec": spec, "role": role})


def predire(identifiant, ids, role=""):
    return _echanger({"op": "predire", "identifiant": identifiant, "ids": list(ids), "role": role})
