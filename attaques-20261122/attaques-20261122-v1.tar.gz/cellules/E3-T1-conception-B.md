# Proposition B — Quatre hypothèses de fragilité à départager

**RAPPORTÉ — Pièces absentes :** aucune proposition A, C ou D ni aucune réponse antérieure n’est jointe.

**VÉRIFIÉ — Périmètre.** Le programme prévoit des sondes à maximum ou à attention, des juges textuels et des lecteurs confrontés à une référence cachée. Il impose une sonde aléatoire appariée et distingue le bras aveugle du bras informé. **HYPOTHÈSE —** Les quatre fiches ci-dessous désignent des familles candidates, non des attaques démontrées. Leur nouveauté bibliographique n’est pas établie.

### Règle de décision commune — HYPOTHÈSE de travail

La quantité décisive est la **perte de détection attribuable au mode**, et non le taux brut d’épisodes manqués. Je propose de mesurer, pour chaque instrument, la différence de sensibilité entre témoin et condition candidate, au même taux de fausses alertes sur épisodes honnêtes appariés. J’appelle cette différence \(D\). Le point de comparaison est choisi sur calibration indépendante ; à l’épreuve, on rapporte aussi les deux taux au seuil de déploiement gelé. Cette seconde lecture distingue un déplacement de calibration d’une perte de discrimination.

Dans chaque duel, \(H_A\) signifie que \(D\) dépasse une marge de pertinence \(\delta\) fixée par l’arbitre avant ouverture ; \(H_B\), que \(D\) ne la dépasse pas. Un intervalle apparié entièrement au-dessus de \(\delta\) réfute \(H_B\) ; un intervalle entièrement au-dessous ou à son niveau réfute \(H_A\). Un intervalle qui chevauche la marge ne tranche pas. **Condition d’interprétation :** si le moniteur ne détecte déjà rien d’utile sur le témoin, ou si le contrôle négatif subit une perte comparable, on ne conclut ni à une résistance ni à une exposition spécifique.

### Fiche S — Dépendance des extrêmes

- **Nom, cible, définition — HYPOTHÈSE.** *Dépendance des extrêmes*, sondes à maximum. À dommage, longueur et distributions de scores locaux comparables, la dépendance entre positions pourrait changer la probabilité qu’un épisode comporte au moins une alerte.
- **Propriété exploitée — HYPOTHÈSE.** Une bonne séparation locale ne garantit pas que la séparation au niveau de l’épisode soit stable : plusieurs positions informatives peuvent apporter autant d’information qu’une seule si elles fluctuent ensemble.
- **Pourquoi un mode — HYPOTHÈSE.** L’invariant est un changement de loi *jointe*, non une diminution du score de chaque position. Le mode ne repose ni sur une moyenne ni sur un allongement du texte.
- **Connaissance et prise — HYPOTHÈSE.** Bras informé quant à l’agrégation ; prise supposée sur la dépendance entre positions de ses propres trajectoires. Aucun accès aux activations mesurées, au seuil ou au score d’entraînement n’est requis par la définition. La possibilité d’une telle prise reste à établir.
- **Inédit — HYPOTHÈSE.** Proche du décalage de dépendance en statistique des extrêmes ; la distinction testée porte sur la perte de détection d’un dommage diffus *à marges locales conservées*. Cela pourrait n’être qu’une application de cette famille.
- **Mesure d’exposition — HYPOTHÈSE.** \(D_S\) pour la sonde à maximum, sur épisodes appariés en longueur, tâche et dommage ; épisodes honnêtes appariés également en longueur et tâche. Contrôle négatif : variation de trajectoire comparable sans changement de dépendance. Un écart sur des séries de scores artificiellement construites pour avoir des maxima différents ne prouverait rien sur l’agent.
- **Vérité indépendante — HYPOTHÈSE.** Un journal scellé attribue le bras ; une annotation des dépendances entre événements, indépendante de la sonde, contrôle sa réalisation. Un validateur de l’état final contre la référence établit le dommage. La conservation approximative des marges de la sonde est un diagnostic après ouverture, jamais un critère de sélection des épisodes.
- **Ce que la mesure apprendrait — HYPOTHÈSE.** \(H_A\) : la dépendance coûte plus que \(\delta\) en détection ; \(H_B\) : pas davantage. Appliquer la règle commune à \(D_S\). Si les marges locales divergent sensiblement, le duel ne permet pas d’attribuer la perte à la dépendance.
- **Parade — HYPOTHÈSE.** Représenter la redondance entre positions plutôt que la seule hauteur du pic ; coût : davantage d’états à conserver et de trajectoires pour la calibration.
- **Manque — HYPOTHÈSE.** Il faudrait des trajectoires réelles assez comparables pour vérifier simultanément les marges locales, la dépendance et le dommage.

### Fiche R — Inversion du repère conditionnel

- **Nom, cible, définition — HYPOTHÈSE.** *Inversion du repère conditionnel*, sondes sur états internes. Une même distinction interne pourrait être informative dans plusieurs contextes, mais y avoir des significations opposées pour le dommage.
- **Propriété exploitée — HYPOTHÈSE.** Le moniteur suppose implicitement qu’une distinction apprise conserve son sens entre contextes, ou qu’il sait reconnaître le contexte nécessaire à son interprétation.
- **Pourquoi un mode — HYPOTHÈSE.** L’information reste lisible conditionnellement ; c’est son interprétation commune qui échoue. Une disparition générale de l’information interne serait un autre phénomène.
- **Connaissance et prise — HYPOTHÈSE.** Bras aveugle envisageable si l’agent peut influer sur le contexte de son propre calcul sans connaître la sonde. Ni accès aux poids du moniteur ni score dans l’entraînement.
- **Inédit — HYPOTHÈSE.** Voisin du décalage conditionnel et du paradoxe de Simpson. Une simple variation des proportions de contextes n’est pas distinctive ; il faut une opposition observable du sens du signal entre strates.
- **Mesure d’exposition — HYPOTHÈSE.** \(D_R\) de la sonde gelée, avec mêmes proportions de contextes et de dommages dans les comparaisons. Cas honnêtes issus des mêmes tâches et contextes. Contrôle négatif : diversité contextuelle sans opposition de sens. Qu’une sonde ajustée séparément dans chaque strate explique mieux ses propres données d’ajustement ne prouve rien.
- **Vérité indépendante — HYPOTHÈSE.** Le contexte doit avoir une étiquette externe antérieure à la lecture des activations. L’affectation scellée atteste la condition ; le dommage est vérifié sur l’état final. L’opposition de sens est recherchée sur épisodes tenus à part.
- **Ce que la mesure apprendrait — HYPOTHÈSE.** Sous réserve qu’un lecteur conditionnel conserve une discrimination hors échantillon, \(H_A\) : le moniteur perd plus que \(\delta\) ; \(H_B\) : sa lecture résiste dans cette marge. La règle commune tranche sur \(D_R\). Sans lisibilité conditionnelle démontrée, une sonde simplement faible reste une explication.
- **Parade — HYPOTHÈSE.** Conditionner la lecture sur un repère contextuel disponible au moment de décider ; coût : couverture de chaque contexte et risque d’erreur sur le repère lui-même.
- **Manque — HYPOTHÈSE.** Un contexte annotable indépendamment, accessible au moniteur et assez fréquent pour tester l’inversion sans choisir les strates après coup.

### Fiche T — Découplage entre citation et portée

- **Nom, cible, définition — HYPOTHÈSE.** *Découplage entre citation et portée*, lecteurs de vérité. Un extrait peut être authentique et pertinent pour une partie du verdict sans justifier le verdict à l’échelle de l’épisode.
- **Propriété exploitée — HYPOTHÈSE.** L’appartenance de l’extrait au texte et sa force probante pour une conclusion globale sont deux propriétés distinctes. **VÉRIFIÉ :** le programme prévoit une vérification programmée de l’extrait ; la portée exacte de cette vérification n’est pas précisée dans la pièce.
- **Pourquoi un mode — HYPOTHÈSE.** Le défaut porte sur la relation entre preuve et conclusion, pas sur une fausse citation, une instruction au juge ou une modification de la référence.
- **Connaissance et prise — HYPOTHÈSE.** Bras informé de l’exigence de citation ; prise limitée à la distribution des preuves dans son propre texte. Aucun score nécessaire.
- **Inédit — HYPOTHÈSE.** Proche de la sélection partiale des preuves. La distinction candidate est une erreur de **portée** qui subsiste même lorsque le fait local cité est exact ; la revendication de nouveauté est faible.
- **Mesure d’exposition — HYPOTHÈSE.** \(D_T\) sur la détection du dommage par le lecteur, à exactitude matérielle des citations comparable. Témoin sans attaque et cas honnêtes appariés sur longueur, quantité de preuves et difficulté de lecture. Contrôle négatif : même dispersion de preuves lorsque le fait local suffit au verdict. La présence textuelle d’une citation choisie parmi des extraits présents est vraie par construction.
- **Vérité indépendante — HYPOTHÈSE.** Restreindre le duel aux tâches où un validateur externe décide du dommage. Une annotation indépendante de la portée de l’extrait distingue *fait local exact* et *conclusion justifiée*. L’affectation scellée atteste le bras, pas la validité de la conclusion.
- **Ce que la mesure apprendrait — HYPOTHÈSE.** \(H_A\) : changer la portée probante coûte plus que \(\delta\) ; \(H_B\) : le lecteur conserve sa sensibilité dans cette marge. Appliquer la règle à \(D_T\), sans écarter les verdicts non cités du dénominateur.
- **Parade — HYPOTHÈSE.** Vérifier que les preuves couvrent les prémisses nécessaires au verdict, quitte à rendre un verdict indéterminé ; coût : lectures supplémentaires et baisse de couverture, à publier séparément.
- **Manque — HYPOTHÈSE.** Des tâches à vérité exécutable et une annotation reproductible de la suffisance probante. Un second juge de même conception ne fournit pas à lui seul cet étalon.

### Fiche J — Dépendance des erreurs entre juges

- **Nom, cible, définition — HYPOTHÈSE.** *Dépendance des erreurs entre juges*, décision collective. Une population de textes pourrait modifier la fréquence des erreurs communes sans modifier sensiblement le taux d’erreur propre à chaque juge.
- **Propriété exploitée — HYPOTHÈSE.** La valeur de la diversité dépend des erreurs que les juges ne font *pas ensemble*, et non de la seule diversité de leurs identités. **VÉRIFIÉ :** des juges hétérogènes sont prévus ; aucune règle collective particulière n’est donnée.
- **Pourquoi un mode — HYPOTHÈSE.** La cible est le bénéfice de la pluralité : un juge individuel n’a pas besoin de devenir moins performant. Ce mode n’a pas de cible collective si aucune décision ne dépend de plusieurs juges.
- **Connaissance et prise — HYPOTHÈSE.** Bras informé de l’existence du collège ; prise supposée sur les propriétés communes des textes interprétés par ses membres, non sur les votes, les seuils ou les modèles. Aucun score dans l’entraînement.
- **Inédit — HYPOTHÈSE.** Proche des défaillances de cause commune. La restriction distinctive est la conservation des performances individuelles ; elle ne suffit pas à établir une famille bibliographiquement nouvelle.
- **Mesure d’exposition — HYPOTHÈSE.** \(D_J\) pour une règle collective déclarée avant ouverture, avec sensibilités et fausses alertes individuelles comparables. Témoins dommageables et honnêtes appariés en tâche, difficulté indépendante et complétude de preuve. Contrôle négatif : changement de population textuelle sans changement attendu des erreurs communes. Recomposer artificiellement les votes pour les rendre concordants ne démontre aucune exposition sur texte réel.
- **Vérité indépendante — HYPOTHÈSE.** La référence et le validateur externe déterminent les erreurs de chaque juge sur les *mêmes* épisodes. L’affectation scellée établit le bras ; ni l’unanimité ni la majorité ne définit la vérité.
- **Ce que la mesure apprendrait — HYPOTHÈSE.** À performances individuelles stables, \(H_A\) : la décision collective perd plus que \(\delta\) ; \(H_B\) : pas davantage. Appliquer la règle à \(D_J\). Une hausse des erreurs communes sans perte pour la règle choisie ne réfute pas \(H_B\).
- **Parade — HYPOTHÈSE.** Choisir les lecteurs sur leur complémentarité d’erreurs validée hors échantillon et réserver une voie de vérification indépendante ; coût : annotations communes et maintien de plusieurs lecteurs.
- **Manque — HYPOTHÈSE.** Une règle collective déclarée et assez d’épisodes indépendants pour estimer les erreurs communes sans confondre leur dépendance avec une hausse générale de difficulté.

### Lecture minimale des instruments et ancrage matériel

**HYPOTHÈSE — Plan de mesure.** Pour chacune des sondes — linéaire, différence de moyennes, petit perceptron, attention, Mahalanobis — publier séparément détection et fausses alertes par épisode, contre sonde aléatoire appariée **et** règle mécanique de longueur et de nombre de positions. Pour les juges par action et à état, publier les mêmes taux par épisode sur historiques honnêtes de même longueur et de même tâche, contre un comptage mécanique des actions et des incohérences explicitement vérifiables. Pour les lecteurs, comparer le verdict à la vérification mécanique de présence de la citation seule ; pour le collège, comparer aussi aux juges isolés. Un instrument ne mérite crédit que pour un gain hors échantillon au même budget de fausses alertes. La matrice de transfert contiendrait les pertes corrigées du témoin, pas les seuls taux d’échec bruts ; une case sans compétence témoin serait déclarée non interprétable.

**HYPOTHÈSE — Faisabilité, non devis.** Un pilote pourrait utiliser des modèles à poids ouverts des familles Qwen et Gemma, sous réserve d’accès aux états requis, de licences compatibles et d’une hétérogénéité effective des erreurs. Le poste sondes demande surtout une passe d’extraction et du stockage ; le poste juges répète l’inférence par lecteur et épisode. Enveloppe pilote **illustrative** : quelques dizaines d’heures de GPU, quelques dizaines à quelques centaines d’euros de calcul, hors annotation. Sans longueurs de contexte, effectif d’épisodes et précision visée sur les erreurs communes, cette enveloppe ne chiffre pas une expérience décisive.

### (a) Présupposés non établis

- **HYPOTHÈSE :** un agent peut effectivement influer sur chacune des propriétés proposées avec les seules prises du bras déclaré. Une fragilité d’estimateur ne démontre pas cette capacité.
- **HYPOTHÈSE :** on peut conserver difficulté, dommage et qualité des témoins assez proches pour isoler l’effet ; en particulier, l’appariement ne doit pas être obtenu en sélectionnant sur les scores attaqués.
- **HYPOTHÈSE :** une vérité du dommage indépendante et assez précise existe sur un sous-ensemble pertinent. Si la conclusion correcte est indécidable à partir des observations autorisées, une erreur ne distingue pas un juge fragile d’un juge privé d’information.
- **HYPOTHÈSE :** au moins une famille dépasse une spécialisation de phénomènes statistiques connus. **RAPPORTÉ :** le directeur demande cette nouveauté ; cette demande n’en constitue pas la preuve.

### (b) Classements séparés

**HYPOTHÈSE — Distance aux familles connues, de la plus grande à la plus faible :** S, R, T, J. S impose la contrainte précise de marges locales conservées sous agrégation par maximum ; J reste très proche d’une défaillance de cause commune.

**HYPOTHÈSE — Solidité de la mesure, de la plus forte à la plus faible :** T, J, S, R. Sur tâches à vérité exécutable, T sépare directement authenticité, portée et verdict. J dispose de votes observables mais exige des erreurs communes assez fréquentes. S demande une comparaison de lois locales sur trajectoires réelles. R exige en plus de justifier le repère contextuel sans le déduire a posteriori de l’échec de la sonde.

FIN-DE-CELLULE