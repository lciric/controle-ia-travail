## Sur la proposition A

**Statuts.** Les intitulés et critères attribués à A ou C sont **RAPPORTÉS** d’après leurs pièces. Les diagnostics, rapprochements avec des familles connues et conditions de validité ci-dessous ont le statut **HYPOTHÈSE** : ils portent sur l’interprétation des mesures, pas sur une exposition observée. **VÉRIFIÉ** (faits 2 et 4) : le dossier spécifie une agrégation par maximum ou attention et une vérification programmatique d’extrait. Il ne spécifie ni la forme de l’attention ni la conséquence décisionnelle d’un extrait rejeté.

**Règle de jugement pour les deux propositions — HYPOTHÈSE.** Soit \(R\) le rappel à taux de fausses alertes \(\alpha\), rapporté à une population honnête désignée. Lorsque la fiche oppose deux instruments, le contraste pertinent est l’écart de rappel entre eux **sous le mode, moins ce même écart sans le mode**. Un avantage permanent du comparateur ne caractérise pas une exposition. Pour chaque population et contraste \(\Delta\) orienté vers la perte, les hypothèses exclusives sont \(H_A:\Delta\leq\delta\) et \(H_B:\Delta>\delta\), où \(\delta\) est la perte pertinente déclarée avant évaluation. Un intervalle entièrement au-dessus de \(\delta\) réfute \(H_A\) ; entièrement en dessous, il réfute \(H_B\) ; à cheval, il ne tranche pas. Cela ne réfute pas une affirmation d’existence sur *toutes* les politiques possibles.

**Contrôles communs — HYPOTHÈSE.** Les témoins négatifs sont de deux sortes : épisodes honnêtes portant la nuisance étudiée, et épisodes avec dommage comparable **sans** le mode supposé. Le premier contrôle les fausses alertes, le second le niveau de détection de départ. Il faut en outre une vérité du dommage indépendante du score contesté et une séparation par tâche ou trajectoire entre construction, étalonnage et épreuve ; séparer des positions du même épisode ne suffit pas. Sans support commun en difficulté et en gravité, l’écart conditionnel n’est pas identifiable. Si l’incertitude du quantile honnête suffit à faire franchir \(\delta\) au contraste, le rappel à \(\alpha\) n’est pas jugeable. Ces réserves s’appliquent aussi aux classements de solidité.

### A — Censure sous-extrémale

- **(a) Attribution.** Famille candidate de perte de puissance d’une statistique de pic, proche de l’opposition entre signal ponctuel et signal distribué. La fiche comporte des détails opérants de réalisation, non repris ici. Une dominance stochastique des maxima marginaux n’implique pas leur ordre presque sûr dans une même trajectoire. Choisir les cas parce que le comparateur cumulatif y répond, puis prendre sa réponse pour confirmation indépendante, serait circulaire.
- **(b) Puissance.** La loi du maximum dépend de la loi jointe des positions, pas seulement de la longueur. À longueurs égales mais dépendances temporelles différentes, le contraste peut mesurer une variation du bruit de fond. Ni le domaine d’attraction de Gumbel ni l’assimilation de l’attention à un maximum ne sont acquis. Si l’avantage du cumulatif est identique avec et sans mode, le contraste spécifique est nul, même avec un grand écart brut.
- **(c) Négatifs indispensables.** Épisodes honnêtes appariés en longueur **et en dépendance temporelle** ; dommages sans mode, lus par les deux agrégateurs avec leurs étalonnages propres. Sans eux, la comparaison sur les mêmes états ne distingue pas exposition et mauvais choix général d’agrégateur.

### A — Compensation spectrale

- **(a) Attribution.** Famille candidate d’erreur d’un score de distance ; la fiche dépasse la définition de famille par des détails géométriques opérants. Avec la vraie covariance inversible, chaque direction propre bénigne centrée apporte en espérance la même contribution à la distance *au carré*. Le nombre de directions peut compter ; leur faible variance ne leur confère pas à elle seule un poids moyen dominant. Une baisse du score ayant servi à définir les cas serait acquise par sélection.
- **(b) Puissance.** Une baisse d’espérance n’impose ni baisse de médiane ni perte de rappel dans la queue d’alerte. Si l’incertitude sur la covariance estimée change l’ordre des médianes, le signe du déplacement n’est pas jugeable. Une différence d’AUROC non significative avec la sonde aléatoire ne prouve pas leur équivalence : son intervalle doit exclure un avantage pertinent.
- **(c) Négatifs indispensables.** Loi honnête de même domaine et de dispersion comparable, indépendante de l’estimation de covariance ; sonde aléatoire appariée et dommages sans mode sur lesquels la sonde nominale a du pouvoir. Une simple variation bénigne de dispersion ne doit pas suffire à reproduire toute la signature attribuée au mode.

### A — Goulot extractif

- **(a) Attribution.** Mode candidat d’insuffisance d’un certificat local, proche des limites de justification extractive. Exiger une citation n’implique pas que le juge fonde son verdict sur cette seule citation. Le comparateur proposé change aussi la représentation du document : un gain peut venir de la facilité de lecture. La pièce donne des détails de réalisation non nécessaires à ce diagnostic.
- **(b) Puissance.** Notons \(Y\) le verdict brut et \(V\) la validité de l’extrait. Sans la loi du verdict final conditionnelle à \((Y,V)\), une baisse de rappel ne peut être attribuée au certificat. Une faible information sur le dommage dans chaque extrait de position *fixe* n’implique pas une faible information dans l’extrait *choisi* après lecture du texte entier. Le « taux de capture » est non jugeable si la conformité de l’extrait est annotée à partir du verdict contesté.
- **(c) Négatifs indispensables.** Documents relationnels honnêtes et dommages à preuve locale, avec le même texte intégral accessible au lecteur et la même règle de décision. La vérité fonctionnelle doit rester disponible même quand la citation est rejetée.

### A — Normalisation et oubli du filtre à état

- **(a) Attribution.** Deux familles déjà interprétables séparément : dérive de référence et perte de mémoire. Un score final ne les sépare pas. Une dépendance au chemin est normale pour un juge à état ; elle n’est pas en elle-même une perte de détection. La fiche donne des précisions temporelles opérantes que je ne reprends pas.
- **(b) Puissance.** Si l’entropie intermédiaire est presque déterminée par la longueur, sa pente partielle à longueur fixée est mal estimée ; si elle l’est exactement, la pente n’est pas identifiable. Si les historiques intermédiaires modifient aussi \(P(D\mid\text{historique})\), un déplacement de score peut être approprié. Une baisse entre deux scores finaux n’est pas un test de la propriété conditionnelle de sous-martingale.
- **(c) Négatifs indispensables.** Histoires honnêtes de mêmes longueur et entropie ; épisodes avec dommage où la prémisse ancienne n’est pas nécessaire au verdict. Une baisse comparable dans ces derniers incrimine la difficulté générale de lecture, non l’oubli de la prémisse.

### A — Variable suppressive de conflit

- **(a) Attribution.** Mode candidat de raccourci partagé. Un faible taux de fausses alertes n’impose aucun coefficient négatif ; une pente négative ne démontre pas un biais de collisionneur. Un indice de conflit tiré des mêmes sorties que les scores créerait une dépendance de mesure. Les détails opérants de la fiche ne sont pas nécessaires au test.
- **(b) Puissance.** Sans variation résiduelle de l’indice à tâche fixée, sa pente n’est pas identifiable. Pour les erreurs \(E_s,E_j\), il faut comparer \(P(E_s,E_j\mid X,D)\) au produit de leurs probabilités marginales conditionnelles, \(X\) désignant la difficulté exogène. Un fort taux d’échecs conjoints peut coexister avec une indépendance exacte. En bras aveugle, cette co-défaillance n’est pas, à elle seule, le transfert d’une attaque réglée contre une source.
- **(c) Négatifs indispensables.** Tâches honnêtes difficiles, dommages sans mode dans les mêmes strates, indice défini indépendamment des sorties, et dépendance de référence des erreurs sans mode. Sans cette dernière, même un excès de co-défaillances ne serait pas spécifique au conflit.

## Sur la proposition C

### C — Copule inter-positions

- **(a) Attribution.** Mode candidat de changement de dépendance à marginales fixes. L’égalité des marginales ne rend pas le maximum aveugle : \(P(\max_t S_t\leq s)=P(\bigcap_t\{S_t\leq s\})\) dépend précisément de la loi jointe. Une bonne détection par le maximum ne réfute donc pas l’invariance marginale. Le comparateur relationnel ne peut servir à choisir les trajectoires puis à certifier leur séparabilité.
- **(b) Puissance.** Si l’intervalle sur la divergence marginale inclut des écarts suffisants pour expliquer le rappel, l’attribution à la seule copule est indécidable. Inversement, des dépendances différentes peuvent avoir les mêmes moments bilinéaires : l’échec du comparateur proposé n’établit pas l’absence d’information relationnelle.
- **(c) Négatifs indispensables.** Trajectoires honnêtes avec variation naturelle des dépendances ; dommages sans mode, appariés en longueur et tâche ; comparateur de capacité appariée évalué hors construction. Une sonde aléatoire seule ne contrôle pas le gain de capacité du lecteur relationnel.

### C — Déplacement de loi nulle usage–mention

- **(a) Attribution.** Famille plausible de confusion entre thème et portée, proche d’une dérive d’étalonnage. Un déplacement du quantile honnête mesure un changement de point de fonctionnement, pas nécessairement une perte de discrimination. L’égalité des lois de scores conditionnelles au dommage rendrait leur non-séparabilité vraie par construction.
- **(b) Puissance.** Si les deux classes subissent la même transformation strictement croissante, le quantile peut changer sans aucune perte de ROC. La précision dépend aussi de la prévalence du dommage : sans prévalence commune, son recul à seuil fixe n’isole rien. Un déplacement rapporté à l’écart bénin–dommage témoin est instable si cet écart est voisin de zéro. L’aire ROC partielle exige le même domaine de fausses alertes et la même normalisation.
- **(c) Négatifs indispensables.** Cas honnêtes de même thème et complexité, et dommages sans mode de même prévalence ; population honnête d’étalonnage distincte de celle de mesure. La règle lexicale est un comparateur, pas un plafond de précision.

### C — Découplage sélection–valuation

- **(a) Attribution.** Famille de dilution dans un agrégateur pondéré ; la fiche contient des détails géométriques de ciblage, non repris. L’appariement de la valuation est utile, mais un écart maximum–attention sur des épisodes retenus pour cet écart serait tautologique. Même des poids croissants avec la valuation ne transforment pas une moyenne pondérée en maximum.
- **(b) Puissance.** Si les écarts de rappel entre agrégateurs sont les mêmes hors mode et sous mode, la perte spécifique est nulle. Si la région invoquée a une masse accessible indiscernable de zéro, son existence géométrique ne renseigne pas sur l’exposition. Une asymétrie de transfert n’est pas interprétable lorsque les taux de succès sur les sources ou les rappels de départ ne sont pas comparables.
- **(c) Négatifs indispensables.** Épisodes honnêtes et dommages sans mode de même longueur, valuation partagée, étalonnages indépendants pour chaque agrégateur. Les évaluations sur le substitut de construction ne doivent pas entrer dans la mesure de transfert hors échantillon.

### C — Collision de quotient à état

- **(a) Attribution.** Mode de perte de suffisance d’un résumé. Une compression peut perdre beaucoup d’information sans perdre celle qui importe au dommage. À état et suite strictement identiques, l’égalité de la loi du verdict d’un juge ne lisant que ces entrées est vraie par construction ; elle ne mesure pas la fréquence des collisions pertinentes.
- **(b) Puissance.** Si \(I(D;\text{préfixe}\mid\text{état},\text{suite})\) est nul, le préfixe brut n’apporte pas d’information supplémentaire sur le dommage, même si le juge préfère son format. Si les collisions pertinentes sont rares, un grand écart conditionnel peut avoir un effet populationnel négligeable. Un juge rétrospectif lui-même au plancher rend le contraste peu puissant.
- **(c) Négatifs indispensables.** Cas de même difficulté où l’état est suffisant, incluant des collisions sans conséquence ; estimation de leur fréquence sur une population non sélectionnée. Le verdict rétrospectif est un comparateur de compétence, non un oracle.

### C — Gel antégrade

- **(a) Attribution.** Hypothèse architecturale plus précise qu’un biais d’ordre, mais non identifiée par le contraste de lecture. Le témoin de longueur contrôle le volume, pas la répétition d’indices pertinents, leur récence ni les occasions de les reconnaître. La fiche précise un agencement opérant, non reproduit ici.
- **(b) Puissance.** Si les lois de gains conditionnelles à la récence et à la difficulté sont identiques avec et sans nécessité d’interprétation rétrospective, le gain ne distingue pas le gel allégué d’un bénéfice général de relecture. Sans support commun pour ces covariables, leurs contributions sont inséparables. Des erreurs corrélées entre juges à difficulté marginalisée n’identifient pas une architecture commune.
- **(c) Négatifs indispensables.** Textes honnêtes et dommages dont la preuve ne dépend pas de l’ordre, avec distributions de répétition, de position et de longueur comparables ; taux de co-erreur inter-juges hors mode, conditionné à la difficulté. La référence cachée ne garantit pas à elle seule l’absence du même biais chez le lecteur de vérité.

### C — Recombinaison du canal de copie

- **(a) Attribution.** Mode candidat de perte entre reconnaissance et validation, proche d’une erreur d’extraction. C’est ici que la séparation des sorties brute et finale est la plus informative. Elle localise une perte dans la chaîne de décision, pas son mécanisme neuronal. La fiche contient des détails opérants sur la forme des erreurs, non repris.
- **(b) Puissance.** *Si* la décision finale est conjonctive, à règle brute inchangée, la perte de rappel vaut \(P(Y{+}\mid D)\,P(V{-}\mid Y{+},D)\) sur les cas endommagés. Cette identité ne prouve aucune interférence particulière et ne vaut pas comme comparaison à fausses alertes réétalonnées. Si les vrais positifs bruts sont rares, le second facteur est imprécis ; si les rejets donnent lieu à abstention ou révision, il ne mesure même pas le taux de faux négatifs finaux.
- **(c) Négatifs indispensables.** Citations valides et invalides étiquetées indépendamment pour contrôler le vérificateur ; épisodes de difficulté de copie comparable sans l’ambiguïté alléguée ; vérité fonctionnelle disponible pour les rejets comme pour les acceptations. Sans ces négatifs, un défaut ordinaire de format peut expliquer toute la perte.

## Sur la proposition D

**RAPPORTÉ** — Pièce E3-T1-conception-D absente (« jamais lancée ») ; aucune critique de méthode n’est possible.

FIN-DE-CELLULE