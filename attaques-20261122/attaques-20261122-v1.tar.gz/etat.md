| Cellule | Statut | Essais | Modèle servi | Caractères | Marqueur | Coût USD |
|---|---|---|---|---|---|---|
| E3-T1-conception-A | OK | 2 | gemini-4-argon | 40268 | oui | 2.32 |
| E3-T1-conception-B | OK | 1 | gpt-6.2-astra | 15474 | oui | 0.23 |
| E3-T1-conception-C | OK | 1 | gemini-4-carbon | 34787 | oui | 1.00 |
| E3-T2-critique-croisee-A | OK | 1 | gemini-4-argon | 48442 | oui | 0.69 |
| E3-T2-critique-croisee-B | OK | 1 | gpt-6.2-astra | 14942 | oui | 0.42 |
| E3-T2-critique-croisee-C | OK | 1 | gemini-4-carbon | 34413 | oui | 0.89 |
| E3-T3-reponse-A | OK | 1 | gemini-4-argon | 38209 | oui | 0.48 |
| E3-T3-reponse-B | OK | 1 | gpt-6.2-astra | 13915 | oui | 0.50 |
| E3-T3-reponse-C | OK | 2 | gemini-4-carbon | 34016 | oui | 3.11 |

Absences acceptées par l'arbitre : E3-T1-conception-D, E3-T2-critique-croisee-D, E3-T3-reponse-D.
Ligne : 16.00 USD, ouverte à 0.00 USD de dépense ; dépensé sur la ligne : 9.64 USD.
Dépense totale : 9.64 USD. Mis à jour 2026-11-22T19:09:34Z.
